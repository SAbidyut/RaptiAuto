RaptiAuto — Arduino section for your website (v2.34.0)
=====================================================

Upload
  1. Unzip. You get the folder "arduino".
  2. Upload the whole folder into your web root (public_html / htdocs / www),
     so the page opens at  https://your-site/arduino/
  3. Needs PHP 5.4 or newer. No database.

Files
  index.php            the page (puts header + #app + footer together)
  config.php           title, description, base URL, version — edit this one
  includes/header.php  <head>, style sheets and the start-up splash
  includes/footer.php  the scripts
  includes/functions.php
  favicon.svg          the tab icon
  css/style.css        main style sheet
  css/theme.css        the RAPTI look: colours, typeface, buttons
  js/app.js            the simulator (menus, Arduino, examples, manual)
  fonts/               Archivo, Inter, JetBrains Mono (used by the css)
  .htaccess            Apache: index.php as start page, file types (.wasm), caching

Notes
  - Keep the folders css/, js/ and fonts/ next to index.php.
  - Do not change the files in css/ and js/ (they are built and minified).
  - Projects are saved in the visitor's browser (localStorage).
  - Nginx: serve .wasm as application/wasm and use index.php as the index.

বাংলা
  1. Zip খুলুন — "arduino" ফোল্ডার পাবেন।
  2. পুরো ফোল্ডারটি hosting-এর public_html (বা htdocs) এ আপলোড করুন।
  3. ব্রাউজারে খুলুন: https://your-site/arduino/
  টাইটেল / ডেসক্রিপশন বদলাতে config.php এডিট করুন।
