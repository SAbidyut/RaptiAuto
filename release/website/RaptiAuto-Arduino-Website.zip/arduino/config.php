<?php
// RaptiAuto — Arduino section: settings of this page.
if (!defined('RAPTI')) { http_response_code(403); exit; }

return array(
    // which part of RaptiAuto this page shows: 'arduino', 'plc' or 'pi' (needs the matching js/ files)
    'section' => 'arduino',

    // the browser tab title and the search-engine description
    'title' => 'Arduino Simulator — RaptiAuto',
    'description' => 'Build Arduino and ESP32 circuits on a breadboard, write the code and simulate them in your browser. By RAPTI.',

    // URL of this folder. Leave it '' when index.php is opened from this folder (https://your-site/arduino/).
    // When the page is included from somewhere else, write the folder's URL with a / at the end, e.g. '/arduino/'.
    'base' => '',

    // added to every css / js URL (?v=…) so visitors get the new files after an update
    'version' => '2.30.0-08be7428',

    // style sheets, in this order
    'css' => array('css/style.css'),
);
