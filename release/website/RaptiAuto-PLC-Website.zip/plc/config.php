<?php
// RaptiAuto — PLC section: settings of this page.
if (!defined('RAPTI')) { http_response_code(403); exit; }

return array(
    // which part of RaptiAuto this page shows: 'arduino', 'plc' or 'pi' (needs the matching js/ files)
    'section' => 'plc',

    // the browser tab title and the search-engine description
    'title' => 'Delta PLC Lab — RaptiAuto',
    'description' => 'A 3D Delta PLC, HMI and VFD trainer: wire the devices, write ladder, design HMI screens and run Modbus in your browser. By RAPTI.',

    // URL of this folder. Leave it '' when index.php is opened from this folder (https://your-site/plc/).
    // When the page is included from somewhere else, write the folder's URL with a / at the end, e.g. '/plc/'.
    'base' => '',

    // added to every css / js URL (?v=…) so visitors get the new files after an update
    'version' => '2.25.0',

    // style sheets, in this order
    'css' => array('css/plc.css', 'css/style.css'),
);
