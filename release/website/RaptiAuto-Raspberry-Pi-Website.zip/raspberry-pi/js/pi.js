(()=>{var yb=Object.create;var gc=Object.defineProperty;var bb=Object.getOwnPropertyDescriptor;var vb=Object.getOwnPropertyNames;var Ob=Object.getPrototypeOf,wb=Object.prototype.hasOwnProperty;var kb=(n=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(n,{get:(e,t)=>(typeof require<"u"?require:e)[t]}):n)(function(n){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+n+'" is not supported')});var Ie=(n,e)=>()=>(e||n((e={exports:{}}).exports,e),e.exports);var xb=(n,e,t,i)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of vb(e))!wb.call(n,s)&&s!==t&&gc(n,s,{get:()=>e[s],enumerable:!(i=bb(e,s))||i.enumerable});return n};var se=(n,e,t)=>(t=n!=null?yb(Ob(n)):{},xb(e||!n||!n.__esModule?gc(t,"default",{value:n,enumerable:!0}):t,n));var ii=Ie((Y2,_c)=>{_c.exports=window.__raptiMods["src/ui/widgets.js"]});var Qi=Ie((K2,yc)=>{yc.exports=window.__raptiMods["src/ui/icons.js"]});var ml=Ie((Z2,bc)=>{bc.exports=window.__raptiMods["src/native.js"]});var Oc=Ie((eT,vc)=>{vc.exports=window.__raptiMods["src/ui/audio.js"]});var ir=Ie((tT,wc)=>{wc.exports=window.__raptiMods["src/pi/gpio.js"]});var Pc=Ie((lT,Tc)=>{Tc.exports=window.__raptiMods["src/site.js"]});var $i=Ie((dT,Ac)=>{Ac.exports=window.__raptiMods["src/pi/boards.js"]});var rr=Ie((uT,Rc)=>{Rc.exports=window.__raptiMods["src/pi/examples.js"]});var Dc=Ie((mT,Nc)=>{Nc.exports=window.__raptiMods["src/net/network.js"]});var w0=Ie((GE,O0)=>{O0.exports=window.__raptiMods["src/ui/browser.js"]});var P0=Ie((KE,T0)=>{T0.exports=window.__raptiMods["src/pi/circuit-parts.js"]});var E0=Ie((ZE,C0)=>{C0.exports=window.__raptiMods["src/ui/editor.js"]});var R0=Ie((eA,A0)=>{A0.exports=window.__raptiMods["src/ui/canvas.js"]});var N0=Ie((tA,M0)=>{M0.exports=window.__raptiMods["src/ui/library.js"]});var I0=Ie((iA,D0)=>{D0.exports=window.__raptiMods["src/components/registry.js"]});var Q0=Ie((sA,L0)=>{L0.exports=window.__raptiMods["src/sim/engine.js"]});var z0=Ie((oA,W0)=>{W0.exports=window.__raptiMods["src/pi/autowire.js"]});var V0=Ie((lA,j0)=>{j0.exports=window.__raptiMods["src/ui/fsdock.js"]});var Q=se(ii(),1),Fe=se(Qi(),1),Ri=se(ml(),1),U0=se(Oc(),1);var Qc=se(ir(),1);var gl={};async function Sb(n={}){var uc,pc,mc;var e=n,t=!!globalThis.window,i=!!globalThis.WorkerGlobalScope,s=((pc=(uc=globalThis.process)==null?void 0:uc.versions)==null?void 0:pc.node)&&((mc=globalThis.process)==null?void 0:mc.type)!="renderer";if(s){let{createRequire:h}=await import("node:module");var r=h(gl.url)}var o=[],l="./this.program",a=(h,d)=>{throw d},f=gl.url,c="";function u(h){return e.locateFile?e.locateFile(h,c):c+h}var p,y;if(s){var v=r("node:fs");f.startsWith("file:")&&(c=r("node:path").dirname(r("node:url").fileURLToPath(f))+"/"),y=h=>{h=I(h)?new URL(h):h;var d=v.readFileSync(h);return d},p=async(h,d=!0)=>{h=I(h)?new URL(h):h;var m=v.readFileSync(h,d?void 0:"utf8");return m},process.argv.length>1&&(l=process.argv[1].replace(/\\/g,"/")),o=process.argv.slice(2),a=(h,d)=>{throw process.exitCode=h,d}}else if(t||i){try{c=new URL(".",f).href}catch{}i&&(y=h=>{var d=new XMLHttpRequest;return d.open("GET",h,!1),d.responseType="arraybuffer",d.send(null),new Uint8Array(d.response)}),p=async h=>{var d=await fetch(h,{credentials:"same-origin"});if(d.ok)return d.arrayBuffer();throw new Error(d.status+" : "+d.url)}}var b=console.log.bind(console),O=console.error.bind(console),k,T=!1,P,I=h=>h.startsWith("file://");class E{}class R extends E{}var N=!1;function B(){return tr.buffer}function J(){var d;if(!((d=ve==null?void 0:ve.buffer)!=null&&d.resizable)){var h=B();ve=new Int8Array(h),gi=new Int16Array(h),e.HEAPU8=ps=new Uint8Array(h),Mt=new Int32Array(h),me=new Uint32Array(h),hl=new Float32Array(h),cl=new Float64Array(h),He=new BigInt64Array(h)}}function fe(){var h=e.preRun;h&&(typeof h=="function"&&(h=[h]),Ni.push(...h)),Ht(Ni)}function Z(){N=!0,!e.noFSInit&&!_.initialized&&_.init(),mi.init(),Li.__wasm_call_ctors(),_.ignorePermissions=!1}function U(){var h=e.postRun;h&&(typeof h=="function"&&(h=[h]),ei.push(...h)),Ht(ei)}function ee(h){var m;(m=e.onAbort)==null||m.call(e,h),h=`Aborted(${h})`,O(h),T=!0,h+=". Build with -sASSERTIONS for more info.";var d=new WebAssembly.RuntimeError(h);throw d}var le;function ye(){return e.locateFile?u("micropython.wasm"):new URL("micropython.wasm",gl.url).href}function We(h){if(y)return y(h);throw"both async and sync fetching of the wasm failed"}async function Ye(h){if(!k)try{var d=await p(h);return new Uint8Array(d)}catch{}return We(h)}async function gt(h,d){try{var m=await Ye(h),g=await WebAssembly.instantiate(m,d);return g}catch(w){O(`failed to asynchronously prepare wasm: ${w}`),ee(w)}}async function Ne(h,d,m){if(!h&&!s)try{var g=fetch(d,{credentials:"same-origin"}),w=await WebAssembly.instantiateStreaming(g,m);return w}catch(x){O(`wasm streaming compile failed: ${x}`),O("falling back to ArrayBuffer instantiation")}return gt(d,m)}function rt(){var h={env:dc,wasi_snapshot_preview1:dc};return h}async function Rt(){function h(S){return Li=S.exports,Li=j.instrumentWasmExports(Li),rb(Li),J(),Li}function d(S){return h(S.instance)}var m=rt(),g=e.instantiateWasm;if(g)return new Promise(S=>{g(m,C=>S(h(C)))});le??(le=ye());var w=await Ne(k,le,m),x=d(w);return x}class Ke{name="ExitStatus";constructor(d){this.message=`Program terminated with exit(${d})`,this.status=d}}var ve,Ht=h=>{for(;h.length>0;)h.shift()(e)},ei=[],Ni=[],De={},G2=(h,d,m)=>{h=h.replace(/p/g,"i");var g=De[h];return g(d,...m)},Ch=!0,_t=h=>Jh(h),yt=()=>Xh(),de={isAbs:h=>h.charAt(0)==="/",splitPath:h=>{var d=/^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;return d.exec(h).slice(1)},normalizeArray:(h,d)=>{for(var m=0,g=h.length-1;g>=0;g--){var w=h[g];w==="."?h.splice(g,1):w===".."?(h.splice(g,1),m++):m&&(h.splice(g,1),m--)}if(d)for(;m;m--)h.unshift("..");return h},normalize:h=>{var d=de.isAbs(h),m=h.slice(-1)==="/";return h=de.normalizeArray(h.split("/").filter(g=>!!g),!d).join("/"),!h&&!d&&(h="."),h&&m&&(h+="/"),(d?"/":"")+h},dirname:h=>{var d=de.splitPath(h),m=d[0],g=d[1];return!m&&!g?".":(g&&(g=g.slice(0,-1)),m+g)},basename:h=>h&&h.match(/([^\/]+|\/)\/*$/)[1],join:(...h)=>de.normalize(h.join("/")),join2:(h,d)=>de.normalize(h+"/"+d)},J0=()=>{if(s){var h=r("node:crypto");return d=>(h.randomFillSync(d),0)}return d=>(crypto.getRandomValues(d),0)},Eh=h=>(Eh=J0())(h),Di={resolve:(...h)=>{for(var d="",m=!1,g=h.length-1;g>=-1&&!m;g--){var w=g>=0?h[g]:_.cwd();if(typeof w!="string")throw new TypeError("Arguments to path.resolve must be strings");if(!w)return"";d=w+"/"+d,m=de.isAbs(w)}return d=de.normalizeArray(d.split("/").filter(x=>!!x),!m).join("/"),(m?"/":"")+d||"."},relative:(h,d)=>{h=Di.resolve(h).slice(1),d=Di.resolve(d).slice(1);function m(q){for(var Y=0;Y<q.length&&q[Y]==="";Y++);for(var te=q.length-1;te>=0&&q[te]==="";te--);return Y>te?[]:q.slice(Y,te-Y+1)}for(var g=m(h.split("/")),w=m(d.split("/")),x=Math.min(g.length,w.length),S=x,C=0;C<x;C++)if(g[C]!==w[C]){S=C;break}for(var D=[],C=S;C<g.length;C++)D.push("..");return D=D.concat(w.slice(S)),D.join("/")}},Ah=globalThis.TextDecoder&&new TextDecoder,Y0=(h,d,m,g)=>{var w=d+m;if(g)return w;for(;h[d]&&!(d>=w);)++d;return d},us=(h,d=0,m,g)=>{var w=Y0(h,d,m,g);if(w-d>16&&h.buffer&&Ah)return Ah.decode(h.subarray(d,w));for(var x="";d<w;){var S=h[d++];if(!(S&128)){x+=String.fromCharCode(S);continue}var C=h[d++]&63;if((S&224)==192){x+=String.fromCharCode((S&31)<<6|C);continue}var D=h[d++]&63;if((S&240)==224?S=(S&15)<<12|C<<6|D:S=(S&7)<<18|C<<12|D<<6|h[d++]&63,S<65536)x+=String.fromCharCode(S);else{var q=S-65536;x+=String.fromCharCode(55296|q>>10,56320|q&1023)}}return x},rl=[],Zs=h=>{for(var d=0,m=0;m<h.length;++m){var g=h.charCodeAt(m);g<=127?d++:g<=2047?d+=2:g>=55296&&g<=57343?(d+=4,++m):d+=3}return d},Rh=(h,d,m,g)=>{if(!(g>0))return 0;for(var w=m,x=m+g-1,S=0;S<h.length;++S){var C=h.codePointAt(S);if(C<=127){if(m>=x)break;d[m++]=C}else if(C<=2047){if(m+1>=x)break;d[m++]=192|C>>6,d[m++]=128|C&63}else if(C<=65535){if(m+2>=x)break;d[m++]=224|C>>12,d[m++]=128|C>>6&63,d[m++]=128|C&63}else{if(m+3>=x)break;d[m++]=240|C>>18,d[m++]=128|C>>12&63,d[m++]=128|C>>6&63,d[m++]=128|C&63,S++}}return d[m]=0,m-w},ol=(h,d,m)=>{var g=m>0?m:Zs(h)+1,w=new Array(g),x=Rh(h,w,0,w.length);return d&&(w.length=x),w},K0=()=>{var w;if(!rl.length){var h=null;if(s){var d=256,m=Buffer.alloc(d),g=0;try{g=v.readSync(process.stdin.fd,m,0,d)}catch(x){if(x.toString().includes("EOF"))g=0;else throw x}g>0&&(h=m.toString("utf-8",0,g))}else(w=globalThis.window)!=null&&w.prompt&&(h=window.prompt("Input: "),h!==null&&(h+=`
`));if(!h)return null;rl=ol(h,!0)}return rl.shift()},mi={ttys:[],init(){},shutdown(){},register(h,d){mi.ttys[h]={input:[],output:[],ops:d},_.registerDevice(h,mi.stream_ops)},stream_ops:{open(h){var d=mi.ttys[h.node.rdev];if(!d)throw new _.ErrnoError(43);h.tty=d,h.seekable=!1},close(h){h.tty.ops.fsync(h.tty)},fsync(h){h.tty.ops.fsync(h.tty)},read(h,d,m,g,w){if(!h.tty||!h.tty.ops.get_char)throw new _.ErrnoError(60);for(var x=0,S=0;S<g;S++){var C;try{C=h.tty.ops.get_char(h.tty)}catch{throw new _.ErrnoError(29)}if(C===void 0&&!x)throw new _.ErrnoError(6);if(C==null||(x++,d[m+S]=C,C===10))break}return x&&(h.node.atime=Date.now()),x},write(h,d,m,g,w){if(!h.tty||!h.tty.ops.put_char)throw new _.ErrnoError(60);try{for(var x=0;x<g;x++)h.tty.ops.put_char(h.tty,d[m+x])}catch{throw new _.ErrnoError(29)}return g&&(h.node.mtime=h.node.ctime=Date.now()),x}},default_tty_ops:{get_char(h){return K0()},put_char(h,d){d===null||d===10?(b(us(h.output)),h.output=[]):d!=0&&h.output.push(d)},fsync(h){var d;((d=h.output)==null?void 0:d.length)>0&&(b(us(h.output)),h.output=[])},ioctl_tcgets(h){return{c_iflag:25856,c_oflag:5,c_cflag:191,c_lflag:35387,c_cc:[3,28,127,21,4,0,1,0,17,19,26,0,18,15,23,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}},ioctl_tcsets(h,d,m){return 0},ioctl_tiocgwinsz(h){return[24,80]}},default_tty1_ops:{put_char(h,d){d===null||d===10?(O(us(h.output)),h.output=[]):d!=0&&h.output.push(d)},fsync(h){var d;((d=h.output)==null?void 0:d.length)>0&&(O(us(h.output)),h.output=[])}}},Mh=h=>{ee()},G={ops_table:null,mount(h){return G.createNode(null,"/",16895,0)},createNode(h,d,m,g){if(_.isBlkdev(m)||_.isFIFO(m))throw new _.ErrnoError(63);G.ops_table||(G.ops_table={dir:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr,lookup:G.node_ops.lookup,mknod:G.node_ops.mknod,rename:G.node_ops.rename,unlink:G.node_ops.unlink,rmdir:G.node_ops.rmdir,readdir:G.node_ops.readdir,symlink:G.node_ops.symlink},stream:{llseek:G.stream_ops.llseek}},file:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr},stream:{llseek:G.stream_ops.llseek,read:G.stream_ops.read,write:G.stream_ops.write,mmap:G.stream_ops.mmap,msync:G.stream_ops.msync}},link:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr,readlink:G.node_ops.readlink},stream:{}},chrdev:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr},stream:_.chrdev_stream_ops}});var w=_.createNode(h,d,m,g);return _.isDir(w.mode)?(w.node_ops=G.ops_table.dir.node,w.stream_ops=G.ops_table.dir.stream,w.contents={}):_.isFile(w.mode)?(w.node_ops=G.ops_table.file.node,w.stream_ops=G.ops_table.file.stream,w.usedBytes=0,w.contents=G.emptyFileContents??(G.emptyFileContents=new Uint8Array(0))):_.isLink(w.mode)?(w.node_ops=G.ops_table.link.node,w.stream_ops=G.ops_table.link.stream):_.isChrdev(w.mode)&&(w.node_ops=G.ops_table.chrdev.node,w.stream_ops=G.ops_table.chrdev.stream),w.atime=w.mtime=w.ctime=Date.now(),h&&(h.contents[d]=w,h.atime=h.mtime=h.ctime=w.atime),w},getFileDataAsTypedArray(h){return h.contents.subarray(0,h.usedBytes)},expandFileStorage(h,d){var m=h.contents.length;if(!(m>=d)){var g=1024*1024;d=Math.max(d,m*(m<g?2:1.125)>>>0),m&&(d=Math.max(d,256));var w=G.getFileDataAsTypedArray(h);h.contents=new Uint8Array(d),h.contents.set(w)}},resizeFileStorage(h,d){if(h.usedBytes!=d){var m=h.contents;h.contents=new Uint8Array(d),h.contents.set(m.subarray(0,Math.min(d,h.usedBytes))),h.usedBytes=d}},node_ops:{getattr(h){var d={};return d.dev=_.isChrdev(h.mode)?h.id:1,d.ino=h.id,d.mode=h.mode,d.nlink=1,d.uid=0,d.gid=0,d.rdev=h.rdev,_.isDir(h.mode)?d.size=4096:_.isFile(h.mode)?d.size=h.usedBytes:_.isLink(h.mode)?d.size=h.link.length:d.size=0,d.atime=new Date(h.atime),d.mtime=new Date(h.mtime),d.ctime=new Date(h.ctime),d.atimeMs=h.atime,d.mtimeMs=h.mtime,d.ctimeMs=h.ctime,d.blksize=4096,d.blocks=Math.ceil(d.size/d.blksize),d},setattr(h,d){for(let m of["mode","atime","mtime","ctime"])d[m]!=null&&(h[m]=d[m]);d.size!==void 0&&G.resizeFileStorage(h,d.size)},lookup(h,d){throw G.doesNotExistError||(G.doesNotExistError=new _.ErrnoError(44),G.doesNotExistError.stack="<generic error, no stack>"),G.doesNotExistError},mknod(h,d,m,g){return G.createNode(h,d,m,g)},rename(h,d,m){var g;try{g=_.lookupNode(d,m)}catch{}if(g&&_.isDir(h.mode))for(var w in g.contents)throw new _.ErrnoError(55);delete h.parent.contents[h.name],d.contents[m]=h,h.name=m,d.ctime=d.mtime=h.parent.ctime=h.parent.mtime=Date.now()},unlink(h,d){delete h.contents[d],h.ctime=h.mtime=Date.now()},rmdir(h,d){var m=_.lookupNode(h,d);for(var g in m.contents)throw new _.ErrnoError(55);delete h.contents[d],h.ctime=h.mtime=Date.now()},readdir(h){return[".","..",...Object.keys(h.contents)]},symlink(h,d,m){var g=G.createNode(h,d,41471,0);return g.link=m,g},readlink(h){if(!_.isLink(h.mode))throw new _.ErrnoError(28);return h.link}},stream_ops:{read(h,d,m,g,w){var x=h.node.contents;if(w>=h.node.usedBytes)return 0;var S=Math.min(h.node.usedBytes-w,g);return d.set(x.subarray(w,w+S),m),S},write(h,d,m,g,w,x){if(d.buffer===ve.buffer&&(x=!1),!g)return 0;var S=h.node;return S.mtime=S.ctime=Date.now(),x?(S.contents=d.subarray(m,m+g),S.usedBytes=g):!S.usedBytes&&!w?(S.contents=d.slice(m,m+g),S.usedBytes=g):(G.expandFileStorage(S,w+g),S.contents.set(d.subarray(m,m+g),w),S.usedBytes=Math.max(S.usedBytes,w+g)),g},llseek(h,d,m){var g=d;if(m===1?g+=h.position:m===2&&_.isFile(h.node.mode)&&(g+=h.node.usedBytes),g<0)throw new _.ErrnoError(28);return g},mmap(h,d,m,g,w){if(!_.isFile(h.node.mode))throw new _.ErrnoError(43);var x,S,C=h.node.contents;if(!(w&2)&&C.buffer===ve.buffer)S=!1,x=C.byteOffset;else{if(S=!0,x=Mh(d),!x)throw new _.ErrnoError(48);C&&((m>0||m+d<C.length)&&(C.subarray?C=C.subarray(m,m+d):C=Array.prototype.slice.call(C,m,m+d)),ve.set(C,x))}return{ptr:x,allocated:S}},msync(h,d,m,g,w){return G.stream_ops.write(h,d,0,g,m,!1),0}}},Z0=h=>{if(typeof h!="string")return h;var d={r:0,"r+":2,w:577,"w+":578,a:1089,"a+":1090},m=d[h];if(typeof m>"u")throw new Error(`Unknown file open mode: ${h}`);return m},Nh=h=>(typeof h=="string"&&(h=ol(h,!0)),h.subarray||(h=new Uint8Array(h)),h),ll=(h,d)=>{var m=0;return h&&(m|=365),d&&(m|=146),m},e_=async h=>{var d=await p(h);return new Uint8Array(d)},t_=(...h)=>_.createDataFile(...h),i_=h=>h,Dh=null,s_=async()=>Dh,Ii=0,Ih=null,n_=h=>{var d;Ii--,(d=e.monitorRunDependencies)==null||d.call(e,Ii),Ii||Ih()},r_=h=>{var d;Ii||(Dh=new Promise(m=>Ih=m)),Ii++,(d=e.monitorRunDependencies)==null||d.call(e,Ii)},o_=[],l_=async(h,d)=>{typeof Browser<"u"&&Browser.init();for(var m of o_)if(m.canHandle(d))return m.handle(h,d);return h},Lh=async(h,d,m,g,w,x,S,C)=>{var D=d?Di.resolve(de.join2(h,d)):h,q=i_(`cp ${D}`);r_(q);try{var Y=m;typeof m=="string"&&(Y=await e_(m)),Y=await l_(Y,D),C==null||C(),x||t_(h,d,Y,g,w,S)}finally{n_(q)}},a_=(h,d,m,g,w,x,S,C,D,q)=>{Lh(h,d,m,g,w,C,D,q).then(x).catch(S)},_={root:null,mounts:[],devices:{},streams:[],nextInode:1,nameTable:[],currentPath:"/",initialized:!1,ignorePermissions:!0,filesystems:null,syncFSRequests:0,ErrnoError:class{name="ErrnoError";constructor(h){this.errno=h}},FSStream:class{shared={};get object(){return this.node}set object(h){this.node=h}get isRead(){return(this.flags&2097155)!==1}get isWrite(){return(this.flags&2097155)!==0}get isAppend(){return this.flags&1024}get flags(){return this.shared.flags}set flags(h){this.shared.flags=h}get position(){return this.shared.position}set position(h){this.shared.position=h}},FSNode:class{node_ops={};stream_ops={};readMode=365;writeMode=146;mounted=null;constructor(h,d,m,g){h||(h=this),this.parent=h,this.mount=h.mount,this.id=_.nextInode++,this.name=d,this.mode=m,this.rdev=g,this.atime=this.mtime=this.ctime=Date.now()}get read(){return(this.mode&this.readMode)===this.readMode}set read(h){h?this.mode|=this.readMode:this.mode&=~this.readMode}get write(){return(this.mode&this.writeMode)===this.writeMode}set write(h){h?this.mode|=this.writeMode:this.mode&=~this.writeMode}get isFolder(){return _.isDir(this.mode)}get isDevice(){return _.isChrdev(this.mode)}addListener(h,d=!1){var m={cb:h,exclusive:d},g=this.listeners??(this.listeners=new Set);return g.add(m),{listeners:g,entry:m}}notifyListeners(h){if(this.listeners){var d;for(var m of this.listeners)m.exclusive?(d||(d=[])).push(m):m.cb(h);if(d){var g=(this.exclTurn||0)%d.length;this.exclTurn=g+1,d[g].cb(h)}}}},lookupPath(h,d={}){if(!h)throw new _.ErrnoError(44);d.follow_mount??(d.follow_mount=!0),de.isAbs(h)||(h=_.cwd()+"/"+h);e:for(var m=0;m<40;m++){for(var g=h.split("/").filter(q=>!!q),w=_.root,x="/",S=0;S<g.length;S++){var C=S===g.length-1;if(C&&d.parent)break;if(g[S]!=="."){if(g[S]===".."){if(x=de.dirname(x),_.isRoot(w)){h=x+"/"+g.slice(S+1).join("/"),m--;continue e}else w=w.parent;continue}x=de.join2(x,g[S]);try{w=_.lookupNode(w,g[S])}catch(q){if((q==null?void 0:q.errno)===44&&C&&d.noent_okay)return{path:x};throw q}if(_.isMountpoint(w)&&(!C||d.follow_mount)&&(w=w.mounted.root),_.isLink(w.mode)&&(!C||d.follow)){if(!w.node_ops.readlink)throw new _.ErrnoError(52);var D=w.node_ops.readlink(w);de.isAbs(D)||(D=de.dirname(x)+"/"+D),h=D+"/"+g.slice(S+1).join("/");continue e}}}return{path:x,node:w}}throw new _.ErrnoError(32)},getPath(h){for(var d;;){if(_.isRoot(h)){var m=h.mount.mountpoint;return d?m[m.length-1]!=="/"?`${m}/${d}`:m+d:m}d=d?`${h.name}/${d}`:h.name,h=h.parent}},hashName(h,d){for(var m=0,g=0;g<d.length;g++)m=(m<<5)-m+d.charCodeAt(g)|0;return(h+m>>>0)%_.nameTable.length},hashAddNode(h){var d=_.hashName(h.parent.id,h.name);h.name_next=_.nameTable[d],_.nameTable[d]=h},hashRemoveNode(h){var d=_.hashName(h.parent.id,h.name);if(_.nameTable[d]===h)_.nameTable[d]=h.name_next;else for(var m=_.nameTable[d];m;){if(m.name_next===h){m.name_next=h.name_next;break}m=m.name_next}},lookupNode(h,d){var m=_.mayLookup(h);if(m)throw new _.ErrnoError(m);for(var g=_.hashName(h.id,d),w=_.nameTable[g];w;w=w.name_next){var x=w.name;if(w.parent.id===h.id&&x===d)return w}return _.lookup(h,d)},createNode(h,d,m,g){var w=new _.FSNode(h,d,m,g);return _.hashAddNode(w),w},destroyNode(h){_.hashRemoveNode(h)},isRoot(h){return h===h.parent},isMountpoint(h){return!!h.mounted},isFile(h){return(h&61440)===32768},isDir(h){return(h&61440)===16384},isLink(h){return(h&61440)===40960},isChrdev(h){return(h&61440)===8192},isBlkdev(h){return(h&61440)===24576},isFIFO(h){return(h&61440)===4096},isSocket(h){return(h&49152)===49152},flagsToPermissionString(h){var d=["r","w","rw"][h&3];return h&512&&(d+="w"),d},nodePermissions(h,d){return _.ignorePermissions?0:d.includes("r")&&!(h.mode&292)||d.includes("w")&&!(h.mode&146)||d.includes("x")&&!(h.mode&73)?2:0},mayLookup(h){if(!_.isDir(h.mode))return 54;var d=_.nodePermissions(h,"x");return d||(h.node_ops.lookup?0:2)},mayCreate(h,d){if(!_.isDir(h.mode))return 54;try{var m=_.lookupNode(h,d);return 20}catch{}return _.nodePermissions(h,"wx")},mayDelete(h,d,m){var g;try{g=_.lookupNode(h,d)}catch(x){return x.errno}var w=_.nodePermissions(h,"wx");if(w)return w;if(m){if(!_.isDir(g.mode))return 54;if(_.isRoot(g)||_.getPath(g)===_.cwd())return 10}else if(_.isDir(g.mode))return 31;return 0},mayOpen(h,d){if(!h)return 44;if(_.isLink(h.mode))return 32;var m=_.flagsToPermissionString(d);return _.isDir(h.mode)&&(m!=="r"||d&576)?31:_.nodePermissions(h,m)},checkOpExists(h,d){if(!h)throw new _.ErrnoError(d);return h},MAX_OPEN_FDS:4096,nextfd(){for(var h=0;h<=_.MAX_OPEN_FDS;h++)if(!_.streams[h])return h;throw new _.ErrnoError(33)},getStreamChecked(h){var d=_.getStream(h);if(!d)throw new _.ErrnoError(8);return d},getStream:h=>_.streams[h],createStream(h,d=-1){return h=Object.assign(new _.FSStream,h),d==-1&&(d=_.nextfd()),h.fd=d,_.streams[d]=h,h},closeStream(h){_.streams[h]=null},dupStream(h,d=-1){var g,w;var m=_.createStream(h,d);return(w=(g=m.stream_ops)==null?void 0:g.dup)==null||w.call(g,m),m},doSetAttr(h,d,m){var g=h==null?void 0:h.stream_ops.setattr,w=g?h:d;g??(g=d.node_ops.setattr),_.checkOpExists(g,63);try{g(w,m)}catch(x){throw x instanceof RangeError?new _.ErrnoError(22):x}},chrdev_stream_ops:{open(h){var m,g;var d=_.getDevice(h.node.rdev);h.stream_ops=d.stream_ops,(g=(m=h.stream_ops).open)==null||g.call(m,h)},llseek(){throw new _.ErrnoError(70)}},major:h=>h>>8,minor:h=>h&255,makedev:(h,d)=>h<<8|d,registerDevice(h,d){_.devices[h]={stream_ops:d}},getDevice:h=>_.devices[h],getMounts(h){for(var d=[],m=[h];m.length;){var g=m.pop();d.push(g),m.push(...g.mounts)}return d},syncfs(h,d){typeof h=="function"&&(d=h,h=!1),_.syncFSRequests++,_.syncFSRequests>1&&O(`warning: ${_.syncFSRequests} FS.syncfs operations in flight at once, probably just doing extra work`);var m=_.getMounts(_.root.mount),g=0;function w(C){return _.syncFSRequests--,d(C)}function x(C){if(C)return x.errored?void 0:(x.errored=!0,w(C));++g>=m.length&&w(null)}for(var S of m)S.type.syncfs?S.type.syncfs(S,h,x):x(null)},mount(h,d,m){var g=m==="/",w=!m,x;if(g&&_.root)throw new _.ErrnoError(10);if(!g&&!w){var S=_.lookupPath(m,{follow_mount:!1});if(m=S.path,x=S.node,_.isMountpoint(x))throw new _.ErrnoError(10);if(!_.isDir(x.mode))throw new _.ErrnoError(54)}var C={type:h,opts:d,mountpoint:m,mounts:[]},D=h.mount(C);return D.mount=C,C.root=D,g?_.root=D:x&&(x.mounted=C,x.mount&&x.mount.mounts.push(C)),D},unmount(h){var d=_.lookupPath(h,{follow_mount:!1});if(!_.isMountpoint(d.node))throw new _.ErrnoError(28);var m=d.node,g=m.mounted,w=_.getMounts(g);for(var[x,S]of Object.entries(_.nameTable))for(;S;){var C=S.name_next;w.includes(S.mount)&&_.destroyNode(S),S=C}m.mounted=null;var D=m.mount.mounts.indexOf(g);m.mount.mounts.splice(D,1)},lookup(h,d){return h.node_ops.lookup(h,d)},mknod(h,d,m){var g=_.lookupPath(h,{parent:!0}),w=g.node,x=de.basename(h);if(!x)throw new _.ErrnoError(28);if(x==="."||x==="..")throw new _.ErrnoError(20);var S=_.mayCreate(w,x);if(S)throw new _.ErrnoError(S);if(!w.node_ops.mknod)throw new _.ErrnoError(63);return w.node_ops.mknod(w,x,d,m)},statfs(h){return _.statfsNode(_.lookupPath(h,{follow:!0}).node)},statfsStream(h){return _.statfsNode(h.node)},statfsNode(h){var d={bsize:4096,frsize:4096,blocks:1e6,bfree:5e5,bavail:5e5,files:_.nextInode,ffree:_.nextInode-1,fsid:42,flags:2,namelen:255};return h.node_ops.statfs&&Object.assign(d,h.node_ops.statfs(h.mount.opts.root)),d},create(h,d=438){return d&=4095,d|=32768,_.mknod(h,d,0)},mkdir(h,d=511){return d&=1023,d|=16384,_.mknod(h,d,0)},mkdirTree(h,d=511){var m=h.split("/"),g="";for(var w of m)if(w){(g||de.isAbs(h))&&(g+="/"),g+=w;try{_.mkdir(g,d)}catch(x){if(x.errno!=20)throw x}}},mkdev(h,d,m){return typeof m>"u"&&(m=d,d=438),d|=8192,_.mknod(h,d,m)},symlink(h,d){if(!Di.resolve(h))throw new _.ErrnoError(44);var m=_.lookupPath(d,{parent:!0}),g=m.node;if(!g)throw new _.ErrnoError(44);var w=de.basename(d),x=_.mayCreate(g,w);if(x)throw new _.ErrnoError(x);if(!g.node_ops.symlink)throw new _.ErrnoError(63);return g.node_ops.symlink(g,w,h)},link(h,d,m){var g=_.lookupPath(d,{parent:!0}),w=g.node;if(!w)throw new _.ErrnoError(44);var x=de.basename(d),S=_.mayCreate(w,x);if(S)throw new _.ErrnoError(S);if(!w.node_ops.link)throw new _.ErrnoError(34);return w.node_ops.link(w,x,h,m)},rename(h,d){var m=de.dirname(h),g=de.dirname(d),w=de.basename(h),x=de.basename(d),S,C,D;if(S=_.lookupPath(h,{parent:!0}),C=S.node,S=_.lookupPath(d,{parent:!0}),D=S.node,!C||!D)throw new _.ErrnoError(44);if(C.mount!==D.mount)throw new _.ErrnoError(75);var q=_.lookupNode(C,w),Y=Di.relative(h,g);if(Y.charAt(0)!==".")throw new _.ErrnoError(28);if(Y=Di.relative(d,m),Y.charAt(0)!==".")throw new _.ErrnoError(55);var te;try{te=_.lookupNode(D,x)}catch{}if(q!==te){var X=_.isDir(q.mode),H=_.mayDelete(C,w,X);if(H)throw new _.ErrnoError(H);if(H=te?_.mayDelete(D,x,X):_.mayCreate(D,x),H)throw new _.ErrnoError(H);if(!C.node_ops.rename)throw new _.ErrnoError(63);if(_.isMountpoint(q)||te&&_.isMountpoint(te))throw new _.ErrnoError(10);if(D!==C&&(H=_.nodePermissions(C,"w"),H))throw new _.ErrnoError(H);_.hashRemoveNode(q);try{C.node_ops.rename(q,D,x),te&&_.hashRemoveNode(te),q.parent=D}catch(re){throw re}finally{_.hashAddNode(q)}}},rmdir(h){var d=_.lookupPath(h,{parent:!0}),m=d.node,g=de.basename(h),w=_.lookupNode(m,g),x=_.mayDelete(m,g,!0);if(x)throw new _.ErrnoError(x);if(!m.node_ops.rmdir)throw new _.ErrnoError(63);if(_.isMountpoint(w))throw new _.ErrnoError(10);m.node_ops.rmdir(m,g),_.destroyNode(w)},readdir(h){var d=_.lookupPath(h,{follow:!0}),m=d.node,g=_.checkOpExists(m.node_ops.readdir,54);return g(m)},unlink(h){var d=_.lookupPath(h,{parent:!0}),m=d.node;if(!m)throw new _.ErrnoError(44);var g=de.basename(h),w=_.lookupNode(m,g),x=_.mayDelete(m,g,!1);if(x)throw new _.ErrnoError(x);if(!m.node_ops.unlink)throw new _.ErrnoError(63);if(_.isMountpoint(w))throw new _.ErrnoError(10);m.node_ops.unlink(m,g),_.destroyNode(w)},readlink(h){var d=_.lookupPath(h),m=d.node;if(!m)throw new _.ErrnoError(44);if(!m.node_ops.readlink)throw new _.ErrnoError(28);return m.node_ops.readlink(m)},stat(h,d=!1){var m=_.lookupPath(h,{follow:!d}),g=m.node,w=_.checkOpExists(g.node_ops.getattr,63);return w(g)},fstat(h){var d=_.getStreamChecked(h),m=d.node,g=d.stream_ops.getattr,w=g?d:m;return g??(g=m.node_ops.getattr),_.checkOpExists(g,63),g(w)},lstat(h){return _.stat(h,!0)},doChmod(h,d,m,g=!1){_.doSetAttr(h,d,{mode:m&4095|d.mode&-4096,ctime:Date.now(),dontFollow:g})},chmod(h,d,m=!1){var g;if(typeof h=="string"){var w=_.lookupPath(h,{follow:!m});g=w.node}else g=h;_.doChmod(null,g,d,m)},lchmod(h,d){_.chmod(h,d,!0)},fchmod(h,d){var m=_.getStreamChecked(h);_.doChmod(m,m.node,d,!1)},doChown(h,d,m=!1){_.doSetAttr(h,d,{timestamp:Date.now(),dontFollow:m})},chown(h,d,m,g=!1){var w;if(typeof h=="string"){var x=_.lookupPath(h,{follow:!g});w=x.node}else w=h;_.doChown(null,w,g)},lchown(h,d,m){_.chown(h,d,m,!0)},fchown(h,d,m){var g=_.getStreamChecked(h);_.doChown(g,g.node,!1)},doTruncate(h,d,m){if(_.isDir(d.mode))throw new _.ErrnoError(31);if(!_.isFile(d.mode))throw new _.ErrnoError(28);var g=_.nodePermissions(d,"w");if(g)throw new _.ErrnoError(g);_.doSetAttr(h,d,{size:m,timestamp:Date.now()})},truncate(h,d){if(d<0)throw new _.ErrnoError(28);var m;if(typeof h=="string"){var g=_.lookupPath(h,{follow:!0});m=g.node}else m=h;_.doTruncate(null,m,d)},ftruncate(h,d){var m=_.getStreamChecked(h);if(d<0||!(m.flags&2097155))throw new _.ErrnoError(28);_.doTruncate(m,m.node,d)},utime(h,d,m,g=!1){var w=_.lookupPath(h,{follow:!g});_.doSetAttr(null,w.node,{atime:d,mtime:m,dontFollow:g})},open(h,d,m=438){if(h==="")throw new _.ErrnoError(44);d=Z0(d),d&64?m=m&4095|32768:m=0;var g,w;if(typeof h=="object")g=h;else{w=h.endsWith("/");var x=_.lookupPath(h,{follow:!(d&131072),noent_okay:!0});g=x.node,h=x.path}var S=!1;if(d&64)if(g){if(d&128)throw new _.ErrnoError(20)}else{if(w)throw new _.ErrnoError(31);g=_.mknod(h,m|511,0),S=!0}if(!g)throw new _.ErrnoError(44);if(_.isChrdev(g.mode)&&(d&=-513),d&65536&&!_.isDir(g.mode))throw new _.ErrnoError(54);if(!S){var C=_.mayOpen(g,d);if(C)throw new _.ErrnoError(C)}d&512&&!S&&_.truncate(g,0),d&=-131713;var D=_.createStream({node:g,path:_.getPath(g),flags:d,seekable:!0,position:0,stream_ops:g.stream_ops,ungotten:[],error:!1});return D.stream_ops.open&&D.stream_ops.open(D),S&&_.chmod(g,m&511),D},close(h){var d;if(_.isClosed(h))throw new _.ErrnoError(8);h.getdents&&(h.getdents=null),(d=h.node)==null||d.notifyListeners(32);try{h.stream_ops.close&&h.stream_ops.close(h)}catch(m){throw m}finally{_.closeStream(h.fd)}h.fd=null},isClosed(h){return h.fd===null},llseek(h,d,m){if(_.isClosed(h))throw new _.ErrnoError(8);if(!h.seekable||!h.stream_ops.llseek)throw new _.ErrnoError(70);if(m!=0&&m!=1&&m!=2)throw new _.ErrnoError(28);return h.position=h.stream_ops.llseek(h,d,m),h.ungotten=[],h.position},read(h,d,m,g,w){if(g<0||w<0)throw new _.ErrnoError(28);if(_.isClosed(h))throw new _.ErrnoError(8);if((h.flags&2097155)===1)throw new _.ErrnoError(8);if(_.isDir(h.node.mode))throw new _.ErrnoError(31);if(!h.stream_ops.read)throw new _.ErrnoError(28);var x=typeof w<"u";if(!x)w=h.position;else if(!h.seekable)throw new _.ErrnoError(70);var S=h.stream_ops.read(h,d,m,g,w);return x||(h.position+=S),S},write(h,d,m,g,w,x){if(g<0||w<0)throw new _.ErrnoError(28);if(_.isClosed(h))throw new _.ErrnoError(8);if(!(h.flags&2097155))throw new _.ErrnoError(8);if(_.isDir(h.node.mode))throw new _.ErrnoError(31);if(!h.stream_ops.write)throw new _.ErrnoError(28);h.seekable&&h.flags&1024&&_.llseek(h,0,2);var S=typeof w<"u";if(!S)w=h.position;else if(!h.seekable)throw new _.ErrnoError(70);var C=h.stream_ops.write(h,d,m,g,w,x);return S||(h.position+=C),C},mmap(h,d,m,g,w){if(g&2&&!(w&2)&&(h.flags&2097155)!==2)throw new _.ErrnoError(2);if((h.flags&2097155)===1)throw new _.ErrnoError(2);if(!h.stream_ops.mmap)throw new _.ErrnoError(43);if(!d)throw new _.ErrnoError(28);return h.stream_ops.mmap(h,d,m,g,w)},msync(h,d,m,g,w){return h.stream_ops.msync?h.stream_ops.msync(h,d,m,g,w):0},ioctl(h,d,m){if(!h.stream_ops.ioctl)throw new _.ErrnoError(59);return h.stream_ops.ioctl(h,d,m)},readFile(h,d={}){d.flags??(d.flags=0),d.encoding??(d.encoding="binary"),d.encoding!=="utf8"&&d.encoding!=="binary"&&ee(`Invalid encoding type "${d.encoding}"`);var m=_.open(h,d.flags),g=_.stat(h),w=g.size,x=new Uint8Array(w);return _.read(m,x,0,w,0),d.encoding==="utf8"&&(x=us(x)),_.close(m),x},writeFile(h,d,m={}){m.flags??(m.flags=577);var g=_.open(h,m.flags,m.mode);d=Nh(d),_.write(g,d,0,d.byteLength,void 0,m.canOwn),_.close(g)},cwd:()=>_.currentPath,chdir(h){var d=_.lookupPath(h,{follow:!0});if(d.node===null)throw new _.ErrnoError(44);if(!_.isDir(d.node.mode))throw new _.ErrnoError(54);var m=_.nodePermissions(d.node,"x");if(m)throw new _.ErrnoError(m);_.currentPath=d.path},createDefaultDirectories(){_.mkdir("/tmp"),_.mkdir("/home"),_.mkdir("/home/web_user")},createDefaultDevices(){_.mkdir("/dev"),_.registerDevice(_.makedev(1,3),{read:()=>0,write:(g,w,x,S,C)=>S,llseek:()=>0}),_.mkdev("/dev/null",_.makedev(1,3)),mi.register(_.makedev(5,0),mi.default_tty_ops),mi.register(_.makedev(6,0),mi.default_tty1_ops),_.mkdev("/dev/tty",_.makedev(5,0)),_.mkdev("/dev/tty1",_.makedev(6,0));var h=new Uint8Array(1024),d=0,m=()=>(d||(Eh(h),d=h.byteLength),h[--d]);_.createDevice("/dev","random",m),_.createDevice("/dev","urandom",m),_.mkdir("/dev/shm"),_.mkdir("/dev/shm/tmp")},createSpecialDirectories(){_.mkdir("/proc");var h=_.mkdir("/proc/self");_.mkdir("/proc/self/fd"),_.mount({mount(){var d=_.createNode(h,"fd",16895,73);return d.stream_ops={llseek:G.stream_ops.llseek},d.node_ops={lookup(m,g){var w=+g,x=_.getStreamChecked(w),S={parent:null,mount:{mountpoint:"fake"},node_ops:{readlink:()=>x.path},id:w+1};return S.parent=S,S},readdir(){return Array.from(_.streams.entries()).filter(([m,g])=>g).map(([m,g])=>m.toString())}},d}},{},"/proc/self/fd")},createStandardStreams(h,d,m){h?_.createDevice("/dev","stdin",h):_.symlink("/dev/tty","/dev/stdin"),d?_.createDevice("/dev","stdout",null,d):_.symlink("/dev/tty","/dev/stdout"),m?_.createDevice("/dev","stderr",null,m):_.symlink("/dev/tty1","/dev/stderr");var g=_.open("/dev/stdin",0),w=_.open("/dev/stdout",1),x=_.open("/dev/stderr",1)},staticInit(){_.nameTable.length=4096,_.mount(G,{},"/"),_.createDefaultDirectories(),_.createDefaultDevices(),_.createSpecialDirectories(),_.filesystems={MEMFS:G}},init(h,d,m){_.initialized=!0,h??(h=e.stdin),d??(d=e.stdout),m??(m=e.stderr),_.createStandardStreams(h,d,m)},quit(){_.initialized=!1;for(var h of _.streams)h&&_.close(h)},analyzePath(h,d=!1){try{var m=_.lookupPath(h,{follow:!d});h=m.path}catch{}var g={isRoot:!1,exists:!1,error:0,name:null,path:null,object:null,parentExists:!1,parentPath:null,parentObject:null};try{var m=_.lookupPath(h,{parent:!0});g.parentExists=!0,g.parentPath=m.path,g.parentObject=m.node,g.name=de.basename(h),m=_.lookupPath(h,{follow:!d}),g.exists=!0,g.path=m.path,g.object=m.node,g.name=m.node.name,g.isRoot=m.path==="/"}catch(w){g.error=w.errno}return g},createPath(h,d,m,g){h=typeof h=="string"?h:_.getPath(h);for(var w=d.split("/").reverse();w.length;){var x=w.pop();if(x){var S=de.join2(h,x);try{_.mkdir(S)}catch(C){if(C.errno!=20)throw C}h=S}}return S},createFile(h,d,m,g,w){var x=de.join2(typeof h=="string"?h:_.getPath(h),d),S=ll(g,w);return _.create(x,S)},createDataFile(h,d,m,g,w,x){var S=d;h&&(h=typeof h=="string"?h:_.getPath(h),S=d?de.join2(h,d):h);var C=ll(g,w),D=_.create(S,C);if(m){m=Nh(m),_.chmod(D,C|146);var q=_.open(D,577);_.write(q,m,0,m.length,0,x),_.close(q),_.chmod(D,C)}},createDevice(h,d,m,g){var C;var w=de.join2(typeof h=="string"?h:_.getPath(h),d),x=ll(!!m,!!g);(C=_.createDevice).major??(C.major=64);var S=_.makedev(_.createDevice.major++,0);return _.registerDevice(S,{open(D){D.seekable=!1},close(D){var q;(q=g==null?void 0:g.buffer)!=null&&q.length&&g(10)},read(D,q,Y,te,X){for(var H=0,re=0;re<te;re++){var he;try{he=m()}catch{throw new _.ErrnoError(29)}if(he===void 0&&!H)throw new _.ErrnoError(6);if(he==null)break;H++,q[Y+re]=he}return H&&(D.node.atime=Date.now()),H},write(D,q,Y,te,X){for(var H=0;H<te;H++)try{g(q[Y+H])}catch{throw new _.ErrnoError(29)}return te&&(D.node.mtime=D.node.ctime=Date.now()),H}}),_.mkdev(w,x,S)},forceLoadFile(h){if(h.isDevice||h.isFolder||h.link||h.contents)return!0;if(globalThis.XMLHttpRequest)ee("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");else try{h.contents=y(h.url)}catch{throw new _.ErrnoError(29)}},createLazyFile(h,d,m,g,w){class x{lengthKnown=!1;chunks=[];get(X){if(!(X>this.length-1||X<0)){var H=X%this.chunkSize,re=X/this.chunkSize|0;return this.getter(re)[H]}}setDataGetter(X){this.getter=X}cacheLength(){var X=new XMLHttpRequest;X.open("HEAD",m,!1),X.send(null),X.status>=200&&X.status<300||X.status===304||ee(`Couldn't load ${m}. Status: ${X.status}`);var H=Number(X.getResponseHeader("Content-length")),re,he=(re=X.getResponseHeader("Accept-Ranges"))&&re==="bytes",ge=(re=X.getResponseHeader("Content-Encoding"))&&re==="gzip",ze=1024*1024;he||(ze=H);var Nt=(Ut,_s)=>{Ut>_s&&ee(`invalid range (${Ut}, ${_s}) or no bytes requested!`),_s>H-1&&ee(`only ${H} bytes available! programmer error!`);var je=new XMLHttpRequest;return je.open("GET",m,!1),H!==ze&&je.setRequestHeader("Range",`bytes=${Ut}-${_s}`),je.responseType="arraybuffer",je.overrideMimeType&&je.overrideMimeType("text/plain; charset=x-user-defined"),je.send(null),je.status>=200&&je.status<300||je.status===304||ee(`Couldn't load ${m}. Status: ${je.status}`),je.response!==void 0?new Uint8Array(je.response||[]):ol(je.responseText??"",!0)},tn=this;tn.setDataGetter(Ut=>{var _s=Ut*ze,je=(Ut+1)*ze-1;return je=Math.min(je,H-1),typeof tn.chunks[Ut]>"u"&&(tn.chunks[Ut]=Nt(_s,je)),typeof tn.chunks[Ut]>"u"&&ee("doXHR failed!"),tn.chunks[Ut]}),(ge||!H)&&(ze=H=1,H=this.getter(0).length,ze=H,b("LazyFiles on gzip forces download of the whole file when length is accessed")),this._length=H,this._chunkSize=ze,this.lengthKnown=!0}get length(){return this.lengthKnown||this.cacheLength(),this._length}get chunkSize(){return this.lengthKnown||this.cacheLength(),this._chunkSize}}if(globalThis.XMLHttpRequest){i||ee("Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc");var S=new x,C={isDevice:!1,contents:S}}else var C={isDevice:!1,url:m};var D=_.createFile(h,d,C,g,w);C.contents?D.contents=C.contents:C.url&&(D.contents=null,D.url=C.url),Object.defineProperties(D,{usedBytes:{get:function(){return this.contents.length}}});var q={};for(let[te,X]of Object.entries(D.stream_ops))q[te]=(...H)=>(_.forceLoadFile(D),X(...H));function Y(te,X,H,re,he){var ge=te.node.contents;if(he>=ge.length)return 0;var ze=Math.min(ge.length-he,re);if(ge.slice)for(var Nt=0;Nt<ze;Nt++)X[H+Nt]=ge[he+Nt];else for(var Nt=0;Nt<ze;Nt++)X[H+Nt]=ge.get(he+Nt);return ze}return q.read=(te,X,H,re,he)=>(_.forceLoadFile(D),Y(te,X,H,re,he)),q.mmap=(te,X,H,re,he)=>{_.forceLoadFile(D);var ge=Mh(X);if(!ge)throw new _.ErrnoError(48);return Y(te,ve,ge,X,H),{ptr:ge,allocated:!0}},D.stream_ops=q,D}},ps,ti=(h,d,m)=>h?us(ps,h,d,m):"",Mt,me,He,ae={currentUmask:18,calculateAt(h,d,m=!1){if(de.isAbs(d))return d;var g;if(h===-100)g=_.cwd();else{var w=ae.getStreamFromFD(h);g=w.path}if(d.length==0){if(!m)throw new _.ErrnoError(44);return g}return g+"/"+d},writeStat(h,d){me[h>>2]=d.dev,me[h+4>>2]=d.mode,me[h+8>>2]=d.nlink,me[h+12>>2]=d.uid,me[h+16>>2]=d.gid,me[h+20>>2]=d.rdev,He[h+24>>3]=BigInt(d.size),Mt[h+32>>2]=4096,Mt[h+36>>2]=d.blocks;var m=d.atimeMs??d.atime.getTime(),g=d.mtimeMs??d.mtime.getTime(),w=d.ctimeMs??d.ctime.getTime();return He[h+40>>3]=BigInt(Math.floor(m/1e3)),me[h+48>>2]=Math.floor(m%1e3*1e6),He[h+56>>3]=BigInt(Math.floor(g/1e3)),me[h+64>>2]=Math.floor(g%1e3*1e6),He[h+72>>3]=BigInt(Math.floor(w/1e3)),me[h+80>>2]=Math.floor(w%1e3*1e6),He[h+88>>3]=BigInt(d.ino),0},writeStatFs(h,d){me[h+4>>2]=d.bsize,me[h+60>>2]=d.bsize,He[h+8>>3]=BigInt(d.blocks),He[h+16>>3]=BigInt(d.bfree),He[h+24>>3]=BigInt(d.bavail),He[h+32>>3]=BigInt(d.files),He[h+40>>3]=BigInt(d.ffree),me[h+48>>2]=d.fsid,me[h+64>>2]=d.flags,me[h+56>>2]=d.namelen},doMsync(h,d,m,g,w){if(!_.isFile(d.node.mode))throw new _.ErrnoError(43);if(g&2)return 0;var x=ps.subarray(h,h+m);_.msync(d,x,w,m,g)},getStreamFromFD(h){var d=_.getStreamChecked(h);return d},varargs:void 0,getStr(h){var d=ti(h);return d}};function f_(h){try{return h=ae.getStr(h),_.chdir(h),0}catch(d){if(typeof _>"u"||d.name!=="ErrnoError")throw d;return-d.errno}}function h_(h,d){try{return ae.writeStat(d,_.fstat(h))}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}var en=(h,d,m)=>Rh(h,ps,d,m);function c_(h,d){try{if(!d)return-28;var m=_.cwd(),g=Zs(m)+1;return d<g?-68:(en(m,h,d),g)}catch(w){if(typeof _>"u"||w.name!=="ErrnoError")throw w;return-w.errno}}var gi;function d_(h,d,m){try{var g=ae.getStreamFromFD(h);g.getdents||(g.getdents=_.readdir(g.path));for(var w=280,x=0,S=_.llseek(g,0,1),C=Math.floor(S/w),D=Math.min(g.getdents.length,C+Math.floor(m/w)),q=C;q<D;q++){var Y,te,X=g.getdents[q];if(X===".")Y=g.node.id,te=4;else if(X===".."){var H=_.lookupPath(g.path,{parent:!0});Y=H.node.id,te=4}else{var re;try{re=_.lookupNode(g.node,X)}catch(he){if((he==null?void 0:he.errno)===28)continue;throw he}Y=re.id,te=_.isChrdev(re.mode)?2:_.isDir(re.mode)?4:_.isLink(re.mode)?10:8}He[d+x>>3]=BigInt(Y),He[d+x+8>>3]=BigInt((q+1)*w),gi[d+x+16>>1]=280,ve[d+x+18]=te,en(X,d+x+19,256),x+=w}return _.llseek(g,q*w,0),x}catch(he){if(typeof _>"u"||he.name!=="ErrnoError")throw he;return-he.errno}}function u_(h,d){try{return h=ae.getStr(h),ae.writeStat(d,_.lstat(h))}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}function p_(h,d,m){try{return d=ae.getStr(d),d=ae.calculateAt(h,d),m&=~ae.currentUmask,_.mkdir(d,m),0}catch(g){if(typeof _>"u"||g.name!=="ErrnoError")throw g;return-g.errno}}function m_(h,d,m,g){try{d=ae.getStr(d);var w=g&256,x=g&4096;return g=g&-6401,d=ae.calculateAt(h,d,x),ae.writeStat(m,w?_.lstat(d):_.stat(d))}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return-S.errno}}var g_=()=>{var h=Mt[+ae.varargs>>2];return ae.varargs+=4,h};function __(h,d,m,g){ae.varargs=g;try{d=ae.getStr(d),d=ae.calculateAt(h,d);var w=g?g_():0;return m&64&&(w&=~ae.currentUmask),_.open(d,m,w).fd}catch(x){if(typeof _>"u"||x.name!=="ErrnoError")throw x;return-x.errno}}var Qh=(h,d)=>{var w,x;var m=_.getStream(h);if(!m)return 32;var g=((x=(w=m.stream_ops)==null?void 0:w.poll)==null?void 0:x.call(w,m))??5;return g&(d|8|16|32)},qh=(h,d)=>{for(var m=0,g=0,w=h;g<d;g++,w+=8){var x=Qh(Mt[w>>2],gi[w+4>>1]);x&&m++,gi[w+6>>1]=x}return m},y_=(h,d,m)=>new Promise(g=>{var w=[],x,S=!1;function C(){for(var H=0,re=0,he=h;re<d;re++,he+=8){var ge=Qh(Mt[he>>2],gi[he+4>>1]);ge&&H++,gi[he+6>>1]=ge}return H}function D(H){if(!S){S=!0;for(var re of w)re.listeners.delete(re.entry);x&&clearTimeout(x),g(H)}}var q=C();if(q||!m)D(q);else{let H=function(){if(!S){var re=C();re&&D(re)}};for(var Y=0,te=h;Y<d;Y++,te+=8){var X=_.getStream(Mt[te>>2]);X&&w.push(X.node.addListener(H))}m>0&&(x=setTimeout(()=>D(0),m))}}),Bh=function(h,d,m){let g=()=>{try{return y_(h,d,m);var w}catch(x){if(typeof _>"u"||x.name!=="ErrnoError")throw x;return-x.errno}};return j.handleAsync(g)};Bh.isAsync=!0;function b_(h,d){try{return qh(h,d)}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}function v_(h,d,m,g){try{return d=ae.getStr(d),g=ae.getStr(g),d=ae.calculateAt(h,d),g=ae.calculateAt(m,g),_.rename(d,g),0}catch(w){if(typeof _>"u"||w.name!=="ErrnoError")throw w;return-w.errno}}function O_(h){try{return h=ae.getStr(h),_.rmdir(h),0}catch(d){if(typeof _>"u"||d.name!=="ErrnoError")throw d;return-d.errno}}function w_(h,d){try{return h=ae.getStr(h),ae.writeStat(d,_.stat(h))}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}function k_(h,d,m){try{return ae.writeStatFs(m,_.statfs(ae.getStr(h))),0}catch(g){if(typeof _>"u"||g.name!=="ErrnoError")throw g;return-g.errno}}function x_(h,d,m){try{if(d=ae.getStr(d),d=ae.calculateAt(h,d),!m)_.unlink(d);else if(m===512)_.rmdir(d);else return-28;return 0}catch(g){if(typeof _>"u"||g.name!=="ErrnoError")throw g;return-g.errno}}var S_=()=>{throw new R},T_=()=>performance.now(),P_=()=>2147483648,C_=(h,d)=>Math.ceil(h/d)*d,E_=h=>{var d=tr.buffer.byteLength,m=(h-d+65535)/65536|0;try{return tr.grow(m),J(),1}catch{}},A_=h=>{var d=ps.length;h>>>=0;var m=P_();if(h>m)return!1;for(var g=1;g<=4;g*=2){var w=d*(1+.2/g);w=Math.min(w,h+100663296);var x=Math.min(m,C_(Math.max(h,w),65536)),S=E_(x);if(S)return!0}return!1},$h=h=>{if(h instanceof Ke||h=="unwind")return P;a(1,h)},al=0,Fh=()=>Ch||al>0,R_=h=>{var d;P=h,Fh()||((d=e.onExit)==null||d.call(e,h),T=!0),a(h,new Ke(h))},M_=(h,d)=>{P=h,R_(h)},N_=M_,D_=()=>{if(!Fh())try{N_(P)}catch(h){$h(h)}},fl=(h,...d)=>{if(!T)try{return h(...d)}catch(m){$h(m)}finally{D_()}},ms=(h,d)=>{var m=ms.nextId++;return ms.pending.set(m,setTimeout(()=>{ms.pending.delete(m),fl(h)},d)),m},Wh=h=>j.handleSleep(d=>{ms(()=>{var m=j.currData+12,g=me[j.currData>>2];((w,x)=>pl(h,w,x))(m,g),d()},0)});Wh.isAsync=!0;var zh=function(h){let d=()=>new Promise(m=>setTimeout(m,h));return j.handleAsync(d)};zh.isAsync=!0;function I_(h){try{var d=ae.getStreamFromFD(h);return _.close(d),0}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return m.errno}}var L_=(h,d,m,g)=>{for(var w=0,x=0;x<m;x++){var S=me[d>>2],C=me[d+4>>2];d+=8;try{var D=_.read(h,ve,S,C,g)}catch(q){if(w>0&&q instanceof _.ErrnoError&&(q.errno==6||q.errno==6))break;throw q}if(D<0)return-1;if(w+=D,D<C)break;typeof g<"u"&&(g+=D)}return w};function Q_(h,d,m,g){try{var w=ae.getStreamFromFD(h),x=L_(w,d,m);return me[g>>2]=x,0}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return S.errno}}var q_=9007199254740992,B_=-9007199254740992,$_=h=>h<B_||h>q_?NaN:Number(h);function F_(h,d,m,g){d=$_(d);try{if(isNaN(d))return 22;var w=ae.getStreamFromFD(h);return _.llseek(w,d,m),He[g>>3]=BigInt(w.position),w.getdents&&!d&&m===0&&(w.getdents=null),0}catch(x){if(typeof _>"u"||x.name!=="ErrnoError")throw x;return x.errno}}var jh=function(h){let d=()=>{var w,x;try{var m=ae.getStreamFromFD(h),g=(x=(w=m.stream_ops)==null?void 0:w.fsync)==null?void 0:x.call(w,m);return new Promise(S=>{var C=m.node.mount;C!=null&&C.type.syncfs?C.type.syncfs(C,!1,D=>S(D?29:0)):S(g)})}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return S.errno}};return j.handleAsync(d)};jh.isAsync=!0;var W_=(h,d,m,g)=>{if(m==1)return _.write(h,ve,me[d>>2],me[d+4>>2],g);for(var w=0,x=0,S=d;x<m;x++,S+=8)w+=me[S+4>>2];for(var C=new Uint8Array(w),D=0,x=0;x<m;x++,d+=8){var q=me[d>>2],Y=me[d+4>>2];C.set(ps.subarray(q,q+Y),D),D+=Y}return _.write(h,C,0,w,g)};function z_(h,d,m,g){try{var w=ae.getStreamFromFD(h),x=W_(w,d,m);return me[g>>2]=x,0}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return S.errno}}var j_=()=>globalThis.crypto.getRandomValues(new Uint32Array(1))[0],V_=()=>Date.now()-Z_,H_=()=>typeof performance<"u"&&performance.timeOrigin?performance.timeOrigin+performance.now():Date.now(),X2=[],er=h=>{try{return h()}catch(d){ee(d)}},U_=()=>{al+=1},G_=()=>{al-=1},j={instrumentWasmImports(h){var d=/^(invoke_.*|__asyncjs__.*)$/;for(let[m,g]of Object.entries(h))if(typeof g=="function"){let w=g.isAsync||d.test(m)}},instrumentFunction(h){var d=(...m)=>{j.exportCallStack.push(h);try{return h(...m)}finally{if(!T){var g=j.exportCallStack.pop();j.maybeStopUnwind()}}};return j.funcWrappers.set(h,d),d},instrumentWasmExports(h){var d={};for(let[g,w]of Object.entries(h))if(typeof w=="function"){var m=j.instrumentFunction(w);d[g]=m}else d[g]=w;return d},State:{Normal:0,Unwinding:1,Rewinding:2,Disabled:3},state:0,StackSize:65536,currData:null,handleSleepReturnValue:0,exportCallStack:[],callstackFuncToId:new Map,callStackIdToFunc:new Map,funcWrappers:new Map,callStackId:0,asyncPromiseHandlers:null,sleepCallbacks:[],getCallStackId(h){if(!j.callstackFuncToId.has(h)){var d=j.callStackId++;j.callstackFuncToId.set(h,d),j.callStackIdToFunc.set(d,h)}return j.callstackFuncToId.get(h)},maybeStopUnwind(){j.currData&&j.state===j.State.Unwinding&&!j.exportCallStack.length&&(j.state=j.State.Normal,er(fc),typeof Fibers<"u"&&Fibers.trampoline())},whenDone(){return new Promise((h,d)=>{j.asyncPromiseHandlers={resolve:h,reject:d}})},allocateData(){var h=ul(12+j.StackSize);return j.setDataHeader(h,h+12,j.StackSize),j.setDataRewindFunc(h),h},setDataHeader(h,d,m){me[h>>2]=d,me[h+4>>2]=d+m},setDataRewindFunc(h){var d=j.exportCallStack[0],m=j.getCallStackId(d);Mt[h+8>>2]=m},getDataRewindFunc(h){var d=Mt[h+8>>2],m=j.callStackIdToFunc.get(d);return m},doRewind(h){var d=j.getDataRewindFunc(h),m=j.funcWrappers.get(d);return fl(m)},handleSleep(h){if(!T){if(j.state===j.State.Normal){var d=!1,m=!1;h((w=0)=>{if(!T&&(j.handleSleepReturnValue=w,d=!0,!!m)){j.state=j.State.Rewinding,er(()=>hc(j.currData)),typeof MainLoop<"u"&&MainLoop.func&&MainLoop.resume();var x,S=!1;try{x=j.doRewind(j.currData)}catch(q){x=q,S=!0}var C=!1;if(!j.currData){var D=j.asyncPromiseHandlers;D&&(j.asyncPromiseHandlers=null,(S?D.reject:D.resolve)(x),C=!0)}if(S&&!C)throw x}}),m=!0,d||(j.state=j.State.Unwinding,j.currData=j.allocateData(),typeof MainLoop<"u"&&MainLoop.func&&MainLoop.pause(),er(()=>ac(j.currData)))}else if(j.state===j.State.Rewinding){j.state=j.State.Normal,er(cc),Gh(j.currData),j.currData=null;for(var g of j.sleepCallbacks)fl(g)}else ee(`invalid state: ${j.state}`);return j.handleSleepReturnValue}},handleAsync:h=>j.handleSleep(async d=>{d(await h())})},hl,cl;function X_(h,d,m="i8"){switch(m.endsWith("*")&&(m="*"),m){case"i1":ve[h]=d;break;case"i8":ve[h]=d;break;case"i16":gi[h>>1]=d;break;case"i32":Mt[h>>2]=d;break;case"i64":He[h>>3]=BigInt(d);break;case"float":hl[h>>2]=d;break;case"double":cl[h>>3]=d;break;case"*":me[h>>2]=d;break;default:ee(`invalid type for setValue: ${m}`)}}function dl(h,d="i8"){switch(d.endsWith("*")&&(d="*"),d){case"i1":return ve[h];case"i8":return ve[h];case"i16":return gi[h>>1];case"i32":return Mt[h>>2];case"i64":return He[h>>3];case"float":return hl[h>>2];case"double":return cl[h>>3];case"*":return me[h>>2];default:ee(`invalid type for getValue: ${d}`)}}var Vh=h=>{var d=e["_"+h];return d},J_=(h,d)=>{ve.set(h,d)},Hh=h=>Yh(h),Y_=h=>{var d=Zs(h)+1,m=Hh(d);return en(h,m,d),m},Uh=(h,d,m,g,w)=>{var x={string:ge=>{var ze=0;return ge!=null&&ge!==0&&(ze=Y_(ge)),ze},array:ge=>{var ze=Hh(ge.length);return J_(ge,ze),ze}};function S(ge){return d==="string"?ti(ge):d==="boolean"?!!ge:ge}var C=Vh(h),D=[],q=0;if(g)for(var Y=0;Y<g.length;Y++){var te=x[m[Y]];te?(q||(q=yt()),D[Y]=te(g[Y])):D[Y]=g[Y]}var X=j.currData,H=C(...D);function re(ge){return G_(),q&&_t(q),S(ge)}var he=w==null?void 0:w.async;return U_(),j.currData!=X?j.whenDone().then(re):(H=re(H),he?Promise.resolve(H):H)},K_=(h,d,m,g)=>{var w=!m||m.every(S=>S==="number"||S==="boolean"),x=d!=="string";return x&&w&&!g?Vh(h):(...S)=>Uh(h,d,m,S,g)};_.createPreloadedFile=a_,_.preloadFile=Lh,_.staticInit(),ms.pending=new Map,ms.nextId=1,globalThis.crypto===void 0&&(globalThis.crypto=r("crypto"));var Z_=Date.now();{e.noExitRuntime&&(Ch=e.noExitRuntime),e.print&&(b=e.print),e.printErr&&(O=e.printErr),e.arguments&&(o=e.arguments),e.thisProgram&&(l=e.thisProgram);var gs=e.preInit;if(gs)for(typeof gs=="function"&&(e.preInit=gs=[gs]);gs.length>0;)gs.shift()()}e.ccall=Uh,e.cwrap=K_,e.setValue=X_,e.getValue=dl,e.PATH=de,e.PATH_FS=Di,e.UTF8ToString=ti,e.stringToUTF8=en,e.lengthBytesUTF8=Zs,e.FS=_;function ey(){return-new Date().getTimezoneOffset()*60}function ty(){return e.raptiPending?e.raptiPending()|0:0}function iy(){return e.raptiShouldYield?e.raptiShouldYield()|0:0}function sy(h){return j.handleAsync(async()=>{let d=ti(h),m=e.raptiReadLine?await e.raptiReadLine(d):"",g=m==null?"":String(m),w=Zs(g)+1,x=ul(w);return en(g,x,w),x})}function ny(){return e.raptiDead?1:0}function ry(){return j.handleAsync(async()=>{await new Promise(()=>{})})}function oy(h){let d=Oe(h);Yb(d,h)}function ly(h){let d=Oe(h),m=Bi.toJs(d);Ce(m,h)}function ay(h){let d=0;for(let m of proxy_js_ref)m!==void 0&&++d;e.setValue(h,proxy_js_ref.length,"i32"),e.setValue(h+4,d,"i32")}function fy(h,d){let m=proxy_js_ref[h];return ti(d)in m}function hy(h,d,m){let g=proxy_js_ref[h],w=ti(d),x=g[w];return x!==void 0||w in g?(Ce(x,m),typeof x=="function"&&!("_ref"in x)?2:1):0}function cy(h,d,m){let g=ti(d),w=Oe(m);proxy_js_ref[h][g]=w}function dy(h,d){let m=proxy_js_ref[h],g=m();Ce(g,d)}function uy(h,d,m,g){let w=Oe(m),x=proxy_js_ref[h],S;d?S=x.call(w):S=x(w),Ce(S,g)}function py(h,d,m,g,w){let x=Oe(m),S=Oe(g),C=proxy_js_ref[h],D;d?D=C.call(x,S):D=C(x,S),Ce(D,w)}function my(h,d,m,g,w){let x=proxy_js_ref[h],S=[];for(let D=0;D<m;++D){let q=Oe(g+D*3*4);S.push(q)}let C;d?C=x.call(...S):C=x(...S),Ce(C,w)}function gy(h,d,m,g,w,x){let S=proxy_js_ref[h],C={};for(let q=0;q<m;++q){let Y=ti(dl(g+q*4,"i32")),te=Oe(w+q*3*4);C[Y]=te}let D;d?D=S.call(C):D=S(C),Ce(D,x)}function _y(h,d,m,g,w,x,S,C){let D=proxy_js_ref[h],q=[];for(let X=0;X<m;++X){let H=Oe(g+X*3*4);q.push(H)}let Y={};for(let X=0;X<w;++X){let H=ti(dl(x+X*4,"i32")),re=Oe(S+X*3*4);Y[H]=re}let te;d?te=D.call(...q,Y):te=D(...q,Y),Ce(te,C)}function yy(h,d,m,g){let w=proxy_js_ref[h],x=[];for(let C=0;C<d;++C)x.push(Oe(m+C*3*4));let S=Reflect.construct(w,x);Ce(S,g)}function by(h,d){let g=proxy_js_ref[h][Symbol.iterator]();Ce(g,d)}function vy(h,d){let g=proxy_js_ref[h].next();return g.done?!1:(Ce(g.value,d),!0)}function Oy(h,d,m){let g=proxy_js_ref[h],w=Kb(g,Oe(d)),x=g[w];Ce(x,m)}function wy(h,d,m){let g=proxy_js_ref[h];g[Oe(d)]=Oe(m)}function ky(h){h>=kc&&(proxy_js_ref_map.delete(proxy_js_ref[h]),proxy_js_ref[h]=void 0,h<proxy_js_ref_next&&(proxy_js_ref_next=h))}function xy(h){return Gb(h)}function Sy(h,d,m){let g=proxy_js_ref[h];Ce(g.name,d),Ce(g.message,m)}function Ty(h,d){let m=Oe(h);Oe(d)(m)}function Py(h,d){let m;try{m=Oe(h)}catch(w){m=w}Oe(d)(m)}function Cy(h,d,m,g,w){let x=Oe(d),S=Oe(m),C=Oe(g),D=proxy_js_ref[h].then(q=>{x(q,null,S,C)},q=>{x(null,q,S,C)});Ce(D,w)}function Ey(h,d){let m=Oe(h),g=new Promise(m);Ce(g,d)}var Ay,Gh,Ry,ul,My,Ny,Dy,Iy,Ly,Qy,qy,By,$y,Fy,Wy,zy,jy,Vy,Hy,Uy,Gy,Xy,Jy,Yy,Xh,bt,Jh,Yh,Kh,Zh,ec,tc,ic,pl,sc,nc,rc,oc,Ky,Zy,eb,lc,tb,ac,fc,hc,cc,ib,sb,tr,nb;function rb(h){Ay=e._mp_sched_keyboard_interrupt=h.mp_sched_keyboard_interrupt,Gh=e._free=h.free,Ry=e._mp_js_init=h.mp_js_init,ul=e._malloc=h.malloc,My=e._mp_js_register_js_module=h.mp_js_register_js_module,Ny=e._mp_js_do_import=h.mp_js_do_import,Dy=e._proxy_convert_mp_to_js_obj_cside=h.proxy_convert_mp_to_js_obj_cside,Iy=e._mp_js_do_exec=h.mp_js_do_exec,Ly=e._mp_js_do_exec_async=h.mp_js_do_exec_async,Qy=e._mp_js_repl_init=h.mp_js_repl_init,qy=e._mp_js_repl_process_char=h.mp_js_repl_process_char,By=e._mp_hal_get_interrupt_char=h.mp_hal_get_interrupt_char,$y=e._proxy_c_init=h.proxy_c_init,Fy=e._proxy_c_free_obj=h.proxy_c_free_obj,Wy=e._proxy_c_to_js_call=h.proxy_c_to_js_call,zy=e._proxy_c_to_js_dir=h.proxy_c_to_js_dir,jy=e._proxy_c_to_js_has_attr=h.proxy_c_to_js_has_attr,Vy=e._proxy_c_to_js_lookup_attr=h.proxy_c_to_js_lookup_attr,Hy=e._proxy_c_to_js_store_attr=h.proxy_c_to_js_store_attr,Uy=e._proxy_c_to_js_delete_attr=h.proxy_c_to_js_delete_attr,Gy=e._proxy_c_to_js_get_type_and_data=h.proxy_c_to_js_get_type_and_data,Xy=e._proxy_c_to_js_get_iter=h.proxy_c_to_js_get_iter,Jy=e._proxy_c_to_js_iternext=h.proxy_c_to_js_iternext,Yy=e._proxy_c_to_js_resume=h.proxy_c_to_js_resume,Xh=h.emscripten_stack_get_current,bt=h.setThrew,Jh=h._emscripten_stack_restore,Yh=h._emscripten_stack_alloc,Kh=De.viii=h.dynCall_viii,Zh=De.vi=h.dynCall_vi,ec=De.ii=h.dynCall_ii,tc=De.iiii=h.dynCall_iiii,ic=De.v=h.dynCall_v,pl=De.vii=h.dynCall_vii,sc=De.iii=h.dynCall_iii,nc=De.viiii=h.dynCall_viiii,rc=De.iiiii=h.dynCall_iiiii,oc=De.i=h.dynCall_i,Ky=De.dd=h.dynCall_dd,Zy=De.ddd=h.dynCall_ddd,eb=De.viiiiii=h.dynCall_viiiiii,lc=De.iiiiii=h.dynCall_iiiiii,tb=De.iidiiiii=h.dynCall_iidiiiii,ac=h.asyncify_start_unwind,fc=h.asyncify_stop_unwind,hc=h.asyncify_start_rewind,cc=h.asyncify_stop_rewind,ib=tr=h.memory,sb=nb=h.__indirect_function_table}var dc={__asyncjs__rapti_js_park:ry,__asyncjs__rapti_js_readline:sy,__syscall_chdir:f_,__syscall_fstat64:h_,__syscall_getcwd:c_,__syscall_getdents64:d_,__syscall_lstat64:u_,__syscall_mkdirat:p_,__syscall_newfstatat:m_,__syscall_openat:__,__syscall_poll:Bh,__syscall_poll_nonblocking:b_,__syscall_renameat:v_,__syscall_rmdir:O_,__syscall_stat64:w_,__syscall_statfs64:k_,__syscall_unlinkat:x_,_emscripten_throw_longjmp:S_,call0:dy,call0_kwarg:gy,call1:uy,call2:py,calln:my,calln_kwarg:_y,create_promise:Ey,emscripten_get_now:T_,emscripten_resize_heap:A_,emscripten_scan_registers:Wh,emscripten_sleep:zh,fd_close:I_,fd_read:Q_,fd_seek:F_,fd_sync:jh,fd_write:z_,has_attr:fy,invoke_i:pb,invoke_ii:ob,invoke_iii:cb,invoke_iiii:lb,invoke_iiiii:hb,invoke_iiiiii:gb,invoke_v:ab,invoke_vi:db,invoke_vii:ub,invoke_viii:fb,invoke_viiii:mb,js_check_existing:xy,js_get_error_info:Sy,js_get_iter:by,js_get_proxy_js_ref_info:ay,js_iter_next:vy,js_reflect_construct:yy,js_subscr_load:Oy,js_subscr_store:wy,js_then_continue:Cy,js_then_reject:Py,js_then_resolve:Ty,lookup_attr:hy,mp_js_random_u32:j_,mp_js_ticks_ms:V_,mp_js_time_ms:H_,mp_js_tz_offset_s:ey,proxy_convert_mp_to_js_then_js_to_js_then_js_to_mp_obj_jsside:ly,proxy_convert_mp_to_js_then_js_to_mp_obj_jsside:oy,proxy_js_free_obj:ky,rapti_js_dead:ny,rapti_js_pending:ty,rapti_js_should_yield:iy,store_attr:cy};function ob(h,d){var m=yt();try{return ec(h,d)}catch(g){if(_t(m),!(g instanceof E))throw g;bt(1,0)}}function lb(h,d,m,g){var w=yt();try{return tc(h,d,m,g)}catch(x){if(_t(w),!(x instanceof E))throw x;bt(1,0)}}function ab(h){var d=yt();try{ic(h)}catch(m){if(_t(d),!(m instanceof E))throw m;bt(1,0)}}function fb(h,d,m,g){var w=yt();try{Kh(h,d,m,g)}catch(x){if(_t(w),!(x instanceof E))throw x;bt(1,0)}}function hb(h,d,m,g,w){var x=yt();try{return rc(h,d,m,g,w)}catch(S){if(_t(x),!(S instanceof E))throw S;bt(1,0)}}function cb(h,d,m){var g=yt();try{return sc(h,d,m)}catch(w){if(_t(g),!(w instanceof E))throw w;bt(1,0)}}function db(h,d){var m=yt();try{Zh(h,d)}catch(g){if(_t(m),!(g instanceof E))throw g;bt(1,0)}}function ub(h,d,m){var g=yt();try{pl(h,d,m)}catch(w){if(_t(g),!(w instanceof E))throw w;bt(1,0)}}function pb(h){var d=yt();try{return oc(h)}catch(m){if(_t(d),!(m instanceof E))throw m;bt(1,0)}}function mb(h,d,m,g,w){var x=yt();try{nc(h,d,m,g,w)}catch(S){if(_t(x),!(S instanceof E))throw S;bt(1,0)}}function gb(h,d,m,g,w,x){var S=yt();try{return lc(h,d,m,g,w,x)}catch(C){if(_t(S),!(C instanceof E))throw C;bt(1,0)}}async function _b(){var d;fe(),Ii&&await s_();var h=e.setStatus;h&&(h("Running..."),await new Promise(m=>setTimeout(m,1)),setTimeout(h,1,"")),!T&&(Z(),(d=e.onRuntimeInitialized)==null||d.call(e),U())}var Li;return Li=await Rt(),await _b(),e}async function _l(n){let{pystack:e,heapsize:t,url:i,stdin:s,stdout:r,stderr:o,linebuffer:l}=Object.assign({pystack:2048,heapsize:1048576,linebuffer:!0},n),a=Object.assign({},n.module||{});a.locateFile=(c,u)=>i||u+c,a._textDecoder=new TextDecoder,s!==void 0&&(a.stdin=s),r!==void 0&&(l?(a._stdoutBuffer=[],a.stdout=c=>{c===10?(r(a._textDecoder.decode(new Uint8Array(a._stdoutBuffer))),a._stdoutBuffer=[]):a._stdoutBuffer.push(c)}):a.stdout=c=>r(new Uint8Array([c]))),o!==void 0&&(l?(a._stderrBuffer=[],a.stderr=c=>{c===10?(o(a._textDecoder.decode(new Uint8Array(a._stderrBuffer))),a._stderrBuffer=[]):a._stderrBuffer.push(c)}):a.stderr=c=>o(new Uint8Array([c]))),a=await Sb(a),globalThis.Module=a,Ub();let f=c=>{let u=a._malloc(12);return a.ccall("mp_js_do_import","null",["string","pointer"],[c,u]),qi(u)};return a.ccall("mp_js_init","null",["number","number"],[e,t]),a.ccall("proxy_c_init","null",[],[]),{_module:a,PyProxy:Bi,FS:a.FS,globals:{__dict__:f("__main__").__dict__,get(c){return this.__dict__[c]},set(c,u){this.__dict__[c]=u},delete(c){delete this.__dict__[c]}},registerJsModule(c,u){let p=a._malloc(12);Ce(u,p),a.ccall("mp_js_register_js_module","null",["string","pointer"],[c,p]),a._free(p)},pyimport:f,runPython(c){let u=a.lengthBytesUTF8(c),p=a._malloc(u+1);a.stringToUTF8(c,p,u+1);let y=a._malloc(3*4);return a.ccall("mp_js_do_exec","number",["pointer","number","pointer"],[p,u,y]),a._free(p),qi(y)},runPythonAsync(c){let u=a.lengthBytesUTF8(c),p=a._malloc(u+1);a.stringToUTF8(c,p,u+1);let y=a._malloc(3*4);a.ccall("mp_js_do_exec_async","number",["pointer","number","pointer"],[p,u,y]),a._free(p);let v=qi(y);return v instanceof ys?Promise.resolve(v):v},replInit(){a.ccall("mp_js_repl_init","null",["null"])},replProcessChar(c){return a.ccall("mp_js_repl_process_char","number",["number"],[c])},async replProcessCharWithAsyncify(c){return a.ccall("mp_js_repl_process_char","number",["number"],[c],{async:!0})}}}globalThis.loadMicroPython=_l;var Bi=class n{constructor(e){this._ref=e}static toJs(e){if(!(e instanceof n))return e;let t=Module._malloc(2*4),i=Module.ccall("proxy_c_to_js_get_type_and_data","number",["number","pointer"],[e._ref,t]),s;if(i===1||i===2){let r=Module._malloc(12),o=Module.getValue(t,"i32"),l=Module.getValue(t+4,"i32"),a=[];for(let f=0;f<o;++f){Module.ccall("proxy_convert_mp_to_js_obj_cside","null",["pointer","pointer"],[Module.getValue(l+f*4,"i32"),r]);let c=Oe(r);a.push(n.toJs(c))}Module._free(r),s=a}else if(i===3){let r=Module._malloc(12),o=Module.getValue(t,"i32"),l=Module.getValue(t+4,"i32"),a={};for(let f=0;f<o;++f){let c=Module.getValue(l+f*8,"i32");if(c>8){Module.ccall("proxy_convert_mp_to_js_obj_cside","null",["pointer","pointer"],[c,r]);let u=Oe(r),p=Module.getValue(l+f*8+4,"i32");Module.ccall("proxy_convert_mp_to_js_obj_cside","null",["pointer","pointer"],[p,r]);let y=Oe(r);a[u]=n.toJs(y)}}Module._free(r),s=a}else if(i===4){let r=Module.getValue(t,"i32"),o=Module.getValue(t+4,"i32");s=Module.HEAPU8.slice(o,o+r)}else s=e;return Module._free(t),s}},Tb={isExtensible(){return!0},ownKeys(n){let e=Module._malloc(12);Module.ccall("proxy_c_to_js_dir","null",["number","pointer"],[n._ref,e]);let t=qi(e);return Bi.toJs(t).filter(i=>!i.startsWith("__"))},getOwnPropertyDescriptor(n,e){return{value:n[e],enumerable:!0,writable:!0,configurable:!0}},has(n,e){return typeof e!="string"?e===Symbol.iterator:Module.ccall("proxy_c_to_js_has_attr","number",["number","string"],[n._ref,e])},get(n,e){if(e==="_ref")return n._ref;if(e==="then"||typeof e!="string"){if(e===Symbol.iterator){let i=Module.ccall("proxy_c_to_js_get_iter","number",["number"],[n._ref]);return function*(){let s=Module._malloc(12);for(;Module.ccall("proxy_c_to_js_iternext","number",["number","pointer"],[i,s]);)yield Oe(s);Module._free(s)}}return}let t=Module._malloc(3*4);return Module.ccall("proxy_c_to_js_lookup_attr","null",["number","string","pointer"],[n._ref,e,t]),qi(t)},set(n,e,t){let i=Module._malloc(12);Ce(t,i);let s=Module.ccall("proxy_c_to_js_store_attr","number",["number","string","number"],[n._ref,e,i]);return Module._free(i),s},deleteProperty(n,e){return Module.ccall("proxy_c_to_js_delete_attr","number",["number","string"],[n._ref,e])}},ys=class{constructor(e){this._ref=e}then(e,t){let i=Module._malloc(36);return Ce(e,i+3*4),Ce(t,i+2*3*4),Module.ccall("proxy_c_to_js_resume","null",["number","pointer"],[this._ref,i]),qi(i)}},kc=2,Pb=-1,Cb=0,Eb=1,Ab=2,Rb=3,Mb=4,Nb=5,Db=6,Ib=7;var Lb=9,Qb=10,qb=0,Bb=1,$b=2,Fb=3,Wb=4,zb=5,jb=6,Vb=7,Hb=8,sr=class extends Error{constructor(e,t){super(t),this.name="PythonError",this.type=e}};function Ub(){globalThis.proxy_js_ref=[globalThis,void 0],globalThis.proxy_js_ref_next=kc,globalThis.proxy_js_ref_map=new Map,globalThis.proxy_js_ref_map.set(globalThis,0),globalThis.proxy_js_map=new Map,globalThis.proxy_js_existing=[void 0],globalThis.pyProxyFinalizationRegistry=new FinalizationRegistry(n=>{globalThis.proxy_js_map.delete(n),Module.ccall("proxy_c_free_obj","null",["number"],[n])})}function Gb(n){var t;let e=(t=globalThis.proxy_js_map.get(n))==null?void 0:t.deref();if(e===void 0)return-1;for(let i=0;i<globalThis.proxy_js_existing.length;++i)if(globalThis.proxy_js_existing[i]===void 0)return globalThis.proxy_js_existing[i]=e,i;return globalThis.proxy_js_existing.push(e),globalThis.proxy_js_existing.length-1}function Xb(n){for(;proxy_js_ref_next<proxy_js_ref.length;){if(proxy_js_ref[proxy_js_ref_next]===void 0){let t=proxy_js_ref_next;return++proxy_js_ref_next,proxy_js_ref[t]=n,proxy_js_ref_map.set(n,t),t}++proxy_js_ref_next}let e=proxy_js_ref.length;return proxy_js_ref[e]=n,proxy_js_ref_next=proxy_js_ref.length,proxy_js_ref_map.set(n,e),e}function Jb(n,e){let t=0;for(;e.length>0&&e[e.length-1]===void 0;)e.pop();if(e.length>0){t=Module._malloc(e.length*3*4);for(let r in e)Ce(e[r],t+r*3*4)}let i=Module._malloc(3*4);Module.ccall("proxy_c_to_js_call","null",["number","number","number","pointer"],[n,e.length,t,i]),e.length>0&&Module._free(t);let s=qi(i);return s instanceof ys?Promise.resolve(s):s}function xc(n,e,t){let i;if(n===void 0)i=qb;else if(n===null)i=Bb;else if(typeof n=="boolean")i=$b,Module.setValue(e+4,n,"i32");else if(typeof n=="number")if(Number.isInteger(n))i=Fb,Module.setValue(e+4,n,"i32");else{i=Wb;let s=e+4&-8;Module.setValue(s,n,"double");let r=Module.getValue(s,"i32"),o=Module.getValue(s+4,"i32");Module.setValue(e+4,r,"i32"),Module.setValue(e+8,o,"i32")}else if(typeof n=="string"){i=zb;let s=Module.lengthBytesUTF8(n),r=Module._malloc(s+1);Module.stringToUTF8(n,r,s+1),Module.setValue(e+4,s,"i32"),Module.setValue(e+8,r,"i32")}else if(t&&(n instanceof Bi||typeof n=="function"&&"_ref"in n||n instanceof ys))i=Hb,Module.setValue(e+4,n._ref,"i32");else{let s,r=proxy_js_ref_map.get(n);r!==void 0?(i=jb,s=r):(i=Vb,s=Xb(n)),Module.setValue(e+4,s,"i32")}Module.setValue(e+0,i,"i32")}function Ce(n,e){xc(n,e,!0)}function Yb(n,e){xc(n,e,!1)}function Oe(n){let e=Module.getValue(n,"i32"),t;if(e===Pb){let i=Module.getValue(n+4,"i32"),s=Module.getValue(n+8,"i32"),r=Module.UTF8ToString(s,i);Module._free(s);let o=r.split("");throw new sr(o[0],o[1])}if(e===Cb)throw new Error("NULL object");if(e===Eb)t=null;else if(e===Ab)t=!!Module.getValue(n+4,"i32");else if(e===Rb)t=Module.getValue(n+4,"i32");else if(e===Mb){let i=n+4&-8,s=Module.getValue(n+4,"i32"),r=Module.getValue(n+8,"i32");Module.setValue(i,s,"i32"),Module.setValue(i+4,r,"i32"),t=Module.getValue(i,"double")}else if(e===Nb){let i=Module.getValue(n+4,"i32"),s=Module.getValue(n+8,"i32");t=Module.UTF8ToString(s,i)}else if(e===Lb){let i=Module.getValue(n+4,"i32");t=proxy_js_ref[i]}else if(e===Qb){let i=Module.getValue(n+4,"i32");t=globalThis.proxy_js_existing[i],globalThis.proxy_js_existing[i]=void 0}else{let i=Module.getValue(n+4,"i32");if(e===Db)t=(...s)=>Jb(i,s),t._ref=i;else if(e===Ib)t=new ys(i);else{let s=new Bi(i);t=new Proxy(s,Tb)}globalThis.pyProxyFinalizationRegistry.register(t,i),globalThis.proxy_js_map.set(i,new WeakRef(t))}return t}function qi(n){let e=Oe(n);return Module._free(n),e}function Kb(n,e){let t=e;if(typeof t=="number"&&(t<0&&(t+=n.length),t<0||t>=n.length))throw new sr("IndexError","index out of range");return t}var Cc=se(ir(),1);function Sc(n){let e=()=>n.net,t=()=>n.netDev,i=0,s=new Map,r=new Map,o=new Map,l=()=>!!(e()&&t());return{net_online:()=>l()&&e().online(t())?1:0,net_ip:()=>l()?t().ip:"",net_resolve:a=>l()?e().resolve(a,t()):"",net_hostname:()=>l()&&t().hostname||"raspberrypi",net_request:(a,f,c,u)=>{let p=++i,y={done:!1,res:null};if(s.set(p,y),!l())return y.done=!0,y.res={failed:!0,error:"ERR_INTERNET_DISCONNECTED",statusText:"No network"},p;let v={};try{v=JSON.parse(c||"{}")}catch{}return e().request({method:a,url:f,headers:v,body:u,fromName:t().name},t()).then(b=>{y.done=!0,y.res=b}),p},net_poll:a=>{let f=s.get(a);return!f||!f.done?"":(s.delete(a),JSON.stringify(f.res))},net_listen:a=>l()?e().serverFor(t(),a)?-1:(e().listen(t(),a,t().name),1):0,net_unlisten:a=>{l()&&e().unlisten(t(),a)},net_accept:a=>{if(!l())return 0;let f=e().serverFor(t(),a);if(!f||!f.pending.length)return 0;let c=++i;return r.set(c,f.pending.shift()),c},net_req:a=>{let f=r.get(a);return f?JSON.stringify(f.req):"{}"},net_respond:(a,f,c,u)=>{let p=r.get(a);if(!p)return;r.delete(a);let y={};try{y=JSON.parse(c||"{}")}catch{}p.respond({status:f,headers:y,body:u})},mqtt_connect:(a,f,c,u,p,y,v)=>{if(!l())return-4;let b=y?{topic:y,payload:v||"",retain:!1}:null,O=e().mqtt.connect(a,f,c,{user:u||void 0,pass:p,will:b},t());if(!O.ok)return O.code;let k=++i;return o.set(k,O.client),k},mqtt_subscribe:(a,f)=>o.has(a)&&e().mqtt.subscribe(o.get(a),f)?1:0,mqtt_unsubscribe:(a,f)=>{o.has(a)&&e().mqtt.unsubscribe(o.get(a),f)},mqtt_publish:(a,f,c,u)=>o.has(a)&&e().mqtt.publish(o.get(a),f,c,!!u)?1:0,mqtt_poll:a=>{let f=o.get(a),c=f&&e().mqtt.poll(f);return c?JSON.stringify(c):""},mqtt_connected:a=>o.has(a)&&o.get(a).connected&&e().online(t())?1:0,mqtt_disconnect:a=>{let f=o.get(a);f&&(e().mqtt.disconnect(f),o.delete(a))},wifi_join:(a,f)=>l()?JSON.stringify(e().join(t(),a,f)):JSON.stringify({status:1,ip:""}),wifi_leave:()=>{l()&&e().leave(t())},wifi_ap:(a,f,c)=>{if(!l())return 0;let u=t();return u.apOn=!!a,u.apIp=a?"192.168.4.1":"",u.apSsid=f||"",e().changed(),1},wifi_info:()=>JSON.stringify(l()?{connected:e().online(t()),ip:t().ip,ssid:t().ssid,rssi:t().rssi,mac:e().macString(t()),router:e().opts.router}:{connected:!1}),wifi_scan:()=>JSON.stringify(l()?e().scan():[])}}var Ec=se(Pc(),1),Zb=["RPi/__init__.py","RPi/GPIO.py","gpiozero/__init__.py","gpiozero/tones.py","board.py","adafruit_dht.py","signal.py","smbus2.py","smbus.py","serial.py","flask.py","http/__init__.py","http/server.py","paho/__init__.py","paho/mqtt/__init__.py","paho/mqtt/client.py","paho/mqtt/publish.py","paho/mqtt/subscribe.py","psutil.py","threading.py","adafruit_ssd1306.py","busio.py","spidev.py","RPLCD/__init__.py","RPLCD/i2c.py"],e1=["machine.py","rp2.py","network.py","dht.py","urequests.py","umqtt/__init__.py","umqtt/simple.py","ntptime.py","pico_i2c_lcd.py","lcd_api.py"],sn=null;function t1(n){return sn||(sn=(async()=>{let e=n?await n():await(await fetch((0,Ec.asset)("micropython.wasm"))).arrayBuffer();return WebAssembly.compile(e)})(),sn.catch(()=>{sn=null})),sn}function i1(n,e){let t=i=>i==="LED"?Cc.PICO_W_LED:i;return{board:()=>n.board,setup:(i,s,r)=>n.setup(t(i),s,r),set_pull:(i,s)=>n.setPull(t(i),s),write:(i,s)=>n.write(t(i),s),read:i=>n.read(t(i)),level:i=>n.level(t(i)),duty:i=>n.duty(t(i)),pwm:(i,s,r)=>n.pwm(t(i),s,r),pwm_off:i=>n.pwmOff(t(i)),blink:(i,s,r,o,l,a,f,c)=>n.blink(t(i),s,r,o,l,a,f,c),stop_bg:i=>n.stopBg(t(i)),watch:(i,s,r)=>n.watch(t(i),s,r),watch_cb:(i,s)=>n.watchCb(t(i),s),unwatch:i=>n.unwatch(t(i)),detected:i=>n.detected(t(i)),release:i=>n.release(t(i)),in_use:i=>(n.pins.get(t(i))||{}).used?1:0,claim:(i,s)=>{let r=n.pins.get(t(i));r&&(r.owner=s)},timer:(i,s,r)=>n.timer(i,s,r),timer_stop:i=>n.timerStop(i),next_event:()=>n.nextEvent(),event_arg:()=>n.evArg,adc:i=>n.adc(i),mcp3008:i=>n.mcp3008(i),light:i=>n.light(i),distance:i=>n.distance(i),dht:(i,s)=>n.dht(i,s),neo:(i,s,r)=>n.neoWrite(t(i),s,r),bootsel:()=>n.bootsel,cpu_temp:()=>n.cpuTemp(),tz_offset:i=>-new Date(i*1e3).getTimezoneOffset()*60,wifi:(i,s)=>{n.wifiState={state:i,ssid:s},n.changed()},uart_write:(i,s)=>{!n.uartWrite(i,s)&&!n.uartWired(i)&&e.write(s)},uart_any:i=>n.uartAny(i),uart_read:(i,s)=>n.uartRead(i,s),uart_readline:(i,s)=>n.uartReadLine(i,s),uart_has_line:i=>n.uartHasLine(i)?1:0,i2c_has:(i,s,r)=>n.i2cHas(i,s,r),i2c_scan:(i,s)=>n.i2cScan(i,s),i2c_write:(i,s,r,o)=>n.i2cWrite(i,s,r,o),i2c_read:(i,s,r,o)=>n.i2cRead(i,s,r,o),spi_xfer:(i,s,r)=>n.spiXfer(i,s,r),disp_tm1637:(i,s,r,o,l)=>n.dispTm1637(i,s,r,o,l),...Sc(n)}}var s1=n=>`
import _rpi_boot as __rb
__rb.start()
try:
    exec(compile(open(${JSON.stringify(n)}).read(), ${JSON.stringify(n)}, 'exec'))
except BaseException as __e:
    __rb.report(__e)
del __rb
`,n1=(n,e)=>`
import _rpi_boot as __rb
__rb.start()
try:
    exec(compile(${JSON.stringify(n)}, ${JSON.stringify(e)}, 'exec'))
except BaseException as __e:
    __rb.report(__e)
del __rb
`,r1=n=>`
import _rpi_boot as __rb
try:
    exec(compile(${JSON.stringify(n)}, '<stdin>', 'single'))
except BaseException as __e:
    __rb.report(__e, True)
del __rb
`,o1=`
import sys, io
_status = [0]
def start():
    _status[0] = 0
def report(e, keep=False):
    if isinstance(e, SystemExit):
        code = e.value if hasattr(e, 'value') else (e.args[0] if e.args else None)
        if code not in (None, 0):
            if not isinstance(code, int):
                print(code, file=sys.stderr)
            _status[0] = 1
        return
    _status[0] = 2 if isinstance(e, KeyboardInterrupt) else 1
    s = io.StringIO()
    sys.print_exception(e, s)
    lines = s.getvalue().split('\\n')
    out = lines if keep else [l for l in lines if '"<stdin>"' not in l]
    sys.stderr.write('\\n'.join(out))
def status():
    return _status[0]
`,l1=new TextDecoder("utf-8",{fatal:!0}),nr=class{constructor({gpio:e,libs:t,out:i,readLine:s,files:r,cwd:o="/home/pi",banner:l,wasmLoader:a,heap:f=6<<20}){this.gpio=e,this.libs=t||{},this.out=i||(()=>{}),this.readLine=s||(async()=>""),this.files=r||{},this.cwd=o,this.banner=l,this.wasmLoader=a,this.heap=f,this.dead=!1,this.busy=!1,this.queue=Promise.resolve(),this.pendingRead=null,this.readDone=null,this.outBuf="",this.errBuf=""}async start(){let e=await t1(this.wasmLoader),t=new TextDecoder,i=new TextDecoder,s={instantiateWasm:(a,f)=>(WebAssembly.instantiate(e,a).then(c=>f(c,e)),{}),locateFile:a=>a,print:()=>{},printErr:()=>{}};this.mp=await _l({heapsize:this.heap,pystack:4096,linebuffer:!1,stdout:a=>this.emit(t.decode(a,{stream:!0}),"out"),stderr:a=>this.emit(i.decode(a,{stream:!0}),"err"),module:s});let r=this.mp._module;this.M=r,r.raptiPending=()=>this.dead?0:this.gpio.pending(),r.raptiShouldYield=()=>this.gpio.shouldYield(),r.raptiReadLine=a=>new Promise(f=>this.startRead(a,f)),this.mp.registerJsModule("_rpi_js",{...i1(this.gpio,this),read_start:a=>{this.readDone=null,this.startRead(a,(f,c)=>{c||(this.readDone=f==null?"":String(f))})},read_ready:()=>this.readDone!=null?1:0,read_line:()=>{let a=this.readDone;return this.readDone=null,a??""}});let o=this.mp.FS,l=this.gpio.isPico;o.mkdirTree("/rlib/RPi");for(let[a,f]of Object.entries(this.libs)){if(l&&Zb.includes(a)||!l&&e1.includes(a))continue;let c=a.lastIndexOf("/");if(c>0)try{o.mkdirTree("/rlib/"+a.slice(0,c))}catch{}o.writeFile("/rlib/"+a,f)}o.writeFile("/rlib/_rpi_boot.py",o1),this.writeFiles(this.files);try{o.mkdirTree(this.cwd)}catch{}return await this.exec(`import sys, os, builtins, _rapti
sys.path.append('/rlib')
os.chdir(${JSON.stringify(this.cwd)})
import _rpi_hw
builtins.input = _rpi_hw.input
`),this.idleT=setInterval(()=>{!this.dead&&!this.busy&&this.gpio.pending()&&this.exec("_rpi_hw._dispatch(0)")},15),this}startRead(e,t){this.flush();let i=(s,r)=>t(s,r);this.pendingRead=i,Promise.resolve(this.readLine(e)).then(s=>{this.pendingRead===i&&(this.pendingRead=null,i(s))})}writeFiles(e){let t=this.mp.FS;for(let[i,s]of Object.entries(e)){let r=i.slice(0,i.lastIndexOf("/"));if(r)try{t.mkdirTree(r)}catch{}try{t.writeFile(i,s)}catch{}}}gone(e){try{return this.mp.FS.stat(e),!1}catch{return!0}}readFiles(e){let t=this.mp.FS,i={},s=r=>{let o=[];try{o=t.readdir(r)}catch{return}for(let l of o){if(l==="."||l==="..")continue;let a=(r==="/"?"":r)+"/"+l,f;try{f=t.stat(a)}catch{continue}if(t.isDir(f.mode))a!=="/rlib"&&a!=="/proc"&&a!=="/dev"&&a!=="/tmp"&&s(a);else try{i[a]=l1.decode(t.readFile(a))}catch{}}};return s(e),i}emit(e,t){e&&(t==="err"?(this.flushOut(),this.errBuf+=e):(this.flushErr(),this.outBuf+=e),this.flushT||(this.flushT=setTimeout(()=>this.flush(),16)))}flushOut(){if(!this.outBuf)return;let e=this.outBuf;this.outBuf="",this.banner&&e.includes("Raspberry Pi with RaptiAuto")&&(e=e.replace(/MicroPython v[\d.]+[^\n]*Raspberry Pi with RaptiAuto/,this.banner)),this.out(e,"out")}flushErr(){if(this.errBuf){let e=this.errBuf;this.errBuf="",this.out(e,"err")}}flush(){clearTimeout(this.flushT),this.flushT=0,this.flushOut(),this.flushErr()}write(e){this.emit(String(e),"out")}exec(e){let t=async()=>{if(this.dead)return;let i=this.M,s=i.lengthBytesUTF8(e),r=i._malloc(s+1);i.stringToUTF8(e,r,s+1);let o=i._malloc(12);this.busy=!0,this.gpio.busy=!0;try{await i.ccall("mp_js_do_exec","null",["pointer","number","pointer"],[r,s,o],{async:!0})}finally{this.busy=!1,this.gpio.busy=!1,this.dead||(i._free(r),i._free(o)),this.flush()}};return this.queue=this.queue.then(t,t),this.queue}async runFile(e){return await this.exec(s1(e)),this.status()}async runSource(e,t="<stdin>"){return await this.exec(n1(e,t)),this.status()}async status(){if(this.dead)return 2;try{return this.mp.pyimport("_rpi_boot").status()}catch{return 1}}async replExec(e){this.repl=!0,await this.exec(r1(e))}interrupt(){if(!this.dead){if(this.pendingRead){let e=this.pendingRead;this.pendingRead=null,this.M._mp_sched_keyboard_interrupt(),e("",!0);return}this.busy&&this.M._mp_sched_keyboard_interrupt()}}async stop(e=1200){this.dead||this.busy&&(this.interrupt(),await Promise.race([this.queue.then(()=>!0,()=>!0),new Promise(i=>setTimeout(()=>i(!1),e))])||this.kill())}kill(){if(!this.dead){if(this.flush(),this.dead=!0,clearInterval(this.idleT),this.M&&(this.M.raptiDead=!0),this.pendingRead){let e=this.pendingRead;this.pendingRead=null,e("",!0)}this.mp=null,this.M=null}}};function ue(n,e="/",t="/home/pi"){if(!n)return e;(n==="~"||n.startsWith("~/"))&&(n=t+n.slice(1)),n.startsWith("/")||(n=(e==="/"?"":e)+"/"+n);let i=[];for(let s of n.split("/"))!s||s==="."||(s===".."?i.pop():i.push(s));return"/"+i.join("/")}var Dt=n=>n.lastIndexOf("/")<=0?"/":n.slice(0,n.lastIndexOf("/")),Te=n=>n.slice(n.lastIndexOf("/")+1),nn=class{constructor(e,t){this.key=e,this.listeners=new Set,this.load(t)}load(e){let t=null;try{t=JSON.parse(localStorage.getItem(this.key)||"null")}catch{t=null}if((!t||!t.files)&&(t={files:{},dirs:[]}),this.files=new Map(Object.entries(t.files)),this.dirs=new Set(t.dirs||[]),this.dirs.add("/"),!t.seeded&&e){for(let i of e.dirs||[])this.mkdir(i,!0,!1);for(let[i,s]of Object.entries(e.files||{}))this.files.has(i)||this.write(i,s,!1);this.seeded=!0,this.save()}else this.seeded=!!t.seeded}save(){let e={};for(let[i,s]of this.files)e[i]=s;let t=!0;if(typeof localStorage<"u")try{localStorage.setItem(this.key,JSON.stringify({files:e,dirs:[...this.dirs],seeded:this.seeded||!1}))}catch{t=!1}this.full=!t;for(let i of this.listeners)i();return t}on(e){return this.listeners.add(e),()=>this.listeners.delete(e)}exists(e){return this.dirs.has(e)||this.files.has(e)}isDir(e){return this.dirs.has(e)}isFile(e){return this.files.has(e)}read(e){let t=this.files.get(e);if(!t)throw new Error(`${e}: No such file or directory`);return t.text}stat(e){if(this.dirs.has(e))return{dir:!0,size:4096,mtime:0};let t=this.files.get(e);return t?{dir:!1,size:new TextEncoder().encode(t.text).length,mtime:t.mtime||0,x:!!t.x}:null}write(e,t,i=!0){if(this.dirs.has(e))throw new Error(`${e}: Is a directory`);let s=Dt(e);this.dirs.has(s)||this.mkdir(s,!0,!1);let r=this.files.get(e);return this.files.set(e,{text:String(t),mtime:Date.now(),x:r?r.x:!1}),i?this.save():!0}chmodX(e,t){let i=this.files.get(e);i&&(i.x=t,this.save())}mkdir(e,t=!1,i=!0){if(this.files.has(e))throw new Error(`cannot create directory '${e}': File exists`);let s=e.split("/").filter(Boolean),r="";for(let o=0;o<s.length;o++)if(r+="/"+s[o],!this.dirs.has(r)){if(!t&&o<s.length-1)throw new Error(`cannot create directory '${e}': No such file or directory`);this.dirs.add(r)}i&&this.save()}list(e){if(!this.dirs.has(e))throw new Error(`cannot access '${e}': No such file or directory`);let t=e==="/"?"/":e+"/",i=new Set;for(let s of this.dirs)s!==e&&s.startsWith(t)&&!s.slice(t.length).includes("/")&&i.add(s.slice(t.length));for(let s of this.files.keys())s.startsWith(t)&&!s.slice(t.length).includes("/")&&i.add(s.slice(t.length));return[...i].sort((s,r)=>s.localeCompare(r))}remove(e,t=!1){if(this.files.has(e)){this.files.delete(e),this.save();return}if(!this.dirs.has(e))throw new Error(`cannot remove '${e}': No such file or directory`);if(e==="/")throw new Error("it is dangerous to operate recursively on '/'");let i=e+"/";if(([...this.files.keys()].some(r=>r.startsWith(i))||[...this.dirs].some(r=>r.startsWith(i)))&&!t)throw new Error(`cannot remove '${e}': Is a directory`);for(let r of[...this.files.keys()])r.startsWith(i)&&this.files.delete(r);for(let r of[...this.dirs])(r===e||r.startsWith(i))&&this.dirs.delete(r);this.save()}copy(e,t){if(this.dirs.has(t)&&(t=(t==="/"?"":t)+"/"+Te(e)),this.files.has(e))return this.write(t,this.files.get(e).text),t;if(!this.dirs.has(e))throw new Error(`cannot stat '${e}': No such file or directory`);let i=e+"/";this.mkdir(t,!0,!1);for(let s of[...this.dirs])s.startsWith(i)&&this.dirs.add(t+s.slice(e.length));for(let[s,r]of[...this.files])s.startsWith(i)&&this.files.set(t+s.slice(e.length),{...r});return this.save(),t}move(e,t){if(this.dirs.has(t)&&(t=(t==="/"?"":t)+"/"+Te(e)),e===t)return t;if(t.startsWith(e+"/"))throw new Error(`cannot move '${e}' to a subdirectory of itself, '${t}'`);return this.copy(e,t),this.remove(e,!0),t}snapshot(e="/"){let t={},i=e==="/"?"/":e+"/";for(let[s,r]of this.files)(s.startsWith(i)||s===e)&&(t[s]=r.text);return t}merge(e,t="/"){let i=!1,s=t==="/"?"/":t+"/";for(let[r,o]of Object.entries(e)){if(!(r.startsWith(s)||r===t))continue;let l=this.files.get(r);(!l||l.text!==o)&&(this.write(r,o,!1),i=!0)}return i&&this.save(),i}};var rn=se($i(),1),lr=se(rr(),1);var a1=se(ii(),1),f1=se(Qi(),1),Mc=se($i(),1);var h1={led:{name:"LED",desc:"LED + 330 \u03A9 resistor to GND",pins:[{key:"a",label:"Anode +"}],props:{color:"red"},ic:"bulb"},rgb:{name:"RGB LED",desc:"Common cathode, 3 resistors",pins:[{key:"r",label:"R"},{key:"g",label:"G"},{key:"b",label:"B"}],props:{},ic:"palette"},button:{name:"Push button",desc:"Between the pin and GND (use the pull-up)",pins:[{key:"a",label:"Pin"}],props:{to:"gnd"},ic:"button"},switch:{name:"Toggle switch",desc:"Latching switch to GND",pins:[{key:"a",label:"Pin"}],props:{to:"gnd"},ic:"sliders"},buzzer:{name:"Buzzer",desc:"Active buzzer (beeps when HIGH; PWM sets the tone)",pins:[{key:"a",label:"+"}],props:{},ic:"bell"},relay:{name:"Relay module",desc:"5 V relay board, IN active HIGH, switches a 230 V lamp",pins:[{key:"a",label:"IN"}],props:{},ic:"plug"},servo:{name:"Servo SG90",desc:"50 Hz PWM, 0.5\u20132.5 ms = 0\u2013180\xB0",pins:[{key:"sig",label:"Signal"}],props:{},ic:"rotate"},motor:{name:"DC motor (L298N)",desc:"IN1 = forward, IN2 = backward, PWM = speed",pins:[{key:"fwd",label:"IN1"},{key:"back",label:"IN2"}],props:{},ic:"motor"},pir:{name:"PIR motion sensor",desc:"HC-SR501, OUT goes HIGH for 3 s",pins:[{key:"out",label:"OUT"}],props:{},ic:"sensor"},ultrasonic:{name:"HC-SR04 ultrasonic",desc:"2\u2013400 cm, echo via voltage divider",pins:[{key:"trig",label:"TRIG"},{key:"echo",label:"ECHO"}],props:{cm:50},ic:"activity"},pot:{name:"Potentiometer",desc:"10 k\u03A9; Pico: on an ADC pin \xB7 Pi: MCP3008 channel",pins:[{key:"a",label:"Wiper",adc:!0}],props:{value:.5,ch:0},ic:"gauge"},ldr:{name:"Light sensor (LDR)",desc:"Pico: analog on an ADC pin \xB7 Pi: module DO pin",pins:[{key:"a",label:"OUT",adc:!0}],props:{light:.6,ch:1},ic:"sun"},dht:{name:"DHT22 sensor",desc:"Temperature and humidity, one data pin",pins:[{key:"data",label:"DATA"}],props:{t:28,h:60},ic:"thermometer"},neopixel:{name:"NeoPixel strip \xD78",desc:"WS2812B, data in",pins:[{key:"din",label:"DIN"}],props:{n:8},ic:"sparkles"}};var c1=0;function _i(n,e,t={}){let i=h1[n];return{id:"p"+Date.now().toString(36)+c1++,type:n,pins:{...e},props:{...i.props,...t},state:{}}}var qc=se(Dc(),1),Ic=()=>({dirs:["/home/pi/Desktop","/home/pi/Documents","/home/pi/Downloads","/home/pi/Music","/home/pi/Pictures","/home/pi/Videos","/home/pi/Public","/home/pi/Templates","/home/pi/projects","/etc","/boot/firmware","/tmp","/usr/bin","/var/log"],files:{...Object.fromEntries(lr.PI_EXAMPLES.map(n=>["/home/pi/"+n.file,n.code])),"/home/pi/Documents/notes.txt":`Raspberry Pi notes
==================
- GPIO pins are 3.3 V. Never connect 5 V to a GPIO!
- Use a resistor (220\u2013330 \u03A9) with every LED.
- Run "pinout" in the terminal to see the header.
`,"/home/pi/.bashrc":`# ~/.bashrc: executed by bash(1) for non-login shells.
alias ll='ls -l'
export PATH="$HOME/.local/bin:$PATH"
`,"/etc/os-release":`PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"
NAME="Debian GNU/Linux"
VERSION_ID="12"
VERSION="12 (bookworm)"
VERSION_CODENAME=bookworm
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
`,"/etc/hostname":`raspberrypi
`,"/boot/firmware/config.txt":`# For more options and information see
# http://rptl.io/configtxt

# Uncomment some or all of these to enable the optional hardware interfaces
#dtparam=i2c_arm=on
#dtparam=i2s=on
#dtparam=spi=on

# Enable audio (loads snd_bcm2835)
dtparam=audio=on

# Automatically load overlays for detected cameras
camera_auto_detect=1

# Automatically load overlays for detected DSI displays
display_auto_detect=1

# Enable DRM VC4 V3D driver
dtoverlay=vc4-kms-v3d
max_framebuffers=2

arm_64bit=1
arm_boost=1

[all]
`}}),Lc=()=>({dirs:["/lib"],files:Object.fromEntries(lr.PICO_EXAMPLES.filter(n=>!n.boards).map(n=>["/"+n.file,n.code]))}),or=class{constructor(e,t){this.libs=t,this.listeners=new Set,this.outTaps=new Set,this.proc=null,this.owner=null,this.gpio=new Qc.GpioSim(e),this.net=new qc.VirtualNet,this.piFs=new nn("rapti.pi.fs.v1",Ic()),this.picoFs=new nn("rapti.pico.fs.v1",Lc()),this.setBoard(e,!0)}get board(){return this.gpio.board}get info(){return rn.BOARDS[this.board]}get isPico(){return this.gpio.isPico}get fs(){return this.isPico?this.picoFs:this.piFs}get home(){return this.isPico?"/":"/home/pi"}on(e){return this.listeners.add(e),()=>this.listeners.delete(e)}onOut(e){return this.outTaps.add(e),()=>this.outTaps.delete(e)}emit(e){for(let t of this.listeners)try{t(e,this)}catch(i){console.error(i)}}setBoard(e,t=!1){t||this.killProcess(),this.gpio.setBoard(e),this.initNet(e),this.gpio.parts=this.loadParts(e),this.gpio.inputsChanged();try{localStorage.setItem("rapti.pi.board",e)}catch{}t||this.emit("board")}initNet(e){let t=rn.BOARDS[e],i=t.kind==="pi";this.netDev&&(this.net.dropServers(this.netDev),this.net.mqtt.dropDevice(this.netDev),this.net.leave(this.netDev),this.net.devices.delete(this.netDev.id)),this.netDev=this.net.registerDevice({id:"pi",name:i?"Raspberry Pi":t.name,kind:i?"pi":"pico",hostname:i?"raspberrypi":"picow",broker:i});let s=i||t.wifi;this.gpio.net=s?this.net:null,this.gpio.netDev=s?this.netDev:null,i&&this.net.join(this.netDev,"RaptiNet","rapti1234")}partsKey(e=this.board){return"rapti.pi.parts."+(rn.BOARDS[e].kind==="pico"?"pico":"pi")}loadParts(e){try{let t=JSON.parse(localStorage.getItem(this.partsKey(e))||"null");if(Array.isArray(t))return t.map(i=>({...i,state:{}}))}catch{}return rn.BOARDS[e].kind==="pico"?[_i("led",{a:15},{color:"red"}),_i("button",{a:14}),_i("pot",{a:26})]:[_i("led",{a:17},{color:"red"}),_i("led",{a:27},{color:"green"}),_i("button",{a:2}),_i("buzzer",{a:22})]}resetFs(){this.killProcess();let e=this.fs;try{localStorage.removeItem(e.key)}catch{}e.load(this.isPico?Lc():Ic()),this.emit("files")}get running(){return!!(this.proc&&!this.proc.dead&&this.proc.busy)}async spawn(e){this.killProcess();let t=new nr({gpio:this.gpio,libs:this.libs,files:this.fs.snapshot(this.isPico?"/":"/home/pi"),cwd:e.cwd||this.home,banner:e.banner,readLine:e.readLine,out:(i,s)=>{e.out&&e.out(i,s);for(let r of this.outTaps)r(i,s)}});return this.proc=t,this.owner=e.owner||null,await t.start(),this.emit("proc"),this.emit("start"),t}syncBack(e=this.proc){if(!e||e.dead||!e.mp)return;let t=this.isPico?"/":"/home/pi";try{let i=e.readFiles(t),s=e.files||{},r={};for(let[a,f]of Object.entries(i))s[a]!==f&&(r[a]=f);let o=!1;for(let a of Object.keys(s))a in i||!e.gone(a)||this.fs.isFile(a)&&this.fs.read(a)===s[a]&&(this.fs.files.delete(a),o=!0);let l=this.fs.merge(r,t);if(!l&&o&&this.fs.save(),(l||o)&&this.fs.full){let a=Object.keys(r).map(f=>f.slice(f.lastIndexOf("/")+1)).join(", ");e.out(`
Storage is full: ${a?"the files the program wrote ("+a+")":"the program's file changes"} could not be saved permanently.
`,"err")}e.files=i}catch{}}killProcess(){let e=this.proc;e&&(this.syncBack(e),e.kill(),this.proc=null,this.owner=null,this.netDev&&(this.net.dropServers(this.netDev),this.net.mqtt.dropDevice(this.netDev)),this.gpio.stopProcess(),this.isPico&&this.gpio.reset(),this.emit("proc"))}async stop(){let e=this.proc;e&&(await e.stop(),this.emit("proc"))}};var Bc=`# RaptiAuto virtual hardware core: callbacks (edges, timers) and pin bookkeeping.
# The simulated GPIO lives in JavaScript (module _rpi_js); this file runs callbacks
# that JavaScript queues while Python sleeps or loops.
import _rpi_js as J
import _rapti
from utime import sleep_ms as _sleep_ms

_cbs = {}
_next = [1]


def register(cb):
    i = _next[0]
    _next[0] += 1
    _cbs[i] = cb
    return i


def unregister(i):
    if i in _cbs:
        del _cbs[i]


def call(cb, *args):
    # gpiozero style: call with no argument, or with the device if the function wants one
    try:
        return cb()
    except TypeError as e:
        # only the call itself had the wrong arity (an error inside the callback is shown as it is)
        m = str(e)
        if args and ('but 0 were given' in m or 'required positional argument' in m):
            return cb(*args)
        raise


def _dispatch(_):
    while True:
        cid = J.next_event()
        if not cid:
            break
        cb = _cbs.get(cid)
        if cb is not None:
            cb(J.event_arg())


_rapti.set_dispatch(_dispatch)


def board():
    return J.board()


def every(ms, fn):
    """Call fn() every ms milliseconds (in the background). Returns a handle for stop()."""
    cid = register(lambda _: fn())
    return (J.timer(cid, ms, 1), cid)


def stop(handle):
    if handle:
        J.timer_stop(handle[0])
        unregister(handle[1])


def input(prompt=''):
    # builtins.input: the terminal / Thonny shell reads the line in the background while this
    # loop sleeps, so callbacks (when_pressed, timers, IRQs) keep running during input();
    # Ctrl+C raises KeyboardInterrupt in the sleep
    J.read_start(str(prompt))
    while not J.read_ready():
        _sleep_ms(10)
    return J.read_line()
`;var $c=`# time: MicroPython's built-in time plus the CPython functions Raspberry Pi scripts often use.
from utime import *
import utime as _t

_MON = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')
_MONL = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
_DAY = ('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')
_DAYL = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')


try:
    from _rapti import ticks_us as _us  # 64-bit: does not wrap like ticks_us (2**30 us = 17.9 min)
except Exception:
    _us = _t.ticks_us


def perf_counter():
    return _us() / 1000000


def monotonic():
    return _t.ticks_ms() / 1000


def process_time():
    return _t.ticks_ms() / 1000


def perf_counter_ns():
    return _us() * 1000


def monotonic_ns():
    return _t.ticks_ms() * 1000000


# Local time everywhere (like CPython on a Pi): time() is UTC seconds; localtime(), localtime(secs),
# ctime(), mktime() and datetime (which calls these) all use the phone's time zone. On a Pico the
# RTC starts at local time (as Thonny sets it); machine.RTC().datetime(...) / ntptime.settime()
# move it, e.g. to UTC.
_rtc = [None]   # Pico RTC offset from UTC in seconds, once a program set the RTC


def _off(secs):
    if _rtc[0] is not None:
        return _rtc[0]
    try:
        import _rpi_js
        return int(_rpi_js.tz_offset(secs))
    except Exception:
        return 0


def _secs(secs):
    s = _t.time() if secs is None else secs
    return int(s // 1)


def _days(y, m, d):
    # days since 1970-01-01 of a proleptic Gregorian date (any year; utime stops at 1970..2106)
    y += (m - 1) // 12
    m = (m - 1) % 12 + 1
    y -= m <= 2
    era = y // 400
    yoe = y - era * 400
    doy = (153 * (m + (-3 if m > 2 else 9)) + 2) // 5 + d - 1
    return era * 146097 + yoe * 365 + yoe // 4 - yoe // 100 + doy - 719468


def _gm(s):
    z, r = divmod(s, 86400)
    days = z
    z += 719468
    era = z // 146097
    doe = z - era * 146097
    yoe = (doe - doe // 1460 + doe // 36524 - doe // 146096) // 365
    doy = doe - (365 * yoe + yoe // 4 - yoe // 100)
    mp = (5 * doy + 2) // 153
    d = doy - (153 * mp + 2) // 5 + 1
    m = mp + (3 if mp < 10 else -9)
    y = yoe + era * 400 + (m <= 2)
    return (y, m, d, r // 3600, r % 3600 // 60, r % 60, (days + 3) % 7, days - _days(y, 1, 1) + 1)


def _mk(t):
    return _days(t[0], t[1], t[2]) * 86400 + t[3] * 3600 + t[4] * 60 + t[5]


def localtime(secs=None):
    s = _secs(secs)
    return _gm(s + _off(s))


def gmtime(secs=None):
    return _gm(_secs(secs))


def mktime(t):
    u = _mk(t)   # the tuple read as UTC
    return u - _off(u - _off(u))


def _set_rtc(t):
    # machine.RTC().datetime(...): the RTC now shows this local time
    _rtc[0] = _mk((t[0], t[1], t[2], t[3], t[4], t[5], 0, 0)) - int(_t.time())


def _tm(t):
    if t is None or isinstance(t, (int, float)):
        return localtime(t)
    return t


try:
    timezone = -_off(int(_t.time()))
    altzone = timezone
except Exception:
    timezone = altzone = 0


def strftime(fmt, t=None):
    t = _tm(t)
    y, mo, d, hh, mm, ss, wd, yd = t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7]
    rep = {
        'Y': '%04d' % y, 'y': '%02d' % (y % 100), 'm': '%02d' % mo, 'd': '%02d' % d, 'e': '%2d' % d,
        'H': '%02d' % hh, 'I': '%02d' % ((hh % 12) or 12), 'M': '%02d' % mm, 'S': '%02d' % ss,
        'p': 'AM' if hh < 12 else 'PM', 'b': _MON[mo - 1], 'B': _MONL[mo - 1], 'a': _DAY[wd], 'A': _DAYL[wd],
        'j': '%03d' % yd, 'w': str((wd + 1) % 7), '%': '%',
    }
    rep['c'] = '%s %s %s %s:%s:%s %s' % (rep['a'], rep['b'], rep['e'], rep['H'], rep['M'], rep['S'], rep['Y'])
    rep['x'] = '%s/%s/%s' % (rep['m'], rep['d'], rep['y'])
    rep['X'] = '%s:%s:%s' % (rep['H'], rep['M'], rep['S'])
    rep['T'] = rep['X']
    rep['D'] = rep['x']
    out = []
    i = 0
    while i < len(fmt):
        c = fmt[i]
        if c == '%' and i + 1 < len(fmt):
            out.append(rep.get(fmt[i + 1], '%' + fmt[i + 1]))
            i += 2
        else:
            out.append(c)
            i += 1
    return ''.join(out)


def asctime(t=None):
    return strftime('%a %b %e %H:%M:%S %Y', t)


def ctime(secs=None):
    return asctime(_tm(secs))


struct_time = tuple
`;var Fc=`# random: MicroPython's built-in random plus shuffle / sample.
from urandom import *
import urandom as _r


def shuffle(x):
    for i in range(len(x) - 1, 0, -1):
        j = _r.randrange(i + 1)
        x[i], x[j] = x[j], x[i]


def sample(population, k):
    pool = list(population)
    if k > len(pool):
        raise ValueError('Sample larger than population or is negative')
    shuffle(pool)
    return pool[:k]


def choices(population, weights=None, k=1):
    pool = list(population)
    if not weights:
        return [_r.choice(pool) for _ in range(k)]
    total = sum(weights)
    out = []
    for _ in range(k):
        r = _r.random() * total
        acc = 0
        for p, w in zip(pool, weights):
            acc += w
            if r < acc:
                out.append(p)
                break
        else:
            out.append(pool[-1])
    return out
`;var Wc=`# signal.pause() keeps a gpiozero script alive while callbacks and blinking run.
import time

SIGINT = 2
SIGTERM = 15


def pause():
    while True:
        time.sleep(1)


def signal(sig, handler):
    return None
`;var zc="";var jc=`# RPi.GPIO for the RaptiAuto virtual Raspberry Pi (same API as RPi.GPIO 0.7).
import _rpi_js as J
import _rpi_hw as H
import time as _time

BOARD = 10
BCM = 11
OUT = 0
IN = 1
LOW = 0
HIGH = 1
PUD_OFF = 20
PUD_DOWN = 21
PUD_UP = 22
RISING = 31
FALLING = 32
BOTH = 33
SERIAL = 40
SPI = 41
I2C = 42
HARD_PWM = 43
UNKNOWN = -1
VERSION = '0.7.1'
RPI_REVISION = 3
RPI_INFO = {'P1_REVISION': 3, 'RAM': '8G', 'REVISION': 'd04170', 'TYPE': 'Pi 5 Model B', 'PROCESSOR': 'BCM2712', 'MANUFACTURER': 'Raspberry Pi Ltd'}

_BOARD = {3: 2, 5: 3, 7: 4, 8: 14, 10: 15, 11: 17, 12: 18, 13: 27, 15: 22, 16: 23, 18: 24, 19: 10, 21: 9, 22: 25,
          23: 11, 24: 8, 26: 7, 27: 0, 28: 1, 29: 5, 31: 6, 32: 12, 33: 13, 35: 19, 36: 16, 37: 26, 38: 20, 40: 21}
_mode = None
_warn = True
_setup = {}     # bcm -> IN / OUT
_events = {}    # bcm -> [callback ids]
_pwm = {}

if J.board() == 'pi4':
    RPI_INFO = {'P1_REVISION': 3, 'RAM': '4G', 'REVISION': 'c03115', 'TYPE': 'Pi 4 Model B', 'PROCESSOR': 'BCM2711', 'MANUFACTURER': 'Sony'}


def _warning(msg):
    if _warn:
        print('<stdin>: RuntimeWarning: ' + msg)


def setwarnings(flag):
    global _warn
    _warn = bool(flag)


def setmode(mode):
    global _mode
    if mode not in (BOARD, BCM):
        raise ValueError('An invalid mode was passed to setmode()')
    if _mode is not None and mode != _mode:
        raise ValueError('A different mode has already been set!')
    _mode = mode


def getmode():
    return _mode


def _bcm(channel):
    if _mode is None:
        raise RuntimeError('Please set pin numbering mode using GPIO.setmode(GPIO.BOARD) or GPIO.setmode(GPIO.BCM)')
    if not isinstance(channel, int):
        raise ValueError('Channel must be an integer or list/tuple of integers')
    if _mode == BOARD:
        if channel not in _BOARD:
            raise ValueError('The channel sent is invalid on a Raspberry Pi')
        return _BOARD[channel]
    if channel < 0 or channel > 27:
        raise ValueError('The channel sent is invalid on a Raspberry Pi')
    return channel


def _each(channel):
    if isinstance(channel, (list, tuple)):
        return list(channel)
    return [channel]


def setup(channel, direction, pull_up_down=PUD_OFF, initial=-1):
    for ch in _each(channel):
        b = _bcm(ch)
        if direction not in (IN, OUT):
            raise ValueError('An invalid direction was passed to setup()')
        if b in _setup or J.in_use(b):
            _warning('This channel is already in use, continuing anyway.  Use GPIO.setwarnings(False) to disable warnings.')
        if direction == OUT:
            if pull_up_down != PUD_OFF:
                raise ValueError('pull_up_down parameter is not valid for outputs')
            # the level is latched before the pin becomes an output: initial=HIGH never glitches LOW
            if initial != -1:
                J.write(b, 1 if initial else 0)
            J.setup(b, 'out', 'none')
        else:
            if initial != -1:
                raise ValueError('initial parameter is not valid for inputs')
            pull = 'up' if pull_up_down == PUD_UP else ('down' if pull_up_down == PUD_DOWN else 'none')
            J.setup(b, 'in', pull)
        _setup[b] = direction


def output(channel, value):
    chans = _each(channel)
    vals = _each(value)
    if len(vals) == 1:
        vals = vals * len(chans)
    if len(vals) != len(chans):
        raise RuntimeError('Number of channels != number of values')
    for ch, v in zip(chans, vals):
        b = _bcm(ch)
        if _setup.get(b) != OUT:
            raise RuntimeError('The GPIO channel has not been set up as an OUTPUT')
        J.write(b, 1 if v else 0)


def input(channel):
    b = _bcm(channel)
    if b not in _setup:
        raise RuntimeError('You must setup() the GPIO channel first')
    return J.read(b)


def gpio_function(channel):
    b = _bcm(channel)
    return _setup.get(b, IN)


def cleanup(channel=None):
    global _mode
    chans = list(_setup.keys()) if channel is None else [_bcm(c) for c in _each(channel)]
    for b in chans:
        remove_event_detect_bcm(b)
        if b in _pwm:
            _pwm[b].stop()
        J.release(b)
        if b in _setup:
            del _setup[b]
    if channel is None:
        _mode = None


def _edge(edge):
    if edge == RISING:
        return 'rising'
    if edge == FALLING:
        return 'falling'
    if edge == BOTH:
        return 'both'
    raise ValueError('The edge must be set to RISING, FALLING or BOTH')


def add_event_detect(channel, edge, callback=None, bouncetime=None):
    b = _bcm(channel)
    if _setup.get(b) != IN:
        raise RuntimeError('You must setup() the GPIO channel as an input first')
    if b in _events:
        raise RuntimeError('Conflicting edge detection already enabled for this GPIO channel')
    _events[b] = []
    J.watch(b, _edge(edge), int(bouncetime or 0))
    if callback is not None:
        add_event_callback(channel, callback)


def add_event_callback(channel, callback):
    b = _bcm(channel)
    if b not in _events:
        raise RuntimeError('Add event detection using add_event_detect first before adding a callback')
    cid = H.register(lambda _arg, ch=channel, cb=callback: cb(ch))
    _events[b].append(cid)
    J.watch_cb(b, cid)


def remove_event_detect_bcm(b):
    if b in _events:
        for cid in _events[b]:
            H.unregister(cid)
        del _events[b]
        J.unwatch(b)


def remove_event_detect(channel):
    remove_event_detect_bcm(_bcm(channel))


def event_detected(channel):
    return bool(J.detected(_bcm(channel)))


def wait_for_edge(channel, edge, bouncetime=None, timeout=None):
    b = _bcm(channel)
    if _setup.get(b) != IN:
        raise RuntimeError('You must setup() the GPIO channel as an input first')
    e = _edge(edge)
    t0 = _time.ticks_ms()
    last = J.read(b)
    while True:
        v = J.read(b)
        if v != last:
            if e == 'both' or (e == 'rising' and v) or (e == 'falling' and not v):
                if bouncetime:
                    _time.sleep_ms(int(bouncetime))
                return channel
            last = v
        if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout:
            return None
        _time.sleep_ms(1)


class PWM:
    def __init__(self, channel, frequency):
        b = _bcm(channel)
        if _setup.get(b) != OUT:
            raise RuntimeError('You must setup() the GPIO channel as an output first')
        if b in _pwm:
            raise RuntimeError('A PWM object already exists for this GPIO channel')
        if frequency <= 0:
            raise ValueError('frequency must be greater than 0.0')
        self._b = b
        self._f = float(frequency)
        self._dc = 0.0
        self._on = False
        _pwm[b] = self

    def start(self, dutycycle):
        if not 0 <= dutycycle <= 100:
            raise ValueError('dutycycle must have a value from 0.0 to 100.0')
        self._dc = float(dutycycle)
        self._on = True
        J.pwm(self._b, self._f, self._dc / 100)

    def ChangeDutyCycle(self, dutycycle):
        if not 0 <= dutycycle <= 100:
            raise ValueError('dutycycle must have a value from 0.0 to 100.0')
        self._dc = float(dutycycle)
        if self._on:
            J.pwm(self._b, self._f, self._dc / 100)

    def ChangeFrequency(self, frequency):
        if frequency <= 0:
            raise ValueError('frequency must be greater than 0.0')
        self._f = float(frequency)
        if self._on:
            J.pwm(self._b, self._f, self._dc / 100)

    def stop(self):
        if self._on:
            J.pwm_off(self._b)
        self._on = False
        if _pwm.get(self._b) is self:
            del _pwm[self._b]
`;var Vc=`# gpiozero for the RaptiAuto virtual Raspberry Pi: the commonly used devices with the
# same names and behaviour as gpiozero 2.0 (pins are BCM numbers, "GPIO17", "BOARD11" ...).
import _rpi_js as J
import _rpi_hw as H
import time as _time

__version__ = '2.0.1'

_BOARD = {3: 2, 5: 3, 7: 4, 8: 14, 10: 15, 11: 17, 12: 18, 13: 27, 15: 22, 16: 23, 18: 24, 19: 10, 21: 9, 22: 25,
          23: 11, 24: 8, 26: 7, 27: 0, 28: 1, 29: 5, 31: 6, 32: 12, 33: 13, 35: 19, 36: 16, 37: 26, 38: 20, 40: 21}
_used = {}


class GPIOZeroError(Exception):
    pass


class DeviceClosed(GPIOZeroError):
    pass


class BadPinFactory(GPIOZeroError):
    pass


class PinInvalidPin(GPIOZeroError):
    pass


class GPIOPinInUse(GPIOZeroError):
    pass


class PinFixedPull(GPIOZeroError):
    pass


def _pin(p):
    if isinstance(p, str):
        s = p.upper().strip()
        for pre in ('GPIO', 'BCM'):
            if s.startswith(pre):
                s = s[len(pre):]
                break
        else:
            for pre in ('BOARD', 'J8:', 'P1:'):
                if s.startswith(pre):
                    n = int(s[len(pre):])
                    if n not in _BOARD:
                        raise PinInvalidPin('%s is not a valid pin' % p)
                    return _BOARD[n]
        try:
            p = int(s)
        except ValueError:
            raise PinInvalidPin('%s is not a valid pin name' % p)
    if not isinstance(p, int) or p < 0 or p > 27:
        raise PinInvalidPin('%r is not a valid pin' % (p,))
    return p


class Device:
    def __init__(self):
        self._closed = False
        self._pins = []
        self._handles = []

    def _claim(self, *pins):
        out = []
        for p in pins:
            b = _pin(p)
            if b in _used and _used[b] is not self:
                raise GPIOPinInUse('pin GPIO%d is already in use by %r' % (b, _used[b]))
            _used[b] = self
            J.claim(b, 'zero')
            self._pins.append(b)
            out.append(b)
        return out[0] if len(out) == 1 else out

    def _check(self):
        if self._closed:
            raise DeviceClosed('%s is closed or uninitialized' % self.__class__.__name__)

    def close(self):
        if self._closed:
            return
        for hdl in self._handles:
            H.stop(hdl)
        self._handles = []
        for b in self._pins:
            J.release(b)
            if _used.get(b) is self:
                del _used[b]
        self._closed = True

    @property
    def closed(self):
        return self._closed

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def __repr__(self):
        if self._closed:
            return '<gpiozero.%s object closed>' % self.__class__.__name__
        pins = ', '.join('GPIO%d' % b for b in self._pins)
        return '<gpiozero.%s object on pin %s, is_active=%s>' % (self.__class__.__name__, pins, getattr(self, 'is_active', '?'))

    # gpiozero "source" / "values": led.source = button
    @property
    def values(self):
        def gen():
            while True:
                yield self.value
        return gen()

    @property
    def source(self):
        return getattr(self, '_source', None)

    @source.setter
    def source(self, src):
        hdl = getattr(self, '_src_handle', None)
        if hdl:
            H.stop(hdl)
            if hdl in self._handles:
                self._handles.remove(hdl)
        self._source = src
        self._src_handle = None
        if src is None:
            return
        it = None if hasattr(src, 'value') else iter(src)

        def tick():
            try:
                self.value = src.value if it is None else next(it)
            except StopIteration:
                H.stop(self._src_handle)

        self._src_handle = H.every(10, tick)
        self._handles.append(self._src_handle)


# ------------------------------------------------------------------ outputs
class OutputDevice(Device):
    def __init__(self, pin=None, active_high=True, initial_value=False, pin_factory=None):
        super().__init__()
        if pin is None:
            raise GPIOZeroError('No pin given')
        self.pin = self._claim(pin)
        self.active_high = active_high
        J.setup(self.pin, 'out', 'none')
        self._v = 0
        if initial_value is not None:
            self._write(1 if initial_value else 0)

    def _write(self, v):
        self._check()
        self._v = v
        J.stop_bg(self.pin)
        J.write(self.pin, v if self.active_high else 1 - v)

    def on(self):
        self._write(1)

    def off(self):
        self._write(0)

    def toggle(self):
        self._write(0 if self.value else 1)

    @property
    def value(self):
        lvl = J.level(self.pin)
        return lvl if self.active_high else 1 - lvl

    @value.setter
    def value(self, v):
        self._write(1 if v else 0)

    @property
    def is_active(self):
        return bool(self.value)


class DigitalOutputDevice(OutputDevice):
    def blink(self, on_time=1, off_time=1, n=None, background=True):
        self._check()
        on = 1 if self.active_high else 0
        J.blink(self.pin, float(on_time), float(off_time), int(n or 0), on, 1 - on, 0.0, 0.0)
        if not background:
            if n is None:
                while True:
                    _time.sleep(1)
            _time.sleep((on_time + off_time) * n)


class LED(DigitalOutputDevice):
    @property
    def is_lit(self):
        return self.is_active


class Buzzer(DigitalOutputDevice):
    def beep(self, on_time=1, off_time=1, n=None, background=True):
        self.blink(on_time, off_time, n, background)


class PWMOutputDevice(OutputDevice):
    def __init__(self, pin=None, active_high=True, initial_value=0, frequency=100, pin_factory=None):
        self._freq = float(frequency)
        self._d = 0.0
        super().__init__(pin, active_high, None)
        self.value = initial_value

    def _write(self, v):
        self._set(float(v))

    def _set(self, v):
        self._check()
        if not 0 <= v <= 1:
            raise ValueError('PWM value must be between 0 and 1')
        self._d = v
        J.stop_bg(self.pin)
        J.pwm(self.pin, self._freq, v if self.active_high else 1 - v)

    @property
    def value(self):
        d = J.duty(self.pin)
        return d if self.active_high else 1 - d

    @value.setter
    def value(self, v):
        self._set(float(v))

    def on(self):
        self._set(1.0)

    def off(self):
        self._set(0.0)

    def toggle(self):
        self._set(1 - self.value)

    @property
    def frequency(self):
        return self._freq

    @frequency.setter
    def frequency(self, f):
        self._freq = float(f)
        self._set(self._d)

    @property
    def is_active(self):
        return self.value > 0

    def blink(self, on_time=1, off_time=1, fade_in_time=0, fade_out_time=0, n=None, background=True):
        self._check()
        on, off = (1.0, 0.0) if self.active_high else (0.0, 1.0)
        J.pwm(self.pin, self._freq, off)
        J.blink(self.pin, float(on_time), float(off_time), int(n or 0), on, off, float(fade_in_time), float(fade_out_time))
        if not background:
            if n is None:
                while True:
                    _time.sleep(1)
            _time.sleep((on_time + off_time + fade_in_time + fade_out_time) * n)

    def pulse(self, fade_in_time=1, fade_out_time=1, n=None, background=True):
        self.blink(0, 0, fade_in_time, fade_out_time, n, background)


class PWMLED(PWMOutputDevice):
    @property
    def is_lit(self):
        return self.is_active


class TonalBuzzer(Device):
    def __init__(self, pin=None, initial_value=None, mid_tone=None, octaves=1, pin_factory=None):
        super().__init__()
        from gpiozero.tones import Tone
        self.pin = self._claim(pin)
        self.mid_tone = Tone('A4') if mid_tone is None else (mid_tone if isinstance(mid_tone, Tone) else Tone(mid_tone))
        self.octaves = octaves
        self._tone = None
        J.setup(self.pin, 'out', 'none')
        if initial_value is not None:
            self.play(initial_value)

    @property
    def min_tone(self):
        return self.mid_tone.down(12 * self.octaves)

    @property
    def max_tone(self):
        return self.mid_tone.up(12 * self.octaves)

    def play(self, tone):
        # tone: a Tone, a note name ('A4', 'C#5'), a MIDI note number (< 128) or a frequency in Hz
        from gpiozero.tones import Tone
        self._check()
        if tone is None:
            self.stop()
            return
        t = tone if isinstance(tone, Tone) else Tone(tone)
        self._tone = t
        J.pwm(self.pin, t.frequency, 0.5)

    def stop(self):
        self._tone = None
        J.pwm_off(self.pin)

    @property
    def tone(self):
        return self._tone

    @tone.setter
    def tone(self, t):
        self.play(t)

    @property
    def is_active(self):
        return J.duty(self.pin) > 0


class RGBLED(Device):
    def __init__(self, red=None, green=None, blue=None, active_high=True, initial_value=(0, 0, 0), pwm=True, pin_factory=None):
        super().__init__()
        self._leds = [PWMLED(p, active_high) if pwm else LED(p, active_high) for p in (red, green, blue)]
        self.red_led, self.green_led, self.blue_led = self._leds
        self._pins = []
        self.color = initial_value

    def close(self):
        for led in self._leds:
            led.close()
        self._closed = True

    @property
    def value(self):
        return tuple(led.value for led in self._leds)

    @value.setter
    def value(self, v):
        for led, x in zip(self._leds, v):
            led.value = x

    color = value

    @property
    def red(self):
        return self._leds[0].value

    @red.setter
    def red(self, v):
        self._leds[0].value = v

    @property
    def green(self):
        return self._leds[1].value

    @green.setter
    def green(self, v):
        self._leds[1].value = v

    @property
    def blue(self):
        return self._leds[2].value

    @blue.setter
    def blue(self, v):
        self._leds[2].value = v

    @property
    def is_active(self):
        return self.value != (0, 0, 0)

    is_lit = is_active

    def on(self):
        self.value = (1, 1, 1)

    def off(self):
        self.value = (0, 0, 0)

    def toggle(self):
        self.value = tuple(1 - x for x in self.value)

    def blink(self, on_time=1, off_time=1, fade_in_time=0, fade_out_time=0, on_color=(1, 1, 1), off_color=(0, 0, 0), n=None, background=True):
        for led, a, b in zip(self._leds, on_color, off_color):
            J.pwm(led.pin, 100.0, float(b))
            J.blink(led.pin, float(on_time), float(off_time), int(n or 0), float(a), float(b), float(fade_in_time), float(fade_out_time))
        if not background and n:
            _time.sleep((on_time + off_time + fade_in_time + fade_out_time) * n)

    def pulse(self, fade_in_time=1, fade_out_time=1, on_color=(1, 1, 1), off_color=(0, 0, 0), n=None, background=True):
        self.blink(0, 0, fade_in_time, fade_out_time, on_color, off_color, n, background)


class Motor(Device):
    def __init__(self, forward=None, backward=None, enable=None, pwm=True, pin_factory=None):
        super().__init__()
        self.forward_device = PWMOutputDevice(forward) if pwm else DigitalOutputDevice(forward)
        self.backward_device = PWMOutputDevice(backward) if pwm else DigitalOutputDevice(backward)
        self.enable_device = DigitalOutputDevice(enable, initial_value=True) if enable is not None else None

    def close(self):
        for d in (self.forward_device, self.backward_device, self.enable_device):
            if d:
                d.close()
        self._closed = True

    @property
    def value(self):
        return self.forward_device.value - self.backward_device.value

    @value.setter
    def value(self, v):
        if v > 0:
            self.forward(v)
        elif v < 0:
            self.backward(-v)
        else:
            self.stop()

    @property
    def is_active(self):
        return self.value != 0

    def forward(self, speed=1):
        self.backward_device.off()
        self.forward_device.value = speed

    def backward(self, speed=1):
        self.forward_device.off()
        self.backward_device.value = speed

    def reverse(self):
        self.value = -self.value

    def stop(self):
        self.forward_device.off()
        self.backward_device.off()


class PhaseEnableMotor(Device):
    def __init__(self, phase=None, enable=None, pwm=True, pin_factory=None):
        super().__init__()
        self.phase_device = DigitalOutputDevice(phase)
        self.enable_device = PWMOutputDevice(enable) if pwm else DigitalOutputDevice(enable)

    def forward(self, speed=1):
        self.phase_device.off()
        self.enable_device.value = speed

    def backward(self, speed=1):
        self.phase_device.on()
        self.enable_device.value = speed

    def stop(self):
        self.enable_device.off()

    @property
    def value(self):
        return -self.enable_device.value if self.phase_device.value else self.enable_device.value

    @value.setter
    def value(self, v):
        if v >= 0:
            self.forward(v)
        else:
            self.backward(-v)


class Robot(Device):
    def __init__(self, left=None, right=None, pwm=True, pin_factory=None):
        super().__init__()
        self.left_motor = Motor(*left, pwm=pwm)
        self.right_motor = Motor(*right, pwm=pwm)

    def forward(self, speed=1, curve_left=0, curve_right=0):
        self.left_motor.forward(speed * (1 - curve_left))
        self.right_motor.forward(speed * (1 - curve_right))

    def backward(self, speed=1, curve_left=0, curve_right=0):
        self.left_motor.backward(speed * (1 - curve_left))
        self.right_motor.backward(speed * (1 - curve_right))

    def left(self, speed=1):
        self.right_motor.forward(speed)
        self.left_motor.backward(speed)

    def right(self, speed=1):
        self.left_motor.forward(speed)
        self.right_motor.backward(speed)

    def stop(self):
        self.left_motor.stop()
        self.right_motor.stop()

    @property
    def value(self):
        return (self.left_motor.value, self.right_motor.value)


class Servo(Device):
    def __init__(self, pin=None, initial_value=0, min_pulse_width=1 / 1000, max_pulse_width=2 / 1000, frame_width=20 / 1000, pin_factory=None):
        super().__init__()
        self.pin = self._claim(pin)
        self.min_pulse_width = min_pulse_width
        self.max_pulse_width = max_pulse_width
        self.frame_width = frame_width
        J.setup(self.pin, 'out', 'none')
        self._value = None
        self.value = initial_value

    @property
    def pulse_width(self):
        if self._value is None:
            return None
        return self.min_pulse_width + (self._value + 1) / 2 * (self.max_pulse_width - self.min_pulse_width)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, v):
        self._check()
        if v is None:
            self._value = None
            J.pwm_off(self.pin)
            return
        if not -1 <= v <= 1:
            raise ValueError('Servo value must be between -1 and 1, or None')
        self._value = float(v)
        J.pwm(self.pin, 1 / self.frame_width, self.pulse_width / self.frame_width)

    def min(self):
        self.value = -1

    def mid(self):
        self.value = 0

    def max(self):
        self.value = 1

    def detach(self):
        self.value = None

    @property
    def is_active(self):
        return self._value is not None


class AngularServo(Servo):
    def __init__(self, pin=None, initial_angle=0, min_angle=-90, max_angle=90, min_pulse_width=1 / 1000, max_pulse_width=2 / 1000, frame_width=20 / 1000, pin_factory=None):
        self.min_angle = min_angle
        self.max_angle = max_angle
        super().__init__(pin, self._a2v(initial_angle) if initial_angle is not None else None, min_pulse_width, max_pulse_width, frame_width)

    def _a2v(self, a):
        return (a - self.min_angle) / (self.max_angle - self.min_angle) * 2 - 1

    @property
    def angle(self):
        if self._value is None:
            return None
        return self.min_angle + (self._value + 1) / 2 * (self.max_angle - self.min_angle)

    @angle.setter
    def angle(self, a):
        self.value = None if a is None else self._a2v(a)


class LEDBoard(Device):
    def __init__(self, *pins, pwm=False, active_high=True, initial_value=False, pin_factory=None, **named):
        super().__init__()
        cls = PWMLED if pwm else LED
        self.leds = tuple(cls(p, active_high) for p in pins) + tuple(cls(p, active_high) for p in named.values())
        for k, led in zip(named.keys(), self.leds[len(pins):]):
            setattr(self, k, led)
        self.value = tuple(initial_value for _ in self.leds) if not isinstance(initial_value, tuple) else initial_value

    def __getitem__(self, i):
        return self.leds[i]

    def __len__(self):
        return len(self.leds)

    def __iter__(self):
        return iter(self.leds)

    def close(self):
        for led in self.leds:
            led.close()
        self._closed = True

    @property
    def value(self):
        return tuple(led.value for led in self.leds)

    @value.setter
    def value(self, v):
        for led, x in zip(self.leds, v):
            led.value = x

    def on(self, *idx):
        for i, led in enumerate(self.leds):
            if not idx or i in idx:
                led.on()

    def off(self, *idx):
        for i, led in enumerate(self.leds):
            if not idx or i in idx:
                led.off()

    def toggle(self, *idx):
        for i, led in enumerate(self.leds):
            if not idx or i in idx:
                led.toggle()

    def blink(self, on_time=1, off_time=1, n=None, background=True):
        for led in self.leds:
            led.blink(on_time, off_time, n, True)
        if not background and n:
            _time.sleep((on_time + off_time) * n)

    @property
    def is_active(self):
        return any(self.value)


class LEDBarGraph(LEDBoard):
    @property
    def value(self):
        return sum(led.value for led in self.leds) / len(self.leds)

    @value.setter
    def value(self, v):
        n = len(self.leds)
        for i, led in enumerate(self.leds):
            led.value = 1 if v * n >= i + 1 else 0


class TrafficLights(Device):
    def __init__(self, red=None, amber=None, green=None, pwm=False, initial_value=False, yellow=None, pin_factory=None):
        super().__init__()
        cls = PWMLED if pwm else LED
        if amber is None:
            amber = yellow
        self.red = cls(red)
        self.amber = cls(amber)
        self.yellow = self.amber
        self.green = cls(green)
        self.leds = (self.red, self.amber, self.green)

    def close(self):
        for led in self.leds:
            led.close()
        self._closed = True

    @property
    def value(self):
        return tuple(led.value for led in self.leds)

    @value.setter
    def value(self, v):
        for led, x in zip(self.leds, v):
            led.value = x

    def on(self):
        self.value = (1, 1, 1)

    def off(self):
        self.value = (0, 0, 0)


# ------------------------------------------------------------------ inputs
class InputDevice(Device):
    def __init__(self, pin=None, pull_up=False, active_state=None, pin_factory=None):
        super().__init__()
        if pin is None:
            raise GPIOZeroError('No pin given')
        self.pin = self._claim(pin)
        self.pull_up = pull_up
        J.setup(self.pin, 'in', 'up' if pull_up is True else ('down' if pull_up is False else 'none'))
        self._active_low = bool(pull_up) if active_state is None else not active_state

    @property
    def value(self):
        self._check()
        v = J.read(self.pin)
        return 1 - v if self._active_low else v

    @property
    def is_active(self):
        return bool(self.value)


class DigitalInputDevice(InputDevice):
    def __init__(self, pin=None, pull_up=False, active_state=None, bounce_time=None, pin_factory=None):
        super().__init__(pin, pull_up, active_state)
        self.bounce_time = bounce_time
        self._when_act = None
        self._when_deact = None
        self._cid = H.register(self._edge)
        J.watch(self.pin, 'both', int((bounce_time or 0) * 1000))
        J.watch_cb(self.pin, self._cid)
        self._t_act = None

    def close(self):
        if not self._closed:
            J.unwatch(self.pin)
            H.unregister(self._cid)
        super().close()

    def _edge(self, level):
        active = (1 - level if self._active_low else level) == 1
        if active:
            self._t_act = _time.ticks_ms()
            if self._when_act:
                H.call(self._when_act, self)
        else:
            self._t_act = None
            if self._when_deact:
                H.call(self._when_deact, self)

    @property
    def when_activated(self):
        return self._when_act

    @when_activated.setter
    def when_activated(self, fn):
        self._when_act = fn

    @property
    def when_deactivated(self):
        return self._when_deact

    @when_deactivated.setter
    def when_deactivated(self, fn):
        self._when_deact = fn

    def wait_for_active(self, timeout=None):
        return self._wait(True, timeout)

    def wait_for_inactive(self, timeout=None):
        return self._wait(False, timeout)

    def _wait(self, state, timeout):
        t0 = _time.ticks_ms()
        while self.is_active != state:
            if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout * 1000:
                return False
            _time.sleep_ms(5)
        return True

    @property
    def active_time(self):
        if self._t_act is None:
            return None
        return _time.ticks_diff(_time.ticks_ms(), self._t_act) / 1000


class SmoothedInputDevice(DigitalInputDevice):
    pass


class Button(DigitalInputDevice):
    def __init__(self, pin=None, pull_up=True, active_state=None, bounce_time=None, hold_time=1, hold_repeat=False, pin_factory=None):
        super().__init__(pin, pull_up, active_state, bounce_time)
        self.hold_time = hold_time
        self.hold_repeat = hold_repeat
        self._when_held = None
        self._hold_handle = None

    def _edge(self, level):
        super()._edge(level)
        if self._hold_handle:
            H.stop(self._hold_handle)
            self._hold_handle = None
        if self.is_active and self._when_held:
            t0 = _time.ticks_ms()
            fired = [0]

            def chk():
                if not self.is_active:
                    H.stop(self._hold_handle)
                    self._hold_handle = None
                    return
                # when_held after hold_time, then (hold_repeat) once every further hold_time
                n = fired[0]
                if (n == 0 or self.hold_repeat) and _time.ticks_diff(_time.ticks_ms(), t0) >= self.hold_time * 1000 * (n + 1):
                    fired[0] = n + 1
                    H.call(self._when_held, self)

            self._hold_handle = H.every(20, chk)

    is_pressed = property(lambda self: self.is_active)
    is_held = property(lambda self: self.is_active and self.active_time is not None and self.active_time >= self.hold_time)
    held_time = property(lambda self: self.active_time)
    pressed_time = held_time

    @property
    def when_pressed(self):
        return self._when_act

    @when_pressed.setter
    def when_pressed(self, fn):
        self._when_act = fn

    @property
    def when_released(self):
        return self._when_deact

    @when_released.setter
    def when_released(self, fn):
        self._when_deact = fn

    @property
    def when_held(self):
        return self._when_held

    @when_held.setter
    def when_held(self, fn):
        self._when_held = fn

    def wait_for_press(self, timeout=None):
        return self.wait_for_active(timeout)

    def wait_for_release(self, timeout=None):
        return self.wait_for_inactive(timeout)


class MotionSensor(DigitalInputDevice):
    def __init__(self, pin=None, pull_up=False, active_state=None, queue_len=1, sample_rate=10, threshold=0.5, partial=False, pin_factory=None):
        super().__init__(pin, pull_up, active_state)

    motion_detected = property(lambda self: self.is_active)

    @property
    def when_motion(self):
        return self._when_act

    @when_motion.setter
    def when_motion(self, fn):
        self._when_act = fn

    @property
    def when_no_motion(self):
        return self._when_deact

    @when_no_motion.setter
    def when_no_motion(self, fn):
        self._when_deact = fn

    def wait_for_motion(self, timeout=None):
        return self.wait_for_active(timeout)

    def wait_for_no_motion(self, timeout=None):
        return self.wait_for_inactive(timeout)


class LineSensor(DigitalInputDevice):
    def __init__(self, pin=None, pull_up=False, active_state=None, queue_len=5, sample_rate=100, threshold=0.5, partial=False, pin_factory=None):
        super().__init__(pin, pull_up, active_state)

    line_detected = property(lambda self: not self.is_active)

    @property
    def when_line(self):
        return self._when_deact

    @when_line.setter
    def when_line(self, fn):
        self._when_deact = fn

    @property
    def when_no_line(self):
        return self._when_act

    @when_no_line.setter
    def when_no_line(self, fn):
        self._when_act = fn


class LightSensor(DigitalInputDevice):
    # value: 0 (dark) ... 1 (bright); light is detected when value > threshold. The callbacks
    # (when_light / when_dark) watch the value, so they follow the threshold too.
    def __init__(self, pin=None, queue_len=5, charge_time_limit=0.01, threshold=0.1, partial=False, pin_factory=None):
        super().__init__(pin, False, None)
        self.threshold = threshold
        self._ph = None
        self._last = None

    @property
    def value(self):
        self._check()
        return J.light(self.pin)

    @property
    def is_active(self):
        return self.value > self.threshold

    light_detected = is_active

    def _edge(self, level):
        # the module's DO pin changed: check the value at once (the 50 ms poll catches the rest)
        if self._ph:
            self._poll()

    def _poll(self):
        a = self.is_active
        if a == self._last:
            return
        self._last = a
        self._t_act = _time.ticks_ms() if a else None
        fn = self._when_act if a else self._when_deact
        if fn:
            H.call(fn, self)

    def _ensure_poll(self):
        if not self._ph and not self._closed:
            self._last = self.is_active
            self._t_act = _time.ticks_ms() if self._last else None
            self._ph = H.every(50, self._poll)
            self._handles.append(self._ph)

    @property
    def when_activated(self):
        return self._when_act

    @when_activated.setter
    def when_activated(self, fn):
        self._when_act = fn
        self._ensure_poll()

    @property
    def when_deactivated(self):
        return self._when_deact

    @when_deactivated.setter
    def when_deactivated(self, fn):
        self._when_deact = fn
        self._ensure_poll()

    when_light = when_activated
    when_dark = when_deactivated

    def wait_for_light(self, timeout=None):
        return self._wait(True, timeout)

    def wait_for_dark(self, timeout=None):
        return self._wait(False, timeout)


class DistanceSensor(Device):
    def __init__(self, echo=None, trigger=None, queue_len=9, max_distance=1, threshold_distance=0.3, partial=False, pin_factory=None):
        super().__init__()
        self.echo, self.trigger = self._claim(echo, trigger)
        J.setup(self.echo, 'in', 'none')
        J.setup(self.trigger, 'out', 'none')
        self.max_distance = max_distance
        self.threshold_distance = threshold_distance
        self._in = None
        self._out = None

    @property
    def distance(self):
        self._check()
        d = J.distance(self.echo)
        if d < 0:
            return self.max_distance
        return min(self.max_distance, d)

    @property
    def value(self):
        return self.distance / self.max_distance

    @property
    def in_range(self):
        return self.distance < self.threshold_distance

    is_active = in_range

    def wait_for_in_range(self, timeout=None):
        t0 = _time.ticks_ms()
        while not self.in_range:
            if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout * 1000:
                return False
            _time.sleep_ms(20)
        return True

    def wait_for_out_of_range(self, timeout=None):
        t0 = _time.ticks_ms()
        while self.in_range:
            if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout * 1000:
                return False
            _time.sleep_ms(20)
        return True

    def _poll(self):
        r = self.in_range
        if r != self._last:
            self._last = r
            fn = self._in if r else self._out
            if fn:
                H.call(fn, self)

    def _ensure_poll(self):
        if not getattr(self, '_ph', None):
            self._last = self.in_range
            self._ph = H.every(50, self._poll)
            self._handles.append(self._ph)

    @property
    def when_in_range(self):
        return self._in

    @when_in_range.setter
    def when_in_range(self, fn):
        self._in = fn
        self._ensure_poll()

    @property
    def when_out_of_range(self):
        return self._out

    @when_out_of_range.setter
    def when_out_of_range(self, fn):
        self._out = fn
        self._ensure_poll()


# ------------------------------------------------------------------ SPI ADC (MCP3008 + pot)
class AnalogInputDevice(Device):
    bits = 10

    def __init__(self, channel=0, differential=False, max_voltage=3.3, **spi):
        super().__init__()
        self.channel = channel
        self.max_voltage = max_voltage

    @property
    def value(self):
        return J.mcp3008(self.channel)

    @property
    def raw_value(self):
        return int(self.value * ((1 << self.bits) - 1))

    @property
    def voltage(self):
        return self.value * self.max_voltage

    @property
    def is_active(self):
        return self.value > 0


class MCP3008(AnalogInputDevice):
    pass


class MCP3004(AnalogInputDevice):
    pass


class MCP3208(AnalogInputDevice):
    bits = 12


class Potentiometer(MCP3008):
    pass


# ------------------------------------------------------------------ internal devices
class CPUTemperature(Device):
    def __init__(self, sensor_file='/sys/class/thermal/thermal_zone0/temp', min_temp=0.0, max_temp=100.0, threshold=80.0, event_delay=5.0, pin_factory=None):
        super().__init__()
        self.min_temp = min_temp
        self.max_temp = max_temp
        self.threshold = threshold

    @property
    def temperature(self):
        return J.cpu_temp()

    @property
    def value(self):
        return min(1, max(0, (self.temperature - self.min_temp) / (self.max_temp - self.min_temp)))

    @property
    def is_active(self):
        return self.temperature > self.threshold


class LoadAverage(Device):
    @property
    def load_average(self):
        return 0.25

    value = property(lambda self: 0.25)


class PingServer(Device):
    def __init__(self, host='google.com', event_delay=10.0, pin_factory=None):
        super().__init__()
        self.host = host

    @property
    def value(self):
        return True

    is_active = value


class TimeOfDay(Device):
    def __init__(self, start_time=None, end_time=None, utc=True, event_delay=10.0, pin_factory=None):
        super().__init__()
        self.start_time = start_time
        self.end_time = end_time

    @property
    def value(self):
        return True


Device.pin_factory = None
`;var Hc=`# gpiozero.tones: Tone, a musical note for TonalBuzzer.play()
#     from gpiozero.tones import Tone
#     Tone('A4').frequency == 440.0;  Tone(midi=60).note == 'C4';  Tone(frequency=262).midi == 60
_NOTES = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
_NAMES = ('C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B')


def _log2(x):
    import math
    return math.log(x) / math.log(2)


class Tone:
    def __init__(self, value=None, *, frequency=None, midi=None, note=None):
        if sum(1 for a in (value, frequency, midi, note) if a is not None) != 1:
            raise TypeError('must specify a value, frequency, midi number, or note')
        if isinstance(value, Tone):
            frequency = value.frequency
        elif isinstance(value, (str, bytes)):
            note = value
        elif value is not None:
            # gpiozero: a number below 128 is a MIDI note, anything else a frequency in Hz
            if 0 <= value < 128:
                midi = value
            else:
                frequency = value
        if note is not None:
            frequency = Tone._note_freq(note)
        elif midi is not None:
            if not 0 <= midi < 128:
                raise ValueError('invalid MIDI note: %r' % (midi,))
            frequency = 440.0 * 2 ** ((midi - 69) / 12)
        frequency = float(frequency)
        if frequency <= 0:
            raise ValueError('invalid frequency: %r' % (frequency,))
        self._f = frequency

    @staticmethod
    def _note_freq(note):
        s = note.decode() if isinstance(note, bytes) else str(note)
        s = s.strip().replace('\u266F', '#').replace('\u266D', 'b')
        if len(s) < 2 or s[0].upper() not in _NOTES:
            raise ValueError('invalid note: %r' % (note,))
        n = _NOTES[s[0].upper()]
        rest = s[1:]
        if rest[0] == '#':
            n += 1
            rest = rest[1:]
        elif rest[0] == 'b' and len(rest) > 1:
            n -= 1
            rest = rest[1:]
        try:
            octave = int(rest)
        except ValueError:
            raise ValueError('invalid note: %r' % (note,))
        return 440.0 * 2 ** ((12 * (octave + 1) + n - 69) / 12)

    @classmethod
    def from_frequency(cls, freq):
        return cls(frequency=freq)

    @classmethod
    def from_midi(cls, midi_note):
        return cls(midi=midi_note)

    @classmethod
    def from_note(cls, note):
        return cls(note=note)

    @property
    def frequency(self):
        return self._f

    @property
    def midi(self):
        m = round(12 * _log2(self._f / 440.0) + 69)
        if not 0 <= m < 128:
            raise ValueError('%r is outside the MIDI range' % self)
        return m

    @property
    def note(self):
        m = self.midi
        return '%s%d' % (_NAMES[m % 12], m // 12 - 1)

    def up(self, n=1):
        return Tone(frequency=self._f * 2 ** (n / 12))

    def down(self, n=1):
        return Tone(frequency=self._f / 2 ** (n / 12))

    def __float__(self):
        return self._f

    def __eq__(self, other):
        o = other._f if isinstance(other, Tone) else other
        try:
            return abs(self._f - float(o)) < 1e-6
        except (TypeError, ValueError):
            return False

    def __lt__(self, other):
        return self._f < float(other._f if isinstance(other, Tone) else other)

    def __hash__(self):
        return hash(self._f)

    def __str__(self):
        try:
            return self.note
        except ValueError:
            return '%.2fHz' % self._f

    def __repr__(self):
        try:
            return "<Tone note=%r midi=%d frequency=%.2fHz>" % (self.note, self.midi, self._f)
        except ValueError:
            return '<Tone frequency=%.2fHz>' % self._f
`;var Uc=`# board: Adafruit Blinka pin names for the Raspberry Pi (board.D4 is BCM GPIO 4).
for _i in range(28):
    globals()['D%d' % _i] = _i
SDA = 2
SCL = 3
SCK = SCLK = 11
MOSI = 10
MISO = 9
CE0 = 8
CE1 = 7
TXD = 14
RXD = 15


def I2C():
    import busio
    return busio.I2C(SCL, SDA)


def SPI():
    import busio
    return busio.SPI(SCLK, MOSI, MISO)
`;var Gc=`# adafruit_dht: DHT11 / DHT22 on a Raspberry Pi (Adafruit CircuitPython API).
import _rpi_js as J


class DHTBase:
    def __init__(self, pin, use_pulseio=True):
        self._id = int(pin)

    def _read(self, which):
        v = J.dht(self._id, which)
        if v < -100:
            raise RuntimeError('DHT sensor not found, check wiring')
        return v

    def exit(self):
        pass


class DHT11(DHTBase):
    @property
    def temperature(self):
        return int(round(self._read(0)))

    @property
    def humidity(self):
        return int(round(self._read(1)))


class DHT22(DHTBase):
    @property
    def temperature(self):
        return round(float(self._read(0)), 1)

    @property
    def humidity(self):
        return round(float(self._read(1)), 1)
`;var Xc=`# machine for the RaptiAuto virtual Raspberry Pi Pico (RP2040 / RP2350) \u2014 the MicroPython API.
import _rpi_js as J
import _rpi_hw as H
import time as _time

_LED = 64   # id of the Pico W "LED" pin (WL_GPIO0 on the wireless chip)


def _pid(id):
    if isinstance(id, Pin):
        return id._id
    if isinstance(id, str):
        s = id.upper()
        if s in ('LED', 'WL_GPIO0'):
            return _LED if J.board() in ('picow', 'pico2w') else 25
        if s.startswith('GPIO'):
            s = s[4:]
        elif s.startswith('GP'):
            s = s[2:]
        try:
            id = int(s)
        except ValueError:
            raise ValueError('unknown named pin "%s"' % id)
    if not isinstance(id, int):
        raise TypeError("can't convert %s to int" % type(id).__name__)
    if id == 25 and J.board() in ('picow', 'pico2w'):
        # on the Pico W GPIO25 is the wireless chip's SPI clock; the LED is Pin("LED")
        return 25
    if id < 0 or id > 29:
        raise ValueError('invalid pin')
    return id


class Pin:
    IN = 0
    OUT = 1
    OPEN_DRAIN = 2
    ALT = 3
    PULL_UP = 1
    PULL_DOWN = 2
    IRQ_FALLING = 4
    IRQ_RISING = 8
    IRQ_LOW_LEVEL = 1
    IRQ_HIGH_LEVEL = 2
    ALT_SPI = 1
    ALT_UART = 2
    ALT_I2C = 3
    ALT_PWM = 4
    ALT_SIO = 5
    ALT_PIO0 = 6
    ALT_PIO1 = 7

    def __init__(self, id, mode=-1, pull=-1, *, value=None, alt=-1):
        self._id = _pid(id)
        self._mode = None
        self._irq = None
        self.init(mode, pull, value=value)

    def init(self, mode=-1, pull=-1, *, value=None, alt=-1):
        if mode != -1:
            self._mode = mode
        if pull != -1:
            self._pull = pull
        if mode == Pin.OUT or mode == Pin.OPEN_DRAIN:
            if value is not None:
                J.write(self._id, 1 if value else 0)
            J.setup(self._id, 'out', 'none')
        elif mode == Pin.IN:
            p = pull if pull != -1 else None
            J.setup(self._id, 'in', 'up' if p == Pin.PULL_UP else ('down' if p == Pin.PULL_DOWN else 'none'))
        elif pull != -1:
            J.set_pull(self._id, 'up' if pull == Pin.PULL_UP else ('down' if pull == Pin.PULL_DOWN else 'none'))
        if value is not None and mode == -1:
            J.write(self._id, 1 if value else 0)

    def value(self, x=None):
        if x is None:
            return J.read(self._id)
        J.write(self._id, 1 if x else 0)

    def __call__(self, x=None):
        return self.value(x)

    def on(self):
        J.write(self._id, 1)

    def off(self):
        J.write(self._id, 0)

    high = on
    low = off

    def toggle(self):
        J.write(self._id, 0 if J.level(self._id) else 1)

    def irq(self, handler=None, trigger=IRQ_FALLING | IRQ_RISING, hard=False):
        if self._irq is not None:
            J.unwatch(self._id)
            H.unregister(self._irq)
            self._irq = None
        if handler is None:
            return None
        if trigger & (Pin.IRQ_FALLING | Pin.IRQ_RISING) == (Pin.IRQ_FALLING | Pin.IRQ_RISING):
            edge = 'both'
        elif trigger & Pin.IRQ_RISING:
            edge = 'rising'
        else:
            edge = 'falling'
        self._irq = H.register(lambda _lvl: handler(self))
        J.watch(self._id, edge, 0)
        J.watch_cb(self._id, self._irq)
        return self

    def mode(self, m=None):
        if m is None:
            return self._mode
        self.init(m)

    def pull(self, p=None):
        if p is None:
            return getattr(self, '_pull', None)
        self.init(pull=p)

    def __repr__(self):
        name = 'EXT_GPIO0' if self._id == _LED else 'GPIO%d' % self._id
        m = {Pin.IN: 'IN', Pin.OUT: 'OUT', Pin.OPEN_DRAIN: 'OPEN_DRAIN', Pin.ALT: 'ALT'}.get(self._mode, 'IN')
        return 'Pin(%s, mode=%s)' % (name, m)


class Signal:
    def __init__(self, pin, *args, invert=False, **kw):
        self._pin = pin if isinstance(pin, Pin) else Pin(pin, *args, **kw)
        self._inv = invert

    def value(self, x=None):
        if x is None:
            return self._pin.value() ^ (1 if self._inv else 0)
        self._pin.value((1 if x else 0) ^ (1 if self._inv else 0))

    def on(self):
        self.value(1)

    def off(self):
        self.value(0)


class PWM:
    def __init__(self, dest, *, freq=None, duty_u16=None, duty_ns=None, invert=False):
        self._id = _pid(dest)
        self._f = 1000 if freq is None else freq
        self._d = 0
        self._inv = invert
        J.setup(self._id, 'out', 'none')
        if duty_u16 is not None:
            self._d = duty_u16
        elif duty_ns is not None:
            self._d = int(duty_ns * self._f * 65535 // 1000000000)
        self._apply()

    def _apply(self):
        d = min(65535, max(0, self._d)) / 65535
        J.pwm(self._id, float(self._f), 1 - d if self._inv else d)

    def init(self, *, freq=None, duty_u16=None, duty_ns=None):
        if freq is not None:
            self._f = freq
        if duty_u16 is not None:
            self._d = duty_u16
        if duty_ns is not None:
            self.duty_ns(duty_ns)
        self._apply()

    def freq(self, f=None):
        if f is None:
            return self._f
        if f < 8 or f > 62500000:
            raise ValueError('freq too small' if f < 8 else 'freq too large')
        self._f = f
        self._apply()

    def duty_u16(self, d=None):
        if d is None:
            return self._d
        self._d = int(d)
        self._apply()

    def duty_ns(self, ns=None):
        if ns is None:
            return int(self._d / 65535 * 1000000000 / self._f)
        self._d = int(ns * self._f * 65535 // 1000000000)
        self._apply()

    def deinit(self):
        J.pwm_off(self._id)

    def __repr__(self):
        return '<PWM slice=%d channel=%d invert=%d>' % ((self._id >> 1) & 7, self._id & 1, 1 if self._inv else 0)


class ADC:
    CORE_TEMP = 4

    def __init__(self, pin, *, atten=None):
        if isinstance(pin, Pin):
            pin = pin._id
        if isinstance(pin, int) and 26 <= pin <= 29:
            self._ch = pin - 26
        elif isinstance(pin, int) and 0 <= pin <= 4:
            self._ch = pin
        else:
            raise ValueError('Pin doesn\\'t have ADC capabilities')

    def read_u16(self):
        v = J.adc(self._ch)
        return max(0, min(65535, int(v * 65535)))

    def __repr__(self):
        return '<ADC channel=%d>' % self._ch


class Timer:
    ONE_SHOT = 0
    PERIODIC = 1

    def __init__(self, id=-1, *, mode=PERIODIC, period=-1, freq=-1, tick_hz=1000, callback=None):
        self._t = None
        self._cid = None
        if callback is not None or period != -1 or freq != -1:
            self.init(mode=mode, period=period, freq=freq, tick_hz=tick_hz, callback=callback)

    def init(self, *, mode=PERIODIC, period=-1, freq=-1, tick_hz=1000, callback=None):
        self.deinit()
        if freq != -1:
            ms = 1000 / freq
        elif period != -1:
            ms = period * 1000 / tick_hz
        else:
            ms = 1000
        if callback is None:
            return
        self._cid = H.register(lambda _a: callback(self))
        self._t = J.timer(self._cid, max(1, ms), 1 if mode == Timer.PERIODIC else 0)

    def deinit(self):
        if self._t is not None:
            J.timer_stop(self._t)
            H.unregister(self._cid)
            self._t = None

    def __repr__(self):
        return '<Timer>'


class I2C:
    # The parts must be wired to the bus pins: SDA to sda, SCL to scl. I2C(0) defaults to GP4 / GP5,
    # I2C(1) to GP6 / GP7 (as on a real Pico).
    _DEF = {0: (4, 5), 1: (6, 7)}

    def __init__(self, id=0, *, scl=None, sda=None, freq=400000, timeout=50000):
        self._id = id
        self._freq = freq
        if id not in (0, 1):
            raise ValueError('I2C(%s) does not exist' % (id,))
        d = self._DEF[id]
        self._sda = d[0] if sda is None else _pid(sda)
        self._scl = d[1] if scl is None else _pid(scl)
        # RP2040 / RP2350: I2C0 SDA on GP0, 4, 8 ..., SCL on GP1, 5, 9 ...; I2C1 SDA on GP2, 6, 10 ..., SCL on GP3, 7, 11 ...
        if self._scl % 4 != 2 * id + 1:
            raise ValueError('bad SCL pin')
        if self._sda % 4 != 2 * id:
            raise ValueError('bad SDA pin')

    def scan(self):
        s = J.i2c_scan(self._sda, self._scl)
        return [int(a) for a in s.split(',')] if s else []

    def _w(self, addr, data):
        J.i2c_write(addr, bytes(data).hex(), self._sda, self._scl)

    def _r(self, addr, n):
        return bytes.fromhex(J.i2c_read(addr, n, self._sda, self._scl))

    def writeto(self, addr, buf, stop=True):
        self._w(addr, buf)
        return len(buf)

    def writevto(self, addr, vector, stop=True):
        data = b''.join(bytes(v) for v in vector)
        self._w(addr, data)
        return len(data)

    def readfrom(self, addr, n, stop=True):
        return self._r(addr, n)

    def readfrom_into(self, addr, buf, stop=True):
        b = self.readfrom(addr, len(buf))
        for i in range(len(buf)):
            buf[i] = b[i]

    def writeto_mem(self, addr, memaddr, buf, *, addrsize=8):
        self._w(addr, bytes([memaddr]) + bytes(buf))

    def readfrom_mem(self, addr, memaddr, n, *, addrsize=8):
        self._w(addr, bytes([memaddr]))
        return self._r(addr, n)

    def readfrom_mem_into(self, addr, memaddr, buf, *, addrsize=8):
        b = self.readfrom_mem(addr, memaddr, len(buf))
        for i in range(len(buf)):
            buf[i] = b[i]

    def __repr__(self):
        return 'I2C(%d, freq=%d, scl=%d, sda=%d)' % (self._id, self._freq, self._scl, self._sda)


class SoftI2C(I2C):
    # bit-banged I2C: any two GPIOs
    def __init__(self, scl, sda, *, freq=400000, timeout=50000):
        self._id = -1
        self._freq = freq
        self._sda = _pid(sda)
        self._scl = _pid(scl)

    def __repr__(self):
        return 'SoftI2C(scl=%d, sda=%d, freq=%d)' % (self._scl, self._sda, self._freq)


class SPI:
    """SPI bus: the bytes reach a MAX7219 chain (or an MCP3008) wired to the SCK / MOSI pins."""
    MSB = 0
    LSB = 1
    _DEFAULT = {0: (18, 19, 16), 1: (10, 11, 12)}   # id -> (sck, mosi, miso) on the Pico

    def __init__(self, id=0, baudrate=1000000, *, polarity=0, phase=0, bits=8, firstbit=0, sck=None, mosi=None, miso=None):
        self._id = id
        d = SPI._DEFAULT.get(id, (18, 19, 16))
        self._sck = _pid(sck) if sck is not None else d[0]
        self._mosi = _pid(mosi) if mosi is not None else d[1]
        self._miso = _pid(miso) if miso is not None else d[2]
        self._baud = baudrate

    def init(self, baudrate=1000000, **kw):
        self._baud = baudrate
        for k in ('sck', 'mosi', 'miso'):
            if kw.get(k) is not None:
                setattr(self, '_' + k, _pid(kw[k]))

    def _xfer(self, data):
        r = J.spi_xfer(self._sck, self._mosi, bytes(data).hex())
        return bytes.fromhex(r)

    def write(self, buf):
        self._xfer(buf)

    def read(self, n, write=0):
        return self._xfer(bytes([write]) * n)

    def readinto(self, buf, write=0):
        r = self.read(len(buf), write)
        for i in range(len(buf)):
            buf[i] = r[i]

    def write_readinto(self, wbuf, rbuf):
        r = self._xfer(wbuf)
        for i in range(len(rbuf)):
            rbuf[i] = r[i]

    def deinit(self):
        pass

    def __repr__(self):
        return 'SPI(%d, baudrate=%d, sck=%d, mosi=%d, miso=%d)' % (self._id, self._baud, self._sck, self._mosi, self._miso)


class SoftSPI(SPI):
    def __init__(self, baudrate=500000, *, polarity=0, phase=0, bits=8, firstbit=0, sck, mosi, miso):
        SPI.__init__(self, -1, baudrate, sck=sck, mosi=mosi, miso=miso)


class UART:
    def __init__(self, id=0, baudrate=115200, **kw):
        self._id = id
        self._baud = baudrate

    def init(self, baudrate=115200, **kw):
        self._baud = baudrate

    def write(self, buf):
        J.uart_write(self._id, bytes(buf).decode('utf-8', 'ignore') if not isinstance(buf, str) else buf)
        return len(buf)

    def any(self):
        return J.uart_any(self._id)

    def read(self, n=-1):
        s = J.uart_read(self._id, -1 if n is None else n)
        return s.encode() if s else None

    def readline(self):
        s = J.uart_readline(self._id, 1)
        return s.encode() if s else None

    def readinto(self, buf, nbytes=None):
        b = self.read(len(buf) if nbytes is None else nbytes)
        if not b:
            return None
        for i in range(len(b)):
            buf[i] = b[i]
        return len(b)

    def deinit(self):
        pass

    def __repr__(self):
        return 'UART(%d, baudrate=%d)' % (self._id, self._baud)


class RTC:
    def __init__(self, id=0):
        self._off = 0

    def datetime(self, dt=None):
        if dt is not None:
            # (year, month, day, weekday, hours, minutes, seconds, subseconds)
            _time._set_rtc((dt[0], dt[1], dt[2], dt[4], dt[5], dt[6]))
            return None
        t = _time.localtime()
        return (t[0], t[1], t[2], t[6], t[3], t[4], t[5], 0)


class WDT:
    def __init__(self, id=0, timeout=5000):
        self._timeout = timeout

    def feed(self):
        pass


PWRON_RESET = 1
WDT_RESET = 3


def freq(hz=None):
    if hz is None:
        return 150000000 if J.board() in ('pico2', 'pico2w') else 125000000


def unique_id():
    return b'\\xe6\\x61\\x41\\x04\\x03\\x2b\\x5c\\x29'


def reset():
    raise SystemExit('machine.reset()')


def soft_reset():
    raise SystemExit('soft reset')


def reset_cause():
    return PWRON_RESET


def bootloader(*a):
    raise SystemExit('BOOTSEL mode')


def idle():
    _time.sleep_ms(1)


def lightsleep(ms=None):
    if ms is None:
        while True:
            _time.sleep(1)
    _time.sleep_ms(ms)


deepsleep = lightsleep


def disable_irq():
    return 0


def enable_irq(state=0):
    pass


def time_pulse_us(pin, pulse_level, timeout_us=1000000):
    t0 = _time.ticks_us()
    while pin.value() != pulse_level:
        if _time.ticks_diff(_time.ticks_us(), t0) > timeout_us:
            return -2
    t1 = _time.ticks_us()
    while pin.value() == pulse_level:
        if _time.ticks_diff(_time.ticks_us(), t1) > timeout_us:
            return -1
    return _time.ticks_diff(_time.ticks_us(), t1)


class mem32:
    pass
`;var Jc=`# rp2: RP2040 specific functions (BOOTSEL button, country code).
import _rpi_js as J


def bootsel_button():
    return J.bootsel()


def country(c=None):
    return 'XX' if c is None else None


class PIO:
    IN_LOW = 0
    IN_HIGH = 1
    OUT_LOW = 2
    OUT_HIGH = 3
    SHIFT_LEFT = 0
    SHIFT_RIGHT = 1

    def __init__(self, id):
        raise OSError('PIO programs are not simulated in RaptiAuto')


class StateMachine:
    def __init__(self, *a, **k):
        raise OSError('PIO state machines are not simulated in RaptiAuto')


def asm_pio(*a, **k):
    def deco(f):
        return f
    return deco
`;var Yc=`# network: Wi-Fi for the Pico W on the simulated network (see src/net). Networks in range: RaptiNet
# (password rapti1234), RAPTI-Lab (password123), Wokwi-GUEST and Guest (open), Home-WiFi (12345678),
# Office-5G (admin1234). Any other name works too when the password has 8+ characters (turn on
# "Strict Wi-Fi" in http://dashboard.rapti.net/ to make a wrong name fail).
import _rpi_js as J
import json
import time as _time

STA_IF = 0
AP_IF = 1
STAT_IDLE = 0
STAT_CONNECTING = 1
STAT_WRONG_PASSWORD = -3
STAT_NO_AP_FOUND = -2
STAT_CONNECT_FAIL = -1
STAT_GOT_IP = 3


def _check():
    if J.board() not in ('picow', 'pico2w'):
        raise ImportError("no module named 'network'")


class WLAN:
    def __init__(self, interface_id=STA_IF):
        _check()
        self._if = interface_id
        self._active = False
        self._t = None
        self._ssid = None
        self._res = None
        self._join = None
        self._ap_ssid = 'MicroPython-ap'
        self._ap_pass = ''

    def active(self, a=None):
        if a is None:
            return self._active
        self._active = bool(a)
        if self._if == AP_IF:
            if self._active and self._ap_pass and 0 < len(self._ap_pass) < 8:
                raise OSError('AP password must be at least 8 characters')
            J.wifi_ap(1 if self._active else 0, self._ap_ssid, self._ap_pass)
            return
        J.wifi(1 if self._active else 0, '')
        if not self._active:
            J.wifi_leave()

    def connect(self, ssid=None, key=None, **kw):
        if not self._active:
            raise OSError('wifi is not active')
        self._ssid = ssid
        self._t = _time.ticks_ms()
        self._res = json.loads(J.wifi_join(ssid or '', key or ''))
        J.wifi(2, ssid or '')

    def disconnect(self):
        self._t = None
        self._res = None
        J.wifi_leave()
        J.wifi(1, '')

    def status(self, param=None):
        if param == 'rssi':
            return json.loads(J.wifi_info()).get('rssi', -48)
        if self._t is None:
            return STAT_IDLE
        if _time.ticks_diff(_time.ticks_ms(), self._t) < 1800:
            return STAT_CONNECTING
        st = self._res['status'] if self._res else 1
        if st == 3:
            if not json.loads(J.wifi_info()).get('connected'):
                return STAT_CONNECT_FAIL
            J.wifi(3, self._ssid or '')
            return STAT_GOT_IP
        return STAT_WRONG_PASSWORD if st == 4 else STAT_NO_AP_FOUND

    def isconnected(self):
        if self._if == AP_IF:
            return self._active
        return self.status() == STAT_GOT_IP

    def ifconfig(self, cfg=None):
        if self._if == AP_IF:
            return ('192.168.4.1', '255.255.255.0', '192.168.4.1', '0.0.0.0') if self._active else ('0.0.0.0', '0.0.0.0', '0.0.0.0', '0.0.0.0')
        if self.isconnected():
            ip = json.loads(J.wifi_info()).get('ip', '192.168.1.50')
            return (ip, '255.255.255.0', '192.168.1.1', '8.8.8.8')
        return ('0.0.0.0', '0.0.0.0', '0.0.0.0', '0.0.0.0')

    def ipconfig(self, *a):
        return self.ifconfig()[0]

    def scan(self):
        out = []
        for n in json.loads(J.wifi_scan()):
            out.append((n['ssid'].encode(), bytes(n['bssid']), n['ch'], n['rssi'], 3 if n['enc'] != 'open' else 0, 0))
        return out

    def config(self, *a, **k):
        if self._if == AP_IF:
            if 'essid' in k or 'ssid' in k:
                self._ap_ssid = k.get('essid') or k.get('ssid')
            if 'password' in k:
                self._ap_pass = k['password']
            if a and a[0] in ('essid', 'ssid'):
                return self._ap_ssid
            if self._active and k:
                J.wifi_ap(1, self._ap_ssid, self._ap_pass)
            return None
        if a and a[0] == 'mac':
            return bytes(int(x, 16) for x in json.loads(J.wifi_info()).get('mac', '28:cd:c1:0a:4b:2e').split(':'))
        if a and a[0] == 'ssid':
            return self._ssid or ''
        return None


def hostname(name=None):
    return 'PicoW' if name is None else None


def country(c=None):
    return 'BD' if c is None else None
`;var Kc=`# neopixel: WS2812 LEDs. Works like MicroPython's NeoPixel(Pin(0), 8) + write(), and like
# Adafruit's neopixel.NeoPixel(board.D18, 8, auto_write=True) + show() on a Raspberry Pi.
import _rpi_js as J

GRB = 'GRB'
RGB = 'RGB'


class NeoPixel:
    def __init__(self, pin, n, bpp=3, timing=1, *, brightness=1.0, auto_write=None, pixel_order=None):
        self._id = pin._id if hasattr(pin, '_id') else int(pin)
        self.n = n
        self.bpp = bpp
        self.brightness = brightness
        # Adafruit's library (board pins are ints) writes after every change
        self.auto_write = (not hasattr(pin, '_id')) if auto_write is None else auto_write
        self._buf = [(0, 0, 0)] * n
        J.setup(self._id, 'out', 'none')

    def __len__(self):
        return self.n

    def __setitem__(self, i, v):
        if isinstance(i, slice):
            for k, c in zip(range(*i.indices(self.n)), v):
                self._buf[k] = tuple(c)[:3]
        else:
            if i < 0:
                i += self.n
            self._buf[i] = tuple(v)[:3]
        if self.auto_write:
            self.write()

    def __getitem__(self, i):
        return self._buf[i]

    def fill(self, v):
        self._buf = [tuple(v)[:3]] * self.n
        if self.auto_write:
            self.write()

    def write(self):
        b = self.brightness
        s = ''.join('%02x%02x%02x' % (int(c[0] * b) & 255, int(c[1] * b) & 255, int(c[2] * b) & 255) for c in self._buf)
        J.neo(self._id, self.n, s)

    show = write

    def deinit(self):
        self.fill((0, 0, 0))
        self.write()
`;var Zc=`# dht: DHT11 / DHT22 temperature and humidity sensors (MicroPython API).
import _rpi_js as J


class DHTBase:
    def __init__(self, pin):
        self._id = pin._id if hasattr(pin, '_id') else int(pin)
        self._t = None
        self._h = None

    def measure(self):
        t = J.dht(self._id, 0)
        if t < -100:
            raise OSError(110)  # ETIMEDOUT: no sensor on this pin
        self._t = t
        self._h = J.dht(self._id, 1)


class DHT11(DHTBase):
    def temperature(self):
        return int(round(self._t))

    def humidity(self):
        return int(round(self._h))


class DHT22(DHTBase):
    def temperature(self):
        return round(float(self._t), 1)

    def humidity(self):
        return round(float(self._h), 1)
`;var ed=`# Character LCD (HD44780, 16x2 / 20x4) on an I2C backpack (PCF8574, address 0x27 or 0x3F) for the
# Raspberry Pi and the Pico:
#     from i2c_lcd import I2cLcd
#     lcd = I2cLcd(0x27, 2, 16)              # Raspberry Pi: SDA = GPIO2, SCL = GPIO3
#     lcd = I2cLcd(i2c, 0x27, 2, 16)         # Pico: i2c = machine.I2C(0, sda=Pin(4), scl=Pin(5))
#     lcd.putstr("Hello!")
import _rpi_js as J
import time

_RS = 0x01
_EN = 0x04
_BL = 0x08


class I2cLcd:
    def __init__(self, *args, **kw):
        a = list(args)
        self._bus = (None, None)   # Raspberry Pi: the I2C bus on GPIO2 (SDA) / GPIO3 (SCL)
        if a and not isinstance(a[0], int):
            i2c = a.pop(0)  # pico_i2c_lcd style: I2cLcd(i2c, addr, rows, cols)
            self._bus = (getattr(i2c, '_sda', None), getattr(i2c, '_scl', None))
        self.addr = a[0] if len(a) > 0 else kw.get('addr', 0x27)
        self.rows = a[1] if len(a) > 1 else kw.get('rows', 2)
        self.cols = a[2] if len(a) > 2 else kw.get('cols', 16)
        if not J.i2c_has(self.addr, self._bus[0], self._bus[1]):
            if self._bus[0] is None:
                pins = 'SDA to GPIO2, SCL to GPIO3' if J.board()[:4] != 'pico' else 'SDA, SCL'
            else:
                pins = 'SDA to GP%d, SCL to GP%d' % self._bus
            raise OSError(19, 'no I2C device at 0x%02X - wire the LCD: %s, VCC to 5V, GND' % (self.addr, pins))
        self._bl = _BL
        self.col = 0
        self.row = 0
        for n in (0x03, 0x03, 0x03, 0x02):
            self._nibble(n << 4, 0)
            time.sleep(0.005)
        self._cmd(0x28)  # 4-bit, 2 lines, 5x8 dots
        self._cmd(0x0C)  # display on, cursor off
        self._cmd(0x06)  # entry mode: increment
        self.clear()

    def _write(self, data):
        J.i2c_write(self.addr, bytes(data).hex(), self._bus[0], self._bus[1])

    def _nibble(self, hi, rs):
        b = (hi & 0xF0) | self._bl | rs
        self._write([b | _EN, b])

    def _send(self, v, rs):
        b1 = (v & 0xF0) | self._bl | rs
        b2 = ((v << 4) & 0xF0) | self._bl | rs
        self._write([b1 | _EN, b1, b2 | _EN, b2])

    def _cmd(self, c):
        self._send(c, 0)

    def clear(self):
        self._cmd(0x01)
        self.col = 0
        self.row = 0

    def home(self):
        self._cmd(0x02)
        self.col = 0
        self.row = 0

    def move_to(self, col, row):
        self.col = col
        self.row = row
        base = (0x00, 0x40, self.cols, 0x40 + self.cols)[row % 4]
        self._cmd(0x80 | (base + col))

    def putchar(self, ch):
        if ch == '\\n':
            self.move_to(0, (self.row + 1) % self.rows)
            return
        self._send(ord(ch) if isinstance(ch, str) else ch, _RS)
        self.col += 1
        if self.col >= self.cols:
            self.move_to(0, (self.row + 1) % self.rows)

    def putstr(self, s):
        for ch in str(s):
            self.putchar(ch)

    def custom_char(self, location, charmap):
        self._cmd(0x40 | ((location & 7) << 3))
        for b in charmap:
            self._send(b, _RS)
        self.move_to(self.col, self.row)

    def backlight_on(self):
        self._bl = _BL
        self._write([self._bl])

    def backlight_off(self):
        self._bl = 0
        self._write([0])

    def display_on(self):
        self._cmd(0x0C)

    def display_off(self):
        self._cmd(0x08)

    def show_cursor(self):
        self._cmd(0x0E)

    def hide_cursor(self):
        self._cmd(0x0C)

    def blink_cursor_on(self):
        self._cmd(0x0F)

    def blink_cursor_off(self):
        self._cmd(0x0E)

    # RPLCD-style names
    def write_string(self, s):
        self.putstr(s)

    @property
    def cursor_pos(self):
        return (self.row, self.col)

    @cursor_pos.setter
    def cursor_pos(self, rc):
        self.move_to(rc[1], rc[0])

    def close(self, clear=False):
        if clear:
            self.clear()
`;var td=`# smbus2 for the RaptiAuto virtual Raspberry Pi: I2C bus 1 (GPIO2 = SDA, GPIO3 = SCL).
# Talks to the parts on the circuit canvas: an I2C LCD backpack, or an Arduino running
# Wire.begin(address) as a slave (its onReceive / onRequest handlers answer).
#     from smbus2 import SMBus
#     bus = SMBus(1)
#     bus.write_i2c_block_data(8, 0, [90, 1])
#     data = bus.read_i2c_block_data(8, 0, 2)
import _rpi_js as J


def _check(addr):
    if not J.i2c_has(addr):
        raise OSError(121, 'Remote I/O error - no I2C device at 0x%02X (check SDA = GPIO2, SCL = GPIO3, GND)' % addr)


class i2c_msg:
    def __init__(self, addr, data, read):
        self.addr = addr
        self.buf = list(data)
        self.read_ = read
        self.len = len(self.buf)

    @staticmethod
    def write(addr, buf):
        return i2c_msg(addr, buf, False)

    @staticmethod
    def read(addr, length):
        return i2c_msg(addr, [0] * length, True)

    def __iter__(self):
        return iter(self.buf)

    def __len__(self):
        return self.len


class SMBus:
    def __init__(self, bus=1, force=False):
        if bus is not None and bus not in (1, '/dev/i2c-1'):
            raise FileNotFoundError(2, "No such file or directory: '/dev/i2c-%s'" % bus)
        self.bus = 1

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def open(self, bus):
        self.bus = bus

    def close(self):
        pass

    def write_quick(self, addr, force=None):
        _check(addr)

    def write_byte(self, addr, value, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([value & 255]).hex())

    def write_byte_data(self, addr, register, value, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255, value & 255]).hex())

    def write_word_data(self, addr, register, value, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255, value & 255, (value >> 8) & 255]).hex())

    def write_block_data(self, addr, register, data, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255, len(data)] + [d & 255 for d in data]).hex())

    def write_i2c_block_data(self, addr, register, data, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255] + [d & 255 for d in data]).hex())

    def read_byte(self, addr, force=None):
        _check(addr)
        return bytes.fromhex(J.i2c_read(addr, 1))[0]

    def read_byte_data(self, addr, register, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255]).hex())
        return bytes.fromhex(J.i2c_read(addr, 1))[0]

    def read_word_data(self, addr, register, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255]).hex())
        b = bytes.fromhex(J.i2c_read(addr, 2))
        return b[0] | (b[1] << 8)

    def read_i2c_block_data(self, addr, register, length, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255]).hex())
        return list(bytes.fromhex(J.i2c_read(addr, length)))

    def i2c_rdwr(self, *msgs):
        for m in msgs:
            _check(m.addr)
            if m.read_:
                m.buf = list(bytes.fromhex(J.i2c_read(m.addr, m.len)))
            else:
                J.i2c_write(m.addr, bytes(m.buf).hex())

    def scan(self):
        s = J.i2c_scan()
        return [int(a) for a in s.split(',')] if s else []
`;var id=`# smbus (python3-smbus) on the RaptiAuto virtual Raspberry Pi: the same bus as smbus2.
from smbus2 import SMBus
`;var sd=`# pyserial for the RaptiAuto virtual Raspberry Pi: the GPIO UART /dev/serial0 (GPIO14 = TXD,
# GPIO15 = RXD). Wire TXD to an Arduino's RX (D0), RXD to its TX (D1) and GND to GND.
#     import serial
#     ser = serial.Serial('/dev/serial0', 9600, timeout=1)
#     ser.write(b'L1\\n')
#     print(ser.readline())
import _rpi_js as J
import time as _time

PARITY_NONE = 'N'
PARITY_EVEN = 'E'
PARITY_ODD = 'O'
STOPBITS_ONE = 1
STOPBITS_TWO = 2
EIGHTBITS = 8
SEVENBITS = 7


class SerialException(OSError):
    pass


class SerialTimeoutException(SerialException):
    pass


_PORTS = ('/dev/serial0', '/dev/ttyAMA0', '/dev/ttyS0', 'serial0')


class Serial:
    def __init__(self, port=None, baudrate=9600, bytesize=8, parity='N', stopbits=1, timeout=None, **kw):
        self.baudrate = baudrate
        self.bytesize = bytesize
        self.parity = parity
        self.stopbits = stopbits
        self.timeout = timeout
        self._port = None
        self.is_open = False
        self.port = port
        if port is not None:
            self.open()

    def open(self):
        if self.port not in _PORTS:
            if str(self.port).startswith('/dev/ttyUSB') or str(self.port).startswith('/dev/ttyACM'):
                raise SerialException(2, "could not open port %s: no USB serial device - use /dev/serial0 (GPIO14 TXD, GPIO15 RXD)" % self.port)
            raise SerialException(2, "could not open port %s: [Errno 2] No such file or directory" % self.port)
        self._port = 'serial0'
        self.is_open = True

    def close(self):
        self.is_open = False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def _need(self):
        if not self.is_open:
            raise SerialException('Attempting to use a port that is not open')

    @property
    def in_waiting(self):
        self._need()
        return J.uart_any(self._port)

    def inWaiting(self):
        return self.in_waiting

    def write(self, data):
        self._need()
        if isinstance(data, str):
            raise TypeError('unicode strings are not supported, please encode to bytes: %r' % data)
        J.uart_write(self._port, bytes(data).decode('utf-8', 'ignore'))
        return len(data)

    def flush(self):
        pass

    def reset_input_buffer(self):
        J.uart_read(self._port, -1)

    flushInput = reset_input_buffer

    def reset_output_buffer(self):
        pass

    def _wait(self, ready):
        if ready():
            return True
        if self.timeout == 0:
            return False
        end = None if self.timeout is None else _time.ticks_add(_time.ticks_ms(), int(self.timeout * 1000))
        while not ready():
            if end is not None and _time.ticks_diff(end, _time.ticks_ms()) <= 0:
                return False
            _time.sleep_ms(5)
        return True

    def read(self, size=1):
        self._need()
        self._wait(lambda: J.uart_any(self._port) >= size)
        return J.uart_read(self._port, size).encode()

    def read_all(self):
        self._need()
        return J.uart_read(self._port, -1).encode()

    def readline(self, size=-1):
        self._need()
        self._wait(lambda: J.uart_has_line(self._port))
        return J.uart_readline(self._port, 1).encode()

    def readlines(self):
        out = []
        while True:
            line = self.readline()
            if not line:
                return out
            out.append(line)

    def read_until(self, expected=b'\\n', size=None):
        if expected == b'\\n':
            return self.readline()
        return self.read(size or 1)

    def __repr__(self):
        return "Serial<id=0x0, open=%s>(port='%s', baudrate=%d, bytesize=%d, parity='%s', stopbits=%d, timeout=%s)" % (self.is_open, self.port, self.baudrate, self.bytesize, self.parity, self.stopbits, self.timeout)
`;var nd=`# RaptiAuto virtual network (Python side): one blocking HTTP call, one server poll. The network lives in
# JavaScript (module _rpi_js); every wait sleeps a little so the screen keeps running.
import _rpi_js as J
import json
import time

# True while threading.Thread.start() runs its target: servers started there keep running in the
# background (polled between the sleeps of the main program) instead of blocking
BG = [False]


def online():
    return bool(J.net_online())


def to_text(body):
    if body is None:
        return ''
    if isinstance(body, (bytes, bytearray)):
        try:
            return bytes(body).decode('utf-8')
        except Exception:
            return ''.join(chr(c) for c in body)
    return str(body)


def to_bytes(text):
    return text.encode('utf-8') if isinstance(text, str) else bytes(text)


def http(method, url, headers=None, body='', timeout=20):
    """Send one HTTP request; returns {'status', 'statusText', 'headers', 'body', 'ms'} or raises OSError."""
    if not J.net_online():
        raise OSError(101, 'Network is unreachable (the Pi has no Wi-Fi connection)')
    rid = J.net_request(method.upper(), url, json.dumps(headers or {}), to_text(body))
    t0 = time.ticks_ms()
    while True:
        r = J.net_poll(rid)
        if r:
            break
        if time.ticks_diff(time.ticks_ms(), t0) > timeout * 1000:
            raise OSError(110, 'Connection timed out')
        time.sleep(0.01)
    res = json.loads(r)
    if res.get('failed'):
        code = res.get('error', 'ERR_FAILED')
        if code == 'ERR_NAME_NOT_RESOLVED':
            raise OSError(-2, 'Name or service not known: ' + url)
        if code == 'ERR_CONNECTION_REFUSED':
            raise OSError(111, 'Connection refused: ' + url)
        raise OSError(101, '%s (%s)' % (res.get('statusText', code), code))
    # a little round-trip time, like a real connection
    ms = res.get('ms', 0)
    if ms:
        time.sleep(min(ms, 250) / 1000)
    return res
`;var rd=`# requests for the RaptiAuto virtual Raspberry Pi / Pico W: the usual calls on the simulated network.
#     import requests
#     r = requests.get("http://wttr.in/Dhaka?format=3")
#     print(r.status_code, r.text)
#     data = requests.get("http://api.open-meteo.com/v1/forecast?latitude=23.8&longitude=90.4&current_weather=true").json()
import json as _json
import _netio
from urllib.parse import urlencode as _urlencode


class RequestException(OSError):
    pass


class ConnectionError(RequestException):
    pass


class Timeout(RequestException):
    pass


class HTTPError(RequestException):
    def __init__(self, *a, response=None):
        super().__init__(*a)
        self.response = response


class InvalidURL(RequestException):
    pass


class _Headers(dict):
    """Case-insensitive headers."""
    def __init__(self, d=None):
        super().__init__()
        for k, v in (d or {}).items():
            self[k] = v

    def __setitem__(self, k, v):
        super().__setitem__(k.lower(), v)

    def __getitem__(self, k):
        return super().__getitem__(k.lower())

    def get(self, k, default=None):
        return super().get(k.lower(), default)

    def __contains__(self, k):
        return super().__contains__(k.lower())


class Response:
    def __init__(self, res, url):
        self.status_code = res['status']
        self.reason = res.get('statusText', '')
        self.headers = _Headers(res.get('headers', {}))
        self._text = res.get('body', '')
        self.url = url
        self.encoding = 'utf-8'
        self.elapsed = res.get('ms', 0)
        self.history = []
        self.cookies = {}

    @property
    def text(self):
        return self._text

    @property
    def content(self):
        return self._text.encode('utf-8')

    @property
    def ok(self):
        return self.status_code < 400

    def json(self, **kw):
        return _json.loads(self._text)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise HTTPError('%d %s Error: %s for url: %s' % (self.status_code, 'Client' if self.status_code < 500 else 'Server', self.reason, self.url), response=self)

    def iter_content(self, chunk_size=1024):
        c = self.content
        for i in range(0, len(c), chunk_size):
            yield c[i:i + chunk_size]

    def iter_lines(self):
        for line in self._text.split('\\n'):
            yield line

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __bool__(self):
        return self.ok

    def __repr__(self):
        return '<Response [%d]>' % self.status_code


def _b64(s):
    import base64
    return base64.b64encode(s.encode()).decode()


def request(method, url, params=None, data=None, headers=None, json=None, timeout=None, auth=None, allow_redirects=True, **kw):
    if not url.startswith('http://') and not url.startswith('https://'):
        raise InvalidURL("Invalid URL %r: No scheme supplied. Perhaps you meant https://%s?" % (url, url))
    h = {'User-Agent': 'python-requests/2.31.0', 'Accept': '*/*'}
    h.update(headers or {})
    if params:
        url += ('&' if '?' in url else '?') + _urlencode(params)
    body = ''
    if json is not None:
        body = _json.dumps(json)
        h.setdefault('Content-Type', 'application/json')
    elif data is not None:
        if isinstance(data, dict):
            body = _urlencode(data)
            h.setdefault('Content-Type', 'application/x-www-form-urlencoded')
        else:
            body = _netio.to_text(data)
    if auth:
        h['Authorization'] = 'Basic ' + _b64('%s:%s' % auth)
    try:
        res = _netio.http(method, url, h, body, timeout or 20)
    except OSError as e:
        if len(e.args) and e.args[0] == 110:
            raise Timeout(*e.args)
        raise ConnectionError(*e.args)
    r = Response(res, url)
    loc = r.headers.get('location')
    if allow_redirects and 300 <= r.status_code < 400 and loc:
        from urllib.parse import urljoin
        return request('GET', urljoin(url, loc), headers=headers, timeout=timeout)
    return r


def get(url, params=None, **kw):
    return request('GET', url, params=params, **kw)


def post(url, data=None, json=None, **kw):
    return request('POST', url, data=data, json=json, **kw)


def put(url, data=None, **kw):
    return request('PUT', url, data=data, **kw)


def patch(url, data=None, **kw):
    return request('PATCH', url, data=data, **kw)


def delete(url, **kw):
    return request('DELETE', url, **kw)


def head(url, **kw):
    return request('HEAD', url, **kw)


class Session:
    def __init__(self):
        self.headers = {}
        self.auth = None
        self.cookies = {}

    def request(self, method, url, **kw):
        h = dict(self.headers)
        h.update(kw.pop('headers', None) or {})
        if self.auth and 'auth' not in kw:
            kw['auth'] = self.auth
        return request(method, url, headers=h, **kw)

    def get(self, url, **kw):
        return self.request('GET', url, **kw)

    def post(self, url, **kw):
        return self.request('POST', url, **kw)

    def put(self, url, **kw):
        return self.request('PUT', url, **kw)

    def delete(self, url, **kw):
        return self.request('DELETE', url, **kw)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass


class codes:
    ok = 200
    created = 201
    not_found = 404
    internal_server_error = 500


_RE, _CE, _TO, _HE, _IU = RequestException, ConnectionError, Timeout, HTTPError, InvalidURL


class exceptions:
    RequestException = _RE
    ConnectionError = _CE
    Timeout = _TO
    ConnectTimeout = _TO
    ReadTimeout = _TO
    HTTPError = _HE
    InvalidURL = _IU

`;var od=`# urequests (MicroPython): the same calls as requests with the small Response of MicroPython.
#     import urequests
#     r = urequests.get(url); print(r.text); r.close()
import requests as _r

Response = _r.Response


def request(method, url, data=None, json=None, headers=None, stream=None, parse_headers=True, **kw):
    return _r.request(method, url, data=data, json=json, headers=headers)


def get(url, **kw):
    return request('GET', url, **kw)


def post(url, **kw):
    return request('POST', url, **kw)


def put(url, **kw):
    return request('PUT', url, **kw)


def patch(url, **kw):
    return request('PATCH', url, **kw)


def delete(url, **kw):
    return request('DELETE', url, **kw)


def head(url, **kw):
    return request('HEAD', url, **kw)
`;var ld="";var ad=`# urllib.parse: quoting, query strings and URL splitting.
_SAFE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-~'


def quote(s, safe='/'):
    if isinstance(s, str):
        s = s.encode('utf-8')
    out = []
    for c in s:
        ch = chr(c)
        if ch in _SAFE or ch in safe:
            out.append(ch)
        else:
            out.append('%%%02X' % c)
    return ''.join(out)


def quote_plus(s, safe=''):
    return quote(s, safe + ' ').replace(' ', '+')


def unquote(s):
    if '%' not in s:
        return s
    b = bytearray()
    i = 0
    while i < len(s):
        c = s[i]
        if c == '%' and i + 3 <= len(s):
            try:
                b.append(int(s[i + 1:i + 3], 16))
                i += 3
                continue
            except ValueError:
                pass
        b.extend(c.encode('utf-8'))
        i += 1
    return bytes(b).decode('utf-8')


def unquote_plus(s):
    return unquote(s.replace('+', ' '))


def urlencode(query, doseq=False, **kw):
    items = query.items() if hasattr(query, 'items') else query
    parts = []
    for k, v in items:
        if doseq and isinstance(v, (list, tuple)):
            for x in v:
                parts.append(quote_plus(str(k)) + '=' + quote_plus(str(x)))
        else:
            parts.append(quote_plus(str(k)) + '=' + quote_plus(str(v)))
    return '&'.join(parts)


def parse_qs(qs, **kw):
    out = {}
    for part in qs.split('&'):
        if not part:
            continue
        k, _, v = part.partition('=')
        out.setdefault(unquote_plus(k), []).append(unquote_plus(v))
    return out


def parse_qsl(qs, **kw):
    return [(k, v) for k, vs in parse_qs(qs).items() for v in vs]


class ParseResult:
    """urlparse() result: a 6-item sequence with named parts (MicroPython can't subclass tuple)."""
    def __init__(self, scheme, netloc, path, params, query, fragment):
        self.scheme, self.netloc, self.path, self.params, self.query, self.fragment = scheme, netloc, path, params, query, fragment

    def _t(self):
        return (self.scheme, self.netloc, self.path, self.params, self.query, self.fragment)

    def __iter__(self):
        return iter(self._t())

    def __getitem__(self, i):
        return self._t()[i]

    def __len__(self):
        return 6

    def __eq__(self, o):
        return tuple(self) == tuple(o)

    def __repr__(self):
        return "ParseResult(scheme=%r, netloc=%r, path=%r, params=%r, query=%r, fragment=%r)" % self._t()

    @property
    def hostname(self):
        h = self.netloc.rpartition('@')[2].partition(':')[0]
        return h or None

    @property
    def port(self):
        p = self.netloc.rpartition(':')[2]
        return int(p) if self.netloc.count(':') and p.isdigit() else None

    def geturl(self):
        return urlunparse(self)


def urlparse(url, scheme=''):
    fragment = ''
    query = ''
    if '#' in url:
        url, _, fragment = url.partition('#')
    if '?' in url:
        url, _, query = url.partition('?')
    netloc = ''
    if '://' in url:
        scheme, _, rest = url.partition('://')
        if '/' in rest:
            netloc, _, path = rest.partition('/')
            path = '/' + path
        else:
            netloc, path = rest, ''
    else:
        path = url
    return ParseResult(scheme, netloc, path, '', query, fragment)


def urlunparse(p):
    scheme, netloc, path, params, query, fragment = p
    u = path
    if netloc:
        u = scheme + '://' + netloc + path if scheme else '//' + netloc + path
    if query:
        u += '?' + query
    if fragment:
        u += '#' + fragment
    return u


def urljoin(base, url):
    if '://' in url:
        return url
    b = urlparse(base)
    if url.startswith('//'):
        return b.scheme + ':' + url
    if url.startswith('/'):
        return b.scheme + '://' + b.netloc + url
    path = b.path.rsplit('/', 1)[0] + '/' + url if '/' in b.path else '/' + url
    return b.scheme + '://' + b.netloc + path
`;var fd=`class URLError(OSError):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


class HTTPError(URLError):
    def __init__(self, url, code, msg, hdrs, fp):
        super().__init__(msg)
        self.url = url
        self.code = code
        self.msg = msg
        self.headers = hdrs
        self.fp = fp

    def read(self):
        return self.fp.read() if self.fp else b''

    def __str__(self):
        return 'HTTP Error %d: %s' % (self.code, self.msg)
`;var hd=`# urllib.request.urlopen on the simulated network.
#     from urllib.request import urlopen
#     print(urlopen("http://wttr.in/Dhaka?format=3").read().decode())
import _netio
from urllib.error import URLError, HTTPError


class Request:
    def __init__(self, url, data=None, headers=None, method=None, **kw):
        self.full_url = url
        self.data = data
        self.headers = dict(headers or {})
        self.method = method or ('POST' if data is not None else 'GET')

    def add_header(self, k, v):
        self.headers[k] = v


class _Resp:
    def __init__(self, res, url):
        self.status = res['status']
        self.code = res['status']
        self.reason = res.get('statusText', '')
        self.headers = res.get('headers', {})
        self._b = res.get('body', '').encode('utf-8')
        self._url = url
        self._p = 0

    def read(self, n=-1):
        if n is None or n < 0:
            d = self._b[self._p:]
            self._p = len(self._b)
        else:
            d = self._b[self._p:self._p + n]
            self._p += len(d)
        return d

    def readline(self):
        i = self._b.find(b'\\n', self._p)
        j = len(self._b) if i < 0 else i + 1
        d = self._b[self._p:j]
        self._p = j
        return d

    def getcode(self):
        return self.status

    def geturl(self):
        return self._url

    def info(self):
        return self.headers

    def getheader(self, k, default=None):
        return self.headers.get(k.lower(), default)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __iter__(self):
        while True:
            l = self.readline()
            if not l:
                break
            yield l


def urlopen(url, data=None, timeout=20, **kw):
    if isinstance(url, Request):
        req = url
    else:
        req = Request(url, data)
    h = {'User-Agent': 'Python-urllib/3.11'}
    h.update(req.headers)
    if req.data is not None and 'Content-Type' not in h:
        h['Content-Type'] = 'application/x-www-form-urlencoded'
    try:
        res = _netio.http(req.method, req.full_url, h, req.data if req.data is not None else '', timeout)
    except OSError as e:
        raise URLError(e)
    if res['status'] >= 400:
        raise HTTPError(req.full_url, res['status'], res.get('statusText', ''), res.get('headers', {}), _Resp(res, req.full_url))
    return _Resp(res, req.full_url)


def urlretrieve(url, filename=None, **kw):
    r = urlopen(url)
    if filename:
        with open(filename, 'wb') as f:
            f.write(r.read())
    return filename, r.headers
`;var cd=`# socket for the RaptiAuto virtual Raspberry Pi / Pico W. TCP sockets speak HTTP: a client socket sends
# a request (GET / HTTP/1.1 \u2026) to a host on the simulated network and reads the answer; a server socket
# (bind / listen / accept) receives the requests a browser sends to this device and replies. That is
# what Pico W "web server" and Raspberry Pi socket examples need.
import _rpi_js as J
import json
import time
import _netio

def _title(k):
    """str.title() for header names (MicroPython has none): content-type -> Content-Type."""
    return '-'.join(p[:1].upper() + p[1:] for p in k.split('-'))

AF_INET = 2
AF_INET6 = 10
SOCK_STREAM = 1
SOCK_DGRAM = 2
SOL_SOCKET = 1
SO_REUSEADDR = 2
SO_BROADCAST = 6
IPPROTO_TCP = 6
IPPROTO_UDP = 17
SHUT_RD = 0
SHUT_WR = 1
SHUT_RDWR = 2
error = OSError
timeout = OSError
gaierror = OSError
herror = OSError

_default_timeout = [None]


def setdefaulttimeout(t):
    _default_timeout[0] = t


def getdefaulttimeout():
    return _default_timeout[0]


def gethostname():
    return J.net_hostname()


def gethostbyname(host):
    ip = J.net_resolve(host)
    if not ip:
        raise gaierror(-2, 'Name or service not known')
    return ip


def getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    ip = gethostbyname(host)
    return [(AF_INET, SOCK_STREAM, 6, '', (ip, int(port) if port else 0))]


def inet_aton(s):
    return bytes(int(x) for x in s.split('.'))


def inet_ntoa(b):
    return '.'.join(str(x) for x in b)


def _my_ip():
    return J.net_ip() or '0.0.0.0'


class _Conn:
    """The connection a server socket hands out: recv() the request, send() the reply, close() delivers it."""
    def __init__(self, rid, addr):
        info = json.loads(J.net_req(rid))
        self._id = rid
        self._addr = addr
        path = info.get('path', '/')
        lines = ['%s %s HTTP/1.1' % (info.get('method', 'GET'), path), 'Host: ' + info.get('host', '')]
        for k, v in (info.get('headers') or {}).items():
            if k != 'host':
                lines.append('%s: %s' % (_title(k), v))
        body = info.get('body', '')
        self._in = ('\\r\\n'.join(lines) + '\\r\\n\\r\\n' + body).encode('utf-8')
        self._out = b''
        self._closed = False

    def recv(self, n=1024):
        d = self._in[:n]
        self._in = self._in[n:]
        return d

    def recvfrom(self, n=1024):
        return self.recv(n), self._addr

    def send(self, data):
        if isinstance(data, str):
            data = data.encode('utf-8')
        self._out += bytes(data)
        return len(data)

    def sendall(self, data):
        self.send(data)

    def write(self, data):
        return self.send(data)

    def read(self, n=-1):
        return self.recv(n if n and n > 0 else 100000)

    def readline(self):
        i = self._in.find(b'\\n')
        j = len(self._in) if i < 0 else i + 1
        d = self._in[:j]
        self._in = self._in[j:]
        return d

    def settimeout(self, t):
        pass

    def setblocking(self, f):
        pass

    def makefile(self, mode='rwb', *a, **k):
        return self

    def fileno(self):
        return self._id

    def close(self):
        if self._closed:
            return
        self._closed = True
        raw = self._out
        status, headers, body = 200, {}, b''
        if raw:
            head, _, body = raw.partition(b'\\r\\n\\r\\n')
            lines = head.decode('utf-8', 'replace').split('\\r\\n')
            parts = lines[0].split(' ', 2)
            if len(parts) > 1 and parts[1].isdigit():
                status = int(parts[1])
            for l in lines[1:]:
                k, _, v = l.partition(':')
                if k:
                    headers[k.strip().lower()] = v.strip()
        else:
            status = 500
        J.net_respond(self._id, status, json.dumps(headers), body.decode('utf-8', 'replace'))

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


class socket:
    def __init__(self, family=AF_INET, type=SOCK_STREAM, proto=0, fileno=None):
        self.family = family
        self.type = type
        self._timeout = _default_timeout[0]
        self._block = True
        self._port = None
        self._listening = False
        self._peer = None
        self._buf = b''
        self._out = b''
        self._resp = None
        self._pos = 0
        self._closed = False

    # ---- options
    def setsockopt(self, *a):
        pass

    def settimeout(self, t):
        self._timeout = t

    def gettimeout(self):
        return self._timeout

    def setblocking(self, flag):
        self._block = bool(flag)
        self._timeout = None if flag else 0

    def getsockname(self):
        return (_my_ip(), self._port or 0)

    # ---- server
    def bind(self, addr):
        self._port = int(addr[1])

    def listen(self, backlog=5):
        if self._port is None:
            raise OSError(22, 'Invalid argument')
        r = J.net_listen(self._port)
        if r == -1:
            raise OSError(98, 'Address already in use')
        if r == 0:
            raise OSError(101, 'Network is unreachable (no Wi-Fi connection)')
        self._listening = True

    def accept(self):
        t0 = time.ticks_ms()
        while True:
            rid = J.net_accept(self._port)
            if rid:
                return _Conn(rid, ('192.168.1.2', 50000 + rid % 1000)), ('192.168.1.2', 50000 + rid % 1000)
            if self._timeout == 0:
                raise OSError(11, 'EAGAIN')
            if self._timeout is not None and time.ticks_diff(time.ticks_ms(), t0) > self._timeout * 1000:
                raise OSError(110, 'timed out')
            time.sleep(0.02)

    # ---- client
    def connect(self, addr):
        host, port = addr[0], int(addr[1])
        if not J.net_online():
            raise OSError(101, 'Network is unreachable')
        if not J.net_resolve(host):
            raise gaierror(-2, 'Name or service not known')
        self._peer = (host, port)

    def _flush(self):
        # one HTTP request is complete: send it and keep the answer for recv()
        raw = self._out
        self._out = b''
        head, _, body = raw.partition(b'\\r\\n\\r\\n')
        lines = head.decode('utf-8', 'replace').split('\\r\\n')
        parts = lines[0].split(' ')
        method = parts[0]
        path = parts[1] if len(parts) > 1 else '/'
        headers = {}
        for l in lines[1:]:
            k, _, v = l.partition(':')
            if k:
                headers[k.strip()] = v.strip()
        host, port = self._peer
        scheme = 'https' if port == 443 else 'http'
        url = '%s://%s%s%s' % (scheme, host, '' if port in (80, 443) else ':%d' % port, path)
        res = _netio.http(method, url, headers, body)
        out = 'HTTP/1.1 %d %s\\r\\n' % (res['status'], res.get('statusText', ''))
        for k, v in res.get('headers', {}).items():
            out += '%s: %s\\r\\n' % (_title(k), v)
        out += 'Connection: close\\r\\n\\r\\n' + res.get('body', '')
        self._buf = out.encode('utf-8')

    def send(self, data):
        if self._peer is None:
            raise OSError(107, 'Transport endpoint is not connected')
        if isinstance(data, str):
            data = data.encode('utf-8')
        self._out += bytes(data)
        head, sep, body = self._out.partition(b'\\r\\n\\r\\n')
        if sep:
            n = 0
            for l in head.split(b'\\r\\n'):
                if l.lower().startswith(b'content-length:'):
                    n = int(l.split(b':')[1])
            if len(body) >= n:
                self._flush()
        return len(data)

    def sendall(self, data):
        self.send(data)

    def recv(self, n=1024):
        if self._out:
            self._flush()
        d = self._buf[:n]
        self._buf = self._buf[n:]
        return d

    def recv_into(self, buf, n=0):
        d = self.recv(n or len(buf))
        buf[:len(d)] = d
        return len(d)

    def sendto(self, data, addr):
        return len(data)

    def recvfrom(self, n=1024):
        return self.recv(n), self._peer

    def makefile(self, mode='rb', *a, **k):
        return self

    def read(self, n=-1):
        return self.recv(n if n and n > 0 else 100000)

    def readline(self):
        if self._out:
            self._flush()
        i = self._buf.find(b'\\n')
        j = len(self._buf) if i < 0 else i + 1
        d = self._buf[:j]
        self._buf = self._buf[j:]
        return d

    def write(self, data):
        return self.send(data)

    def shutdown(self, how):
        pass

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._listening and self._port is not None:
            J.net_unlisten(self._port)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def create_connection(addr, timeout=None, **kw):
    s = socket()
    s.connect(addr)
    return s
`;var dd=`class HTTPStatus:
    OK = 200
    CREATED = 201
    NO_CONTENT = 204
    MOVED_PERMANENTLY = 301
    FOUND = 302
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    METHOD_NOT_ALLOWED = 405
    INTERNAL_SERVER_ERROR = 500
`;var ud=`# http.server on the simulated network: a web server on the Raspberry Pi, reachable from Chromium
# (http://localhost:8000/) and from other devices (http://<pi ip>:8000/).
#     from http.server import HTTPServer, BaseHTTPRequestHandler
#     class H(BaseHTTPRequestHandler):
#         def do_GET(self):
#             self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers()
#             self.wfile.write(b"<h1>Hello</h1>")
#     HTTPServer(("", 8000), H).serve_forever()
import json
import time
import _rpi_js as J
import _netio
from urllib.parse import urlparse

_REASON = {200: 'OK', 201: 'Created', 204: 'No Content', 301: 'Moved Permanently', 302: 'Found', 304: 'Not Modified', 400: 'Bad Request',
           401: 'Unauthorized', 403: 'Forbidden', 404: 'Not Found', 405: 'Method Not Allowed', 500: 'Internal Server Error'}


class _Headers:
    def __init__(self, d):
        self._d = {}
        for k, v in d.items():
            self._d[k.lower()] = v

    def get(self, k, default=None):
        return self._d.get(k.lower(), default)

    def __getitem__(self, k):
        return self._d[k.lower()]

    def __contains__(self, k):
        return k.lower() in self._d

    def items(self):
        return self._d.items()

    def keys(self):
        return self._d.keys()

    def get_content_type(self):
        return self._d.get('content-type', 'text/plain').split(';')[0]


class _In:
    def __init__(self, b):
        self._b = b
        self._p = 0

    def read(self, n=-1):
        if n is None or n < 0:
            d = self._b[self._p:]
        else:
            d = self._b[self._p:self._p + n]
        self._p += len(d)
        return d

    def readline(self):
        i = self._b.find(b'\\n', self._p)
        j = len(self._b) if i < 0 else i + 1
        d = self._b[self._p:j]
        self._p = j
        return d


class _Out:
    def __init__(self):
        self.data = b''

    def write(self, b):
        if isinstance(b, str):
            b = b.encode('utf-8')
        self.data += bytes(b)
        return len(b)

    def flush(self):
        pass


class BaseHTTPRequestHandler:
    server_version = 'BaseHTTP/0.6'
    sys_version = 'Python/3.11'
    protocol_version = 'HTTP/1.0'
    default_request_version = 'HTTP/0.9'

    def __init__(self, info, server):
        self.server = server
        self.client_address = ('192.168.1.2', 50000)
        self.command = info.get('method', 'GET')
        self.path = info.get('path', '/')
        self.request_version = 'HTTP/1.1'
        self.headers = _Headers(info.get('headers') or {})
        self.rfile = _In(info.get('body', '').encode('utf-8'))
        self.wfile = _Out()
        self._status = 200
        self._hdrs = []
        self._head_done = False
        self.requestline = '%s %s HTTP/1.1' % (self.command, self.path)

    def send_response(self, code, message=None):
        self._status = code
        self._msg = message

    def send_response_only(self, code, message=None):
        self._status = code

    def send_header(self, k, v):
        self._hdrs.append((k, str(v)))

    def end_headers(self):
        self._head_done = True

    def send_error(self, code, message=None, explain=None):
        msg = message or _REASON.get(code, '')
        body = '<!DOCTYPE HTML><html><head><title>Error response</title></head><body><h1>Error response</h1><p>Error code: %d</p><p>Message: %s.</p></body></html>' % (code, msg)
        self.send_response(code, msg)
        self.send_header('Content-Type', 'text/html;charset=utf-8')
        self.end_headers()
        self.wfile.write(body.encode('utf-8'))

    def log_message(self, fmt, *args):
        print('%s - - [%s] %s' % (self.client_address[0], time.strftime('%d/%b/%Y %H:%M:%S'), fmt % args))

    def log_request(self, code='-', size='-'):
        self.log_message('"%s" %s %s', self.requestline, str(code), str(size))

    def date_time_string(self, ts=None):
        return time.strftime('%a, %d %b %Y %H:%M:%S GMT')

    def address_string(self):
        return self.client_address[0]

    def handle_one(self):
        m = getattr(self, 'do_' + self.command, None)
        if m is None:
            self.send_error(501, 'Unsupported method (%r)' % self.command)
        else:
            try:
                m()
            except Exception as e:
                import sys
                sys.print_exception(e)
                if not self.wfile.data:
                    self.send_error(500, 'Internal Server Error')
        self.log_request(self._status)

    def respond(self, rid):
        hdrs = {}
        for k, v in self._hdrs:
            hdrs[k.lower()] = v
        J.net_respond(rid, self._status, json.dumps(hdrs), self.wfile.data.decode('utf-8', 'replace'))


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    """Serves the files of the current folder."""
    def do_GET(self):
        import os
        path = urlparse(self.path).path
        fs = '.' + path
        if fs.endswith('/'):
            if 'index.html' in os.listdir(fs):
                fs += 'index.html'
            else:
                names = sorted(os.listdir(fs))
                body = '<!DOCTYPE HTML><html><head><title>Directory listing for %s</title></head><body><h1>Directory listing for %s</h1><hr><ul>%s</ul><hr></body></html>' % (path, path, ''.join('<li><a href="%s%s">%s</a></li>' % (path, n, n) for n in names))
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(body.encode('utf-8'))
                return
        try:
            with open(fs, 'rb') as f:
                data = f.read()
        except OSError:
            self.send_error(404, 'File not found')
            return
        ctype = 'text/html' if fs.endswith('.html') else 'text/css' if fs.endswith('.css') else 'application/javascript' if fs.endswith('.js') else 'application/json' if fs.endswith('.json') else 'text/plain'
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)


class HTTPServer:
    allow_reuse_address = True

    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        self.server_address = (server_address[0] or '0.0.0.0', server_address[1])
        self.server_name = 'raspberrypi'
        self.server_port = server_address[1]
        self.RequestHandlerClass = RequestHandlerClass
        self._stop = False
        self._bg = None
        if bind_and_activate:
            r = J.net_listen(self.server_port)
            if r == -1:
                raise OSError(98, 'Address already in use')
            if r == 0:
                raise OSError(101, 'Network is unreachable (the Pi has no Wi-Fi / network connection)')

    def _serve_one(self):
        rid = J.net_accept(self.server_port)
        if not rid:
            return False
        info = json.loads(J.net_req(rid))
        h = self.RequestHandlerClass(info, self)
        h.handle_one()
        h.respond(rid)
        return True

    def handle_request(self):
        while not self._serve_one():
            time.sleep(0.02)

    def serve_forever(self, poll_interval=0.5):
        self._stop = False
        if _netio.BG[0]:
            import _rpi_hw
            self._bg = _rpi_hw.every(20, self._serve_one)
            return
        while not self._stop:
            if not self._serve_one():
                time.sleep(0.02)

    def shutdown(self):
        self._stop = True
        if self._bg:
            import _rpi_hw
            _rpi_hw.stop(self._bg)
            self._bg = None

    def server_close(self):
        J.net_unlisten(self.server_port)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.server_close()


ThreadingHTTPServer = HTTPServer
`;var pd=`# A small Flask for the RaptiAuto virtual Raspberry Pi: routes, request, jsonify, render_template_string,
# redirect. The server answers browsers on the simulated network (Chromium: http://localhost:5000/).
#     from flask import Flask, jsonify
#     app = Flask(__name__)
#     @app.route("/")
#     def home(): return "Hello from the Pi!"
#     app.run(host="0.0.0.0", port=5000)
import json as _json
import time
import _rpi_js as J
import _netio
from urllib.parse import urlparse, parse_qs, unquote_plus


class Headers:
    def __init__(self, d=None):
        self._d = {}
        for k, v in (d or {}).items():
            self._d[k.lower()] = v

    def get(self, k, default=None):
        return self._d.get(k.lower(), default)

    def __getitem__(self, k):
        return self._d[k.lower()]

    def __setitem__(self, k, v):
        self._d[k.lower()] = v

    def __contains__(self, k):
        return k.lower() in self._d

    def items(self):
        return self._d.items()

    def add(self, k, v):
        self._d[k.lower()] = v


class _Args:
    """request.args / request.form: a dict that returns the first value (and has getlist)."""
    def __init__(self, multi):
        self._m = multi

    def get(self, k, default=None, type=None):
        v = self._m.get(k)
        if not v:
            return default
        v = v[0]
        if type is not None:
            try:
                return type(v)
            except Exception:
                return default
        return v

    def getlist(self, k):
        return list(self._m.get(k, []))

    def __getitem__(self, k):
        v = self._m.get(k)
        if not v:
            raise KeyError(k)
        return v[0]

    def __contains__(self, k):
        return k in self._m

    def keys(self):
        return self._m.keys()

    def items(self):
        return [(k, v[0]) for k, v in self._m.items()]

    def to_dict(self):
        return dict(self.items())

    def __iter__(self):
        return iter(self._m)

    def __len__(self):
        return len(self._m)


class Request:
    method = 'GET'
    path = '/'
    args = _Args({})
    form = _Args({})
    values = _Args({})
    headers = Headers()
    data = b''
    host = 'localhost'
    url = ''
    remote_addr = '127.0.0.1'

    def get_json(self, force=False, silent=False):
        try:
            return _json.loads(self.data.decode('utf-8'))
        except Exception:
            if silent:
                return None
            raise

    @property
    def json(self):
        ct = self.headers.get('content-type', '')
        return self.get_json(silent=True) if 'json' in ct else None


request = Request()


class Response:
    def __init__(self, response='', status=200, headers=None, mimetype=None, content_type=None):
        if isinstance(response, (bytes, bytearray)):
            response = bytes(response).decode('utf-8', 'replace')
        self.data = response
        self.status_code = status
        self.headers = Headers(headers)
        ct = content_type or (mimetype and (mimetype + ('; charset=utf-8' if mimetype.startswith('text/') else '')))
        if ct:
            self.headers['content-type'] = ct
        elif 'content-type' not in self.headers:
            self.headers['content-type'] = 'text/html; charset=utf-8'

    @property
    def status(self):
        return '%d' % self.status_code

    @property
    def mimetype(self):
        return self.headers.get('content-type', '').split(';')[0]

    def get_data(self, as_text=False):
        return self.data if as_text else self.data.encode('utf-8')

    def set_cookie(self, *a, **k):
        pass


def make_response(*args):
    return _to_response(args if len(args) > 1 else args[0] if args else '')


def jsonify(*args, **kwargs):
    obj = args[0] if len(args) == 1 else (list(args) if args else kwargs)
    return Response(_json.dumps(obj), 200, mimetype='application/json')


def redirect(location, code=302):
    return Response('Redirecting to ' + location, code, {'Location': location})


class HTTPException(Exception):
    def __init__(self, code, description=''):
        super().__init__(description)
        self.code = code
        self.description = description


def abort(code, description=''):
    raise HTTPException(code, description)


def url_for(endpoint, **values):
    app = _CURRENT[0]
    if endpoint == 'static':
        return '/static/' + values.get('filename', '')
    for rule, (fn, methods, name) in app._rules:
        if name == endpoint:
            url = rule
            for k, v in values.items():
                url = url.replace('<%s>' % k, str(v)).replace('<int:%s>' % k, str(v))
            return url
    return '/'


def escape(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


class Markup(str):
    pass


# ---------------------------------------------------------------- templates (a small Jinja subset)
def _render(src, ctx):
    pos = 0
    toks = []
    while True:
        i = src.find('{', pos)
        while i >= 0 and src[i + 1:i + 2] not in ('{', '%', '#'):
            i = src.find('{', i + 1)
        if i < 0:
            toks.append(('t', src[pos:]))
            break
        toks.append(('t', src[pos:i]))
        kind = src[i + 1]
        end = src.find({'{': '}}', '%': '%}', '#': '#}'}[kind], i + 2)
        if end < 0:
            toks.append(('t', src[i:]))
            break
        toks.append((kind, src[i + 2:end].strip()))
        pos = end + 2
    out, _ = _run(toks, 0, ctx, None)
    return out


def _eval(expr, ctx):
    filt = None
    if '|' in expr and '||' not in expr:
        expr, _, filt = expr.rpartition('|')
        filt = filt.strip()
        expr = expr.strip()
    g = {'len': len, 'range': range, 'str': str, 'int': int, 'float': float, 'round': round, 'abs': abs, 'min': min, 'max': max, 'sum': sum, 'sorted': sorted, 'enumerate': enumerate, 'zip': zip, 'True': True, 'False': False, 'None': None}
    g.update(ctx)
    try:
        v = eval(expr, g)
    except Exception as e:
        v = ''
    if filt:
        if filt == 'safe':
            return Markup(str(v))
        if filt.startswith('round'):
            n = filt[filt.find('(') + 1:filt.find(')')]
            v = round(v, int(n) if n else 0)
        elif filt == 'int':
            v = int(v)
        elif filt == 'upper':
            v = str(v).upper()
        elif filt == 'lower':
            v = str(v).lower()
        elif filt == 'length':
            v = len(v)
        elif filt == 'tojson':
            return Markup(_json.dumps(v))
    return v


def _run(toks, i, ctx, stop):
    out = ''
    while i < len(toks):
        kind, val = toks[i]
        if kind == 't':
            out += val
        elif kind == '{':
            v = _eval(val, ctx)
            out += str(v) if isinstance(v, Markup) else escape(v)
        elif kind == '#':
            pass
        else:
            word = val.split(None, 1)[0] if val else ''
            if stop and word in stop:
                return out, i
            if word == 'for':
                rest = val[3:].strip()
                var, _, it = rest.partition(' in ')
                seq = _eval(it.strip(), ctx)
                names = [v.strip() for v in var.split(',')]
                # find the matching endfor
                depth, j = 1, i + 1
                while j < len(toks):
                    if toks[j][0] == '%':
                        w = toks[j][1].split(None, 1)[0] if toks[j][1] else ''
                        if w == 'for':
                            depth += 1
                        elif w == 'endfor':
                            depth -= 1
                            if depth == 0:
                                break
                    j += 1
                n = 0
                for item in seq:
                    c = dict(ctx)
                    if len(names) == 1:
                        c[names[0]] = item
                    else:
                        for a, b in zip(names, item):
                            c[a] = b
                    c['loop'] = {'index': n + 1, 'index0': n, 'first': n == 0}
                    o, _ = _run(toks[i + 1:j], 0, c, None)
                    out += o
                    n += 1
                i = j
            elif word == 'if':
                # collect branches until endif (nesting aware)
                depth, j, branches, cur_start, cur_cond = 1, i + 1, [], i + 1, val[2:].strip()
                while j < len(toks):
                    if toks[j][0] == '%':
                        w = toks[j][1].split(None, 1)[0] if toks[j][1] else ''
                        if w == 'if':
                            depth += 1
                        elif w == 'endif':
                            depth -= 1
                            if depth == 0:
                                branches.append((cur_cond, toks[cur_start:j]))
                                break
                        elif depth == 1 and w == 'elif':
                            branches.append((cur_cond, toks[cur_start:j]))
                            cur_cond, cur_start = toks[j][1][4:].strip(), j + 1
                        elif depth == 1 and w == 'else':
                            branches.append((cur_cond, toks[cur_start:j]))
                            cur_cond, cur_start = 'True', j + 1
                    j += 1
                for cond, body in branches:
                    if _eval(cond, ctx):
                        o, _ = _run(body, 0, ctx, None)
                        out += o
                        break
                i = j
            elif word == 'set':
                name, _, ex = val[3:].partition('=')
                ctx[name.strip()] = _eval(ex.strip(), ctx)
        i += 1
    return out, i


def render_template_string(source, **context):
    return _render(source, context)


def render_template(name, **context):
    import os
    for d in ('templates', '.'):
        try:
            with open(d + '/' + name) as f:
                return _render(f.read(), context)
        except OSError:
            pass
    raise OSError('TemplateNotFound: ' + name)


_CURRENT = [None]


def _to_response(rv):
    status, headers = 200, None
    if isinstance(rv, tuple):
        if len(rv) == 3:
            rv, status, headers = rv
        elif len(rv) == 2:
            rv, x = rv
            if isinstance(x, int):
                status = x
            else:
                headers = x
    if isinstance(rv, Response):
        if status != 200:
            rv.status_code = status
        if headers:
            for k, v in headers.items():
                rv.headers[k] = v
        return rv
    if isinstance(rv, (dict, list)):
        return Response(_json.dumps(rv), status, headers, mimetype='application/json')
    if rv is None:
        raise TypeError('The view function did not return a valid response. The function either returned None or ended without a return statement.')
    return Response(rv, status, headers)


class Flask:
    def __init__(self, import_name='app', **kw):
        self.name = import_name
        self.config = {}
        self._rules = []
        self._before = []
        self._after = []
        self._errors = {}
        self.debug = False
        self.static_folder = 'static'
        self._stop = False
        self._bg = None
        self._port = 5000
        _CURRENT[0] = self

    def route(self, rule, methods=None, **kw):
        def deco(fn):
            self._rules.append((rule, (fn, [m.upper() for m in (methods or ['GET'])], kw.get('endpoint') or fn.__name__)))
            return fn
        return deco

    def get(self, rule, **kw):
        return self.route(rule, methods=['GET'], **kw)

    def post(self, rule, **kw):
        return self.route(rule, methods=['POST'], **kw)

    def add_url_rule(self, rule, endpoint=None, view_func=None, methods=None, **kw):
        self._rules.append((rule, (view_func, [m.upper() for m in (methods or ['GET'])], endpoint or view_func.__name__)))

    def before_request(self, fn):
        self._before.append(fn)
        return fn

    def after_request(self, fn):
        self._after.append(fn)
        return fn

    def errorhandler(self, code):
        def deco(fn):
            self._errors[code] = fn
            return fn
        return deco

    def _match(self, path):
        for rule, (fn, methods, name) in self._rules:
            rp, pp = rule.strip('/').split('/'), path.strip('/').split('/')
            if len(rp) != len(pp):
                continue
            kw = {}
            ok = True
            for a, b in zip(rp, pp):
                if a.startswith('<') and a.endswith('>'):
                    spec = a[1:-1]
                    conv, _, nm = spec.rpartition(':')
                    b = unquote_plus(b)
                    if conv == 'int':
                        if not b.lstrip('-').isdigit():
                            ok = False
                            break
                        b = int(b)
                    elif conv == 'float':
                        try:
                            b = float(b)
                        except ValueError:
                            ok = False
                            break
                    kw[nm] = b
                elif a != b:
                    ok = False
                    break
            if ok:
                return fn, methods, kw
        return None

    def _dispatch(self, info):
        u = urlparse(info.get('path', '/'))
        method = info.get('method', 'GET')
        req = request
        req.method = method
        req.path = u.path
        req.url = 'http://' + info.get('host', 'localhost') + info.get('path', '/')
        req.host = info.get('host', 'localhost')
        req.args = _Args(parse_qs(u.query))
        body = info.get('body', '')
        req.data = body.encode('utf-8')
        req.headers = Headers(info.get('headers') or {})
        ct = req.headers.get('content-type', '')
        req.form = _Args(parse_qs(body) if 'urlencoded' in ct else {})
        m = {}
        for k in req.args.keys():
            m[k] = req.args._m[k]
        for k in req.form.keys():
            m[k] = req.form._m[k]
        req.values = _Args(m)
        try:
            for fn in self._before:
                r = fn()
                if r is not None:
                    return _to_response(r)
            if u.path.startswith('/static/'):
                try:
                    with open(self.static_folder + u.path[7:]) as f:
                        data = f.read()
                    ctype = 'text/css' if u.path.endswith('.css') else 'application/javascript' if u.path.endswith('.js') else 'text/html' if u.path.endswith('.html') else 'text/plain'
                    return Response(data, 200, mimetype=ctype)
                except OSError:
                    raise HTTPException(404, 'Not Found')
            hit = self._match(u.path)
            if hit is None:
                raise HTTPException(404, 'The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.')
            fn, methods, kw = hit
            if method not in methods and not (method == 'HEAD' and 'GET' in methods):
                raise HTTPException(405, 'The method is not allowed for the requested URL.')
            resp = _to_response(fn(**kw))
        except HTTPException as e:
            h = self._errors.get(e.code)
            if h:
                resp = _to_response(h(e))
            else:
                names = {404: 'Not Found', 405: 'Method Not Allowed', 400: 'Bad Request', 401: 'Unauthorized', 403: 'Forbidden', 500: 'Internal Server Error'}
                resp = Response('<!doctype html>\\n<html lang=en>\\n<title>%d %s</title>\\n<h1>%s</h1>\\n<p>%s</p>\\n' % (e.code, names.get(e.code, 'Error'), names.get(e.code, 'Error'), e.description), e.code)
        except Exception as e:
            import sys
            sys.print_exception(e)
            h = self._errors.get(500)
            resp = _to_response(h(e)) if h else Response('<!doctype html>\\n<html lang=en>\\n<title>500 Internal Server Error</title>\\n<h1>Internal Server Error</h1>\\n<p>The server encountered an internal error and was unable to complete your request. Either the server is overloaded or there is an error in the application.</p>\\n', 500)
        for fn in self._after:
            resp = fn(resp) or resp
        return resp

    def _serve_one(self):
        rid = J.net_accept(self._port)
        if not rid:
            return False
        info = _json.loads(J.net_req(rid))
        resp = self._dispatch(info)
        hdrs = dict(resp.headers.items())
        J.net_respond(rid, resp.status_code, _json.dumps(hdrs), resp.data)
        print('%s - - [%s] "%s %s HTTP/1.1" %d -' % (info.get('from', '192.168.1.2'), time.strftime('%d/%b/%Y %H:%M:%S'), info.get('method', 'GET'), info.get('path', '/'), resp.status_code))
        return True

    def test_client(self):
        return _TestClient(self)

    def run(self, host=None, port=None, debug=None, use_reloader=None, threaded=True, **kw):
        self._port = int(port or 5000)
        r = J.net_listen(self._port)
        if r == -1:
            raise OSError(98, 'Address already in use')
        if r == 0:
            raise OSError(101, 'Network is unreachable (the Pi has no Wi-Fi / network connection)')
        ip = J.net_ip() or '127.0.0.1'
        print(' * Serving Flask app %r' % self.name)
        print(' * Debug mode: %s' % ('on' if debug else 'off'))
        print('WARNING: This is a development server. Do not use it in a production deployment.')
        print(' * Running on all addresses (0.0.0.0)' if host == '0.0.0.0' else ' * Running on http://127.0.0.1:%d' % self._port)
        print(' * Running on http://127.0.0.1:%d' % self._port)
        if host == '0.0.0.0':
            print(' * Running on http://%s:%d' % (ip, self._port))
        print('Press CTRL+C to quit')
        self._stop = False
        if _netio.BG[0]:
            import _rpi_hw
            self._bg = _rpi_hw.every(20, self._serve_one)
            return
        while not self._stop:
            if not self._serve_one():
                time.sleep(0.02)


class _TestClient:
    def __init__(self, app):
        self.app = app

    def open(self, path, method='GET', data=None, json=None, headers=None):
        info = {'method': method, 'path': path, 'host': 'localhost', 'headers': dict(headers or {}), 'body': ''}
        if json is not None:
            info['body'] = _json.dumps(json)
            info['headers']['content-type'] = 'application/json'
        elif data:
            from urllib.parse import urlencode
            info['body'] = urlencode(data)
            info['headers']['content-type'] = 'application/x-www-form-urlencoded'
        return self.app._dispatch(info)

    def get(self, path, **kw):
        return self.open(path, 'GET', **kw)

    def post(self, path, **kw):
        return self.open(path, 'POST', **kw)
`;var md=`
`;var gd=`
`;var _d=`# paho-mqtt for the RaptiAuto virtual Raspberry Pi: a client for the simulated MQTT brokers
# (broker.hivemq.com, test.mosquitto.org, localhost = the Pi's own Mosquitto).
#     import paho.mqtt.client as mqtt
#     def on_message(client, userdata, msg): print(msg.topic, msg.payload.decode())
#     c = mqtt.Client(); c.on_message = on_message
#     c.connect("broker.hivemq.com", 1883); c.subscribe("rapti/#"); c.loop_forever()
import json
import time
import _rpi_js as J
import _netio

MQTT_ERR_SUCCESS = 0
MQTT_ERR_NO_CONN = 4
MQTT_ERR_CONN_REFUSED = 5
MQTTv31 = 3
MQTTv311 = 4
MQTTv5 = 5
MQTT_CLEAN_START_FIRST_ONLY = 3


class CallbackAPIVersion:
    VERSION1 = 1
    VERSION2 = 2


class MQTTMessage:
    def __init__(self, topic, payload, retain=False):
        self.topic = topic
        self.payload = payload.encode('utf-8') if isinstance(payload, str) else payload
        self.qos = 0
        self.retain = retain
        self.mid = 0


class MQTTMessageInfo:
    def __init__(self, rc=0):
        self.rc = rc
        self.mid = 1

    def wait_for_publish(self, timeout=None):
        pass

    def is_published(self):
        return True


def error_string(rc):
    return {0: 'No error.', 4: 'The client is not currently connected.', 5: 'Connection Refused: not authorised'}.get(rc, 'Unknown error.')


def connack_string(rc):
    return {0: 'Connection Accepted.', 5: 'Connection Refused: not authorised.'}.get(rc, 'Connection Refused: unknown reason.')


class Client:
    def __init__(self, *args, client_id='', clean_session=True, userdata=None, protocol=MQTTv311, transport='tcp', **kw):
        # Client(), Client("id"), Client(CallbackAPIVersion.VERSION2, "id")
        self._v2 = False
        a = list(args)
        if a and isinstance(a[0], int) and not isinstance(a[0], bool):
            self._v2 = a[0] == 2
            a = a[1:]
        if a and isinstance(a[0], str):
            client_id = a[0]
        self._cid = client_id or 'rapti-%d' % (time.ticks_ms() % 100000)
        self._userdata = userdata
        self._h = 0
        self._host = None
        self._user = None
        self._pass = None
        self._will = None
        self._subs = []
        self._cbs = {}
        self._bg = None
        self._stop = False
        self._connected = False
        self.on_connect = None
        self.on_disconnect = None
        self.on_message = None
        self.on_publish = None
        self.on_subscribe = None
        self.on_unsubscribe = None
        self.on_log = None

    def user_data_set(self, u):
        self._userdata = u

    def username_pw_set(self, username, password=None):
        self._user = username
        self._pass = password

    def will_set(self, topic, payload=None, qos=0, retain=False):
        self._will = (topic, payload if isinstance(payload, str) else (payload or b'').decode('utf-8'))

    def tls_set(self, *a, **k):
        pass

    def tls_insecure_set(self, *a):
        pass

    def enable_logger(self, *a):
        pass

    def reconnect_delay_set(self, *a, **k):
        pass

    def message_callback_add(self, sub, cb):
        self._cbs[sub] = cb

    def message_callback_remove(self, sub):
        self._cbs.pop(sub, None)

    def connect(self, host, port=1883, keepalive=60, bind_address='', *a, **k):
        if not J.net_online():
            raise OSError(101, 'Network is unreachable')
        w = self._will
        h = J.mqtt_connect(self._cid, host, int(port), self._user or '', self._pass or '', w[0] if w else '', w[1] if w else '')
        if h < 0:
            if h == -4 and not J.net_resolve(host):
                raise OSError(-2, 'Name or service not known')
            if h == 5:
                self._fire_connect(5)
                return 5
            raise OSError(111, 'Connection refused')
        self._h = h
        self._host = host
        self._connected = True
        for t in self._subs:
            J.mqtt_subscribe(h, t)
        self._fire_connect(0)
        return MQTT_ERR_SUCCESS

    def connect_async(self, host, port=1883, keepalive=60, *a, **k):
        self.connect(host, port, keepalive)

    def reconnect(self):
        return self.connect(self._host)

    def _fire_connect(self, rc):
        if self.on_connect:
            if self._v2:
                self.on_connect(self, self._userdata, {'session present': 0}, rc, None)
            else:
                self.on_connect(self, self._userdata, {'session present': 0}, rc)

    def disconnect(self):
        if self._h:
            J.mqtt_disconnect(self._h)
            self._h = 0
        was = self._connected
        self._connected = False
        self._stop = True
        if was and self.on_disconnect:
            if self._v2:
                self.on_disconnect(self, self._userdata, {}, 0, None)
            else:
                self.on_disconnect(self, self._userdata, 0)
        return MQTT_ERR_SUCCESS

    def is_connected(self):
        return bool(self._h and J.mqtt_connected(self._h))

    def subscribe(self, topic, qos=0, *a, **k):
        topics = topic if isinstance(topic, list) else [topic]
        for t in topics:
            if isinstance(t, tuple):
                t = t[0]
            self._subs.append(t)
            if self._h:
                J.mqtt_subscribe(self._h, t)
        if self.on_subscribe:
            if self._v2:
                self.on_subscribe(self, self._userdata, 1, [0], None)
            else:
                self.on_subscribe(self, self._userdata, 1, (qos,))
        return (MQTT_ERR_SUCCESS, 1)

    def unsubscribe(self, topic, *a):
        for t in (topic if isinstance(topic, list) else [topic]):
            if t in self._subs:
                self._subs.remove(t)
            if self._h:
                J.mqtt_unsubscribe(self._h, t)
        return (MQTT_ERR_SUCCESS, 1)

    def publish(self, topic, payload=None, qos=0, retain=False, properties=None):
        if not self._h or not J.mqtt_connected(self._h):
            return MQTTMessageInfo(MQTT_ERR_NO_CONN)
        if isinstance(payload, (bytes, bytearray)):
            payload = bytes(payload).decode('utf-8', 'replace')
        elif payload is None:
            payload = ''
        elif not isinstance(payload, str):
            payload = str(payload)
        J.mqtt_publish(self._h, topic, payload, 1 if retain else 0)
        if self.on_publish:
            if self._v2:
                self.on_publish(self, self._userdata, 1, 0, None)
            else:
                self.on_publish(self, self._userdata, 1)
        return MQTTMessageInfo(0)

    def _deliver(self, m):
        msg = MQTTMessage(m['topic'], m['payload'], m.get('retained', False))
        for sub, cb in self._cbs.items():
            if _match(sub, msg.topic):
                cb(self, self._userdata, msg)
                return
        if self.on_message:
            self.on_message(self, self._userdata, msg)

    def loop(self, timeout=1.0, max_packets=1):
        if not self._h:
            return MQTT_ERR_NO_CONN
        n = 0
        t0 = time.ticks_ms()
        while True:
            r = J.mqtt_poll(self._h)
            if r:
                self._deliver(json.loads(r))
                n += 1
                if n >= 50:
                    break
            elif n or time.ticks_diff(time.ticks_ms(), t0) >= timeout * 1000:
                break
            else:
                time.sleep(0.01)
        return MQTT_ERR_SUCCESS

    def _tick(self):
        if not self._h:
            return
        for _ in range(20):
            r = J.mqtt_poll(self._h)
            if not r:
                break
            self._deliver(json.loads(r))

    def loop_start(self):
        import _rpi_hw
        if self._bg is None:
            self._bg = _rpi_hw.every(20, self._tick)
        return MQTT_ERR_SUCCESS

    def loop_stop(self, force=False):
        if self._bg is not None:
            import _rpi_hw
            _rpi_hw.stop(self._bg)
            self._bg = None
        return MQTT_ERR_SUCCESS

    def loop_forever(self, timeout=1.0, retry_first_connection=False):
        self._stop = False
        while not self._stop and self._h:
            self._tick()
            time.sleep(0.02)
        return MQTT_ERR_SUCCESS

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.disconnect()


def _match(f, t):
    fs, ts = f.split('/'), t.split('/')
    for i, p in enumerate(fs):
        if p == '#':
            return True
        if i >= len(ts):
            return False
        if p != '+' and p != ts[i]:
            return False
    return len(fs) == len(ts)


def topic_matches_sub(sub, topic):
    return _match(sub, topic)
`;var yd=`from paho.mqtt.client import Client


def single(topic, payload=None, qos=0, retain=False, hostname='localhost', port=1883, client_id='', auth=None, **kw):
    c = Client(client_id=client_id)
    if auth:
        c.username_pw_set(auth.get('username'), auth.get('password'))
    c.connect(hostname, port)
    c.publish(topic, payload, qos, retain)
    c.disconnect()


def multiple(msgs, hostname='localhost', port=1883, client_id='', auth=None, **kw):
    c = Client(client_id=client_id)
    c.connect(hostname, port)
    for m in msgs:
        if isinstance(m, dict):
            c.publish(m['topic'], m.get('payload'), m.get('qos', 0), m.get('retain', False))
        else:
            c.publish(*m[:4])
    c.disconnect()
`;var bd=`import time
from paho.mqtt.client import Client


def simple(topics, hostname='localhost', port=1883, msg_count=1, **kw):
    out = []
    c = Client()

    def on_message(client, userdata, msg):
        out.append(msg)

    c.on_message = on_message
    c.connect(hostname, port)
    c.subscribe(topics)
    while len(out) < msg_count:
        c.loop(0.2)
    c.disconnect()
    return out[0] if msg_count == 1 else out
`;var vd=`
`;var Od=`# umqtt.simple (MicroPython): MQTT client for the Pico W on the simulated brokers.
#     from umqtt.simple import MQTTClient
#     c = MQTTClient("pico", "broker.hivemq.com"); c.connect(); c.publish(b"rapti/pico", b"hello")
import json
import time
import _rpi_js as J


class MQTTException(Exception):
    pass


class MQTTClient:
    def __init__(self, client_id, server, port=0, user=None, password=None, keepalive=0, ssl=False, ssl_params={}):
        self.client_id = client_id if isinstance(client_id, str) else client_id.decode()
        self.server = server
        self.port = port or (8883 if ssl else 1883)
        self.user = user
        self.pswd = password
        self.cb = None
        self._h = 0
        self._will = None

    def set_callback(self, f):
        self.cb = f

    def set_last_will(self, topic, msg, retain=False, qos=0):
        self._will = (topic.decode() if isinstance(topic, bytes) else topic, msg.decode() if isinstance(msg, bytes) else msg)

    def connect(self, clean_session=True, timeout=None):
        w = self._will
        h = J.mqtt_connect(self.client_id, self.server, self.port, self.user or '', (self.pswd or ''), w[0] if w else '', w[1] if w else '')
        if h < 0:
            if h == 5:
                raise MQTTException(5)
            raise OSError(-1 if h == -4 else 111, 'MQTT connect failed')
        self._h = h
        return False

    def disconnect(self):
        if self._h:
            J.mqtt_disconnect(self._h)
            self._h = 0

    def ping(self):
        pass

    def publish(self, topic, msg, retain=False, qos=0):
        if not self._h or not J.mqtt_connected(self._h):
            raise OSError(104, 'ECONNRESET')
        J.mqtt_publish(self._h, topic.decode() if isinstance(topic, bytes) else topic, msg.decode() if isinstance(msg, (bytes, bytearray)) else str(msg), 1 if retain else 0)

    def subscribe(self, topic, qos=0):
        if not self.cb:
            raise MQTTException('subscribe callback is not set')
        J.mqtt_subscribe(self._h, topic.decode() if isinstance(topic, bytes) else topic)

    def check_msg(self):
        r = J.mqtt_poll(self._h) if self._h else ''
        if not r:
            return None
        m = json.loads(r)
        self.cb(m['topic'].encode(), m['payload'].encode())
        return None

    def wait_msg(self):
        while True:
            r = J.mqtt_poll(self._h)
            if r:
                m = json.loads(r)
                self.cb(m['topic'].encode(), m['payload'].encode())
                return None
            time.sleep(0.02)
`;var wd=`def bisect_left(a, x, lo=0, hi=None):
    if hi is None:
        hi = len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        if a[mid] < x:
            lo = mid + 1
        else:
            hi = mid
    return lo


def bisect_right(a, x, lo=0, hi=None):
    if hi is None:
        hi = len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        if x < a[mid]:
            hi = mid
        else:
            lo = mid + 1
    return lo


bisect = bisect_right


def insort_left(a, x, lo=0, hi=None):
    a.insert(bisect_left(a, x, lo, hi), x)


def insort_right(a, x, lo=0, hi=None):
    a.insert(bisect_right(a, x, lo, hi), x)


insort = insort_right
`;var kd=`def wrap(text, width=70, **kw):
    lines, cur = [], ''
    for w in text.split():
        if cur and len(cur) + 1 + len(w) > width:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + ' ' + w) if cur else w
    if cur:
        lines.append(cur)
    return lines


def fill(text, width=70, **kw):
    return '\\n'.join(wrap(text, width))


def shorten(text, width, placeholder=' [...]', **kw):
    t = ' '.join(text.split())
    if len(t) <= width:
        return t
    return t[:max(0, width - len(placeholder))].rstrip() + placeholder


def dedent(text):
    lines = text.split('\\n')
    ind = min((len(l) - len(l.lstrip()) for l in lines if l.strip()), default=0)
    return '\\n'.join(l[ind:] for l in lines)


def indent(text, prefix):
    return ''.join(prefix + l if l.strip() else l for l in text.splitlines(True))
`;var xd=`class _GC:
    def __init__(self, gen):
        self._gen = gen

    def __enter__(self):
        return next(self._gen)

    def __exit__(self, t, v, tb):
        try:
            if t is None:
                next(self._gen)
            else:
                try:
                    self._gen.throw(v)
                except StopIteration:
                    return True
        except StopIteration:
            pass
        return False


def contextmanager(fn):
    def helper(*a, **k):
        return _GC(fn(*a, **k))
    return helper


class closing:
    def __init__(self, thing):
        self.thing = thing

    def __enter__(self):
        return self.thing

    def __exit__(self, *a):
        self.thing.close()


class suppress:
    def __init__(self, *exc):
        self.exc = exc

    def __enter__(self):
        return None

    def __exit__(self, t, v, tb):
        return t is not None and issubclass(t, self.exc)
`;var Sd=`# threading for the virtual Pi (one interpreter, no real threads): Thread(target).start() runs the
# target at once. A web server started in it (Flask app.run, HTTPServer.serve_forever) keeps running
# in the background, and mqtt loop_start() does too, so the main program carries on.
import time
import _netio


class Thread:
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, daemon=None):
        self._target = target
        self._args = args
        self._kwargs = kwargs or {}
        self.name = name or 'Thread-1'
        self.daemon = bool(daemon)
        self._alive = False

    def start(self):
        self._alive = True
        _netio.BG[0] = True
        try:
            self.run()
        finally:
            _netio.BG[0] = False
            self._alive = False

    def run(self):
        if self._target:
            self._target(*self._args, **self._kwargs)

    def join(self, timeout=None):
        pass

    def is_alive(self):
        return self._alive

    def setDaemon(self, d):
        self.daemon = d


class Event:
    def __init__(self):
        self._f = False

    def set(self):
        self._f = True

    def clear(self):
        self._f = False

    def is_set(self):
        return self._f

    def wait(self, timeout=None):
        t0 = time.ticks_ms()
        while not self._f:
            if timeout is not None and time.ticks_diff(time.ticks_ms(), t0) > timeout * 1000:
                break
            time.sleep(0.01)
        return self._f


class Lock:
    def acquire(self, *a, **k):
        return True

    def release(self):
        pass

    def locked(self):
        return False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass


RLock = Lock


class Timer(Thread):
    def __init__(self, interval, function, args=None, kwargs=None):
        super().__init__(target=function, args=args or (), kwargs=kwargs)
        self.interval = interval

    def start(self):
        import _rpi_hw
        h = [None]

        def fire():
            _rpi_hw.stop(h[0])
            self._target(*self._args, **self._kwargs)
        h[0] = _rpi_hw.every(int(self.interval * 1000), fire)
        self._h = h

    def cancel(self):
        h = getattr(self, '_h', None)
        if h and h[0]:
            import _rpi_hw
            _rpi_hw.stop(h[0])
            h[0] = None


def current_thread():
    return Thread(name='MainThread')


def active_count():
    return 1
`;var Td=`# psutil (a few calls) for dashboards: CPU load, memory, temperature of the virtual Pi.
import random as _r
import time as _t


class _N:
    def __init__(self, **k):
        self._v = tuple(k.values())
        for key in k:
            setattr(self, key, k[key])

    def __iter__(self):
        return iter(self._v)


def cpu_percent(interval=None, percpu=False):
    v = 6 + (_t.ticks_ms() // 700) % 17 + _r.random() * 4
    return [v, v + 1, v - 1, v + 2] if percpu else round(v, 1)


def cpu_count(logical=True):
    return 4


def virtual_memory():
    total = 8 * 1024 ** 3
    used = int(total * (0.11 + ((_t.ticks_ms() // 3000) % 9) * 0.004))
    return _N(total=total, available=total - used, used=used, free=total - used, percent=round(used * 100 / total, 1))


def disk_usage(path='/'):
    total = 29 * 1024 ** 3
    used = int(6.6 * 1024 ** 3)
    return _N(total=total, used=used, free=total - used, percent=round(used * 100 / total, 1))


def sensors_temperatures(fahrenheit=False):
    t = 44 + ((_t.ticks_ms() // 2000) % 7) * 0.5
    return {'cpu_thermal': [_N(label='', current=t, high=None, critical=None)]}


def boot_time():
    return _t.time() - 3600


def net_if_addrs():
    import _rpi_js as J
    return {'wlan0': [_N(family=2, address=J.net_ip() or '0.0.0.0', netmask='255.255.255.0')]}
`;var Pd=`# ntptime (MicroPython): sets the RTC from the simulated NTP server (the phone's clock).
import time as _t

host = 'pool.ntp.org'
timeout = 1


def time():
    return int(_t.time())


def settime():
    try:
        import machine
        tm = _t.gmtime(int(_t.time()))
        machine.RTC().datetime((tm[0], tm[1], tm[2], tm[6], tm[3], tm[4], tm[5], 0))
    except Exception:
        pass
`;var Cd=`# SSD1306 OLED driver (the MicroPython one): 128x64 or 128x32 on I2C
#     from machine import Pin, I2C
#     import ssd1306
#     i2c = I2C(0, sda=Pin(4), scl=Pin(5))
#     oled = ssd1306.SSD1306_I2C(128, 64, i2c)
#     oled.fill(0); oled.text("Hello", 0, 0); oled.show()
import framebuf

SET_CONTRAST = 0x81
SET_ENTIRE_ON = 0xA4
SET_NORM_INV = 0xA6
SET_DISP = 0xAE
SET_MEM_ADDR = 0x20
SET_COL_ADDR = 0x21
SET_PAGE_ADDR = 0x22
SET_DISP_START_LINE = 0x40
SET_SEG_REMAP = 0xA0
SET_MUX_RATIO = 0xA8
SET_IREF_SELECT = 0x8D
SET_COM_OUT_DIR = 0xC0
SET_DISP_OFFSET = 0xD3
SET_COM_PIN_CFG = 0xDA
SET_DISP_CLK_DIV = 0xD5
SET_PRECHARGE = 0xD9
SET_VCOM_DESEL = 0xDB
SET_CHARGE_PUMP = 0x8D


class SSD1306(framebuf.FrameBuffer):
    def __init__(self, width, height, external_vcc):
        self.width = width
        self.height = height
        self.external_vcc = external_vcc
        self.pages = self.height // 8
        self.buffer = bytearray(self.pages * self.width)
        super().__init__(self.buffer, self.width, self.height, framebuf.MONO_VLSB)
        self.init_display()

    def init_display(self):
        for cmd in (
            SET_DISP,
            SET_MEM_ADDR, 0x00,
            SET_DISP_START_LINE,
            SET_SEG_REMAP | 0x01,
            SET_MUX_RATIO, self.height - 1,
            SET_COM_OUT_DIR | 0x08,
            SET_DISP_OFFSET, 0x00,
            SET_COM_PIN_CFG, 0x02 if self.width > 2 * self.height else 0x12,
            SET_DISP_CLK_DIV, 0x80,
            SET_PRECHARGE, 0x22 if self.external_vcc else 0xF1,
            SET_VCOM_DESEL, 0x30,
            SET_CONTRAST, 0xFF,
            SET_ENTIRE_ON,
            SET_NORM_INV,
            SET_IREF_SELECT, 0x10 if self.external_vcc else 0x14,
            SET_DISP | 0x01,
        ):
            self.write_cmd(cmd)
        self.fill(0)
        self.show()

    def poweroff(self):
        self.write_cmd(SET_DISP)

    def poweron(self):
        self.write_cmd(SET_DISP | 0x01)

    def contrast(self, contrast):
        self.write_cmd(SET_CONTRAST)
        self.write_cmd(contrast)

    def invert(self, invert):
        self.write_cmd(SET_NORM_INV | (invert & 1))

    def rotate(self, rotate):
        self.write_cmd(SET_COM_OUT_DIR | ((rotate & 1) << 3))
        self.write_cmd(SET_SEG_REMAP | (rotate & 1))

    def show(self):
        x0 = 0
        x1 = self.width - 1
        if self.width != 128:
            col_offset = (128 - self.width) // 2
            x0 += col_offset
            x1 += col_offset
        self.write_cmd(SET_COL_ADDR)
        self.write_cmd(x0)
        self.write_cmd(x1)
        self.write_cmd(SET_PAGE_ADDR)
        self.write_cmd(0)
        self.write_cmd(self.pages - 1)
        self.write_data(self.buffer)


class SSD1306_I2C(SSD1306):
    def __init__(self, width, height, i2c, addr=0x3C, external_vcc=False):
        self.i2c = i2c
        self.addr = addr
        self.temp = bytearray(2)
        self.write_list = [b"\\x40", None]
        super().__init__(width, height, external_vcc)

    def write_cmd(self, cmd):
        self.temp[0] = 0x80
        self.temp[1] = cmd
        self.i2c.writeto(self.addr, self.temp)

    def write_data(self, buf):
        self.i2c.writeto(self.addr, b"\\x40" + bytes(buf))
`;var Ed=`# adafruit_ssd1306 (CircuitPython / Blinka) for the Raspberry Pi:
#     import board, busio, adafruit_ssd1306
#     i2c = board.I2C()
#     oled = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c, addr=0x3C)
#     oled.fill(0); oled.text("Hello", 0, 0, 1); oled.show()
import ssd1306 as _s

class SSD1306_I2C(_s.SSD1306_I2C):
    def __init__(self, width, height, i2c, *, addr=0x3C, external_vcc=False, reset=None):
        if not i2c.try_lock():
            raise RuntimeError("I2C bus is in use")
        i2c.unlock()
        if addr not in i2c.scan():
            raise ValueError("No I2C device at address: 0x%x" % addr)
        super().__init__(width, height, _Bus(i2c), addr, external_vcc)

    def image(self, image):
        raise NotImplementedError("PIL images are not available in the simulator - draw with fill/text/line/rect/pixel")

    @property
    def power(self):
        return True


class _Bus:
    def __init__(self, i2c):
        self.i2c = i2c

    def writeto(self, addr, buf):
        self.i2c.writeto(addr, bytes(buf))
`;var Ad=`# busio (Adafruit Blinka): I2C, SPI and UART on the Raspberry Pi
import _rpi_js as J


class I2C:
    def __init__(self, scl=None, sda=None, frequency=100000):
        self.frequency = frequency
        self._locked = False

    def try_lock(self):
        if self._locked:
            return False
        self._locked = True
        return True

    def unlock(self):
        self._locked = False

    def deinit(self):
        pass

    def scan(self):
        s = J.i2c_scan()
        return [int(a) for a in s.split(',')] if s else []

    def writeto(self, address, buffer, *, start=0, end=None, stop=True):
        end = len(buffer) if end is None else end
        J.i2c_write(address, bytes(buffer[start:end]).hex())

    def readfrom_into(self, address, buffer, *, start=0, end=None, stop=True):
        end = len(buffer) if end is None else end
        data = bytes.fromhex(J.i2c_read(address, end - start))
        for i in range(end - start):
            buffer[start + i] = data[i]

    def writeto_then_readfrom(self, address, buffer_out, buffer_in, *, out_start=0, out_end=None, in_start=0, in_end=None, stop=False):
        self.writeto(address, buffer_out, start=out_start, end=out_end)
        self.readfrom_into(address, buffer_in, start=in_start, end=in_end)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.deinit()


class SPI:
    def __init__(self, clock=None, MOSI=None, MISO=None):
        self._sck = clock if clock is not None else 11
        self._mosi = MOSI if MOSI is not None else 10
        self._locked = False

    def try_lock(self):
        self._locked = True
        return True

    def unlock(self):
        self._locked = False

    def configure(self, **kw):
        pass

    def write(self, buf, start=0, end=None):
        end = len(buf) if end is None else end
        J.spi_xfer(self._sck, self._mosi, bytes(buf[start:end]).hex())

    def deinit(self):
        pass
`;var Rd=`# TM1637 4-digit 7-segment display (the popular micropython-tm1637 / tm1637 PyPI API):
#     import tm1637
#     tm = tm1637.TM1637(clk=Pin(2), dio=Pin(3))     # Pico  (Raspberry Pi: clk=23, dio=24)
#     tm.number(1234)    tm.show("HELP")    tm.numbers(12, 34)    tm.temperature(25)
import _rpi_js as J
import time

_SEGMENTS = bytearray(b'\\x3F\\x06\\x5B\\x4F\\x66\\x6D\\x7D\\x07\\x7F\\x6F\\x77\\x7C\\x39\\x5E\\x79\\x71\\x3D\\x76\\x06\\x1E\\x76\\x38\\x55\\x54\\x3F\\x73\\x67\\x50\\x6D\\x78\\x3E\\x1C\\x2A\\x76\\x6E\\x5B\\x00\\x40\\x63')


def _gpio(p):
    if isinstance(p, int):
        return p
    return p._id if hasattr(p, '_id') else int(p)


class TM1637:
    def __init__(self, clk, dio, brightness=7):
        self.clk = _gpio(clk)
        self.dio = _gpio(dio)
        self._brightness = brightness
        self._frame = bytearray(6)
        self._send(self._frame[:4])

    def _send(self, segs):
        for i in range(len(segs)):
            self._frame[i] = segs[i]
        J.disp_tm1637(self.clk, self.dio, bytes(self._frame).hex(), self._brightness, 1)

    def brightness(self, val=None):
        """Set the display brightness 0-7."""
        if val is None:
            return self._brightness
        if not 0 <= val <= 7:
            raise ValueError("Brightness out of range")
        self._brightness = val
        self._send(self._frame[:4])

    def write(self, segments, pos=0):
        """Display up to 6 segments (a segment is one byte: bit 0 = A ... bit 6 = G, bit 7 = dot)."""
        if not 0 <= pos <= 5:
            raise ValueError("Position out of range")
        for i in range(len(segments)):
            if pos + i < 6:
                self._frame[pos + i] = segments[i]
        self._send(self._frame[:4])

    def encode_digit(self, digit):
        return _SEGMENTS[digit & 0x0f]

    def encode_string(self, string):
        segments = bytearray(len(string))
        for i in range(len(string)):
            segments[i] = self.encode_char(string[i])
        return segments

    def encode_char(self, char):
        o = ord(char)
        if o == 32:
            return _SEGMENTS[36]
        if o == 42:
            return _SEGMENTS[38]
        if o == 45:
            return _SEGMENTS[37]
        if o >= 65 and o <= 90:
            return _SEGMENTS[o - 55]
        if o >= 97 and o <= 122:
            return _SEGMENTS[o - 87]
        if o >= 48 and o <= 57:
            return _SEGMENTS[o - 48]
        raise ValueError("Character out of range: {:d} '{:s}'".format(o, chr(o)))

    def hex(self, val):
        string = '{:04x}'.format(val & 0xffff)
        self.write(self.encode_string(string))

    def number(self, num):
        num = max(-999, min(num, 9999))
        string = '{0: >4d}'.format(num)
        self.write(self.encode_string(string))

    def numbers(self, num1, num2, colon=True):
        num1 = max(-9, min(num1, 99))
        num2 = max(-9, min(num2, 99))
        segments = self.encode_string('{0:0>2d}{1:0>2d}'.format(num1, num2))
        if colon:
            segments[1] |= 0x80
        self.write(segments)

    def temperature(self, num):
        if num < -9:
            self.show('lo')
        elif num > 99:
            self.show('hi')
        else:
            string = '{0: >2d}'.format(num)
            self.write(self.encode_string(string))
        self.write([_SEGMENTS[38], _SEGMENTS[12]], 2)

    def show(self, string, colon=False):
        segments = self.encode_string(string)
        if len(segments) > 1 and colon:
            segments[1] |= 128
        self.write(segments[:4])

    def scroll(self, string, delay=250):
        segments = string if isinstance(string, list) else self.encode_string(string)
        data = [0] * 8
        data[4:0] = list(segments)
        for i in range(len(segments) + 5):
            self.write(data[0 + i:4 + i])
            time.sleep_ms(delay) if hasattr(time, 'sleep_ms') else time.sleep(delay / 1000)


class TM1637Decimal(TM1637):
    def number(self, num):
        self.show(str(num)[:5].rjust(4))
`;var Md=`# MAX7219 8x8 LED matrix (the MicroPython driver API, plus the Raspberry Pi: pass a spidev device):
#     from machine import Pin, SPI
#     import max7219
#     spi = SPI(0, sck=Pin(2), mosi=Pin(3))
#     display = max7219.Matrix8x8(spi, Pin(5, Pin.OUT), 4)     # 4 modules = 32x8
#     display.text("Hi!", 0, 0, 1); display.show()
import framebuf

_DECODEMODE = 9
_INTENSITY = 10
_SCANLIMIT = 11
_SHUTDOWN = 12
_DISPLAYTEST = 15


class Matrix8x8:
    def __init__(self, spi, cs=None, num=1):
        self.spi = spi
        self.cs = cs
        self.num = num
        self.buffer = bytearray(8 * num)
        self.fb = framebuf.FrameBuffer(self.buffer, 8 * num, 8, framebuf.MONO_HLSB)
        self.width = 8 * num
        self.height = 8
        self.init()

    def _write(self, command, data):
        frame = bytearray([command, data] * self.num)
        if hasattr(self.spi, 'xfer2'):
            self.spi.xfer2(list(frame))
        else:
            if self.cs is not None:
                self.cs.value(0)
            self.spi.write(frame)
            if self.cs is not None:
                self.cs.value(1)

    def init(self):
        for command, data in ((_SHUTDOWN, 0), (_DISPLAYTEST, 0), (_SCANLIMIT, 7), (_DECODEMODE, 0), (_SHUTDOWN, 1)):
            self._write(command, data)
        self.fill(0)
        self.show()

    def brightness(self, value):
        if not 0 <= value <= 15:
            raise ValueError("Brightness out of range")
        self._write(_INTENSITY, value)

    def show(self):
        for y in range(8):
            frame = bytearray()
            for m in range(self.num - 1, -1, -1):
                frame.append(y + 1)
                frame.append(self.buffer[y * self.num + m])
            if hasattr(self.spi, 'xfer2'):
                self.spi.xfer2(list(frame))
            else:
                if self.cs is not None:
                    self.cs.value(0)
                self.spi.write(frame)
                if self.cs is not None:
                    self.cs.value(1)

    # framebuf API
    def fill(self, c):
        self.fb.fill(c)

    def pixel(self, x, y, c=None):
        return self.fb.pixel(x, y, c) if c is not None else self.fb.pixel(x, y)

    def text(self, s, x, y, c=1):
        self.fb.text(s, x, y, c)

    def line(self, x1, y1, x2, y2, c):
        self.fb.line(x1, y1, x2, y2, c)

    def rect(self, x, y, w, h, c):
        self.fb.rect(x, y, w, h, c)

    def fill_rect(self, x, y, w, h, c):
        self.fb.fill_rect(x, y, w, h, c)

    def hline(self, x, y, w, c):
        self.fb.hline(x, y, w, c)

    def vline(self, x, y, h, c):
        self.fb.vline(x, y, h, c)

    def scroll(self, dx, dy):
        self.fb.scroll(dx, dy)
`;var Nd=`# spidev: SPI on the Raspberry Pi header (SPI0: SCLK GPIO11, MOSI GPIO10, MISO GPIO9, CE0 GPIO8, CE1 GPIO7)
import _rpi_js as J

_PINS = {0: (11, 10), 1: (21, 20)}


class SpiDev:
    def __init__(self):
        self._bus = 0
        self._dev = 0
        self.max_speed_hz = 500000
        self.mode = 0
        self.bits_per_word = 8
        self.cshigh = False
        self._open = False

    def open(self, bus, device):
        if bus not in _PINS:
            raise FileNotFoundError(2, "No such file or directory")
        self._bus = bus
        self._dev = device
        self._open = True

    def close(self):
        self._open = False

    def _xfer(self, data):
        if not self._open:
            raise OSError(9, "Bad file descriptor")
        sck, mosi = _PINS[self._bus]
        r = J.spi_xfer(sck, mosi, bytes(data).hex())
        return list(bytes.fromhex(r))

    def xfer(self, data, speed_hz=0, delay_usec=0, bits_per_word=0):
        return self._xfer(data)

    def xfer2(self, data, speed_hz=0, delay_usec=0, bits_per_word=0):
        return self._xfer(data)

    def writebytes(self, data):
        self._xfer(data)

    writebytes2 = writebytes

    def readbytes(self, n):
        return self._xfer([0] * n)
`;var Dd="";var Id=`# RPLCD.i2c.CharLCD: HD44780 character LCD with a PCF8574 I2C backpack
#     from RPLCD.i2c import CharLCD
#     lcd = CharLCD('PCF8574', 0x27, cols=16, rows=2)
#     lcd.write_string("Hello"); lcd.cursor_pos = (1, 0); lcd.clear()
from i2c_lcd import I2cLcd


class CharLCD(I2cLcd):
    def __init__(self, i2c_expander='PCF8574', address=0x27, port=1, charmap='A02', cols=16, rows=2, **kw):
        I2cLcd.__init__(self, address, rows, cols)

    @property
    def backlight_enabled(self):
        return self._bl != 0

    @backlight_enabled.setter
    def backlight_enabled(self, on):
        if on:
            self.backlight_on()
        else:
            self.backlight_off()

    def create_char(self, location, bitmap):
        self.custom_char(location, bitmap)
`;var Ld=`from i2c_lcd import I2cLcd
`;var Qd=`from i2c_lcd import I2cLcd as LcdApi
`;var qd={"_rpi_hw.py":Bc,"time.py":$c,"random.py":Fc,"signal.py":Wc,"RPi/__init__.py":zc,"RPi/GPIO.py":jc,"gpiozero/__init__.py":Vc,"gpiozero/tones.py":Hc,"board.py":Uc,"adafruit_dht.py":Gc,"machine.py":Xc,"rp2.py":Jc,"network.py":Yc,"neopixel.py":Kc,"dht.py":Zc,"i2c_lcd.py":ed,"smbus2.py":td,"smbus.py":id,"serial.py":sd,"_netio.py":nd,"requests.py":rd,"urequests.py":od,"socket.py":cd,"urllib/__init__.py":ld,"urllib/parse.py":ad,"urllib/error.py":fd,"urllib/request.py":hd,"http/__init__.py":dd,"http/server.py":ud,"flask.py":pd,"paho/__init__.py":md,"paho/mqtt/__init__.py":gd,"paho/mqtt/client.py":_d,"paho/mqtt/publish.py":yd,"paho/mqtt/subscribe.py":bd,"umqtt/__init__.py":vd,"umqtt/simple.py":Od,"bisect.py":wd,"textwrap.py":kd,"contextlib.py":xd,"threading.py":Sd,"psutil.py":Td,"ntptime.py":Pd,"ssd1306.py":Cd,"adafruit_ssd1306.py":Ed,"busio.py":Ad,"tm1637.py":Rd,"max7219.py":Md,"spidev.py":Nd,"RPLCD/__init__.py":Dd,"RPLCD/i2c.py":Id,"pico_i2c_lcd.py":Ld,"lcd_api.py":Qd};var nt=se($i(),1),z2=se(ir(),1);var V=se(ii(),1),Jn=se(Qi(),1);var ot=se(ii(),1),Bd={30:"k",31:"r",32:"g",33:"y",34:"b",35:"m",36:"c",37:"w",90:"K",91:"R",92:"G",93:"Y",94:"B",95:"M",96:"C",97:"W"},cv=2500,bs=class{constructor({cls:e="",onKey:t,extraKeys:i=null,placeholder:s=""}={}){this.el=(0,ot.h)("div",{class:"con "+e}),this.scroller=(0,ot.h)("div",{class:"con-scroll"}),this.lines=(0,ot.h)("div",{class:"con-lines"}),this.prefix=(0,ot.h)("span",{class:"con-prefix"}),this.input=(0,ot.h)("input",{class:"con-input",type:"text",autocomplete:"off",autocapitalize:"off",autocorrect:"off",spellcheck:"false",enterkeyhint:"send",placeholder:s}),this.inrow=(0,ot.h)("div",{class:"con-inrow hidden"},this.prefix,this.input),this.scroller.append(this.lines,this.inrow),this.el.appendChild(this.scroller),i&&this.el.appendChild(this.keyBar(i)),this.cur=null,this.sgr="",this.history=[],this.hIdx=0,this.pending=null,this.onKey=t,this.input.addEventListener("keydown",r=>this.keydown(r)),this.scroller.addEventListener("click",r=>{!this.inrow.classList.contains("hidden")&&!window.getSelection().toString()&&r.target.closest(".con-scroll")&&this.focus()})}keyBar(e){let t=(0,ot.h)("div",{class:"con-keys"});for(let[i,s]of e){let r=(0,ot.h)("button",{class:"ck"},i);r.addEventListener("pointerdown",o=>o.preventDefault()),r.addEventListener("click",()=>s(this)),t.appendChild(r)}return t}focus(){try{this.input.focus({preventScroll:!0})}catch{this.input.focus()}}clear(){this.lines.innerHTML="",this.cur=null}newLine(){let e=(0,ot.h)("div",{class:"cl"});for(this.lines.appendChild(e);this.lines.childElementCount>cv;)this.lines.firstChild.remove();return e}write(e,t=""){if(!e)return;let i=this.atBottom(),s="",r=()=>{if(!s)return;this.cur||(this.cur=this.newLine());let o=[t,this.sgr].filter(Boolean).join(" "),l=this.cur.lastChild;if(l&&l.nodeType===1&&l.className===o)l.textContent+=s;else{let a=document.createElement("span");o&&(a.className=o),a.textContent=s,this.cur.appendChild(a)}s=""};for(let o=0;o<e.length;o++){let l=e[o];if(l===`
`)r(),this.cur||(this.cur=this.newLine()),this.cur.firstChild||(this.cur.innerHTML="&#8203;"),this.cur=null;else if(l==="\r"){if(e[o+1]===`
`)continue;r(),this.cur&&(this.cur.innerHTML="")}else if(l==="\b")r(),this.backspace();else if(l==="\x1B"&&e[o+1]==="["){r();let a=/^\x1b\[([\d;?]*)([A-Za-z])/.exec(e.slice(o));if(!a)continue;if(o+=a[0].length-1,a[2]==="m"){let f=a[1].split(";").filter(Boolean).map(Number);f.length||f.push(0);let c=new Set(this.sgr.split(" ").filter(Boolean));for(let u of f)if(u===0)c.clear();else if(u===1)c.add("bold");else if(Bd[u]){for(let p of[...c])p.startsWith("fg-")&&c.delete(p);c.add("fg-"+Bd[u])}this.sgr=[...c].join(" ")}else a[2]==="J"?this.clear():a[2]}else l==="\x07"||l==="\0"||(s+=l)}r(),i&&this.scrollEnd()}backspace(){if(!this.cur)return;let e=this.cur.lastChild;e&&(e.textContent=e.textContent.slice(0,-1),e.textContent||e.remove())}writeln(e="",t=""){this.write(e+`
`,t)}segs(e){for(let[t,i]of e)this.write(t,i||"")}atBottom(){let e=this.scroller;return e.scrollHeight-e.scrollTop-e.clientHeight<40}scrollEnd(){requestAnimationFrame(()=>{this.scroller.scrollTop=this.scroller.scrollHeight})}prompt(e="",t={}){if(this.pending){let s=this.pending;this.pending=null,s.resolve(null)}if(this.prefix.innerHTML="",this.cur&&this.cur.textContent){for(;this.cur.firstChild;)this.prefix.appendChild(this.cur.firstChild);this.cur.remove(),this.cur=null}let i=typeof e=="string"?[[e,""]]:e;for(let[s,r]of i){let o=document.createElement("span");r&&(o.className=r),o.textContent=s,this.prefix.appendChild(o)}return this.input.value=t.value||"",this.input.type=t.mask?"password":"text",this.inrow.classList.remove("hidden"),this.hIdx=this.history.length,this.keepHistory=t.keepHistory!==!1,this.scrollEnd(),t.focus!==!1&&this.focus(),new Promise(s=>{this.pending={resolve:s}})}get waiting(){return!!this.pending}submit(e=this.input.value){if(!this.pending)return;let t=this.pending;this.pending=null;let i=(0,ot.h)("div",{class:"cl"});for(;this.prefix.firstChild;)i.appendChild(this.prefix.firstChild);i.appendChild((0,ot.h)("span",{class:"con-typed"},this.input.type==="password"?"":e)),this.lines.appendChild(i),this.cur=null,this.inrow.classList.add("hidden"),this.input.value="",e.trim()&&this.keepHistory&&this.history[this.history.length-1]!==e&&this.history.push(e),this.scrollEnd(),t.resolve(e)}cancel(e="^C"){if(!this.pending)return!1;let t=this.pending;this.pending=null;let i=(0,ot.h)("div",{class:"cl"});for(;this.prefix.firstChild;)i.appendChild(this.prefix.firstChild);return i.appendChild((0,ot.h)("span",{},this.input.value+e)),this.lines.appendChild(i),this.cur=null,this.inrow.classList.add("hidden"),this.input.value="",t.resolve(null),!0}hideInput(){if(this.pending){let e=this.pending;this.pending=null,e.resolve(null)}this.inrow.classList.add("hidden")}keydown(e){if(this.onKey&&this.onKey(e,this)===!0){e.preventDefault();return}if(e.key==="Enter"){e.preventDefault(),this.submit();return}if(e.key==="ArrowUp"){e.preventDefault(),this.histMove(-1);return}e.key==="ArrowDown"&&(e.preventDefault(),this.histMove(1))}histMove(e){if(!this.history.length)return;this.hIdx=Math.max(0,Math.min(this.history.length,this.hIdx+e)),this.input.value=this.history[this.hIdx]||"";let t=this.input.value.length;requestAnimationFrame(()=>this.input.setSelectionRange(t,t))}insert(e){let t=this.input,i=t.selectionStart??t.value.length,s=t.selectionEnd??t.value.length;t.value=t.value.slice(0,i)+e+t.value.slice(s),t.setSelectionRange(i+e.length,i+e.length),this.focus()}};var bl=[],zd=[];(()=>{let n="lc,34,7n,7,7b,19,,,,2,,2,,,20,b,1c,l,g,,2t,7,2,6,2,2,,4,z,,u,r,2j,b,1m,9,9,,o,4,,9,,3,,5,17,3,1n,9,16,o,,x,1i,3,,i,,7,a,2,t,3,1k,,,7,2,2,2,3,9,,a,2,q,,2,3,1k,,,5,4,2,2,3,3,,u,2,3,,b,3,1k,,,8,,3,,3,k,2,m,6,,3,1k,,,7,2,2,2,3,7,3,a,2,u,,1n,5,3,3,,4,9,,14,5,1j,,,7,,3,,4,7,2,b,2,t,3,1k,,,7,,3,,4,7,2,b,2,f,,c,4,1j,2,,7,,3,,4,9,,a,2,t,3,1y,,4,6,,,,8,i,2,1p,,,8,c,8,2q,,,a,b,7,21,2,r,,,,,,4,2,1d,k,,2,5,b,,10,9,,2u,b,,6,n,4,4,3,g,4,d,,,3,6,,f,,jj,3,qa,4,s,3,t,2,u,2,1s,w,9,,19,3,,,39,2,y,,3a,c,4,c,63,5,1l,a,,,,,2,o,2,,1c,1a,2,c,k,5,1b,h,12,9,c,3,u,d,1k,e,1c,k,48,3,,l,4,,6,,2,3,5i,1s,ek,,5f,x,2da,3,3x,,2o,w,fe,6,2x,2,n9w,4,,a,w,2,28,2,7k,,3,,4,,n,5,4,,2b,2,1e,i,q,i,d,,12,8,p,d,18,4,1b,e,10,,1v,e,c,,8,2,1a,,1f,,,3,2,2,5,2,,,15,5,5,2,6k,8,,2,fn4,,kh,g,g,g,a6,2,gt,,6a,,45,5,1ae,3,,2,5,4,14,3,4,,4l,2,fx,4,1t,5,8t,2,25,6,1y,b,1d,4,3e,3,1h,f,15,,2,2,a,4,19,b,7,,1p,3,10,e,g,2,18,,c,3,1c,e,8,4,,2,2k,c,6,,2,,4d,c,l,4,1j,2,,7,2,2,2,3,9,,a,2,2,7,3,5,1v,9,,,2,,,4,,5,,,e,2,2a,i,n,,29,k,6j,7,2,9,r,2,2a,h,2y,d,2t,3,2,a,74,f,6t,6,,2,2,4,,,,2,3x,7,2,7,3,,s,a,14,7,,4,8,,9,b,1a,g,5i,8,5j,8,,8,2a,m,,e,3e,6,3,,,2,,7,,,1u,5,,2,,5,9n,4,9,2,,,1c,7,3,5,n,,44l,,6,f,8ug,i,1xc,5,1n,7,t4,,,1j,7,4,29,,b,2,f57,2,3mp,1a,2,n,f2,5,3,6,8,8,2,7,u,4,44,3,1iz,1j,4,1e,8,,e,,m,5,,f,11s,7,,h,2,7,,2,,5,2s,,4g,7,af,,1p,4,e4,4,72,2,6r,,2,,7,2,5,,d6,7,31,7,240,5".split(",").map(e=>e?parseInt(e,36):1);for(let e=0,t=0;e<n.length;e++)(e%2?zd:bl).push(t=t+n[e])})();function dv(n){if(n<768)return!1;for(let e=0,t=bl.length;;){let i=e+t>>1;if(n<bl[i])t=i;else if(n>=zd[i])e=i+1;else return!0;if(e==t)return!1}}function $d(n){return n>=127462&&n<=127487}var Fd=8205;function jd(n,e,t=!0,i=!0){return(t?Vd:uv)(n,e,i)}function Vd(n,e,t){if(e==n.length)return e;e&&Hd(n.charCodeAt(e))&&Ud(n.charCodeAt(e-1))&&e--;let i=yl(n,e);for(e+=Wd(i);e<n.length;){let s=yl(n,e);if(i==Fd||s==Fd||t&&dv(s))e+=Wd(s),i=s;else if($d(s)){let r=0,o=e-2;for(;o>=0&&$d(yl(n,o));)r++,o-=2;if(r%2==0)break;e+=2}else break}return e}function uv(n,e,t){for(;e>1;){let i=Vd(n,e-2,t);if(i<e)return i;e--}return 0}function yl(n,e){let t=n.charCodeAt(e);if(!Ud(t)||e+1==n.length)return t;let i=n.charCodeAt(e+1);return Hd(i)?(t-55296<<10)+(i-56320)+65536:t}function Hd(n){return n>=56320&&n<57344}function Ud(n){return n>=55296&&n<56320}function Wd(n){return n<65536?1:2}var oe=class n{lineAt(e){if(e<0||e>this.length)throw new RangeError(`Invalid position ${e} in document of length ${this.length}`);return this.lineInner(e,!1,1,0)}line(e){if(e<1||e>this.lines)throw new RangeError(`Invalid line number ${e} in ${this.lines}-line document`);return this.lineInner(e,!0,1,0)}replace(e,t,i){[e,t]=xs(this,e,t);let s=[];return this.decompose(0,e,s,2),i.length&&i.decompose(0,i.length,s,3),this.decompose(t,this.length,s,1),Os.from(s,this.length-(t-e)+i.length)}append(e){return this.replace(this.length,this.length,e)}slice(e,t=this.length){[e,t]=xs(this,e,t);let i=[];return this.decompose(e,t,i,0),Os.from(i,t-e)}eq(e){if(e==this)return!0;if(e.length!=this.length||e.lines!=this.lines)return!1;let t=this.scanIdentical(e,1),i=this.length-this.scanIdentical(e,-1),s=new ji(this),r=new ji(e);for(let o=t,l=t;;){if(s.next(o),r.next(o),o=0,s.lineBreak!=r.lineBreak||s.done!=r.done||s.value!=r.value)return!1;if(l+=s.value.length,s.done||l>=i)return!0}}iter(e=1){return new ji(this,e)}iterRange(e,t=this.length){return new dr(this,e,t)}iterLines(e,t){let i;if(e==null)i=this.iter();else{t==null&&(t=this.lines+1);let s=this.line(e).from;i=this.iterRange(s,Math.max(s,t==this.lines+1?this.length:t<=1?0:this.line(t-1).to))}return new ur(i)}toString(){return this.sliceString(0)}toJSON(){let e=[];return this.flatten(e),e}constructor(){}static of(e){if(e.length==0)throw new RangeError("A document must have at least one line");return e.length==1&&!e[0]?n.empty:e.length<=32?new ht(e):Os.from(ht.split(e,[]))}},ht=class n extends oe{constructor(e,t=pv(e)){super(),this.text=e,this.length=t}get lines(){return this.text.length}get children(){return null}lineInner(e,t,i,s){for(let r=0;;r++){let o=this.text[r],l=s+o.length;if((t?i:l)>=e)return new Ol(s,l,i,o);s=l+1,i++}}decompose(e,t,i,s){let r=e<=0&&t>=this.length?this:new n(Gd(this.text,e,t),Math.min(t,this.length)-Math.max(0,e));if(s&1){let o=i.pop(),l=cr(r.text,o.text.slice(),0,r.length);if(l.length<=32)i.push(new n(l,o.length+r.length));else{let a=l.length>>1;i.push(new n(l.slice(0,a)),new n(l.slice(a)))}}else i.push(r)}replace(e,t,i){if(!(i instanceof n))return super.replace(e,t,i);[e,t]=xs(this,e,t);let s=cr(this.text,cr(i.text,Gd(this.text,0,e)),t),r=this.length+i.length-(t-e);return s.length<=32?new n(s,r):Os.from(n.split(s,[]),r)}sliceString(e,t=this.length,i=`
`){[e,t]=xs(this,e,t);let s="";for(let r=0,o=0;r<=t&&o<this.text.length;o++){let l=this.text[o],a=r+l.length;r>e&&o&&(s+=i),e<a&&t>r&&(s+=l.slice(Math.max(0,e-r),t-r)),r=a+1}return s}flatten(e){for(let t of this.text)e.push(t)}scanIdentical(){return 0}static split(e,t){let i=[],s=-1;for(let r of e)i.push(r),s+=r.length+1,i.length==32&&(t.push(new n(i,s)),i=[],s=-1);return s>-1&&t.push(new n(i,s)),t}},Os=class n extends oe{constructor(e,t){super(),this.children=e,this.length=t,this.lines=0;for(let i of e)this.lines+=i.lines}lineInner(e,t,i,s){for(let r=0;;r++){let o=this.children[r],l=s+o.length,a=i+o.lines-1;if((t?a:l)>=e)return o.lineInner(e,t,i,s);s=l+1,i=a+1}}decompose(e,t,i,s){for(let r=0,o=0;o<=t&&r<this.children.length;r++){let l=this.children[r],a=o+l.length;if(e<=a&&t>=o){let f=s&((o<=e?1:0)|(a>=t?2:0));o>=e&&a<=t&&!f?i.push(l):l.decompose(e-o,t-o,i,f)}o=a+1}}replace(e,t,i){if([e,t]=xs(this,e,t),i.lines<this.lines)for(let s=0,r=0;s<this.children.length;s++){let o=this.children[s],l=r+o.length;if(e>=r&&t<=l){let a=o.replace(e-r,t-r,i),f=this.lines-o.lines+a.lines;if(a.lines<f>>4&&a.lines>f>>6){let c=this.children.slice();return c[s]=a,new n(c,this.length-(t-e)+i.length)}return super.replace(r,l,a)}r=l+1}return super.replace(e,t,i)}sliceString(e,t=this.length,i=`
`){[e,t]=xs(this,e,t);let s="";for(let r=0,o=0;r<this.children.length&&o<=t;r++){let l=this.children[r],a=o+l.length;o>e&&r&&(s+=i),e<a&&t>o&&(s+=l.sliceString(e-o,t-o,i)),o=a+1}return s}flatten(e){for(let t of this.children)t.flatten(e)}scanIdentical(e,t){if(!(e instanceof n))return 0;let i=0,[s,r,o,l]=t>0?[0,0,this.children.length,e.children.length]:[this.children.length-1,e.children.length-1,-1,-1];for(;;s+=t,r+=t){if(s==o||r==l)return i;let a=this.children[s],f=e.children[r];if(a!=f)return i+a.scanIdentical(f,t);i+=a.length+1}}static from(e,t=e.reduce((i,s)=>i+s.length+1,-1)){let i=0;for(let y of e)i+=y.lines;if(i<32){let y=[];for(let v of e)v.flatten(y);return new ht(y,t)}let s=Math.max(32,i>>5),r=s<<1,o=s>>1,l=[],a=0,f=-1,c=[];function u(y){let v;if(y.lines>r&&y instanceof n)for(let b of y.children)u(b);else y.lines>o&&(a>o||!a)?(p(),l.push(y)):y instanceof ht&&a&&(v=c[c.length-1])instanceof ht&&y.lines+v.lines<=32?(a+=y.lines,f+=y.length+1,c[c.length-1]=new ht(v.text.concat(y.text),v.length+1+y.length)):(a+y.lines>s&&p(),a+=y.lines,f+=y.length+1,c.push(y))}function p(){a!=0&&(l.push(c.length==1?c[0]:n.from(c,f)),f=-1,a=c.length=0)}for(let y of e)u(y);return p(),l.length==1?l[0]:new n(l,t)}};oe.empty=new ht([""],0);function pv(n){let e=-1;for(let t of n)e+=t.length+1;return e}function cr(n,e,t=0,i=1e9){for(let s=0,r=0,o=!0;r<n.length&&s<=i;r++){let l=n[r],a=s+l.length;a>=t&&(a>i&&(l=l.slice(0,i-s)),s<t&&(l=l.slice(t-s)),o?(e[e.length-1]+=l,o=!1):e.push(l)),s=a+1}return e}function Gd(n,e,t){return cr(n,[""],e,t)}var ji=class{constructor(e,t=1){this.dir=t,this.done=!1,this.lineBreak=!1,this.value="",this.nodes=[e],this.offsets=[t>0?1:(e instanceof ht?e.text.length:e.children.length)<<1]}nextInner(e,t){for(this.done=this.lineBreak=!1;;){let i=this.nodes.length-1,s=this.nodes[i],r=this.offsets[i],o=r>>1,l=s instanceof ht?s.text.length:s.children.length;if(o==(t>0?l:0)){if(i==0)return this.done=!0,this.value="",this;t>0&&this.offsets[i-1]++,this.nodes.pop(),this.offsets.pop()}else if((r&1)==(t>0?0:1)){if(this.offsets[i]+=t,e==0)return this.lineBreak=!0,this.value=`
`,this;e--}else if(s instanceof ht){let a=s.text[o+(t<0?-1:0)];if(this.offsets[i]+=t,a.length>Math.max(0,e))return this.value=e==0?a:t>0?a.slice(e):a.slice(0,a.length-e),this;e-=a.length}else{let a=s.children[o+(t<0?-1:0)];e>a.length?(e-=a.length,this.offsets[i]+=t):(t<0&&this.offsets[i]--,this.nodes.push(a),this.offsets.push(t>0?1:(a instanceof ht?a.text.length:a.children.length)<<1))}}}next(e=0){return e<0&&(this.nextInner(-e,-this.dir),e=this.value.length),this.nextInner(e,this.dir)}},dr=class{constructor(e,t,i){this.value="",this.done=!1,this.cursor=new ji(e,t>i?-1:1),this.pos=t>i?e.length:0,this.from=Math.min(t,i),this.to=Math.max(t,i)}nextInner(e,t){if(t<0?this.pos<=this.from:this.pos>=this.to)return this.value="",this.done=!0,this;e+=Math.max(0,t<0?this.pos-this.to:this.from-this.pos);let i=t<0?this.pos-this.from:this.to-this.pos;e>i&&(e=i),i-=e;let{value:s}=this.cursor.next(e);return this.pos+=(s.length+e)*t,this.value=s.length<=i?s:t<0?s.slice(s.length-i):s.slice(0,i),this.done=!this.value,this}next(e=0){return e<0?e=Math.max(e,this.from-this.pos):e>0&&(e=Math.min(e,this.to-this.pos)),this.nextInner(e,this.cursor.dir)}get lineBreak(){return this.cursor.lineBreak&&this.value!=""}},ur=class{constructor(e){this.inner=e,this.afterBreak=!0,this.value="",this.done=!1}next(e=0){let{done:t,lineBreak:i,value:s}=this.inner.next(e);return t&&this.afterBreak?(this.value="",this.afterBreak=!1):t?(this.done=!0,this.value=""):i?this.afterBreak?this.value="":(this.afterBreak=!0,this.next()):(this.value=s,this.afterBreak=!1),this}get lineBreak(){return!1}};typeof Symbol<"u"&&(oe.prototype[Symbol.iterator]=function(){return this.iter()},ji.prototype[Symbol.iterator]=dr.prototype[Symbol.iterator]=ur.prototype[Symbol.iterator]=function(){return this});var Ol=class{constructor(e,t,i,s){this.from=e,this.to=t,this.number=i,this.text=s}get length(){return this.to-this.from}};function xs(n,e,t){return e=Math.max(0,Math.min(n.length,e)),[e,Math.max(e,Math.min(n.length,t))]}function Ee(n,e,t=!0,i=!0){return jd(n,e,t,i)}function mv(n){return n>=56320&&n<57344}function gv(n){return n>=55296&&n<56320}function Ge(n,e){let t=n.charCodeAt(e);if(!gv(t)||e+1==n.length)return t;let i=n.charCodeAt(e+1);return mv(i)?(t-55296<<10)+(i-56320)+65536:t}function cn(n){return n<=65535?String.fromCharCode(n):(n-=65536,String.fromCharCode((n>>10)+55296,(n&1023)+56320))}function ct(n){return n<65536?1:2}var wl=/\r\n?|\n/,Le=function(n){return n[n.Simple=0]="Simple",n[n.TrackDel=1]="TrackDel",n[n.TrackBefore=2]="TrackBefore",n[n.TrackAfter=3]="TrackAfter",n}(Le||(Le={})),si=class n{constructor(e){this.sections=e}get length(){let e=0;for(let t=0;t<this.sections.length;t+=2)e+=this.sections[t];return e}get newLength(){let e=0;for(let t=0;t<this.sections.length;t+=2){let i=this.sections[t+1];e+=i<0?this.sections[t]:i}return e}get empty(){return this.sections.length==0||this.sections.length==2&&this.sections[1]<0}iterGaps(e){for(let t=0,i=0,s=0;t<this.sections.length;){let r=this.sections[t++],o=this.sections[t++];o<0?(e(i,s,r),s+=r):s+=o,i+=r}}iterChangedRanges(e,t=!1){kl(this,e,t)}get invertedDesc(){let e=[];for(let t=0;t<this.sections.length;){let i=this.sections[t++],s=this.sections[t++];s<0?e.push(i,s):e.push(s,i)}return new n(e)}composeDesc(e){return this.empty?e:e.empty?this:Zd(this,e)}mapDesc(e,t=!1){return e.empty?this:xl(this,e,t)}mapPos(e,t=-1,i=Le.Simple){let s=0,r=0;for(let o=0;o<this.sections.length;){let l=this.sections[o++],a=this.sections[o++],f=s+l;if(a<0){if(f>e)return r+(e-s);r+=l}else{if(i!=Le.Simple&&f>=e&&(i==Le.TrackDel&&s<e&&f>e||i==Le.TrackBefore&&s<e||i==Le.TrackAfter&&f>e))return null;if(f>e||f==e&&t<0&&!l)return e==s||t<0?r:r+a;r+=a}s=f}if(e>s)throw new RangeError(`Position ${e} is out of range for changeset of length ${s}`);return r}touchesRange(e,t=e){for(let i=0,s=0;i<this.sections.length&&s<=t;){let r=this.sections[i++],o=this.sections[i++],l=s+r;if(o>=0&&s<=t&&l>=e)return s<e&&l>t?"cover":!0;s=l}return!1}toString(){let e="";for(let t=0;t<this.sections.length;){let i=this.sections[t++],s=this.sections[t++];e+=(e?" ":"")+i+(s>=0?":"+s:"")}return e}toJSON(){return this.sections}static fromJSON(e){if(!Array.isArray(e)||e.length%2||e.some(t=>typeof t!="number"))throw new RangeError("Invalid JSON representation of ChangeDesc");return new n(e)}static create(e){return new n(e)}},Ze=class n extends si{constructor(e,t){super(e),this.inserted=t}apply(e){if(this.length!=e.length)throw new RangeError("Applying change set to a document with the wrong length");return kl(this,(t,i,s,r,o)=>e=e.replace(s,s+(i-t),o),!1),e}mapDesc(e,t=!1){return xl(this,e,t,!0)}invert(e){let t=this.sections.slice(),i=[];for(let s=0,r=0;s<t.length;s+=2){let o=t[s],l=t[s+1];if(l>=0){t[s]=l,t[s+1]=o;let a=s>>1;for(;i.length<a;)i.push(oe.empty);i.push(o?e.slice(r,r+o):oe.empty)}r+=o}return new n(t,i)}compose(e){return this.empty?e:e.empty?this:Zd(this,e,!0)}map(e,t=!1){return e.empty?this:xl(this,e,t,!0)}iterChanges(e,t=!1){kl(this,e,t)}get desc(){return si.create(this.sections)}filter(e){let t=[],i=[],s=[],r=new Vi(this);e:for(let o=0,l=0;;){let a=o==e.length?1e9:e[o++];for(;l<a||l==a&&r.len==0;){if(r.done)break e;let c=Math.min(r.len,a-l);Ue(s,c,-1);let u=r.ins==-1?-1:r.off==0?r.ins:0;Ue(t,c,u),u>0&&yi(i,t,r.text),r.forward(c),l+=c}let f=e[o++];for(;l<f;){if(r.done)break e;let c=Math.min(r.len,f-l);Ue(t,c,-1),Ue(s,c,r.ins==-1?-1:r.off==0?r.ins:0),r.forward(c),l+=c}}return{changes:new n(t,i),filtered:si.create(s)}}toJSON(){let e=[];for(let t=0;t<this.sections.length;t+=2){let i=this.sections[t],s=this.sections[t+1];s<0?e.push(i):s==0?e.push([i]):e.push([i].concat(this.inserted[t>>1].toJSON()))}return e}static of(e,t,i){let s=[],r=[],o=0,l=null;function a(c=!1){if(!c&&!s.length)return;o<t&&Ue(s,t-o,-1);let u=new n(s,r);l=l?l.compose(u.map(l)):u,s=[],r=[],o=0}function f(c){if(Array.isArray(c))for(let u of c)f(u);else if(c instanceof n){if(c.length!=t)throw new RangeError(`Mismatched change set length (got ${c.length}, expected ${t})`);a(),l=l?l.compose(c.map(l)):c}else{let{from:u,to:p=u,insert:y}=c;if(u>p||u<0||p>t)throw new RangeError(`Invalid change range ${u} to ${p} (in doc of length ${t})`);let v=y?typeof y=="string"?oe.of(y.split(i||wl)):y:oe.empty,b=v.length;if(u==p&&b==0)return;u<o&&a(),u>o&&Ue(s,u-o,-1),Ue(s,p-u,b),yi(r,s,v),o=p}}return f(e),a(!l),l}static empty(e){return new n(e?[e,-1]:[],[])}static fromJSON(e){if(!Array.isArray(e))throw new RangeError("Invalid JSON representation of ChangeSet");let t=[],i=[];for(let s=0;s<e.length;s++){let r=e[s];if(typeof r=="number")t.push(r,-1);else{if(!Array.isArray(r)||typeof r[0]!="number"||r.some((o,l)=>l&&typeof o!="string"))throw new RangeError("Invalid JSON representation of ChangeSet");if(r.length==1)t.push(r[0],0);else{for(;i.length<s;)i.push(oe.empty);i[s]=oe.of(r.slice(1)),t.push(r[0],i[s].length)}}}return new n(t,i)}static createSet(e,t){return new n(e,t)}};function Ue(n,e,t,i=!1){if(e==0&&t<=0)return;let s=n.length-2;s>=0&&t<=0&&t==n[s+1]?n[s]+=e:s>=0&&e==0&&n[s]==0?n[s+1]+=t:i?(n[s]+=e,n[s+1]+=t):n.push(e,t)}function yi(n,e,t){if(t.length==0)return;let i=e.length-2>>1;if(i<n.length)n[n.length-1]=n[n.length-1].append(t);else{for(;n.length<i;)n.push(oe.empty);n.push(t)}}function kl(n,e,t){let i=n.inserted;for(let s=0,r=0,o=0;o<n.sections.length;){let l=n.sections[o++],a=n.sections[o++];if(a<0)s+=l,r+=l;else{let f=s,c=r,u=oe.empty;for(;f+=l,c+=a,a&&i&&(u=u.append(i[o-2>>1])),!(t||o==n.sections.length||n.sections[o+1]<0);)l=n.sections[o++],a=n.sections[o++];e(s,f,r,c,u),s=f,r=c}}}function xl(n,e,t,i=!1){let s=[],r=i?[]:null,o=new Vi(n),l=new Vi(e);for(let a=-1;;){if(o.done&&l.len||l.done&&o.len)throw new Error("Mismatched change set lengths");if(o.ins==-1&&l.ins==-1){let f=Math.min(o.len,l.len);Ue(s,f,-1),o.forward(f),l.forward(f)}else if(l.ins>=0&&(o.ins<0||a==o.i||o.off==0&&(l.len<o.len||l.len==o.len&&!t))){let f=l.len;for(Ue(s,l.ins,-1);f;){let c=Math.min(o.len,f);o.ins>=0&&a<o.i&&o.len<=c&&(Ue(s,0,o.ins),r&&yi(r,s,o.text),a=o.i),o.forward(c),f-=c}l.next()}else if(o.ins>=0){let f=0,c=o.len;for(;c;)if(l.ins==-1){let u=Math.min(c,l.len);f+=u,c-=u,l.forward(u)}else if(l.ins==0&&l.len<c)c-=l.len,l.next();else break;Ue(s,f,a<o.i?o.ins:0),r&&a<o.i&&yi(r,s,o.text),a=o.i,o.forward(o.len-c)}else{if(o.done&&l.done)return r?Ze.createSet(s,r):si.create(s);throw new Error("Mismatched change set lengths")}}}function Zd(n,e,t=!1){let i=[],s=t?[]:null,r=new Vi(n),o=new Vi(e);for(let l=!1;;){if(r.done&&o.done)return s?Ze.createSet(i,s):si.create(i);if(r.ins==0)Ue(i,r.len,0,l),r.next();else if(o.len==0&&!o.done)Ue(i,0,o.ins,l),s&&yi(s,i,o.text),o.next();else{if(r.done||o.done)throw new Error("Mismatched change set lengths");{let a=Math.min(r.len2,o.len),f=i.length;if(r.ins==-1){let c=o.ins==-1?-1:o.off?0:o.ins;Ue(i,a,c,l),s&&c&&yi(s,i,o.text)}else o.ins==-1?(Ue(i,r.off?0:r.len,a,l),s&&yi(s,i,r.textBit(a))):(Ue(i,r.off?0:r.len,o.off?0:o.ins,l),s&&!o.off&&yi(s,i,o.text));l=(r.ins>a||o.ins>=0&&o.len>a)&&(l||i.length>f),r.forward2(a),o.forward(a)}}}}var Vi=class{constructor(e){this.set=e,this.i=0,this.next()}next(){let{sections:e}=this.set;this.i<e.length?(this.len=e[this.i++],this.ins=e[this.i++]):(this.len=0,this.ins=-2),this.off=0}get done(){return this.ins==-2}get len2(){return this.ins<0?this.len:this.ins}get text(){let{inserted:e}=this.set,t=this.i-2>>1;return t>=e.length?oe.empty:e[t]}textBit(e){let{inserted:t}=this.set,i=this.i-2>>1;return i>=t.length&&!e?oe.empty:t[i].slice(this.off,e==null?void 0:this.off+e)}forward(e){e==this.len?this.next():(this.len-=e,this.off+=e)}forward2(e){this.ins==-1?this.forward(e):e==this.ins?this.next():(this.ins-=e,this.off+=e)}},Fi=class n{constructor(e,t,i,s){this.from=e,this.to=t,this.flags=i,this.goalColumn=s}get anchor(){return this.flags&32?this.to:this.from}get head(){return this.flags&32?this.from:this.to}get empty(){return this.from==this.to}get assoc(){return this.flags&8?-1:this.flags&16?1:0}get undirectional(){return(this.flags&64)>0}get bidiLevel(){let e=this.flags&7;return e==7?null:e}map(e,t=-1){let i,s;return this.empty?i=s=e.mapPos(this.from,t):(i=e.mapPos(this.from,1),s=e.mapPos(this.to,-1)),i==this.from&&s==this.to?this:new n(i,s,this.flags,this.goalColumn)}extend(e,t=e,i=0){if(e<=this.anchor&&t>=this.anchor)return M.range(e,t,void 0,void 0,i);let s=Math.abs(e-this.anchor)>Math.abs(t-this.anchor)?e:t;return M.range(this.anchor,s,void 0,void 0,i)}eq(e,t=!1){return this.anchor==e.anchor&&this.head==e.head&&this.goalColumn==e.goalColumn&&(!t||!this.empty||this.assoc==e.assoc)}toJSON(){return{anchor:this.anchor,head:this.head}}static fromJSON(e){if(!e||typeof e.anchor!="number"||typeof e.head!="number")throw new RangeError("Invalid JSON representation for SelectionRange");return M.range(e.anchor,e.head)}static create(e,t,i,s){return new n(e,t,i,s)}},M=class n{constructor(e,t){this.ranges=e,this.mainIndex=t}map(e,t=-1){return e.empty?this:n.create(this.ranges.map(i=>i.map(e,t)),this.mainIndex)}eq(e,t=!1){if(this.ranges.length!=e.ranges.length||this.mainIndex!=e.mainIndex)return!1;for(let i=0;i<this.ranges.length;i++)if(!this.ranges[i].eq(e.ranges[i],t))return!1;return!0}get main(){return this.ranges[this.mainIndex]}asSingle(){return this.ranges.length==1?this:new n([this.main],0)}addRange(e,t=!0){return n.create([e].concat(this.ranges),t?0:this.mainIndex+1)}replaceRange(e,t=this.mainIndex){let i=this.ranges.slice();return i[t]=e,n.create(i,this.mainIndex)}toJSON(){return{ranges:this.ranges.map(e=>e.toJSON()),main:this.mainIndex}}static fromJSON(e){if(!e||!Array.isArray(e.ranges)||typeof e.main!="number"||e.main>=e.ranges.length)throw new RangeError("Invalid JSON representation for EditorSelection");return new n(e.ranges.map(t=>Fi.fromJSON(t)),e.main)}static single(e,t=e){return new n([n.range(e,t)],0)}static create(e,t=0){if(e.length==0)throw new RangeError("A selection needs at least one range");for(let i=0,s=0;s<e.length;s++){let r=e[s];if(r.empty?r.from<=i:r.from<i)return n.normalized(e.slice(),t);i=r.to}return new n(e,t)}static cursor(e,t=0,i,s){return Fi.create(e,e,(t==0?0:t<0?8:16)|(i==null?7:Math.min(6,i)),s)}static range(e,t,i,s,r){let o=s==null?7:Math.min(6,s);return!r&&e!=t&&(r=t<e?1:-1),r&&(o|=r<0?8:16),t<e?Fi.create(t,e,o|32,i):Fi.create(e,t,o,i)}static undirectionalRange(e,t){return Fi.create(e,t,64,void 0)}static normalized(e,t=0){let i=e[t];e.sort((s,r)=>s.from-r.from),t=e.indexOf(i);for(let s=1;s<e.length;s++){let r=e[s],o=e[s-1];if(r.empty?r.from<=o.to:r.from<o.to){let l=o.from,a=Math.max(r.to,o.to);s<=t&&t--,e.splice(--s,2,r.anchor>r.head?n.range(a,l):n.range(l,a))}}return new n(e,t)}};function eu(n,e){for(let t of n.ranges)if(t.to>e)throw new RangeError("Selection points outside of document")}var Dl=0,W=class n{constructor(e,t,i,s,r){this.combine=e,this.compareInput=t,this.compare=i,this.isStatic=s,this.id=Dl++,this.default=e([]),this.extensions=typeof r=="function"?r(this):r}get reader(){return this}static define(e={}){return new n(e.combine||(t=>t),e.compareInput||((t,i)=>t===i),e.compare||(e.combine?(t,i)=>t===i:Il),!!e.static,e.enables)}of(e){return new ws([],this,0,e)}compute(e,t){if(this.isStatic)throw new Error("Can't compute a static facet");return new ws(e,this,1,t)}computeN(e,t){if(this.isStatic)throw new Error("Can't compute a static facet");return new ws(e,this,2,t)}from(e,t){return t||(t=i=>i),this.compute([e],i=>t(i.field(e)))}};function Il(n,e){return n==e||n.length==e.length&&n.every((t,i)=>t===e[i])}var ws=class{constructor(e,t,i,s){this.dependencies=e,this.facet=t,this.type=i,this.value=s,this.id=Dl++}dynamicSlot(e){var t;let i=this.value,s=this.facet.compareInput,r=this.id,o=e[r]>>1,l=this.type==2,a=!1,f=!1,c=[];for(let u of this.dependencies)u=="doc"?a=!0:u=="selection"?f=!0:((t=e[u.id])!==null&&t!==void 0?t:1)&1||c.push(e[u.id]);return{create(u){return u.values[o]=i(u),1},update(u,p){if(a&&p.docChanged||f&&(p.docChanged||p.selection)||Sl(u,c)){let y=i(u);if(l?!Xd(y,u.values[o],s):!s(y,u.values[o]))return u.values[o]=y,1}return 0},reconfigure:(u,p)=>{let y,v=p.config.address[r];if(v!=null){let b=gr(p,v);if(this.dependencies.every(O=>O instanceof W?p.facet(O)===u.facet(O):O instanceof Qe?p.field(O,!1)==u.field(O,!1):!0)||(l?Xd(y=i(u),b,s):s(y=i(u),b)))return u.values[o]=b,0}else y=i(u);return u.values[o]=y,1}}}get extension(){return this}};function Xd(n,e,t){if(n.length!=e.length)return!1;for(let i=0;i<n.length;i++)if(!t(n[i],e[i]))return!1;return!0}function Sl(n,e){let t=!1;for(let i of e)ln(n,i)&1&&(t=!0);return t}function _v(n,e,t){let i=t.map(a=>n[a.id]),s=t.map(a=>a.type),r=i.filter(a=>!(a&1)),o=n[e.id]>>1;function l(a){let f=[];for(let c=0;c<i.length;c++){let u=gr(a,i[c]);if(s[c]==2)for(let p of u)f.push(p);else f.push(u)}return e.combine(f)}return{create(a){for(let f of i)ln(a,f);return a.values[o]=l(a),1},update(a,f){if(!Sl(a,r))return 0;let c=l(a);return e.compare(c,a.values[o])?0:(a.values[o]=c,1)},reconfigure(a,f){let c=Sl(a,i),u=f.config.facets[e.id],p=f.facet(e);if(u&&!c&&Il(t,u))return a.values[o]=p,0;let y=l(a);return e.compare(y,p)?(a.values[o]=p,0):(a.values[o]=y,1)}}}var ar=W.define({static:!0}),Qe=class n{constructor(e,t,i,s,r){this.id=e,this.createF=t,this.updateF=i,this.compareF=s,this.spec=r,this.provides=void 0}static define(e){let t=new n(Dl++,e.create,e.update,e.compare||((i,s)=>i===s),e);return e.provide&&(t.provides=e.provide(t)),t}create(e){let t=e.facet(ar).find(i=>i.field==this);return((t==null?void 0:t.create)||this.createF)(e)}slot(e){let t=e[this.id]>>1;return{create:i=>(i.values[t]=this.create(i),1),update:(i,s)=>{let r=i.values[t],o=this.updateF(r,s);return this.compareF(r,o)?0:(i.values[t]=o,1)},reconfigure:(i,s)=>{let r=i.facet(ar),o=s.facet(ar),l;return(l=r.find(a=>a.field==this))&&l!=o.find(a=>a.field==this)?(i.values[t]=l.create(i),1):s.config.address[this.id]!=null?(i.values[t]=s.field(this),0):(i.values[t]=this.create(i),1)}}}init(e){return[this,ar.of({field:this,create:e})]}get extension(){return this}},Wi={lowest:4,low:3,default:2,high:1,highest:0};function on(n){return e=>new pr(e,n)}var Ot={highest:on(Wi.highest),high:on(Wi.high),default:on(Wi.default),low:on(Wi.low),lowest:on(Wi.lowest)},pr=class{constructor(e,t){this.inner=e,this.prec=t}get extension(){return this}},Ss=class n{of(e){return new an(this,e)}reconfigure(e){return n.reconfigure.of({compartment:this,extension:e})}get(e){return e.config.compartments.get(this)}},an=class{constructor(e,t){this.compartment=e,this.inner=t}get extension(){return this}},mr=class n{constructor(e,t,i,s,r,o){for(this.base=e,this.compartments=t,this.dynamicSlots=i,this.address=s,this.staticValues=r,this.facets=o,this.statusTemplate=[];this.statusTemplate.length<i.length;)this.statusTemplate.push(0)}staticFacet(e){let t=this.address[e.id];return t==null?e.default:this.staticValues[t>>1]}static resolve(e,t,i){let s=[],r=Object.create(null),o=new Map;for(let p of yv(e,t,o))p instanceof Qe?s.push(p):(r[p.facet.id]||(r[p.facet.id]=[])).push(p);let l=Object.create(null),a=[],f=[];for(let p of s)l[p.id]=f.length<<1,f.push(y=>p.slot(y));let c=i==null?void 0:i.config.facets;for(let p in r){let y=r[p],v=y[0].facet,b=c&&c[p]||[];if(y.every(O=>O.type==0))if(l[v.id]=a.length<<1|1,Il(b,y))a.push(i.facet(v));else{let O=v.combine(y.map(k=>k.value));a.push(i&&v.compare(O,i.facet(v))?i.facet(v):O)}else{for(let O of y)O.type==0?(l[O.id]=a.length<<1|1,a.push(O.value)):(l[O.id]=f.length<<1,f.push(k=>O.dynamicSlot(k)));l[v.id]=f.length<<1,f.push(O=>_v(O,v,y))}}let u=f.map(p=>p(l));return new n(e,o,u,l,a,r)}};function yv(n,e,t){let i=[[],[],[],[],[]],s=new Map;function r(o,l){let a=s.get(o);if(a!=null){if(a<=l)return;let f=i[a].indexOf(o);f>-1&&i[a].splice(f,1),o instanceof an&&t.delete(o.compartment)}if(s.set(o,l),Array.isArray(o))for(let f of o)r(f,l);else if(o instanceof an){if(t.has(o.compartment))throw new RangeError("Duplicate use of compartment in extensions");let f=e.get(o.compartment)||o.inner;t.set(o.compartment,f),r(f,l)}else if(o instanceof pr)r(o.inner,o.prec);else if(o instanceof Qe)i[l].push(o),o.provides&&r(o.provides,l);else if(o instanceof ws)i[l].push(o),o.facet.extensions&&r(o.facet.extensions,Wi.default);else{let f=o.extension;if(!f)throw new Error(`Unrecognized extension value in extension set (${o}).`);if(f==o)throw new Error(`Unrecognized extension value in extension set (${o}). This sometimes happens because multiple instances of @codemirror/state are loaded, breaking instanceof checks.`);r(f,l)}}return r(n,Wi.default),i.reduce((o,l)=>o.concat(l))}function ln(n,e){if(e&1)return 2;let t=e>>1,i=n.status[t];if(i==4)throw new Error("Cyclic dependency between fields and/or facets");if(i&2)return i;n.status[t]=4;let s=n.computeSlot(n,n.config.dynamicSlots[t]);return n.status[t]=2|s}function gr(n,e){return e&1?n.config.staticValues[e>>1]:n.values[e>>1]}var tu=W.define(),Tl=W.define({combine:n=>n.some(e=>e),static:!0}),iu=W.define({combine:n=>n.length?n[0]:void 0,static:!0}),su=W.define(),nu=W.define(),ru=W.define(),ou=W.define({combine:n=>n.length?n[0]:!1}),lt=class{constructor(e,t){this.type=e,this.value=t}static define(){return new Pl}},Pl=class{of(e){return new lt(this,e)}},Cl=class{constructor(e){this.map=e}of(e){return new ne(this,e)}},ne=class n{constructor(e,t){this.type=e,this.value=t}map(e){let t=this.type.map(this.value,e);return t===void 0?void 0:t==this.value?this:new n(this.type,t)}is(e){return this.type==e}static define(e={}){return new Cl(e.map||(t=>t))}static mapEffects(e,t){if(!e.length)return e;let i=[];for(let s of e){let r=s.map(t);r&&i.push(r)}return i}};ne.reconfigure=ne.define();ne.appendConfig=ne.define();var Re=class n{constructor(e,t,i,s,r,o){this.startState=e,this.changes=t,this.selection=i,this.effects=s,this.annotations=r,this.scrollIntoView=o,this._doc=null,this._state=null,i&&eu(i,t.newLength),r.some(l=>l.type==n.time)||(this.annotations=r.concat(n.time.of(Date.now())))}static create(e,t,i,s,r,o){return new n(e,t,i,s,r,o)}get newDoc(){return this._doc||(this._doc=this.changes.apply(this.startState.doc))}get newSelection(){return this.selection||this.startState.selection.map(this.changes)}get state(){return this._state||this.startState.applyTransaction(this),this._state}annotation(e){for(let t of this.annotations)if(t.type==e)return t.value}get docChanged(){return!this.changes.empty}get reconfigured(){return this.startState.config!=this.state.config}isUserEvent(e){let t=this.annotation(n.userEvent);return!!(t&&(t==e||t.length>e.length&&t.slice(0,e.length)==e&&t[e.length]=="."))}};Re.time=lt.define();Re.userEvent=lt.define();Re.addToHistory=lt.define();Re.remote=lt.define();function bv(n,e){let t=[];for(let i=0,s=0;;){let r,o;if(i<n.length&&(s==e.length||e[s]>=n[i]))r=n[i++],o=n[i++];else if(s<e.length)r=e[s++],o=e[s++];else return t;!t.length||t[t.length-1]<r?t.push(r,o):t[t.length-1]<o&&(t[t.length-1]=o)}}function lu(n,e,t){var i;let s,r,o;return t?(s=e.changes,r=Ze.empty(e.changes.length),o=n.changes.compose(e.changes)):(s=e.changes.map(n.changes),r=n.changes.mapDesc(e.changes,!0),o=n.changes.compose(s)),{changes:o,selection:e.selection?e.selection.map(r):(i=n.selection)===null||i===void 0?void 0:i.map(s),effects:ne.mapEffects(n.effects,s).concat(ne.mapEffects(e.effects,r)),annotations:n.annotations.length?n.annotations.concat(e.annotations):e.annotations,scrollIntoView:n.scrollIntoView||e.scrollIntoView}}function El(n,e,t){let i=e.selection,s=ks(e.annotations);return e.userEvent&&(s=s.concat(Re.userEvent.of(e.userEvent))),{changes:e.changes instanceof Ze?e.changes:Ze.of(e.changes||[],t,n.facet(iu)),selection:i&&(i instanceof M?i:M.single(i.anchor,i.head)),effects:ks(e.effects),annotations:s,scrollIntoView:!!e.scrollIntoView}}function au(n,e,t){let i=El(n,e.length?e[0]:{},n.doc.length);e.length&&e[0].filter===!1&&(t=!1);for(let r=1;r<e.length;r++){e[r].filter===!1&&(t=!1);let o=!!e[r].sequential;i=lu(i,El(n,e[r],o?i.changes.newLength:n.doc.length),o)}let s=Re.create(n,i.changes,i.selection,i.effects,i.annotations,i.scrollIntoView);return Ov(t?vv(s):s)}function vv(n){let e=n.startState,t=!0;for(let s of e.facet(su)){let r=s(n);if(r===!1){t=!1;break}Array.isArray(r)&&(t=t===!0?r:bv(t,r))}if(t!==!0){let s,r;if(t===!1)r=n.changes.invertedDesc,s=Ze.empty(e.doc.length);else{let o=n.changes.filter(t);s=o.changes,r=o.filtered.mapDesc(o.changes).invertedDesc}n=Re.create(e,s,n.selection&&n.selection.map(r),ne.mapEffects(n.effects,r),n.annotations,n.scrollIntoView)}let i=e.facet(nu);for(let s=i.length-1;s>=0;s--){let r=i[s](n);r instanceof Re?n=r:Array.isArray(r)&&r.length==1&&r[0]instanceof Re?n=r[0]:n=au(e,ks(r),!1)}return n}function Ov(n){let e=n.startState,t=e.facet(ru),i=n;for(let s=t.length-1;s>=0;s--){let r=t[s](n);r&&Object.keys(r).length&&(i=lu(i,El(e,r,n.changes.newLength),!0))}return i==n?n:Re.create(e,n.changes,n.selection,i.effects,i.annotations,i.scrollIntoView)}var wv=[];function ks(n){return n==null?wv:Array.isArray(n)?n:[n]}var be=function(n){return n[n.Word=0]="Word",n[n.Space=1]="Space",n[n.Other=2]="Other",n}(be||(be={})),kv=/[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/,Al;try{Al=new RegExp("[\\p{Alphabetic}\\p{Number}_]","u")}catch{}function xv(n){if(Al)return Al.test(n);for(let e=0;e<n.length;e++){let t=n[e];if(/\w/.test(t)||t>"\x80"&&(t.toUpperCase()!=t.toLowerCase()||kv.test(t)))return!0}return!1}function Sv(n){return e=>{if(!/\S/.test(e))return be.Space;if(xv(e))return be.Word;for(let t=0;t<n.length;t++)if(e.indexOf(n[t])>-1)return be.Word;return be.Other}}var pe=class n{constructor(e,t,i,s,r,o){this.config=e,this.doc=t,this.selection=i,this.values=s,this.status=e.statusTemplate.slice(),this.computeSlot=r,o&&(o._state=this);for(let l=0;l<this.config.dynamicSlots.length;l++)ln(this,l<<1);this.computeSlot=null}field(e,t=!0){let i=this.config.address[e.id];if(i==null){if(t)throw new RangeError("Field is not present in this state");return}return ln(this,i),gr(this,i)}update(...e){return au(this,e,!0)}applyTransaction(e){let t=this.config,{base:i,compartments:s}=t;for(let l of e.effects)l.is(Ss.reconfigure)?(t&&(s=new Map,t.compartments.forEach((a,f)=>s.set(f,a)),t=null),s.set(l.value.compartment,l.value.extension)):l.is(ne.reconfigure)?(t=null,i=l.value):l.is(ne.appendConfig)&&(t=null,i=ks(i).concat(l.value));let r;t?r=e.startState.values.slice():(t=mr.resolve(i,s,this),r=new n(t,this.doc,this.selection,t.dynamicSlots.map(()=>null),(a,f)=>f.reconfigure(a,this),null).values);let o=e.startState.facet(Tl)?e.newSelection:e.newSelection.asSingle();new n(t,e.newDoc,o,r,(l,a)=>a.update(l,e),e)}replaceSelection(e){return typeof e=="string"&&(e=this.toText(e)),this.changeByRange(t=>({changes:{from:t.from,to:t.to,insert:e},range:M.cursor(t.from+e.length,-1)}))}changeByRange(e){let t=this.selection,i=e(t.ranges[0]),s=this.changes(i.changes),r=[i.range],o=ks(i.effects);for(let l=1;l<t.ranges.length;l++){let a=e(t.ranges[l]),f=this.changes(a.changes),c=f.map(s);for(let p=0;p<l;p++)r[p]=r[p].map(c);let u=s.mapDesc(f,!0);r.push(a.range.map(u)),s=s.compose(c),o=ne.mapEffects(o,c).concat(ne.mapEffects(ks(a.effects),u))}return{changes:s,selection:M.create(r,t.mainIndex),effects:o}}changes(e=[]){return e instanceof Ze?e:Ze.of(e,this.doc.length,this.facet(n.lineSeparator))}toText(e){return oe.of(e.split(this.facet(n.lineSeparator)||wl))}sliceDoc(e=0,t=this.doc.length){return this.doc.sliceString(e,t,this.lineBreak)}facet(e){let t=this.config.address[e.id];return t==null?e.default:(ln(this,t),gr(this,t))}toJSON(e){let t={doc:this.sliceDoc(),selection:this.selection.toJSON()};if(e)for(let i in e){let s=e[i];s instanceof Qe&&this.config.address[s.id]!=null&&(t[i]=s.spec.toJSON(this.field(e[i]),this))}return t}static fromJSON(e,t={},i){if(!e||typeof e.doc!="string")throw new RangeError("Invalid JSON representation for EditorState");let s=[];if(i){for(let r in i)if(Object.prototype.hasOwnProperty.call(e,r)){let o=i[r],l=e[r];s.push(o.init(a=>o.spec.fromJSON(l,a)))}}return n.create({doc:e.doc,selection:M.fromJSON(e.selection),extensions:t.extensions?s.concat([t.extensions]):s})}static create(e={}){let t=mr.resolve(e.extensions||[],new Map),i=e.doc instanceof oe?e.doc:oe.of((e.doc||"").split(t.staticFacet(n.lineSeparator)||wl)),s=e.selection?e.selection instanceof M?e.selection:M.single(e.selection.anchor,e.selection.head):M.single(0);return eu(s,i.length),t.staticFacet(Tl)||(s=s.asSingle()),new n(t,i,s,t.dynamicSlots.map(()=>null),(r,o)=>o.create(r),null)}get tabSize(){return this.facet(n.tabSize)}get lineBreak(){return this.facet(n.lineSeparator)||`
`}get readOnly(){return this.facet(ou)}phrase(e,...t){for(let i of this.facet(n.phrases))if(Object.prototype.hasOwnProperty.call(i,e)){e=i[e];break}return t.length&&(e=e.replace(/\$(\$|\d*)/g,(i,s)=>{if(s=="$")return"$";let r=+(s||1);return!r||r>t.length?i:t[r-1]})),e}languageDataAt(e,t,i=-1){let s=[];for(let r of this.facet(tu))for(let o of r(this,t,i))Object.prototype.hasOwnProperty.call(o,e)&&s.push(o[e]);return s}charCategorizer(e){let t=this.languageDataAt("wordChars",e);return Sv(t.length?t[0]:"")}wordAt(e){let{text:t,from:i,length:s}=this.doc.lineAt(e),r=this.charCategorizer(e),o=e-i,l=e-i;for(;o>0;){let a=Ee(t,o,!1);if(r(t.slice(a,o))!=be.Word)break;o=a}for(;l<s;){let a=Ee(t,l);if(r(t.slice(l,a))!=be.Word)break;l=a}return o==l?null:M.range(o+i,l+i)}};pe.allowMultipleSelections=Tl;pe.tabSize=W.define({combine:n=>n.length?n[0]:4});pe.lineSeparator=iu;pe.readOnly=ou;pe.phrases=W.define({compare(n,e){let t=Object.keys(n),i=Object.keys(e);return t.length==i.length&&t.every(s=>n[s]==e[s])}});pe.languageData=tu;pe.changeFilter=su;pe.transactionFilter=nu;pe.transactionExtender=ru;Ss.reconfigure=ne.define();function wt(n,e,t={}){let i={};for(let s of n)for(let r of Object.keys(s)){let o=s[r],l=i[r];if(l===void 0)i[r]=o;else if(!(l===o||o===void 0))if(Object.hasOwnProperty.call(t,r))i[r]=t[r](l,o);else throw new Error("Config merge conflict for field "+r)}for(let s in e)i[s]===void 0&&(i[s]=e[s]);return i}var vt=class{eq(e){return this==e}range(e,t=e){return fn.create(e,t,this)}};vt.prototype.startSide=vt.prototype.endSide=0;vt.prototype.point=!1;vt.prototype.mapMode=Le.TrackDel;function Ll(n,e){return n==e||n.constructor==e.constructor&&n.eq(e)}var fn=class n{constructor(e,t,i){this.from=e,this.to=t,this.value=i}static create(e,t,i){return new n(e,t,i)}};function Rl(n,e){return n.from-e.from||n.value.startSide-e.value.startSide}var Ml=class n{constructor(e,t,i,s){this.from=e,this.to=t,this.value=i,this.maxPoint=s}get length(){return vs(this.to)}findIndex(e,t,i,s=0){let r=i?this.to:this.from;for(let o=s,l=r.length;;){if(o==l)return o;let a=o+l>>1,f=r[a]-e||(i?this.value[a].endSide:this.value[a].startSide)-t;if(a==o)return f>=0?o:l;f>=0?l=a:o=a+1}}between(e,t,i,s){for(let r=this.findIndex(t,-1e9,!0),o=this.findIndex(i,1e9,!1,r);r<o;r++)if(s(this.from[r]+e,this.to[r]+e,this.value[r])===!1)return!1}map(e,t,i,s,r){let o=[],l=[],a=[],f=-1,c=-1;e:for(let u=0;u<this.value.length;u++){let p=this.value[u],y=this.from[u]+e,v=this.to[u]+e,b,O;if(y==v){let k=t.mapPos(y,p.startSide,p.mapMode);if(k==null||(b=O=k,p.startSide!=p.endSide&&(O=t.mapPos(y,p.endSide),O<b)))continue}else if(b=t.mapPos(y,p.startSide),O=t.mapPos(v,p.endSide),b>O||b==O&&p.startSide>0&&p.endSide<=0)continue;if(!((O-b||p.endSide-p.startSide)<0))if(f<0&&(f=b),p.point&&(c=Math.max(c,O-b)),(b-i||p.startSide-s)>=0)o.push(p),l.push(b-f),a.push(O-f),i=O,s=p.endSide;else{if(b==O)for(let k=o.length;k>0;k--){if((b-(a[k-1]+f)||p.startSide-o[k-1].endSide)>=0){o.splice(k,0,p),l.splice(k,0,b-f),a.splice(k,0,O-f);continue e}if((b-(l[k-1]+f)||p.endSide-o[k-1].startSide)>0)break}r(b,O,p)}}return{mapped:o.length?new n(l,a,o,c):null,pos:f}}},ce=class n{constructor(e,t,i,s){this.chunkPos=e,this.chunk=t,this.nextLayer=i,this.maxPoint=s}static create(e,t,i,s){return new n(e,t,i,s)}get length(){let e=this.chunk.length-1;return e<0?0:Math.max(this.chunkEnd(e),this.nextLayer.length)}get size(){if(this.isEmpty)return 0;let e=this.nextLayer.size;for(let t of this.chunk)e+=t.value.length;return e}chunkEnd(e){return this.chunkPos[e]+this.chunk[e].length}update(e){let{add:t=[],sort:i=!1,filterFrom:s=0,filterTo:r=this.length}=e,o=e.filter;if(t.length==0&&!o)return this;if(i&&(t=t.slice().sort(Rl)),this.isEmpty)return t.length?n.of(t):this;let l=new _r(this,null,-1).goto(0),a=0,f=[],c=new Gt;for(;l.value||a<t.length;)if(a<t.length&&(l.from-t[a].from||l.startSide-t[a].value.startSide)>=0){let u=t[a++];c.addInner(u.from,u.to,u.value,!1)||f.push(u)}else l.rangeIndex==1&&l.chunkIndex<this.chunk.length&&(a==t.length||this.chunkEnd(l.chunkIndex)<t[a].from)&&(!o||s>this.chunkEnd(l.chunkIndex)||r<this.chunkPos[l.chunkIndex])&&c.addChunk(this.chunkPos[l.chunkIndex],this.chunk[l.chunkIndex])?l.nextChunk():((!o||s>l.to||r<l.from||o(l.from,l.to,l.value))&&(c.addInner(l.from,l.to,l.value,!1)||f.push(fn.create(l.from,l.to,l.value))),l.next());return c.finishInner(this.nextLayer.isEmpty&&!f.length?n.empty:this.nextLayer.update({add:f,filter:o,filterFrom:s,filterTo:r}))}map(e){if(e.empty||this.isEmpty)return this;let t=[],i=[],s=-1,r,o=(a,f,c)=>{r||(r=new Gt),r.addRange(a,f,c,!1)};for(let a=0;a<this.chunk.length;a++){let f=this.chunkPos[a],c=this.chunk[a],u=e.touchesRange(f,f+c.length);if(u===!1)s=Math.max(s,c.maxPoint),t.push(c),i.push(e.mapPos(f));else if(u===!0){let[p,y]=t.length?[vs(i)+vs(t).length,vs(vs(t).value).endSide]:[-1,-1],{mapped:v,pos:b}=c.map(f,e,p,y,o);v&&(s=Math.max(s,v.maxPoint),t.push(v),i.push(b))}}let l=this.nextLayer.map(e);return r&&(l=r.finishInner(l)),t.length==0?l:new n(i,t,l||n.empty,s)}between(e,t,i){if(!this.isEmpty){for(let s=0;s<this.chunk.length;s++){let r=this.chunkPos[s],o=this.chunk[s];if(t>=r&&e<=r+o.length&&o.between(r,e-r,t-r,i)===!1)return}this.nextLayer.between(e,t,i)}}iter(e=0){return hn.from([this]).goto(e)}get isEmpty(){return this.nextLayer==this}static iter(e,t=0){return hn.from(e).goto(t)}static compare(e,t,i,s,r=-1){let o=e.filter(u=>u.maxPoint>0||!u.isEmpty&&u.maxPoint>=r),l=t.filter(u=>u.maxPoint>0||!u.isEmpty&&u.maxPoint>=r),a=Jd(o,l,i),f=new zi(o,a,r),c=new zi(l,a,r);i.iterGaps((u,p,y)=>Yd(f,u,c,p,y,s)),i.empty&&i.length==0&&Yd(f,0,c,0,0,s)}static eq(e,t,i=0,s){s==null&&(s=999999999);let r=e.filter(c=>!c.isEmpty&&t.indexOf(c)<0),o=t.filter(c=>!c.isEmpty&&e.indexOf(c)<0);if(r.length!=o.length)return!1;if(!r.length)return!0;let l=Jd(r,o),a=new zi(r,l,0).goto(i),f=new zi(o,l,0).goto(i);for(;;){if(a.to!=f.to||!Nl(a.active,f.active)||a.point&&(!f.point||!Ll(a.point,f.point)))return!1;if(a.to>s)return!0;a.next(),f.next()}}static spans(e,t,i,s,r=-1){let o=new zi(e,null,r).goto(t),l=t,a=o.openStart;for(;;){let f=Math.min(o.to,i);if(o.point){let c=o.activeForPoint(o.to),u=o.pointFrom<t?c.length+1:o.point.startSide<0?c.length:Math.min(c.length,a);s.point(l,f,o.point,c,u,o.pointRank),a=Math.min(o.openEnd(f),c.length)}else f>l&&(s.span(l,f,o.active,a),a=o.openEnd(f));if(o.to>i)return a+(o.point&&o.to>i?1:0);l=o.to,o.next()}}static of(e,t=!1){let i=new Gt;for(let s of e instanceof fn?[e]:t?Tv(e):e)i.add(s.from,s.to,s.value);return i.finish()}static join(e){if(!e.length)return n.empty;let t=vs(e);for(let i=e.length-2;i>=0;i--)for(let s=e[i];s!=n.empty;s=s.nextLayer)t=new n(s.chunkPos,s.chunk,t,Math.max(s.maxPoint,t.maxPoint));return t}};ce.empty=new ce([],[],null,-1);function vs(n){return n[n.length-1]}function Tv(n){if(n.length>1)for(let e=n[0],t=1;t<n.length;t++){let i=n[t];if(Rl(e,i)>0)return n.slice().sort(Rl);e=i}return n}ce.empty.nextLayer=ce.empty;var Gt=class n{finishChunk(e){this.chunks.push(new Ml(this.from,this.to,this.value,this.maxPoint)),this.chunkPos.push(this.chunkStart),this.chunkStart=-1,this.setMaxPoint=Math.max(this.setMaxPoint,this.maxPoint),this.maxPoint=-1,e&&(this.from=[],this.to=[],this.value=[])}constructor(){this.chunks=[],this.chunkPos=[],this.chunkStart=-1,this.last=null,this.lastFrom=-1e9,this.lastTo=-1e9,this.from=[],this.to=[],this.value=[],this.maxPoint=-1,this.setMaxPoint=-1,this.nextLayer=null}add(e,t,i){this.addRange(e,t,i,!0)}addRange(e,t,i,s){this.addInner(e,t,i,s)||(this.nextLayer||(this.nextLayer=new n)).addRange(e,t,i,s)}addInner(e,t,i,s){let r=e-this.lastTo||i.startSide-this.last.endSide;if(s&&r<=0&&(e-this.lastFrom||i.startSide-this.last.startSide)<0)throw new Error("Ranges must be added sorted by `from` position and `startSide`");return r<0?!1:(this.from.length==250&&this.finishChunk(!0),this.chunkStart<0&&(this.chunkStart=e),this.from.push(e-this.chunkStart),this.to.push(t-this.chunkStart),this.last=i,this.lastFrom=e,this.lastTo=t,this.value.push(i),i.point&&(this.maxPoint=Math.max(this.maxPoint,t-e)),!0)}addChunk(e,t){if((e-this.lastTo||t.value[0].startSide-this.last.endSide)<0)return!1;this.from.length&&this.finishChunk(!0),this.setMaxPoint=Math.max(this.setMaxPoint,t.maxPoint),this.chunks.push(t),this.chunkPos.push(e);let i=t.value.length-1;return this.last=t.value[i],this.lastFrom=t.from[i]+e,this.lastTo=t.to[i]+e,!0}finish(){return this.finishInner(ce.empty)}finishInner(e){if(this.from.length&&this.finishChunk(!1),this.chunks.length==0)return e;let t=ce.create(this.chunkPos,this.chunks,this.nextLayer?this.nextLayer.finishInner(e):e,this.setMaxPoint);return this.from=null,t}};function Jd(n,e,t){let i=new Map;for(let r of n)for(let o=0;o<r.chunk.length;o++)r.chunk[o].maxPoint<=0&&i.set(r.chunk[o],r.chunkPos[o]);let s=new Set;for(let r of e)for(let o=0;o<r.chunk.length;o++){let l=i.get(r.chunk[o]);l!=null&&(t?t.mapPos(l):l)==r.chunkPos[o]&&!(t!=null&&t.touchesRange(l,l+r.chunk[o].length))&&s.add(r.chunk[o])}return s}var _r=class{constructor(e,t,i,s=0){this.layer=e,this.skip=t,this.minPoint=i,this.rank=s}get startSide(){return this.value?this.value.startSide:0}get endSide(){return this.value?this.value.endSide:0}goto(e,t=-1e9){return this.chunkIndex=this.rangeIndex=0,this.gotoInner(e,t,!1),this}gotoInner(e,t,i){for(;this.chunkIndex<this.layer.chunk.length;){let s=this.layer.chunk[this.chunkIndex];if(!(this.skip&&this.skip.has(s)||this.layer.chunkEnd(this.chunkIndex)<e||s.maxPoint<this.minPoint))break;this.chunkIndex++,i=!1}if(this.chunkIndex<this.layer.chunk.length){let s=this.layer.chunk[this.chunkIndex].findIndex(e-this.layer.chunkPos[this.chunkIndex],t,!0);(!i||this.rangeIndex<s)&&this.setRangeIndex(s)}this.next()}forward(e,t){(this.to-e||this.endSide-t)<0&&this.gotoInner(e,t,!0)}next(){for(;;)if(this.chunkIndex==this.layer.chunk.length){this.from=this.to=1e9,this.value=null;break}else{let e=this.layer.chunkPos[this.chunkIndex],t=this.layer.chunk[this.chunkIndex],i=e+t.from[this.rangeIndex];if(this.from=i,this.to=e+t.to[this.rangeIndex],this.value=t.value[this.rangeIndex],this.setRangeIndex(this.rangeIndex+1),this.minPoint<0||this.value.point&&this.to-this.from>=this.minPoint)break}}setRangeIndex(e){if(e==this.layer.chunk[this.chunkIndex].value.length){if(this.chunkIndex++,this.skip)for(;this.chunkIndex<this.layer.chunk.length&&this.skip.has(this.layer.chunk[this.chunkIndex]);)this.chunkIndex++;this.rangeIndex=0}else this.rangeIndex=e}nextChunk(){this.chunkIndex++,this.rangeIndex=0,this.next()}compare(e){return this.from-e.from||this.startSide-e.startSide||this.rank-e.rank||this.to-e.to||this.endSide-e.endSide}},hn=class n{constructor(e){this.heap=e}static from(e,t=null,i=-1){let s=[];for(let r=0;r<e.length;r++)for(let o=e[r];!o.isEmpty;o=o.nextLayer)o.maxPoint>=i&&s.push(new _r(o,t,i,r));return s.length==1?s[0]:new n(s)}get startSide(){return this.value?this.value.startSide:0}goto(e,t=-1e9){for(let i of this.heap)i.goto(e,t);for(let i=this.heap.length>>1;i>=0;i--)vl(this.heap,i);return this.next(),this}forward(e,t){for(let i of this.heap)i.forward(e,t);for(let i=this.heap.length>>1;i>=0;i--)vl(this.heap,i);(this.to-e||this.value.endSide-t)<0&&this.next()}next(){if(this.heap.length==0)this.from=this.to=1e9,this.value=null,this.rank=-1;else{let e=this.heap[0];this.from=e.from,this.to=e.to,this.value=e.value,this.rank=e.rank,e.value&&e.next(),vl(this.heap,0)}}};function vl(n,e){for(let t=n[e];;){let i=(e<<1)+1;if(i>=n.length)break;let s=n[i];if(i+1<n.length&&s.compare(n[i+1])>=0&&(s=n[i+1],i++),t.compare(s)<0)break;n[i]=t,n[e]=s,e=i}}var zi=class{constructor(e,t,i){this.minPoint=i,this.active=[],this.activeTo=[],this.activeRank=[],this.minActive=-1,this.point=null,this.pointFrom=0,this.pointRank=0,this.to=-1e9,this.endSide=0,this.openStart=-1,this.cursor=hn.from(e,t,i)}goto(e,t=-1e9){return this.cursor.goto(e,t),this.active.length=this.activeTo.length=this.activeRank.length=0,this.minActive=-1,this.to=e,this.endSide=t,this.openStart=-1,this.next(),this}forward(e,t){for(;this.minActive>-1&&(this.activeTo[this.minActive]-e||this.active[this.minActive].endSide-t)<0;)this.removeActive(this.minActive);this.cursor.forward(e,t)}removeActive(e){fr(this.active,e),fr(this.activeTo,e),fr(this.activeRank,e),this.minActive=Kd(this.active,this.activeTo)}addActive(e){let t=0,{value:i,to:s,rank:r}=this.cursor;for(;t<this.activeRank.length&&(r-this.activeRank[t]||s-this.activeTo[t])>0;)t++;hr(this.active,t,i),hr(this.activeTo,t,s),hr(this.activeRank,t,r),e&&hr(e,t,this.cursor.from),this.minActive=Kd(this.active,this.activeTo)}next(){let e=this.to,t=this.point;this.point=null;let i=this.openStart<0?[]:null;for(;;){let s=this.minActive;if(s>-1&&(this.activeTo[s]-this.cursor.from||this.active[s].endSide-this.cursor.startSide)<0){if(this.activeTo[s]>e){this.to=this.activeTo[s],this.endSide=this.active[s].endSide;break}this.removeActive(s),i&&fr(i,s)}else if(this.cursor.value)if(this.cursor.from>e){this.to=this.cursor.from,this.endSide=this.cursor.startSide;break}else{let r=this.cursor.value;if(!r.point)this.addActive(i),this.cursor.next();else if(t&&this.cursor.to==this.to&&this.cursor.from<this.cursor.to)this.cursor.next();else{this.point=r,this.pointFrom=this.cursor.from,this.pointRank=this.cursor.rank,this.to=this.cursor.to,this.endSide=r.endSide,this.cursor.next(),this.forward(this.to,this.endSide);break}}else{this.to=this.endSide=1e9;break}}if(i){this.openStart=0;for(let s=i.length-1;s>=0&&i[s]<e;s--)this.openStart++}}activeForPoint(e){if(!this.active.length)return this.active;let t=[];for(let i=this.active.length-1;i>=0&&!(this.activeRank[i]<this.pointRank);i--)(this.activeTo[i]>e||this.activeTo[i]==e&&this.active[i].endSide>=this.point.endSide)&&t.push(this.active[i]);return t.reverse()}openEnd(e){let t=0;for(let i=this.activeTo.length-1;i>=0&&this.activeTo[i]>e;i--)t++;return t}};function Yd(n,e,t,i,s,r){n.goto(e),t.goto(i);let o=i+s,l=i,a=i-e,f=!!r.boundChange;for(let c=!1;;){let u=n.to+a-t.to,p=u||n.endSide-t.endSide,y=p<0?n.to+a:t.to,v=Math.min(y,o);if(n.point||t.point?(n.point&&t.point&&Ll(n.point,t.point)&&Nl(n.activeForPoint(n.to),t.activeForPoint(t.to))||r.comparePoint(l,v,n.point,t.point),c=!1):(c&&(r.boundChange(l),c=!1),v>l&&!Nl(n.active,t.active)&&r.compareRange(l,v,n.active,t.active),f&&v<o&&(u||n.openEnd(y)!=t.openEnd(y))&&(c=!0)),y>o)break;l=y,p<=0&&n.next(),p>=0&&t.next()}}function Nl(n,e){if(n.length!=e.length)return!1;for(let t=0;t<n.length;t++)if(n[t]!=e[t]&&!Ll(n[t],e[t]))return!1;return!0}function fr(n,e){for(let t=e,i=n.length-1;t<i;t++)n[t]=n[t+1];n.pop()}function hr(n,e,t){for(let i=n.length-1;i>=e;i--)n[i+1]=n[i];n[e]=t}function Kd(n,e){let t=-1,i=1e9;for(let s=0;s<e.length;s++)(e[s]-i||n[s].endSide-n[t].endSide)<0&&(t=s,i=e[s]);return t}function Hi(n,e,t=n.length){let i=0;for(let s=0;s<t&&s<n.length;)n.charCodeAt(s)==9?(i+=e-i%e,s++):(i++,s=Ee(n,s));return i}function fu(n,e,t,i){for(let s=0,r=0;;){if(r>=e)return s;if(s==n.length)break;r+=n.charCodeAt(s)==9?t-r%t:1,s=Ee(n,s)}return i===!0?-1:n.length}var Ql="\u037C",hu=typeof Symbol>"u"?"__"+Ql:Symbol.for(Ql),ql=typeof Symbol>"u"?"__styleSet"+Math.floor(Math.random()*1e8):Symbol("styleSet"),cu=typeof globalThis<"u"?globalThis:typeof window<"u"?window:{},kt=class{constructor(e,t){this.rules=[];let{finish:i}=t||{};function s(o){return/^@/.test(o)?[o]:o.split(/,\s*/)}function r(o,l,a,f){let c=[],u=/^@(\w+)\b/.exec(o[0]),p=u&&u[1]=="keyframes";if(u&&l==null)return a.push(o[0]+";");for(let y in l){let v=l[y];if(/&/.test(y))r(y.split(/,\s*/).map(b=>o.map(O=>b.replace(/&/,O))).reduce((b,O)=>b.concat(O)),v,a);else if(v&&typeof v=="object"){if(!u)throw new RangeError("The value of a property ("+y+") should be a primitive value.");r(s(y),v,c,p)}else v!=null&&c.push(y.replace(/_.*/,"").replace(/[A-Z]/g,b=>"-"+b.toLowerCase())+": "+v+";")}(c.length||p)&&a.push((i&&!u&&!f?o.map(i):o).join(", ")+" {"+c.join(" ")+"}")}for(let o in e)r(s(o),e[o],this.rules)}getRules(){return this.rules.join(`
`)}static newName(){let e=cu[hu]||1;return cu[hu]=e+1,Ql+e.toString(36)}static mount(e,t,i){let s=e[ql],r=i&&i.nonce;s?r&&s.setNonce(r):s=new Bl(e,r),s.mount(Array.isArray(t)?t:[t],e)}},du=new Map,Bl=class{constructor(e,t){let i=e.ownerDocument||e,s=i.defaultView;if(!e.head&&e.adoptedStyleSheets&&s.CSSStyleSheet){let r=du.get(i);if(r)return e[ql]=r;this.sheet=new s.CSSStyleSheet,du.set(i,this)}else this.styleTag=i.createElement("style"),t&&this.styleTag.setAttribute("nonce",t);this.modules=[],e[ql]=this}mount(e,t){let i=this.sheet,s=0,r=0,o=!1;for(let l=0;l<e.length;l++){let a=e[l],f=this.modules.indexOf(a);if(f<r&&f>-1&&(this.modules.splice(f,1),o=!0,r--,f=-1),f==-1){if(this.modules.splice(r++,0,a),o=!0,i)for(let c=0;c<a.rules.length;c++)i.insertRule(a.rules[c],s++)}else{for(;r<f;)s+=this.modules[r++].rules.length;s+=a.rules.length,r++}}if(i)t.adoptedStyleSheets.indexOf(this.sheet)<0&&(t.adoptedStyleSheets=[this.sheet,...t.adoptedStyleSheets]);else{if(o){let a="";for(let f=0;f<this.modules.length;f++)a+=this.modules[f].getRules()+`
`;this.styleTag.textContent=a}let l=t.head||t;this.styleTag.parentNode!=l&&l.insertBefore(this.styleTag,l.firstChild)}}setNonce(e){this.styleTag&&this.styleTag.getAttribute("nonce")!=e&&this.styleTag.setAttribute("nonce",e)}};var ni={8:"Backspace",9:"Tab",10:"Enter",12:"NumLock",13:"Enter",16:"Shift",17:"Control",18:"Alt",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",44:"PrintScreen",45:"Insert",46:"Delete",59:";",61:"=",91:"Meta",92:"Meta",106:"*",107:"+",108:",",109:"-",110:".",111:"/",144:"NumLock",145:"ScrollLock",160:"Shift",161:"Shift",162:"Control",163:"Control",164:"Alt",165:"Alt",173:"-",186:";",187:"=",188:",",189:"-",190:".",191:"/",192:"`",219:"[",220:"\\",221:"]",222:"'"},Ts={48:")",49:"!",50:"@",51:"#",52:"$",53:"%",54:"^",55:"&",56:"*",57:"(",59:":",61:"+",173:"_",186:":",187:"+",188:"<",189:"_",190:">",191:"?",192:"~",219:"{",220:"|",221:"}",222:'"'},Pv=typeof navigator<"u"&&/Mac/.test(navigator.platform),Cv=typeof navigator<"u"&&/MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent);for(Me=0;Me<10;Me++)ni[48+Me]=ni[96+Me]=String(Me);var Me;for(Me=1;Me<=24;Me++)ni[Me+111]="F"+Me;var Me;for(Me=65;Me<=90;Me++)ni[Me]=String.fromCharCode(Me+32),Ts[Me]=String.fromCharCode(Me);var Me;for(yr in ni)Ts.hasOwnProperty(yr)||(Ts[yr]=ni[yr]);var yr;function uu(n){var e=Pv&&n.metaKey&&n.shiftKey&&!n.ctrlKey&&!n.altKey||Cv&&n.shiftKey&&n.key&&n.key.length==1||n.key=="Unidentified",t=!e&&n.key||(n.shiftKey?Ts:ni)[n.keyCode]||n.key||"Unidentified";return t=="Esc"&&(t="Escape"),t=="Del"&&(t="Delete"),t=="Left"&&(t="ArrowLeft"),t=="Up"&&(t="ArrowUp"),t=="Right"&&(t="ArrowRight"),t=="Down"&&(t="ArrowDown"),t}function Ae(){var n=arguments[0];typeof n=="string"&&(n=document.createElement(n));var e=1,t=arguments[1];if(t&&typeof t=="object"&&t.nodeType==null&&!Array.isArray(t)){for(var i in t)if(Object.prototype.hasOwnProperty.call(t,i)){var s=t[i];typeof s=="string"?n.setAttribute(i,s):s!=null&&(n[i]=s)}e++}for(;e<arguments.length;e++)pu(n,arguments[e]);return n}function pu(n,e){if(typeof e=="string")n.appendChild(document.createTextNode(e));else if(e!=null)if(e.nodeType!=null)n.appendChild(e);else if(Array.isArray(e))for(var t=0;t<e.length;t++)pu(n,e[t]);else throw new RangeError("Unsupported child node: "+e)}var et=typeof navigator<"u"?navigator:{userAgent:"",vendor:"",platform:""},Ul=typeof document<"u"?document:{documentElement:{style:{}}},Gl=/Edge\/(\d+)/.exec(et.userAgent),Ju=/MSIE \d/.test(et.userAgent),Xl=/Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(et.userAgent),Gr=!!(Ju||Xl||Gl),mu=!Gr&&/gecko\/(\d+)/i.test(et.userAgent),$l=!Gr&&/Chrome\/(\d+)/.exec(et.userAgent),gu="webkitFontSmoothing"in Ul.documentElement.style,Jl=!Gr&&/Apple Computer/.test(et.vendor),_u=Jl&&(/Mobile\/\w+/.test(et.userAgent)||et.maxTouchPoints>2),F={mac:_u||/Mac/.test(et.platform),windows:/Win/.test(et.platform),linux:/Linux|X11/.test(et.platform),ie:Gr,ie_version:Ju?Ul.documentMode||6:Xl?+Xl[1]:Gl?+Gl[1]:0,gecko:mu,gecko_version:mu?+(/Firefox\/(\d+)/.exec(et.userAgent)||[0,0])[1]:0,chrome:!!$l,chrome_version:$l?+$l[1]:0,ios:_u,android:/Android\b/.test(et.userAgent),webkit:gu,webkit_version:gu?+(/\bAppleWebKit\/(\d+)/.exec(et.userAgent)||[0,0])[1]:0,safari:Jl,safari_version:Jl?+(/\bVersion\/(\d+(\.\d+)?)/.exec(et.userAgent)||[0,0])[1]:0,tabSize:Ul.documentElement.style.tabSize!=null?"tab-size":"-moz-tab-size"};function Qa(n,e){for(let t in n)t=="class"&&e.class?e.class+=" "+n.class:t=="style"&&e.style?e.style+=";"+n.style:e[t]=n[t];return e}var Nr=Object.create(null);function qa(n,e,t){if(n==e)return!0;n||(n=Nr),e||(e=Nr);let i=Object.keys(n),s=Object.keys(e);if(i.length-(t&&i.indexOf(t)>-1?1:0)!=s.length-(t&&s.indexOf(t)>-1?1:0))return!1;for(let r of i)if(r!=t&&(s.indexOf(r)==-1||n[r]!==e[r]))return!1;return!0}function Ev(n,e){for(let t=n.attributes.length-1;t>=0;t--){let i=n.attributes[t].name;e[i]==null&&n.removeAttribute(i)}for(let t in e){let i=e[t];t=="style"?n.style.cssText=i:n.getAttribute(t)!=i&&n.setAttribute(t,i)}}function yu(n,e,t){let i=!1;if(e)for(let s in e)t&&s in t||(i=!0,s=="style"?n.style.cssText="":n.removeAttribute(s));if(t)for(let s in t)e&&e[s]==t[s]||(i=!0,s=="style"?n.style.cssText=t[s]:n.setAttribute(s,t[s]));return i}function Av(n){let e=Object.create(null);for(let t=0;t<n.attributes.length;t++){let i=n.attributes[t];e[i.name]=i.value}return e}var li=class{eq(e){return!1}updateDOM(e,t,i){return!1}compare(e){return this==e||this.constructor==e.constructor&&this.eq(e)}get estimatedHeight(){return-1}get lineBreaks(){return 0}ignoreEvent(e){return!0}coordsAt(e,t,i){return null}get isHidden(){return!1}get editable(){return!1}destroy(e){}},Ve=function(n){return n[n.Text=0]="Text",n[n.WidgetBefore=1]="WidgetBefore",n[n.WidgetAfter=2]="WidgetAfter",n[n.WidgetRange=3]="WidgetRange",n}(Ve||(Ve={})),K=class extends vt{constructor(e,t,i,s){super(),this.startSide=e,this.endSide=t,this.widget=i,this.spec=s}get heightRelevant(){return!1}static mark(e){return new wn(e)}static widget(e){let t=Math.max(-1e4,Math.min(1e4,e.side||0)),i=!!e.block;return t+=i&&!e.inlineOrder?t>0?3e8:-4e8:t>0?1e8:-1e8,new Ji(e,t,t,i,e.widget||null,!1)}static replace(e){let t=!!e.block,i,s;if(e.isBlockGap)i=-5e8,s=4e8;else{let{start:r,end:o}=Yu(e,t);i=(r?t?-3e8:-1:5e8)-1,s=(o?t?2e8:1:-6e8)+1}return new Ji(e,i,s,t,e.widget||null,!0)}static line(e){return new kn(e)}static set(e,t=!1){return ce.of(e,t)}hasHeight(){return this.widget?this.widget.estimatedHeight>-1:!1}};K.none=ce.empty;var wn=class n extends K{constructor(e){let{start:t,end:i}=Yu(e);super(t?-1:5e8,i?1:-6e8,null,e),this.tagName=e.tagName||"span",this.attrs=e.class&&e.attributes?Qa(e.attributes,{class:e.class}):e.class?{class:e.class}:e.attributes||Nr}eq(e){return this==e||e instanceof n&&this.tagName==e.tagName&&qa(this.attrs,e.attrs)}range(e,t=e){if(e>=t)throw new RangeError("Mark decorations may not be empty");return super.range(e,t)}};wn.prototype.point=!1;var kn=class n extends K{constructor(e){super(-2e8,-2e8,null,e)}eq(e){return e instanceof n&&this.spec.class==e.spec.class&&qa(this.spec.attributes,e.spec.attributes)}range(e,t=e){if(t!=e)throw new RangeError("Line decoration ranges must be zero-length");return super.range(e,t)}};kn.prototype.mapMode=Le.TrackBefore;kn.prototype.point=!0;var Ji=class n extends K{constructor(e,t,i,s,r,o){super(t,i,r,e),this.block=s,this.isReplace=o,this.mapMode=s?t<=0?Le.TrackBefore:Le.TrackAfter:Le.TrackDel}get type(){return this.startSide!=this.endSide?Ve.WidgetRange:this.startSide<=0?Ve.WidgetBefore:Ve.WidgetAfter}get heightRelevant(){return this.block||!!this.widget&&(this.widget.estimatedHeight>=5||this.widget.lineBreaks>0)}eq(e){return e instanceof n&&Rv(this.widget,e.widget)&&this.block==e.block&&this.startSide==e.startSide&&this.endSide==e.endSide}range(e,t=e){if(this.isReplace&&(e>t||e==t&&this.startSide>0&&this.endSide<=0))throw new RangeError("Invalid range for replacement decoration");if(!this.isReplace&&t!=e)throw new RangeError("Widget decorations can only have zero-length ranges");return super.range(e,t)}};Ji.prototype.point=!0;function Yu(n,e=!1){let{inclusiveStart:t,inclusiveEnd:i}=n;return t==null&&(t=n.inclusive),i==null&&(i=n.inclusive),{start:t??e,end:i??e}}function Rv(n,e){return n==e||!!(n&&e&&n.compare(e))}function Ms(n,e,t,i=0){let s=t.length-1;s>=0&&t[s]+i>=n?t[s]=Math.max(t[s],e):t.push(n,e)}var Dr=class n extends vt{constructor(e,t,i){super(),this.tagName=e,this.attributes=t,this.rank=i}eq(e){return e==this||e instanceof n&&this.tagName==e.tagName&&qa(this.attributes,e.attributes)}static create(e){return new n(e.tagName,e.attributes||Nr,e.rank==null?50:Math.max(0,Math.min(e.rank,100)))}static set(e,t=!1){return ce.of(e,t)}};Dr.prototype.startSide=Dr.prototype.endSide=-1;function xn(n){let e;return n.nodeType==11?e=n.getSelection?n:n.ownerDocument:e=n,e.getSelection()}function Yl(n,e){return e?n==e||n.contains(e.nodeType!=1?e.parentNode:e):!1}function pn(n,e){if(!e.anchorNode)return!1;try{return Yl(n,e.anchorNode)}catch{return!1}}function Pr(n){return n.nodeType==3?Sn(n,0,n.nodeValue.length).getClientRects():n.nodeType==1?n.getClientRects():[]}function mn(n,e,t,i){return t?bu(n,e,t,i,-1)||bu(n,e,t,i,1):!1}function Oi(n){for(var e=0;;e++)if(n=n.previousSibling,!n)return e}function Ir(n){return n.nodeType==1&&/^(DIV|P|LI|UL|OL|BLOCKQUOTE|DD|DT|H\d|SECTION|PRE)$/.test(n.nodeName)}function bu(n,e,t,i,s){for(;;){if(n==t&&e==i)return!0;if(e==(s<0?0:ai(n))){if(n.nodeName=="DIV")return!1;let r=n.parentNode;if(!r||r.nodeType!=1)return!1;e=Oi(n)+(s<0?0:1),n=r}else if(n.nodeType==1){if(n=n.childNodes[e+(s<0?-1:0)],n.nodeType==1&&n.contentEditable=="false")return!1;e=s<0?ai(n):0}else return!1}}function ai(n){return n.nodeType==3?n.nodeValue.length:n.childNodes.length}function Lr(n,e){let{left:t,right:i}=n;if(t==i)return n;let s=e?t:i;return{left:s,right:s,top:n.top,bottom:n.bottom}}function Mv(n){let e=n.visualViewport;return e?{left:0,right:e.width,top:0,bottom:e.height}:{left:0,right:n.innerWidth,top:0,bottom:n.innerHeight}}function Ku(n,e){let t=e.width/n.offsetWidth,i=e.height/n.offsetHeight;return(t>.995&&t<1.005||!isFinite(t)||Math.abs(e.width-n.offsetWidth)<1)&&(t=1),(i>.995&&i<1.005||!isFinite(i)||Math.abs(e.height-n.offsetHeight)<1)&&(i=1),{scaleX:t,scaleY:i}}function Nv(n,e,t,i,s,r,o,l){let a=n.ownerDocument,f=a.defaultView||window;for(let c=n,u=!1;c&&!u;)if(c.nodeType==1){let p,y=c==a.body,v=1,b=1;if(y)p=Mv(f);else{if(/^(fixed|sticky)$/.test(getComputedStyle(c).position)&&(u=!0),c.scrollHeight<=c.clientHeight&&c.scrollWidth<=c.clientWidth){c=c.assignedSlot||c.parentNode;continue}let T=c.getBoundingClientRect();({scaleX:v,scaleY:b}=Ku(c,T)),p={left:T.left,right:T.left+c.clientWidth*v,top:T.top,bottom:T.top+c.clientHeight*b}}let O=0,k=0;if(s=="nearest")e.top<p.top+o?(k=e.top-(p.top+o),t>0&&e.bottom>p.bottom+k&&(k=e.bottom-p.bottom+o)):e.bottom>p.bottom-o&&(k=e.bottom-p.bottom+o,t<0&&e.top-k<p.top&&(k=e.top-(p.top+o)));else{let T=e.bottom-e.top,P=p.bottom-p.top;k=(s=="center"&&T<=P?e.top+T/2-P/2:s=="start"||s=="center"&&t<0?e.top-o:e.bottom-P+o)-p.top}if(i=="nearest"?e.left<p.left+r?(O=e.left-(p.left+r),t>0&&e.right>p.right+O&&(O=e.right-p.right+r)):e.right>p.right-r&&(O=e.right-p.right+r,t<0&&e.left<p.left+O&&(O=e.left-(p.left+r))):O=(i=="center"?e.left+(e.right-e.left)/2-(p.right-p.left)/2:i=="start"==l?e.left-r:e.right-(p.right-p.left)+r)-p.left,O||k)if(y)f.scrollBy(O,k);else{let T=0,P=0;if(k){let I=c.scrollTop;c.scrollTop+=k/b,P=(c.scrollTop-I)*b}if(O){let I=c.scrollLeft;c.scrollLeft+=O/v,T=(c.scrollLeft-I)*v}e={left:e.left-T,top:e.top-P,right:e.right-T,bottom:e.bottom-P},T&&Math.abs(T-O)<1&&(i="nearest"),P&&Math.abs(P-k)<1&&(s="nearest")}if(y)break;(e.top<p.top||e.bottom>p.bottom||e.left<p.left||e.right>p.right)&&(e={left:Math.max(e.left,p.left),right:Math.min(e.right,p.right),top:Math.max(e.top,p.top),bottom:Math.min(e.bottom,p.bottom)}),c=c.assignedSlot||c.parentNode}else if(c.nodeType==11)c=c.host;else break}function Zu(n,e=!0){let t=n.ownerDocument,i=null,s=null;for(let r=n.parentNode;r&&!(r==t.body||(!e||i)&&s);)if(r.nodeType==1)!s&&r.scrollHeight>r.clientHeight&&(s=r),e&&!i&&r.scrollWidth>r.clientWidth&&(i=r),r=r.assignedSlot||r.parentNode;else if(r.nodeType==11)r=r.host;else break;return{x:i,y:s}}var Kl=class{constructor(){this.anchorNode=null,this.anchorOffset=0,this.focusNode=null,this.focusOffset=0}eq(e){return this.anchorNode==e.anchorNode&&this.anchorOffset==e.anchorOffset&&this.focusNode==e.focusNode&&this.focusOffset==e.focusOffset}setRange(e){let{anchorNode:t,focusNode:i}=e;this.set(t,Math.min(e.anchorOffset,t?ai(t):0),i,Math.min(e.focusOffset,i?ai(i):0))}set(e,t,i,s){this.anchorNode=e,this.anchorOffset=t,this.focusNode=i,this.focusOffset=s}};function ep(n){let e=[];for(let t=n;t;t=t.nodeType==11?t.host:t.parentNode)t.nodeType==1&&e.push({node:t,left:t.scrollLeft,top:t.scrollTop});return e}function tp(n,e=!0){for(let{node:t,left:i,top:s}of n)e&&t.scrollTop!=s&&(t.scrollTop=s),t.scrollLeft!=i&&(t.scrollLeft=i)}var Ui=null;F.safari&&F.safari_version>=26&&(Ui=!1);function ip(n){if(n.setActive)return n.setActive();if(Ui)return n.focus(Ui);let e=ep(n);n.focus(Ui==null?{get preventScroll(){return Ui={preventScroll:!0},!0}}:void 0),Ui||(Ui=!1,tp(e))}var vu;function Sn(n,e,t=e){let i=vu||(vu=document.createRange());return i.setEnd(n,t),i.setStart(n,e),i}function Ns(n,e,t,i){let s={key:e,code:e,keyCode:t,which:t,cancelable:!0};i&&({altKey:s.altKey,ctrlKey:s.ctrlKey,shiftKey:s.shiftKey,metaKey:s.metaKey}=i);let r=new KeyboardEvent("keydown",s);r.synthetic=!0,n.dispatchEvent(r);let o=new KeyboardEvent("keyup",s);return o.synthetic=!0,n.dispatchEvent(o),r.defaultPrevented||o.defaultPrevented}function Dv(n){for(;n;){if(n&&(n.nodeType==9||n.nodeType==11&&n.host))return n;n=n.assignedSlot||n.parentNode}return null}function Iv(n,e){let t=e.focusNode,i=e.focusOffset;if(!t||e.anchorNode!=t||e.anchorOffset!=i)return!1;for(i=Math.min(i,ai(t));;)if(i){if(t.nodeType!=1)return!1;let s=t.childNodes[i-1];s.contentEditable=="false"?i--:(t=s,i=ai(t))}else{if(t==n)return!0;i=Oi(t),t=t.parentNode}}function sp(n){return n instanceof Window?n.pageYOffset>Math.max(0,n.document.documentElement.scrollHeight-n.innerHeight-4):n.scrollTop>Math.max(1,n.scrollHeight-n.clientHeight-4)}function np(n,e){for(let t=n,i=e;;){if(t.nodeType==3&&i>0)return{node:t,offset:i};if(t.nodeType==1&&i>0){if(t.contentEditable=="false")return null;t=t.childNodes[i-1],i=ai(t)}else if(t.parentNode&&!Ir(t))i=Oi(t),t=t.parentNode;else return null}}function rp(n,e){for(let t=n,i=e;;){if(t.nodeType==3&&i<t.nodeValue.length)return{node:t,offset:i};if(t.nodeType==1&&i<t.childNodes.length){if(t.contentEditable=="false")return null;t=t.childNodes[i],i=0}else if(t.parentNode&&!Ir(t))i=Oi(t)+1,t=t.parentNode;else return null}}var Jt=class n{constructor(e,t,i=!0){this.node=e,this.offset=t,this.precise=i}static before(e,t){return new n(e.parentNode,Oi(e),t)}static after(e,t){return new n(e.parentNode,Oi(e)+1,t)}},_e=function(n){return n[n.LTR=0]="LTR",n[n.RTL=1]="RTL",n}(_e||(_e={})),Yi=_e.LTR,Ba=_e.RTL;function op(n){let e=[];for(let t=0;t<n.length;t++)e.push(1<<+n[t]);return e}var Lv=op("88888888888888888888888888888888888666888888787833333333337888888000000000000000000000000008888880000000000000000000000000088888888888888888888888888888888888887866668888088888663380888308888800000000000000000000000800000000000000000000000000000008"),Qv=op("4444448826627288999999999992222222222222222222222222222222222222222222222229999999999999999999994444444444644222822222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222999999949999999229989999223333333333"),Zl=Object.create(null),Xt=[];for(let n of["()","[]","{}"]){let e=n.charCodeAt(0),t=n.charCodeAt(1);Zl[e]=t,Zl[t]=-e}function lp(n){return n<=247?Lv[n]:1424<=n&&n<=1524?2:1536<=n&&n<=1785?Qv[n-1536]:1774<=n&&n<=2220?4:8192<=n&&n<=8204?256:64336<=n&&n<=65023?4:1}var qv=/[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac\ufb50-\ufdff]/,Tt=class{get dir(){return this.level%2?Ba:Yi}constructor(e,t,i){this.from=e,this.to=t,this.level=i}side(e,t){return this.dir==t==e?this.to:this.from}forward(e,t){return e==(this.dir==t)}static find(e,t,i,s){let r=-1;for(let o=0;o<e.length;o++){let l=e[o];if(l.from<=t&&l.to>=t){if(l.level==i)return o;(r<0||(s!=0?s<0?l.from<t:l.to>t:e[r].level>l.level))&&(r=o)}}if(r<0)throw new RangeError("Index out of range");return r}};function ap(n,e){if(n.length!=e.length)return!1;for(let t=0;t<n.length;t++){let i=n[t],s=e[t];if(i.from!=s.from||i.to!=s.to||i.direction!=s.direction||!ap(i.inner,s.inner))return!1}return!0}var we=[];function Bv(n,e,t,i,s){for(let r=0;r<=i.length;r++){let o=r?i[r-1].to:e,l=r<i.length?i[r].from:t,a=r?256:s;for(let f=o,c=a,u=a;f<l;f++){let p=lp(n.charCodeAt(f));p==512?p=c:p==8&&u==4&&(p=16),we[f]=p==4?2:p,p&7&&(u=p),c=p}for(let f=o,c=a,u=a;f<l;f++){let p=we[f];if(p==128)f<l-1&&c==we[f+1]&&c&24?p=we[f]=c:we[f]=256;else if(p==64){let y=f+1;for(;y<l&&we[y]==64;)y++;let v=f&&c==8||y<t&&we[y]==8?u==1?1:8:256;for(let b=f;b<y;b++)we[b]=v;f=y-1}else p==8&&u==1&&(we[f]=1);c=p,p&7&&(u=p)}}}function $v(n,e,t,i,s){let r=s==1?2:1;for(let o=0,l=0,a=0;o<=i.length;o++){let f=o?i[o-1].to:e,c=o<i.length?i[o].from:t;for(let u=f,p,y,v;u<c;u++)if(y=Zl[p=n.charCodeAt(u)])if(y<0){for(let b=l-3;b>=0;b-=3)if(Xt[b+1]==-y){let O=Xt[b+2],k=O&2?s:O&4?O&1?r:s:0;k&&(we[u]=we[Xt[b]]=k),l=b;break}}else{if(Xt.length==189)break;Xt[l++]=u,Xt[l++]=p,Xt[l++]=a}else if((v=we[u])==2||v==1){let b=v==s;a=b?0:1;for(let O=l-3;O>=0;O-=3){let k=Xt[O+2];if(k&2)break;if(b)Xt[O+2]|=2;else{if(k&4)break;Xt[O+2]|=4}}}}}function Fv(n,e,t,i){for(let s=0,r=i;s<=t.length;s++){let o=s?t[s-1].to:n,l=s<t.length?t[s].from:e;for(let a=o;a<l;){let f=we[a];if(f==256){let c=a+1;for(;;)if(c==l){if(s==t.length)break;c=t[s++].to,l=s<t.length?t[s].from:e}else if(we[c]==256)c++;else break;let u=r==1,p=(c<e?we[c]:i)==1,y=u==p?u?1:2:i;for(let v=c,b=s,O=b?t[b-1].to:n;v>a;)v==O&&(v=t[--b].from,O=b?t[b-1].to:n),we[--v]=y;a=c}else r=f,a++}}}function ea(n,e,t,i,s,r,o){let l=i%2?2:1;if(i%2==s%2)for(let a=e,f=0;a<t;){let c=!0,u=!1;if(f==r.length||a<r[f].from){let b=we[a];b!=l&&(c=!1,u=b==16)}let p=!c&&l==1?[]:null,y=c?i:i+1,v=a;e:for(;;)if(f<r.length&&v==r[f].from){if(u)break e;let b=r[f];if(!c)for(let O=b.to,k=f+1;;){if(O==t)break e;if(k<r.length&&r[k].from==O)O=r[k++].to;else{if(we[O]==l)break e;break}}if(f++,p)p.push(b);else{b.from>a&&o.push(new Tt(a,b.from,y));let O=b.direction==Yi!=!(y%2);ta(n,O?i+1:i,s,b.inner,b.from,b.to,o),a=b.to}v=b.to}else{if(v==t||(c?we[v]!=l:we[v]==l))break;v++}p?ea(n,a,v,i+1,s,p,o):a<v&&o.push(new Tt(a,v,y)),a=v}else for(let a=t,f=r.length;a>e;){let c=!0,u=!1;if(!f||a>r[f-1].to){let b=we[a-1];b!=l&&(c=!1,u=b==16)}let p=!c&&l==1?[]:null,y=c?i:i+1,v=a;e:for(;;)if(f&&v==r[f-1].to){if(u)break e;let b=r[--f];if(!c)for(let O=b.from,k=f;;){if(O==e)break e;if(k&&r[k-1].to==O)O=r[--k].from;else{if(we[O-1]==l)break e;break}}if(p)p.push(b);else{b.to<a&&o.push(new Tt(b.to,a,y));let O=b.direction==Yi!=!(y%2);ta(n,O?i+1:i,s,b.inner,b.from,b.to,o),a=b.from}v=b.from}else{if(v==e||(c?we[v-1]!=l:we[v-1]==l))break;v--}p?ea(n,v,a,i+1,s,p,o):v<a&&o.push(new Tt(v,a,y)),a=v}}function ta(n,e,t,i,s,r,o){let l=e%2?2:1;Bv(n,s,r,i,l),$v(n,s,r,i,l),Fv(s,r,i,l),ea(n,s,r,e,t,i,o)}function Wv(n,e,t){if(!n)return[new Tt(0,0,e==Ba?1:0)];if(e==Yi&&!t.length&&!qv.test(n))return fp(n.length);if(t.length)for(;n.length>we.length;)we[we.length]=256;let i=[],s=e==Yi?0:1;return ta(n,s,s,t,0,n.length,i),i}function fp(n){return[new Tt(0,n,0)]}var hp="";function zv(n,e,t,i,s){var r;if(!n.length)return null;let o=i.head-n.from,l;if(i.head==n.from&&i.assoc<0){if(!s)return null;o=e[l=0].side(!1,t)}else if(i.head==n.to&&i.assoc>0){if(s)return null;o=e[l=e.length-1].side(!0,t)}else l=Tt.find(e,o,(r=i.bidiLevel)!==null&&r!==void 0?r:-1,i.assoc);let a=e[l],f=a.side(s,t);if(o==f){let p=l+=s?1:-1;if(p<0||p>=e.length)return null;a=e[l=p],o=a.side(!s,t),f=a.side(s,t)}let c=Ee(n.text,o,a.forward(s,t));(c<a.from||c>a.to)&&(c=f),hp=n.text.slice(Math.min(o,c),Math.max(o,c));let u=l==(s?e.length-1:0)?null:e[l+(s?1:-1)];if(c==f){if(!u)return s?M.cursor(n.to,1):M.cursor(n.from,-1);if(u.level+(s?0:1)<a.level)return M.cursor(u.side(!s,t)+n.from,u.forward(s,t)?1:-1,u.level)}return M.cursor(c+n.from,a.forward(s,t)?-1:1,a.level)}function jv(n,e,t){for(let i=e;i<t;i++){let s=lp(n.charCodeAt(i));if(s==1)return Yi;if(s==2||s==4)return Ba}return Yi}var cp=W.define(),dp=W.define(),up=W.define(),pp=W.define(),ia=W.define(),mp=W.define(),gp=W.define(),$a=W.define(),Fa=W.define(),_p=W.define({combine:n=>n.some(e=>e)}),yp=W.define({combine:n=>n.some(e=>e)}),bp=W.define(),gn=class n{constructor(e,t,i,s,r,o=!1){this.range=e,this.y=t,this.x=i,this.yMargin=s,this.xMargin=r,this.isSnapshot=o}map(e){return e.empty?this:new n(this.range.map(e),this.y,this.x,this.yMargin,this.xMargin,this.isSnapshot)}clip(e){return this.range.to<=e.doc.length?this:new n(M.cursor(e.doc.length),this.y,this.x,this.yMargin,this.xMargin,this.isSnapshot)}},br=ne.define({map:(n,e)=>n.map(e)}),vp=ne.define();function tt(n,e,t){let i=n.facet(pp);i.length?i[0](e):window.onerror&&window.onerror(String(e),t,void 0,void 0,e)||(t?console.error(t+":",e):console.error(e))}var ri=W.define({combine:n=>n.length?n[0]:!0}),Vv=0,Cs=W.define({combine(n){return n.filter((e,t)=>{for(let i=0;i<t;i++)if(n[i].plugin==e.plugin)return!1;return!0})}}),qe=class n{constructor(e,t,i,s,r){this.id=e,this.create=t,this.domEventHandlers=i,this.domEventObservers=s,this.baseExtensions=r(this),this.extension=this.baseExtensions.concat(Cs.of({plugin:this,arg:void 0}))}of(e){return this.baseExtensions.concat(Cs.of({plugin:this,arg:e}))}static define(e,t){let{eventHandlers:i,eventObservers:s,provide:r,decorations:o}=t||{};return new n(Vv++,e,i,s,l=>{let a=[];return o&&a.push(Xr.of(f=>{let c=f.plugin(l);return c?o(c):K.none})),r&&a.push(r(l)),a})}static fromClass(e,t){return n.define((i,s)=>new e(i,s),t)}},_n=class{constructor(e){this.spec=e,this.mustUpdate=null,this.value=null}get plugin(){return this.spec&&this.spec.plugin}update(e){if(this.value){if(this.mustUpdate){let t=this.mustUpdate;if(this.mustUpdate=null,this.value.update)try{this.value.update(t)}catch(i){if(tt(t.state,i,"CodeMirror plugin crashed"),this.value.destroy)try{this.value.destroy()}catch{}this.deactivate()}}}else if(this.spec)try{this.value=this.spec.plugin.create(e,this.spec.arg)}catch(t){tt(e.state,t,"CodeMirror plugin crashed"),this.deactivate()}return this}destroy(e){var t;if(!((t=this.value)===null||t===void 0)&&t.destroy)try{this.value.destroy()}catch(i){tt(e.state,i,"CodeMirror plugin crashed")}}deactivate(){this.spec=this.value=null}},Op=W.define(),Wa=W.define(),Xr=W.define(),wp=W.define(),za=W.define(),Pn=W.define(),kp=W.define();function Ou(n,e){let t=n.state.facet(kp);if(!t.length)return t;let i=t.map(r=>r instanceof Function?r(n):r),s=[];return ce.spans(i,e.from,e.to,{point(){},span(r,o,l,a){let f=r-e.from,c=o-e.from,u=s;for(let p=l.length-1;p>=0;p--,a--){let y=l[p].spec.bidiIsolate,v;if(y==null&&(y=jv(e.text,f,c)),a>0&&u.length&&(v=u[u.length-1]).to==f&&v.direction==y)v.to=c,u=v.inner;else{let b={from:f,to:c,direction:y,inner:[]};u.push(b),u=b.inner}}}}),s}var xp=W.define();function ja(n){let e=0,t=0,i=0,s=0;for(let r of n.state.facet(xp)){let o=r(n);o&&(o.left!=null&&(e=Math.max(e,o.left)),o.right!=null&&(t=Math.max(t,o.right)),o.top!=null&&(i=Math.max(i,o.top)),o.bottom!=null&&(s=Math.max(s,o.bottom)))}return{left:e,right:t,top:i,bottom:s}}var dn=W.define(),Lt=class n{constructor(e,t,i,s){this.fromA=e,this.toA=t,this.fromB=i,this.toB=s}join(e){return new n(Math.min(this.fromA,e.fromA),Math.max(this.toA,e.toA),Math.min(this.fromB,e.fromB),Math.max(this.toB,e.toB))}addToSet(e){let t=e.length,i=this;for(;t>0;t--){let s=e[t-1];if(!(s.fromA>i.toA)){if(s.toA<i.fromA)break;i=i.join(s),e.splice(t-1,1)}}return e.splice(t,0,i),e}static extendWithRanges(e,t){if(t.length==0)return e;let i=[];for(let s=0,r=0,o=0;;){let l=s<e.length?e[s].fromB:1e9,a=r<t.length?t[r]:1e9,f=Math.min(l,a);if(f==1e9)break;let c=f+o,u=f,p=c;for(;;)if(r<t.length&&t[r]<=u){let y=t[r+1];r+=2,u=Math.max(u,y);for(let v=s;v<e.length&&e[v].fromB<=u;v++)o=e[v].toA-e[v].toB;p=Math.max(p,y+o)}else if(s<e.length&&e[s].fromB<=u){let y=e[s++];u=Math.max(u,y.toB),p=Math.max(p,y.toA),o=y.toA-y.toB}else break;i.push(new n(c,p,f,u))}return i}},Qr=class n{constructor(e,t,i){this.view=e,this.state=t,this.transactions=i,this.flags=0,this.startState=e.state,this.changes=Ze.empty(this.startState.doc.length);for(let r of i)this.changes=this.changes.compose(r.changes);let s=[];this.changes.iterChangedRanges((r,o,l,a)=>s.push(new Lt(r,o,l,a))),this.changedRanges=s}static create(e,t,i){return new n(e,t,i)}get viewportChanged(){return(this.flags&4)>0}get viewportMoved(){return(this.flags&8)>0}get heightChanged(){return(this.flags&2)>0}get geometryChanged(){return this.docChanged||(this.flags&18)>0}get focusChanged(){return(this.flags&1)>0}get docChanged(){return!this.changes.empty}get selectionSet(){return this.transactions.some(e=>e.selection)}get empty(){return this.flags==0&&this.transactions.length==0}},Hv=[],Se=class{constructor(e,t,i=0){this.dom=e,this.length=t,this.flags=i,this.parent=null,e.cmTile=this}get breakAfter(){return this.flags&1}get children(){return Hv}isWidget(){return!1}get isHidden(){return!1}isComposite(){return!1}isLine(){return!1}isText(){return!1}isBlock(){return!1}get domAttrs(){return null}sync(e){if(this.flags|=2,this.flags&4){this.flags&=-5;let t=this.domAttrs;t&&Ev(this.dom,t)}}toString(){return this.constructor.name+(this.children.length?`(${this.children})`:"")+(this.breakAfter?"#":"")}destroy(){this.parent=null}setDOM(e){this.dom=e,e.cmTile=this}get posAtStart(){return this.parent?this.parent.posBefore(this):0}get posAtEnd(){return this.posAtStart+this.length}posBefore(e,t=this.posAtStart){let i=t;for(let s of this.children){if(s==e)return i;i+=s.length+s.breakAfter}throw new RangeError("Invalid child in posBefore")}posAfter(e){return this.posBefore(e)+e.length}covers(e){return!0}coordsIn(e,t,i){return null}domPosFor(e,t){let i=Oi(this.dom),s=this.length?e>0:t>0;return new Jt(this.parent.dom,i+(s?1:0),e==0||e==this.length)}markDirty(e){this.flags&=-3,e&&(this.flags|=4),this.parent&&this.parent.flags&2&&this.parent.markDirty(!1)}get overrideDOMText(){return null}get root(){for(let e=this;e;e=e.parent)if(e instanceof Is)return e;return null}static get(e){return e.cmTile}},Ds=class extends Se{constructor(e){super(e,0),this._children=[]}isComposite(){return!0}get children(){return this._children}get lastChild(){return this.children.length?this.children[this.children.length-1]:null}append(e){this.children.push(e),e.parent=this}sync(e){if(this.flags&2)return;super.sync(e);let t=this.dom,i=null,s,r=(e==null?void 0:e.node)==t?e:null,o=0;for(let l of this.children){if(l.sync(e),o+=l.length+l.breakAfter,s=i?i.nextSibling:t.firstChild,r&&s!=l.dom&&(r.written=!0),l.dom.parentNode==t)for(;s&&s!=l.dom;)s=wu(s);else t.insertBefore(l.dom,s);i=l.dom}for(s=i?i.nextSibling:t.firstChild,r&&s&&(r.written=!0);s;)s=wu(s);this.length=o}};function wu(n){let e=n.nextSibling;return n.parentNode.removeChild(n),e}var Is=class extends Ds{constructor(e,t){super(t),this.view=e}owns(e){for(;e;e=e.parent)if(e==this)return!0;return!1}isBlock(){return!0}nearest(e){for(;;){if(!e)return null;let t=Se.get(e);if(t&&this.owns(t))return t;e=e.parentNode}}blockTiles(e){for(let t=[],i=this,s=0,r=0;;)if(s==i.children.length){if(!t.length)return;i=i.parent,i.breakAfter&&r++,s=t.pop()}else{let o=i.children[s++];if(o instanceof oi)t.push(s),i=o,s=0;else{let l=r+o.length,a=e(o,r);if(a!==void 0)return a;r=l+o.breakAfter}}}resolveBlock(e,t){let i,s=-1,r,o=-1;if(this.blockTiles((l,a)=>{let f=a+l.length;if(e>=a&&e<=f){if(l.isWidget()&&t>=-1&&t<=1){if(l.flags&32)return!0;l.flags&16&&(i=void 0)}(a<e||e==f&&(t<-1?l.length:l.covers(1)))&&(!i||!l.isWidget()&&i.isWidget())&&(i=l,s=e-a),(f>e||e==a&&(t>1?l.length:l.covers(-1)))&&(!r||!l.isWidget()&&r.isWidget())&&(r=l,o=e-a)}}),!i&&!r)throw new Error("No tile at position "+e);return i&&t<0||!r?{tile:i,offset:s}:{tile:r,offset:o}}},oi=class n extends Ds{constructor(e,t){super(e),this.wrapper=t}isBlock(){return!0}covers(e){return this.children.length?e<0?this.children[0].covers(-1):this.lastChild.covers(1):!1}get domAttrs(){return this.wrapper.attributes}static of(e,t){let i=new n(t||document.createElement(e.tagName),e);return t||(i.flags|=4),i}},Ls=class n extends Ds{constructor(e,t){super(e),this.attrs=t}isLine(){return!0}static start(e,t,i){let s=new n(t||document.createElement("div"),e);return(!t||!i)&&(s.flags|=4),s}get domAttrs(){return this.attrs}resolveInline(e,t,i){let s=null,r=-1,o=null,l=-1;function a(c,u){for(let p=0,y=0;p<c.children.length&&y<=u;p++){let v=c.children[p],b=y+v.length;b>=u&&(v.isComposite()?a(v,u-y):(!o||o.isHidden&&(t>0&&!(o.flags&32)||i&&Gv(o,v)))&&(b>u||v.flags&32&&t<=1)?(o=v,l=u-y):(y<u||v.flags&16&&!v.isHidden&&t>=-1)&&(s=v,r=u-y)),y=b}}a(this,e);let f=(t<0?s:o)||s||o;return f?{tile:f,offset:f==s?r:l}:null}coordsIn(e,t,i){let s=this.resolveInline(e,t,!0);return s?s.tile.coordsIn(Math.max(0,s.offset),t,i):Uv(this)}domIn(e,t){let i=this.resolveInline(e,t);if(i){let{tile:s,offset:r}=i;if(this.dom.contains(s.dom))return s.isText()?new Jt(s.dom,Math.min(s.dom.nodeValue.length,r)):s.domPosFor(r,s.flags&16?1:s.flags&32?-1:t);let o=i.tile.parent,l=!1;for(let a of o.children){if(l)return new Jt(a.dom,0);a==i.tile&&(l=!0)}}return new Jt(this.dom,0)}};function Uv(n){let e=n.dom.lastChild;if(!e)return n.dom.getBoundingClientRect();let t=Pr(e);return t[t.length-1]||null}function Gv(n,e){let t=n.coordsIn(0,1),i=e.coordsIn(0,1);return t&&i&&i.top<t.bottom}var at=class n extends Ds{constructor(e,t){super(e),this.mark=t}get domAttrs(){return this.mark.attrs}static of(e,t){let i=new n(t||document.createElement(e.tagName),e);return t||(i.flags|=4),i}},Gi=class n extends Se{constructor(e,t){super(e,t.length),this.text=t}sync(e){this.flags&2||(super.sync(e),this.dom.nodeValue!=this.text&&(e&&e.node==this.dom&&(e.written=!0),this.dom.nodeValue=this.text))}isText(){return!0}toString(){return JSON.stringify(this.text)}coordsIn(e,t,i){let s=this.dom.nodeValue.length;e>s&&(e=s);let r=e,o=e,l=0;e==0&&t<0||e==s&&t>=0?F.chrome||F.gecko||(e?(r--,l=1):o<s&&(o++,l=-1)):t<0?r--:o<s&&o++;let a=Sn(this.dom,r,o).getClientRects();if(!a.length)return null;let f=a[(l?l<0:t>=0)?0:a.length-1];return F.safari&&!l&&f.width==0&&(f=Array.prototype.find.call(a,c=>c.width)||f),i==null?f:Lr(f,(l?l>0:t<0)==i)}static of(e,t){let i=new n(t||document.createTextNode(e),e);return t||(i.flags|=2),i}},Ki=class n extends Se{constructor(e,t,i,s){super(e,t,s),this.widget=i}isWidget(){return!0}get isHidden(){return this.widget.isHidden}covers(e){return this.flags&48?!1:(this.flags&(e<0?64:128))>0}coordsIn(e,t){return this.coordsInWidget(e,t,!1)}coordsInWidget(e,t,i){let s=this.widget.coordsAt(this.dom,e,t);if(s)return s;if(i)return Lr(this.dom.getBoundingClientRect(),this.length?e==0:t<=0);{let r=this.dom.getClientRects(),o=null;if(!r.length)return null;let l=this.flags&16?!0:this.flags&32?!1:e>0;for(let a=l?r.length-1:0;o=r[a],!(e>0?a==0:a==r.length-1||o.top<o.bottom);a+=l?-1:1);return Lr(o,!l)}}get overrideDOMText(){if(!this.length)return oe.empty;let{root:e}=this;if(!e)return oe.empty;let t=this.posAtStart;return e.view.state.doc.slice(t,t+this.length)}destroy(){super.destroy(),this.widget.destroy(this.dom)}static of(e,t,i,s,r){return r||(r=e.toDOM(t),e.editable||(r.contentEditable="false")),new n(r,i,e,s)}},Qs=class extends Se{constructor(e){let t=document.createElement("img");t.className="cm-widgetBuffer",t.setAttribute("aria-hidden","true"),super(t,0,e)}get isHidden(){return!0}get overrideDOMText(){return oe.empty}coordsIn(e,t,i){let s=this.dom.getBoundingClientRect();return i==null?s:Lr(s,t>0==i)}},sa=class{constructor(e){this.index=0,this.beforeBreak=!1,this.parents=[],this.tile=e}advance(e,t,i){let{tile:s,index:r,beforeBreak:o,parents:l}=this;for(;e||t>0;)if(s.isComposite())if(o){if(!e)break;i&&i.break(),e--,o=!1}else if(r==s.children.length){if(!e&&!l.length)break;i&&i.leave(s),o=!!s.breakAfter,{tile:s,index:r}=l.pop(),r++}else{let a=s.children[r],f=a.breakAfter;(t>0?a.length<=e:a.length<e)&&(!i||i.skip(a,0,a.length)!==!1||!a.isComposite)?(o=!!f,r++,e-=a.length):(l.push({tile:s,index:r}),s=a,r=0,i&&a.isComposite()&&i.enter(a))}else{let a=s.length;if(r<a&&e){let f=Math.min(e,a-r);i&&i.skip(s,r,r+f),e-=f,r+=f}if(r==a)o=!!s.breakAfter,{tile:s,index:r}=l.pop(),r++;else if(!e)break}return this.tile=s,this.index=r,this.beforeBreak=o,this}get root(){return this.parents.length?this.parents[0].tile:this.tile}},na=class{constructor(e,t,i,s){this.from=e,this.to=t,this.wrapper=i,this.rank=s}},ra=class{constructor(e,t,i){this.cache=e,this.root=t,this.blockWrappers=i,this.curLine=null,this.lastBlock=null,this.afterWidget=null,this.pos=0,this.wrappers=[],this.wrapperPos=0}addText(e,t,i,s){var r;this.flushBuffer();let o=this.ensureMarks(t,i),l=o.lastChild;if(l&&l.isText()&&!(l.flags&8)&&l.length+e.length<512){this.cache.reused.set(l,2);let a=o.children[o.children.length-1]=new Gi(l.dom,l.text+e);a.parent=o}else o.append(s||Gi.of(e,(r=this.cache.find(Gi))===null||r===void 0?void 0:r.dom));this.pos+=e.length,this.afterWidget=null}addComposition(e,t){let i=this.curLine;i.dom!=t.line.dom&&(i.setDOM(this.cache.reused.has(t.line)?Fl(t.line.dom):t.line.dom),this.cache.reused.set(t.line,2));let s=i;for(let l=t.marks.length-1;l>=0;l--){let a=t.marks[l],f=s.lastChild;if(f instanceof at&&f.mark.eq(a.mark))f.dom!=a.dom&&f.setDOM(Fl(a.dom)),s=f;else{let{dom:c}=a;this.cache.reused.get(a)&&Se.get(a.dom)&&(c=Fl(a.dom));let u=at.of(a.mark,c);s.append(u),s=u}this.cache.reused.set(a,2)}let r=Se.get(e.text);r&&this.cache.reused.set(r,2);let o=new Gi(e.text,e.text.nodeValue);o.flags|=8,this.pos=e.range.toB,s.append(o)}addInlineWidget(e,t,i){let s=this.afterWidget&&e.flags&48&&(this.afterWidget.flags&48)==(e.flags&48);s||this.flushBuffer();let r=this.ensureMarks(t,i);!s&&!(e.flags&16)&&r.append(this.getBuffer(1)),r.append(e),this.pos+=e.length,this.afterWidget=e}addMark(e,t,i){this.flushBuffer(),this.ensureMarks(t,i).append(e),this.pos+=e.length,this.afterWidget=null}addBlockWidget(e){this.getBlockPos().append(e),this.pos+=e.length,this.lastBlock=e,this.endLine()}continueWidget(e){let t=this.afterWidget||this.lastBlock;t.length+=e,this.pos+=e}addLineStart(e,t){var i;e||(e=Sp);let s=Ls.start(e,t||((i=this.cache.find(Ls))===null||i===void 0?void 0:i.dom),!!t);this.getBlockPos().append(this.lastBlock=this.curLine=s)}addLine(e){this.getBlockPos().append(e),this.pos+=e.length,this.lastBlock=e,this.endLine()}addBreak(){this.lastBlock.flags|=1,this.endLine(),this.pos++}addLineStartIfNotCovered(e){this.blockPosCovered()||this.addLineStart(e)}ensureLine(e){this.curLine||this.addLineStart(e)}ensureMarks(e,t){var i;let s=this.curLine;for(let r=e.length-1;r>=0;r--){let o=e[r],l;if(t>0&&(l=s.lastChild)&&l instanceof at&&l.mark.eq(o))s=l,t--;else{let a=at.of(o,(i=this.cache.find(at,f=>f.mark.eq(o)))===null||i===void 0?void 0:i.dom);s.append(a),s=a,t=0}}return s}endLine(){if(this.curLine){this.flushBuffer();let e=this.curLine.lastChild;(!e||!ku(this.curLine,!1)||e.dom.nodeName!="BR"&&e.isWidget()&&!(F.ios&&ku(this.curLine,!0)))&&this.curLine.append(this.cache.findWidget(Wl,0,32)||new Ki(Wl.toDOM(),0,Wl,32)),this.curLine=this.afterWidget=null}}updateBlockWrappers(){this.wrapperPos>this.pos+1e4&&(this.blockWrappers.goto(this.pos),this.wrappers.length=0);for(let e=this.wrappers.length-1;e>=0;e--)this.wrappers[e].to<this.pos&&this.wrappers.splice(e,1);for(let e=this.blockWrappers;e.value&&e.from<=this.pos;e.next())if(e.to>=this.pos){let t=e.rank*102+e.value.rank,i=new na(e.from,e.to,e.value,t),s=this.wrappers.length;for(;s>0&&(this.wrappers[s-1].rank-i.rank||this.wrappers[s-1].to-i.to)<0;)s--;this.wrappers.splice(s,0,i)}this.wrapperPos=this.pos}getBlockPos(){var e;this.updateBlockWrappers();let t=this.root;for(let i of this.wrappers){let s=t.lastChild;if(i.from<this.pos&&s instanceof oi&&s.wrapper.eq(i.wrapper))t=s;else{let r=oi.of(i.wrapper,(e=this.cache.find(oi,o=>o.wrapper.eq(i.wrapper)))===null||e===void 0?void 0:e.dom);t.append(r),t=r}}return t}blockPosCovered(){let e=this.lastBlock;return e!=null&&!e.breakAfter&&(!e.isWidget()||(e.flags&160)>0)}getBuffer(e){let t=2|(e<0?16:32),i=this.cache.find(Qs,void 0,1);return i&&(i.flags=t),i||new Qs(t)}flushBuffer(){this.afterWidget&&!(this.afterWidget.flags&32)&&(this.afterWidget.parent.append(this.getBuffer(-1)),this.afterWidget=null)}},oa=class{constructor(e){this.skipCount=0,this.text="",this.textOff=0,this.cursor=e.iter()}skip(e){this.textOff+e<=this.text.length?this.textOff+=e:(this.skipCount+=e-(this.text.length-this.textOff),this.text="",this.textOff=0)}next(e){if(this.textOff==this.text.length){let{value:s,lineBreak:r,done:o}=this.cursor.next(this.skipCount);if(this.skipCount=0,o)throw new Error("Ran out of text content when drawing inline views");this.text=s;let l=this.textOff=Math.min(e,s.length);return r?null:s.slice(0,l)}let t=Math.min(this.text.length,this.textOff+e),i=this.text.slice(this.textOff,t);return this.textOff=t,i}},qr=[Ki,Ls,Gi,at,Qs,oi,Is];for(let n=0;n<qr.length;n++)qr[n].bucket=n;var la=class{constructor(e){this.view=e,this.buckets=qr.map(()=>[]),this.index=qr.map(()=>0),this.reused=new Map}add(e){let t=e.constructor.bucket,i=this.buckets[t];i.length<6?i.push(e):i[this.index[t]=(this.index[t]+1)%6]=e}find(e,t,i=2){let s=e.bucket,r=this.buckets[s],o=this.index[s];for(let l=0;l<r.length;l++){let a=(l+o)%r.length,f=r[a];if((!t||t(f))&&!this.reused.has(f))return r.splice(a,1),a<o&&this.index[s]--,this.reused.set(f,i),f}return null}findWidget(e,t,i){let s=this.buckets[0];if(s.length)for(let r=0,o=0;;r++){if(r==s.length){if(o)return null;o=1,r=0}let l=s[r];if(!this.reused.has(l)&&(o==0?l.widget.compare(e):l.widget.constructor==e.constructor&&e.updateDOM(l.dom,this.view,l.widget)))return s.splice(r,1),r<this.index[0]&&this.index[0]--,l.widget==e&&l.length==t&&(l.flags&497)==i?(this.reused.set(l,1),l):(this.reused.set(l,2),new Ki(l.dom,t,e,l.flags&-498|i))}}reuse(e){return this.reused.set(e,1),e}maybeReuse(e,t=2){if(!this.reused.has(e))return this.reused.set(e,t),e.dom}clear(){for(let e=0;e<this.buckets.length;e++)this.buckets[e].length=this.index[e]=0}},aa=class{constructor(e,t,i,s,r){this.view=e,this.decorations=s,this.disallowBlockEffectsFor=r,this.openWidget=!1,this.openMarks=0,this.cache=new la(e),this.text=new oa(e.state.doc),this.builder=new ra(this.cache,new Is(e,e.contentDOM),ce.iter(i)),this.cache.reused.set(t,2),this.old=new sa(t),this.reuseWalker={skip:(o,l,a)=>{if(this.cache.add(o),o.isComposite())return!1},enter:o=>this.cache.add(o),leave:()=>{},break:()=>{}}}run(e,t){let i=t&&this.getCompositionContext(t.text);for(let s=0,r=0,o=0;;){let l=o<e.length?e[o++]:null,a=l?l.fromA:this.old.root.length;if(a>s){let f=a-s;this.preserve(f,!o,!l),s=a,r+=f}if(!l)break;t&&l.fromA<=t.range.fromA&&l.toA>=t.range.toA?(this.forward(l.fromA,t.range.fromA,t.range.fromA<t.range.toA?1:-1),this.emit(r,t.range.fromB),this.builder.flushBuffer(),this.cache.clear(),this.builder.addComposition(t,i),this.text.skip(t.range.toB-t.range.fromB),this.forward(t.range.fromA,l.toA),this.emit(t.range.toB,l.toB)):(this.forward(l.fromA,l.toA),this.emit(r,l.toB)),r=l.toB,s=l.toA}return this.builder.curLine&&this.builder.endLine(),this.builder.root}preserve(e,t,i){let s=Yv(this.old),r=this.openMarks;this.old.advance(e,i?1:-1,{skip:(o,l,a)=>{if(o.isWidget())if(this.openWidget)this.builder.continueWidget(a-l);else{let f=a>0||l<o.length?Ki.of(o.widget,this.view,a-l,o.flags&496,this.cache.maybeReuse(o)):this.cache.reuse(o);f.flags&256?(f.flags&=-2,this.builder.addBlockWidget(f)):(this.builder.ensureLine(null),this.builder.addInlineWidget(f,s,r),r=s.length)}else if(o.isText())this.builder.ensureLine(null),!l&&a==o.length&&!this.cache.reused.has(o)?this.builder.addText(o.text,s,r,this.cache.reuse(o)):(this.cache.add(o),this.builder.addText(o.text.slice(l,a),s,r)),r=s.length;else if(o.isLine())o.flags&=-2,this.cache.reused.set(o,1),this.builder.addLine(o);else if(o instanceof Qs)this.cache.add(o);else if(o instanceof at)this.builder.ensureLine(null),this.builder.addMark(o,s,r),this.cache.reused.set(o,1),r=s.length;else return!1;this.openWidget=!1},enter:o=>{o.isLine()?this.builder.addLineStart(o.attrs,this.cache.maybeReuse(o)):(this.cache.add(o),o instanceof at&&s.unshift(o.mark)),this.openWidget=!1},leave:o=>{o.isLine()?s.length&&(s.length=r=0):o instanceof at&&(s.shift(),r=Math.min(r,s.length))},break:()=>{this.builder.addBreak(),this.openWidget=!1}}),this.text.skip(e)}emit(e,t){let i=null,s=this.builder,r=-1,o=ce.spans(this.decorations,e,t,{point:(l,a,f,c,u,p)=>{if(f instanceof Ji){if(this.disallowBlockEffectsFor[p]){if(f.block)throw new RangeError("Block decorations may not be specified via plugins");if(a>this.view.state.doc.lineAt(l).to)throw new RangeError("Decorations that replace line breaks may not be specified via plugins")}if(r=c.length,u>c.length)s.continueWidget(a-l);else{let y=f.widget||(f.block?wi.block:wi.inline),v=Xv(f),b=this.cache.findWidget(y,a-l,v)||Ki.of(y,this.view,a-l,v);f.block?(f.startSide>0&&s.addLineStartIfNotCovered(i),s.addBlockWidget(b)):(s.ensureLine(i),s.addInlineWidget(b,c,u))}i=null}else i=Jv(i,f);a>l&&this.text.skip(a-l)},span:(l,a,f,c)=>{for(let u=l;u<a;){let p=this.text.next(Math.min(512,a-u));p==null?(s.addLineStartIfNotCovered(i),s.addBreak(),u++):(s.ensureLine(i),s.addText(p,f,u==l?c:f.length),u+=p.length),i=null}r=f.length}});r>-1&&(this.openWidget=o>r),this.openWidget||s.addLineStartIfNotCovered(i),this.openMarks=o}forward(e,t,i=1){t-e<=10?this.old.advance(t-e,i,this.reuseWalker):(this.old.advance(5,-1,this.reuseWalker),this.old.advance(t-e-10,-1),this.old.advance(5,i,this.reuseWalker))}getCompositionContext(e){let t=[],i=null;for(let s=e.parentNode;;s=s.parentNode){let r=Se.get(s);if(s==this.view.contentDOM)break;r instanceof at?t.push(r):r!=null&&r.isLine()?i=r:r instanceof oi||(s.nodeName=="DIV"&&!i?i=new Ls(s,Sp):i||t.push(at.of(new wn({tagName:s.nodeName.toLowerCase(),attributes:Av(s)}),s)))}return i?{line:i,marks:t}:null}};function ku(n,e){let t=i=>{for(let s of i.children)if((e?s.isText():s.length)||t(s))return!0;return!1};return t(n)}function Xv(n){let e=n.isReplace?(n.startSide<0?64:0)|(n.endSide>0?128:0):n.startSide>0?32:16;return n.block&&(e|=256),e}var Sp={class:"cm-line"};function Jv(n,e){let t=e.spec.attributes,i=e.spec.class;return!t&&!i||(n||(n={class:"cm-line"}),t&&Qa(t,n),i&&(n.class+=" "+i)),n}function Yv(n){let e=[];for(let t=n.parents.length;t>1;t--){let i=t==n.parents.length?n.tile:n.parents[t].tile;i instanceof at&&e.push(i.mark)}return e}function Fl(n){let e=Se.get(n);return e&&e.setDOM(n.cloneNode()),n}var wi=class extends li{constructor(e){super(),this.tag=e}eq(e){return e.tag==this.tag}toDOM(){return document.createElement(this.tag)}updateDOM(e){return e.nodeName.toLowerCase()==this.tag}get isHidden(){return!0}};wi.inline=new wi("span");wi.block=new wi("div");var Wl=new class extends li{toDOM(){return document.createElement("br")}get isHidden(){return!0}get editable(){return!0}},Br=class{constructor(e){this.view=e,this.decorations=[],this.blockWrappers=[],this.dynamicDecorationMap=[!1],this.domChanged=null,this.hasComposition=null,this.editContextFormatting=K.none,this.lastCompositionAfterCursor=!1,this.minWidth=0,this.minWidthFrom=0,this.minWidthTo=0,this.impreciseAnchor=null,this.impreciseHead=null,this.forceSelection=!1,this.lastUpdate=Date.now(),this.updateDeco(),this.tile=new Is(e,e.contentDOM),this.updateInner([new Lt(0,0,0,e.state.doc.length)],null)}update(e){var t;let i=e.changedRanges;this.minWidth>0&&i.length&&(i.every(({fromA:c,toA:u})=>u<this.minWidthFrom||c>this.minWidthTo)?(this.minWidthFrom=e.changes.mapPos(this.minWidthFrom,1),this.minWidthTo=e.changes.mapPos(this.minWidthTo,1)):this.minWidth=this.minWidthFrom=this.minWidthTo=0),this.updateEditContextFormatting(e);let s=-1;this.view.inputState.composing>=0&&!this.view.observer.editContext&&(!((t=this.domChanged)===null||t===void 0)&&t.newSel?s=this.domChanged.newSel.head:!rO(e.changes,this.hasComposition)&&!e.selectionSet&&(s=e.state.selection.main.head));let r=s>-1?Zv(this.view,e.changes,s):null;if(this.domChanged=null,this.hasComposition){let{from:c,to:u}=this.hasComposition;i=new Lt(c,u,e.changes.mapPos(c,-1),e.changes.mapPos(u,1)).addToSet(i.slice())}this.hasComposition=r?{from:r.range.fromB,to:r.range.toB}:null,(F.ie||F.chrome)&&!r&&e&&e.state.doc.lines!=e.startState.doc.lines&&(this.forceSelection=!0);let o=this.decorations,l=this.blockWrappers;this.updateDeco();let a=iO(o,this.decorations,e.changes);a.length&&(i=Lt.extendWithRanges(i,a));let f=sO(l,this.blockWrappers,e.changes);return f.length&&(i=Lt.extendWithRanges(i,f)),r&&!i.some(c=>c.fromA<=r.range.fromA&&c.toA>=r.range.toA)&&(i=r.range.addToSet(i.slice())),this.tile.flags&2&&i.length==0?!1:(this.updateInner(i,r),e.transactions.length&&(this.lastUpdate=Date.now()),!0)}updateInner(e,t){this.view.viewState.mustMeasureContent=!0;let{observer:i}=this.view;i.ignore(()=>{if(t||e.length){let o=this.tile,l=new aa(this.view,o,this.blockWrappers,this.decorations,this.dynamicDecorationMap);t&&Se.get(t.text)&&l.cache.reused.set(Se.get(t.text),2),this.tile=l.run(e,t),fa(o,l.cache.reused)}this.tile.dom.style.height=this.view.viewState.contentHeight/this.view.scaleY+"px",this.tile.dom.style.flexBasis=this.minWidth?this.minWidth+"px":"";let r=F.chrome||F.ios?{node:i.selectionRange.focusNode,written:!1}:void 0;this.tile.sync(r),r&&(r.written||i.selectionRange.focusNode!=r.node||!this.tile.dom.contains(r.node))&&(this.forceSelection=!0),this.tile.dom.style.height=""});let s=[];if(this.view.viewport.from||this.view.viewport.to<this.view.state.doc.length)for(let r of this.tile.children)r.isWidget()&&r.widget instanceof yn&&s.push(r.dom);i.updateGaps(s)}updateEditContextFormatting(e){this.editContextFormatting=this.editContextFormatting.map(e.changes);for(let t of e.transactions)for(let i of t.effects)i.is(vp)&&(this.editContextFormatting=i.value)}updateSelection(e=!1,t=!1){(e||!this.view.observer.selectionRange.focusNode)&&this.view.observer.readSelectionRange();let{dom:i}=this.tile,s=this.view.root.activeElement,r=s==i,o=!r&&!(this.view.state.facet(ri)||i.tabIndex>-1)&&pn(i,this.view.observer.selectionRange)&&!(s&&i.contains(s));if(!(r||t||o))return;let l=this.forceSelection;this.forceSelection=!1;let a=this.view.state.selection.main,f,c;if(a.empty?c=f=this.inlineDOMNearPos(a.anchor,a.assoc||1):(c=this.inlineDOMNearPos(a.head,a.head==a.from?1:-1),f=this.inlineDOMNearPos(a.anchor,a.anchor==a.from?1:-1)),F.gecko&&a.empty&&!this.hasComposition&&Kv(f)){let p=document.createTextNode("");this.view.observer.ignore(()=>f.node.insertBefore(p,f.node.childNodes[f.offset]||null)),f=c=new Jt(p,0),l=!0}let u=this.view.observer.selectionRange;(l||!u.focusNode||(!mn(f.node,f.offset,u.anchorNode,u.anchorOffset)||!mn(c.node,c.offset,u.focusNode,u.focusOffset))&&!this.suppressWidgetCursorChange(u,a))&&(this.view.observer.ignore(()=>{F.android&&F.chrome&&i.contains(u.focusNode)&&nO(u.focusNode,i)&&(i.blur(),i.focus({preventScroll:!0}));let p=xn(this.view.root);if(p)if(a.empty){if(F.gecko){let y=eO(f.node,f.offset);if(y&&y!=3){let v=(y==1?np:rp)(f.node,f.offset);v&&(f=new Jt(v.node,v.offset))}}p.collapse(f.node,f.offset),a.bidiLevel!=null&&p.caretBidiLevel!==void 0&&(p.caretBidiLevel=a.bidiLevel)}else if(p.extend){p.collapse(f.node,f.offset);try{p.extend(c.node,c.offset)}catch{}}else{let y=document.createRange();a.anchor>a.head&&([f,c]=[c,f]),y.setEnd(c.node,c.offset),y.setStart(f.node,f.offset),p.removeAllRanges(),p.addRange(y)}o&&this.view.root.activeElement==i&&(i.blur(),s&&s.focus())}),this.view.observer.setSelectionRange(f,c)),this.impreciseAnchor=f.precise?null:new Jt(u.anchorNode,u.anchorOffset),this.impreciseHead=c.precise?null:new Jt(u.focusNode,u.focusOffset)}suppressWidgetCursorChange(e,t){return this.hasComposition&&t.empty&&mn(e.focusNode,e.focusOffset,e.anchorNode,e.anchorOffset)&&this.posFromDOM(e.focusNode,e.focusOffset)==t.head}enforceCursorAssoc(){if(this.hasComposition)return;let{view:e}=this,t=e.state.selection.main,i=xn(e.root),{anchorNode:s,anchorOffset:r}=e.observer.selectionRange;if(!i||!t.empty||!t.assoc||!i.modify)return;let o=this.lineAt(t.head,t.assoc);if(!o)return;let l=o.posAtStart;if(t.head==l||t.head==l+o.length)return;let a=this.coordsAt(t.head,-1),f=this.coordsAt(t.head,1);if(!a||!f||a.bottom>f.top)return;let c=this.domAtPos(t.head+t.assoc,t.assoc);i.collapse(c.node,c.offset),i.modify("move",t.assoc<0?"forward":"backward","lineboundary"),e.observer.readSelectionRange();let u=e.observer.selectionRange;e.docView.posFromDOM(u.anchorNode,u.anchorOffset)!=t.from&&i.collapse(s,r)}posFromDOM(e,t){let i=this.tile.nearest(e);if(!i)return this.tile.dom.compareDocumentPosition(e)&2?0:this.view.state.doc.length;let s=i.posAtStart;if(i.isComposite()){let r;if(e==i.dom)r=i.dom.childNodes[t];else{let o=ai(e)==0?0:t==0?-1:1;for(;;){let l=e.parentNode;if(l==i.dom)break;o==0&&l.firstChild!=l.lastChild&&(e==l.firstChild?o=-1:o=1),e=l}o<0?r=e:r=e.nextSibling}if(r==i.dom.firstChild)return s;for(;r&&!Se.get(r);)r=r.nextSibling;if(!r)return s+i.length;for(let o=0,l=s;;o++){let a=i.children[o];if(a.dom==r)return l;l+=a.length+a.breakAfter}}else return i.isText()?e==i.dom?s+t:s+(t?i.length:0):s}domAtPos(e,t){let{tile:i,offset:s}=this.tile.resolveBlock(e,t);return i.isWidget()?i.domPosFor(s,t):i.domIn(s,t)}inlineDOMNearPos(e,t){let i,s=-1,r=!1,o,l=-1,a=!1;return this.tile.blockTiles((f,c)=>{if(f.isWidget()){if(f.flags&32&&c>=e)return!0;f.flags&16&&(r=!0)}else{let u=c+f.length;if(c<=e&&(i=f,s=e-c,r=u<e),u>=e&&!o&&(o=f,l=e-c,a=c>e),c>e&&o)return!0}}),!i&&!o?this.domAtPos(e,t):(r&&o?i=null:a&&i&&(o=null),i&&t<0||!o?i.domIn(s,t):o.domIn(l,t))}coordsAt(e,t,i){let{tile:s,offset:r}=this.tile.resolveBlock(e,t);return s.isWidget()?s.widget instanceof yn?null:s.coordsInWidget(r,t,!0):s.coordsIn(r,t,i)}lineAt(e,t){let{tile:i}=this.tile.resolveBlock(e,t);return i.isLine()?i:null}coordsForChar(e){let{tile:t,offset:i}=this.tile.resolveBlock(e,1);if(!t.isLine())return null;function s(r,o){if(r.isComposite())for(let l of r.children){if(l.length>=o){let a=s(l,o);if(a)return a}if(o-=l.length,o<0)break}else if(r.isText()&&o<r.length){let l=Ee(r.text,o);if(l==o)return null;let a=Sn(r.dom,o,l).getClientRects();for(let f=0;f<a.length;f++){let c=a[f];if(f==a.length-1||c.top<c.bottom&&c.left<c.right)return c}}return null}return s(t,i)}measureVisibleLineHeights(e){let t=[],{from:i,to:s}=e,r=this.view.contentDOM.clientWidth,o=r>Math.max(this.view.scrollDOM.clientWidth,this.minWidth)+1,l=-1,a=this.view.textDirection==_e.LTR,f=0,c=(u,p,y)=>{for(let v=0;v<u.children.length&&!(p>s);v++){let b=u.children[v],O=p+b.length,k=b.dom.getBoundingClientRect(),{height:T}=k;if(y&&!v&&(f+=k.top-y.top),b instanceof oi)O>i&&c(b,p,k);else if(p>=i&&(f>0&&t.push(-f),t.push(T+f),f=0,o)){let P=b.dom.lastChild,I=P?Pr(P):[];if(I.length){let E=I[I.length-1],R=a?E.right-k.left:k.right-E.left;R>l&&(l=R,this.minWidth=r,this.minWidthFrom=p,this.minWidthTo=O)}}y&&v==u.children.length-1&&(f+=y.bottom-k.bottom),p=O+b.breakAfter}};return c(this.tile,0,null),t}textDirectionAt(e){let{tile:t}=this.tile.resolveBlock(e,1);return getComputedStyle(t.dom).direction=="rtl"?_e.RTL:_e.LTR}measureTextSize(){let e=this.tile.blockTiles(o=>{if(o.isLine()&&o.children.length&&o.length<=20){let l=0,a;for(let f of o.children){if(!f.isText()||/[^ -~]/.test(f.text))return;let c=Pr(f.dom);if(c.length!=1)return;l+=c[0].width,a=c[0].height}if(l)return{lineHeight:o.dom.getBoundingClientRect().height,charWidth:l/o.length,textHeight:a}}});if(e)return e;let t=document.createElement("div"),i,s,r;return t.className="cm-line",t.style.width="99999px",t.style.position="absolute",t.textContent="abc def ghi jkl mno pqr stu",this.view.observer.ignore(()=>{this.tile.dom.appendChild(t);let o=Pr(t.firstChild)[0];i=t.getBoundingClientRect().height,s=o&&o.width?o.width/27:7,r=o&&o.height?o.height:i,t.remove()}),{lineHeight:i,charWidth:s,textHeight:r}}computeBlockGapDeco(){let e=[],t=this.view.viewState;for(let i=0,s=0;;s++){let r=s==t.viewports.length?null:t.viewports[s],o=r?r.from-1:this.view.state.doc.length;if(o>i){let l=(t.lineBlockAt(o).bottom-t.lineBlockAt(i).top)/this.view.scaleY;e.push(K.replace({widget:new yn(l),block:!0,inclusive:!0,isBlockGap:!0}).range(i,o))}if(!r)break;i=r.to+1}return K.set(e)}updateDeco(){let e=1,t=this.view.state.facet(Xr).map(r=>(this.dynamicDecorationMap[e++]=typeof r=="function")?r(this.view):r),i=!1,s=this.view.state.facet(za).map((r,o)=>{let l=typeof r=="function";return l&&(i=!0),l?r(this.view):r});for(s.length&&(this.dynamicDecorationMap[e++]=i,t.push(ce.join(s))),this.decorations=[this.editContextFormatting,...t,this.computeBlockGapDeco(),this.view.viewState.lineGapDeco];e<this.decorations.length;)this.dynamicDecorationMap[e++]=!1;this.blockWrappers=this.view.state.facet(wp).map(r=>typeof r=="function"?r(this.view):r)}scrollIntoView(e){if(e.isSnapshot){let f=this.view.viewState.lineBlockAt(e.range.head);this.view.scrollDOM.scrollTop=f.top-e.yMargin,this.view.scrollDOM.scrollLeft=e.xMargin;return}for(let f of this.view.state.facet(bp))try{if(f(this.view,e.range,e))return!0}catch(c){tt(this.view.state,c,"scroll handler")}let{range:t}=e,i=this.coordsAt(t.head,t.assoc||(t.head>t.anchor?-1:1)),s;if(!i)return;!t.empty&&(s=this.coordsAt(t.anchor,t.anchor>t.head?-1:1))&&(i={left:Math.min(i.left,s.left),top:Math.min(i.top,s.top),right:Math.max(i.right,s.right),bottom:Math.max(i.bottom,s.bottom)});let r=ja(this.view),o={left:i.left-r.left,top:i.top-r.top,right:i.right+r.right,bottom:i.bottom+r.bottom},{offsetWidth:l,offsetHeight:a}=this.view.scrollDOM;if(Nv(this.view.scrollDOM,o,t.head<t.anchor?-1:1,e.x,e.y,Math.max(Math.min(e.xMargin,l),-l),Math.max(Math.min(e.yMargin,a),-a),this.view.textDirection==_e.LTR),window.visualViewport&&window.innerHeight-window.visualViewport.height>1&&(i.top>window.visualViewport.offsetTop+window.visualViewport.height||i.bottom<window.visualViewport.offsetTop)){let f=this.view.docView.lineAt(t.head,1);if(f){let c=ep(f.dom);f.dom.scrollIntoView({block:"nearest"}),tp(c,!1)}}}lineHasWidget(e){let t=i=>i.isWidget()||i.children.some(t);return t(this.tile.resolveBlock(e,1).tile)}destroy(){fa(this.tile)}};function fa(n,e){let t=e==null?void 0:e.get(n);if(t!=1){t==null&&n.destroy();for(let i of n.children)fa(i,e)}}function Kv(n){return n.node.nodeType==1&&n.node.firstChild&&(n.offset==0||n.node.childNodes[n.offset-1].contentEditable=="false")&&(n.offset==n.node.childNodes.length||n.node.childNodes[n.offset].contentEditable=="false")}function Tp(n,e){let t=n.observer.selectionRange;if(!t.focusNode)return null;let i=np(t.focusNode,t.focusOffset),s=rp(t.focusNode,t.focusOffset),r=i||s;if(s&&i&&s.node!=i.node){let l=Se.get(s.node);if(!l||l.isText()&&l.text!=s.node.nodeValue)r=s;else if(n.docView.lastCompositionAfterCursor){let a=Se.get(i.node);!a||a.isText()&&a.text!=i.node.nodeValue||(r=s)}}if(n.docView.lastCompositionAfterCursor=r!=i,!r)return null;let o=e-r.offset;return{from:o,to:o+r.node.nodeValue.length,node:r.node}}function Zv(n,e,t){let i=Tp(n,t);if(!i)return null;let{node:s,from:r,to:o}=i,l=s.nodeValue;if(/[\n\r]/.test(l)||n.state.doc.sliceString(i.from,i.to)!=l)return null;let a=e.invertedDesc;return{range:new Lt(a.mapPos(r),a.mapPos(o),r,o),text:s}}function eO(n,e){return n.nodeType!=1?0:(e&&n.childNodes[e-1].contentEditable=="false"?1:0)|(e<n.childNodes.length&&n.childNodes[e].contentEditable=="false"?2:0)}var tO=class{constructor(){this.changes=[]}compareRange(e,t){Ms(e,t,this.changes)}comparePoint(e,t){Ms(e,t,this.changes)}boundChange(e){Ms(e,e,this.changes)}};function iO(n,e,t){let i=new tO;return ce.compare(n,e,t,i),i.changes}var ha=class{constructor(){this.changes=[]}compareRange(e,t){Ms(e,t,this.changes)}comparePoint(){}boundChange(e){Ms(e,e,this.changes)}};function sO(n,e,t){let i=new ha;return ce.compare(n,e,t,i),i.changes}function nO(n,e){for(let t=n;t&&t!=e;t=t.assignedSlot||t.parentNode)if(t.nodeType==1&&t.contentEditable=="false")return!0;return!1}function rO(n,e){let t=!1;return e&&n.iterChangedRanges((i,s)=>{i<e.to&&s>e.from&&(t=!0)}),t}var yn=class extends li{constructor(e){super(),this.height=e}toDOM(){let e=document.createElement("div");return e.className="cm-gap",this.updateDOM(e),e}eq(e){return e.height==this.height}updateDOM(e){return e.style.height=this.height+"px",!0}get editable(){return!0}get estimatedHeight(){return this.height}ignoreEvent(){return!1}};function oO(n,e,t=1){let i=n.charCategorizer(e),s=n.doc.lineAt(e),r=e-s.from;if(s.length==0)return M.cursor(e);r==0?t=1:r==s.length&&(t=-1);let o=r,l=r;t<0?o=Ee(s.text,r,!1):l=Ee(s.text,r);let a=i(s.text.slice(o,l));for(;o>0;){let f=Ee(s.text,o,!1);if(i(s.text.slice(f,o))!=a)break;o=f}for(;l<s.length;){let f=Ee(s.text,l);if(i(s.text.slice(l,f))!=a)break;l=f}return M.undirectionalRange(o+s.from,l+s.from)}function lO(n,e,t,i,s){let r=Math.round((i-e.left)*n.defaultCharacterWidth);if(n.lineWrapping&&t.height>n.defaultLineHeight*1.5){let l=n.viewState.heightOracle.textHeight,a=Math.floor((s-t.top-(n.defaultLineHeight-l)*.5)/l);r+=a*n.viewState.heightOracle.lineLength}let o=n.state.sliceDoc(t.from,t.to);return t.from+fu(o,r,n.state.tabSize)}function ca(n,e,t){let i=n.lineBlockAt(e);if(Array.isArray(i.type)){let s;for(let r of i.type){if(r.from>e)break;if(!(r.to<e)){if(r.from<e&&r.to>e)return r;(!s||r.type==Ve.Text&&(s.type!=r.type||(t<0?r.from<e:r.to>e)))&&(s=r)}}return s||i}return i}function aO(n,e,t,i){let s=ca(n,e.head,e.assoc||-1),r=!i||s.type!=Ve.Text||!(n.lineWrapping||s.widgetLineBreaks)?null:n.coordsAtPos(e.assoc<0&&e.head>s.from?e.head-1:e.head);if(r){let o=n.dom.getBoundingClientRect(),l=n.textDirectionAt(s.from),a=n.posAtCoords({x:t==(l==_e.LTR)?o.right-1:o.left+1,y:(r.top+r.bottom)/2});if(a!=null)return M.cursor(a,t?-1:1)}return M.cursor(t?s.to:s.from,t?-1:1)}function xu(n,e,t,i){let s=n.state.doc.lineAt(e.head),r=n.bidiSpans(s),o=n.textDirectionAt(s.from);for(let l=e,a=null;;){let f=zv(s,r,o,l,t),c=hp;if(!f){if(s.number==(t?n.state.doc.lines:1))return l;c=`
`,s=n.state.doc.line(s.number+(t?1:-1)),r=n.bidiSpans(s),f=t?M.cursor(s.from,-1):M.cursor(s.to,1)}if(a){if(!a(c))return l}else{if(!i)return f;a=i(c)}l=f}}function fO(n,e,t){let i=n.state.charCategorizer(e),s=i(t);return r=>{let o=i(r);return s==be.Space&&(s=o),s==o}}function hO(n,e,t,i){let s=e.head,r=t?1:-1;if(s==(t?n.state.doc.length:0))return M.cursor(s,e.assoc);let o=e.goalColumn,l,a=n.contentDOM.getBoundingClientRect(),f=n.coordsAtPos(s,e.assoc||((e.empty?t:e.head==e.from)?1:-1)),c=n.documentTop;if(f)o==null&&(o=f.left-a.left),l=r<0?f.top:f.bottom;else{let v=n.viewState.lineBlockAt(s);o==null&&(o=Math.min(a.right-a.left,n.defaultCharacterWidth*(s-v.from))),l=(r<0?v.top:v.bottom)+c}let u=a.left+o,p=n.viewState.heightOracle.textHeight>>1,y=i??p;for(let v=0;;v+=p){let b=l+(y+v)*r,O=da(n,{x:u,y:b},!1,r);if(t?b>a.bottom:b<a.top)return M.cursor(O.pos,O.assoc);let k=n.coordsAtPos(O.pos,O.assoc),T=k?(k.top+k.bottom)/2:0;if(!k||(t?T>l:T<l))return M.cursor(O.pos,O.assoc,void 0,o)}}function bn(n,e,t){for(;;){let i=0;for(let s of n)s.between(e-1,e+1,(r,o,l)=>{if(e>r&&e<o){let a=i||t||(e-r<o-e?-1:1);e=a<0?r:o,i=a}});if(!i)return e}}function Pp(n,e){let t=null;for(let i=0;i<e.ranges.length;i++){let s=e.ranges[i],r=null;if(s.empty){let o=bn(n,s.from,0);o!=s.from&&(r=M.cursor(o,-1))}else{let o=bn(n,s.from,-1),l=bn(n,s.to,1);(o!=s.from||l!=s.to)&&(s.undirectional?r=M.undirectionalRange(s.from,s.to):r=M.range(s.from==s.anchor?o:l,s.from==s.head?o:l))}r&&(t||(t=e.ranges.slice()),t[i]=r)}return t?M.create(t,e.mainIndex):e}function zl(n,e,t){let i=bn(n.state.facet(Pn).map(s=>s(n)),t.from,e.head>t.from?-1:1);return i==t.from?t:M.cursor(i,i<t.from?1:-1)}var St=class{constructor(e,t){this.pos=e,this.assoc=t}};function da(n,e,t,i){let s=n.contentDOM.getBoundingClientRect(),r=s.top+n.viewState.paddingTop,{x:o,y:l}=e,a=l-r,f;for(;;){if(a<0)return new St(0,1);if(a>n.viewState.docHeight)return new St(n.state.doc.length,-1);if(f=n.elementAtHeight(a),i==null)break;if(f.type==Ve.Text){if(i<0?f.to<n.viewport.from:f.from>n.viewport.to)break;let p=n.docView.coordsAt(i<0?f.from:f.to,i>0?-1:1);if(p&&(i<0?p.top<=a+r:p.bottom>=a+r))break}let u=n.viewState.heightOracle.textHeight/2;a=i>0?f.bottom+u:f.top-u}if(n.viewport.from>=f.to||n.viewport.to<=f.from){if(t)return null;if(f.type==Ve.Text){let u=lO(n,s,f,o,l);return new St(u,u==f.from?1:-1)}}if(f.type!=Ve.Text)return a<(f.top+f.bottom)/2?new St(f.from,1):new St(f.to,-1);let c=n.docView.lineAt(f.from,2);return(!c||c.length!=f.length)&&(c=n.docView.lineAt(f.from,-2)),new ua(n,o,l,n.textDirectionAt(f.from)).scanTile(c,f.from)}var ua=class{constructor(e,t,i,s){this.view=e,this.x=t,this.y=i,this.baseDir=s,this.line=null,this.spans=null}bidiSpansAt(e){return(!this.line||this.line.from>e||this.line.to<e)&&(this.line=this.view.state.doc.lineAt(e),this.spans=this.view.bidiSpans(this.line)),this}baseDirAt(e,t){let{line:i,spans:s}=this.bidiSpansAt(e);return s[Tt.find(s,e-i.from,-1,t)].level==this.baseDir}dirAt(e,t){let{line:i,spans:s}=this.bidiSpansAt(e);return s[Tt.find(s,e-i.from,-1,t)].dir}bidiIn(e,t){let{spans:i,line:s}=this.bidiSpansAt(e);return i.length>1||i.length&&(i[0].level!=this.baseDir||i[0].to+s.from<t)}scan(e,t,i=!1){let s=0,r=e.length-1,o=new Set,l=this.bidiIn(e[0],e[r]),a,f,c=-1,u=1e9,p;e:for(;s<r;){let v=r-s,b=s+r>>1;t:if(o.has(b)){for(let T=1;T<v;T++){let P=b+T;if(P>=r&&(P-=v),!o.has(P)){b=P;break t}}break e}o.add(b);let O=t(b),k=0;if(O)for(let T=0;T<O.length;T++){let P=O[T];if(!(P.width==0&&O.length>1))if(P.bottom<this.y)(!a||a.bottom<P.bottom)&&(a=P),k=1;else if(P.top>this.y)(!f||f.top>P.top)&&(f=P),k=-1;else{let I=P.left>this.x?this.x-P.left:P.right<this.x?this.x-P.right:0,E=Math.abs(I);E<u&&(c=b,u=E,p=P),I&&(k=I<0==(this.baseDir==_e.LTR)?-1:1)}}k==-1&&(!l||this.baseDirAt(e[b],1))?r=b:k==1&&(!l||this.baseDirAt(e[b+1],-1))&&(s=b+1)}if(!p){if(!f&&!a)return{i:0,after:!1};let v=a&&(!f||this.y-a.bottom<f.top-this.y)?a:f;return this.y=(v.top+v.bottom)/2,this.scan(e,t,!0)}if(u&&!i){let{top:v,bottom:b}=p;if(a&&a.bottom>(v+v+b)/3)return this.y=a.bottom-1,this.scan(e,t,!0);if(f&&f.top<(v+b+b)/3)return this.y=f.top+1,this.scan(e,t,!0)}let y=(l?this.dirAt(e[c],1):this.baseDir)==_e.LTR;return{i:c,after:this.x>(p.left+p.right)/2==y}}scanText(e,t){let i=[];for(let r=0;r<e.length;r=Ee(e.text,r))i.push(t+r);i.push(t+e.length);let s=this.scan(i,r=>{let o=i[r]-t,l=i[r+1]-t;return Sn(e.dom,o,l).getClientRects()});return s.after?new St(i[s.i+1],-1):new St(i[s.i],1)}scanTile(e,t){if(!e.length)return new St(t,1);if(e.children.length==1){let l=e.children[0];if(l.isText())return this.scanText(l,t);if(l.isComposite())return this.scanTile(l,t)}let i=[t];for(let l=0,a=t;l<e.children.length;l++)i.push(a+=e.children[l].length);let s=this.scan(i,l=>{let a=e.children[l];return a.flags&48?null:(a.dom.nodeType==1?a.dom:Sn(a.dom,0,a.length)).getClientRects()}),r=e.children[s.i],o=i[s.i];return r.isText()?this.scanText(r,o):r.isComposite()?this.scanTile(r,o):s.after?new St(i[s.i+1],-1):new St(o,1)}},Ps="\uFFFF",pa=class{constructor(e,t){this.points=e,this.view=t,this.text="",this.lineSeparator=t.state.facet(pe.lineSeparator)}append(e){this.text+=e}lineBreak(){this.text+=Ps}readRange(e,t){if(!e)return this;let i=e.parentNode;for(let s=e;;){this.findPointBefore(i,s);let r=this.text.length;this.readNode(s);let o=Se.get(s),l=s.nextSibling;if(l==t){o!=null&&o.breakAfter&&!l&&i!=this.view.contentDOM&&this.lineBreak();break}let a=Se.get(l);(o&&a?o.breakAfter:(o?o.breakAfter:Ir(s))||Ir(l)&&(s.nodeName!="BR"||o!=null&&o.isWidget())&&this.text.length>r)&&!dO(l,t)&&this.lineBreak(),s=l}return this.findPointBefore(i,t),this}readTextNode(e){let t=e.nodeValue;for(let i of this.points)i.node==e&&(i.pos=this.text.length+Math.min(i.offset,t.length));for(let i=0,s=this.lineSeparator?null:/\r\n?|\n/g;;){let r=-1,o=1,l;if(this.lineSeparator?(r=t.indexOf(this.lineSeparator,i),o=this.lineSeparator.length):(l=s.exec(t))&&(r=l.index,o=l[0].length),this.append(t.slice(i,r<0?t.length:r)),r<0)break;if(this.lineBreak(),o>1)for(let a of this.points)a.node==e&&a.pos>this.text.length&&(a.pos-=o-1);i=r+o}}readNode(e){let t=Se.get(e),i=t&&t.overrideDOMText;if(i!=null){this.findPointInside(e,i.length);for(let s=i.iter();!s.next().done;)s.lineBreak?this.lineBreak():this.append(s.value)}else e.nodeType==3?this.readTextNode(e):e.nodeName=="BR"?e.nextSibling&&this.lineBreak():e.nodeType==1&&this.readRange(e.firstChild,null)}findPointBefore(e,t){for(let i of this.points)i.node==e&&e.childNodes[i.offset]==t&&(i.pos=this.text.length)}findPointInside(e,t){for(let i of this.points)(e.nodeType==3?i.node==e:e.contains(i.node))&&(i.pos=this.text.length+(cO(e,i.node,i.offset)?t:0))}};function cO(n,e,t){for(;;){if(!e||t<ai(e))return!1;if(e==n)return!0;t=Oi(e)+1,e=e.parentNode}}function dO(n,e){let t;for(;!(n==e||!n);n=n.nextSibling){let i=Se.get(n);if(!(i!=null&&i.isWidget()))return!1;i&&(t||(t=[])).push(i)}if(t)for(let i of t){let s=i.overrideDOMText;if(s!=null&&s.length)return!1}return!0}var $r=class{constructor(e,t){this.node=e,this.offset=t,this.pos=-1}},ma=class{constructor(e,t,i,s){this.typeOver=s,this.bounds=null,this.text="",this.domChanged=t>-1;let{impreciseHead:r,impreciseAnchor:o}=e.docView,l=e.state.selection;if(e.state.readOnly&&t>-1)this.newSel=null;else if(t>-1&&(this.bounds=Cp(e.docView.tile,t,i,0))){let a=r||o?[]:pO(e),f=new pa(a,e);f.readRange(this.bounds.startDOM,this.bounds.endDOM),this.text=f.text,this.newSel=mO(a,this.bounds.from)}else{let a=e.observer.selectionRange,f=r&&r.node==a.focusNode&&r.offset==a.focusOffset||!Yl(e.contentDOM,a.focusNode)?l.main.head:e.docView.posFromDOM(a.focusNode,a.focusOffset),c=o&&o.node==a.anchorNode&&o.offset==a.anchorOffset||!Yl(e.contentDOM,a.anchorNode)?l.main.anchor:e.docView.posFromDOM(a.anchorNode,a.anchorOffset),u=e.viewport;if((F.ios||F.chrome)&&f!=c&&Math.min(f,c)<=l.main.from&&Math.max(f,c)>=l.main.to&&(u.from>0||u.to<e.state.doc.length)){let p=Math.min(f,c),y=Math.max(f,c),v=u.from-p,b=u.to-y;(v==0||v==1||p==0)&&(b==0||b==-1||y==e.state.doc.length)&&(f=0,c=e.state.doc.length)}if(e.inputState.composing>-1&&l.ranges.length>1)this.newSel=l.replaceRange(M.range(c,f));else if(e.lineWrapping&&c==f&&!(l.main.empty&&l.main.head==f)&&e.inputState.lastTouchTime>Date.now()-100){let p=e.coordsAtPos(f,-1),y=0;p&&(y=e.inputState.lastTouchY<=p.bottom?-1:1),this.newSel=M.create([M.cursor(f,y)])}else this.newSel=M.single(c,f)}}};function Cp(n,e,t,i){if(n.isComposite()){let s=-1,r=-1,o=-1,l=-1;for(let a=0,f=i,c=i;a<n.children.length;a++){let u=n.children[a],p=f+u.length;if(f<e&&p>t)return Cp(u,e,t,f);if(p>=e&&s==-1&&(s=a,r=f),f>t&&u.dom.parentNode==n.dom){o=a,l=c;break}c=p,f=p+u.breakAfter}return{from:r,to:l<0?i+n.length:l,startDOM:(s?n.children[s-1].dom.nextSibling:null)||n.dom.firstChild,endDOM:o<n.children.length&&o>=0?n.children[o].dom:null}}else return n.isText()?{from:i,to:i+n.length,startDOM:n.dom,endDOM:n.dom.nextSibling}:null}function Ep(n,e){let t,{newSel:i}=e,{state:s}=n,r=s.selection.main,o=n.inputState.lastKeyTime>Date.now()-100?n.inputState.lastKeyCode:-1;if(e.bounds){let{from:l,to:a}=e.bounds,f=r.from,c=null;(o===8||F.android&&e.text.length<a-l)&&(f=r.to,c="end");let u=s.doc.sliceString(l,a,Ps),p,y;!r.empty&&r.from>=l&&r.to<=a&&(e.typeOver||u!=e.text)&&u.slice(0,r.from-l)==e.text.slice(0,r.from-l)&&u.slice(r.to-l)==e.text.slice(p=e.text.length-(u.length-(r.to-l)))?t={from:r.from,to:r.to,insert:oe.of(e.text.slice(r.from-l,p).split(Ps))}:(y=Ap(u,e.text,f-l,c))&&(F.chrome&&o==13&&y.toB==y.from+2&&e.text.slice(y.from,y.toB)==Ps+Ps&&y.toB--,t={from:l+y.from,to:l+y.toA,insert:oe.of(e.text.slice(y.from,y.toB).split(Ps))})}else i&&(!n.hasFocus&&s.facet(ri)||Fr(i,r))&&(i=null);if(!t&&!i)return!1;if((F.mac||F.android)&&t&&t.from==t.to&&t.from==r.head-1&&/^\. ?$/.test(t.insert.toString())&&n.contentDOM.getAttribute("autocorrect")=="off"?(i&&t.insert.length==2&&(i=M.single(i.main.anchor-1,i.main.head-1)),t={from:t.from,to:t.to,insert:oe.of([t.insert.toString().replace("."," ")])}):s.doc.lineAt(r.from).to<r.to&&n.docView.lineHasWidget(r.to)&&n.inputState.insertingTextAt>Date.now()-50?t={from:r.from,to:r.to,insert:s.toText(n.inputState.insertingText)}:F.chrome&&t&&t.from==t.to&&t.from==r.head&&t.insert.toString()==`
 `&&n.lineWrapping&&(i&&(i=M.single(i.main.anchor-1,i.main.head-1)),t={from:r.from,to:r.to,insert:oe.of([" "])}),t)return Va(n,t,i,o);if(i&&!Fr(i,r)){let l=!1,a="select";return n.inputState.lastSelectionTime>Date.now()-50&&(n.inputState.lastSelectionOrigin=="select"&&(l=!0),a=n.inputState.lastSelectionOrigin,a=="select.pointer"&&(i=Pp(s.facet(Pn).map(f=>f(n)),i))),n.dispatch({selection:i,scrollIntoView:l,userEvent:a}),!0}else return!1}function Va(n,e,t,i=-1){if(F.ios&&n.inputState.flushIOSKey(e))return!0;let s=n.state.selection.main;if(F.android&&(e.to==s.to&&(e.from==s.from||e.from==s.from-1&&n.state.sliceDoc(e.from,s.from)==" ")&&e.insert.length==1&&e.insert.lines==2&&Ns(n.contentDOM,"Enter",13)||(e.from==s.from-1&&e.to==s.to&&e.insert.length==0||i==8&&e.insert.length<e.to-e.from&&e.to>s.head)&&Ns(n.contentDOM,"Backspace",8)||e.from==s.from&&e.to==s.to+1&&e.insert.length==0&&Ns(n.contentDOM,"Delete",46)))return!0;let r=e.insert.toString();n.inputState.composing>=0&&n.inputState.composing++;let o,l=()=>o||(o=uO(n,e,t));return n.state.facet(mp).some(a=>a(n,e.from,e.to,r,l))||n.dispatch(l()),!0}function uO(n,e,t){let i,s=n.state,r=s.selection.main,o=-1;if(e.from==e.to&&e.from<r.from||e.from>r.to){let a=e.from<r.from?-1:1,f=a<0?r.from:r.to,c=bn(s.facet(Pn).map(u=>u(n)),f,a);e.from==c&&(o=c)}if(o>-1)i={changes:e,selection:M.cursor(e.from+e.insert.length,-1)};else if(e.from>=r.from&&e.to<=r.to&&e.to-e.from>=(r.to-r.from)/3&&(!t||t.main.empty&&t.main.from==e.from+e.insert.length)&&n.inputState.composing<0){let a=r.from<e.from?s.sliceDoc(r.from,e.from):"",f=r.to>e.to?s.sliceDoc(e.to,r.to):"";i=s.replaceSelection(n.state.toText(a+e.insert.sliceString(0,void 0,n.state.lineBreak)+f))}else{let a=s.changes(e),f=t&&t.main.to<=a.newLength?t.main:void 0;if(s.selection.ranges.length>1&&(n.inputState.composing>=0||n.inputState.compositionPendingChange)&&e.to<=r.to+10&&e.to>=r.to-10){let c=n.state.sliceDoc(e.from,e.to),u,p=t&&Tp(n,t.main.head);if(p){let v=e.insert.length-(e.to-e.from);u={from:p.from,to:p.to-v}}else u=n.state.doc.lineAt(r.head);let y=r.to-e.to;i=s.changeByRange(v=>{if(v.from==r.from&&v.to==r.to)return{changes:a,range:f||v.map(a)};let b=v.to-y,O=b-c.length;if(n.state.sliceDoc(O,b)!=c||b>=u.from&&O<=u.to)return{range:v};let k=s.changes({from:O,to:b,insert:e.insert}),T=v.to-r.to;return{changes:k,range:f?M.range(Math.max(0,f.anchor+T),Math.max(0,f.head+T)):v.map(k)}})}else i={changes:a,selection:f&&s.selection.replaceRange(f)}}let l="input.type";return(n.composing||n.inputState.compositionPendingChange&&n.inputState.compositionEndedAt>Date.now()-50)&&(n.inputState.compositionPendingChange=!1,l+=".compose",n.inputState.compositionFirstChange&&(l+=".start",n.inputState.compositionFirstChange=!1)),s.update(i,{userEvent:l,scrollIntoView:!0})}function Ap(n,e,t,i){let s=Math.min(n.length,e.length),r=0;for(;r<s&&n.charCodeAt(r)==e.charCodeAt(r);)r++;if(r==s&&n.length==e.length)return null;let o=n.length,l=e.length;for(;o>0&&l>0&&n.charCodeAt(o-1)==e.charCodeAt(l-1);)o--,l--;if(i=="end"){let a=Math.max(0,r-Math.min(o,l));t-=o+a-r}if(o<r&&n.length<e.length){let a=t<=r&&t>=o?r-t:0;r-=a,l=r+(l-o),o=r}else if(l<r){let a=t<=r&&t>=l?r-t:0;r-=a,o=r+(o-l),l=r}return{from:r,toA:o,toB:l}}function pO(n){let e=[];if(n.root.activeElement!=n.contentDOM)return e;let{anchorNode:t,anchorOffset:i,focusNode:s,focusOffset:r}=n.observer.selectionRange;return t&&(e.push(new $r(t,i)),(s!=t||r!=i)&&e.push(new $r(s,r))),e}function mO(n,e){if(n.length==0)return null;let t=n[0].pos,i=n.length==2?n[1].pos:t;return t<0||i<0?null:t==i?M.create([M.cursor(i+e,-1)]):M.single(t+e,i+e)}function Fr(n,e){return e.head==n.main.head&&e.anchor==n.main.anchor}var ga=class{setSelectionOrigin(e){this.lastSelectionOrigin=e,this.lastSelectionTime=Date.now()}constructor(e){this.view=e,this.lastKeyCode=0,this.lastKeyTime=0,this.touchActive=!1,this.lastTouchTime=0,this.lastTouchX=0,this.lastTouchY=0,this.lastFocusTime=0,this.lastScrollTop=0,this.lastScrollLeft=0,this.lastWheelEvent=0,this.pendingIOSKey=void 0,this.lastIOSMomentumScroll=0,this.tabFocusMode=-1,this.lastSelectionOrigin=null,this.lastSelectionTime=0,this.lastContextMenu=0,this.scrollHandlers=[],this.handlers=Object.create(null),this.composing=-1,this.compositionFirstChange=null,this.compositionEndedAt=0,this.compositionPendingKey=!1,this.compositionPendingChange=!1,this.insertingText="",this.insertingTextAt=0,this.mouseSelection=null,this.draggedContent=null,this.handleEvent=this.handleEvent.bind(this),this.notifiedFocused=e.hasFocus,F.safari&&e.contentDOM.addEventListener("input",()=>null),F.gecko&&AO(e.contentDOM.ownerDocument)}handleEvent(e){!kO(this.view,e)||this.ignoreDuringComposition(e)||e.type=="keydown"&&this.keydown(e)||(this.view.updateState!=0?Promise.resolve().then(()=>this.runHandlers(e.type,e)):this.runHandlers(e.type,e))}runHandlers(e,t){let i=this.handlers[e];if(i){for(let s of i.observers)s(this.view,t);for(let s of i.handlers){if(t.defaultPrevented)break;if(s(this.view,t)){t.preventDefault();break}}}}ensureHandlers(e){let t=_O(e),i=this.handlers,s=this.view.contentDOM;for(let r in t)if(r!="scroll"){let o=!t[r].handlers.length,l=i[r];l&&o!=!l.handlers.length&&(s.removeEventListener(r,this.handleEvent),l=null),l||s.addEventListener(r,this.handleEvent,{passive:o})}for(let r in i)r!="scroll"&&!t[r]&&s.removeEventListener(r,this.handleEvent);this.handlers=t}keydown(e){if(this.lastKeyCode=e.keyCode,this.lastKeyTime=Date.now(),e.keyCode==9&&this.tabFocusMode>-1&&(!this.tabFocusMode||Date.now()<=this.tabFocusMode))return!0;if(this.tabFocusMode>0&&e.keyCode!=27&&Mp.indexOf(e.keyCode)<0&&(this.tabFocusMode=-1),F.android&&F.chrome&&!e.synthetic&&(e.keyCode==13||e.keyCode==8))return this.view.observer.delayAndroidKey(e.key,e.keyCode),!0;if(F.ios&&!e.synthetic&&!e.altKey&&!e.metaKey&&(Rp.some(t=>t.keyCode==e.keyCode)&&!e.ctrlKey||yO.indexOf(e.key)>-1&&e.ctrlKey)){let t={ctrlKey:e.ctrlKey,altKey:e.altKey,metaKey:e.metaKey,shiftKey:e.shiftKey};t.shiftKey&&F.ios&&!/^(off|none)$/.test(this.view.contentDOM.autocapitalize)&&gO(this.view.win)&&(t.shiftKey=!1);let i=this.pendingIOSKey={key:e.key,keyCode:e.keyCode,mods:t};return setTimeout(()=>{this.pendingIOSKey==i&&this.flushIOSKey()},50),!0}return e.keyCode!=229&&this.view.observer.forceFlush(),!1}flushIOSKey(e){let t=this.pendingIOSKey;return!t||this.view.observer.pendingRecords().length||t.key=="Enter"&&e&&e.from<e.to&&/^\S+$/.test(e.insert.toString())?!1:(this.pendingIOSKey=void 0,Ns(this.view.contentDOM,t.key,t.keyCode,t.mods))}ignoreDuringComposition(e){return!/^key/.test(e.type)||e.synthetic?!1:this.composing>0?!0:F.safari&&!F.ios&&this.compositionPendingKey&&Date.now()-this.compositionEndedAt<100?(this.compositionPendingKey=!1,!0):!1}startMouseSelection(e){this.mouseSelection&&this.mouseSelection.destroy(),this.mouseSelection=e}update(e){this.view.observer.update(e),this.mouseSelection&&this.mouseSelection.update(e),this.draggedContent&&e.docChanged&&(this.draggedContent=this.draggedContent.map(e.changes)),e.transactions.length&&(this.lastKeyCode=this.lastSelectionTime=0)}destroy(){this.mouseSelection&&this.mouseSelection.destroy()}};function gO(n){return n.visualViewport?n.visualViewport.height*n.visualViewport.scale/n.document.documentElement.clientHeight<.85:!1}function Su(n,e){return(t,i)=>{try{return e.call(n,i,t)}catch(s){tt(t.state,s)}}}function _O(n){let e=Object.create(null);function t(i){return e[i]||(e[i]={observers:[],handlers:[]})}for(let i of n){let s=i.spec,r=s&&s.plugin.domEventHandlers,o=s&&s.plugin.domEventObservers;if(r)for(let l in r){let a=r[l];a&&t(l).handlers.push(Su(i.value,a))}if(o)for(let l in o){let a=o[l];a&&t(l).observers.push(Su(i.value,a))}}for(let i in Qt)t(i).handlers.push(Qt[i]);for(let i in it)t(i).observers.push(it[i]);return e}var Rp=[{key:"Backspace",keyCode:8,inputType:"deleteContentBackward"},{key:"Enter",keyCode:13,inputType:"insertParagraph"},{key:"Enter",keyCode:13,inputType:"insertLineBreak"},{key:"Delete",keyCode:46,inputType:"deleteContentForward"}],yO="dthko",Mp=[16,17,18,20,91,92,224,225],vr=6;function Or(n){return Math.max(0,n)*.7+8}function bO(n,e){return Math.max(Math.abs(n.clientX-e.clientX),Math.abs(n.clientY-e.clientY))}var _a=class{constructor(e,t,i,s){this.view=e,this.startEvent=t,this.style=i,this.mustSelect=s,this.scrollSpeed={x:0,y:0},this.scrolling=-1,this.lastEvent=t,this.scrollParents=Zu(e.contentDOM),this.atoms=e.state.facet(Pn).map(o=>o(e));let r=e.contentDOM.ownerDocument;r.addEventListener("mousemove",this.move=this.move.bind(this)),r.addEventListener("mouseup",this.up=this.up.bind(this)),this.extend=t.shiftKey,this.multiple=e.state.facet(pe.allowMultipleSelections)&&vO(e,t),this.dragging=wO(e,t)&&Ip(t)==1?null:!1}start(e){this.dragging===!1&&this.select(e)}move(e){if(e.buttons==0)return this.destroy();if(this.dragging||this.dragging==null&&bO(this.startEvent,e)<10)return;this.select(this.lastEvent=e);let t=0,i=0,s=0,r=0,o=this.view.win.innerWidth,l=this.view.win.innerHeight;this.scrollParents.x&&({left:s,right:o}=this.scrollParents.x.getBoundingClientRect()),this.scrollParents.y&&({top:r,bottom:l}=this.scrollParents.y.getBoundingClientRect());let a=ja(this.view);e.clientX-a.left<=s+vr?t=-Or(s-e.clientX):e.clientX+a.right>=o-vr&&(t=Or(e.clientX-o)),e.clientY-a.top<=r+vr?i=-Or(r-e.clientY):e.clientY+a.bottom>=l-vr&&(i=Or(e.clientY-l)),this.setScrollSpeed(t,i)}up(e){this.dragging==null&&this.select(this.lastEvent),this.dragging||e.preventDefault(),this.destroy()}destroy(){this.setScrollSpeed(0,0);let e=this.view.contentDOM.ownerDocument;e.removeEventListener("mousemove",this.move),e.removeEventListener("mouseup",this.up),this.view.inputState.mouseSelection=this.view.inputState.draggedContent=null}setScrollSpeed(e,t){this.scrollSpeed={x:e,y:t},e||t?this.scrolling<0&&(this.scrolling=setInterval(()=>this.scroll(),50)):this.scrolling>-1&&(clearInterval(this.scrolling),this.scrolling=-1)}scroll(){let{x:e,y:t}=this.scrollSpeed;e&&this.scrollParents.x&&(this.scrollParents.x.scrollLeft+=e,e=0),t&&this.scrollParents.y&&(this.scrollParents.y.scrollTop+=t,t=0),(e||t)&&this.view.win.scrollBy(e,t),this.dragging===!1&&this.select(this.lastEvent)}select(e){let{view:t}=this,i=Pp(this.atoms,this.style.get(e,this.extend,this.multiple));(this.mustSelect||!i.eq(t.state.selection,this.dragging===!1))&&this.view.dispatch({selection:i,userEvent:"select.pointer"}),this.mustSelect=!1}update(e){e.transactions.some(t=>t.isUserEvent("input.type"))?this.destroy():this.style.update(e)&&setTimeout(()=>this.select(this.lastEvent),20)}};function vO(n,e){let t=n.state.facet(cp);return t.length?t[0](e):F.mac?e.metaKey:e.ctrlKey}function OO(n,e){let t=n.state.facet(dp);return t.length?t[0](e):F.mac?!e.altKey:!e.ctrlKey}function wO(n,e){let{main:t}=n.state.selection;if(t.empty)return!1;let i=xn(n.root);if(!i||i.rangeCount==0)return!0;let s=i.getRangeAt(0).getClientRects();for(let r=0;r<s.length;r++){let o=s[r];if(o.left<=e.clientX&&o.right>=e.clientX&&o.top<=e.clientY&&o.bottom>=e.clientY)return!0}return!1}function kO(n,e){if(!e.bubbles)return!0;if(e.defaultPrevented)return!1;for(let t=e.target,i;t!=n.contentDOM;t=t.parentNode)if(!t||t.nodeType==11||(i=Se.get(t))&&i.isWidget()&&!i.isHidden&&i.widget.ignoreEvent(e))return!1;return!0}var Qt=Object.create(null),it=Object.create(null),Np=F.ie&&F.ie_version<15||F.ios&&F.webkit_version<604;function xO(n){let e=n.dom.parentNode;if(!e)return;let t=e.appendChild(document.createElement("textarea"));t.style.cssText="position: fixed; left: -10000px; top: 10px",t.focus(),setTimeout(()=>{n.focus(),t.remove(),Dp(n,t.value)},50)}function Jr(n,e,t){for(let i of n.facet(e))t=i(t,n);return t}function Dp(n,e){e=Jr(n.state,$a,e);let{state:t}=n,i,s=1,r=t.toText(e),o=r.lines==t.selection.ranges.length;if(ya!=null&&t.selection.ranges.every(a=>a.empty)&&ya==r.toString()){let a=-1;i=t.changeByRange(f=>{let c=t.doc.lineAt(f.from);if(c.from==a)return{range:f};a=c.from;let u=t.toText((o?r.line(s++).text:e)+t.lineBreak);return{changes:{from:c.from,insert:u},range:M.cursor(f.from+u.length,-1)}})}else o?i=t.changeByRange(a=>{let f=r.line(s++);return{changes:{from:a.from,to:a.to,insert:f.text},range:M.cursor(a.from+f.length,-1)}}):i=t.replaceSelection(r);n.dispatch(i,{userEvent:"input.paste",scrollIntoView:!0})}it.scroll=n=>{let e=n.inputState;e.lastScrollTop=n.scrollDOM.scrollTop,e.lastScrollLeft=n.scrollDOM.scrollLeft,F.ios&&!e.touchActive&&(e.lastIOSMomentumScroll=Date.now())};it.wheel=it.mousewheel=n=>{n.inputState.lastWheelEvent=Date.now()};Qt.keydown=(n,e)=>(n.inputState.setSelectionOrigin("select"),e.keyCode==27&&n.inputState.tabFocusMode!=0&&(n.inputState.tabFocusMode=Date.now()+2e3),!1);it.touchstart=(n,e)=>{let t=n.inputState,i=e.targetTouches[0];t.touchActive=!0,t.lastTouchTime=Date.now(),i&&(t.lastTouchX=i.clientX,t.lastTouchY=i.clientY),t.setSelectionOrigin("select.pointer")};it.touchmove=n=>{n.inputState.setSelectionOrigin("select.pointer")};it.touchend=(n,e)=>{n.inputState.touchActive=!1};Qt.mousedown=(n,e)=>{if(n.observer.flush(),n.inputState.lastTouchTime>Date.now()-2e3)return!1;let t=null;for(let i of n.state.facet(up))if(t=i(n,e),t)break;if(!t&&e.button==0&&(t=TO(n,e)),t){let i=!n.hasFocus;n.inputState.startMouseSelection(new _a(n,e,t,i)),i&&n.observer.ignore(()=>{ip(n.contentDOM);let r=n.root.activeElement;r&&!r.contains(n.contentDOM)&&r.blur()});let s=n.inputState.mouseSelection;if(s)return s.start(e),s.dragging===!1}else n.inputState.setSelectionOrigin("select.pointer");return!1};function Tu(n,e,t,i){if(i==1)return M.cursor(e,t);if(i==2)return oO(n.state,e,t);{let s=n.docView.lineAt(e,t),r=n.state.doc.lineAt(s?s.posAtEnd:e),o=s?s.posAtStart:r.from,l=s?s.posAtEnd:r.to;return l<n.state.doc.length&&l==r.to&&l++,M.undirectionalRange(o,l)}}var SO=F.ie&&F.ie_version<=11,Pu=null,Cu=0,Eu=0;function Ip(n){if(!SO)return n.detail;let e=Pu,t=Eu;return Pu=n,Eu=Date.now(),Cu=!e||t>Date.now()-400&&Math.abs(e.clientX-n.clientX)<2&&Math.abs(e.clientY-n.clientY)<2?(Cu+1)%3:1}function TO(n,e){let t=n.posAndSideAtCoords({x:e.clientX,y:e.clientY},!1),i=Ip(e),s=n.state.selection;return{update(r){r.docChanged&&(t.pos=r.changes.mapPos(t.pos),s=s.map(r.changes))},get(r,o,l){let a=n.posAndSideAtCoords({x:r.clientX,y:r.clientY},!1),f,c=Tu(n,a.pos,a.assoc,i);if(t.pos!=a.pos&&!o){let u=Tu(n,t.pos,t.assoc,i),p=Math.min(u.from,c.from),y=Math.max(u.to,c.to);c=p<c.from?M.range(p,y,c.assoc):M.range(y,p,c.assoc)}return o?s.replaceRange(s.main.extend(c.from,c.to,c.assoc)):l&&i==1&&s.ranges.length>1&&(f=PO(s,a.pos))?f:l?s.addRange(c):M.create([c])}}}function PO(n,e){for(let t=0;t<n.ranges.length;t++){let{from:i,to:s}=n.ranges[t];if(i<=e&&s>=e)return M.create(n.ranges.slice(0,t).concat(n.ranges.slice(t+1)),n.mainIndex==t?0:n.mainIndex-(n.mainIndex>t?1:0))}return null}Qt.dragstart=(n,e)=>{let{selection:{main:t}}=n.state;if(e.target.draggable){let s=n.docView.tile.nearest(e.target);if(s&&s.isWidget()){let r=s.posAtStart,o=r+s.length;(r>=t.to||o<=t.from)&&(t=M.undirectionalRange(r,o))}}let{inputState:i}=n;return i.mouseSelection&&(i.mouseSelection.dragging=!0),i.draggedContent=t,e.dataTransfer&&(e.dataTransfer.setData("Text",Jr(n.state,Fa,n.state.sliceDoc(t.from,t.to))),e.dataTransfer.effectAllowed="copyMove"),!1};Qt.dragend=n=>(n.inputState.draggedContent=null,!1);function Au(n,e,t,i){if(t=Jr(n.state,$a,t),!t)return;let s=n.posAtCoords({x:e.clientX,y:e.clientY},!1),{draggedContent:r}=n.inputState,o=i&&r&&OO(n,e)?{from:r.from,to:r.to}:null,l={from:s,insert:t},a=n.state.changes(o?[o,l]:l);n.focus(),n.dispatch({changes:a,selection:{anchor:a.mapPos(s,-1),head:a.mapPos(s,1)},userEvent:o?"move.drop":"input.drop"}),n.inputState.draggedContent=null}Qt.drop=(n,e)=>{if(!e.dataTransfer)return!1;if(n.state.readOnly)return!0;let t=e.dataTransfer.files;if(t&&t.length){let i=Array(t.length),s=0,r=()=>{++s==t.length&&Au(n,e,i.filter(o=>o!=null).join(n.state.lineBreak),!1)};for(let o=0;o<t.length;o++){let l=new FileReader;l.onerror=r,l.onload=()=>{/[\x00-\x08\x0e-\x1f]{2}/.test(l.result)||(i[o]=l.result),r()},l.readAsText(t[o])}return!0}else{let i=e.dataTransfer.getData("Text");if(i)return Au(n,e,i,!0),!0}return!1};Qt.paste=(n,e)=>{if(n.state.readOnly)return!0;n.observer.flush();let t=Np?null:e.clipboardData;return t?(Dp(n,t.getData("text/plain")||t.getData("text/uri-list")),!0):(xO(n),!1)};function CO(n,e){let t=n.dom.parentNode;if(!t)return;let i=t.appendChild(document.createElement("textarea"));i.style.cssText="position: fixed; left: -10000px; top: 10px",i.value=e,i.focus(),i.selectionEnd=e.length,i.selectionStart=0,setTimeout(()=>{i.remove(),n.focus()},50)}function EO(n){let e=[],t=[],i=!1;for(let s of n.selection.ranges)s.empty||(e.push(n.sliceDoc(s.from,s.to)),t.push(s));if(!e.length){let s=-1;for(let{from:r}of n.selection.ranges){let o=n.doc.lineAt(r);o.number>s&&(e.push(o.text),t.push({from:o.from,to:Math.min(n.doc.length,o.to+1)})),s=o.number}i=!0}return{text:Jr(n,Fa,e.join(n.lineBreak)),ranges:t,linewise:i}}var ya=null;Qt.copy=Qt.cut=(n,e)=>{if(!pn(n.contentDOM,n.observer.selectionRange))return!1;let{text:t,ranges:i,linewise:s}=EO(n.state);if(!t&&!s)return!1;ya=s?t:null,e.type=="cut"&&!n.state.readOnly&&n.dispatch({changes:i,scrollIntoView:!0,userEvent:"delete.cut"});let r=Np?null:e.clipboardData;return r?(r.clearData(),r.setData("text/plain",t),!0):(CO(n,t),!1)};var Lp=lt.define();function Qp(n,e){let t=[];for(let i of n.facet(gp)){let s=i(n,e);s&&t.push(s)}return t.length?n.update({effects:t,annotations:Lp.of(!0)}):null}function qp(n){setTimeout(()=>{let e=n.hasFocus;if(e!=n.inputState.notifiedFocused){let t=Qp(n.state,e);t?n.dispatch(t):n.update([])}},10)}it.focus=n=>{n.inputState.lastFocusTime=Date.now(),!n.scrollDOM.scrollTop&&(n.inputState.lastScrollTop||n.inputState.lastScrollLeft)&&(n.scrollDOM.scrollTop=n.inputState.lastScrollTop,n.scrollDOM.scrollLeft=n.inputState.lastScrollLeft),qp(n)};it.blur=n=>{n.observer.clearSelectionRange(),qp(n)};it.compositionstart=it.compositionupdate=n=>{if(!n.observer.editContext&&(n.inputState.compositionFirstChange==null&&(n.inputState.compositionFirstChange=!0),n.inputState.composing<0)){let{main:e}=n.state.selection;!e.empty&&n.lineBlockAt(e.from).from!=n.lineBlockAt(e.to).from&&n.dispatch({changes:n.state.selection.ranges.filter(t=>!t.empty).map(t=>({from:t.from,to:t.to})),userEvent:"input"}),n.inputState.composing=0}};it.compositionend=n=>{n.observer.editContext||(n.inputState.composing=-1,n.inputState.compositionEndedAt=Date.now(),n.inputState.compositionPendingKey=!0,n.inputState.compositionPendingChange=n.observer.pendingRecords().length>0,n.inputState.compositionFirstChange=null,F.chrome&&F.android?n.observer.flushSoon():n.inputState.compositionPendingChange?Promise.resolve().then(()=>n.observer.flush()):setTimeout(()=>{n.inputState.composing<0&&n.docView.hasComposition&&n.update([])},50))};it.contextmenu=n=>{n.inputState.lastContextMenu=Date.now()};Qt.beforeinput=(n,e)=>{var t,i;if((e.inputType=="insertText"||e.inputType=="insertCompositionText")&&(n.inputState.insertingText=e.data,n.inputState.insertingTextAt=Date.now()),e.inputType=="insertReplacementText"&&n.observer.editContext){let r=(t=e.dataTransfer)===null||t===void 0?void 0:t.getData("text/plain"),o=e.getTargetRanges();if(r&&o.length){let l=o[0],a=n.posAtDOM(l.startContainer,l.startOffset),f=n.posAtDOM(l.endContainer,l.endOffset);return Va(n,{from:a,to:f,insert:n.state.toText(r)},null),!0}}let s;if(F.chrome&&F.android&&(s=Rp.find(r=>r.inputType==e.inputType))&&(n.observer.delayAndroidKey(s.key,s.keyCode),s.key=="Backspace"||s.key=="Delete")){let r=((i=window.visualViewport)===null||i===void 0?void 0:i.height)||0;setTimeout(()=>{var o;(((o=window.visualViewport)===null||o===void 0?void 0:o.height)||0)>r+10&&n.hasFocus&&(n.contentDOM.blur(),n.focus())},100)}return F.ios&&e.inputType=="deleteContentForward"&&n.observer.flushSoon(),F.safari&&e.inputType=="insertText"&&n.inputState.composing>=0&&setTimeout(()=>it.compositionend(n,e),20),!1};var Ru=new Set;function AO(n){Ru.has(n)||(Ru.add(n),n.addEventListener("copy",()=>{}),n.addEventListener("cut",()=>{}))}var Mu=["pre-wrap","normal","pre-line","break-spaces"],qs=!1;function Nu(){qs=!1}var ba=class{constructor(e){this.lineWrapping=e,this.doc=oe.empty,this.heightSamples={},this.lineHeight=14,this.charWidth=7,this.textHeight=14,this.lineLength=30}heightForGap(e,t){let i=this.doc.lineAt(t).number-this.doc.lineAt(e).number+1;return this.lineWrapping&&(i+=Math.max(0,Math.ceil((t-e-i*this.lineLength*.5)/this.lineLength))),this.lineHeight*i}heightForLine(e){return this.lineWrapping?(1+Math.max(0,Math.ceil((e-this.lineLength)/Math.max(1,this.lineLength-5))))*this.lineHeight:this.lineHeight}setDoc(e){return this.doc=e,this}mustRefreshForWrapping(e){return Mu.indexOf(e)>-1!=this.lineWrapping}mustRefreshForHeights(e){let t=!1;for(let i=0;i<e.length;i++){let s=e[i];s<0?i++:this.heightSamples[Math.floor(s*10)]||(t=!0,this.heightSamples[Math.floor(s*10)]=!0)}return t}refresh(e,t,i,s,r,o){let l=Mu.indexOf(e)>-1,a=Math.abs(t-this.lineHeight)>.3||this.lineWrapping!=l;if(this.lineWrapping=l,this.lineHeight=t,this.charWidth=i,this.textHeight=s,this.lineLength=r,a){this.heightSamples={};for(let f=0;f<o.length;f++){let c=o[f];c<0?f++:this.heightSamples[Math.floor(c*10)]=!0}}return a}},va=class{constructor(e,t){this.from=e,this.heights=t,this.index=0}get more(){return this.index<this.heights.length}},It=class n{constructor(e,t,i,s,r){this.from=e,this.length=t,this.top=i,this.height=s,this._content=r}get type(){return typeof this._content=="number"?Ve.Text:Array.isArray(this._content)?this._content:this._content.type}get to(){return this.from+this.length}get bottom(){return this.top+this.height}get widget(){return this._content instanceof Ji?this._content.widget:null}get widgetLineBreaks(){return typeof this._content=="number"?this._content:0}join(e){let t=(Array.isArray(this._content)?this._content:[this]).concat(Array.isArray(e._content)?e._content:[e]);return new n(this.from,this.length+e.length,this.top,this.height+e.height,t)}},ke=function(n){return n[n.ByPos=0]="ByPos",n[n.ByHeight=1]="ByHeight",n[n.ByPosNoHeight=2]="ByPosNoHeight",n}(ke||(ke={})),Cr=.001,dt=class n{constructor(e,t,i=2){this.length=e,this.height=t,this.flags=i}get outdated(){return(this.flags&2)>0}set outdated(e){this.flags=(e?2:0)|this.flags&-3}setHeight(e){this.height!=e&&(Math.abs(this.height-e)>Cr&&(qs=!0),this.height=e)}replace(e,t,i){return n.of(i)}decomposeLeft(e,t){t.push(this)}decomposeRight(e,t){t.push(this)}applyChanges(e,t,i,s){let r=this,o=i.doc;for(let l=s.length-1;l>=0;l--){let{fromA:a,toA:f,fromB:c,toB:u}=s[l],p=r.lineAt(a,ke.ByPosNoHeight,i.setDoc(t),0,0),y=p.to>=f?p:r.lineAt(f,ke.ByPosNoHeight,i,0,0);for(u+=y.to-f,f=y.to;l>0&&p.from<=s[l-1].toA;)a=s[l-1].fromA,c=s[l-1].fromB,l--,a<p.from&&(p=r.lineAt(a,ke.ByPosNoHeight,i,0,0));c+=p.from-a,a=p.from;let v=wa.build(i.setDoc(o),e,c,u);r=Wr(r,r.replace(a,f,v))}return r.updateHeight(i,0)}static empty(){return new xt(0,0,0)}static of(e){if(e.length==1)return e[0];let t=0,i=e.length,s=0,r=0;for(;;)if(t==i)if(s>r*2){let l=e[t-1];l.break?e.splice(--t,1,l.left,null,l.right):e.splice(--t,1,l.left,l.right),i+=1+l.break,s-=l.size}else if(r>s*2){let l=e[i];l.break?e.splice(i,1,l.left,null,l.right):e.splice(i,1,l.left,l.right),i+=2+l.break,r-=l.size}else break;else if(s<r){let l=e[t++];l&&(s+=l.size)}else{let l=e[--i];l&&(r+=l.size)}let o=!1;return e[t-1]==null?(o=!0,t--):e[t]==null&&(o=!0,i++),new Oa(n.of(e.slice(0,t)),o,n.of(e.slice(i)))}};function Wr(n,e){return n==e?n:(n.constructor!=e.constructor&&(qs=!0),e)}dt.prototype.size=1;var RO=K.replace({}),zr=class extends dt{constructor(e,t,i){super(e,t),this.deco=i,this.spaceAbove=0}mainBlock(e,t){return new It(t,this.length,e+this.spaceAbove,this.height-this.spaceAbove,this.deco||0)}blockAt(e,t,i,s){return this.spaceAbove&&e<i+this.spaceAbove?new It(s,0,i,this.spaceAbove,RO):this.mainBlock(i,s)}lineAt(e,t,i,s,r){let o=this.mainBlock(s,r);return this.spaceAbove?this.blockAt(0,i,s,r).join(o):o}forEachLine(e,t,i,s,r,o){e<=r+this.length&&t>=r&&o(this.lineAt(0,ke.ByPos,i,s,r))}setMeasuredHeight(e){let t=e.heights[e.index++];t<0?(this.spaceAbove=-t,t=e.heights[e.index++]):this.spaceAbove=0,this.setHeight(t)}updateHeight(e,t=0,i=!1,s){return s&&s.from<=t&&s.more&&this.setMeasuredHeight(s),this.outdated=!1,this}toString(){return`block(${this.length})`}},xt=class n extends zr{constructor(e,t,i){super(e,t,null),this.collapsed=0,this.widgetHeight=0,this.breaks=0,this.spaceAbove=i}mainBlock(e,t){return new It(t,this.length,e+this.spaceAbove,this.height-this.spaceAbove,this.breaks)}replace(e,t,i){let s=i[0];return i.length==1&&(s instanceof n||s instanceof vi&&s.flags&4)&&Math.abs(this.length-s.length)<10?(s instanceof vi?s=new n(s.length,this.height,this.spaceAbove):s.height=this.height,this.outdated||(s.outdated=!1),s):dt.of(i)}updateHeight(e,t=0,i=!1,s){return s&&s.from<=t&&s.more?this.setMeasuredHeight(s):(i||this.outdated)&&(this.spaceAbove=0,this.setHeight(Math.max(this.widgetHeight,e.heightForLine(this.length-this.collapsed))+this.breaks*e.lineHeight)),this.outdated=!1,this}toString(){return`line(${this.length}${this.collapsed?-this.collapsed:""}${this.widgetHeight?":"+this.widgetHeight:""})`}},vi=class n extends dt{constructor(e){super(e,0)}heightMetrics(e,t){let i=e.doc.lineAt(t).number,s=e.doc.lineAt(t+this.length).number,r=s-i+1,o,l=0;if(e.lineWrapping){let a=Math.min(this.height,e.lineHeight*r);o=a/r,this.length>r+1&&(l=(this.height-a)/(this.length-r-1))}else o=this.height/r;return{firstLine:i,lastLine:s,perLine:o,perChar:l}}blockAt(e,t,i,s){let{firstLine:r,lastLine:o,perLine:l,perChar:a}=this.heightMetrics(t,s);if(t.lineWrapping){let f=s+(e<t.lineHeight?0:Math.round(Math.max(0,Math.min(1,(e-i)/this.height))*this.length)),c=t.doc.lineAt(f),u=l+c.length*a,p=Math.max(i,e-u/2);return new It(c.from,c.length,p,u,0)}else{let f=Math.max(0,Math.min(o-r,Math.floor((e-i)/l))),{from:c,length:u}=t.doc.line(r+f);return new It(c,u,i+l*f,l,0)}}lineAt(e,t,i,s,r){if(t==ke.ByHeight)return this.blockAt(e,i,s,r);if(t==ke.ByPosNoHeight){let{from:y,to:v}=i.doc.lineAt(e);return new It(y,v-y,0,0,0)}let{firstLine:o,perLine:l,perChar:a}=this.heightMetrics(i,r),f=i.doc.lineAt(e),c=l+f.length*a,u=f.number-o,p=s+l*u+a*(f.from-r-u);return new It(f.from,f.length,Math.max(s,Math.min(p,s+this.height-c)),c,0)}forEachLine(e,t,i,s,r,o){e=Math.max(e,r),t=Math.min(t,r+this.length);let{firstLine:l,perLine:a,perChar:f}=this.heightMetrics(i,r);for(let c=e,u=s;c<=t;){let p=i.doc.lineAt(c);if(c==e){let v=p.number-l;u+=a*v+f*(e-r-v)}let y=a+f*p.length;o(new It(p.from,p.length,u,y,0)),u+=y,c=p.to+1}}replace(e,t,i){let s=this.length-t;if(s>0){let r=i[i.length-1];r instanceof n?i[i.length-1]=new n(r.length+s):i.push(null,new n(s-1))}if(e>0){let r=i[0];r instanceof n?i[0]=new n(e+r.length):i.unshift(new n(e-1),null)}return dt.of(i)}decomposeLeft(e,t){t.push(new n(e-1),null)}decomposeRight(e,t){t.push(null,new n(this.length-e-1))}updateHeight(e,t=0,i=!1,s){let r=t+this.length;if(s&&s.from<=t+this.length&&s.more){let o=[],l=Math.max(t,s.from),a=-1;for(s.from>t&&o.push(new n(s.from-t-1).updateHeight(e,t));l<=r&&s.more;){let c=e.doc.lineAt(l).length;o.length&&o.push(null);let u=s.heights[s.index++],p=0;u<0&&(p=-u,u=s.heights[s.index++]),a==-1?a=u:Math.abs(u-a)>=Cr&&(a=-2);let y=new xt(c,u,p);y.outdated=!1,o.push(y),l+=c+1}l<=r&&o.push(null,new n(r-l).updateHeight(e,l));let f=dt.of(o);return(a<0||Math.abs(f.height-this.height)>=Cr||Math.abs(a-this.heightMetrics(e,t).perLine)>=Cr)&&(qs=!0),Wr(this,f)}else(i||this.outdated)&&(this.setHeight(e.heightForGap(t,t+this.length)),this.outdated=!1);return this}toString(){return`gap(${this.length})`}},Oa=class extends dt{constructor(e,t,i){super(e.length+(t?1:0)+i.length,e.height+i.height,(t?1:0)|(e.outdated||i.outdated?2:0)),this.left=e,this.right=i,this.size=e.size+i.size}get break(){return this.flags&1}blockAt(e,t,i,s){let r=i+this.left.height;return e<r?this.left.blockAt(e,t,i,s):this.right.blockAt(e,t,r,s+this.left.length+this.break)}lineAt(e,t,i,s,r){let o=s+this.left.height,l=r+this.left.length+this.break,a=t==ke.ByHeight?e<o:e<l,f=a?this.left.lineAt(e,t,i,s,r):this.right.lineAt(e,t,i,o,l);if(this.break||(a?f.to<l:f.from>l))return f;let c=t==ke.ByPosNoHeight?ke.ByPosNoHeight:ke.ByPos;return a?f.join(this.right.lineAt(l,c,i,o,l)):this.left.lineAt(l,c,i,s,r).join(f)}forEachLine(e,t,i,s,r,o){let l=s+this.left.height,a=r+this.left.length+this.break;if(this.break)e<a&&this.left.forEachLine(e,t,i,s,r,o),t>=a&&this.right.forEachLine(e,t,i,l,a,o);else{let f=this.lineAt(a,ke.ByPos,i,s,r);e<f.from&&this.left.forEachLine(e,Math.min(t,f.from-1),i,s,r,o),f.to>=e&&f.from<=t&&o(f),t>f.to&&this.right.forEachLine(Math.max(e,f.to+1),t,i,l,a,o)}}replace(e,t,i){let s=this.left.length+this.break;if(t<s)return this.balanced(this.left.replace(e,t,i),this.right);if(e>this.left.length)return this.balanced(this.left,this.right.replace(e-s,t-s,i));let r=[];e>0&&this.decomposeLeft(e,r);let o=r.length;for(let l of i)r.push(l);if(e>0&&Du(r,o-1),t<this.length){let l=r.length;this.decomposeRight(t,r),Du(r,l)}return dt.of(r)}decomposeLeft(e,t){let i=this.left.length;if(e<=i)return this.left.decomposeLeft(e,t);t.push(this.left),this.break&&(i++,e>=i&&t.push(null)),e>i&&this.right.decomposeLeft(e-i,t)}decomposeRight(e,t){let i=this.left.length,s=i+this.break;if(e>=s)return this.right.decomposeRight(e-s,t);e<i&&this.left.decomposeRight(e,t),this.break&&e<s&&t.push(null),t.push(this.right)}balanced(e,t){return e.size>2*t.size||t.size>2*e.size?dt.of(this.break?[e,null,t]:[e,t]):(this.left=Wr(this.left,e),this.right=Wr(this.right,t),this.setHeight(e.height+t.height),this.outdated=e.outdated||t.outdated,this.size=e.size+t.size,this.length=e.length+this.break+t.length,this)}updateHeight(e,t=0,i=!1,s){let{left:r,right:o}=this,l=t+r.length+this.break,a=null;return s&&s.from<=t+r.length&&s.more?a=r=r.updateHeight(e,t,i,s):r.updateHeight(e,t,i),s&&s.from<=l+o.length&&s.more?a=o=o.updateHeight(e,l,i,s):o.updateHeight(e,l,i),a?this.balanced(r,o):(this.height=this.left.height+this.right.height,this.outdated=!1,this)}toString(){return this.left+(this.break?" ":"-")+this.right}};function Du(n,e){let t,i;n[e]==null&&(t=n[e-1])instanceof vi&&(i=n[e+1])instanceof vi&&n.splice(e-1,3,new vi(t.length+1+i.length))}var MO=5,wa=class n{constructor(e,t){this.pos=e,this.oracle=t,this.nodes=[],this.lineStart=-1,this.lineEnd=-1,this.covering=null,this.writtenTo=e}get isCovered(){return this.covering&&this.nodes[this.nodes.length-1]==this.covering}span(e,t){if(this.lineStart>-1){let i=Math.min(t,this.lineEnd),s=this.nodes[this.nodes.length-1];s instanceof xt?s.length+=i-this.pos:(i>this.pos||!this.isCovered)&&this.nodes.push(new xt(i-this.pos,-1,0)),this.writtenTo=i,t>i&&(this.nodes.push(null),this.writtenTo++,this.lineStart=-1)}this.pos=t}point(e,t,i){if(e<t||i.heightRelevant){let s=i.widget?i.widget.estimatedHeight:0,r=i.widget?i.widget.lineBreaks:0;s<0&&(s=this.oracle.lineHeight);let o=t-e;i.block?this.addBlock(new zr(o,s,i)):(o||r||s>=MO)&&this.addLineDeco(s,r,o)}else t>e&&this.span(e,t);this.lineEnd>-1&&this.lineEnd<this.pos&&(this.lineEnd=this.oracle.doc.lineAt(this.pos).to)}enterLine(){if(this.lineStart>-1)return;let{from:e,to:t}=this.oracle.doc.lineAt(this.pos);this.lineStart=e,this.lineEnd=t,this.writtenTo<e&&((this.writtenTo<e-1||this.nodes[this.nodes.length-1]==null)&&this.nodes.push(this.blankContent(this.writtenTo,e-1)),this.nodes.push(null)),this.pos>e&&this.nodes.push(new xt(this.pos-e,-1,0)),this.writtenTo=this.pos}blankContent(e,t){let i=new vi(t-e);return this.oracle.doc.lineAt(e).to==t&&(i.flags|=4),i}ensureLine(){this.enterLine();let e=this.nodes.length?this.nodes[this.nodes.length-1]:null;if(e instanceof xt)return e;let t=new xt(0,-1,0);return this.nodes.push(t),t}addBlock(e){this.enterLine();let t=e.deco;t&&t.startSide>0&&!this.isCovered&&this.ensureLine(),this.nodes.push(e),this.writtenTo=this.pos=this.pos+e.length,t&&t.endSide>0&&(this.covering=e)}addLineDeco(e,t,i){let s=this.ensureLine();s.length+=i,s.collapsed+=i,s.widgetHeight=Math.max(s.widgetHeight,e),s.breaks+=t,this.writtenTo=this.pos=this.pos+i}finish(e){let t=this.nodes.length==0?null:this.nodes[this.nodes.length-1];this.lineStart>-1&&!(t instanceof xt)&&!this.isCovered?this.nodes.push(new xt(0,-1,0)):(this.writtenTo<this.pos||t==null)&&this.nodes.push(this.blankContent(this.writtenTo,this.pos));let i=e;for(let s of this.nodes)s instanceof xt&&s.updateHeight(this.oracle,i),i+=s?s.length:1;return this.nodes}static build(e,t,i,s){let r=new n(i,e);return ce.spans(t,i,s,r,0),r.finish(i)}};function NO(n,e,t){let i=new ka;return ce.compare(n,e,t,i,0),i.changes}var ka=class{constructor(){this.changes=[]}compareRange(){}comparePoint(e,t,i,s){(e<t||i&&i.heightRelevant||s&&s.heightRelevant)&&Ms(e,t,this.changes,5)}};function DO(n,e){let t=n.getBoundingClientRect(),i=n.ownerDocument,s=i.defaultView||window,r=Math.max(0,t.left),o=Math.min(s.innerWidth,t.right),l=Math.max(0,t.top),a=Math.min(s.innerHeight,t.bottom);for(let f=n.parentNode;f&&f!=i.body;)if(f.nodeType==1){let c=f,u=window.getComputedStyle(c);if((c.scrollHeight>c.clientHeight||c.scrollWidth>c.clientWidth)&&u.overflow!="visible"){let p=c.getBoundingClientRect();r=Math.max(r,p.left),o=Math.min(o,p.right),l=Math.max(l,p.top),a=Math.min(f==n.parentNode?s.innerHeight:a,p.bottom)}f=u.position=="absolute"||u.position=="fixed"?c.offsetParent:c.parentNode}else if(f.nodeType==11)f=f.host;else break;return{left:r-t.left,right:Math.max(r,o)-t.left,top:l-(t.top+e),bottom:Math.max(l,a)-(t.top+e)}}function IO(n){let e=n.getBoundingClientRect(),t=n.ownerDocument.defaultView||window;return e.left<t.innerWidth&&e.right>0&&e.top<t.innerHeight&&e.bottom>0}function LO(n,e){let t=n.getBoundingClientRect();return{left:0,right:t.right-t.left,top:e,bottom:t.bottom-(t.top+e)}}var vn=class{constructor(e,t,i,s){this.from=e,this.to=t,this.size=i,this.displaySize=s}static same(e,t){if(e.length!=t.length)return!1;for(let i=0;i<e.length;i++){let s=e[i],r=t[i];if(s.from!=r.from||s.to!=r.to||s.size!=r.size)return!1}return!0}draw(e,t){return K.replace({widget:new xa(this.displaySize*(t?e.scaleY:e.scaleX),t)}).range(this.from,this.to)}},xa=class extends li{constructor(e,t){super(),this.size=e,this.vertical=t}eq(e){return e.size==this.size&&e.vertical==this.vertical}toDOM(){let e=document.createElement("div");return this.vertical?e.style.height=this.size+"px":(e.style.width=this.size+"px",e.style.height="2px",e.style.display="inline-block"),e}get estimatedHeight(){return this.vertical?this.size:-1}},jr=class{constructor(e,t){this.view=e,this.state=t,this.pixelViewport={left:0,right:window.innerWidth,top:0,bottom:0},this.inView=!0,this.paddingTop=0,this.paddingBottom=0,this.contentDOMWidth=0,this.contentDOMHeight=0,this.editorHeight=0,this.editorWidth=0,this.scaleX=1,this.scaleY=1,this.scrollOffset=0,this.scrolledToBottom=!1,this.scrollAnchorPos=0,this.scrollAnchorHeight=-1,this.scaler=Iu,this.scrollTarget=null,this.printing=!1,this.mustMeasureContent=!0,this.defaultTextDirection=_e.LTR,this.visibleRanges=[],this.mustEnforceCursorAssoc=!1;let i=t.facet(Wa).some(s=>typeof s!="function"&&s.class=="cm-lineWrapping");this.heightOracle=new ba(i),this.stateDeco=Lu(t),this.heightMap=dt.empty().applyChanges(this.stateDeco,oe.empty,this.heightOracle.setDoc(t.doc),[new Lt(0,0,0,t.doc.length)]);for(let s=0;s<2&&(this.viewport=this.getViewport(0,null),!!this.updateForViewport());s++);this.updateViewportLines(),this.lineGaps=this.ensureLineGaps([]),this.lineGapDeco=K.set(this.lineGaps.map(s=>s.draw(this,!1))),this.scrollParent=e.scrollDOM,this.computeVisibleRanges()}updateForViewport(){let e=[this.viewport],{main:t}=this.state.selection;for(let i=0;i<=1;i++){let s=i?t.head:t.anchor;if(!e.some(({from:r,to:o})=>s>=r&&s<=o)){let{from:r,to:o}=this.lineBlockAt(s);e.push(new Es(r,o))}}return this.viewports=e.sort((i,s)=>i.from-s.from),this.updateScaler()}updateScaler(){let e=this.scaler;return this.scaler=this.heightMap.height<=7e6?Iu:new Sa(this.heightOracle,this.heightMap,this.viewports),e.eq(this.scaler)?0:2}updateViewportLines(){this.viewportLines=[],this.heightMap.forEachLine(this.viewport.from,this.viewport.to,this.heightOracle.setDoc(this.state.doc),0,0,e=>{this.viewportLines.push(un(e,this.scaler))})}update(e,t=null){this.state=e.state;let i=this.stateDeco;this.stateDeco=Lu(this.state);let s=e.changedRanges,r=Lt.extendWithRanges(s,NO(i,this.stateDeco,e?e.changes:Ze.empty(this.state.doc.length))),o=this.heightMap.height,l=this.scrolledToBottom?null:this.scrollAnchorAt(this.scrollOffset);Nu(),this.heightMap=this.heightMap.applyChanges(this.stateDeco,e.startState.doc,this.heightOracle.setDoc(this.state.doc),r),(this.heightMap.height!=o||qs)&&(e.flags|=2),l?(this.scrollAnchorPos=e.changes.mapPos(l.from,-1),this.scrollAnchorHeight=l.top):(this.scrollAnchorPos=-1,this.scrollAnchorHeight=o);let a=r.length?this.mapViewport(this.viewport,e.changes):this.viewport;(t&&(t.range.head<a.from||t.range.head>a.to)||!this.viewportIsAppropriate(a))&&(a=this.getViewport(0,t));let f=a.from!=this.viewport.from||a.to!=this.viewport.to;this.viewport=a,e.flags|=this.updateForViewport(),(f||!e.changes.empty||e.flags&2)&&this.updateViewportLines(),(this.lineGaps.length||this.viewport.to-this.viewport.from>4e3)&&this.updateLineGaps(this.ensureLineGaps(this.mapLineGaps(this.lineGaps,e.changes))),e.flags|=this.computeVisibleRanges(e.changes),t&&(this.scrollTarget=t),!this.mustEnforceCursorAssoc&&(e.selectionSet||e.focusChanged)&&e.view.lineWrapping&&e.state.selection.main.empty&&e.state.selection.main.assoc&&!e.state.facet(yp)&&(this.mustEnforceCursorAssoc=!0)}measure(){let{view:e}=this,t=e.contentDOM,i=window.getComputedStyle(t),s=this.heightOracle,r=i.whiteSpace;this.defaultTextDirection=i.direction=="rtl"?_e.RTL:_e.LTR;let o=this.heightOracle.mustRefreshForWrapping(r)||this.mustMeasureContent==="refresh",l=t.getBoundingClientRect(),a=o||this.mustMeasureContent||this.contentDOMHeight!=l.height;this.contentDOMHeight=l.height,this.mustMeasureContent=!1;let f=0,c=0;if(l.width&&l.height){let{scaleX:E,scaleY:R}=Ku(t,l);(E>.005&&Math.abs(this.scaleX-E)>.005||R>.005&&Math.abs(this.scaleY-R)>.005)&&(this.scaleX=E,this.scaleY=R,f|=16,o=a=!0)}let u=(parseInt(i.paddingTop)||0)*this.scaleY,p=(parseInt(i.paddingBottom)||0)*this.scaleY;(this.paddingTop!=u||this.paddingBottom!=p)&&(this.paddingTop=u,this.paddingBottom=p,f|=18),this.editorWidth!=e.scrollDOM.clientWidth&&(s.lineWrapping&&(a=!0),this.editorWidth=e.scrollDOM.clientWidth,f|=16);let y=Zu(this.view.contentDOM,!1).y;y!=this.scrollParent&&(this.scrollParent=y,this.scrollAnchorHeight=-1,this.scrollOffset=0);let v=this.getScrollOffset();this.scrollOffset!=v&&(this.scrollAnchorHeight=-1,this.scrollOffset=v),this.scrolledToBottom=sp(this.scrollParent||e.win);let b=(this.printing?LO:DO)(t,this.paddingTop),O=b.top-this.pixelViewport.top,k=b.bottom-this.pixelViewport.bottom;this.pixelViewport=b;let T=this.pixelViewport.bottom>this.pixelViewport.top&&this.pixelViewport.right>this.pixelViewport.left;if(T!=this.inView&&(this.inView=T,T&&(a=!0)),!this.inView&&!this.scrollTarget&&!IO(e.dom))return 0;let P=l.width;if((this.contentDOMWidth!=P||this.editorHeight!=e.scrollDOM.clientHeight)&&(this.contentDOMWidth=l.width,this.editorHeight=e.scrollDOM.clientHeight,f|=16),a){let E=e.docView.measureVisibleLineHeights(this.viewport);if(s.mustRefreshForHeights(E)&&(o=!0),o||s.lineWrapping&&Math.abs(P-this.contentDOMWidth)>s.charWidth){let{lineHeight:R,charWidth:N,textHeight:B}=e.docView.measureTextSize();o=R>0&&s.refresh(r,R,N,B,Math.max(5,P/N),E),o&&(e.docView.minWidth=0,f|=16)}O>0&&k>0?c=Math.max(O,k):O<0&&k<0&&(c=Math.min(O,k)),Nu();for(let R of this.viewports){let N=R.from==this.viewport.from?E:e.docView.measureVisibleLineHeights(R);this.heightMap=(o?dt.empty().applyChanges(this.stateDeco,oe.empty,this.heightOracle,[new Lt(0,0,0,e.state.doc.length)]):this.heightMap).updateHeight(s,0,o,new va(R.from,N))}qs&&(f|=2)}let I=!this.viewportIsAppropriate(this.viewport,c)||this.scrollTarget&&(this.scrollTarget.range.head<this.viewport.from||this.scrollTarget.range.head>this.viewport.to);return I&&(f&2&&(f|=this.updateScaler()),this.viewport=this.getViewport(c,this.scrollTarget),f|=this.updateForViewport()),(f&2||I)&&this.updateViewportLines(),(this.lineGaps.length||this.viewport.to-this.viewport.from>4e3)&&this.updateLineGaps(this.ensureLineGaps(o?[]:this.lineGaps,e)),f|=this.computeVisibleRanges(),this.mustEnforceCursorAssoc&&(this.mustEnforceCursorAssoc=!1,e.docView.enforceCursorAssoc()),f}get visibleTop(){return this.scaler.fromDOM(this.pixelViewport.top)}get visibleBottom(){return this.scaler.fromDOM(this.pixelViewport.bottom)}getViewport(e,t){let i=.5-Math.max(-.5,Math.min(.5,e/1e3/2)),s=this.heightMap,r=this.heightOracle,{visibleTop:o,visibleBottom:l}=this,a=new Es(s.lineAt(o-i*1e3,ke.ByHeight,r,0,0).from,s.lineAt(l+(1-i)*1e3,ke.ByHeight,r,0,0).to);if(t){let{head:f}=t.range;if(f<a.from||f>a.to){let c=Math.min(this.editorHeight,this.pixelViewport.bottom-this.pixelViewport.top),u=s.lineAt(f,ke.ByPos,r,0,0),p;t.y=="center"?p=(u.top+u.bottom)/2-c/2:t.y=="start"||t.y=="nearest"&&f<a.from?p=u.top:p=u.bottom-c,a=new Es(s.lineAt(p-1e3/2,ke.ByHeight,r,0,0).from,s.lineAt(p+c+1e3/2,ke.ByHeight,r,0,0).to)}}return a}mapViewport(e,t){let i=t.mapPos(e.from,-1),s=t.mapPos(e.to,1);return new Es(this.heightMap.lineAt(i,ke.ByPos,this.heightOracle,0,0).from,this.heightMap.lineAt(s,ke.ByPos,this.heightOracle,0,0).to)}viewportIsAppropriate({from:e,to:t},i=0){if(!this.inView)return!0;let{top:s}=this.heightMap.lineAt(e,ke.ByPos,this.heightOracle,0,0),{bottom:r}=this.heightMap.lineAt(t,ke.ByPos,this.heightOracle,0,0),{visibleTop:o,visibleBottom:l}=this;return(e==0||s<=o-Math.max(10,Math.min(-i,250)))&&(t==this.state.doc.length||r>=l+Math.max(10,Math.min(i,250)))&&s>o-2*1e3&&r<l+2*1e3}mapLineGaps(e,t){if(!e.length||t.empty)return e;let i=[];for(let s of e)t.touchesRange(s.from,s.to)||i.push(new vn(t.mapPos(s.from),t.mapPos(s.to),s.size,s.displaySize));return i}ensureLineGaps(e,t){let i=this.heightOracle.lineWrapping,s=i?1e4:2e3,r=s>>1,o=s<<1;if(this.defaultTextDirection!=_e.LTR&&!i)return[];let l=[],a=(c,u,p,y)=>{if(u-c<r)return;let v=this.state.selection.main,b=[v.from];v.empty||b.push(v.to);for(let k of b)if(k>c&&k<u){a(c,k-10,p,y),a(k+10,u,p,y);return}let O=qO(e,k=>k.from>=p.from&&k.to<=p.to&&Math.abs(k.from-c)<r&&Math.abs(k.to-u)<r&&!b.some(T=>k.from<T&&k.to>T));if(!O){if(u<p.to&&t&&i&&t.visibleRanges.some(P=>P.from<=u&&P.to>=u)){let P=t.moveToLineBoundary(M.cursor(u),!1,!0).head;P>c&&(u=P)}let k=this.gapSize(p,c,u,y),T=i||k<2e6?k:2e6;O=new vn(c,u,k,T)}l.push(O)},f=c=>{if(c.length<o||c.type!=Ve.Text)return;let u=QO(c.from,c.to,this.stateDeco);if(u.total<o)return;let p=this.scrollTarget?this.scrollTarget.range.head:null,y,v;if(i){let b=s/this.heightOracle.lineLength*this.heightOracle.lineHeight,O,k;if(p!=null){let T=kr(u,p),P=((this.visibleBottom-this.visibleTop)/2+b)/c.height;O=T-P,k=T+P}else O=(this.visibleTop-c.top-b)/c.height,k=(this.visibleBottom-c.top+b)/c.height;y=wr(u,O),v=wr(u,k)}else{let b=u.total*this.heightOracle.charWidth,O=s*this.heightOracle.charWidth,k=0;if(b>2e6)for(let R of e)R.from>=c.from&&R.from<c.to&&R.size!=R.displaySize&&R.from*this.heightOracle.charWidth+k<this.pixelViewport.left&&(k=R.size-R.displaySize);let T=this.pixelViewport.left+k,P=this.pixelViewport.right+k,I,E;if(p!=null){let R=kr(u,p),N=((P-T)/2+O)/b;I=R-N,E=R+N}else I=(T-O)/b,E=(P+O)/b;y=wr(u,I),v=wr(u,E)}y>c.from&&a(c.from,y,c,u),v<c.to&&a(v,c.to,c,u)};for(let c of this.viewportLines)Array.isArray(c.type)?c.type.forEach(f):f(c);return l}gapSize(e,t,i,s){let r=kr(s,i)-kr(s,t);return this.heightOracle.lineWrapping?e.height*r:s.total*this.heightOracle.charWidth*r}updateLineGaps(e){vn.same(e,this.lineGaps)||(this.lineGaps=e,this.lineGapDeco=K.set(e.map(t=>t.draw(this,this.heightOracle.lineWrapping))))}computeVisibleRanges(e){let t=this.stateDeco;this.lineGaps.length&&(t=t.concat(this.lineGapDeco));let i=[];ce.spans(t,this.viewport.from,this.viewport.to,{span(r,o){i.push({from:r,to:o})},point(){}},20);let s=0;if(i.length!=this.visibleRanges.length)s=12;else for(let r=0;r<i.length&&!(s&8);r++){let o=this.visibleRanges[r],l=i[r];(o.from!=l.from||o.to!=l.to)&&(s|=4,e&&e.mapPos(o.from,-1)==l.from&&e.mapPos(o.to,1)==l.to||(s|=8))}return this.visibleRanges=i,s}lineBlockAt(e){return e>=this.viewport.from&&e<=this.viewport.to&&this.viewportLines.find(t=>t.from<=e&&t.to>=e)||un(this.heightMap.lineAt(e,ke.ByPos,this.heightOracle,0,0),this.scaler)}lineBlockAtHeight(e){return e>=this.viewportLines[0].top&&e<=this.viewportLines[this.viewportLines.length-1].bottom&&this.viewportLines.find(t=>t.top<=e&&t.bottom>=e)||un(this.heightMap.lineAt(this.scaler.fromDOM(e),ke.ByHeight,this.heightOracle,0,0),this.scaler)}getScrollOffset(){return this.scrollParent==this.view.scrollDOM?this.scrollParent.scrollTop*this.scaleY:(this.scrollParent?this.scrollParent.getBoundingClientRect().top:0)-this.view.contentDOM.getBoundingClientRect().top}scrollAnchorAt(e){let t=this.lineBlockAtHeight(e+8);return t.from>=this.viewport.from||this.viewportLines[0].top-e>200?t:this.viewportLines[0]}elementAtHeight(e){return un(this.heightMap.blockAt(this.scaler.fromDOM(e),this.heightOracle,0,0),this.scaler)}get docHeight(){return this.scaler.toDOM(this.heightMap.height)}get contentHeight(){return this.docHeight+this.paddingTop+this.paddingBottom}},Es=class{constructor(e,t){this.from=e,this.to=t}};function QO(n,e,t){let i=[],s=n,r=0;return ce.spans(t,n,e,{span(){},point(o,l){o>s&&(i.push({from:s,to:o}),r+=o-s),s=l}},20),s<e&&(i.push({from:s,to:e}),r+=e-s),{total:r,ranges:i}}function wr({total:n,ranges:e},t){if(t<=0)return e[0].from;if(t>=1)return e[e.length-1].to;let i=Math.floor(n*t);for(let s=0;;s++){let{from:r,to:o}=e[s],l=o-r;if(i<=l)return r+i;i-=l}}function kr(n,e){let t=0;for(let{from:i,to:s}of n.ranges){if(e<=s){t+=e-i;break}t+=s-i}return t/n.total}function qO(n,e){for(let t of n)if(e(t))return t}var Iu={toDOM(n){return n},fromDOM(n){return n},scale:1,eq(n){return n==this}};function Lu(n){let e=n.facet(Xr).filter(i=>typeof i!="function"),t=n.facet(za).filter(i=>typeof i!="function");return t.length&&e.push(ce.join(t)),e}var Sa=class n{constructor(e,t,i){let s=0,r=0,o=0;this.viewports=i.map(({from:l,to:a})=>{let f=t.lineAt(l,ke.ByPos,e,0,0).top,c=t.lineAt(a,ke.ByPos,e,0,0).bottom;return s+=c-f,{from:l,to:a,top:f,bottom:c,domTop:0,domBottom:0}}),this.scale=(7e6-s)/(t.height-s);for(let l of this.viewports)l.domTop=o+(l.top-r)*this.scale,o=l.domBottom=l.domTop+(l.bottom-l.top),r=l.bottom}toDOM(e){for(let t=0,i=0,s=0;;t++){let r=t<this.viewports.length?this.viewports[t]:null;if(!r||e<r.top)return s+(e-i)*this.scale;if(e<=r.bottom)return r.domTop+(e-r.top);i=r.bottom,s=r.domBottom}}fromDOM(e){for(let t=0,i=0,s=0;;t++){let r=t<this.viewports.length?this.viewports[t]:null;if(!r||e<r.domTop)return i+(e-s)/this.scale;if(e<=r.domBottom)return r.top+(e-r.domTop);i=r.bottom,s=r.domBottom}}eq(e){return e instanceof n?this.scale==e.scale&&this.viewports.length==e.viewports.length&&this.viewports.every((t,i)=>t.from==e.viewports[i].from&&t.to==e.viewports[i].to):!1}};function un(n,e){if(e.scale==1)return n;let t=e.toDOM(n.top),i=e.toDOM(n.bottom);return new It(n.from,n.length,t,i-t,Array.isArray(n._content)?n._content.map(s=>un(s,e)):n._content)}var xr=W.define({combine:n=>n.join(" ")}),Ta=W.define({combine:n=>n.indexOf(!0)>-1}),Pa=kt.newName(),Bp=kt.newName(),$p=kt.newName(),Fp={"&light":"."+Bp,"&dark":"."+$p};function Ca(n,e,t){return new kt(e,{finish(i){return/&/.test(i)?i.replace(/&\w*/,s=>{if(s=="&")return n;if(!t||!t[s])throw new RangeError(`Unsupported selector: ${s}`);return t[s]}):n+" "+i}})}var BO=Ca("."+Pa,{"&":{position:"relative !important",boxSizing:"border-box","&.cm-focused":{outline:"1px dotted #212121"},display:"flex !important",flexDirection:"column"},".cm-scroller":{display:"flex !important",alignItems:"flex-start !important",fontFamily:"monospace",lineHeight:1.4,height:"100%",overflowX:"auto",position:"relative",zIndex:0,overflowAnchor:"none"},".cm-content":{margin:0,flexGrow:2,flexShrink:0,display:"block",whiteSpace:"pre",wordWrap:"normal",boxSizing:"border-box",minHeight:"100%",padding:"4px 0",outline:"none","&[contenteditable=true]":{WebkitUserModify:"read-write-plaintext-only"}},".cm-lineWrapping":{whiteSpace_fallback:"pre-wrap",whiteSpace:"break-spaces",wordBreak:"break-word",overflowWrap:"anywhere",flexShrink:1},"&light .cm-content":{caretColor:"black"},"&dark .cm-content":{caretColor:"white"},".cm-line":{display:"block",padding:"0 2px 0 6px"},".cm-layer":{userSelect:"none",position:"absolute",left:0,top:0,contain:"size style","& > *":{position:"absolute"}},"&light .cm-selectionBackground":{background:"#d9d9d9"},"&dark .cm-selectionBackground":{background:"#222"},"&light.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground":{background:"#d7d4f0"},"&dark.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground":{background:"#233"},".cm-cursorLayer":{pointerEvents:"none"},"&.cm-focused > .cm-scroller > .cm-cursorLayer":{animation:"steps(1) cm-blink 1.2s infinite"},"@keyframes cm-blink":{"0%":{},"50%":{opacity:0},"100%":{}},"@keyframes cm-blink2":{"0%":{},"50%":{opacity:0},"100%":{}},".cm-cursor, .cm-dropCursor":{borderLeft:"1.2px solid black",marginLeft:"-0.6px",pointerEvents:"none"},".cm-cursor":{display:"none"},"&dark .cm-cursor":{borderLeftColor:"#ddd"},".cm-selectionHandle":{backgroundColor:"currentColor",width:"1.5px"},".cm-selectionHandle-start::before, .cm-selectionHandle-end::before":{content:'""',backgroundColor:"inherit",borderRadius:"50%",width:"8px",height:"8px",position:"absolute",left:"-3.25px"},".cm-selectionHandle-start::before":{top:"-8px"},".cm-selectionHandle-end::before":{bottom:"-8px"},".cm-dropCursor":{position:"absolute"},"&.cm-focused > .cm-scroller > .cm-cursorLayer .cm-cursor":{display:"block"},".cm-iso":{unicodeBidi:"isolate"},".cm-announced":{position:"fixed",top:"-10000px"},"@media print":{".cm-announced":{display:"none"}},"&light .cm-activeLine":{backgroundColor:"#cceeff44"},"&dark .cm-activeLine":{backgroundColor:"#99eeff33"},"&light .cm-specialChar":{color:"red"},"&dark .cm-specialChar":{color:"#f78"},".cm-gutters":{flexShrink:0,display:"flex",height:"100%",boxSizing:"border-box",zIndex:200},".cm-gutters-before":{insetInlineStart:0},".cm-gutters-after":{insetInlineEnd:0},"&light .cm-gutters":{backgroundColor:"#f5f5f5",color:"#6c6c6c",border:"0px solid #ddd","&.cm-gutters-before":{borderRightWidth:"1px"},"&.cm-gutters-after":{borderLeftWidth:"1px"}},"&dark .cm-gutters":{backgroundColor:"#333338",color:"#ccc"},".cm-gutter":{display:"flex !important",flexDirection:"column",flexShrink:0,boxSizing:"border-box",minHeight:"100%",overflow:"hidden"},".cm-gutterElement":{boxSizing:"border-box"},".cm-lineNumbers .cm-gutterElement":{padding:"0 3px 0 5px",minWidth:"20px",textAlign:"right",whiteSpace:"nowrap"},"&light .cm-activeLineGutter":{backgroundColor:"#e2f2ff"},"&dark .cm-activeLineGutter":{backgroundColor:"#222227"},".cm-panels":{boxSizing:"border-box",position:"sticky",left:0,right:0,zIndex:300},"&light .cm-panels":{backgroundColor:"#f5f5f5",color:"black"},".cm-panels-top":{top:"0"},".cm-panels-bottom":{bottom:"0"},"&light .cm-panels-top":{borderBottom:"1px solid #ddd"},"&light .cm-panels-bottom":{borderTop:"1px solid #ddd"},"&dark .cm-panels":{backgroundColor:"#333338",color:"white"},".cm-dialog":{padding:"2px 19px 4px 6px",position:"relative","& label":{fontSize:"80%"}},".cm-dialog-close":{position:"absolute",top:"3px",right:"4px",backgroundColor:"inherit",border:"none",font:"inherit",fontSize:"14px",padding:"0"},".cm-tab":{display:"inline-block",overflow:"hidden",verticalAlign:"bottom"},".cm-widgetBuffer":{verticalAlign:"text-top",height:"1em",width:0,display:"inline"},".cm-placeholder":{color:"#888",display:"inline-block",verticalAlign:"top",userSelect:"none"},".cm-highlightSpace":{background:"radial-gradient(circle at 50% 55%, #aaa 20%, transparent 0) no-repeat",backgroundSize:".4em",backgroundPosition:"calc(min(50%, 0px)) center"},".cm-highlightTab":{backgroundImage:`url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="20"><path stroke="%23888" stroke-width="1" fill="none" d="M1 10H196L190 5M190 15L196 10M197 4L197 16"/></svg>')`,backgroundSize:"auto 100%",backgroundPosition:"right 90%",backgroundRepeat:"no-repeat"},".cm-trailingSpace":{backgroundColor:"#ff332255"},".cm-button":{verticalAlign:"middle",color:"inherit",fontSize:"70%",padding:".2em 1em",borderRadius:"1px"},"&light .cm-button":{backgroundImage:"linear-gradient(#eff1f5, #d9d9df)",border:"1px solid #888","&:active":{backgroundImage:"linear-gradient(#b4b4b4, #d0d3d6)"}},"&dark .cm-button":{backgroundImage:"linear-gradient(#393939, #111)",border:"1px solid #888","&:active":{backgroundImage:"linear-gradient(#111, #333)"}},".cm-textfield":{verticalAlign:"middle",color:"inherit",fontSize:"70%",border:"1px solid silver",padding:".2em .5em"},"&light .cm-textfield":{backgroundColor:"white"},"&dark .cm-textfield":{border:"1px solid #555",backgroundColor:"inherit"}},Fp),$O={childList:!0,characterData:!0,subtree:!0,attributes:!0,characterDataOldValue:!0},jl=F.ie&&F.ie_version<=11,Ea=class{constructor(e){this.view=e,this.active=!1,this.editContext=null,this.selectionRange=new Kl,this.selectionChanged=!1,this.delayedFlush=-1,this.resizeTimeout=-1,this.queue=[],this.delayedAndroidKey=null,this.flushingAndroidKey=-1,this.lastChange=0,this.scrollTargets=[],this.intersection=null,this.resizeScroll=null,this.intersecting=!1,this.gapIntersection=null,this.gaps=[],this.printQuery=null,this.parentCheck=-1,this.dom=e.contentDOM,this.observer=new MutationObserver(t=>{for(let i of t)this.queue.push(i);(F.ie&&F.ie_version<=11||F.ios&&e.composing)&&t.some(i=>i.type=="childList"&&i.removedNodes.length||i.type=="characterData"&&i.oldValue.length>i.target.nodeValue.length)?this.flushSoon():this.flush()}),window.EditContext&&F.android&&e.constructor.EDIT_CONTEXT!==!1&&!(F.chrome&&F.chrome_version<126)&&(this.editContext=new Aa(e),e.state.facet(ri)&&(e.contentDOM.editContext=this.editContext.editContext)),jl&&(this.onCharData=t=>{this.queue.push({target:t.target,type:"characterData",oldValue:t.prevValue}),this.flushSoon()}),this.onSelectionChange=this.onSelectionChange.bind(this),this.onResize=this.onResize.bind(this),this.onPrint=this.onPrint.bind(this),this.onScroll=this.onScroll.bind(this),window.matchMedia&&(this.printQuery=window.matchMedia("print")),typeof ResizeObserver=="function"&&(this.resizeScroll=new ResizeObserver(()=>{var t;((t=this.view.docView)===null||t===void 0?void 0:t.lastUpdate)<Date.now()-75&&this.onResize()}),this.resizeScroll.observe(e.scrollDOM)),this.addWindowListeners(this.win=e.win),this.start(),typeof IntersectionObserver=="function"&&(this.intersection=new IntersectionObserver(t=>{this.parentCheck<0&&(this.parentCheck=setTimeout(this.listenForScroll.bind(this),1e3)),t.length>0&&t[t.length-1].intersectionRatio>0!=this.intersecting&&(this.intersecting=!this.intersecting,this.intersecting!=this.view.inView&&this.onScrollChanged(document.createEvent("Event")))},{threshold:[0,.001]}),this.intersection.observe(this.dom),this.gapIntersection=new IntersectionObserver(t=>{t.length>0&&t[t.length-1].intersectionRatio>0&&this.onScrollChanged(document.createEvent("Event"))},{})),this.listenForScroll(),this.readSelectionRange()}onScrollChanged(e){this.view.inputState.runHandlers("scroll",e),this.intersecting&&this.view.measure()}onScroll(e){this.intersecting&&this.flush(!1),this.editContext&&this.view.requestMeasure(this.editContext.measureReq),this.onScrollChanged(e)}onResize(){this.resizeTimeout<0&&(this.resizeTimeout=setTimeout(()=>{this.resizeTimeout=-1,this.view.requestMeasure()},50))}onPrint(e){(e.type=="change"||!e.type)&&!e.matches||(this.view.viewState.printing=!0,this.view.measure(),setTimeout(()=>{this.view.viewState.printing=!1,this.view.requestMeasure()},500))}updateGaps(e){if(this.gapIntersection&&(e.length!=this.gaps.length||this.gaps.some((t,i)=>t!=e[i]))){this.gapIntersection.disconnect();for(let t of e)this.gapIntersection.observe(t);this.gaps=e}}onSelectionChange(e){let t=this.selectionChanged;if(!this.readSelectionRange()||this.delayedAndroidKey)return;let{view:i}=this,s=this.selectionRange;if(i.state.facet(ri)?i.root.activeElement!=this.dom:!pn(this.dom,s))return;let r=s.anchorNode&&i.docView.tile.nearest(s.anchorNode);if(r&&r.isWidget()&&r.widget.ignoreEvent(e)){t||(this.selectionChanged=!1);return}(F.ie&&F.ie_version<=11||F.android&&F.chrome)&&!i.state.selection.main.empty&&s.focusNode&&mn(s.focusNode,s.focusOffset,s.anchorNode,s.anchorOffset)?this.flushSoon():this.flush(!1)}readSelectionRange(){let{view:e}=this,t=xn(e.root);if(!t)return!1;let i=F.safari&&e.root.nodeType==11&&e.root.activeElement==this.dom&&FO(this.view,t)||t;if(!i||this.selectionRange.eq(i))return!1;let s=pn(this.dom,i);return s&&!this.selectionChanged&&e.inputState.lastFocusTime>Date.now()-200&&e.inputState.lastTouchTime<Date.now()-300&&Iv(this.dom,i)?(this.view.inputState.lastFocusTime=0,e.docView.updateSelection(),!1):(this.selectionRange.setRange(i),s&&(this.selectionChanged=!0),!0)}setSelectionRange(e,t){this.selectionRange.set(e.node,e.offset,t.node,t.offset),this.selectionChanged=!1}clearSelectionRange(){this.selectionRange.set(null,0,null,0)}listenForScroll(){this.parentCheck=-1;let e=0,t=null;for(let i=this.dom;i;)if(i.nodeType==1)!t&&e<this.scrollTargets.length&&this.scrollTargets[e]==i?e++:t||(t=this.scrollTargets.slice(0,e)),t&&t.push(i),i=i.assignedSlot||i.parentNode;else if(i.nodeType==11)i=i.host;else break;if(e<this.scrollTargets.length&&!t&&(t=this.scrollTargets.slice(0,e)),t){for(let i of this.scrollTargets)i.removeEventListener("scroll",this.onScroll);for(let i of this.scrollTargets=t)i.addEventListener("scroll",this.onScroll)}}ignore(e){if(!this.active)return e();try{return this.stop(),e()}finally{this.start(),this.clear()}}start(){this.active||(this.observer.observe(this.dom,$O),jl&&this.dom.addEventListener("DOMCharacterDataModified",this.onCharData),this.active=!0)}stop(){this.active&&(this.active=!1,this.observer.disconnect(),jl&&this.dom.removeEventListener("DOMCharacterDataModified",this.onCharData))}clear(){this.processRecords(),this.queue.length=0,this.selectionChanged=!1}delayAndroidKey(e,t){var i;if(!this.delayedAndroidKey){let s=()=>{let r=this.delayedAndroidKey;r&&(this.clearDelayedAndroidKey(),this.view.inputState.lastKeyCode=r.keyCode,this.view.inputState.lastKeyTime=Date.now(),!this.flush()&&r.force&&Ns(this.dom,r.key,r.keyCode))};this.flushingAndroidKey=this.view.win.requestAnimationFrame(s)}(!this.delayedAndroidKey||e=="Enter")&&(this.delayedAndroidKey={key:e,keyCode:t,force:this.lastChange<Date.now()-50||!!(!((i=this.delayedAndroidKey)===null||i===void 0)&&i.force)})}clearDelayedAndroidKey(){this.win.cancelAnimationFrame(this.flushingAndroidKey),this.delayedAndroidKey=null,this.flushingAndroidKey=-1}flushSoon(){this.delayedFlush<0&&(this.delayedFlush=this.view.win.requestAnimationFrame(()=>{this.delayedFlush=-1,this.flush()}))}forceFlush(){this.delayedFlush>=0&&(this.view.win.cancelAnimationFrame(this.delayedFlush),this.delayedFlush=-1),this.flush()}pendingRecords(){for(let e of this.observer.takeRecords())this.queue.push(e);return this.queue}processRecords(){let e=this.pendingRecords();e.length&&(this.queue=[]);let t=-1,i=-1,s=!1;for(let r of e){let o=this.readMutation(r);o&&(o.typeOver&&(s=!0),t==-1?{from:t,to:i}=o:(t=Math.min(o.from,t),i=Math.max(o.to,i)))}return{from:t,to:i,typeOver:s}}readChange(){let{from:e,to:t,typeOver:i}=this.processRecords(),s=this.selectionChanged&&pn(this.dom,this.selectionRange);if(e<0&&!s)return null;e>-1&&(this.lastChange=Date.now()),this.view.inputState.lastFocusTime=0,this.selectionChanged=!1;let r=new ma(this.view,e,t,i);return this.view.docView.domChanged={newSel:r.newSel?r.newSel.main:null},r}flush(e=!0){if(this.delayedFlush>=0||this.delayedAndroidKey)return!1;e&&this.readSelectionRange();let t=this.readChange();if(!t)return this.view.requestMeasure(),!1;let i=this.view.state,s=Ep(this.view,t);return this.view.state==i&&(t.domChanged||t.newSel&&!Fr(this.view.state.selection,t.newSel.main))&&this.view.update([]),s}readMutation(e){let t=this.view.docView.tile.nearest(e.target);if(!t||t.isWidget())return null;if(t.markDirty(e.type=="attributes"),e.type=="childList"){let i=Qu(t,e.previousSibling||e.target.previousSibling,-1),s=Qu(t,e.nextSibling||e.target.nextSibling,1);return{from:i?t.posAfter(i):t.posAtStart,to:s?t.posBefore(s):t.posAtEnd,typeOver:!1}}else return e.type=="characterData"?{from:t.posAtStart,to:t.posAtEnd,typeOver:e.target.nodeValue==e.oldValue}:null}setWindow(e){e!=this.win&&(this.removeWindowListeners(this.win),this.win=e,this.addWindowListeners(this.win))}addWindowListeners(e){e.addEventListener("resize",this.onResize),this.printQuery?this.printQuery.addEventListener?this.printQuery.addEventListener("change",this.onPrint):this.printQuery.addListener(this.onPrint):e.addEventListener("beforeprint",this.onPrint),e.addEventListener("scroll",this.onScroll),e.document.addEventListener("selectionchange",this.onSelectionChange)}removeWindowListeners(e){e.removeEventListener("scroll",this.onScroll),e.removeEventListener("resize",this.onResize),this.printQuery?this.printQuery.removeEventListener?this.printQuery.removeEventListener("change",this.onPrint):this.printQuery.removeListener(this.onPrint):e.removeEventListener("beforeprint",this.onPrint),e.document.removeEventListener("selectionchange",this.onSelectionChange)}update(e){this.editContext&&(this.editContext.update(e),e.startState.facet(ri)!=e.state.facet(ri)&&(e.view.contentDOM.editContext=e.state.facet(ri)?this.editContext.editContext:null))}destroy(){var e,t,i;this.stop(),(e=this.intersection)===null||e===void 0||e.disconnect(),(t=this.gapIntersection)===null||t===void 0||t.disconnect(),(i=this.resizeScroll)===null||i===void 0||i.disconnect();for(let s of this.scrollTargets)s.removeEventListener("scroll",this.onScroll);this.removeWindowListeners(this.win),clearTimeout(this.parentCheck),clearTimeout(this.resizeTimeout),this.win.cancelAnimationFrame(this.delayedFlush),this.win.cancelAnimationFrame(this.flushingAndroidKey),this.editContext&&(this.view.contentDOM.editContext=null,this.editContext.destroy())}};function Qu(n,e,t){for(;e;){let i=Se.get(e);if(i&&i.parent==n)return i;let s=e.parentNode;e=s!=n.dom?s:t>0?e.nextSibling:e.previousSibling}return null}function qu(n,e){let t=e.startContainer,i=e.startOffset,s=e.endContainer,r=e.endOffset,o=n.docView.domAtPos(n.state.selection.main.anchor,1);return mn(o.node,o.offset,s,r)&&([t,i,s,r]=[s,r,t,i]),{anchorNode:t,anchorOffset:i,focusNode:s,focusOffset:r}}function FO(n,e){if(e.getComposedRanges){let s=e.getComposedRanges(n.root)[0];if(s)return qu(n,s)}let t=null;function i(s){s.preventDefault(),s.stopImmediatePropagation(),t=s.getTargetRanges()[0]}return n.contentDOM.addEventListener("beforeinput",i,!0),n.dom.ownerDocument.execCommand("indent"),n.contentDOM.removeEventListener("beforeinput",i,!0),t?qu(n,t):null}var Aa=class{constructor(e){this.from=0,this.to=0,this.pendingContextChange=null,this.handlers=Object.create(null),this.composing=null,this.resetRange(e.state);let t=this.editContext=new window.EditContext({text:e.state.doc.sliceString(this.from,this.to),selectionStart:this.toContextPos(Math.max(this.from,Math.min(this.to,e.state.selection.main.anchor))),selectionEnd:this.toContextPos(e.state.selection.main.head)});this.handlers.textupdate=i=>{let s=e.state.selection.main,{anchor:r,head:o}=s,l=this.toEditorPos(i.updateRangeStart),a=this.toEditorPos(i.updateRangeEnd);e.inputState.composing>=0&&!this.composing&&(this.composing={contextBase:i.updateRangeStart,editorBase:l,drifted:!1});let f=a-l>i.text.length;l==this.from&&r<this.from?l=r:a==this.to&&r>this.to&&(a=r);let c=Ap(e.state.sliceDoc(l,a),i.text,(f?s.from:s.to)-l,f?"end":null);if(!c){let p=M.single(this.toEditorPos(i.selectionStart),this.toEditorPos(i.selectionEnd));Fr(p,s)||e.dispatch({selection:p,userEvent:"select"});return}let u={from:c.from+l,to:c.toA+l,insert:oe.of(i.text.slice(c.from,c.toB).split(`
`))};if((F.mac||F.android)&&u.from==o-1&&/^\. ?$/.test(i.text)&&e.contentDOM.getAttribute("autocorrect")=="off"&&(u={from:l,to:a,insert:oe.of([i.text.replace("."," ")])}),this.pendingContextChange=u,!e.state.readOnly){let p=this.to-this.from+(u.to-u.from+u.insert.length);Va(e,u,M.single(this.toEditorPos(i.selectionStart,p),this.toEditorPos(i.selectionEnd,p)))}this.pendingContextChange&&(this.revertPending(e.state),this.setSelection(e.state)),u.from<u.to&&!u.insert.length&&e.inputState.composing>=0&&!/[\\p{Alphabetic}\\p{Number}_]/.test(t.text.slice(Math.max(0,i.updateRangeStart-1),Math.min(t.text.length,i.updateRangeStart+1)))&&this.handlers.compositionend(i)},this.handlers.characterboundsupdate=i=>{let s=[],r=null;for(let o=this.toEditorPos(i.rangeStart),l=this.toEditorPos(i.rangeEnd);o<l;o++){let a=e.coordsForChar(o);r=a&&new DOMRect(a.left,a.top,a.right-a.left,a.bottom-a.top)||r||new DOMRect,s.push(r)}t.updateCharacterBounds(i.rangeStart,s)},this.handlers.textformatupdate=i=>{let s=[];for(let r of i.getTextFormats()){let o=r.underlineStyle,l=r.underlineThickness;if(!/none/i.test(o)&&!/none/i.test(l)){let a=this.toEditorPos(r.rangeStart),f=this.toEditorPos(r.rangeEnd);if(a<f){let c=`text-decoration: underline ${/^[a-z]/.test(o)?o+" ":o=="Dashed"?"dashed ":o=="Squiggle"?"wavy ":""}${/thin/i.test(l)?1:2}px`;s.push(K.mark({attributes:{style:c}}).range(a,f))}}}e.dispatch({effects:vp.of(K.set(s))})},this.handlers.compositionstart=()=>{e.inputState.composing<0&&(e.inputState.composing=0,e.inputState.compositionFirstChange=!0)},this.handlers.compositionend=()=>{if(e.inputState.composing=-1,e.inputState.compositionFirstChange=null,this.composing){let{drifted:i}=this.composing;this.composing=null,i&&this.reset(e.state)}};for(let i in this.handlers)t.addEventListener(i,this.handlers[i]);this.measureReq={read:i=>{let s=xn(i.root);s&&s.rangeCount&&this.editContext.updateSelectionBounds(s.getRangeAt(0).getBoundingClientRect())}}}applyEdits(e){let t=0,i=!1,s=this.pendingContextChange;return e.changes.iterChanges((r,o,l,a,f)=>{if(i)return;let c=f.length-(o-r);if(s&&o>=s.to)if(s.from==r&&s.to==o&&s.insert.eq(f)){s=this.pendingContextChange=null,t+=c,this.to+=c;return}else s=null,this.revertPending(e.state);if(r+=t,o+=t,o<=this.from)this.from+=c,this.to+=c;else if(r<this.to){if(r<this.from||o>this.to||this.to-this.from+f.length>3e4){i=!0;return}this.editContext.updateText(this.toContextPos(r),this.toContextPos(o),f.toString()),this.to+=c}t+=c}),s&&!i&&this.revertPending(e.state),!i}update(e){let t=this.pendingContextChange,i=e.startState.selection.main;this.composing&&(this.composing.drifted||!e.changes.touchesRange(i.from,i.to)&&e.transactions.some(s=>!s.isUserEvent("input.type")&&s.changes.touchesRange(this.from,this.to)))?(this.composing.drifted=!0,this.composing.editorBase=e.changes.mapPos(this.composing.editorBase)):!this.applyEdits(e)||!this.rangeIsValid(e.state)?(this.pendingContextChange=null,this.reset(e.state)):(e.docChanged||e.selectionSet||t)&&this.setSelection(e.state),(e.geometryChanged||e.docChanged||e.selectionSet)&&e.view.requestMeasure(this.measureReq)}resetRange(e){let{head:t}=e.selection.main;this.from=Math.max(0,t-1e4),this.to=Math.min(e.doc.length,t+1e4)}reset(e){this.resetRange(e),this.editContext.updateText(0,this.editContext.text.length,e.doc.sliceString(this.from,this.to)),this.setSelection(e)}revertPending(e){let t=this.pendingContextChange;this.pendingContextChange=null,this.editContext.updateText(this.toContextPos(t.from),this.toContextPos(t.from+t.insert.length),e.doc.sliceString(t.from,t.to))}setSelection(e){let{main:t}=e.selection,i=this.toContextPos(Math.max(this.from,Math.min(this.to,t.anchor))),s=this.toContextPos(t.head);(this.editContext.selectionStart!=i||this.editContext.selectionEnd!=s)&&this.editContext.updateSelection(i,s)}rangeIsValid(e){let{head:t}=e.selection.main;return!(this.from>0&&t-this.from<500||this.to<e.doc.length&&this.to-t<500||this.to-this.from>1e4*3)}toEditorPos(e,t=this.to-this.from){e=Math.min(e,t);let i=this.composing;return i&&i.drifted?i.editorBase+(e-i.contextBase):e+this.from}toContextPos(e){let t=this.composing;return t&&t.drifted?t.contextBase+(e-t.editorBase):e-this.from}destroy(){for(let e in this.handlers)this.editContext.removeEventListener(e,this.handlers[e])}},z=class n{get state(){return this.viewState.state}get viewport(){return this.viewState.viewport}get visibleRanges(){return this.viewState.visibleRanges}get inView(){return this.viewState.inView}get composing(){return!!this.inputState&&this.inputState.composing>0}get compositionStarted(){return!!this.inputState&&this.inputState.composing>=0}get root(){return this._root}get win(){return this.dom.ownerDocument.defaultView||window}constructor(e={}){var t;this.plugins=[],this.pluginMap=new Map,this.editorAttrs={},this.contentAttrs={},this.bidiCache=[],this.destroyed=!1,this.updateState=2,this.measureScheduled=-1,this.measureRequests=[],this.clearAnnouncement=-1,this.contentDOM=document.createElement("div"),this.scrollDOM=document.createElement("div"),this.scrollDOM.tabIndex=-1,this.scrollDOM.className="cm-scroller",this.scrollDOM.appendChild(this.contentDOM),this.announceDOM=document.createElement("div"),this.announceDOM.className="cm-announced",this.announceDOM.setAttribute("aria-live","polite"),this.dom=document.createElement("div"),this.dom.appendChild(this.announceDOM),this.dom.appendChild(this.scrollDOM),e.parent&&e.parent.appendChild(this.dom);let{dispatch:i}=e;this.dispatchTransactions=e.dispatchTransactions||i&&(s=>s.forEach(r=>i(r,this)))||(s=>this.update(s)),this.dispatch=this.dispatch.bind(this),this._root=e.root||Dv(e.parent)||document,this.viewState=new jr(this,e.state||pe.create(e)),e.scrollTo&&e.scrollTo.is(br)&&(this.viewState.scrollTarget=e.scrollTo.value.clip(this.viewState.state)),this.plugins=this.state.facet(Cs).map(s=>new _n(s));for(let s of this.plugins)s.update(this);this.observer=new Ea(this),this.inputState=new ga(this),this.inputState.ensureHandlers(this.plugins),this.docView=new Br(this),this.mountStyles(),this.updateAttrs(),this.updateState=0,this.requestMeasure(),!((t=document.fonts)===null||t===void 0)&&t.ready&&document.fonts.ready.then(()=>{this.viewState.mustMeasureContent="refresh",this.requestMeasure()})}dispatch(...e){let t=e.length==1&&e[0]instanceof Re?e:e.length==1&&Array.isArray(e[0])?e[0]:[this.state.update(...e)];this.dispatchTransactions(t,this)}update(e){if(this.updateState!=0)throw new Error("Calls to EditorView.update are not allowed while an update is in progress");let t=!1,i=!1,s,r=this.state;for(let p of e){if(p.startState!=r)throw new RangeError("Trying to update state with a transaction that doesn't start from the previous state.");r=p.state}if(this.destroyed){this.viewState.state=r;return}let o=this.hasFocus,l=0,a=null;e.some(p=>p.annotation(Lp))?(this.inputState.notifiedFocused=o,l=1):o!=this.inputState.notifiedFocused&&(this.inputState.notifiedFocused=o,a=Qp(r,o),a||(l=1));let f=this.observer.delayedAndroidKey,c=null;if(f?(this.observer.clearDelayedAndroidKey(),c=this.observer.readChange(),(c&&!this.state.doc.eq(r.doc)||!this.state.selection.eq(r.selection))&&(c=null)):this.observer.clear(),r.facet(pe.phrases)!=this.state.facet(pe.phrases))return this.setState(r);s=Qr.create(this,r,e),s.flags|=l;let u=this.viewState.scrollTarget;try{this.updateState=2;for(let p of e){if(u&&(u=u.map(p.changes)),p.scrollIntoView){let{main:y}=p.state.selection,{x:v,y:b}=this.state.facet(n.cursorScrollMargin);u=new gn(y.empty?y:M.cursor(y.head,y.head>y.anchor?-1:1),"nearest","nearest",b,v)}for(let y of p.effects)y.is(br)&&(u=y.value.clip(this.state))}this.viewState.update(s,u),this.bidiCache=Vr.update(this.bidiCache,s.changes),s.empty||(this.updatePlugins(s),this.inputState.update(s)),t=this.docView.update(s),this.state.facet(dn)!=this.styleModules&&this.mountStyles(),i=this.updateAttrs(),this.showAnnouncements(e),this.docView.updateSelection(t,e.some(p=>p.isUserEvent("select.pointer")))}finally{this.updateState=0}if(s.startState.facet(xr)!=s.state.facet(xr)&&(this.viewState.mustMeasureContent=!0),(t||i||u||this.viewState.mustEnforceCursorAssoc||this.viewState.mustMeasureContent)&&this.requestMeasure(),t&&this.docViewUpdate(),!s.empty)for(let p of this.state.facet(ia))try{p(s)}catch(y){tt(this.state,y,"update listener")}(a||c)&&Promise.resolve().then(()=>{a&&this.state==a.startState&&this.dispatch(a),c&&!Ep(this,c)&&f.force&&Ns(this.contentDOM,f.key,f.keyCode)})}setState(e){if(this.updateState!=0)throw new Error("Calls to EditorView.setState are not allowed while an update is in progress");if(this.destroyed){this.viewState.state=e;return}this.updateState=2;let t=this.hasFocus;try{for(let i of this.plugins)i.destroy(this);this.viewState=new jr(this,e),this.plugins=e.facet(Cs).map(i=>new _n(i)),this.pluginMap.clear();for(let i of this.plugins)i.update(this);this.docView.destroy(),this.docView=new Br(this),this.inputState.ensureHandlers(this.plugins),this.mountStyles(),this.updateAttrs(),this.bidiCache=[]}finally{this.updateState=0}t&&this.focus(),this.requestMeasure()}updatePlugins(e){let t=e.startState.facet(Cs),i=e.state.facet(Cs);if(t!=i){let s=[];for(let r of i){let o=t.indexOf(r);if(o<0)s.push(new _n(r));else{let l=this.plugins[o];l.mustUpdate=e,s.push(l)}}for(let r of this.plugins)r.mustUpdate!=e&&r.destroy(this);this.plugins=s,this.pluginMap.clear()}else for(let s of this.plugins)s.mustUpdate=e;for(let s=0;s<this.plugins.length;s++)this.plugins[s].update(this);t!=i&&this.inputState.ensureHandlers(this.plugins)}docViewUpdate(){for(let e of this.plugins){let t=e.value;if(t&&t.docViewUpdate)try{t.docViewUpdate(this)}catch(i){tt(this.state,i,"doc view update listener")}}}measure(e=!0){if(this.destroyed)return;if(this.measureScheduled>-1&&this.win.cancelAnimationFrame(this.measureScheduled),this.observer.delayedAndroidKey){this.measureScheduled=-1,this.requestMeasure();return}this.measureScheduled=0,e&&this.observer.forceFlush();let t=null,i=this.viewState.scrollParent,s=this.viewState.getScrollOffset(),{scrollAnchorPos:r,scrollAnchorHeight:o,scaleY:l}=this.viewState;Math.abs(s-this.viewState.scrollOffset)>1&&(o=-1),this.viewState.scrollAnchorHeight=-1;try{for(let a=0;;a++){if(o<0){if(sp(i||this.win))r=-1,o=this.viewState.heightMap.height/this.viewState.scaleY;else{let v=this.viewState.scrollAnchorAt(s);r=v.from,o=v.top}l=this.viewState.scaleY}this.updateState=1;let f=this.viewState.measure();if(!f&&!this.measureRequests.length&&this.viewState.scrollTarget==null)break;if(a>5){console.warn(this.measureRequests.length?"Measure loop restarted more than 5 times":"Viewport failed to stabilize");break}let c=[];f&4||([this.measureRequests,c]=[c,this.measureRequests]);let u=c.map(v=>{try{return v.read(this)}catch(b){return tt(this.state,b),Bu}}),p=Qr.create(this,this.state,[]),y=!1;p.flags|=f,t?t.flags|=f:t=p,this.updateState=2,p.empty||(this.updatePlugins(p),this.inputState.update(p),this.updateAttrs(),y=this.docView.update(p),y&&this.docViewUpdate());for(let v=0;v<c.length;v++)if(u[v]!=Bu)try{let b=c[v];b.write&&b.write(u[v],this)}catch(b){tt(this.state,b)}if(y&&this.docView.updateSelection(!0),!p.viewportChanged&&this.measureRequests.length==0){if(this.viewState.editorHeight)if(this.viewState.scrollTarget){this.docView.scrollIntoView(this.viewState.scrollTarget),this.viewState.scrollTarget=null,o=-1;continue}else{let b=(r<0?this.viewState.heightMap.height:this.viewState.lineBlockAt(r).top)/this.viewState.scaleY-o/l;if((b>1||b<-1)&&!(F.ios&&this.inputState.lastIOSMomentumScroll>Date.now()-100)&&(i==this.scrollDOM||this.hasFocus||Math.max(this.inputState.lastWheelEvent,this.inputState.lastTouchTime)>Date.now()-100)){s=s+b,i?r<0?i.scrollTop=i.scrollHeight:i.scrollTop+=b:this.win.scrollBy(0,b),o=-1;continue}}break}}}finally{this.updateState=0,this.measureScheduled=-1}if(t&&!t.empty)for(let a of this.state.facet(ia))a(t)}get themeClasses(){return Pa+" "+(this.state.facet(Ta)?$p:Bp)+" "+this.state.facet(xr)}updateAttrs(){let e=$u(this,Op,{class:"cm-editor"+(this.hasFocus?" cm-focused ":" ")+this.themeClasses}),t={spellcheck:"false",autocorrect:"off",autocapitalize:"off",writingsuggestions:"false",translate:"no",contenteditable:this.state.facet(ri)?"true":"false",class:"cm-content",style:`${F.tabSize}: ${this.state.tabSize}`,role:"textbox","aria-multiline":"true"};this.state.readOnly&&(t["aria-readonly"]="true"),$u(this,Wa,t);let i=this.observer.ignore(()=>{let s=yu(this.contentDOM,this.contentAttrs,t),r=yu(this.dom,this.editorAttrs,e);return s||r});return this.editorAttrs=e,this.contentAttrs=t,i}showAnnouncements(e){let t=!0;for(let i of e)for(let s of i.effects)if(s.is(n.announce)){t&&(this.announceDOM.textContent="",this.win.clearTimeout(this.clearAnnouncement),this.clearAnnouncement=this.win.setTimeout(()=>{this.announceDOM.textContent="\xA0"},200),t=!1);let r=this.announceDOM.appendChild(document.createElement("div"));r.textContent=s.value}}mountStyles(){this.styleModules=this.state.facet(dn);let e=this.state.facet(n.cspNonce);kt.mount(this.root,this.styleModules.concat(BO).reverse(),e?{nonce:e}:void 0)}readMeasured(){if(this.updateState==2)throw new Error("Reading the editor layout isn't allowed during an update");this.updateState==0&&this.measureScheduled>-1&&this.measure(!1)}requestMeasure(e){if(this.measureScheduled<0&&(this.measureScheduled=this.win.requestAnimationFrame(()=>this.measure())),e){if(this.measureRequests.indexOf(e)>-1)return;if(e.key!=null){for(let t=0;t<this.measureRequests.length;t++)if(this.measureRequests[t].key===e.key){this.measureRequests[t]=e;return}}this.measureRequests.push(e)}}plugin(e){let t=this.pluginMap.get(e);return(t===void 0||t&&t.plugin!=e)&&this.pluginMap.set(e,t=this.plugins.find(i=>i.plugin==e)||null),t&&t.update(this).value}get documentTop(){return this.contentDOM.getBoundingClientRect().top+this.viewState.paddingTop}get documentPadding(){return{top:this.viewState.paddingTop,bottom:this.viewState.paddingBottom}}get scaleX(){return this.viewState.scaleX}get scaleY(){return this.viewState.scaleY}elementAtHeight(e){return this.readMeasured(),this.viewState.elementAtHeight(e)}lineBlockAtHeight(e){return this.readMeasured(),this.viewState.lineBlockAtHeight(e)}get viewportLineBlocks(){return this.viewState.viewportLines}lineBlockAt(e){return this.viewState.lineBlockAt(e)}get contentHeight(){return this.viewState.contentHeight}moveByChar(e,t,i){return zl(this,e,xu(this,e,t,i))}moveByGroup(e,t){return zl(this,e,xu(this,e,t,i=>fO(this,e.head,i)))}visualLineSide(e,t){return t?M.cursor(e.to,1):M.cursor(e.from,-1)}moveToLineBoundary(e,t,i=!0){return aO(this,e,t,i)}moveVertically(e,t,i){return zl(this,e,hO(this,e,t,i))}domAtPos(e,t=1){return this.docView.domAtPos(e,t)}posAtDOM(e,t=0){return this.docView.posFromDOM(e,t)}posAtCoords(e,t=!0){this.readMeasured();let i=da(this,e,t);return i&&i.pos}posAndSideAtCoords(e,t=!0){return this.readMeasured(),da(this,e,t)}coordsAtPos(e,t=1){this.readMeasured();let i=this.state.doc.lineAt(e),s=this.bidiSpans(i),r=s[Tt.find(s,e-i.from,-1,t)];return i.length&&(e==i.from&&t<0||e==i.to&&t>0)&&r.dir!=this.textDirectionAt(i.from)&&(e==i.to?(e=i.from+r.from,t=1):(e=i.from+r.to,t=-1)),this.docView.coordsAt(e,t,r.dir==_e.RTL)}coordsForChar(e){return this.readMeasured(),this.docView.coordsForChar(e)}get defaultCharacterWidth(){return this.viewState.heightOracle.charWidth}get defaultLineHeight(){return this.viewState.heightOracle.lineHeight}get textDirection(){return this.viewState.defaultTextDirection}textDirectionAt(e){return!this.state.facet(_p)||e<this.viewport.from||e>this.viewport.to?this.textDirection:(this.readMeasured(),this.docView.textDirectionAt(e))}get lineWrapping(){return this.viewState.heightOracle.lineWrapping}bidiSpans(e){if(e.length>WO)return fp(e.length);let t=this.textDirectionAt(e.from),i;for(let r of this.bidiCache)if(r.from==e.from&&r.dir==t&&(r.fresh||ap(r.isolates,i=Ou(this,e))))return r.order;i||(i=Ou(this,e));let s=Wv(e.text,t,i);return this.bidiCache.push(new Vr(e.from,e.to,t,i,!0,s)),s}get hasFocus(){var e;return(this.dom.ownerDocument.hasFocus()||F.safari&&((e=this.inputState)===null||e===void 0?void 0:e.lastContextMenu)>Date.now()-3e4)&&this.root.activeElement==this.contentDOM}focus(){this.observer.ignore(()=>{ip(this.contentDOM),this.docView.updateSelection()})}setRoot(e){this._root!=e&&(this._root=e,this.observer.setWindow((e.nodeType==9?e:e.ownerDocument).defaultView||window),this.mountStyles())}destroy(){this.root.activeElement==this.contentDOM&&this.contentDOM.blur();for(let e of this.plugins)e.destroy(this);this.plugins=[],this.inputState.destroy(),this.docView.destroy(),this.dom.remove(),this.observer.destroy(),this.win.clearTimeout(this.clearAnnouncement),this.measureScheduled>-1&&this.win.cancelAnimationFrame(this.measureScheduled),this.destroyed=!0}static scrollIntoView(e,t={}){var i,s,r,o;return br.of(new gn(typeof e=="number"?M.cursor(e):e,(i=t.y)!==null&&i!==void 0?i:"nearest",(s=t.x)!==null&&s!==void 0?s:"nearest",(r=t.yMargin)!==null&&r!==void 0?r:5,(o=t.xMargin)!==null&&o!==void 0?o:5))}scrollSnapshot(){let{scrollTop:e,scrollLeft:t}=this.scrollDOM,i=this.viewState.scrollAnchorAt(e);return br.of(new gn(M.cursor(i.from),"start","start",i.top-e,t,!0))}setTabFocusMode(e){e==null?this.inputState.tabFocusMode=this.inputState.tabFocusMode<0?0:-1:typeof e=="boolean"?this.inputState.tabFocusMode=e?0:-1:this.inputState.tabFocusMode!=0&&(this.inputState.tabFocusMode=Date.now()+e)}static domEventHandlers(e){return qe.define(()=>({}),{eventHandlers:e})}static domEventObservers(e){return qe.define(()=>({}),{eventObservers:e})}static theme(e,t){let i=kt.newName(),s=[xr.of(i),dn.of(Ca(`.${i}`,e))];return t&&t.dark&&s.push(Ta.of(!0)),s}static baseTheme(e){return Ot.lowest(dn.of(Ca("."+Pa,e,Fp)))}static findFromDOM(e){var t;let i=e.querySelector(".cm-content"),s=i&&Se.get(i)||Se.get(e);return((t=s==null?void 0:s.root)===null||t===void 0?void 0:t.view)||null}};z.styleModule=dn;z.inputHandler=mp;z.clipboardInputFilter=$a;z.clipboardOutputFilter=Fa;z.scrollHandler=bp;z.focusChangeEffect=gp;z.perLineTextDirection=_p;z.exceptionSink=pp;z.updateListener=ia;z.editable=ri;z.mouseSelectionStyle=up;z.dragMovesSelection=dp;z.clickAddsSelectionRange=cp;z.decorations=Xr;z.blockWrappers=wp;z.outerDecorations=za;z.atomicRanges=Pn;z.bidiIsolatedRanges=kp;z.cursorScrollMargin=W.define({combine:n=>{let e=5,t=5;for(let i of n)typeof i=="number"?e=t=i:{x:e,y:t}=i;return{x:e,y:t}}});z.scrollMargins=xp;z.darkTheme=Ta;z.cspNonce=W.define({combine:n=>n.length?n[0]:""});z.contentAttributes=Wa;z.editorAttributes=Op;z.lineWrapping=z.contentAttributes.of({class:"cm-lineWrapping"});z.announce=ne.define();var WO=4096,Bu={},Vr=class n{constructor(e,t,i,s,r,o){this.from=e,this.to=t,this.dir=i,this.isolates=s,this.fresh=r,this.order=o}static update(e,t){if(t.empty&&!e.some(r=>r.fresh))return e;let i=[],s=e.length?e[e.length-1].dir:_e.LTR;for(let r=Math.max(0,e.length-10);r<e.length;r++){let o=e[r];o.dir==s&&!t.touchesRange(o.from,o.to)&&i.push(new n(t.mapPos(o.from,1),t.mapPos(o.to,-1),o.dir,o.isolates,!1,o.order))}return i}};function $u(n,e,t){for(let i=n.state.facet(e),s=i.length-1;s>=0;s--){let r=i[s],o=typeof r=="function"?r(n):r;o&&Qa(o,t)}return t}var zO=F.mac?"mac":F.windows?"win":F.linux?"linux":"key";function jO(n,e){let t=n.split(/-(?!$)/),i=t[t.length-1];i=="Space"&&(i=" ");let s,r,o,l;for(let a=0;a<t.length-1;++a){let f=t[a];if(/^(cmd|meta|m)$/i.test(f))l=!0;else if(/^a(lt)?$/i.test(f))s=!0;else if(/^(c|ctrl|control)$/i.test(f))r=!0;else if(/^s(hift)?$/i.test(f))o=!0;else if(/^mod$/i.test(f))e=="mac"?l=!0:r=!0;else throw new Error("Unrecognized modifier name: "+f)}return s&&(i="Alt-"+i),r&&(i="Ctrl-"+i),l&&(i="Meta-"+i),o&&(i="Shift-"+i),i}function Sr(n,e,t){return e.altKey&&(n="Alt-"+n),e.ctrlKey&&(n="Ctrl-"+n),e.metaKey&&(n="Meta-"+n),t!==!1&&e.shiftKey&&(n="Shift-"+n),n}var VO=Ot.default(z.domEventHandlers({keydown(n,e){return jp(Wp(e.state),n,e,"editor")}})),$s=W.define({enables:VO}),Fu=new WeakMap;function Wp(n){let e=n.facet($s),t=Fu.get(e);return t||Fu.set(e,t=UO(e.reduce((i,s)=>i.concat(s),[]))),t}function zp(n,e,t){return jp(Wp(n.state),e,n,t)}var bi=null,HO=4e3;function UO(n,e=zO){let t=Object.create(null),i=Object.create(null),s=(o,l)=>{let a=i[o];if(a==null)i[o]=l;else if(a!=l)throw new Error("Key binding "+o+" is used both as a regular binding and as a multi-stroke prefix")},r=(o,l,a,f,c)=>{var u,p;let y=t[o]||(t[o]=Object.create(null)),v=l.split(/ (?!$)/).map(k=>jO(k,e));for(let k=1;k<v.length;k++){let T=v.slice(0,k).join(" ");s(T,!0),y[T]||(y[T]={preventDefault:!0,stopPropagation:!1,run:[P=>{let I=bi={view:P,prefix:T,scope:o};return setTimeout(()=>{bi==I&&(bi=null)},HO),!0}]})}let b=v.join(" ");s(b,!1);let O=y[b]||(y[b]={preventDefault:!1,stopPropagation:!1,run:((p=(u=y._any)===null||u===void 0?void 0:u.run)===null||p===void 0?void 0:p.slice())||[]});a&&O.run.push(a),f&&(O.preventDefault=!0),c&&(O.stopPropagation=!0)};for(let o of n){let l=o.scope?o.scope.split(" "):["editor"];if(o.any)for(let f of l){let c=t[f]||(t[f]=Object.create(null));c._any||(c._any={preventDefault:!1,stopPropagation:!1,run:[]});let{any:u}=o;for(let p in c)c[p].run.push(y=>u(y,Ra))}let a=o[e]||o.key;if(a)for(let f of l)r(f,a,o.run,o.preventDefault,o.stopPropagation),o.shift&&r(f,"Shift-"+a,o.shift,o.preventDefault,o.stopPropagation)}return t}var Ra=null;function jp(n,e,t,i){Ra=e;let s=uu(e),r=Ge(s,0),o=ct(r)==s.length&&s!=" ",l="",a=!1,f=!1,c=!1;bi&&bi.view==t&&bi.scope==i&&(l=bi.prefix+" ",Mp.indexOf(e.keyCode)<0&&(f=!0,bi=null));let u=new Set,p=O=>{if(O){for(let k of O.run)if(!u.has(k)&&(u.add(k),k(t)))return O.stopPropagation&&(c=!0),!0;O.preventDefault&&(O.stopPropagation&&(c=!0),f=!0)}return!1},y=n[i],v,b;return y&&(p(y[l+Sr(s,e,!o)])?a=!0:o&&(e.altKey||e.metaKey||e.ctrlKey)&&!(F.windows&&e.ctrlKey&&e.altKey)&&!(F.mac&&e.altKey&&!(e.ctrlKey||e.metaKey))&&(v=ni[e.keyCode])&&v!=s?(p(y[l+Sr(v,e,!0)])||e.shiftKey&&(b=Ts[e.keyCode])!=s&&b!=v&&p(y[l+Sr(b,e,!1)]))&&(a=!0):o&&e.shiftKey&&p(y[l+Sr(s,e,!0)])&&(a=!0),!a&&p(y._any)&&(a=!0)),f&&(a=!0),a&&c&&e.stopPropagation(),Ra=null,a}var Xi=class n{constructor(e,t,i,s,r){this.className=e,this.left=t,this.top=i,this.width=s,this.height=r}draw(){let e=document.createElement("div");return e.className=this.className,this.adjust(e),e}update(e,t){return t.className!=this.className?!1:(this.adjust(e),!0)}adjust(e){e.style.left=this.left+"px",e.style.top=this.top+"px",this.width!=null&&(e.style.width=this.width+"px"),e.style.height=this.height+"px"}eq(e){return this.left==e.left&&this.top==e.top&&this.width==e.width&&this.height==e.height&&this.className==e.className}static forRange(e,t,i){if(i.empty){let s=e.coordsAtPos(i.head,i.assoc||1);if(!s)return[];let r=Vp(e);return[new n(t,s.left-r.left,s.top-r.top,null,s.bottom-s.top)]}else return GO(e,t,i)}};function Vp(n){let e=n.scrollDOM.getBoundingClientRect();return{left:(n.textDirection==_e.LTR?e.left:e.right-n.scrollDOM.clientWidth*n.scaleX)-n.scrollDOM.scrollLeft*n.scaleX,top:e.top-n.scrollDOM.scrollTop*n.scaleY}}function Wu(n,e,t,i){let s=n.coordsAtPos(e,t*2);if(!s)return i;let r=n.dom.getBoundingClientRect(),o=(s.top+s.bottom)/2,l=n.posAtCoords({x:r.left+1,y:o}),a=n.posAtCoords({x:r.right-1,y:o});return l==null||a==null?i:{from:Math.max(i.from,Math.min(l,a)),to:Math.min(i.to,Math.max(l,a))}}function GO(n,e,t){if(t.to<=n.viewport.from||t.from>=n.viewport.to)return[];let i=Math.max(t.from,n.viewport.from),s=Math.min(t.to,n.viewport.to),r=n.textDirection==_e.LTR,o=n.contentDOM,l=o.getBoundingClientRect(),a=Vp(n),f=o.querySelector(".cm-line"),c=f&&window.getComputedStyle(f),u=l.left+(c?parseInt(c.paddingLeft)+Math.min(0,parseInt(c.textIndent)):0),p=l.right-(c?parseInt(c.paddingRight):0),y=ca(n,i,1),v=ca(n,s,-1),b=y.type==Ve.Text?y:null,O=v.type==Ve.Text?v:null;if(b&&(n.lineWrapping||y.widgetLineBreaks)&&(b=Wu(n,i,1,b)),O&&(n.lineWrapping||v.widgetLineBreaks)&&(O=Wu(n,s,-1,O)),b&&O&&b.from==O.from&&b.to==O.to)return T(P(t.from,t.to,b));{let E=b?P(t.from,null,b):I(y,!1),R=O?P(null,t.to,O):I(v,!0),N=[];return(b||y).to<(O||v).from-(b&&O?1:0)||y.widgetLineBreaks>1&&E.bottom+n.defaultLineHeight/2<R.top?N.push(k(u,E.bottom,p,R.top)):E.bottom<R.top&&n.elementAtHeight((E.bottom+R.top)/2).type==Ve.Text&&(E.bottom=R.top=(E.bottom+R.top)/2),T(E).concat(N).concat(T(R))}function k(E,R,N,B){return new Xi(e,E-a.left,R-a.top,Math.max(0,N-E),B-R)}function T({top:E,bottom:R,horizontal:N}){let B=[];for(let J=0;J<N.length;J+=2)B.push(k(N[J],E,N[J+1],R));return B}function P(E,R,N){let B=1e9,J=-1e9,fe=[];function Z(le,ye,We,Ye,gt){let Ne=n.coordsAtPos(le,le==N.to?-2:2),rt=n.coordsAtPos(We,We==N.from?2:-2);!Ne||!rt||(B=Math.min(Ne.top,rt.top,B),J=Math.max(Ne.bottom,rt.bottom,J),gt==_e.LTR?fe.push(r&&ye?u:Ne.left,r&&Ye?p:rt.right):fe.push(!r&&Ye?u:rt.left,!r&&ye?p:Ne.right))}let U=E??N.from,ee=R??N.to;for(let le of n.visibleRanges)if(le.to>U&&le.from<ee)for(let ye=Math.max(le.from,U),We=Math.min(le.to,ee);;){let Ye=n.state.doc.lineAt(ye);for(let gt of n.bidiSpans(Ye)){let Ne=gt.from+Ye.from,rt=gt.to+Ye.from;if(Ne>=We)break;rt>ye&&Z(Math.max(Ne,ye),E==null&&Ne<=U,Math.min(rt,We),R==null&&rt>=ee,gt.dir)}if(ye=Ye.to+1,ye>=We)break}return fe.length==0&&Z(U,E==null,ee,R==null,n.textDirection),{top:B,bottom:J,horizontal:fe}}function I(E,R){let N=l.top+(R?E.top:E.bottom);return{top:N,bottom:N,horizontal:[]}}}function XO(n,e){return n.constructor==e.constructor&&n.eq(e)}var Ma=class{constructor(e,t){this.view=e,this.layer=t,this.drawn=[],this.scaleX=1,this.scaleY=1,this.measureReq={read:this.measure.bind(this),write:this.draw.bind(this)},this.dom=e.scrollDOM.appendChild(document.createElement("div")),this.dom.classList.add("cm-layer"),t.above&&this.dom.classList.add("cm-layer-above"),t.class&&this.dom.classList.add(t.class),this.scale(),this.dom.setAttribute("aria-hidden","true"),this.setOrder(e.state),e.requestMeasure(this.measureReq),t.mount&&t.mount(this.dom,e)}update(e){e.startState.facet(Er)!=e.state.facet(Er)&&this.setOrder(e.state),(this.layer.update(e,this.dom)||e.geometryChanged)&&(this.scale(),e.view.requestMeasure(this.measureReq))}docViewUpdate(e){this.layer.updateOnDocViewUpdate!==!1&&e.requestMeasure(this.measureReq)}setOrder(e){let t=0,i=e.facet(Er);for(;t<i.length&&i[t]!=this.layer;)t++;this.dom.style.zIndex=String((this.layer.above?150:-1)-t)}measure(){return this.layer.markers(this.view)}scale(){let{scaleX:e,scaleY:t}=this.view;(e!=this.scaleX||t!=this.scaleY)&&(this.scaleX=e,this.scaleY=t,this.dom.style.transform=`scale(${1/e}, ${1/t})`)}draw(e){if(e.length!=this.drawn.length||e.some((t,i)=>!XO(t,this.drawn[i]))){let t=this.dom.firstChild,i=0;for(let s of e)s.update&&t&&s.constructor&&this.drawn[i].constructor&&s.update(t,this.drawn[i])?(t=t.nextSibling,i++):this.dom.insertBefore(s.draw(),t);for(;t;){let s=t.nextSibling;t.remove(),t=s}this.drawn=e,F.webkit&&(this.dom.style.display=this.dom.firstChild?"":"none")}}destroy(){this.layer.destroy&&this.layer.destroy(this.dom,this.view),this.dom.remove()}},Er=W.define();function Hp(n){return[qe.define(e=>new Ma(e,n)),Er.of(n)]}var Bs=W.define({combine(n){return wt(n,{cursorBlinkRate:1200,drawRangeCursor:!0,iosSelectionHandles:!0},{cursorBlinkRate:(e,t)=>Math.min(e,t),drawRangeCursor:(e,t)=>e||t})}});function Up(n={}){return[Bs.of(n),JO,YO,ZO,yp.of(!0)]}function Gp(n){return n.startState.facet(Bs)!=n.state.facet(Bs)}var JO=Hp({above:!0,markers(n){let{state:e}=n,t=e.facet(Bs),i=[];for(let s of e.selection.ranges){let r=s==e.selection.main;if(s.empty||t.drawRangeCursor&&!(r&&F.ios&&t.iosSelectionHandles)){let o=r?"cm-cursor cm-cursor-primary":"cm-cursor cm-cursor-secondary",l=s.empty?s:M.cursor(s.head,s.assoc);for(let a of Xi.forRange(n,o,l))i.push(a)}}return i},update(n,e){n.transactions.some(i=>i.selection)&&(e.style.animationName=e.style.animationName=="cm-blink"?"cm-blink2":"cm-blink");let t=Gp(n);return t&&zu(n.state,e),n.docChanged||n.selectionSet||t},mount(n,e){zu(e.state,n)},class:"cm-cursorLayer"});function zu(n,e){e.style.animationDuration=n.facet(Bs).cursorBlinkRate+"ms"}var YO=Hp({above:!1,markers(n){let e=[],{main:t,ranges:i}=n.state.selection;for(let s of i)if(!s.empty)for(let r of Xi.forRange(n,"cm-selectionBackground",s))e.push(r);if(F.ios&&!t.empty&&n.state.facet(Bs).iosSelectionHandles){for(let s of Xi.forRange(n,"cm-selectionHandle cm-selectionHandle-start",M.cursor(t.from,1)))e.push(s);for(let s of Xi.forRange(n,"cm-selectionHandle cm-selectionHandle-end",M.cursor(t.to,1)))e.push(s)}return e},update(n,e){return n.docChanged||n.selectionSet||n.viewportChanged||Gp(n)},class:"cm-selectionLayer"}),KO=F.gecko&&F.gecko_version==153?"#ffffff01":"transparent",ZO=Ot.highest(z.theme({".cm-line":{"& ::selection, &::selection":{backgroundColor:`${KO} !important`},caretColor:"transparent !important"},".cm-content":{caretColor:"transparent !important","& :focus":{caretColor:"initial !important","&::selection, & ::selection":{backgroundColor:"Highlight !important"}}}}));var RC=/x/.unicode!=null?"gu":"g";function Xp(){return tw}var ew=K.line({class:"cm-activeLine"}),tw=qe.fromClass(class{constructor(n){this.decorations=this.getDeco(n)}update(n){(n.docChanged||n.selectionSet)&&(this.decorations=this.getDeco(n.view))}getDeco(n){let e=-1,t=[];for(let i of n.state.selection.ranges){let s=n.lineBlockAt(i.head);s.from>e&&(t.push(ew.range(s.from)),e=s.from)}return K.set(t)}},{decorations:n=>n.decorations});var Tr="-10000px",Na=class{constructor(e,t,i,s){this.facet=t,this.createTooltipView=i,this.removeTooltipView=s,this.input=e.state.facet(t),this.tooltips=this.input.filter(o=>o);let r=null;this.tooltipViews=this.tooltips.map(o=>r=i(o,r))}update(e,t){var i;let s=e.state.facet(this.facet),r=s.filter(a=>a);if(s===this.input){for(let a of this.tooltipViews)a.update&&a.update(e);return!1}let o=[],l=t?[]:null;for(let a=0;a<r.length;a++){let f=r[a],c=-1;if(f){for(let u=0;u<this.tooltips.length;u++){let p=this.tooltips[u];p&&p.create==f.create&&(c=u)}if(c<0)o[a]=this.createTooltipView(f,a?o[a-1]:null),l&&(l[a]=!!f.above);else{let u=o[a]=this.tooltipViews[c];l&&(l[a]=t[c]),u.update&&u.update(e)}}}for(let a of this.tooltipViews)o.indexOf(a)<0&&(this.removeTooltipView(a),(i=a.destroy)===null||i===void 0||i.call(a));return t&&(l.forEach((a,f)=>t[f]=a),t.length=l.length),this.input=s,this.tooltips=r,this.tooltipViews=o,!0}};function iw(n){let e=n.dom.ownerDocument.documentElement;return{top:0,left:0,bottom:e.clientHeight,right:e.clientWidth}}var Vl=W.define({combine:n=>{var e,t,i;return{position:F.ios?"absolute":((e=n.find(s=>s.position))===null||e===void 0?void 0:e.position)||"fixed",parent:((t=n.find(s=>s.parent))===null||t===void 0?void 0:t.parent)||null,tooltipSpace:((i=n.find(s=>s.tooltipSpace))===null||i===void 0?void 0:i.tooltipSpace)||iw}}}),ju=new WeakMap,Jp=qe.fromClass(class{constructor(n){this.view=n,this.above=[],this.inView=!0,this.madeAbsolute=!1,this.lastTransaction=0,this.measureTimeout=-1;let e=n.state.facet(Vl);this.position=e.position,this.parent=e.parent,this.classes=n.themeClasses,this.createContainer(),this.measureReq={read:this.readMeasure.bind(this),write:this.writeMeasure.bind(this),key:this},this.resizeObserver=typeof ResizeObserver=="function"?new ResizeObserver(()=>this.measureSoon()):null,this.manager=new Na(n,Ha,(t,i)=>this.createTooltip(t,i),t=>{this.resizeObserver&&this.resizeObserver.unobserve(t.dom),t.dom.remove()}),this.above=this.manager.tooltips.map(t=>!!t.above),this.intersectionObserver=typeof IntersectionObserver=="function"?new IntersectionObserver(t=>{Date.now()>this.lastTransaction-50&&t.length>0&&t[t.length-1].intersectionRatio<1&&this.measureSoon()},{threshold:[1]}):null,this.observeIntersection(),n.win.addEventListener("resize",this.measureSoon=this.measureSoon.bind(this)),this.maybeMeasure()}createContainer(){this.parent?(this.container=document.createElement("div"),this.container.style.position="relative",this.container.className=this.view.themeClasses,this.parent.appendChild(this.container)):this.container=this.view.dom}observeIntersection(){if(this.intersectionObserver){this.intersectionObserver.disconnect();for(let n of this.manager.tooltipViews)this.intersectionObserver.observe(n.dom)}}measureSoon(){this.measureTimeout<0&&(this.measureTimeout=setTimeout(()=>{this.measureTimeout=-1,this.maybeMeasure()},50))}update(n){n.transactions.length&&(this.lastTransaction=Date.now());let e=this.manager.update(n,this.above);e&&this.observeIntersection();let t=e||n.geometryChanged,i=n.state.facet(Vl);if(i.position!=this.position&&!this.madeAbsolute){this.position=i.position;for(let s of this.manager.tooltipViews)s.dom.style.position=this.position;t=!0}if(i.parent!=this.parent){this.parent&&this.container.remove(),this.parent=i.parent,this.createContainer();for(let s of this.manager.tooltipViews)this.container.appendChild(s.dom);t=!0}else this.parent&&this.view.themeClasses!=this.classes&&(this.classes=this.container.className=this.view.themeClasses);t&&this.maybeMeasure()}createTooltip(n,e){let t=n.create(this.view),i=e?e.dom:null;if(t.dom.classList.add("cm-tooltip"),n.arrow&&!t.dom.querySelector(".cm-tooltip > .cm-tooltip-arrow")){let s=document.createElement("div");s.className="cm-tooltip-arrow",t.dom.appendChild(s)}return t.dom.style.position=this.position,t.dom.style.top=Tr,t.dom.style.left="0px",this.container.insertBefore(t.dom,i),t.mount&&t.mount(this.view),this.resizeObserver&&this.resizeObserver.observe(t.dom),t}destroy(){var n,e,t;this.view.win.removeEventListener("resize",this.measureSoon);for(let i of this.manager.tooltipViews)i.dom.remove(),(n=i.destroy)===null||n===void 0||n.call(i);this.parent&&this.container.remove(),(e=this.resizeObserver)===null||e===void 0||e.disconnect(),(t=this.intersectionObserver)===null||t===void 0||t.disconnect(),clearTimeout(this.measureTimeout)}readMeasure(){let n=1,e=1,t=!1;if(this.position=="fixed"&&this.manager.tooltipViews.length){let{dom:r}=this.manager.tooltipViews[0];if(F.safari){let o=r.getBoundingClientRect();t=Math.abs(o.top+1e4)>1||Math.abs(o.left)>1}else t=!!r.offsetParent&&r.offsetParent!=this.container.ownerDocument.body}if(t||this.position=="absolute")if(this.parent){let r=this.parent.getBoundingClientRect();r.width&&r.height&&(n=r.width/this.parent.offsetWidth,e=r.height/this.parent.offsetHeight)}else({scaleX:n,scaleY:e}=this.view.viewState);let i=this.view.scrollDOM.getBoundingClientRect(),s=ja(this.view);return{visible:{left:i.left+s.left,top:i.top+s.top,right:i.right-s.right,bottom:i.bottom-s.bottom},parent:this.parent?this.container.getBoundingClientRect():this.view.dom.getBoundingClientRect(),pos:this.manager.tooltips.map((r,o)=>{let l=this.manager.tooltipViews[o];return l.getCoords?l.getCoords(r.pos):this.view.coordsAtPos(r.pos)}),size:this.manager.tooltipViews.map(({dom:r})=>r.getBoundingClientRect()),space:this.view.state.facet(Vl).tooltipSpace(this.view),scaleX:n,scaleY:e,makeAbsolute:t}}writeMeasure(n){var e;if(n.makeAbsolute){this.madeAbsolute=!0,this.position="absolute";for(let l of this.manager.tooltipViews)l.dom.style.position="absolute"}let{visible:t,space:i,scaleX:s,scaleY:r}=n,o=[];for(let l=0;l<this.manager.tooltips.length;l++){let a=this.manager.tooltips[l],f=this.manager.tooltipViews[l],{dom:c}=f,u=n.pos[l],p=n.size[l];if(!u||a.clip!==!1&&(u.bottom<=Math.max(t.top,i.top)||u.top>=Math.min(t.bottom,i.bottom)||u.right<Math.max(t.left,i.left)-.1||u.left>Math.min(t.right,i.right)+.1)){c.style.top=Tr;continue}let y=a.arrow?f.dom.querySelector(".cm-tooltip-arrow"):null,v=y?7:0,b=p.right-p.left,O=(e=ju.get(f))!==null&&e!==void 0?e:p.bottom-p.top,k=f.offset||nw,T=this.view.textDirection==_e.LTR,P=p.width>i.right-i.left?T?i.left:i.right-p.width:T?Math.max(i.left,Math.min(u.left-(y?14:0)+k.x,i.right-b)):Math.min(Math.max(i.left,u.left-b+(y?14:0)-k.x),i.right-b),I=this.above[l];!a.strictSide&&(I?u.top-O-v-k.y<i.top:u.bottom+O+v+k.y>i.bottom)&&I==i.bottom-u.bottom>u.top-i.top&&(I=this.above[l]=!I);let E=(I?u.top-i.top:i.bottom-u.bottom)-v;if(E<O&&f.resize!==!1){if(E<this.view.defaultLineHeight){c.style.top=Tr;continue}ju.set(f,O),c.style.height=(O=E)/r+"px"}else c.style.height&&(c.style.height="");let R=I?u.top-O-v-k.y:u.bottom+v+k.y,N=P+b;if(f.overlap!==!0)for(let B of o)B.left<N&&B.right>P&&B.top<R+O&&B.bottom>R&&(R=I?B.top-O-2-v:B.bottom+v+2);if(this.position=="absolute"?(c.style.top=(R-n.parent.top)/r+"px",Vu(c,(P-n.parent.left)/s)):(c.style.top=R/r+"px",Vu(c,P/s)),y){let B=u.left+(T?k.x:-k.x)-(P+14-7);y.style.left=B/s+"px"}f.overlap!==!0&&o.push({left:P,top:R,right:N,bottom:R+O}),c.classList.toggle("cm-tooltip-above",I),c.classList.toggle("cm-tooltip-below",!I),f.positioned&&f.positioned(n.space)}}maybeMeasure(){if(this.manager.tooltips.length&&(this.view.inView&&this.view.requestMeasure(this.measureReq),this.inView!=this.view.inView&&(this.inView=this.view.inView,!this.inView)))for(let n of this.manager.tooltipViews)n.dom.style.top=Tr}},{eventObservers:{scroll(){this.maybeMeasure()}}});function Vu(n,e){let t=parseInt(n.style.left,10);(isNaN(t)||Math.abs(e-t)>1)&&(n.style.left=e+"px")}var sw=z.baseTheme({".cm-tooltip":{zIndex:500,boxSizing:"border-box"},"&light .cm-tooltip":{border:"1px solid #bbb",backgroundColor:"#f5f5f5"},"&light .cm-tooltip-section:not(:first-child)":{borderTop:"1px solid #bbb"},"&dark .cm-tooltip":{backgroundColor:"#333338",color:"white"},".cm-tooltip-arrow":{height:"7px",width:`${7*2}px`,position:"absolute",zIndex:-1,overflow:"hidden","&:before, &:after":{content:"''",position:"absolute",width:0,height:0,borderLeft:"7px solid transparent",borderRight:"7px solid transparent"},".cm-tooltip-above &":{bottom:"-7px","&:before":{borderTop:"7px solid #bbb"},"&:after":{borderTop:"7px solid #f5f5f5",bottom:"1px"}},".cm-tooltip-below &":{top:"-7px","&:before":{borderBottom:"7px solid #bbb"},"&:after":{borderBottom:"7px solid #f5f5f5",top:"1px"}}},"&dark .cm-tooltip .cm-tooltip-arrow":{"&:before":{borderTopColor:"#333338",borderBottomColor:"#333338"},"&:after":{borderTopColor:"transparent",borderBottomColor:"transparent"}}}),nw={x:0,y:0},Ha=W.define({enables:[Jp,sw]});function Ua(n,e){let t=n.plugin(Jp);if(!t)return null;let i=t.manager.tooltips.indexOf(e);return i<0?null:t.manager.tooltipViews[i]}var Hu=W.define({combine(n){let e,t;for(let i of n)e=e||i.topContainer,t=t||i.bottomContainer;return{topContainer:e,bottomContainer:t}}});function Yr(n,e){let t=n.plugin(Yp),i=t?t.specs.indexOf(e):-1;return i>-1?t.panels[i]:null}var Yp=qe.fromClass(class{constructor(n){this.input=n.state.facet(Tn),this.specs=this.input.filter(t=>t),this.panels=this.specs.map(t=>t(n));let e=n.state.facet(Hu);this.top=new As(n,!0,e.topContainer),this.bottom=new As(n,!1,e.bottomContainer),this.top.sync(this.panels.filter(t=>t.top)),this.bottom.sync(this.panels.filter(t=>!t.top));for(let t of this.panels)t.dom.classList.add("cm-panel"),t.mount&&t.mount()}update(n){let e=n.state.facet(Hu);this.top.container!=e.topContainer&&(this.top.sync([]),this.top=new As(n.view,!0,e.topContainer)),this.bottom.container!=e.bottomContainer&&(this.bottom.sync([]),this.bottom=new As(n.view,!1,e.bottomContainer)),this.top.syncClasses(),this.bottom.syncClasses();let t=n.state.facet(Tn);if(t!=this.input){let i=t.filter(a=>a),s=[],r=[],o=[],l=[];for(let a of i){let f=this.specs.indexOf(a),c;f<0?(c=a(n.view),l.push(c)):(c=this.panels[f],c.update&&c.update(n)),s.push(c),(c.top?r:o).push(c)}this.specs=i,this.panels=s,this.top.sync(r),this.bottom.sync(o);for(let a of l)a.dom.classList.add("cm-panel"),a.mount&&a.mount()}else for(let i of this.panels)i.update&&i.update(n)}destroy(){this.top.sync([]),this.bottom.sync([])}},{provide:n=>z.scrollMargins.of(e=>{let t=e.plugin(n);return t&&{top:t.top.scrollMargin(),bottom:t.bottom.scrollMargin()}})}),As=class{constructor(e,t,i){this.view=e,this.top=t,this.container=i,this.dom=void 0,this.classes="",this.panels=[],this.syncClasses()}sync(e){for(let t of this.panels)t.destroy&&e.indexOf(t)<0&&t.destroy();this.panels=e,this.syncDOM()}syncDOM(){if(this.panels.length==0){this.dom&&(this.dom.remove(),this.dom=void 0);return}if(!this.dom){this.dom=document.createElement("div"),this.dom.className=this.top?"cm-panels cm-panels-top":"cm-panels cm-panels-bottom";let t=this.container||this.view.dom;t.insertBefore(this.dom,this.top?t.firstChild:null)}let e=this.dom.firstChild;for(let t of this.panels)if(t.dom.parentNode==this.dom){for(;e!=t.dom;)e=Uu(e);e=e.nextSibling}else this.dom.insertBefore(t.dom,e);for(;e;)e=Uu(e)}scrollMargin(){return!this.dom||this.container?0:Math.max(0,this.top?this.dom.getBoundingClientRect().bottom-Math.max(0,this.view.scrollDOM.getBoundingClientRect().top):Math.min(innerHeight,this.view.scrollDOM.getBoundingClientRect().bottom)-this.dom.getBoundingClientRect().top)}syncClasses(){if(!(!this.container||this.classes==this.view.themeClasses)){for(let e of this.classes.split(" "))e&&this.container.classList.remove(e);for(let e of(this.classes=this.view.themeClasses).split(" "))e&&this.container.classList.add(e)}}};function Uu(n){let e=n.nextSibling;return n.remove(),e}var Tn=W.define({enables:Yp});function Kp(n,e){let t,i=new Promise(o=>t=o),s=o=>rw(o,e,t);n.state.field(Ar,!1)?n.dispatch({effects:em.of(s)}):n.dispatch({effects:ne.appendConfig.of(Ar.init(()=>[s]))});let r=tm.of(s);return{close:r,result:i.then(o=>((n.win.queueMicrotask||(a=>n.win.setTimeout(a,10)))(()=>{n.state.field(Ar).indexOf(s)>-1&&n.dispatch({effects:r})}),o))}}function Zp(n,e){let t=n.state.field(Ar,!1)||[];for(let i of t){let s=Yr(n,i);if(s&&s.dom.classList.contains(e))return s}return null}var Ar=Qe.define({create(){return[]},update(n,e){for(let t of e.effects)t.is(em)?n=[t.value].concat(n):t.is(tm)&&(n=n.filter(i=>i!=t.value));return n},provide:n=>Tn.computeN([n],e=>e.field(n))}),em=ne.define(),tm=ne.define();function rw(n,e,t){let i=e.content?e.content(n,()=>o(null)):null;if(!i){if(i=Ae("form"),e.input){let l=Ae("input",e.input);/^(text|password|number|email|tel|url)$/.test(l.type)&&l.classList.add("cm-textfield"),l.name||(l.name="input"),i.appendChild(Ae("label",(e.label||"")+": ",l))}else i.appendChild(document.createTextNode(e.label||""));i.appendChild(document.createTextNode(" ")),i.appendChild(Ae("button",{class:"cm-button",type:"submit"},e.submitLabel||"OK"))}let s=i.nodeName=="FORM"?[i]:i.querySelectorAll("form");for(let l=0;l<s.length;l++){let a=s[l];a.addEventListener("keydown",f=>{f.keyCode==27?(f.preventDefault(),o(null)):f.keyCode==13&&(f.preventDefault(),o(a))}),a.addEventListener("submit",f=>{f.preventDefault(),o(a)})}let r=Ae("div",i,Ae("button",{onclick:()=>o(null),"aria-label":n.state.phrase("close"),class:"cm-dialog-close",type:"button"},["\xD7"]));e.class&&(r.className=e.class),r.classList.add("cm-dialog");function o(l){r.contains(r.ownerDocument.activeElement)&&n.focus(),t(l)}return{dom:r,top:e.top,mount:()=>{if(e.focus){let l;typeof e.focus=="string"?l=i.querySelector(e.focus):l=i.querySelector("input")||i.querySelector("button"),l&&"select"in l?l.select():l&&"focus"in l&&l.focus()}}}}var qt=class extends vt{compare(e){return this==e||this.constructor==e.constructor&&this.eq(e)}eq(e){return!1}destroy(e){}};qt.prototype.elementClass="";qt.prototype.toDOM=void 0;qt.prototype.mapMode=Le.TrackBefore;qt.prototype.startSide=qt.prototype.endSide=-1;qt.prototype.point=!0;var Rr=W.define(),ow=W.define();var Mr=W.define();var Da=W.define({combine:n=>n.some(e=>e)});function lw(n){let e=[aw];return n&&n.fixed===!1&&e.push(Da.of(!0)),e}var aw=qe.fromClass(class{constructor(n){this.view=n,this.domAfter=null,this.prevViewport=n.viewport,this.dom=document.createElement("div"),this.dom.className="cm-gutters cm-gutters-before",this.dom.setAttribute("aria-hidden","true"),this.dom.style.minHeight=this.view.contentHeight/this.view.scaleY+"px",this.gutters=n.state.facet(Mr).map(e=>new Hr(n,e)),this.fixed=!n.state.facet(Da);for(let e of this.gutters)e.config.side=="after"?this.getDOMAfter().appendChild(e.dom):this.dom.appendChild(e.dom);this.fixed&&(this.dom.style.position="sticky"),this.syncGutters(!1),n.scrollDOM.insertBefore(this.dom,n.contentDOM)}getDOMAfter(){return this.domAfter||(this.domAfter=document.createElement("div"),this.domAfter.className="cm-gutters cm-gutters-after",this.domAfter.setAttribute("aria-hidden","true"),this.domAfter.style.minHeight=this.view.contentHeight/this.view.scaleY+"px",this.domAfter.style.position=this.fixed?"sticky":"",this.view.scrollDOM.appendChild(this.domAfter)),this.domAfter}update(n){if(this.updateGutters(n)){let e=this.prevViewport,t=n.view.viewport,i=Math.min(e.to,t.to)-Math.max(e.from,t.from);this.syncGutters(i<(t.to-t.from)*.8)}if(n.geometryChanged){let e=this.view.contentHeight/this.view.scaleY+"px";this.dom.style.minHeight=e,this.domAfter&&(this.domAfter.style.minHeight=e)}this.view.state.facet(Da)!=!this.fixed&&(this.fixed=!this.fixed,this.dom.style.position=this.fixed?"sticky":"",this.domAfter&&(this.domAfter.style.position=this.fixed?"sticky":"")),this.prevViewport=n.view.viewport}syncGutters(n){let e=this.dom.nextSibling;n&&(this.dom.remove(),this.domAfter&&this.domAfter.remove());let t=ce.iter(this.view.state.facet(Rr),this.view.viewport.from),i=[],s=this.gutters.map(r=>new La(r,this.view.viewport,-this.view.documentPadding.top));for(let r of this.view.viewportLineBlocks)if(i.length&&(i=[]),Array.isArray(r.type)){let o=!0;for(let l of r.type)if(l.type==Ve.Text&&o){Ia(t,i,l.from);for(let a of s)a.line(this.view,l,i);o=!1}else if(l.widget)for(let a of s)a.widget(this.view,l)}else if(r.type==Ve.Text){Ia(t,i,r.from);for(let o of s)o.line(this.view,r,i)}else if(r.widget)for(let o of s)o.widget(this.view,r);for(let r of s)r.finish();n&&(this.view.scrollDOM.insertBefore(this.dom,e),this.domAfter&&this.view.scrollDOM.appendChild(this.domAfter))}updateGutters(n){let e=n.startState.facet(Mr),t=n.state.facet(Mr),i=n.docChanged||n.heightChanged||n.viewportChanged||!ce.eq(n.startState.facet(Rr),n.state.facet(Rr),n.view.viewport.from,n.view.viewport.to);if(e==t)for(let s of this.gutters)s.update(n)&&(i=!0);else{i=!0;let s=[];for(let r of t){let o=e.indexOf(r);o<0?s.push(new Hr(this.view,r)):(this.gutters[o].update(n),s.push(this.gutters[o]))}for(let r of this.gutters)r.dom.remove(),s.indexOf(r)<0&&r.destroy();for(let r of s)r.config.side=="after"?this.getDOMAfter().appendChild(r.dom):this.dom.appendChild(r.dom);this.gutters=s}return i}destroy(){for(let n of this.gutters)n.destroy();this.dom.remove(),this.domAfter&&this.domAfter.remove()}},{provide:n=>z.scrollMargins.of(e=>{let t=e.plugin(n);if(!t||t.gutters.length==0||!t.fixed)return null;let i=t.dom.offsetWidth*e.scaleX,s=t.domAfter?t.domAfter.offsetWidth*e.scaleX:0;return e.textDirection==_e.LTR?{left:i,right:s}:{right:i,left:s}})});function Gu(n){return Array.isArray(n)?n:[n]}function Ia(n,e,t){for(;n.value&&n.from<=t;)n.from==t&&e.push(n.value),n.next()}var La=class{constructor(e,t,i){this.gutter=e,this.height=i,this.i=0,this.cursor=ce.iter(e.markers,t.from)}addElement(e,t,i){let{gutter:s}=this,r=(t.top-this.height)/e.scaleY,o=t.height/e.scaleY;if(this.i==s.elements.length){let l=new Ur(e,o,r,i);s.elements.push(l),s.dom.appendChild(l.dom)}else s.elements[this.i].update(e,o,r,i);this.height=t.bottom,this.i++}line(e,t,i){let s=[];Ia(this.cursor,s,t.from),i.length&&(s=s.concat(i));let r=this.gutter.config.lineMarker(e,t,s);r&&s.unshift(r);let o=this.gutter;s.length==0&&!o.config.renderEmptyElements||this.addElement(e,t,s)}widget(e,t){let i=this.gutter.config.widgetMarker(e,t.widget,t),s=i?[i]:null;for(let r of e.state.facet(ow)){let o=r(e,t.widget,t);o&&(s||(s=[])).push(o)}s&&this.addElement(e,t,s)}finish(){let e=this.gutter;for(;e.elements.length>this.i;){let t=e.elements.pop();e.dom.removeChild(t.dom),t.destroy()}}},Hr=class{constructor(e,t){this.view=e,this.config=t,this.elements=[],this.spacer=null,this.dom=document.createElement("div"),this.dom.className="cm-gutter"+(this.config.class?" "+this.config.class:"");for(let i in t.domEventHandlers)this.dom.addEventListener(i,s=>{let r=s.target,o;if(r!=this.dom&&this.dom.contains(r)){for(;r.parentNode!=this.dom;)r=r.parentNode;let a=r.getBoundingClientRect();o=(a.top+a.bottom)/2}else o=s.clientY;let l=e.lineBlockAtHeight(o-e.documentTop);t.domEventHandlers[i](e,l,s)&&s.preventDefault()});this.markers=Gu(t.markers(e)),t.initialSpacer&&(this.spacer=new Ur(e,0,0,[t.initialSpacer(e)]),this.dom.appendChild(this.spacer.dom),this.spacer.dom.style.cssText+="visibility: hidden; pointer-events: none")}update(e){let t=this.markers;if(this.markers=Gu(this.config.markers(e.view)),this.spacer&&this.config.updateSpacer){let s=this.config.updateSpacer(this.spacer.markers[0],e);s!=this.spacer.markers[0]&&this.spacer.update(e.view,0,0,[s])}let i=e.view.viewport;return!ce.eq(this.markers,t,i.from,i.to)||(this.config.lineMarkerChange?this.config.lineMarkerChange(e):!1)}destroy(){for(let e of this.elements)e.destroy()}},Ur=class{constructor(e,t,i,s){this.height=-1,this.above=0,this.markers=[],this.dom=document.createElement("div"),this.dom.className="cm-gutterElement",this.update(e,t,i,s)}update(e,t,i,s){this.height!=t&&(this.height=t,this.dom.style.height=t+"px"),this.above!=i&&(this.dom.style.marginTop=(this.above=i)?i+"px":""),fw(this.markers,s)||this.setMarkers(e,s)}setMarkers(e,t){let i="cm-gutterElement",s=this.dom.firstChild;for(let r=0,o=0;;){let l=o,a=r<t.length?t[r++]:null,f=!1;if(a){let c=a.elementClass;c&&(i+=" "+c);for(let u=o;u<this.markers.length;u++)if(this.markers[u].compare(a)){l=u,f=!0;break}}else l=this.markers.length;for(;o<l;){let c=this.markers[o++];if(c.toDOM){c.destroy(s);let u=s.nextSibling;s.remove(),s=u}}if(!a)break;a.toDOM&&(f?s=s.nextSibling:this.dom.insertBefore(a.toDOM(e),s)),f&&o++}this.dom.className=i,this.markers=t}destroy(){this.setMarkers(null,[])}};function fw(n,e){if(n.length!=e.length)return!1;for(let t=0;t<n.length;t++)if(!n[t].compare(e[t]))return!1;return!0}var hw=W.define(),cw=W.define(),Rs=W.define({combine(n){return wt(n,{formatNumber:String,domEventHandlers:{}},{domEventHandlers(e,t){let i=Object.assign({},e);for(let s in t){let r=i[s],o=t[s];i[s]=r?(l,a,f)=>r(l,a,f)||o(l,a,f):o}return i}})}}),On=class extends qt{constructor(e){super(),this.number=e}eq(e){return this.number==e.number}toDOM(){return document.createTextNode(this.number)}};function Hl(n,e){return n.state.facet(Rs).formatNumber(e,n.state)}var dw=Mr.compute([Rs],n=>({class:"cm-lineNumbers",renderEmptyElements:!1,markers(e){return e.state.facet(hw)},lineMarker(e,t,i){return i.some(s=>s.toDOM)?null:new On(Hl(e,e.state.doc.lineAt(t.from).number))},widgetMarker:(e,t,i)=>{for(let s of e.state.facet(cw)){let r=s(e,t,i);if(r)return r}return null},lineMarkerChange:e=>e.startState.facet(Rs)!=e.state.facet(Rs),initialSpacer(e){return new On(Hl(e,Xu(e.state.doc.lines)))},updateSpacer(e,t){let i=Hl(t.view,Xu(t.view.state.doc.lines));return i==e.number?e:new On(i)},domEventHandlers:n.facet(Rs).domEventHandlers,side:"before"}));function im(n={}){return[Rs.of(n),lw(),dw]}function Xu(n){let e=9;for(;e<n;)e=e*10+9;return e}var uw=new class extends qt{constructor(){super(...arguments),this.elementClass="cm-activeLineGutter"}},pw=Rr.compute(["selection"],n=>{let e=[],t=-1;for(let i of n.selection.ranges){let s=n.doc.lineAt(i.head).from;s>t&&(t=s,e.push(uw.range(s)))}return ce.of(e)});function sm(){return pw}var mw=0,Cn=class{constructor(e,t){this.from=e,this.to=t}},ie=class{constructor(e={}){this.id=mw++,this.perNode=!!e.perNode,this.deserialize=e.deserialize||(()=>{throw new Error("This node type doesn't define a deserialize function")}),this.combine=e.combine||null}add(e){if(this.perNode)throw new RangeError("Can't add per-node props to node types");return typeof e!="function"&&(e=Xe.match(e)),t=>{let i=e(t);return i===void 0?null:[this,i]}}};ie.closedBy=new ie({deserialize:n=>n.split(" ")});ie.openedBy=new ie({deserialize:n=>n.split(" ")});ie.group=new ie({deserialize:n=>n.split(" ")});ie.isolate=new ie({deserialize:n=>{if(n&&n!="rtl"&&n!="ltr"&&n!="auto")throw new RangeError("Invalid value for isolate: "+n);return n||"auto"}});ie.contextHash=new ie({perNode:!0});ie.lookAhead=new ie({perNode:!0});ie.mounted=new ie({perNode:!0});var Zi=class{constructor(e,t,i,s=!1){this.tree=e,this.overlay=t,this.parser=i,this.bracketed=s}static get(e){return e&&e.props&&e.props[ie.mounted.id]}},gw=Object.create(null),Xe=class n{constructor(e,t,i,s=0){this.name=e,this.props=t,this.id=i,this.flags=s}static define(e){let t=e.props&&e.props.length?Object.create(null):gw,i=(e.top?1:0)|(e.skipped?2:0)|(e.error?4:0)|(e.name==null?8:0),s=new n(e.name||"",t,e.id,i);if(e.props){for(let r of e.props)if(Array.isArray(r)||(r=r(s)),r){if(r[0].perNode)throw new RangeError("Can't store a per-node prop on a node type");t[r[0].id]=r[1]}}return s}prop(e){return this.props[e.id]}get isTop(){return(this.flags&1)>0}get isSkipped(){return(this.flags&2)>0}get isError(){return(this.flags&4)>0}get isAnonymous(){return(this.flags&8)>0}is(e){if(typeof e=="string"){if(this.name==e)return!0;let t=this.prop(ie.group);return t?t.indexOf(e)>-1:!1}return this.id==e}static match(e){let t=Object.create(null);for(let i in e)for(let s of i.split(" "))t[s]=e[i];return i=>{for(let s=i.prop(ie.group),r=-1;r<(s?s.length:0);r++){let o=t[r<0?i.name:s[r]];if(o)return o}}}};Xe.none=new Xe("",Object.create(null),0,8);var En=class n{constructor(e){this.types=e;for(let t=0;t<e.length;t++)if(e[t].id!=t)throw new RangeError("Node type ids should correspond to array positions when creating a node set")}extend(...e){let t=[];for(let i of this.types){let s=null;for(let r of e){let o=r(i);if(o){s||(s=Object.assign({},i.props));let l=o[1],a=o[0];a.combine&&a.id in s&&(l=a.combine(s[a.id],l)),s[a.id]=l}}t.push(s?new Xe(i.name,s,i.id,i.flags):i)}return new n(t)}},Kr=new WeakMap,nm=new WeakMap,xe;(function(n){n[n.ExcludeBuffers=1]="ExcludeBuffers",n[n.IncludeAnonymous=2]="IncludeAnonymous",n[n.IgnoreMounts=4]="IgnoreMounts",n[n.IgnoreOverlays=8]="IgnoreOverlays",n[n.EnterBracketed=16]="EnterBracketed"})(xe||(xe={}));var Pe=class n{constructor(e,t,i,s,r){if(this.type=e,this.children=t,this.positions=i,this.length=s,this.props=null,r&&r.length){this.props=Object.create(null);for(let[o,l]of r)this.props[typeof o=="number"?o:o.id]=l}}toString(){let e=Zi.get(this);if(e&&!e.overlay)return e.tree.toString();let t="";for(let i of this.children){let s=i.toString();s&&(t&&(t+=","),t+=s)}return this.type.name?(/\W/.test(this.type.name)&&!this.type.isError?JSON.stringify(this.type.name):this.type.name)+(t.length?"("+t+")":""):t}cursor(e=0){return new Rn(this.topNode,e)}cursorAt(e,t=0,i=0){let s=Kr.get(this)||this.topNode,r=new Rn(s);return r.moveTo(e,t),Kr.set(this,r._tree),r}get topNode(){return new Pt(this,0,0,null)}resolve(e,t=0){let i=An(Kr.get(this)||this.topNode,e,t,!1);return Kr.set(this,i),i}resolveInner(e,t=0){let i=An(nm.get(this)||this.topNode,e,t,!0);return nm.set(this,i),i}resolveStack(e,t=0){return _w(this,e,t)}iterate(e){let{enter:t,leave:i,from:s=0,to:r=this.length}=e,o=e.mode||0,l=(o&xe.IncludeAnonymous)>0;for(let a=this.cursor(o|xe.IncludeAnonymous);;){let f=!1;if(a.from<=r&&a.to>=s&&(!l&&a.type.isAnonymous||t(a)!==!1)){if(a.firstChild())continue;f=!0}for(;f&&i&&(l||!a.type.isAnonymous)&&i(a),!a.nextSibling();){if(!a.parent())return;f=!0}}}prop(e){return e.perNode?this.props?this.props[e.id]:void 0:this.type.prop(e)}get propValues(){let e=[];if(this.props)for(let t in this.props)e.push([+t,this.props[t]]);return e}balance(e={}){return this.children.length<=8?this:ef(Xe.none,this.children,this.positions,0,this.children.length,0,this.length,(t,i,s)=>new n(this.type,t,i,s,this.propValues),e.makeTree||((t,i,s)=>new n(Xe.none,t,i,s)))}static build(e){return yw(e)}};Pe.empty=new Pe(Xe.none,[],[],0);var Ga=class n{constructor(e,t){this.buffer=e,this.index=t}get id(){return this.buffer[this.index-4]}get start(){return this.buffer[this.index-3]}get end(){return this.buffer[this.index-2]}get size(){return this.buffer[this.index-1]}get pos(){return this.index}next(){this.index-=4}fork(){return new n(this.buffer,this.index)}},ki=class n{constructor(e,t,i){this.buffer=e,this.length=t,this.set=i}get type(){return Xe.none}toString(){let e=[];for(let t=0;t<this.buffer.length;)e.push(this.childString(t)),t=this.buffer[t+3];return e.join(",")}childString(e){let t=this.buffer[e],i=this.buffer[e+3],s=this.set.types[t],r=s.name;if(/\W/.test(r)&&!s.isError&&(r=JSON.stringify(r)),e+=4,i==e)return r;let o=[];for(;e<i;)o.push(this.childString(e)),e=this.buffer[e+3];return r+"("+o.join(",")+")"}findChild(e,t,i,s,r){let{buffer:o}=this,l=-1;for(let a=e;a!=t&&!(lm(r,s,o[a+1],o[a+2])&&(l=a,i>0));a=o[a+3]);return l}slice(e,t,i){let s=this.buffer,r=new Uint16Array(t-e),o=0;for(let l=e,a=0;l<t;){r[a++]=s[l++],r[a++]=s[l++]-i;let f=r[a++]=s[l++]-i;r[a++]=s[l++]-e,o=Math.max(o,f)}return new n(r,o,this.set)}};function lm(n,e,t,i){switch(n){case-2:return t<e;case-1:return i>=e&&t<e;case 0:return t<e&&i>e;case 1:return t<=e&&i>e;case 2:return i>e;case 4:return!0}}function An(n,e,t,i){for(var s;n.from==n.to||(t<1?n.from>=e:n.from>e)||(t>-1?n.to<=e:n.to<e);){let o=!i&&n instanceof Pt&&n.index<0?null:n.parent;if(!o)return n;n=o}let r=i?0:xe.IgnoreOverlays;if(i)for(let o=n,l=o.parent;l;o=l,l=o.parent)o instanceof Pt&&o.index<0&&((s=l.enter(e,t,r))===null||s===void 0?void 0:s.from)!=o.from&&(n=l);for(;;){let o=n.enter(e,t,r);if(!o)return n;n=o}}var eo=class{cursor(e=0){return new Rn(this,e)}getChild(e,t=null,i=null){let s=rm(this,e,t,i);return s.length?s[0]:null}getChildren(e,t=null,i=null){return rm(this,e,t,i)}resolve(e,t=0){return An(this,e,t,!1)}resolveInner(e,t=0){return An(this,e,t,!0)}matchContext(e){return Xa(this.parent,e)}enterUnfinishedNodesBefore(e){let t=this.childBefore(e),i=this;for(;t;){let s=t.lastChild;if(!s||s.to!=t.to)break;s.type.isError&&s.from==s.to?(i=t,t=s.prevSibling):t=s}return i}get node(){return this}get next(){return this.parent}},Pt=class n extends eo{constructor(e,t,i,s){super(),this._tree=e,this.from=t,this.index=i,this._parent=s}get type(){return this._tree.type}get name(){return this._tree.type.name}get to(){return this.from+this._tree.length}nextChild(e,t,i,s,r=0){for(let o=this;;){for(let{children:l,positions:a}=o._tree,f=t>0?l.length:-1;e!=f;e+=t){let c=l[e],u=a[e]+o.from,p;if(!(!(r&xe.EnterBracketed&&c instanceof Pe&&(p=Zi.get(c))&&!p.overlay&&p.bracketed&&i>=u&&i<=u+c.length)&&!lm(s,i,u,u+c.length))){if(c instanceof ki){if(r&xe.ExcludeBuffers)continue;let y=c.findChild(0,c.buffer.length,t,i-u,s);if(y>-1)return new es(new Ja(o,c,e,u),null,y)}else if(r&xe.IncludeAnonymous||!c.type.isAnonymous||Za(c)){let y;if(!(r&xe.IgnoreMounts)&&(y=Zi.get(c))&&!y.overlay)return new n(y.tree,u,e,o);let v=new n(c,u,e,o);return r&xe.IncludeAnonymous||!v.type.isAnonymous?v:v.nextChild(t<0?c.children.length-1:0,t,i,s,r)}}}if(r&xe.IncludeAnonymous||!o.type.isAnonymous||(o.index>=0?e=o.index+t:e=t<0?-1:o._parent._tree.children.length,o=o._parent,!o))return null}}get firstChild(){return this.nextChild(0,1,0,4)}get lastChild(){return this.nextChild(this._tree.children.length-1,-1,0,4)}childAfter(e){return this.nextChild(0,1,e,2)}childBefore(e){return this.nextChild(this._tree.children.length-1,-1,e,-2)}prop(e){return this._tree.prop(e)}enter(e,t,i=0){let s;if(!(i&xe.IgnoreOverlays)&&(s=Zi.get(this._tree))&&s.overlay){let r=e-this.from,o=i&xe.EnterBracketed&&s.bracketed;for(let{from:l,to:a}of s.overlay)if((t>0||o?l<=r:l<r)&&(t<0||o?a>=r:a>r))return new n(s.tree,s.overlay[0].from+this.from,-1,this)}return this.nextChild(0,1,e,t,i)}nextSignificantParent(){let e=this;for(;e.type.isAnonymous&&e._parent;)e=e._parent;return e}get parent(){return this._parent?this._parent.nextSignificantParent():null}get nextSibling(){return this._parent&&this.index>=0?this._parent.nextChild(this.index+1,1,0,4):null}get prevSibling(){return this._parent&&this.index>=0?this._parent.nextChild(this.index-1,-1,0,4):null}get tree(){return this._tree}toTree(){return this._tree}toString(){return this._tree.toString()}};function rm(n,e,t,i){let s=n.cursor(),r=[];if(!s.firstChild())return r;if(t!=null){for(let o=!1;!o;)if(o=s.type.is(t),!s.nextSibling())return r}for(;;){if(i!=null&&s.type.is(i))return r;if(s.type.is(e)&&r.push(s.node),!s.nextSibling())return i==null?r:[]}}function Xa(n,e,t=e.length-1){for(let i=n;t>=0;i=i.parent){if(!i)return!1;if(!i.type.isAnonymous){if(e[t]&&e[t]!=i.name)return!1;t--}}return!0}var Ja=class{constructor(e,t,i,s){this.parent=e,this.buffer=t,this.index=i,this.start=s}},es=class n extends eo{get name(){return this.type.name}get from(){return this.context.start+this.context.buffer.buffer[this.index+1]}get to(){return this.context.start+this.context.buffer.buffer[this.index+2]}constructor(e,t,i){super(),this.context=e,this._parent=t,this.index=i,this.type=e.buffer.set.types[e.buffer.buffer[i]]}child(e,t,i){let{buffer:s}=this.context,r=s.findChild(this.index+4,s.buffer[this.index+3],e,t-this.context.start,i);return r<0?null:new n(this.context,this,r)}get firstChild(){return this.child(1,0,4)}get lastChild(){return this.child(-1,0,4)}childAfter(e){return this.child(1,e,2)}childBefore(e){return this.child(-1,e,-2)}prop(e){return this.type.prop(e)}enter(e,t,i=0){if(i&xe.ExcludeBuffers)return null;let{buffer:s}=this.context,r=s.findChild(this.index+4,s.buffer[this.index+3],t>0?1:-1,e-this.context.start,t);return r<0?null:new n(this.context,this,r)}get parent(){return this._parent||this.context.parent.nextSignificantParent()}externalSibling(e){return this._parent?null:this.context.parent.nextChild(this.context.index+e,e,0,4)}get nextSibling(){let{buffer:e}=this.context,t=e.buffer[this.index+3];return t<(this._parent?e.buffer[this._parent.index+3]:e.buffer.length)?new n(this.context,this._parent,t):this.externalSibling(1)}get prevSibling(){let{buffer:e}=this.context,t=this._parent?this._parent.index+4:0;return this.index==t?this.externalSibling(-1):new n(this.context,this._parent,e.findChild(t,this.index,-1,0,4))}get tree(){return null}toTree(){let e=[],t=[],{buffer:i}=this.context,s=this.index+4,r=i.buffer[this.index+3];if(r>s){let o=i.buffer[this.index+1];e.push(i.slice(s,r,o)),t.push(0)}return new Pe(this.type,e,t,this.to-this.from)}toString(){return this.context.buffer.childString(this.index)}};function am(n){if(!n.length)return null;let e=0,t=n[0];for(let r=1;r<n.length;r++){let o=n[r];(o.from>t.from||o.to<t.to)&&(t=o,e=r)}let i=t instanceof Pt&&t.index<0?null:t.parent,s=n.slice();return i?s[e]=i:s.splice(e,1),new Ya(s,t)}var Ya=class{constructor(e,t){this.heads=e,this.node=t}get next(){return am(this.heads)}};function _w(n,e,t){let i=n.resolveInner(e,t),s=null;for(let r=i instanceof Pt?i:i.context.parent;r;r=r.parent)if(r.index<0){let o=r.parent;(s||(s=[i])).push(o.resolve(e,t)),r=o}else{let o=Zi.get(r.tree);if(o&&o.overlay&&o.overlay[0].from<=e&&o.overlay[o.overlay.length-1].to>=e){let l=new Pt(o.tree,o.overlay[0].from+r.from,-1,r);(s||(s=[i])).push(An(l,e,t,!1))}}return s?am(s):i}var Rn=class{get name(){return this.type.name}constructor(e,t=0){if(this.buffer=null,this.stack=[],this.index=0,this.bufferNode=null,this.mode=t&~xe.EnterBracketed,e instanceof Pt)this.yieldNode(e);else{this._tree=e.context.parent,this.buffer=e.context;for(let i=e._parent;i;i=i._parent)this.stack.unshift(i.index);this.bufferNode=e,this.yieldBuf(e.index)}}yieldNode(e){return e?(this._tree=e,this.type=e.type,this.from=e.from,this.to=e.to,!0):!1}yieldBuf(e,t){this.index=e;let{start:i,buffer:s}=this.buffer;return this.type=t||s.set.types[s.buffer[e]],this.from=i+s.buffer[e+1],this.to=i+s.buffer[e+2],!0}yield(e){return e?e instanceof Pt?(this.buffer=null,this.yieldNode(e)):(this.buffer=e.context,this.yieldBuf(e.index,e.type)):!1}toString(){return this.buffer?this.buffer.buffer.childString(this.index):this._tree.toString()}enterChild(e,t,i){if(!this.buffer)return this.yield(this._tree.nextChild(e<0?this._tree._tree.children.length-1:0,e,t,i,this.mode));let{buffer:s}=this.buffer,r=s.findChild(this.index+4,s.buffer[this.index+3],e,t-this.buffer.start,i);return r<0?!1:(this.stack.push(this.index),this.yieldBuf(r))}firstChild(){return this.enterChild(1,0,4)}lastChild(){return this.enterChild(-1,0,4)}childAfter(e){return this.enterChild(1,e,2)}childBefore(e){return this.enterChild(-1,e,-2)}enter(e,t,i=this.mode){return this.buffer?i&xe.ExcludeBuffers?!1:this.enterChild(1,e,t):this.yield(this._tree.enter(e,t,i))}parent(){if(!this.buffer)return this.yieldNode(this.mode&xe.IncludeAnonymous?this._tree._parent:this._tree.parent);if(this.stack.length)return this.yieldBuf(this.stack.pop());let e=this.mode&xe.IncludeAnonymous?this.buffer.parent:this.buffer.parent.nextSignificantParent();return this.buffer=null,this.yieldNode(e)}sibling(e){if(!this.buffer)return this._tree._parent?this.yield(this._tree.index<0?null:this._tree._parent.nextChild(this._tree.index+e,e,0,4,this.mode)):!1;let{buffer:t}=this.buffer,i=this.stack.length-1;if(e<0){let s=i<0?0:this.stack[i]+4;if(this.index!=s)return this.yieldBuf(t.findChild(s,this.index,-1,0,4))}else{let s=t.buffer[this.index+3];if(s<(i<0?t.buffer.length:t.buffer[this.stack[i]+3]))return this.yieldBuf(s)}return i<0?this.yield(this.buffer.parent.nextChild(this.buffer.index+e,e,0,4,this.mode)):!1}nextSibling(){return this.sibling(1)}prevSibling(){return this.sibling(-1)}atLastNode(e){let t,i,{buffer:s}=this;if(s){if(e>0){if(this.index<s.buffer.buffer.length)return!1}else for(let r=0;r<this.index;r++)if(s.buffer.buffer[r+3]<this.index)return!1;({index:t,parent:i}=s)}else({index:t,_parent:i}=this._tree);for(;i;{index:t,_parent:i}=i)if(t>-1)for(let r=t+e,o=e<0?-1:i._tree.children.length;r!=o;r+=e){let l=i._tree.children[r];if(this.mode&xe.IncludeAnonymous||l instanceof ki||!l.type.isAnonymous||Za(l))return!1}return!0}move(e,t){if(t&&this.enterChild(e,0,4))return!0;for(;;){if(this.sibling(e))return!0;if(this.atLastNode(e)||!this.parent())return!1}}next(e=!0){return this.move(1,e)}prev(e=!0){return this.move(-1,e)}moveTo(e,t=0){for(;(this.from==this.to||(t<1?this.from>=e:this.from>e)||(t>-1?this.to<=e:this.to<e))&&this.parent(););for(;this.enterChild(1,e,t););return this}get node(){if(!this.buffer)return this._tree;let e=this.bufferNode,t=null,i=0;if(e&&e.context==this.buffer)e:for(let s=this.index,r=this.stack.length;r>=0;){for(let o=e;o;o=o._parent)if(o.index==s){if(s==this.index)return o;t=o,i=r+1;break e}s=this.stack[--r]}for(let s=i;s<this.stack.length;s++)t=new es(this.buffer,t,this.stack[s]);return this.bufferNode=new es(this.buffer,t,this.index)}get tree(){return this.buffer?null:this._tree._tree}iterate(e,t){for(let i=0;;){let s=!1;if(this.type.isAnonymous||e(this)!==!1){if(this.firstChild()){i++;continue}this.type.isAnonymous||(s=!0)}for(;;){if(s&&t&&t(this),s=this.type.isAnonymous,!i)return;if(this.nextSibling())break;this.parent(),i--,s=!0}}}matchContext(e){if(!this.buffer)return Xa(this.node.parent,e);let{buffer:t}=this.buffer,{types:i}=t.set;for(let s=e.length-1,r=this.stack.length-1;s>=0;r--){if(r<0)return Xa(this._tree,e,s);let o=i[t.buffer[this.stack[r]]];if(!o.isAnonymous){if(e[s]&&e[s]!=o.name)return!1;s--}}return!0}};function Za(n){return n.children.some(e=>e instanceof ki||!e.type.isAnonymous||Za(e))}function yw(n){var e;let{buffer:t,nodeSet:i,maxBufferLength:s=1024,reused:r=[],minRepeatType:o=i.types.length}=n,l=Array.isArray(t)?new Ga(t,t.length):t,a=i.types,f=0,c=0;function u(E,R,N,B,J,fe){let{id:Z,start:U,end:ee,size:le}=l,ye=c,We=f;if(le<0)if(l.next(),le==-1){let Rt=r[Z];N.push(Rt),B.push(U-E);return}else if(le==-3){f=Z;return}else if(le==-4){c=Z;return}else throw new RangeError(`Unrecognized record size: ${le}`);let Ye=a[Z],gt,Ne,rt=U-E;if(ee-U<=s&&(Ne=O(l.pos-R,J))){let Rt=new Uint16Array(Ne.size-Ne.skip),Ke=l.pos-Ne.size,ve=Rt.length;for(;l.pos>Ke;)ve=k(Ne.start,Rt,ve);gt=new ki(Rt,ee-Ne.start,i),rt=Ne.start-E}else{let Rt=l.pos-le;l.next();let Ke=[],ve=[],Ht=Z>=o?Z:-1,ei=0,Ni=ee;for(;l.pos>Rt;)Ht>=0&&l.id==Ht&&l.size>=0?(l.end<=Ni-s&&(v(Ke,ve,U,ei,l.end,Ni,Ht,ye,We),ei=Ke.length,Ni=l.end),l.next()):fe>2500?p(U,Rt,Ke,ve):u(U,Rt,Ke,ve,Ht,fe+1);if(Ht>=0&&ei>0&&ei<Ke.length&&v(Ke,ve,U,ei,U,Ni,Ht,ye,We),Ke.reverse(),ve.reverse(),Ht>-1&&ei>0){let De=y(Ye,We);gt=ef(Ye,Ke,ve,0,Ke.length,0,ee-U,De,De)}else gt=b(Ye,Ke,ve,ee-U,ye-ee,We)}N.push(gt),B.push(rt)}function p(E,R,N,B){let J=[],fe=0,Z=-1;for(;l.pos>R;){let{id:U,start:ee,end:le,size:ye}=l;if(ye>4)l.next();else{if(Z>-1&&ee<Z)break;Z<0&&(Z=le-s),J.push(U,ee,le),fe++,l.next()}}if(fe){let U=new Uint16Array(fe*4),ee=J[J.length-2];for(let le=J.length-3,ye=0;le>=0;le-=3)U[ye++]=J[le],U[ye++]=J[le+1]-ee,U[ye++]=J[le+2]-ee,U[ye++]=ye;N.push(new ki(U,J[2]-ee,i)),B.push(ee-E)}}function y(E,R){return(N,B,J)=>{let fe=0,Z=N.length-1,U,ee;if(Z>=0&&(U=N[Z])instanceof Pe){if(!Z&&U.type==E&&U.length==J)return U;(ee=U.prop(ie.lookAhead))&&(fe=B[Z]+U.length+ee)}return b(E,N,B,J,fe,R)}}function v(E,R,N,B,J,fe,Z,U,ee){let le=[],ye=[];for(;E.length>B;)le.push(E.pop()),ye.push(R.pop()+N-J);E.push(b(i.types[Z],le,ye,fe-J,U-fe,ee)),R.push(J-N)}function b(E,R,N,B,J,fe,Z){if(fe){let U=[ie.contextHash,fe];Z=Z?[U].concat(Z):[U]}if(J>25){let U=[ie.lookAhead,J];Z=Z?[U].concat(Z):[U]}return new Pe(E,R,N,B,Z)}function O(E,R){let N=l.fork(),B=0,J=0,fe=0,Z=N.end-s,U={size:0,start:0,skip:0};e:for(let ee=N.pos-E;N.pos>ee;){let le=N.size;if(N.id==R&&le>=0){U.size=B,U.start=J,U.skip=fe,fe+=4,B+=4,N.next();continue}let ye=N.pos-le;if(le<0||ye<ee||N.start<Z)break;let We=N.id>=o?4:0,Ye=N.start;for(N.next();N.pos>ye;){if(N.size<0)if(N.size==-3||N.size==-4)We+=4;else break e;else N.id>=o&&(We+=4);N.next()}J=Ye,B+=le,fe+=We}return(R<0||B==E)&&(U.size=B,U.start=J,U.skip=fe),U.size>4?U:void 0}function k(E,R,N){let{id:B,start:J,end:fe,size:Z}=l;if(l.next(),Z>=0&&B<o){let U=N;if(Z>4){let ee=l.pos-(Z-4);for(;l.pos>ee;)N=k(E,R,N)}R[--N]=U,R[--N]=fe-E,R[--N]=J-E,R[--N]=B}else Z==-3?f=B:Z==-4&&(c=B);return N}let T=[],P=[];for(;l.pos>0;)u(n.start||0,n.bufferStart||0,T,P,-1,0);let I=(e=n.length)!==null&&e!==void 0?e:T.length?P[0]+T[0].length:0;return new Pe(a[n.topID],T.reverse(),P.reverse(),I)}var om=new WeakMap;function Zr(n,e){if(!n.isAnonymous||e instanceof ki||e.type!=n)return 1;let t=om.get(e);if(t==null){t=1;for(let i of e.children){if(i.type!=n||!(i instanceof Pe)){t=1;break}t+=Zr(n,i)}om.set(e,t)}return t}function ef(n,e,t,i,s,r,o,l,a){let f=0;for(let v=i;v<s;v++)f+=Zr(n,e[v]);let c=Math.ceil(f*1.5/8),u=[],p=[];function y(v,b,O,k,T){for(let P=O;P<k;){let I=P,E=b[P],R=Zr(n,v[P]);for(P++;P<k;P++){let N=Zr(n,v[P]);if(R+N>=c)break;R+=N}if(P==I+1){if(R>c){let N=v[I];y(N.children,N.positions,0,N.children.length,b[I]+T);continue}u.push(v[I])}else{let N=b[P-1]+v[P-1].length-E;u.push(ef(n,v,b,I,P,E,N,null,a))}p.push(E+T-r)}}return y(e,t,i,s,0),(l||a)(u,p,o)}var to=class{constructor(){this.map=new WeakMap}setBuffer(e,t,i){let s=this.map.get(e);s||this.map.set(e,s=new Map),s.set(t,i)}getBuffer(e,t){let i=this.map.get(e);return i&&i.get(t)}set(e,t){e instanceof es?this.setBuffer(e.context.buffer,e.index,t):e instanceof Pt&&this.map.set(e.tree,t)}get(e){return e instanceof es?this.getBuffer(e.context.buffer,e.index):e instanceof Pt?this.map.get(e.tree):void 0}cursorSet(e,t){e.buffer?this.setBuffer(e.buffer.buffer,e.index,t):this.map.set(e.tree,t)}cursorGet(e){return e.buffer?this.getBuffer(e.buffer.buffer,e.index):this.map.get(e.tree)}},ts=class n{constructor(e,t,i,s,r=!1,o=!1){this.from=e,this.to=t,this.tree=i,this.offset=s,this.open=(r?1:0)|(o?2:0)}get openStart(){return(this.open&1)>0}get openEnd(){return(this.open&2)>0}static addTree(e,t=[],i=!1){let s=[new n(0,e.length,e,0,!1,i)];for(let r of t)r.to>e.length&&s.push(r);return s}static applyChanges(e,t,i=128){if(!t.length)return e;let s=[],r=1,o=e.length?e[0]:null;for(let l=0,a=0,f=0;;l++){let c=l<t.length?t[l]:null,u=c?c.fromA:1e9;if(u-a>=i)for(;o&&o.from<u;){let p=o;if(a>=p.from||u<=p.to||f){let y=Math.max(p.from,a)-f,v=Math.min(p.to,u)-f;p=y>=v?null:new n(y,v,p.tree,p.offset+f,l>0,!!c)}if(p&&s.push(p),o.to>u)break;o=r<e.length?e[r++]:null}if(!c)break;a=c.toA,f=c.toA-c.toB}return s}},Fs=class{startParse(e,t,i){return typeof e=="string"&&(e=new Ka(e)),i=i?i.length?i.map(s=>new Cn(s.from,s.to)):[new Cn(0,0)]:[new Cn(0,e.length)],this.createParse(e,t||[],i)}parse(e,t,i){let s=this.startParse(e,t,i);for(;;){let r=s.advance();if(r)return r}}},Ka=class{constructor(e){this.string=e}get length(){return this.string.length}chunk(e){return this.string.slice(e)}get lineChunks(){return!1}read(e,t){return this.string.slice(e,t)}};var BC=new ie({perNode:!0});var bw=0,Bt=class n{constructor(e,t,i,s){this.name=e,this.set=t,this.base=i,this.modified=s,this.id=bw++}toString(){let{name:e}=this;for(let t of this.modified)t.name&&(e=`${t.name}(${e})`);return e}static define(e,t){let i=typeof e=="string"?e:"?";if(e instanceof n&&(t=e),t!=null&&t.base)throw new Error("Can not derive from a modified tag");let s=new n(i,[],null,[]);if(s.set.push(s),t)for(let r of t.set)s.set.push(r);return s}static defineModifier(e){let t=new ro(e);return i=>i.modified.indexOf(t)>-1?i:ro.get(i.base||i,i.modified.concat(t).sort((s,r)=>s.id-r.id))}},vw=0,ro=class n{constructor(e){this.name=e,this.instances=[],this.id=vw++}static get(e,t){if(!t.length)return e;let i=t[0].instances.find(l=>l.base==e&&Ow(t,l.modified));if(i)return i;let s=[],r=new Bt(e.name,s,e,t);for(let l of t)l.instances.push(r);let o=ww(t);for(let l of e.set)if(!l.modified.length)for(let a of o)s.push(n.get(l,a));return r}};function Ow(n,e){return n.length==e.length&&n.every((t,i)=>t==e[i])}function ww(n){let e=[[]];for(let t=0;t<n.length;t++)for(let i=0,s=e.length;i<s;i++)e.push(e[i].concat(n[t]));return e.sort((t,i)=>i.length-t.length)}function oo(n){let e=Object.create(null);for(let t in n){let i=n[t];Array.isArray(i)||(i=[i]);for(let s of t.split(" "))if(s){let r=[],o=2,l=s;for(let u=0;;){if(l=="..."&&u>0&&u+3==s.length){o=1;break}let p=/^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(l);if(!p)throw new RangeError("Invalid path: "+s);if(r.push(p[0]=="*"?"":p[0][0]=='"'?JSON.parse(p[0]):p[0]),u+=p[0].length,u==s.length)break;let y=s[u++];if(u==s.length&&y=="!"){o=0;break}if(y!="/")throw new RangeError("Invalid path: "+s);l=s.slice(u)}let a=r.length-1,f=r[a];if(!f)throw new RangeError("Invalid path: "+s);let c=new ss(i,o,a>0?r.slice(0,a):null);e[f]=c.sort(e[f])}}return cm.add(e)}var cm=new ie({combine(n,e){let t,i,s;for(;n||e;){if(!n||e&&n.depth<=e.depth?(s=e,e=e.next):(s=n,n=n.next),t&&t.mode==s.mode&&!s.context&&!t.context)continue;let r=new ss(s.tags,s.mode,s.context);t?t.next=r:i=r,t=r}return i}}),ss=class{constructor(e,t,i,s){this.tags=e,this.mode=t,this.context=i,this.next=s}get opaque(){return this.mode==0}get inherit(){return this.mode==1}sort(e){return!e||e.depth<this.depth?(this.next=e,this):(e.next=this.sort(e.next),e)}get depth(){return this.context?this.context.length:0}};ss.empty=new ss([],2,null);function rf(n,e){let t=Object.create(null);for(let r of n)if(!Array.isArray(r.tag))t[r.tag.id]=r.class;else for(let o of r.tag)t[o.id]=r.class;let{scope:i,all:s=null}=e||{};return{style:r=>{let o=s;for(let l of r)for(let a of l.set){let f=t[a.id];if(f){o=o?o+" "+f:f;break}}return o},scope:i}}function kw(n,e){let t=null;for(let i of n){let s=i.style(e);s&&(t=t?t+" "+s:s)}return t}function dm(n,e,t,i=0,s=n.length){let r=new sf(i,Array.isArray(e)?e:[e],t);r.highlightRange(n.cursor(),i,s,"",r.highlighters),r.flush(s)}var sf=class{constructor(e,t,i){this.at=e,this.highlighters=t,this.span=i,this.class=""}startSpan(e,t){t!=this.class&&(this.flush(e),e>this.at&&(this.at=e),this.class=t)}flush(e){e>this.at&&this.class&&this.span(this.at,e,this.class)}highlightRange(e,t,i,s,r){let{type:o,from:l,to:a}=e;if(l>=i||a<=t)return;o.isTop&&(r=this.highlighters.filter(y=>!y.scope||y.scope(o)));let f=s,c=xw(e)||ss.empty,u=kw(r,c.tags);if(u&&(f&&(f+=" "),f+=u,c.mode==1&&(s+=(s?" ":"")+u)),this.startSpan(Math.max(t,l),f),c.opaque)return;let p=e.tree&&e.tree.prop(ie.mounted);if(p&&p.overlay){let y=e.node.enter(p.overlay[0].from+l,1),v=this.highlighters.filter(O=>!O.scope||O.scope(p.tree.type)),b=e.firstChild();for(let O=0,k=l;;O++){let T=O<p.overlay.length?p.overlay[O]:null,P=T?T.from+l:a,I=Math.max(t,k),E=Math.min(i,P);if(I<E&&b)for(;e.from<E&&(this.highlightRange(e,I,E,s,r),this.startSpan(Math.min(E,e.to),f),!(e.to>=P||!e.nextSibling())););if(!T||P>i)break;k=T.to+l,k>t&&(this.highlightRange(y.cursor(),Math.max(t,T.from+l),Math.min(i,k),"",v),this.startSpan(Math.min(i,k),f))}b&&e.parent()}else if(e.firstChild()){p&&(s="");do if(!(e.to<=t)){if(e.from>=i)break;this.highlightRange(e,t,i,s,r),this.startSpan(Math.min(i,e.to),f)}while(e.nextSibling());e.parent()}}};function xw(n){let e=n.type.prop(cm);for(;e&&e.context&&!n.matchContext(e.context);)e=e.next;return e||null}var $=Bt.define,io=$(),xi=$(),fm=$(xi),hm=$(xi),Si=$(),so=$(Si),tf=$(Si),Zt=$(),is=$(Zt),Yt=$(),Kt=$(),nf=$(),Mn=$(nf),no=$(),A={comment:io,lineComment:$(io),blockComment:$(io),docComment:$(io),name:xi,variableName:$(xi),typeName:fm,tagName:$(fm),propertyName:hm,attributeName:$(hm),className:$(xi),labelName:$(xi),namespace:$(xi),macroName:$(xi),literal:Si,string:so,docString:$(so),character:$(so),attributeValue:$(so),number:tf,integer:$(tf),float:$(tf),bool:$(Si),regexp:$(Si),escape:$(Si),color:$(Si),url:$(Si),keyword:Yt,self:$(Yt),null:$(Yt),atom:$(Yt),unit:$(Yt),modifier:$(Yt),operatorKeyword:$(Yt),controlKeyword:$(Yt),definitionKeyword:$(Yt),moduleKeyword:$(Yt),operator:Kt,derefOperator:$(Kt),arithmeticOperator:$(Kt),logicOperator:$(Kt),bitwiseOperator:$(Kt),compareOperator:$(Kt),updateOperator:$(Kt),definitionOperator:$(Kt),typeOperator:$(Kt),controlOperator:$(Kt),punctuation:nf,separator:$(nf),bracket:Mn,angleBracket:$(Mn),squareBracket:$(Mn),paren:$(Mn),brace:$(Mn),content:Zt,heading:is,heading1:$(is),heading2:$(is),heading3:$(is),heading4:$(is),heading5:$(is),heading6:$(is),contentSeparator:$(Zt),list:$(Zt),quote:$(Zt),emphasis:$(Zt),strong:$(Zt),link:$(Zt),monospace:$(Zt),strikethrough:$(Zt),inserted:$(),deleted:$(),changed:$(),invalid:$(),meta:no,documentMeta:$(no),annotation:$(no),processingInstruction:$(no),definition:Bt.defineModifier("definition"),constant:Bt.defineModifier("constant"),function:Bt.defineModifier("function"),standard:Bt.defineModifier("standard"),local:Bt.defineModifier("local"),special:Bt.defineModifier("special")};for(let n in A){let e=A[n];e instanceof Bt&&(e.name=n)}var WC=rf([{tag:A.link,class:"tok-link"},{tag:A.heading,class:"tok-heading"},{tag:A.emphasis,class:"tok-emphasis"},{tag:A.strong,class:"tok-strong"},{tag:A.keyword,class:"tok-keyword"},{tag:A.atom,class:"tok-atom"},{tag:A.bool,class:"tok-bool"},{tag:A.url,class:"tok-url"},{tag:A.labelName,class:"tok-labelName"},{tag:A.inserted,class:"tok-inserted"},{tag:A.deleted,class:"tok-deleted"},{tag:A.literal,class:"tok-literal"},{tag:A.string,class:"tok-string"},{tag:A.number,class:"tok-number"},{tag:[A.regexp,A.escape,A.special(A.string)],class:"tok-string2"},{tag:A.variableName,class:"tok-variableName"},{tag:A.local(A.variableName),class:"tok-variableName tok-local"},{tag:A.definition(A.variableName),class:"tok-variableName tok-definition"},{tag:A.special(A.variableName),class:"tok-variableName2"},{tag:A.definition(A.propertyName),class:"tok-propertyName tok-definition"},{tag:A.typeName,class:"tok-typeName"},{tag:A.namespace,class:"tok-namespace"},{tag:A.className,class:"tok-className"},{tag:A.macroName,class:"tok-macroName"},{tag:A.propertyName,class:"tok-propertyName"},{tag:A.operator,class:"tok-operator"},{tag:A.comment,class:"tok-comment"},{tag:A.meta,class:"tok-meta"},{tag:A.invalid,class:"tok-invalid"},{tag:A.punctuation,class:"tok-punctuation"}]);var of,Ws=new ie;function Sw(n){return W.define({combine:n?e=>e.concat(n):void 0})}var Tw=new ie,ut=class{constructor(e,t,i=[],s=""){this.data=e,this.name=s,pe.prototype.hasOwnProperty("tree")||Object.defineProperty(pe.prototype,"tree",{get(){return Be(this)}}),this.parser=t,this.extension=[zs.of(this),pe.languageData.of((r,o,l)=>{let a=um(r,o,l),f=a.type.prop(Ws);if(!f)return[];let c=r.facet(f),u=a.type.prop(Tw);if(u){let p=a.resolve(o-a.from,l);for(let y of u)if(y.test(p,r)){let v=r.facet(y.facet);return y.type=="replace"?v:v.concat(c)}}return c})].concat(i)}isActiveAt(e,t,i=-1){return um(e,t,i).type.prop(Ws)==this.data}findRegions(e){let t=e.facet(zs);if((t==null?void 0:t.data)==this.data)return[{from:0,to:e.doc.length}];if(!t||!t.allowsNesting)return[];let i=[],s=(r,o)=>{if(r.prop(Ws)==this.data){i.push({from:o,to:o+r.length});return}let l=r.prop(ie.mounted);if(l){if(l.tree.prop(Ws)==this.data){if(l.overlay)for(let a of l.overlay)i.push({from:a.from+o,to:a.to+o});else i.push({from:o,to:o+r.length});return}else if(l.overlay){let a=i.length;if(s(l.tree,l.overlay[0].from+o),i.length>a)return}}for(let a=0;a<r.children.length;a++){let f=r.children[a];f instanceof Pe&&s(f,r.positions[a]+o)}};return s(Be(e),0),i}get allowsNesting(){return!0}};ut.setState=ne.define();function um(n,e,t){let i=n.facet(zs),s=Be(n).topNode;if(!i||i.allowsNesting)for(let r=s;r;r=r.enter(e,t,xe.ExcludeBuffers|xe.EnterBracketed))r.type.isTop&&(s=r);return s}var lo=class n extends ut{constructor(e,t,i){super(e,t,[],i),this.parser=t}static define(e){let t=Sw(e.languageData);return new n(t,e.parser.configure({props:[Ws.add(i=>i.isTop?t:void 0)]}),e.name)}configure(e,t){return new n(this.data,this.parser.configure(e),t||this.name)}get allowsNesting(){return this.parser.hasWrappers()}};function Be(n){let e=n.field(ut.state,!1);return e?e.tree:Pe.empty}var hf=class{constructor(e){this.doc=e,this.cursorPos=0,this.string="",this.cursor=e.iter()}get length(){return this.doc.length}syncTo(e){return this.string=this.cursor.next(e-this.cursorPos).value,this.cursorPos=e+this.string.length,this.cursorPos-this.string.length}chunk(e){return this.syncTo(e),this.string}get lineChunks(){return!0}read(e,t){let i=this.cursorPos-this.string.length;return e<i||t>=this.cursorPos?this.doc.sliceString(e,t):this.string.slice(e-i,t-i)}},Nn=null,cf=class n{constructor(e,t,i=[],s,r,o,l,a){this.parser=e,this.state=t,this.fragments=i,this.tree=s,this.treeLen=r,this.viewport=o,this.skipped=l,this.scheduleOn=a,this.parse=null,this.tempSkipped=[]}static create(e,t,i){return new n(e,t,[],Pe.empty,0,i,[],null)}startParse(){return this.parser.startParse(new hf(this.state.doc),this.fragments)}work(e,t){return t!=null&&t>=this.state.doc.length&&(t=void 0),this.tree!=Pe.empty&&this.isDone(t??this.state.doc.length)?(this.takeTree(),!0):this.withContext(()=>{var i;if(typeof e=="number"){let s=Date.now()+e;e=()=>Date.now()>s}for(this.parse||(this.parse=this.startParse()),t!=null&&(this.parse.stoppedAt==null||this.parse.stoppedAt>t)&&t<this.state.doc.length&&this.parse.stopAt(t);;){let s=this.parse.advance();if(s)if(this.fragments=this.withoutTempSkipped(ts.addTree(s,this.fragments,this.parse.stoppedAt!=null)),this.treeLen=(i=this.parse.stoppedAt)!==null&&i!==void 0?i:this.state.doc.length,this.tree=s,this.parse=null,this.treeLen<(t??this.state.doc.length))this.parse=this.startParse();else return!0;if(e())return!1}})}takeTree(){let e,t;this.parse&&(e=this.parse.parsedPos)>=this.treeLen&&((this.parse.stoppedAt==null||this.parse.stoppedAt>e)&&this.parse.stopAt(e),this.withContext(()=>{for(;!(t=this.parse.advance()););}),this.treeLen=e,this.tree=t,this.fragments=this.withoutTempSkipped(ts.addTree(this.tree,this.fragments,!0)),this.parse=null)}withContext(e){let t=Nn;Nn=this;try{return e()}finally{Nn=t}}withoutTempSkipped(e){for(let t;t=this.tempSkipped.pop();)e=pm(e,t.from,t.to);return e}changes(e,t){let{fragments:i,tree:s,treeLen:r,viewport:o,skipped:l}=this;if(this.takeTree(),!e.empty){let a=[];if(e.iterChangedRanges((f,c,u,p)=>a.push({fromA:f,toA:c,fromB:u,toB:p})),i=ts.applyChanges(i,a),s=Pe.empty,r=0,o={from:e.mapPos(o.from,-1),to:e.mapPos(o.to,1)},this.skipped.length){l=[];for(let f of this.skipped){let c=e.mapPos(f.from,1),u=e.mapPos(f.to,-1);c<u&&l.push({from:c,to:u})}}}return new n(this.parser,t,i,s,r,o,l,this.scheduleOn)}updateViewport(e){if(this.viewport.from==e.from&&this.viewport.to==e.to)return!1;this.viewport=e;let t=this.skipped.length;for(let i=0;i<this.skipped.length;i++){let{from:s,to:r}=this.skipped[i];s<e.to&&r>e.from&&(this.fragments=pm(this.fragments,s,r),this.skipped.splice(i--,1))}return this.skipped.length>=t?!1:(this.reset(),!0)}reset(){this.parse&&(this.takeTree(),this.parse=null)}skipUntilInView(e,t){this.skipped.push({from:e,to:t})}static getSkippingParser(e){return new class extends Fs{createParse(t,i,s){let r=s[0].from,o=s[s.length-1].to;return{parsedPos:r,advance(){let a=Nn;if(a){for(let f of s)a.tempSkipped.push(f);e&&(a.scheduleOn=a.scheduleOn?Promise.all([a.scheduleOn,e]):e)}return this.parsedPos=o,new Pe(Xe.none,[],[],o-r)},stoppedAt:null,stopAt(){}}}}}isDone(e){e=Math.min(e,this.state.doc.length);let t=this.fragments;return this.treeLen>=e&&t.length&&t[0].from==0&&t[0].to>=e}static get(){return Nn}};function pm(n,e,t){return ts.applyChanges(n,[{fromA:e,toA:t,fromB:e,toB:t}])}var Dn=class n{constructor(e){this.context=e,this.tree=e.tree}apply(e){if(!e.docChanged&&this.tree==this.context.tree)return this;let t=this.context.changes(e.changes,e.state),i=this.context.treeLen==e.startState.doc.length?void 0:Math.max(e.changes.mapPos(this.context.treeLen),t.viewport.to);return t.work(20,i)||t.takeTree(),new n(t)}static init(e){let t=Math.min(3e3,e.doc.length),i=cf.create(e.facet(zs).parser,e,{from:0,to:t});return i.work(20,t)||i.takeTree(),new n(i)}};ut.state=Qe.define({create:Dn.init,update(n,e){for(let t of e.effects)if(t.is(ut.setState))return t.value;return e.startState.facet(zs)!=e.state.facet(zs)?Dn.init(e.state):n.apply(e)}});var bm=n=>{let e=setTimeout(()=>n(),500);return()=>clearTimeout(e)};typeof requestIdleCallback<"u"&&(bm=n=>{let e=-1,t=setTimeout(()=>{e=requestIdleCallback(n,{timeout:400})},100);return()=>e<0?clearTimeout(t):cancelIdleCallback(e)});var lf=typeof navigator<"u"&&(!((of=navigator.scheduling)===null||of===void 0)&&of.isInputPending)?()=>navigator.scheduling.isInputPending():null,Pw=qe.fromClass(class{constructor(e){this.view=e,this.working=null,this.workScheduled=0,this.chunkEnd=-1,this.chunkBudget=-1,this.work=this.work.bind(this),this.scheduleWork()}update(e){let t=this.view.state.field(ut.state).context;(t.updateViewport(e.view.viewport)||this.view.viewport.to>t.treeLen)&&this.scheduleWork(),(e.docChanged||e.selectionSet)&&(this.view.hasFocus&&(this.chunkBudget+=50),this.scheduleWork()),this.checkAsyncSchedule(t)}scheduleWork(){if(this.working)return;let{state:e}=this.view,t=e.field(ut.state);(t.tree!=t.context.tree||!t.context.isDone(e.doc.length))&&(this.working=bm(this.work))}work(e){this.working=null;let t=Date.now();if(this.chunkEnd<t&&(this.chunkEnd<0||this.view.hasFocus)&&(this.chunkEnd=t+3e4,this.chunkBudget=3e3),this.chunkBudget<=0)return;let{state:i,viewport:{to:s}}=this.view,r=i.field(ut.state);if(r.tree==r.context.tree&&r.context.isDone(s+1e5))return;let o=Date.now()+Math.min(this.chunkBudget,100,e&&!lf?Math.max(25,e.timeRemaining()-5):1e9),l=r.context.treeLen<s&&i.doc.length>s+1e3,a=r.context.work(()=>lf&&lf()||Date.now()>o,s+(l?0:1e5));this.chunkBudget-=Date.now()-t,(a||this.chunkBudget<=0)&&(r.context.takeTree(),this.view.dispatch({effects:ut.setState.of(new Dn(r.context))})),this.chunkBudget>0&&!(a&&!l)&&this.scheduleWork(),this.checkAsyncSchedule(r.context)}checkAsyncSchedule(e){e.scheduleOn&&(this.workScheduled++,e.scheduleOn.then(()=>this.scheduleWork()).catch(t=>tt(this.view.state,t)).then(()=>this.workScheduled--),e.scheduleOn=null)}destroy(){this.working&&this.working()}isWorking(){return!!(this.working||this.workScheduled>0)}},{eventHandlers:{focus(){this.scheduleWork()}}}),zs=W.define({combine(n){return n.length?n[0]:null},enables:n=>[ut.state,Pw,z.contentAttributes.compute([n],e=>{let t=e.facet(n);return t&&t.name?{"data-language":t.name}:{}})]}),ao=class{constructor(e,t=[]){this.language=e,this.support=t,this.extension=[e,t]}};var Cw=W.define(),Ti=W.define({combine:n=>{if(!n.length)return"  ";let e=n[0];if(!e||/\S/.test(e)||Array.from(e).some(t=>t!=e[0]))throw new Error("Invalid indent unit: "+JSON.stringify(n[0]));return e}});function In(n){let e=n.facet(Ti);return e.charCodeAt(0)==9?n.tabSize*e.length:e.length}function Vs(n,e){let t="",i=n.tabSize,s=n.facet(Ti)[0];if(s=="	"){for(;e>=i;)t+="	",e-=i;s=" "}for(let r=0;r<e;r++)t+=s;return t}function fo(n,e){n instanceof pe&&(n=new ns(n));for(let i of n.state.facet(Cw)){let s=i(n,e);if(s!==void 0)return s}let t=Be(n.state);return t.length>=e?Ew(n,t,e):null}var ns=class{constructor(e,t={}){this.state=e,this.options=t,this.unit=In(e)}lineAt(e,t=1){let i=this.state.doc.lineAt(e),{simulateBreak:s,simulateDoubleBreak:r}=this.options;return s!=null&&s>=i.from&&s<=i.to?r&&s==e?{text:"",from:e}:(t<0?s<e:s<=e)?{text:i.text.slice(s-i.from),from:s}:{text:i.text.slice(0,s-i.from),from:i.from}:i}textAfterPos(e,t=1){if(this.options.simulateDoubleBreak&&e==this.options.simulateBreak)return"";let{text:i,from:s}=this.lineAt(e,t);return i.slice(e-s,Math.min(i.length,e+100-s))}column(e,t=1){let{text:i,from:s}=this.lineAt(e,t),r=this.countColumn(i,e-s),o=this.options.overrideIndentation?this.options.overrideIndentation(s):-1;return o>-1&&(r+=o-this.countColumn(i,i.search(/\S|$/))),r}countColumn(e,t=e.length){return Hi(e,this.state.tabSize,t)}lineIndent(e,t=1){let{text:i,from:s}=this.lineAt(e,t),r=this.options.overrideIndentation;if(r){let o=r(s);if(o>-1)return o}return this.countColumn(i,i.search(/\S|$/))}get simulatedBreak(){return this.options.simulateBreak||null}},_f=new ie;function Ew(n,e,t){let i=e.resolveStack(t),s=e.resolveInner(t,-1).resolve(t,0).enterUnfinishedNodesBefore(t);if(s!=i.node){let r=[];for(let o=s;o&&!(o.from<i.node.from||o.to>i.node.to||o.from==i.node.from&&o.type==i.node.type);o=o.parent)r.push(o);for(let o=r.length-1;o>=0;o--)i={node:r[o],next:i}}return vm(i,n,t)}function vm(n,e,t){for(let i=n;i;i=i.next){let s=Rw(i.node);if(s)return s(df.create(e,t,i))}return 0}function Aw(n){return n.pos==n.options.simulateBreak&&n.options.simulateDoubleBreak}function Rw(n){let e=n.type.prop(_f);if(e)return e;let t=n.firstChild,i;if(t&&(i=t.type.prop(ie.closedBy))){let s=n.lastChild,r=s&&i.indexOf(s.name)>-1;return o=>Om(o,!0,1,void 0,r&&!Aw(o)?s.from:void 0)}return n.parent==null?Mw:null}function Mw(){return 0}var df=class n extends ns{constructor(e,t,i){super(e.state,e.options),this.base=e,this.pos=t,this.context=i}get node(){return this.context.node}static create(e,t,i){return new n(e,t,i)}get textAfter(){return this.textAfterPos(this.pos)}get baseIndent(){return this.baseIndentFor(this.node)}baseIndentFor(e){let t=this.state.doc.lineAt(e.from);for(;;){let i=e.resolve(t.from);for(;i.parent&&i.parent.from==i.from;)i=i.parent;if(Nw(i,e))break;t=this.state.doc.lineAt(i.from)}return this.lineIndent(t.from)}continue(){return vm(this.context.next,this.base,this.pos)}};function Nw(n,e){for(let t=e;t;t=t.parent)if(n==t)return!0;return!1}function Dw(n){let e=n.node,t=e.childAfter(e.from),i=e.lastChild;if(!t)return null;let s=n.options.simulateBreak,r=n.state.doc.lineAt(t.from),o=s==null||s<=r.from?r.to:Math.min(r.to,s);for(let l=t.to;;){let a=e.childAfter(l);if(!a||a==i)return null;if(!a.type.isSkipped){if(a.from>=o)return null;let f=/^ */.exec(r.text.slice(t.to-r.from))[0].length;return{from:t.from,to:t.to+f}}l=a.to}}function ho({closing:n,align:e=!0,units:t=1}){return i=>Om(i,e,t,n)}function Om(n,e,t,i,s){let r=n.textAfter,o=r.match(/^\s*/)[0].length,l=i&&r.slice(o,o+i.length)==i||s==n.pos+o,a=e?Dw(n):null;return a?l?n.column(a.from):n.column(a.to):n.baseIndent+(l?0:n.unit*t)}var Iw=200;function wm(){return pe.transactionFilter.of(n=>{if(!n.docChanged||!n.isUserEvent("input.type")&&!n.isUserEvent("input.complete"))return n;let e=n.startState.languageDataAt("indentOnInput",n.startState.selection.main.head);if(!e.length)return n;let t=n.newDoc,{head:i}=n.newSelection.main,s=t.lineAt(i);if(i>s.from+Iw)return n;let r=t.sliceString(s.from,i);if(!e.some(f=>f.test(r)))return n;let{state:o}=n,l=-1,a=[];for(let{head:f}of o.selection.ranges){let c=o.doc.lineAt(f);if(c.from==l)continue;l=c.from;let u=fo(o,c.from);if(u==null)continue;let p=/^\s*/.exec(c.text)[0],y=Vs(o,u);p!=y&&a.push({from:c.from,to:c.from+p.length,insert:y})}return a.length?[n,{changes:a,sequential:!0}]:n})}var km=new ie;function xm(n){let e=n.firstChild,t=n.lastChild;return e&&e.to<t.from?{from:e.to,to:t.type.isError?n.to:t.from}:null}var js=class n{constructor(e,t){this.specs=e;let i;function s(l){let a=kt.newName();return(i||(i=Object.create(null)))["."+a]=l,a}let r=typeof t.all=="string"?t.all:t.all?s(t.all):void 0,o=t.scope;this.scope=o instanceof ut?l=>l.prop(Ws)==o.data:o?l=>l==o:void 0,this.style=rf(e.map(l=>({tag:l.tag,class:l.class||s(Object.assign({},l,{tag:null}))})),{all:r}).style,this.module=i?new kt(i):null,this.themeType=t.themeType}static define(e,t){return new n(e,t||{})}},uf=W.define(),Sm=W.define({combine(n){return n.length?[n[0]]:null}});function af(n){let e=n.facet(uf);return e.length?e:n.facet(Sm)}function Tm(n,e){let t=[Lw],i;return n instanceof js&&(n.module&&t.push(z.styleModule.of(n.module)),i=n.themeType),e!=null&&e.fallback?t.push(Sm.of(n)):i?t.push(uf.computeN([z.darkTheme],s=>s.facet(z.darkTheme)==(i=="dark")?[n]:[])):t.push(uf.of(n)),t}var pf=class{constructor(e){this.markCache=Object.create(null),this.tree=Be(e.state),this.decorations=this.buildDeco(e,af(e.state)),this.decoratedTo=e.viewport.to}update(e){let t=Be(e.state),i=af(e.state),s=i!=af(e.startState),{viewport:r}=e.view,o=e.changes.mapPos(this.decoratedTo,1);t.length<r.to&&!s&&t.type==this.tree.type&&o>=r.to?(this.decorations=this.decorations.map(e.changes),this.decoratedTo=o):(t!=this.tree||e.viewportChanged||s)&&(this.tree=t,this.decorations=this.buildDeco(e.view,i),this.decoratedTo=r.to)}buildDeco(e,t){if(!t||!this.tree.length)return K.none;let i=new Gt;for(let{from:s,to:r}of e.visibleRanges)dm(this.tree,t,(o,l,a)=>{i.add(o,l,this.markCache[a]||(this.markCache[a]=K.mark({class:a})))},s,r);return i.finish()}},Lw=Ot.high(qe.fromClass(pf,{decorations:n=>n.decorations})),YC=js.define([{tag:A.meta,color:"#404740"},{tag:A.link,textDecoration:"underline"},{tag:A.heading,textDecoration:"underline",fontWeight:"bold"},{tag:A.emphasis,fontStyle:"italic"},{tag:A.strong,fontWeight:"bold"},{tag:A.strikethrough,textDecoration:"line-through"},{tag:A.keyword,color:"#708"},{tag:[A.atom,A.bool,A.url,A.contentSeparator,A.labelName],color:"#219"},{tag:[A.literal,A.inserted],color:"#164"},{tag:[A.string,A.deleted],color:"#a11"},{tag:[A.regexp,A.escape,A.special(A.string)],color:"#e40"},{tag:A.definition(A.variableName),color:"#00f"},{tag:A.local(A.variableName),color:"#30a"},{tag:[A.typeName,A.namespace],color:"#085"},{tag:A.className,color:"#167"},{tag:[A.special(A.variableName),A.macroName],color:"#256"},{tag:A.definition(A.propertyName),color:"#00c"},{tag:A.comment,color:"#940"},{tag:A.invalid,color:"#f00"}]),Qw=z.baseTheme({"&.cm-focused .cm-matchingBracket":{backgroundColor:"#328c8252"},"&.cm-focused .cm-nonmatchingBracket":{backgroundColor:"#bb555544"}}),Pm=1e4,Cm="()[]{}",Em=W.define({combine(n){return wt(n,{afterCursor:!0,brackets:Cm,maxScanDistance:Pm,renderMatch:$w})}}),qw=K.mark({class:"cm-matchingBracket"}),Bw=K.mark({class:"cm-nonmatchingBracket"});function $w(n){let e=[],t=n.matched?qw:Bw;return e.push(t.range(n.start.from,n.start.to)),n.end&&e.push(t.range(n.end.from,n.end.to)),e}function mm(n){let e=[],t=n.facet(Em);for(let i of n.selection.ranges){if(!i.empty)continue;let s=$t(n,i.head,-1,t)||i.head>0&&$t(n,i.head-1,1,t)||t.afterCursor&&($t(n,i.head,1,t)||i.head<n.doc.length&&$t(n,i.head+1,-1,t));s&&(e=e.concat(t.renderMatch(s,n)))}return K.set(e,!0)}var Fw=qe.fromClass(class{constructor(n){this.paused=!1,this.decorations=mm(n.state)}update(n){(n.docChanged||n.selectionSet||this.paused)&&(n.view.composing?(this.decorations=this.decorations.map(n.changes),this.paused=!0):(this.decorations=mm(n.state),this.paused=!1))}},{decorations:n=>n.decorations}),Ww=[Fw,Qw];function Am(n={}){return[Em.of(n),Ww]}var zw=new ie;function mf(n,e,t){let i=n.prop(e<0?ie.openedBy:ie.closedBy);if(i)return i;if(n.name.length==1){let s=t.indexOf(n.name);if(s>-1&&s%2==(e<0?1:0))return[t[s+e]]}return null}function gf(n){let e=n.type.prop(zw);return e?e(n.node):n}function $t(n,e,t,i={}){let s=i.maxScanDistance||Pm,r=i.brackets||Cm,o=Be(n),l=o.resolveInner(e,t);for(let a=l;a;a=a.parent){let f=mf(a.type,t,r);if(f&&a.from<a.to){let c=gf(a);if(c&&(t>0?e>=c.from&&e<c.to:e>c.from&&e<=c.to))return jw(n,e,t,a,c,f,r)}}return Vw(n,e,t,o,l.type,s,r)}function jw(n,e,t,i,s,r,o){let l=i.parent,a={from:s.from,to:s.to},f=0,c=l==null?void 0:l.cursor();if(c&&(t<0?c.childBefore(i.from):c.childAfter(i.to)))do if(t<0?c.to<=i.from:c.from>=i.to){if(f==0&&r.indexOf(c.type.name)>-1&&c.from<c.to){let u=gf(c);return{start:a,end:u?{from:u.from,to:u.to}:void 0,matched:!0}}else if(mf(c.type,t,o))f++;else if(mf(c.type,-t,o)){if(f==0){let u=gf(c);return{start:a,end:u&&u.from<u.to?{from:u.from,to:u.to}:void 0,matched:!1}}f--}}while(t<0?c.prevSibling():c.nextSibling());return{start:a,matched:!1}}function Vw(n,e,t,i,s,r,o){if(t<0?!e:e==n.doc.length)return null;let l=t<0?n.sliceDoc(e-1,e):n.sliceDoc(e,e+1),a=o.indexOf(l);if(a<0||a%2==0!=t>0)return null;let f={from:t<0?e-1:e,to:t>0?e+1:e},c=n.doc.iterRange(e,t>0?n.doc.length:0),u=0;for(let p=0;!c.next().done&&p<=r;){let y=c.value;t<0&&(p+=y.length);let v=e+p*t;for(let b=t>0?0:y.length-1,O=t>0?y.length:-1;b!=O;b+=t){let k=o.indexOf(y[b]);if(!(k<0||i.resolveInner(v+b,1).type!=s))if(k%2==0==t>0)u++;else{if(u==1)return{start:f,end:{from:v+b,to:v+b+1},matched:k>>1==a>>1};u--}}t>0&&(p+=y.length)}return c.done?{start:f,matched:!1}:null}var Hw=Object.create(null),gm=[Xe.none];var _m=[],ym=Object.create(null),Uw=Object.create(null);for(let[n,e]of[["variable","variableName"],["variable-2","variableName.special"],["string-2","string.special"],["def","variableName.definition"],["tag","tagName"],["attribute","attributeName"],["type","typeName"],["builtin","variableName.standard"],["qualifier","modifier"],["error","invalid"],["header","heading"],["property","propertyName"]])Uw[n]=Gw(Hw,e);function ff(n,e){_m.indexOf(n)>-1||(_m.push(n),console.warn(e))}function Gw(n,e){let t=[];for(let l of e.split(" ")){let a=[];for(let f of l.split(".")){let c=n[f]||A[f];c?typeof c=="function"?a.length?a=a.map(c):ff(f,`Modifier ${f} used at start of tag`):a.length?ff(f,`Tag ${f} used as modifier`):a=Array.isArray(c)?c:[c]:ff(f,`Unknown highlighting tag ${f}`)}for(let f of a)t.push(f)}if(!t.length)return 0;let i=e.replace(/ /g,"_"),s=i+" "+t.map(l=>l.id),r=ym[s];if(r)return r.id;let o=ym[s]=Xe.define({id:gm.length,name:i,props:[oo({[i]:t})]});return gm.push(o),o.id}var KC={rtl:K.mark({class:"cm-iso",inclusive:!0,attributes:{dir:"rtl"},bidiIsolate:_e.RTL}),ltr:K.mark({class:"cm-iso",inclusive:!0,attributes:{dir:"ltr"},bidiIsolate:_e.LTR}),auto:K.mark({class:"cm-iso",inclusive:!0,attributes:{dir:"auto"},bidiIsolate:null})};var wf=n=>{let{state:e}=n,t=e.doc.lineAt(e.selection.main.from),i=xf(n.state,t.from);return i.line?Xw(n):i.block?Yw(n):!1};function kf(n,e){return({state:t,dispatch:i})=>{if(t.readOnly)return!1;let s=n(e,t);return s?(i(t.update(s)),!0):!1}}var Xw=kf(ek,0);var Jw=kf(Bm,0);var Yw=kf((n,e)=>Bm(n,e,Zw(e)),0);function xf(n,e){let t=n.languageDataAt("commentTokens",e,1);return t.length?t[0]:{}}var Ln=50;function Kw(n,{open:e,close:t},i,s){let r=n.sliceDoc(i-Ln,i),o=n.sliceDoc(s,s+Ln),l=/\s*$/.exec(r)[0].length,a=/^\s*/.exec(o)[0].length,f=r.length-l;if(r.slice(f-e.length,f)==e&&o.slice(a,a+t.length)==t)return{open:{pos:i-l,margin:l&&1},close:{pos:s+a,margin:a&&1}};let c,u;s-i<=2*Ln?c=u=n.sliceDoc(i,s):(c=n.sliceDoc(i,i+Ln),u=n.sliceDoc(s-Ln,s));let p=/^\s*/.exec(c)[0].length,y=/\s*$/.exec(u)[0].length,v=u.length-y-t.length;return c.slice(p,p+e.length)==e&&u.slice(v,v+t.length)==t?{open:{pos:i+p+e.length,margin:/\s/.test(c.charAt(p+e.length))?1:0},close:{pos:s-y-t.length,margin:/\s/.test(u.charAt(v-1))?1:0}}:null}function Zw(n){let e=[];for(let t of n.selection.ranges){let i=n.doc.lineAt(t.from),s=t.to<=i.to?i:n.doc.lineAt(t.to);s.from>i.from&&s.from==t.to&&(s=t.to==i.to+1?i:n.doc.lineAt(t.to-1));let r=e.length-1;r>=0&&e[r].to>i.from?e[r].to=s.to:e.push({from:i.from+/^\s*/.exec(i.text)[0].length,to:s.to})}return e}function Bm(n,e,t=e.selection.ranges){let i=t.map(r=>xf(e,r.from).block);if(!i.every(r=>r))return null;let s=t.map((r,o)=>Kw(e,i[o],r.from,r.to));if(n!=2&&!s.every(r=>r))return{changes:e.changes(t.map((r,o)=>s[o]?[]:[{from:r.from,insert:i[o].open+" "},{from:r.to,insert:" "+i[o].close}]))};if(n!=1&&s.some(r=>r)){let r=[];for(let o=0,l;o<s.length;o++)if(l=s[o]){let a=i[o],{open:f,close:c}=l;r.push({from:f.pos-a.open.length,to:f.pos+f.margin},{from:c.pos-c.margin,to:c.pos+a.close.length})}return{changes:r}}return null}function ek(n,e,t=e.selection.ranges){let i=[],s=-1;e:for(let{from:r,to:o}of t){let l=i.length,a=1e9,f;for(let c=r;c<=o;){let u=e.doc.lineAt(c);if(f==null&&(f=xf(e,u.from).line,!f))continue e;if(u.from>s&&(r==o||o>u.from)){s=u.from;let p=/^\s*/.exec(u.text)[0].length,y=p==u.length,v=u.text.slice(p,p+f.length)==f?p:-1;p<u.text.length&&p<a&&(a=p),i.push({line:u,comment:v,token:f,indent:p,empty:y,single:!1})}c=u.to+1}if(a<1e9)for(let c=l;c<i.length;c++)i[c].indent<i[c].line.text.length&&(i[c].indent=a);i.length==l+1&&(i[l].single=!0)}if(n!=2&&i.some(r=>r.comment<0&&(!r.empty||r.single))){let r=[];for(let{line:l,token:a,indent:f,empty:c,single:u}of i)(u||!c)&&r.push({from:l.from+f,insert:a+" "});let o=e.changes(r);return{changes:o,selection:e.selection.map(o,1)}}else if(n!=1&&i.some(r=>r.comment>=0)){let r=[];for(let{line:o,comment:l,token:a}of i)if(l>=0){let f=o.from+l,c=f+a.length;o.text[c-o.from]==" "&&c++,r.push({from:f,to:c})}return{changes:r}}return null}var bf=lt.define(),tk=lt.define(),ik=W.define(),$m=W.define({combine(n){return wt(n,{minDepth:100,newGroupDelay:500,joinToEvent:(e,t)=>t},{minDepth:Math.max,newGroupDelay:Math.min,joinToEvent:(e,t)=>(i,s)=>e(i,s)||t(i,s)})}}),Fm=Qe.define({create(){return rs.empty},update(n,e){let t=e.state.facet($m),i=e.annotation(bf);if(i){let a=Ft.fromTransaction(e,i.selection),f=i.side,c=f==0?n.undone:n.done;return a?c=uo(c,c.length,t.minDepth,a):c=jm(c,e.startState.selection),new rs(f==0?i.rest:c,f==0?c:i.rest)}let s=e.annotation(tk);if((s=="full"||s=="before")&&(n=n.isolate()),e.annotation(Re.addToHistory)===!1)return e.changes.empty?n:n.addMapping(e.changes.desc);let r=Ft.fromTransaction(e),o=e.annotation(Re.time),l=e.annotation(Re.userEvent);return r?n=n.addChanges(r,o,l,t,e):e.selection&&(n=n.addSelection(e.startState.selection,o,l,t.newGroupDelay)),(s=="full"||s=="after")&&(n=n.isolate()),n},toJSON(n){return{done:n.done.map(e=>e.toJSON()),undone:n.undone.map(e=>e.toJSON())}},fromJSON(n){return new rs(n.done.map(Ft.fromJSON),n.undone.map(Ft.fromJSON))}});function Wm(n={}){return[Fm,$m.of(n),z.domEventHandlers({beforeinput(e,t){let i=e.inputType=="historyUndo"?Qn:e.inputType=="historyRedo"?Hs:null;return i?(e.preventDefault(),i(t)):!1}})]}function po(n,e){return function({state:t,dispatch:i}){if(!e&&t.readOnly)return!1;let s=t.field(Fm,!1);if(!s)return!1;let r=s.pop(n,t,e);return r?(i(r),!0):!1}}var Qn=po(0,!1),Hs=po(1,!1),sk=po(0,!0),nk=po(1,!0);var Ft=class n{constructor(e,t,i,s,r){this.changes=e,this.effects=t,this.mapped=i,this.startSelection=s,this.selectionsAfter=r}setSelAfter(e){return new n(this.changes,this.effects,this.mapped,this.startSelection,e)}toJSON(){var e,t,i;return{changes:(e=this.changes)===null||e===void 0?void 0:e.toJSON(),mapped:(t=this.mapped)===null||t===void 0?void 0:t.toJSON(),startSelection:(i=this.startSelection)===null||i===void 0?void 0:i.toJSON(),selectionsAfter:this.selectionsAfter.map(s=>s.toJSON())}}static fromJSON(e){return new n(e.changes&&Ze.fromJSON(e.changes),[],e.mapped&&si.fromJSON(e.mapped),e.startSelection&&M.fromJSON(e.startSelection),e.selectionsAfter.map(M.fromJSON))}static fromTransaction(e,t){let i=Ct;for(let s of e.startState.facet(ik)){let r=s(e);r.length&&(i=i.concat(r))}return!i.length&&e.changes.empty?null:new n(e.changes.invert(e.startState.doc),i,void 0,t||e.startState.selection,Ct)}static selection(e){return new n(void 0,Ct,void 0,void 0,e)}};function uo(n,e,t,i){let s=e+1>t+20?e-t-1:0,r=n.slice(s,e);return r.push(i),r}function rk(n,e){let t=[],i=!1;return n.iterChangedRanges((s,r)=>t.push(s,r)),e.iterChangedRanges((s,r,o,l)=>{for(let a=0;a<t.length;){let f=t[a++],c=t[a++];l>=f&&o<=c&&(i=!0)}}),i}function ok(n,e){return n.ranges.length==e.ranges.length&&n.ranges.filter((t,i)=>t.empty!=e.ranges[i].empty).length===0}function zm(n,e){return n.length?e.length?n.concat(e):n:e}var Ct=[],lk=200;function jm(n,e){if(n.length){let t=n[n.length-1],i=t.selectionsAfter.slice(Math.max(0,t.selectionsAfter.length-lk));return i.length&&i[i.length-1].eq(e)?n:(i.push(e),uo(n,n.length-1,1e9,t.setSelAfter(i)))}else return[Ft.selection([e])]}function ak(n){let e=n[n.length-1],t=n.slice();return t[n.length-1]=e.setSelAfter(e.selectionsAfter.slice(0,e.selectionsAfter.length-1)),t}function yf(n,e){if(!n.length)return n;let t=n.length,i=Ct;for(;t;){let s=fk(n[t-1],e,i);if(s.changes&&!s.changes.empty||s.effects.length){let r=n.slice(0,t);return r[t-1]=s,r}else e=s.mapped,t--,i=s.selectionsAfter}return i.length?[Ft.selection(i)]:Ct}function fk(n,e,t){let i=zm(n.selectionsAfter.length?n.selectionsAfter.map(l=>l.map(e)):Ct,t);if(!n.changes)return Ft.selection(i);let s=n.changes.map(e),r=e.mapDesc(n.changes,!0),o=n.mapped?n.mapped.composeDesc(r):r;return new Ft(s,ne.mapEffects(n.effects,e),o,n.startSelection.map(r),i)}var hk=/^(input\.type|delete)($|\.)/,rs=class n{constructor(e,t,i=0,s=void 0){this.done=e,this.undone=t,this.prevTime=i,this.prevUserEvent=s}isolate(){return this.prevTime?new n(this.done,this.undone):this}addChanges(e,t,i,s,r){let o=this.done,l=o[o.length-1];return l&&l.changes&&!l.changes.empty&&e.changes&&(!i||hk.test(i))&&(!l.selectionsAfter.length&&t-this.prevTime<s.newGroupDelay&&s.joinToEvent(r,rk(l.changes,e.changes))||i=="input.type.compose")?o=uo(o,o.length-1,s.minDepth,new Ft(e.changes.compose(l.changes),zm(ne.mapEffects(e.effects,l.changes),l.effects),l.mapped,l.startSelection,Ct)):o=uo(o,o.length,s.minDepth,e),new n(o,Ct,t,i)}addSelection(e,t,i,s){let r=this.done.length?this.done[this.done.length-1].selectionsAfter:Ct;return r.length>0&&t-this.prevTime<s&&i==this.prevUserEvent&&i&&/^select($|\.)/.test(i)&&ok(r[r.length-1],e)?this:new n(jm(this.done,e),this.undone,t,i)}addMapping(e){return new n(yf(this.done,e),yf(this.undone,e),this.prevTime,this.prevUserEvent)}pop(e,t,i){let s=e==0?this.done:this.undone;if(s.length==0)return null;let r=s[s.length-1],o=r.selectionsAfter[0]||(r.startSelection?r.startSelection.map(r.changes.invertedDesc,1):t.selection);if(i&&r.selectionsAfter.length)return t.update({selection:r.selectionsAfter[r.selectionsAfter.length-1],annotations:bf.of({side:e,rest:ak(s),selection:o}),userEvent:e==0?"select.undo":"select.redo",scrollIntoView:!0});if(r.changes){let l=s.length==1?Ct:s.slice(0,s.length-1);return r.mapped&&(l=yf(l,r.mapped)),t.update({changes:r.changes,selection:r.startSelection,effects:r.effects,annotations:bf.of({side:e,rest:l,selection:o}),filter:!1,userEvent:e==0?"undo":"redo",scrollIntoView:!0})}else return null}};rs.empty=new rs(Ct,Ct);var Vm=[{key:"Mod-z",run:Qn,preventDefault:!0},{key:"Mod-y",mac:"Mod-Shift-z",run:Hs,preventDefault:!0},{linux:"Ctrl-Shift-z",run:Hs,preventDefault:!0},{key:"Mod-u",run:sk,preventDefault:!0},{key:"Alt-u",mac:"Mod-Shift-u",run:nk,preventDefault:!0}];function Us(n,e){return M.create(n.ranges.map(e),n.mainIndex)}function Wt(n,e){return n.update({selection:e,scrollIntoView:!0,userEvent:"select"})}function zt({state:n,dispatch:e},t){let i=Us(n.selection,t);return i.eq(n.selection,!0)?!1:(e(Wt(n,i)),!0)}function mo(n,e){return M.cursor(e?n.to:n.from)}function Hm(n,e){return zt(n,t=>t.empty?n.moveByChar(t,e):mo(t,e))}function Je(n){return n.textDirectionAt(n.state.selection.main.head)==_e.LTR}var go=n=>Hm(n,!Je(n)),_o=n=>Hm(n,Je(n));function Um(n,e){return zt(n,t=>t.empty?n.moveByGroup(t,e):mo(t,e))}var ck=n=>Um(n,!Je(n)),dk=n=>Um(n,Je(n));var oE=typeof Intl<"u"&&Intl.Segmenter?new Intl.Segmenter(void 0,{granularity:"word"}):null;function uk(n,e,t){if(e.type.prop(t))return!0;let i=e.to-e.from;return i&&(i>2||/[^\s,.;:]/.test(n.sliceDoc(e.from,e.to)))||e.firstChild}function yo(n,e,t){let i=Be(n).resolveInner(e.head),s=t?ie.closedBy:ie.openedBy;for(let a=e.head;;){let f=t?i.childAfter(a):i.childBefore(a);if(!f)break;uk(n,f,s)?i=f:a=t?f.to:f.from}let r=i.type.prop(s),o,l;return r&&(o=t?$t(n,i.from,1):$t(n,i.to,-1))&&o.matched?l=t?o.end.to:o.end.from:l=t?i.to:i.from,M.cursor(l,t?-1:1)}var pk=n=>zt(n,e=>yo(n.state,e,!Je(n))),mk=n=>zt(n,e=>yo(n.state,e,Je(n)));function Gm(n,e){return zt(n,t=>{if(!t.empty)return mo(t,e);let i=n.moveVertically(t,e);return i.head!=t.head?i:n.moveToLineBoundary(t,e)})}var Xm=n=>Gm(n,!1),Jm=n=>Gm(n,!0);function Ym(n){let e=n.scrollDOM.clientHeight<n.scrollDOM.scrollHeight-2,t=0,i=0,s;if(e){for(let r of n.state.facet(z.scrollMargins)){let o=r(n);o!=null&&o.top&&(t=Math.max(o==null?void 0:o.top,t)),o!=null&&o.bottom&&(i=Math.max(o==null?void 0:o.bottom,i))}s=n.scrollDOM.clientHeight-t-i}else s=(n.dom.ownerDocument.defaultView||window).innerHeight;return{marginTop:t,marginBottom:i,selfScroll:e,height:Math.max(n.defaultLineHeight,s-5)}}function Km(n,e){let t=Ym(n),{state:i}=n,s=Us(i.selection,o=>o.empty?n.moveVertically(o,e,t.height):mo(o,e));if(s.eq(i.selection))return!1;let r;if(t.selfScroll){let o=n.coordsAtPos(i.selection.main.head),l=n.scrollDOM.getBoundingClientRect(),a=l.top+t.marginTop,f=l.bottom-t.marginBottom;o&&o.top>a&&o.bottom<f&&(r=z.scrollIntoView(s.main.head,{y:"start",yMargin:o.top-a}))}return n.dispatch(Wt(i,s),{effects:r}),!0}var Rm=n=>Km(n,!1),vf=n=>Km(n,!0);function Pi(n,e,t){let i=n.lineBlockAt(e.head),s=n.moveToLineBoundary(e,t);if(s.head==e.head&&s.head!=(t?i.to:i.from)&&(s=n.moveToLineBoundary(e,t,!1)),!t&&s.head==i.from&&i.length){let r=/^\s*/.exec(n.state.sliceDoc(i.from,Math.min(i.from+100,i.to)))[0].length;r&&e.head!=i.from+r&&(s=M.cursor(i.from+r))}return s}var gk=n=>zt(n,e=>Pi(n,e,!0)),_k=n=>zt(n,e=>Pi(n,e,!1)),yk=n=>zt(n,e=>Pi(n,e,!Je(n))),bk=n=>zt(n,e=>Pi(n,e,Je(n))),vk=n=>zt(n,e=>n.moveToLineBoundary(e,!1,!1)),Ok=n=>zt(n,e=>n.moveToLineBoundary(e,!0,!1));function wk(n,e,t){let i=!1,s=Us(n.selection,r=>{let o=$t(n,r.head,-1)||$t(n,r.head,1)||r.head>0&&$t(n,r.head-1,1)||r.head<n.doc.length&&$t(n,r.head+1,-1);if(!o||!o.end)return r;i=!0;let l=o.start.from==r.head?o.end.to:o.end.from;return t?M.range(r.anchor,l):M.cursor(l)});return i?(e(Wt(n,s)),!0):!1}var kk=({state:n,dispatch:e})=>wk(n,e,!1);function Et(n,e,t){let i=Us(n.state.selection,s=>{s.undirectional&&s.head>=s.anchor!=e&&(s=M.range(s.head,s.anchor));let r=t(s);return M.range(s.anchor,r.head,r.goalColumn,r.bidiLevel||void 0,r.assoc)});return i.eq(n.state.selection)?!1:(n.dispatch(Wt(n.state,i)),!0)}function Zm(n,e){return Et(n,e,t=>n.moveByChar(t,e))}var eg=n=>Zm(n,!Je(n)),tg=n=>Zm(n,Je(n));function ig(n,e){return Et(n,e,t=>n.moveByGroup(t,e))}var xk=n=>ig(n,!Je(n)),Sk=n=>ig(n,Je(n));var Tk=n=>{let e=!Je(n);return Et(n,e,t=>yo(n.state,t,e))},Pk=n=>{let e=Je(n);return Et(n,e,t=>yo(n.state,t,e))};function sg(n,e){return Et(n,e,t=>n.moveVertically(t,e))}var ng=n=>sg(n,!1),rg=n=>sg(n,!0);function og(n,e){return Et(n,e,t=>n.moveVertically(t,e,Ym(n).height))}var Mm=n=>og(n,!1),Nm=n=>og(n,!0),Ck=n=>Et(n,!0,e=>Pi(n,e,!0)),Ek=n=>Et(n,!1,e=>Pi(n,e,!1)),Ak=n=>{let e=!Je(n);return Et(n,e,t=>Pi(n,t,e))},Rk=n=>{let e=Je(n);return Et(n,e,t=>Pi(n,t,e))},Mk=n=>Et(n,!1,e=>M.cursor(n.lineBlockAt(e.head).from)),Nk=n=>Et(n,!0,e=>M.cursor(n.lineBlockAt(e.head).to)),Dm=({state:n,dispatch:e})=>(e(Wt(n,{anchor:0})),!0),Im=({state:n,dispatch:e})=>(e(Wt(n,{anchor:n.doc.length})),!0),Lm=({state:n,dispatch:e})=>(e(Wt(n,{anchor:n.selection.main.anchor,head:0})),!0),Qm=({state:n,dispatch:e})=>(e(Wt(n,{anchor:n.selection.main.anchor,head:n.doc.length})),!0),Dk=({state:n,dispatch:e})=>(e(n.update({selection:{anchor:0,head:n.doc.length},userEvent:"select"})),!0),Ik=({state:n,dispatch:e})=>{let t=bo(n).map(({from:i,to:s})=>M.undirectionalRange(i,Math.min(s+1,n.doc.length)));return e(n.update({selection:M.create(t),userEvent:"select"})),!0},Lk=({state:n,dispatch:e})=>{let t=Us(n.selection,i=>{let s=Be(n),r=s.resolveStack(i.from,1);if(i.empty){let o=s.resolveStack(i.from,-1);o.node.from>=r.node.from&&o.node.to<=r.node.to&&(r=o)}for(let o=r;o;o=o.next){let{node:l}=o;if((l.from<i.from&&l.to>=i.to||l.to>i.to&&l.from<=i.from)&&o.next)return M.undirectionalRange(l.from,l.to)}return i});return t.eq(n.selection)?!1:(e(Wt(n,t)),!0)};function lg(n,e){let{state:t}=n,i=t.selection,s=t.selection.ranges.slice();for(let r of t.selection.ranges){let o=t.doc.lineAt(r.head);if(e?o.to<n.state.doc.length:o.from>0)for(let l=r;;){let a=n.moveVertically(l,e);if(a.head<o.from||a.head>o.to){s.some(f=>f.head==a.head)||s.push(a);break}else{if(a.head==l.head)break;l=a}}}return s.length==i.ranges.length?!1:(n.dispatch(Wt(t,M.create(s,s.length-1))),!0)}var Qk=n=>lg(n,!1),qk=n=>lg(n,!0),Bk=({state:n,dispatch:e})=>{let t=n.selection,i=null;return t.ranges.length>1?i=M.create([t.main]):t.main.empty||(i=M.create([M.cursor(t.main.head)])),i?(e(Wt(n,i)),!0):!1};function qn(n,e){if(n.state.readOnly)return!1;let t="delete.selection",{state:i}=n,s=i.changeByRange(r=>{let{from:o,to:l}=r;if(o==l){let a=e(r);a<o?(t="delete.backward",a=co(n,a,!1)):a>o&&(t="delete.forward",a=co(n,a,!0)),o=Math.min(o,a),l=Math.max(l,a)}else o=co(n,o,!1),l=co(n,l,!0);return o==l?{range:r}:{changes:{from:o,to:l},range:M.cursor(o,o<r.head?-1:1)}});return s.changes.empty?!1:(n.dispatch(i.update(s,{scrollIntoView:!0,userEvent:t,effects:t=="delete.selection"?z.announce.of(i.phrase("Selection deleted")):void 0})),!0)}function co(n,e,t){if(n instanceof z)for(let i of n.state.facet(z.atomicRanges).map(s=>s(n)))i.between(e,e,(s,r)=>{s<e&&r>e&&(e=t?r:s)});return e}var ag=(n,e,t)=>qn(n,i=>{let s=i.from,{state:r}=n,o=r.doc.lineAt(s),l,a;if(t&&!e&&s>o.from&&s<o.from+200&&!/[^ \t]/.test(l=o.text.slice(0,s-o.from))){if(l[l.length-1]=="	")return s-1;let f=Hi(l,r.tabSize),c=f%In(r)||In(r);for(let u=0;u<c&&l[l.length-1-u]==" ";u++)s--;a=s}else a=Ee(o.text,s-o.from,e,e)+o.from,a==s&&o.number!=(e?r.doc.lines:1)?a+=e?1:-1:!e&&/[\ufe00-\ufe0f]/.test(o.text.slice(a-o.from,s-o.from))&&(a=Ee(o.text,a-o.from,!1,!1)+o.from);return a}),Of=n=>ag(n,!1,!0);var fg=n=>ag(n,!0,!1),hg=(n,e)=>qn(n,t=>{let i=t.head,{state:s}=n,r=s.doc.lineAt(i),o=s.charCategorizer(i);for(let l=null;;){if(i==(e?r.to:r.from)){i==t.head&&r.number!=(e?s.doc.lines:1)&&(i+=e?1:-1);break}let a=Ee(r.text,i-r.from,e)+r.from,f=r.text.slice(Math.min(i,a)-r.from,Math.max(i,a)-r.from),c=o(f);if(l!=null&&c!=l)break;(f!=" "||i!=t.head)&&(l=c),i=a}return i}),cg=n=>hg(n,!1),$k=n=>hg(n,!0);var Fk=n=>qn(n,e=>{let t=n.lineBlockAt(e.head).to;return e.head<t?t:Math.min(n.state.doc.length,e.head+1)});var Wk=n=>qn(n,e=>{let t=n.moveToLineBoundary(e,!1).head;return e.head>t?t:Math.max(0,e.head-1)}),zk=n=>qn(n,e=>{let t=n.moveToLineBoundary(e,!0).head;return e.head<t?t:Math.min(n.state.doc.length,e.head+1)});var jk=({state:n,dispatch:e})=>{if(n.readOnly)return!1;let t=n.changeByRange(i=>({changes:{from:i.from,to:i.to,insert:oe.of(["",""])},range:M.cursor(i.from)}));return e(n.update(t,{scrollIntoView:!0,userEvent:"input"})),!0},Vk=({state:n,dispatch:e})=>{if(n.readOnly)return!1;let t=n.changeByRange(i=>{if(!i.empty||i.from==0||i.from==n.doc.length)return{range:i};let s=i.from,r=n.doc.lineAt(s),o=s==r.from?s-1:Ee(r.text,s-r.from,!1)+r.from,l=s==r.to?s+1:Ee(r.text,s-r.from,!0)+r.from;return{changes:{from:o,to:l,insert:n.doc.slice(s,l).append(n.doc.slice(o,s))},range:M.cursor(l)}});return t.changes.empty?!1:(e(n.update(t,{scrollIntoView:!0,userEvent:"move.character"})),!0)};function bo(n){let e=[],t=-1;for(let i of n.selection.ranges){let s=n.doc.lineAt(i.from),r=n.doc.lineAt(i.to);if(!i.empty&&i.to==r.from&&(r=n.doc.lineAt(i.to-1)),t>=s.number){let o=e[e.length-1];o.to=r.to,o.ranges.push(i)}else e.push({from:s.from,to:r.to,ranges:[i]});t=r.number+1}return e}function dg(n,e,t){if(n.readOnly)return!1;let i=[],s=[];for(let r of bo(n)){if(t?r.to==n.doc.length:r.from==0)continue;let o=n.doc.lineAt(t?r.to+1:r.from-1),l=o.length+1;if(t){i.push({from:r.to,to:o.to},{from:r.from,insert:o.text+n.lineBreak});for(let a of r.ranges)s.push(M.range(Math.min(n.doc.length,a.anchor+l),Math.min(n.doc.length,a.head+l)))}else{i.push({from:o.from,to:r.from},{from:r.to,insert:n.lineBreak+o.text});for(let a of r.ranges)s.push(M.range(a.anchor-l,a.head-l))}}return i.length?(e(n.update({changes:i,scrollIntoView:!0,selection:M.create(s,n.selection.mainIndex),userEvent:"move.line"})),!0):!1}var Hk=({state:n,dispatch:e})=>dg(n,e,!1),Uk=({state:n,dispatch:e})=>dg(n,e,!0);function ug(n,e,t){if(n.readOnly)return!1;let i=[];for(let r of bo(n))t?i.push({from:r.from,insert:n.doc.slice(r.from,r.to)+n.lineBreak}):i.push({from:r.to,insert:n.lineBreak+n.doc.slice(r.from,r.to)});let s=n.changes(i);return e(n.update({changes:s,selection:n.selection.map(s,t?1:-1),scrollIntoView:!0,userEvent:"input.copyline"})),!0}var Gk=({state:n,dispatch:e})=>ug(n,e,!1),Xk=({state:n,dispatch:e})=>ug(n,e,!0),Jk=n=>{if(n.state.readOnly)return!1;let{state:e}=n,t=e.changes(bo(e).map(({from:s,to:r})=>(s>0?s--:r<e.doc.length&&r++,{from:s,to:r}))),i=Us(e.selection,s=>{let r;if(n.lineWrapping){let o=n.lineBlockAt(s.head),l=n.coordsAtPos(s.head,s.assoc||1);l&&(r=o.bottom+n.documentTop-l.bottom+n.defaultLineHeight/2)}return n.moveVertically(s,!0,r)}).map(t);return n.dispatch({changes:t,selection:i,scrollIntoView:!0,userEvent:"delete.line"}),!0};function Yk(n,e){if(/\(\)|\[\]|\{\}/.test(n.sliceDoc(e-1,e+1)))return{from:e,to:e};let t=Be(n).resolveInner(e),i=t.childBefore(e),s=t.childAfter(e),r;return i&&s&&i.to<=e&&s.from>=e&&(r=i.type.prop(ie.closedBy))&&r.indexOf(s.name)>-1&&n.doc.lineAt(i.to).from==n.doc.lineAt(s.from).from&&!/\S/.test(n.sliceDoc(i.to,s.from))?{from:i.to,to:s.from}:null}var qm=pg(!1),Kk=pg(!0);function pg(n){return({state:e,dispatch:t})=>{if(e.readOnly)return!1;let i=e.changeByRange(s=>{let{from:r,to:o}=s,l=e.doc.lineAt(r),a=!n&&r==o&&Yk(e,r);n&&(r=o=(o<=l.to?l:e.doc.lineAt(o)).to);let f=new ns(e,{simulateBreak:r,simulateDoubleBreak:!!a}),c=fo(f,r);for(c==null&&(c=Hi(/^\s*/.exec(e.doc.lineAt(r).text)[0],e.tabSize));o<l.to&&/\s/.test(l.text[o-l.from]);)o++;a?{from:r,to:o}=a:r>l.from&&r<l.from+100&&!/\S/.test(l.text.slice(0,r))&&(r=l.from);let u=["",Vs(e,c)];return a&&u.push(Vs(e,f.lineIndent(l.from,-1))),{changes:{from:r,to:o,insert:oe.of(u)},range:M.cursor(r+1+u[1].length)}});return t(e.update(i,{scrollIntoView:!0,userEvent:"input"})),!0}}function Sf(n,e){let t=-1;return n.changeByRange(i=>{let s=[];for(let o=i.from;o<=i.to;){let l=n.doc.lineAt(o);l.number>t&&(i.empty||i.to>l.from)&&(e(l,s,i),t=l.number),o=l.to+1}let r=n.changes(s);return{changes:s,range:M.range(r.mapPos(i.anchor,1),r.mapPos(i.head,1))}})}var Zk=({state:n,dispatch:e})=>{if(n.readOnly)return!1;let t=Object.create(null),i=new ns(n,{overrideIndentation:r=>{let o=t[r];return o??-1}}),s=Sf(n,(r,o,l)=>{let a=fo(i,r.from);if(a==null)return;/\S/.test(r.text)||(a=0);let f=/^\s*/.exec(r.text)[0],c=Vs(n,a);(f!=c||l.from<r.from+f.length)&&(t[r.from]=a,o.push({from:r.from,to:r.from+f.length,insert:c}))});return s.changes.empty||e(n.update(s,{userEvent:"indent"})),!0},vo=({state:n,dispatch:e})=>n.readOnly?!1:(e(n.update(Sf(n,(t,i)=>{i.push({from:t.from,insert:n.facet(Ti)})}),{userEvent:"input.indent"})),!0),Oo=({state:n,dispatch:e})=>n.readOnly?!1:(e(n.update(Sf(n,(t,i)=>{let s=/^\s*/.exec(t.text)[0];if(!s)return;let r=Hi(s,n.tabSize),o=0,l=Vs(n,Math.max(0,r-In(n)));for(;o<s.length&&o<l.length&&s.charCodeAt(o)==l.charCodeAt(o);)o++;i.push({from:t.from+o,to:t.from+s.length,insert:l.slice(o)})}),{userEvent:"delete.dedent"})),!0),ex=n=>(n.setTabFocusMode(),!0);var tx=[{key:"Ctrl-b",run:go,shift:eg,preventDefault:!0},{key:"Ctrl-f",run:_o,shift:tg},{key:"Ctrl-p",run:Xm,shift:ng},{key:"Ctrl-n",run:Jm,shift:rg},{key:"Ctrl-a",run:vk,shift:Mk},{key:"Ctrl-e",run:Ok,shift:Nk},{key:"Ctrl-d",run:fg},{key:"Ctrl-h",run:Of},{key:"Ctrl-k",run:Fk},{key:"Ctrl-Alt-h",run:cg},{key:"Ctrl-o",run:jk},{key:"Ctrl-t",run:Vk},{key:"Ctrl-v",run:vf}],ix=[{key:"ArrowLeft",run:go,shift:eg,preventDefault:!0},{key:"Mod-ArrowLeft",mac:"Alt-ArrowLeft",run:ck,shift:xk,preventDefault:!0},{mac:"Cmd-ArrowLeft",run:yk,shift:Ak,preventDefault:!0},{key:"ArrowRight",run:_o,shift:tg,preventDefault:!0},{key:"Mod-ArrowRight",mac:"Alt-ArrowRight",run:dk,shift:Sk,preventDefault:!0},{mac:"Cmd-ArrowRight",run:bk,shift:Rk,preventDefault:!0},{key:"ArrowUp",run:Xm,shift:ng,preventDefault:!0},{mac:"Cmd-ArrowUp",run:Dm,shift:Lm},{mac:"Ctrl-ArrowUp",run:Rm,shift:Mm},{key:"ArrowDown",run:Jm,shift:rg,preventDefault:!0},{mac:"Cmd-ArrowDown",run:Im,shift:Qm},{mac:"Ctrl-ArrowDown",run:vf,shift:Nm},{key:"PageUp",run:Rm,shift:Mm},{key:"PageDown",run:vf,shift:Nm},{key:"Home",run:_k,shift:Ek,preventDefault:!0},{key:"Mod-Home",run:Dm,shift:Lm},{key:"End",run:gk,shift:Ck,preventDefault:!0},{key:"Mod-End",run:Im,shift:Qm},{key:"Enter",run:qm,shift:qm},{key:"Mod-a",run:Dk},{key:"Backspace",run:Of,shift:Of,preventDefault:!0},{key:"Delete",run:fg,preventDefault:!0},{key:"Mod-Backspace",mac:"Alt-Backspace",run:cg,preventDefault:!0},{key:"Mod-Delete",mac:"Alt-Delete",run:$k,preventDefault:!0},{mac:"Mod-Backspace",run:Wk,preventDefault:!0},{mac:"Mod-Delete",run:zk,preventDefault:!0}].concat(tx.map(n=>({mac:n.key,run:n.run,shift:n.shift}))),mg=[{key:"Alt-ArrowLeft",mac:"Ctrl-ArrowLeft",run:pk,shift:Tk},{key:"Alt-ArrowRight",mac:"Ctrl-ArrowRight",run:mk,shift:Pk},{key:"Alt-ArrowUp",run:Hk},{key:"Shift-Alt-ArrowUp",run:Gk},{key:"Alt-ArrowDown",run:Uk},{key:"Shift-Alt-ArrowDown",run:Xk},{key:"Mod-Alt-ArrowUp",run:Qk},{key:"Mod-Alt-ArrowDown",run:qk},{key:"Escape",run:Bk},{key:"Mod-Enter",run:Kk},{key:"Alt-l",mac:"Ctrl-l",run:Ik},{key:"Mod-i",run:Lk,preventDefault:!0},{key:"Mod-[",run:Oo},{key:"Mod-]",run:vo},{key:"Mod-Alt-\\",run:Zk},{key:"Shift-Mod-k",run:Jk},{key:"Shift-Mod-\\",run:kk},{key:"Mod-/",run:wf},{key:"Alt-A",mac:"Ctrl-A",run:Jw},{key:"Ctrl-m",mac:"Shift-Alt-m",run:ex}].concat(ix),gg={key:"Tab",run:vo,shift:Oo};var Cf=class n{constructor(e,t,i,s,r,o,l,a,f,c=0,u){this.p=e,this.stack=t,this.state=i,this.reducePos=s,this.pos=r,this.score=o,this.buffer=l,this.bufferBase=a,this.curContext=f,this.lookAhead=c,this.parent=u}toString(){return`[${this.stack.filter((e,t)=>t%3==0).concat(this.state)}]@${this.pos}${this.score?"!"+this.score:""}`}static start(e,t,i=0){let s=e.parser.context;return new n(e,[],t,i,i,0,[],0,s?new wo(s,s.start):null,0,null)}get context(){return this.curContext?this.curContext.context:null}pushState(e,t){this.stack.push(this.state,t,this.bufferBase+this.buffer.length),this.state=e}reduce(e){var t;let i=e>>19,s=e&65535,{parser:r}=this.p,o=this.reducePos<this.pos-25&&this.setLookAhead(this.pos),l=r.dynamicPrecedence(s);if(l&&(this.score+=l),i==0){s<r.minRepeatTerm&&this.reducePos<this.pos&&(this.reducePos=this.pos),this.pushState(r.getGoto(this.state,s,!0),this.reducePos),s<r.minRepeatTerm&&this.storeNode(s,this.reducePos,this.reducePos,o?8:4,!0),this.reduceContext(s,this.reducePos);return}let a=this.stack.length-(i-1)*3-(e&262144?6:0),f=a?this.stack[a-2]:this.p.ranges[0].from;s<r.minRepeatTerm&&f==this.reducePos&&this.reducePos<this.pos&&(this.reducePos=this.pos);let c=this.reducePos-f;c>=2e3&&!(!((t=this.p.parser.nodeSet.types[s])===null||t===void 0)&&t.isAnonymous)&&(f==this.p.lastBigReductionStart?(this.p.bigReductionCount++,this.p.lastBigReductionSize=c):this.p.lastBigReductionSize<c&&(this.p.bigReductionCount=1,this.p.lastBigReductionStart=f,this.p.lastBigReductionSize=c));let u=a?this.stack[a-1]:0,p=this.bufferBase+this.buffer.length-u;if(s<r.minRepeatTerm||e&131072){let y=r.stateFlag(this.state,1)?this.pos:this.reducePos;this.storeNode(s,f,y,p+4,!0)}if(e&262144)this.state=this.stack[a];else{let y=this.stack[a-3];this.state=r.getGoto(y,s,!0)}for(;this.stack.length>a;)this.stack.pop();this.reduceContext(s,f)}storeNode(e,t,i,s=4,r=!1){if(e==0&&(!this.stack.length||this.stack[this.stack.length-1]<this.buffer.length+this.bufferBase)){let o=this.buffer.length;if(o>0&&this.buffer[o-4]==0&&this.buffer[o-1]>-1){if(t==i)return;if(this.buffer[o-2]>=t){this.buffer[o-2]=i;return}}}if(!r||this.pos==i)this.buffer.push(e,t,i,s);else{let o=this.buffer.length;if(o>0&&(this.buffer[o-4]!=0||this.buffer[o-1]<0)){let l=!1;for(let a=o;a>0&&this.buffer[a-2]>i;a-=4)if(this.buffer[a-1]>=0){l=!0;break}if(l)for(;o>0&&this.buffer[o-2]>i;)this.buffer[o]=this.buffer[o-4],this.buffer[o+1]=this.buffer[o-3],this.buffer[o+2]=this.buffer[o-2],this.buffer[o+3]=this.buffer[o-1],o-=4,s>4&&(s-=4)}this.buffer[o]=e,this.buffer[o+1]=t,this.buffer[o+2]=i,this.buffer[o+3]=s}}shift(e,t,i,s){if(e&131072)this.pushState(e&65535,this.pos);else if(e&262144)this.pos=s,this.shiftContext(t,i),t<=this.p.parser.maxNode&&this.buffer.push(t,i,s,4);else{let r=e,{parser:o}=this.p;this.pos=s;let l=o.stateFlag(r,1);!l&&(s>i||t<=o.maxNode)&&(this.reducePos=s),this.pushState(r,l?i:Math.min(i,this.reducePos)),this.shiftContext(t,i),t<=o.maxNode&&this.buffer.push(t,i,s,4)}}apply(e,t,i,s){e&65536?this.reduce(e):this.shift(e,t,i,s)}useNode(e,t){let i=this.p.reused.length-1;(i<0||this.p.reused[i]!=e)&&(this.p.reused.push(e),i++);let s=this.pos;this.reducePos=this.pos=s+e.length,this.pushState(t,s),this.buffer.push(i,s,this.reducePos,-1),this.curContext&&this.updateContext(this.curContext.tracker.reuse(this.curContext.context,e,this,this.p.stream.reset(this.pos-e.length)))}split(){let e=this,t=e.buffer.length;for(t&&e.buffer[t-4]==0&&(t-=4);t>0&&e.buffer[t-2]>e.reducePos;)t-=4;let i=e.buffer.slice(t),s=e.bufferBase+t;for(;e&&s==e.bufferBase;)e=e.parent;return new n(this.p,this.stack.slice(),this.state,this.reducePos,this.pos,this.score,i,s,this.curContext,this.lookAhead,e)}recoverByDelete(e,t){let i=e<=this.p.parser.maxNode;i&&this.storeNode(e,this.pos,t,4),this.storeNode(0,this.pos,t,i?8:4),this.pos=this.reducePos=t,this.score-=190}canShift(e){for(let t=new Ef(this);;){let i=this.p.parser.stateSlot(t.state,4)||this.p.parser.hasAction(t.state,e);if(i==0)return!1;if(!(i&65536))return!0;t.reduce(i)}}recoverByInsert(e){if(this.stack.length>=300)return[];let t=this.p.parser.nextStates(this.state);if(t.length>8||this.stack.length>=120){let s=[];for(let r=0,o;r<t.length;r+=2)(o=t[r+1])!=this.state&&this.p.parser.hasAction(o,e)&&s.push(t[r],o);if(this.stack.length<120)for(let r=0;s.length<8&&r<t.length;r+=2){let o=t[r+1];s.some((l,a)=>a&1&&l==o)||s.push(t[r],o)}t=s}let i=[];for(let s=0;s<t.length&&i.length<4;s+=2){let r=t[s+1];if(r==this.state)continue;let o=this.split();o.pushState(r,this.pos),o.storeNode(0,o.pos,o.pos,4,!0),o.shiftContext(t[s],this.pos),o.reducePos=this.pos,o.score-=200,i.push(o)}return i}forceReduce(){let{parser:e}=this.p,t=e.stateSlot(this.state,5);if(!(t&65536))return!1;if(!e.validAction(this.state,t)){let i=t>>19,s=t&65535,r=this.stack.length-i*3;if(r<0||e.getGoto(this.stack[r],s,!1)<0){let o=this.findForcedReduction();if(o==null)return!1;t=o}this.storeNode(0,this.pos,this.pos,4,!0),this.score-=100}return this.reducePos=this.pos,this.reduce(t),!0}findForcedReduction(){let{parser:e}=this.p,t=[],i=(s,r)=>{if(!t.includes(s))return t.push(s),e.allActions(s,o=>{if(!(o&393216))if(o&65536){let l=(o>>19)-r;if(l>1){let a=o&65535,f=this.stack.length-l*3;if(f>=0&&e.getGoto(this.stack[f],a,!1)>=0)return l<<19|65536|a}}else{let l=i(o,r+1);if(l!=null)return l}})};return i(this.state,0)}forceAll(){for(;!this.p.parser.stateFlag(this.state,2);)if(!this.forceReduce()){this.storeNode(0,this.pos,this.pos,4,!0);break}return this}get deadEnd(){if(this.stack.length!=3)return!1;let{parser:e}=this.p;return e.data[e.stateSlot(this.state,1)]==65535&&!e.stateSlot(this.state,4)}restart(){this.storeNode(0,this.pos,this.pos,4,!0),this.state=this.stack[0],this.stack.length=0}sameState(e){if(this.state!=e.state||this.stack.length!=e.stack.length)return!1;for(let t=0;t<this.stack.length;t+=3)if(this.stack[t]!=e.stack[t])return!1;return!0}get parser(){return this.p.parser}dialectEnabled(e){return this.p.parser.dialect.flags[e]}shiftContext(e,t){this.curContext&&this.updateContext(this.curContext.tracker.shift(this.curContext.context,e,this,this.p.stream.reset(t)))}reduceContext(e,t){this.curContext&&this.updateContext(this.curContext.tracker.reduce(this.curContext.context,e,this,this.p.stream.reset(t)))}emitContext(){let e=this.buffer.length-1;(e<0||this.buffer[e]!=-3)&&this.buffer.push(this.curContext.hash,this.pos,this.pos,-3)}emitLookAhead(){let e=this.buffer.length-1;(e<0||this.buffer[e]!=-4)&&this.buffer.push(this.lookAhead,this.pos,this.pos,-4)}updateContext(e){if(e!=this.curContext.context){let t=new wo(this.curContext.tracker,e);t.hash!=this.curContext.hash&&this.emitContext(),this.curContext=t}}setLookAhead(e){return e<=this.lookAhead?!1:(this.emitLookAhead(),this.lookAhead=e,!0)}close(){this.curContext&&this.curContext.tracker.strict&&this.emitContext(),this.lookAhead>0&&this.emitLookAhead()}},wo=class{constructor(e,t){this.tracker=e,this.context=t,this.hash=e.strict?e.hash(t):0}},Ef=class{constructor(e){this.start=e,this.state=e.state,this.stack=e.stack,this.base=this.stack.length}reduce(e){let t=e&65535,i=e>>19;i==0?(this.stack==this.start.stack&&(this.stack=this.stack.slice()),this.stack.push(this.state,0,0),this.base+=3):this.base-=(i-1)*3;let s=this.start.p.parser.getGoto(this.stack[this.base-3],t,!0);this.state=s}},Af=class n{constructor(e,t,i){this.stack=e,this.pos=t,this.index=i,this.buffer=e.buffer,this.index==0&&this.maybeNext()}static create(e,t=e.bufferBase+e.buffer.length){return new n(e,t,t-e.bufferBase)}maybeNext(){let e=this.stack.parent;e!=null&&(this.index=this.stack.bufferBase-e.bufferBase,this.stack=e,this.buffer=e.buffer)}get id(){return this.buffer[this.index-4]}get start(){return this.buffer[this.index-3]}get end(){return this.buffer[this.index-2]}get size(){return this.buffer[this.index-1]}next(){this.index-=4,this.pos-=4,this.index==0&&this.maybeNext()}fork(){return new n(this.stack,this.pos,this.index)}};function Bn(n,e=Uint16Array){if(typeof n!="string")return n;let t=null;for(let i=0,s=0;i<n.length;){let r=0;for(;;){let o=n.charCodeAt(i++),l=!1;if(o==126){r=65535;break}o>=92&&o--,o>=34&&o--;let a=o-32;if(a>=46&&(a-=46,l=!0),r+=a,l)break;r*=46}t?t[s++]=r:t=new e(r)}return t}var Gs=class{constructor(){this.start=-1,this.value=-1,this.end=-1,this.extended=-1,this.lookAhead=0,this.mask=0,this.context=0}},_g=new Gs,Rf=class{constructor(e,t){this.input=e,this.ranges=t,this.chunk="",this.chunkOff=0,this.chunk2="",this.chunk2Pos=0,this.next=-1,this.token=_g,this.rangeIndex=0,this.pos=this.chunkPos=t[0].from,this.range=t[0],this.end=t[t.length-1].to,this.readNext()}resolveOffset(e,t){let i=this.range,s=this.rangeIndex,r=this.pos+e;for(;r<i.from;){if(!s)return null;let o=this.ranges[--s];r-=i.from-o.to,i=o}for(;t<0?r>i.to:r>=i.to;){if(s==this.ranges.length-1)return null;let o=this.ranges[++s];r+=o.from-i.to,i=o}return r}clipPos(e){if(e>=this.range.from&&e<this.range.to)return e;for(let t of this.ranges)if(t.to>e)return Math.max(e,t.from);return this.end}peek(e){let t=this.chunkOff+e,i,s;if(t>=0&&t<this.chunk.length)i=this.pos+e,s=this.chunk.charCodeAt(t);else{let r=this.resolveOffset(e,1);if(r==null)return-1;if(i=r,i>=this.chunk2Pos&&i<this.chunk2Pos+this.chunk2.length)s=this.chunk2.charCodeAt(i-this.chunk2Pos);else{let o=this.rangeIndex,l=this.range;for(;l.to<=i;)l=this.ranges[++o];this.chunk2=this.input.chunk(this.chunk2Pos=i),i+this.chunk2.length>l.to&&(this.chunk2=this.chunk2.slice(0,l.to-i)),s=this.chunk2.charCodeAt(0)}}return i>=this.token.lookAhead&&(this.token.lookAhead=i+1),s}acceptToken(e,t=0){let i=t?this.resolveOffset(t,-1):this.pos;if(i==null||i<this.token.start)throw new RangeError("Token end out of bounds");this.token.value=e,this.token.end=i}acceptTokenTo(e,t){this.token.value=e,this.token.end=t}getChunk(){if(this.pos>=this.chunk2Pos&&this.pos<this.chunk2Pos+this.chunk2.length){let{chunk:e,chunkPos:t}=this;this.chunk=this.chunk2,this.chunkPos=this.chunk2Pos,this.chunk2=e,this.chunk2Pos=t,this.chunkOff=this.pos-this.chunkPos}else{this.chunk2=this.chunk,this.chunk2Pos=this.chunkPos;let e=this.input.chunk(this.pos),t=this.pos+e.length;this.chunk=t>this.range.to?e.slice(0,this.range.to-this.pos):e,this.chunkPos=this.pos,this.chunkOff=0}}readNext(){return this.chunkOff>=this.chunk.length&&(this.getChunk(),this.chunkOff==this.chunk.length)?this.next=-1:this.next=this.chunk.charCodeAt(this.chunkOff)}advance(e=1){for(this.chunkOff+=e;this.pos+e>=this.range.to;){if(this.rangeIndex==this.ranges.length-1)return this.setDone();e-=this.range.to-this.pos,this.range=this.ranges[++this.rangeIndex],this.pos=this.range.from}return this.pos+=e,this.pos>=this.token.lookAhead&&(this.token.lookAhead=this.pos+1),this.readNext()}setDone(){return this.pos=this.chunkPos=this.end,this.range=this.ranges[this.rangeIndex=this.ranges.length-1],this.chunk="",this.next=-1}reset(e,t){if(t?(this.token=t,t.start=e,t.lookAhead=e+1,t.value=t.extended=-1):this.token=_g,this.pos!=e){if(this.pos=e,e==this.end)return this.setDone(),this;for(;e<this.range.from;)this.range=this.ranges[--this.rangeIndex];for(;e>=this.range.to;)this.range=this.ranges[++this.rangeIndex];e>=this.chunkPos&&e<this.chunkPos+this.chunk.length?this.chunkOff=e-this.chunkPos:(this.chunk="",this.chunkOff=0),this.readNext()}return this}read(e,t){if(e>=this.chunkPos&&t<=this.chunkPos+this.chunk.length)return this.chunk.slice(e-this.chunkPos,t-this.chunkPos);if(e>=this.chunk2Pos&&t<=this.chunk2Pos+this.chunk2.length)return this.chunk2.slice(e-this.chunk2Pos,t-this.chunk2Pos);if(e>=this.range.from&&t<=this.range.to)return this.input.read(e,t);let i="";for(let s of this.ranges){if(s.from>=t)break;s.to>e&&(i+=this.input.read(Math.max(s.from,e),Math.min(s.to,t)))}return i}},Ci=class{constructor(e,t){this.data=e,this.id=t}token(e,t){let{parser:i}=t.p;wg(this.data,e,t,this.id,i.data,i.tokenPrecTable)}};Ci.prototype.contextual=Ci.prototype.fallback=Ci.prototype.extend=!1;var Mf=class{constructor(e,t,i){this.precTable=t,this.elseToken=i,this.data=typeof e=="string"?Bn(e):e}token(e,t){let i=e.pos,s=0;for(;;){let r=e.next<0,o=e.resolveOffset(1,1);if(wg(this.data,e,t,0,this.data,this.precTable),e.token.value>-1)break;if(this.elseToken==null)return;if(r||s++,o==null)break;e.reset(o,e.token)}s&&(e.reset(i,e.token),e.acceptToken(this.elseToken,s))}};Mf.prototype.contextual=Ci.prototype.fallback=Ci.prototype.extend=!1;var os=class{constructor(e,t={}){this.token=e,this.contextual=!!t.contextual,this.fallback=!!t.fallback,this.extend=!!t.extend}};function wg(n,e,t,i,s,r){let o=0,l=1<<i,{dialect:a}=t.p.parser;e:for(;l&n[o];){let f=n[o+1];for(let y=o+3;y<f;y+=2)if((n[y+1]&l)>0){let v=n[y];if(a.allows(v)&&(e.token.value==-1||e.token.value==v||nx(v,e.token.value,s,r))){e.acceptToken(v);break}}let c=e.next,u=0,p=n[o+2];if(e.next<0&&p>u&&n[f+p*3-3]==65535){o=n[f+p*3-1];continue e}for(;u<p;){let y=u+p>>1,v=f+y+(y<<1),b=n[v],O=n[v+1]||65536;if(c<b)p=y;else if(c>=O)u=y+1;else{o=n[v+2],e.advance();continue e}}break}}function yg(n,e,t){for(let i=e,s;(s=n[i])!=65535;i++)if(s==t)return i-e;return-1}function nx(n,e,t,i){let s=yg(t,i,e);return s<0||yg(t,i,n)<s}var pt=typeof process<"u"&&process.env&&/\bparse\b/.test(process.env.LOG),Tf=null;function bg(n,e,t){let i=n.cursor(xe.IncludeAnonymous);for(i.moveTo(e);;)if(!(t<0?i.childBefore(e):i.childAfter(e)))for(;;){if((t<0?i.to<e:i.from>e)&&!i.type.isError)return t<0?Math.max(0,Math.min(i.to-1,e-25)):Math.min(n.length,Math.max(i.from+1,e+25));if(t<0?i.prevSibling():i.nextSibling())break;if(!i.parent())return t<0?0:n.length}}var Nf=class{constructor(e,t){this.fragments=e,this.nodeSet=t,this.i=0,this.fragment=null,this.safeFrom=-1,this.safeTo=-1,this.trees=[],this.start=[],this.index=[],this.nextFragment()}nextFragment(){let e=this.fragment=this.i==this.fragments.length?null:this.fragments[this.i++];if(e){for(this.safeFrom=e.openStart?bg(e.tree,e.from+e.offset,1)-e.offset:e.from,this.safeTo=e.openEnd?bg(e.tree,e.to+e.offset,-1)-e.offset:e.to;this.trees.length;)this.trees.pop(),this.start.pop(),this.index.pop();this.trees.push(e.tree),this.start.push(-e.offset),this.index.push(0),this.nextStart=this.safeFrom}else this.nextStart=1e9}nodeAt(e){if(e<this.nextStart)return null;for(;this.fragment&&this.safeTo<=e;)this.nextFragment();if(!this.fragment)return null;for(;;){let t=this.trees.length-1;if(t<0)return this.nextFragment(),null;let i=this.trees[t],s=this.index[t];if(s==i.children.length){this.trees.pop(),this.start.pop(),this.index.pop();continue}let r=i.children[s],o=this.start[t]+i.positions[s];if(o>e)return this.nextStart=o,null;if(r instanceof Pe){if(o==e){if(o<this.safeFrom)return null;let l=o+r.length;if(l<=this.safeTo){let a=r.prop(ie.lookAhead);if(!a||l+a<this.fragment.to)return r}}this.index[t]++,o+r.length>=Math.max(this.safeFrom,e)&&(this.trees.push(r),this.start.push(o),this.index.push(0))}else this.index[t]++,this.nextStart=o+r.length}}},Df=class{constructor(e,t){this.stream=t,this.tokens=[],this.mainToken=null,this.actions=[],this.tokens=e.tokenizers.map(i=>new Gs)}getActions(e){let t=0,i=null,{parser:s}=e.p,{tokenizers:r}=s,o=s.stateSlot(e.state,3),l=e.curContext?e.curContext.hash:0,a=0;for(let f=0;f<r.length;f++){if(!(1<<f&o))continue;let c=r[f],u=this.tokens[f];if(!(i&&!c.fallback)&&((c.contextual||u.start!=e.pos||u.mask!=o||u.context!=l)&&(this.updateCachedToken(u,c,e),u.mask=o,u.context=l),u.lookAhead>u.end+25&&(a=Math.max(u.lookAhead,a)),u.value!=0)){let p=t;if(u.extended>-1&&(t=this.addActions(e,u.extended,u.end,t)),t=this.addActions(e,u.value,u.end,t),!c.extend&&(i=u,t>p))break}}for(;this.actions.length>t;)this.actions.pop();return a&&e.setLookAhead(a),!i&&e.pos==this.stream.end&&(i=new Gs,i.value=e.p.parser.eofTerm,i.start=i.end=e.pos,t=this.addActions(e,i.value,i.end,t)),this.mainToken=i,this.actions}getMainToken(e){if(this.mainToken)return this.mainToken;let t=new Gs,{pos:i,p:s}=e;return t.start=i,t.end=Math.min(i+1,s.stream.end),t.value=i==s.stream.end?s.parser.eofTerm:0,t}updateCachedToken(e,t,i){let s=this.stream.clipPos(i.pos);if(t.token(this.stream.reset(s,e),i),e.value>-1){let{parser:r}=i.p;for(let o=0;o<r.specialized.length;o++)if(r.specialized[o]==e.value){let l=r.specializers[o](this.stream.read(e.start,e.end),i);if(l>=0&&i.p.parser.dialect.allows(l>>1)){l&1?e.extended=l>>1:e.value=l>>1;break}}}else e.value=0,e.end=this.stream.clipPos(s+1)}putAction(e,t,i,s){for(let r=0;r<s;r+=3)if(this.actions[r]==e)return s;return this.actions[s++]=e,this.actions[s++]=t,this.actions[s++]=i,s}addActions(e,t,i,s){let{state:r}=e,{parser:o}=e.p,{data:l}=o;for(let a=0;a<2;a++)for(let f=o.stateSlot(r,a?2:1);;f+=3){if(l[f]==65535)if(l[f+1]==1)f=fi(l,f+2);else{s==0&&l[f+1]==2&&(s=this.putAction(fi(l,f+2),t,i,s));break}l[f]==t&&(s=this.putAction(fi(l,f+1),t,i,s))}return s}},If=class{constructor(e,t,i,s){this.parser=e,this.input=t,this.ranges=s,this.recovering=0,this.nextStackID=9812,this.minStackPos=0,this.reused=[],this.stoppedAt=null,this.lastBigReductionStart=-1,this.lastBigReductionSize=0,this.bigReductionCount=0,this.stream=new Rf(t,s),this.tokens=new Df(e,this.stream),this.topTerm=e.top[1];let{from:r}=s[0];this.stacks=[Cf.start(this,e.top[0],r)],this.fragments=i.length&&this.stream.end-r>e.bufferLength*4?new Nf(i,e.nodeSet):null}get parsedPos(){return this.minStackPos}advance(){let e=this.stacks,t=this.minStackPos,i=this.stacks=[],s,r;if(this.bigReductionCount>300&&e.length==1){let[o]=e;for(;o.forceReduce()&&o.stack.length&&o.stack[o.stack.length-2]>=this.lastBigReductionStart;);this.bigReductionCount=this.lastBigReductionSize=0}for(let o=0;o<e.length;o++){let l=e[o];for(;;){if(this.tokens.mainToken=null,l.pos>t)i.push(l);else{if(this.advanceStack(l,i,e))continue;{s||(s=[],r=[]),s.push(l);let a=this.tokens.getMainToken(l);r.push(a.value,a.end)}}break}}if(!i.length){let o=s&&rx(s);if(o)return pt&&console.log("Finish with "+this.stackID(o)),this.stackToTree(o);if(this.parser.strict)throw pt&&s&&console.log("Stuck with token "+(this.tokens.mainToken?this.parser.getName(this.tokens.mainToken.value):"none")),new SyntaxError("No parse at "+t);this.recovering||(this.recovering=5)}if(this.recovering&&s){let o=this.stoppedAt!=null&&s[0].pos>this.stoppedAt?s[0]:this.runRecovery(s,r,i);if(o)return pt&&console.log("Force-finish "+this.stackID(o)),this.stackToTree(o.forceAll())}if(this.recovering){let o=this.recovering==1?1:this.recovering*3;if(i.length>o)for(i.sort((l,a)=>a.score-l.score);i.length>o;)i.pop();i.some(l=>l.reducePos>t)&&this.recovering--}else if(i.length>1){e:for(let o=0;o<i.length-1;o++){let l=i[o];for(let a=o+1;a<i.length;a++){let f=i[a];if(l.sameState(f)||l.buffer.length>500&&f.buffer.length>500)if((l.score-f.score||l.buffer.length-f.buffer.length)>0)i.splice(a--,1);else{i.splice(o--,1);continue e}}}i.length>12&&(i.sort((o,l)=>l.score-o.score),i.splice(12,i.length-12))}this.minStackPos=i[0].pos;for(let o=1;o<i.length;o++)i[o].pos<this.minStackPos&&(this.minStackPos=i[o].pos);return null}stopAt(e){if(this.stoppedAt!=null&&this.stoppedAt<e)throw new RangeError("Can't move stoppedAt forward");this.stoppedAt=e}advanceStack(e,t,i){let s=e.pos,{parser:r}=this,o=pt?this.stackID(e)+" -> ":"";if(this.stoppedAt!=null&&s>this.stoppedAt)return e.forceReduce()?e:null;if(this.fragments){let f=e.curContext&&e.curContext.tracker.strict,c=f?e.curContext.hash:0;for(let u=this.fragments.nodeAt(s);u;){let p=this.parser.nodeSet.types[u.type.id]==u.type?r.getGoto(e.state,u.type.id):-1;if(p>-1&&u.length&&(!f||(u.prop(ie.contextHash)||0)==c))return e.useNode(u,p),pt&&console.log(o+this.stackID(e)+` (via reuse of ${r.getName(u.type.id)})`),!0;if(!(u instanceof Pe)||u.children.length==0||u.positions[0]>0)break;let y=u.children[0];if(y instanceof Pe&&u.positions[0]==0)u=y;else break}}let l=r.stateSlot(e.state,4);if(l>0)return e.reduce(l),pt&&console.log(o+this.stackID(e)+` (via always-reduce ${r.getName(l&65535)})`),!0;if(e.stack.length>=8400)for(;e.stack.length>6e3&&e.forceReduce(););let a=this.tokens.getActions(e);for(let f=0;f<a.length;){let c=a[f++],u=a[f++],p=a[f++],y=f==a.length||!i,v=y?e:e.split(),b=this.tokens.mainToken;if(v.apply(c,u,b?b.start:v.pos,p),pt&&console.log(o+this.stackID(v)+` (via ${c&65536?`reduce of ${r.getName(c&65535)}`:"shift"} for ${r.getName(u)} @ ${s}${v==e?"":", split"})`),y)return!0;v.pos>s?t.push(v):i.push(v)}return!1}advanceFully(e,t){let i=e.pos;for(;;){if(!this.advanceStack(e,null,null))return!1;if(e.pos>i)return vg(e,t),!0}}runRecovery(e,t,i){let s=null,r=!1;for(let o=0;o<e.length;o++){let l=e[o],a=t[o<<1],f=t[(o<<1)+1],c=pt?this.stackID(l)+" -> ":"";if(l.deadEnd&&(r||(r=!0,l.restart(),pt&&console.log(c+this.stackID(l)+" (restarted)"),this.advanceFully(l,i))))continue;let u=l.split(),p=c;for(let y=0;y<10&&u.forceReduce()&&(pt&&console.log(p+this.stackID(u)+" (via force-reduce)"),!this.advanceFully(u,i));y++)pt&&(p=this.stackID(u)+" -> ");for(let y of l.recoverByInsert(a))pt&&console.log(c+this.stackID(y)+" (via recover-insert)"),this.advanceFully(y,i);this.stream.end>l.pos?(f==l.pos&&(f++,a=0),l.recoverByDelete(a,f),pt&&console.log(c+this.stackID(l)+` (via recover-delete ${this.parser.getName(a)})`),vg(l,i)):(!s||s.score<u.score)&&(s=u)}return s}stackToTree(e){return e.close(),Pe.build({buffer:Af.create(e),nodeSet:this.parser.nodeSet,topID:this.topTerm,maxBufferLength:this.parser.bufferLength,reused:this.reused,start:this.ranges[0].from,length:e.pos-this.ranges[0].from,minRepeatType:this.parser.minRepeatTerm})}stackID(e){let t=(Tf||(Tf=new WeakMap)).get(e);return t||Tf.set(e,t=String.fromCodePoint(this.nextStackID++)),t+e}};function vg(n,e){for(let t=0;t<e.length;t++){let i=e[t];if(i.pos==n.pos&&i.sameState(n)){e[t].score<n.score&&(e[t]=n);return}}e.push(n)}var Lf=class{constructor(e,t,i){this.source=e,this.flags=t,this.disabled=i}allows(e){return!this.disabled||this.disabled[e]==0}},Pf=n=>n,ko=class{constructor(e){this.start=e.start,this.shift=e.shift||Pf,this.reduce=e.reduce||Pf,this.reuse=e.reuse||Pf,this.hash=e.hash||(()=>0),this.strict=e.strict!==!1}},xo=class n extends Fs{constructor(e){if(super(),this.wrappers=[],e.version!=14)throw new RangeError(`Parser version (${e.version}) doesn't match runtime version (14)`);let t=e.nodeNames.split(" ");this.minRepeatTerm=t.length;for(let l=0;l<e.repeatNodeCount;l++)t.push("");let i=Object.keys(e.topRules).map(l=>e.topRules[l][1]),s=[];for(let l=0;l<t.length;l++)s.push([]);function r(l,a,f){s[l].push([a,a.deserialize(String(f))])}if(e.nodeProps)for(let l of e.nodeProps){let a=l[0];typeof a=="string"&&(a=ie[a]);for(let f=1;f<l.length;){let c=l[f++];if(c>=0)r(c,a,l[f++]);else{let u=l[f+-c];for(let p=-c;p>0;p--)r(l[f++],a,u);f++}}}this.nodeSet=new En(t.map((l,a)=>Xe.define({name:a>=this.minRepeatTerm?void 0:l,id:a,props:s[a],top:i.indexOf(a)>-1,error:a==0,skipped:e.skippedNodes&&e.skippedNodes.indexOf(a)>-1}))),e.propSources&&(this.nodeSet=this.nodeSet.extend(...e.propSources)),this.strict=!1,this.bufferLength=1024;let o=Bn(e.tokenData);this.context=e.context,this.specializerSpecs=e.specialized||[],this.specialized=new Uint16Array(this.specializerSpecs.length);for(let l=0;l<this.specializerSpecs.length;l++)this.specialized[l]=this.specializerSpecs[l].term;this.specializers=this.specializerSpecs.map(Og),this.states=Bn(e.states,Uint32Array),this.data=Bn(e.stateData),this.goto=Bn(e.goto),this.maxTerm=e.maxTerm,this.tokenizers=e.tokenizers.map(l=>typeof l=="number"?new Ci(o,l):l),this.topRules=e.topRules,this.dialects=e.dialects||{},this.dynamicPrecedences=e.dynamicPrecedences||null,this.tokenPrecTable=e.tokenPrec,this.termNames=e.termNames||null,this.maxNode=this.nodeSet.types.length-1,this.dialect=this.parseDialect(),this.top=this.topRules[Object.keys(this.topRules)[0]]}createParse(e,t,i){let s=new If(this,e,t,i);for(let r of this.wrappers)s=r(s,e,t,i);return s}getGoto(e,t,i=!1){let s=this.goto;if(t>=s[0])return-1;for(let r=s[t+1];;){let o=s[r++],l=o&1,a=s[r++];if(l&&i)return a;for(let f=r+(o>>1);r<f;r++)if(s[r]==e)return a;if(l)return-1}}hasAction(e,t){let i=this.data;for(let s=0;s<2;s++)for(let r=this.stateSlot(e,s?2:1),o;;r+=3){if((o=i[r])==65535)if(i[r+1]==1)o=i[r=fi(i,r+2)];else{if(i[r+1]==2)return fi(i,r+2);break}if(o==t||o==0)return fi(i,r+1)}return 0}stateSlot(e,t){return this.states[e*6+t]}stateFlag(e,t){return(this.stateSlot(e,0)&t)>0}validAction(e,t){return!!this.allActions(e,i=>i==t?!0:null)}allActions(e,t){let i=this.stateSlot(e,4),s=i?t(i):void 0;for(let r=this.stateSlot(e,1);s==null;r+=3){if(this.data[r]==65535)if(this.data[r+1]==1)r=fi(this.data,r+2);else break;s=t(fi(this.data,r+1))}return s}nextStates(e){let t=[];for(let i=this.stateSlot(e,1);;i+=3){if(this.data[i]==65535)if(this.data[i+1]==1)i=fi(this.data,i+2);else break;if(!(this.data[i+2]&1)){let s=this.data[i+1];t.some((r,o)=>o&1&&r==s)||t.push(this.data[i],s)}}return t}configure(e){let t=Object.assign(Object.create(n.prototype),this);if(e.props&&(t.nodeSet=this.nodeSet.extend(...e.props)),e.top){let i=this.topRules[e.top];if(!i)throw new RangeError(`Invalid top rule name ${e.top}`);t.top=i}return e.tokenizers&&(t.tokenizers=this.tokenizers.map(i=>{let s=e.tokenizers.find(r=>r.from==i);return s?s.to:i})),e.specializers&&(t.specializers=this.specializers.slice(),t.specializerSpecs=this.specializerSpecs.map((i,s)=>{let r=e.specializers.find(l=>l.from==i.external);if(!r)return i;let o=Object.assign(Object.assign({},i),{external:r.to});return t.specializers[s]=Og(o),o})),e.contextTracker&&(t.context=e.contextTracker),e.dialect&&(t.dialect=this.parseDialect(e.dialect)),e.strict!=null&&(t.strict=e.strict),e.wrap&&(t.wrappers=t.wrappers.concat(e.wrap)),e.bufferLength!=null&&(t.bufferLength=e.bufferLength),t}hasWrappers(){return this.wrappers.length>0}getName(e){return this.termNames?this.termNames[e]:String(e<=this.maxNode&&this.nodeSet.types[e].name||e)}get eofTerm(){return this.maxNode+1}get topNode(){return this.nodeSet.types[this.top[1]]}dynamicPrecedence(e){let t=this.dynamicPrecedences;return t==null?0:t[e]||0}parseDialect(e){let t=Object.keys(this.dialects),i=t.map(()=>!1);if(e)for(let r of e.split(" ")){let o=t.indexOf(r);o>=0&&(i[o]=!0)}let s=null;for(let r=0;r<t.length;r++)if(!i[r])for(let o=this.dialects[t[r]],l;(l=this.data[o++])!=65535;)(s||(s=new Uint8Array(this.maxTerm+1)))[l]=1;return new Lf(e,i,s)}static deserialize(e){return new n(e)}};function fi(n,e){return n[e]|n[e+1]<<16}function rx(n){let e=null;for(let t of n){let i=t.p.stoppedAt;(t.pos==t.p.stream.end||i!=null&&t.pos>i)&&t.p.parser.stateFlag(t.state,2)&&(!e||e.score<t.score)&&(e=t)}return e}function Og(n){if(n.external){let e=n.extend?1:0;return(t,i)=>n.external(t,i)<<1|e}return n.get}var ox=1,Cg=194,Eg=195,lx=196,kg=197,ax=198,fx=199,hx=200,cx=2,Ag=3,xg=201,dx=24,ux=25,px=49,mx=50,gx=55,_x=56,yx=57,bx=59,vx=60,Ox=61,wx=62,kx=63,xx=65,Sx=238,Tx=71,Px=241,Cx=242,Ex=243,Ax=244,Rx=245,Mx=246,Nx=247,Dx=248,Rg=72,Ix=249,Lx=250,Qx=251,qx=252,Bx=253,$x=254,Fx=255,Wx=256,zx=73,jx=77,Vx=263,Hx=112,Ux=130,Gx=151,Xx=152,Jx=155,ls=10,$n=13,$f=32,Po=9,Ff=35,Yx=40,Kx=46,Bf=123,Sg=125,Mg=39,Ng=34,Tg=92,Zx=111,eS=120,tS=78,iS=117,sS=85,nS=new Set([ux,px,mx,Vx,xx,Ux,_x,yx,Sx,wx,kx,Rg,zx,jx,vx,Ox,Gx,Xx,Jx,Hx]);function Qf(n){return n==ls||n==$n}function qf(n){return n>=48&&n<=57||n>=65&&n<=70||n>=97&&n<=102}var rS=new os((n,e)=>{let t;if(n.next<0)n.acceptToken(fx);else if(e.context.flags&So)Qf(n.next)&&n.acceptToken(ax,1);else if(((t=n.peek(-1))<0||Qf(t))&&e.canShift(kg)){let i=0;for(;n.next==$f||n.next==Po;)n.advance(),i++;(n.next==ls||n.next==$n||n.next==Ff)&&n.acceptToken(kg,-i)}else Qf(n.next)&&n.acceptToken(lx,1)},{contextual:!0}),oS=new os((n,e)=>{let t=e.context;if(t.flags)return;let i=n.peek(-1);if(i==ls||i==$n){let s=0,r=0;for(;;){if(n.next==$f)s++;else if(n.next==Po)s+=8-s%8;else break;n.advance(),r++}s!=t.indent&&n.next!=ls&&n.next!=$n&&n.next!=Ff&&(s<t.indent?n.acceptToken(Eg,-r):n.acceptToken(Cg))}}),So=1,Dg=2,hi=4,ci=8,di=16,ui=32;function To(n,e,t){this.parent=n,this.indent=e,this.flags=t,this.hash=(n?n.hash+n.hash<<8:0)+e+(e<<4)+t+(t<<6)}var lS=new To(null,0,0);function aS(n){let e=0;for(let t=0;t<n.length;t++)e+=n.charCodeAt(t)==Po?8-e%8:1;return e}var Pg=new Map([[Px,0],[Cx,hi],[Ex,ci],[Ax,ci|hi],[Rx,di],[Mx,di|hi],[Nx,di|ci],[Dx,di|ci|hi],[Ix,ui],[Lx,ui|hi],[Qx,ui|ci],[qx,ui|ci|hi],[Bx,ui|di],[$x,ui|di|hi],[Fx,ui|di|ci],[Wx,ui|di|ci|hi]].map(([n,e])=>[n,e|Dg])),fS=new ko({start:lS,reduce(n,e,t,i){return n.flags&So&&nS.has(e)||(e==Tx||e==Rg)&&n.flags&Dg?n.parent:n},shift(n,e,t,i){return e==Cg?new To(n,aS(i.read(i.pos,t.pos)),0):e==Eg?n.parent:e==dx||e==gx||e==bx||e==Ag?new To(n,0,So):Pg.has(e)?new To(n,0,Pg.get(e)|n.flags&So):n},hash(n){return n.hash}}),hS=new os(n=>{for(let e=0;e<5;e++){if(n.next!="print".charCodeAt(e))return;n.advance()}if(!/\w/.test(String.fromCharCode(n.next)))for(let e=0;;e++){let t=n.peek(e);if(!(t==$f||t==Po)){t!=Yx&&t!=Kx&&t!=ls&&t!=$n&&t!=Ff&&n.acceptToken(ox);return}}}),cS=new os((n,e)=>{let{flags:t}=e.context,i=t&hi?Ng:Mg,s=(t&ci)>0,r=!(t&di),o=(t&ui)>0,l=n.pos;for(;!(n.next<0);)if(o&&n.next==Bf)if(n.peek(1)==Bf)n.advance(2);else{if(n.pos==l){n.acceptToken(Ag,1);return}break}else if(r&&n.next==Tg){if(n.pos==l){n.advance();let a=n.next;a>=0&&(n.advance(),dS(n,a)),n.acceptToken(cx);return}break}else if(n.next==Tg&&!r&&n.peek(1)>-1)n.advance(2);else if(n.next==i&&(!s||n.peek(1)==i&&n.peek(2)==i)){if(n.pos==l){n.acceptToken(xg,s?3:1);return}break}else if(n.next==ls){if(s)n.advance();else if(n.pos==l){n.acceptToken(xg);return}break}else n.advance();n.pos>l&&n.acceptToken(hx)});function dS(n,e){if(e==Zx)for(let t=0;t<2&&n.next>=48&&n.next<=55;t++)n.advance();else if(e==eS)for(let t=0;t<2&&qf(n.next);t++)n.advance();else if(e==iS)for(let t=0;t<4&&qf(n.next);t++)n.advance();else if(e==sS)for(let t=0;t<8&&qf(n.next);t++)n.advance();else if(e==tS&&n.next==Bf){for(n.advance();n.next>=0&&n.next!=Sg&&n.next!=Mg&&n.next!=Ng&&n.next!=ls;)n.advance();n.next==Sg&&n.advance()}}var uS=oo({'async "*" "**" FormatConversion FormatSpec':A.modifier,"for while if elif else try except finally return raise break continue with pass assert await yield match case":A.controlKeyword,"in not and or is del":A.operatorKeyword,"from def class global nonlocal lambda":A.definitionKeyword,import:A.moduleKeyword,"with as print":A.keyword,Boolean:A.bool,None:A.null,VariableName:A.variableName,"CallExpression/VariableName":A.function(A.variableName),"FunctionDefinition/VariableName":A.function(A.definition(A.variableName)),"ClassDefinition/VariableName":A.definition(A.className),PropertyName:A.propertyName,"CallExpression/MemberExpression/PropertyName":A.function(A.propertyName),Comment:A.lineComment,Number:A.number,String:A.string,FormatString:A.special(A.string),Escape:A.escape,UpdateOp:A.updateOperator,"ArithOp!":A.arithmeticOperator,BitOp:A.bitwiseOperator,CompareOp:A.compareOperator,AssignOp:A.definitionOperator,Ellipsis:A.punctuation,At:A.meta,"( )":A.paren,"[ ]":A.squareBracket,"{ }":A.brace,".":A.derefOperator,", ;":A.separator}),pS={__proto__:null,await:44,or:54,and:56,in:60,not:62,is:64,if:70,else:72,lambda:76,yield:94,from:96,async:102,for:104,None:162,True:164,False:164,del:178,pass:182,break:186,continue:190,return:194,raise:202,import:206,as:208,global:212,nonlocal:214,assert:218,type:223,elif:236,while:240,try:246,except:248,finally:250,with:254,def:258,class:268,match:279,case:285},Ig=xo.deserialize({version:14,states:"##jQ`QeOOP$}OSOOO&WQtO'#HUOOQS'#Co'#CoOOQS'#Cp'#CpO'vQdO'#CnO*UQtO'#HTOOQS'#HU'#HUOOQS'#DU'#DUOOQS'#HT'#HTO*rQdO'#D_O+VQdO'#DfO+gQdO'#DjO+zOWO'#DuO,VOWO'#DvO.[QtO'#GuOOQS'#Gu'#GuO'vQdO'#GtO0ZQtO'#GtOOQS'#Eb'#EbO0rQdO'#EcOOQS'#Gs'#GsO0|QdO'#GrOOQV'#Gr'#GrO1XQdO'#FYOOQS'#G^'#G^O1^QdO'#FXOOQV'#IS'#ISOOQV'#Gq'#GqOOQV'#Fq'#FqQ`QeOOO'vQdO'#CqO1lQdO'#C}O1sQdO'#DRO2RQdO'#HYO2cQtO'#EVO'vQdO'#EWOOQS'#EY'#EYOOQS'#E['#E[OOQS'#E^'#E^O2wQdO'#E`O3_QdO'#EdO3rQdO'#EfO3zQtO'#EfO1XQdO'#EiO0rQdO'#ElO1XQdO'#EnO0rQdO'#EtO0rQdO'#EwO4VQdO'#EyO4^QdO'#FOO4iQdO'#EzO0rQdO'#FOO1XQdO'#FQO1XQdO'#FVO4nQdO'#F[P4uOdO'#GpPOOO)CBd)CBdOOQS'#Ce'#CeOOQS'#Cf'#CfOOQS'#Cg'#CgOOQS'#Ch'#ChOOQS'#Ci'#CiOOQS'#Cj'#CjOOQS'#Cl'#ClO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO5TQdO'#DoOOQS,5:Y,5:YO5hQdO'#HdOOQS,5:],5:]O5uQ!fO,5:]O5zQtO,59YO1lQdO,59bO1lQdO,59bO1lQdO,59bO8jQdO,59bO8oQdO,59bO8vQdO,59jO8}QdO'#HTO:TQdO'#HSOOQS'#HS'#HSOOQS'#D['#D[O:lQdO,59aO'vQdO,59aO:zQdO,59aOOQS,59y,59yO;PQdO,5:RO'vQdO,5:ROOQS,5:Q,5:QO;_QdO,5:QO;dQdO,5:XO'vQdO,5:XO'vQdO,5:VOOQS,5:U,5:UO;uQdO,5:UO;zQdO,5:WOOOW'#Fy'#FyO<POWO,5:aOOQS,5:a,5:aO<[QdO'#HwOOOW'#Dw'#DwOOOW'#Fz'#FzO<lOWO,5:bOOQS,5:b,5:bOOQS'#F}'#F}O<zQtO,5:iO?lQtO,5=`O@VQ#xO,5=`O@vQtO,5=`OOQS,5:},5:}OA_QeO'#GWOBqQdO,5;^OOQV,5=^,5=^OB|QtO'#IPOCkQdO,5;tOOQS-E:[-E:[OOQV,5;s,5;sO4dQdO'#FQOOQV-E9o-E9oOCsQtO,59]OEzQtO,59iOFeQdO'#HVOFpQdO'#HVO1XQdO'#HVOF{QdO'#DTOGTQdO,59mOGYQdO'#HZO'vQdO'#HZO0rQdO,5=tOOQS,5=t,5=tO0rQdO'#EROOQS'#ES'#ESOGwQdO'#GPOHXQdO,58|OHXQdO,58|O*xQdO,5:oOHgQtO'#H]OOQS,5:r,5:rOOQS,5:z,5:zOHzQdO,5;OOI]QdO'#IOO1XQdO'#H}OOQS,5;Q,5;QOOQS'#GT'#GTOIqQtO,5;QOJPQdO,5;QOJUQdO'#IQOOQS,5;T,5;TOJdQdO'#H|OOQS,5;W,5;WOJuQdO,5;YO4iQdO,5;`O4iQdO,5;cOJ}QtO'#ITO'vQdO'#ITOKXQdO,5;eO4VQdO,5;eO0rQdO,5;jO1XQdO,5;lOK^QeO'#EuOLjQgO,5;fO!!kQdO'#IUO4iQdO,5;jO!!vQdO,5;lO!#OQdO,5;qO!#ZQtO,5;vO'vQdO,5;vPOOO,5=[,5=[P!#bOSO,5=[P!#jOdO,5=[O!&bQtO1G.jO!&iQtO1G.jO!)YQtO1G.jO!)dQtO1G.jO!+}QtO1G.jO!,bQtO1G.jO!,uQdO'#HcO!-TQtO'#GuO0rQdO'#HcO!-_QdO'#HbOOQS,5:Z,5:ZO!-gQdO,5:ZO!-lQdO'#HeO!-wQdO'#HeO!.[QdO,5>OOOQS'#Ds'#DsOOQS1G/w1G/wOOQS1G.|1G.|O!/[QtO1G.|O!/cQtO1G.|O1lQdO1G.|O!0OQdO1G/UOOQS'#DZ'#DZO0rQdO,59tOOQS1G.{1G.{O!0VQdO1G/eO!0gQdO1G/eO!0oQdO1G/fO'vQdO'#H[O!0tQdO'#H[O!0yQtO1G.{O!1ZQdO,59iO!2aQdO,5=zO!2qQdO,5=zO!2yQdO1G/mO!3OQtO1G/mOOQS1G/l1G/lO!3`QdO,5=uO!4VQdO,5=uO0rQdO1G/qO!4tQdO1G/sO!4yQtO1G/sO!5ZQtO1G/qOOQS1G/p1G/pOOQS1G/r1G/rOOOW-E9w-E9wOOQS1G/{1G/{O!5kQdO'#HxO0rQdO'#HxO!5|QdO,5>cOOOW-E9x-E9xOOQS1G/|1G/|OOQS-E9{-E9{O!6[Q#xO1G2zO!6{QtO1G2zO'vQdO,5<jOOQS,5<j,5<jOOQS-E9|-E9|OOQS,5<r,5<rOOQS-E:U-E:UOOQV1G0x1G0xO1XQdO'#GRO!7dQtO,5>kOOQS1G1`1G1`O!8RQdO1G1`OOQS'#DV'#DVO0rQdO,5=qOOQS,5=q,5=qO!8WQdO'#FrO!8cQdO,59oO!8kQdO1G/XO!8uQtO,5=uOOQS1G3`1G3`OOQS,5:m,5:mO!9fQdO'#GtOOQS,5<k,5<kOOQS-E9}-E9}O!9wQdO1G.hOOQS1G0Z1G0ZO!:VQdO,5=wO!:gQdO,5=wO0rQdO1G0jO0rQdO1G0jO!:xQdO,5>jO!;ZQdO,5>jO1XQdO,5>jO!;lQdO,5>iOOQS-E:R-E:RO!;qQdO1G0lO!;|QdO1G0lO!<RQdO,5>lO!<aQdO,5>lO!<oQdO,5>hO!=VQdO,5>hO!=hQdO'#EpO0rQdO1G0tO!=sQdO1G0tO!=xQgO1G0zO!AvQgO1G0}O!EqQdO,5>oO!E{QdO,5>oO!FTQtO,5>oO0rQdO1G1PO!F_QdO1G1PO4iQdO1G1UO!!vQdO1G1WOOQV,5;a,5;aO!FdQfO,5;aO!FiQgO1G1QO!JjQdO'#GZO4iQdO1G1QO4iQdO1G1QO!JzQdO,5>pO!KXQdO,5>pO1XQdO,5>pOOQV1G1U1G1UO!KaQdO'#FSO!KrQ!fO1G1WO!KzQdO1G1WOOQV1G1]1G1]O4iQdO1G1]O!LPQdO1G1]O!LXQdO'#F^OOQV1G1b1G1bO!#ZQtO1G1bPOOO1G2v1G2vP!L^OSO1G2vOOQS,5=},5=}OOQS'#Dp'#DpO0rQdO,5=}O!LfQdO,5=|O!LyQdO,5=|OOQS1G/u1G/uO!MRQdO,5>PO!McQdO,5>PO!MkQdO,5>PO!NOQdO,5>PO!N`QdO,5>POOQS1G3j1G3jOOQS7+$h7+$hO!8kQdO7+$pO#!RQdO1G.|O#!YQdO1G.|OOQS1G/`1G/`OOQS,5<`,5<`O'vQdO,5<`OOQS7+%P7+%PO#!aQdO7+%POOQS-E9r-E9rOOQS7+%Q7+%QO#!qQdO,5=vO'vQdO,5=vOOQS7+$g7+$gO#!vQdO7+%PO##OQdO7+%QO##TQdO1G3fOOQS7+%X7+%XO##eQdO1G3fO##mQdO7+%XOOQS,5<_,5<_O'vQdO,5<_O##rQdO1G3aOOQS-E9q-E9qO#$iQdO7+%]OOQS7+%_7+%_O#$wQdO1G3aO#%fQdO7+%_O#%kQdO1G3gO#%{QdO1G3gO#&TQdO7+%]O#&YQdO,5>dO#&sQdO,5>dO#&sQdO,5>dOOQS'#Dx'#DxO#'UO&jO'#DzO#'aO`O'#HyOOOW1G3}1G3}O#'fQdO1G3}O#'nQdO1G3}O#'yQ#xO7+(fO#(jQtO1G2UP#)TQdO'#GOOOQS,5<m,5<mOOQS-E:P-E:POOQS7+&z7+&zOOQS1G3]1G3]OOQS,5<^,5<^OOQS-E9p-E9pOOQS7+$s7+$sO#)bQdO,5=`O#){QdO,5=`O#*^QtO,5<aO#*qQdO1G3cOOQS-E9s-E9sOOQS7+&U7+&UO#+RQdO7+&UO#+aQdO,5<nO#+uQdO1G4UOOQS-E:Q-E:QO#,WQdO1G4UOOQS1G4T1G4TOOQS7+&W7+&WO#,iQdO7+&WOOQS,5<p,5<pO#,tQdO1G4WOOQS-E:S-E:SOOQS,5<l,5<lO#-SQdO1G4SOOQS-E:O-E:OO1XQdO'#EqO#-jQdO'#EqO#-uQdO'#IRO#-}QdO,5;[OOQS7+&`7+&`O0rQdO7+&`O#.SQgO7+&fO!JmQdO'#GXO4iQdO7+&fO4iQdO7+&iO#2QQtO,5<tO'vQdO,5<tO#2[QdO1G4ZOOQS-E:W-E:WO#2fQdO1G4ZO4iQdO7+&kO0rQdO7+&kOOQV7+&p7+&pO!KrQ!fO7+&rO!KzQdO7+&rO`QeO1G0{OOQV-E:X-E:XO4iQdO7+&lO4iQdO7+&lOOQV,5<u,5<uO#2nQdO,5<uO!JmQdO,5<uOOQV7+&l7+&lO#2yQgO7+&lO#6tQdO,5<vO#7PQdO1G4[OOQS-E:Y-E:YO#7^QdO1G4[O#7fQdO'#IWO#7tQdO'#IWO1XQdO'#IWOOQS'#IW'#IWO#8PQdO'#IVOOQS,5;n,5;nO#8XQdO,5;nO0rQdO'#FUOOQV7+&r7+&rO4iQdO7+&rOOQV7+&w7+&wO4iQdO7+&wO#8^QfO,5;xOOQV7+&|7+&|POOO7+(b7+(bO#8cQdO1G3iOOQS,5<c,5<cO#8qQdO1G3hOOQS-E9u-E9uO#9UQdO,5<dO#9aQdO,5<dO#9tQdO1G3kOOQS-E9v-E9vO#:UQdO1G3kO#:^QdO1G3kO#:nQdO1G3kO#:UQdO1G3kOOQS<<H[<<H[O#:yQtO1G1zOOQS<<Hk<<HkP#;WQdO'#FtO8vQdO1G3bO#;eQdO1G3bO#;jQdO<<HkOOQS<<Hl<<HlO#;zQdO7+)QOOQS<<Hs<<HsO#<[QtO1G1yP#<{QdO'#FsO#=YQdO7+)RO#=jQdO7+)RO#=rQdO<<HwO#=wQdO7+({OOQS<<Hy<<HyO#>nQdO,5<bO'vQdO,5<bOOQS-E9t-E9tOOQS<<Hw<<HwOOQS,5<g,5<gO0rQdO,5<gO#>sQdO1G4OOOQS-E9y-E9yO#?^QdO1G4OO<[QdO'#H{OOOO'#D{'#D{OOOO'#F|'#F|O#?oO&jO,5:fOOOW,5>e,5>eOOOW7+)i7+)iO#?zQdO7+)iO#@SQdO1G2zO#@mQdO1G2zP'vQdO'#FuO0rQdO<<IpO1XQdO1G2YP1XQdO'#GSO#AOQdO7+)pO#AaQdO7+)pOOQS<<Ir<<IrP1XQdO'#GUP0rQdO'#GQOOQS,5;],5;]O#ArQdO,5>mO#BQQdO,5>mOOQS1G0v1G0vOOQS<<Iz<<IzOOQV-E:V-E:VO4iQdO<<JQOOQV,5<s,5<sO4iQdO,5<sOOQV<<JQ<<JQOOQV<<JT<<JTO#BYQtO1G2`P#BdQdO'#GYO#BkQdO7+)uO#BuQgO<<JVO4iQdO<<JVOOQV<<J^<<J^O4iQdO<<J^O!KrQ!fO<<J^O#FpQgO7+&gOOQV<<JW<<JWO#FzQgO<<JWOOQV1G2a1G2aO1XQdO1G2aO#JuQdO1G2aO4iQdO<<JWO1XQdO1G2bP0rQdO'#G[O#KQQdO7+)vO#K_QdO7+)vOOQS'#FT'#FTO0rQdO,5>rO#KgQdO,5>rO#KrQdO,5>rO#K}QdO,5>qO#L`QdO,5>qOOQS1G1Y1G1YOOQS,5;p,5;pOOQV<<Jc<<JcO#LhQdO1G1dOOQS7+)T7+)TP#LmQdO'#FwO#L}QdO1G2OO#MbQdO1G2OO#MrQdO1G2OP#M}QdO'#FxO#N[QdO7+)VO#NlQdO7+)VO#NlQdO7+)VO#NtQdO7+)VO$ UQdO7+(|O8vQdO7+(|OOQSAN>VAN>VO$ oQdO<<LmOOQSAN>cAN>cO0rQdO1G1|O$!PQtO1G1|P$!ZQdO'#FvOOQS1G2R1G2RP$!hQdO'#F{O$!uQdO7+)jO$#`QdO,5>gOOOO-E9z-E9zOOOW<<MT<<MTO$#nQdO7+(fOOQSAN?[AN?[OOQS7+'t7+'tO$$XQdO<<M[OOQS,5<q,5<qO$$jQdO1G4XOOQS-E:T-E:TOOQVAN?lAN?lOOQV1G2_1G2_O4iQdOAN?qO$$xQgOAN?qOOQVAN?xAN?xO4iQdOAN?xOOQV<<JR<<JRO4iQdOAN?rO4iQdO7+'{OOQV7+'{7+'{O1XQdO7+'{OOQVAN?rAN?rOOQS7+'|7+'|O$(sQdO<<MbOOQS1G4^1G4^O0rQdO1G4^OOQS,5<w,5<wO$)QQdO1G4]OOQS-E:Z-E:ZOOQU'#G_'#G_O$)cQfO7+'OO$)nQdO'#F_O$*uQdO7+'jO$+VQdO7+'jOOQS7+'j7+'jO$+bQdO<<LqO$+rQdO<<LqO$+rQdO<<LqO$+zQdO'#H^OOQS<<Lh<<LhO$,UQdO<<LhOOQS7+'h7+'hOOQS'#D|'#D|OOOO1G4R1G4RO$,oQdO1G4RO$,wQdO1G4RP!=hQdO'#GVOOQVG25]G25]O4iQdOG25]OOQVG25dG25dOOQVG25^G25^OOQV<<Kg<<KgO4iQdO<<KgOOQS7+)x7+)xP$-SQdO'#G]OOQU-E:]-E:]OOQV<<Jj<<JjO$-vQtO'#FaOOQS'#Fc'#FcO$.WQdO'#FbO$.xQdO'#FbOOQS'#Fb'#FbO$.}QdO'#IYO$)nQdO'#FiO$)nQdO'#FiO$/fQdO'#FjO$)nQdO'#FkO$/mQdO'#IZOOQS'#IZ'#IZO$0[QdO,5;yOOQS<<KU<<KUO$0dQdO<<KUO$0tQdOANB]O$1UQdOANB]O$1^QdO'#H_OOQS'#H_'#H_O1sQdO'#DcO$1wQdO,5=xOOQSANBSANBSOOOO7+)m7+)mO$2`QdO7+)mOOQVLD*wLD*wOOQVANARANARO5uQ!fO'#GaO$2hQtO,5<SO$)nQdO'#FmOOQS,5<W,5<WOOQS'#Fd'#FdO$3YQdO,5;|O$3_QdO,5;|OOQS'#Fg'#FgO$)nQdO'#G`O$4PQdO,5<QO$4kQdO,5>tO$4{QdO,5>tO1XQdO,5<PO$5^QdO,5<TO$5cQdO,5<TO$)nQdO'#I[O$5hQdO'#I[O$5mQdO,5<UOOQS,5<V,5<VO0rQdO'#FpOOQU1G1e1G1eO4iQdO1G1eOOQSAN@pAN@pO$5rQdOG27wO$6SQdO,59}OOQS1G3d1G3dOOOO<<MX<<MXOOQS,5<{,5<{OOQS-E:_-E:_O$6XQtO'#FaO$6`QdO'#I]O$6nQdO'#I]O$6vQdO,5<XOOQS1G1h1G1hO$6{QdO1G1hO$7QQdO,5<zOOQS-E:^-E:^O$7lQdO,5=OO$8TQdO1G4`OOQS-E:b-E:bOOQS1G1k1G1kOOQS1G1o1G1oO$8eQdO,5>vO$)nQdO,5>vOOQS1G1p1G1pOOQS,5<[,5<[OOQU7+'P7+'PO$+zQdO1G/iO$)nQdO,5<YO$8sQdO,5>wO$8zQdO,5>wOOQS1G1s1G1sOOQS7+'S7+'SP$)nQdO'#GdO$9SQdO1G4bO$9^QdO1G4bO$9fQdO1G4bOOQS7+%T7+%TO$9tQdO1G1tO$:SQtO'#FaO$:ZQdO,5<}OOQS,5<},5<}O$:iQdO1G4cOOQS-E:a-E:aO$)nQdO,5<|O$:pQdO,5<|O$:uQdO7+)|OOQS-E:`-E:`O$;PQdO7+)|O$)nQdO,5<ZP$)nQdO'#GcO$;XQdO1G2hO$)nQdO1G2hP$;gQdO'#GbO$;nQdO<<MhO$;xQdO1G1uO$<WQdO7+(SO8vQdO'#C}O8vQdO,59bO8vQdO,59bO8vQdO,59bO$<fQtO,5=`O8vQdO1G.|O0rQdO1G/XO0rQdO7+$pP$<yQdO'#GOO'vQdO'#GtO$=WQdO,59bO$=]QdO,59bO$=dQdO,59mO$=iQdO1G/UO1sQdO'#DRO8vQdO,59j",stateData:"$>S~O%cOS%^OSSOS%]PQ~OPdOVaOfoOhYOopOs!POvqO!PrO!Q{O!T!SO!U!RO!XZO!][O!h`O!r`O!s`O!t`O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO#l!QO#o!TO#s!UO#u!VO#z!WO#}hO$P!XO%oRO%pRO%tSO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O~O%]!YO~OV!aO_!aOa!bOh!iO!X!kO!f!mO%j![O%k!]O%l!^O%m!_O%n!_O%o!`O%p!`O%q!aO%r!aO%s!aO~Ok%xXl%xXm%xXn%xXo%xXp%xXs%xXz%xX{%xX!x%xX#g%xX%[%xX%_%xX%z%xXg%xX!T%xX!U%xX%{%xX!W%xX![%xX!Q%xX#[%xXt%xX!m%xX~P%SOfoOhYO!XZO!][O!h`O!r`O!s`O!t`O%oRO%pRO%tSO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O~Oz%wX{%wX#g%wX%[%wX%_%wX%z%wX~Ok!pOl!qOm!oOn!oOo!rOp!sOs!tO!x%wX~P)pOV!zOg!|Oo0cOv0qO!PrO~P'vOV#OOo0cOv0qO!W#PO~P'vOV#SOa#TOo0cOv0qO![#UO~P'vOQ#XO%`#XO%a#ZO~OQ#^OR#[O%`#^O%a#`O~OV%iX_%iXa%iXh%iXk%iXl%iXm%iXn%iXo%iXp%iXs%iXz%iX!X%iX!f%iX%j%iX%k%iX%l%iX%m%iX%n%iX%o%iX%p%iX%q%iX%r%iX%s%iXg%iX!T%iX!U%iX~O&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O{%iX!x%iX#g%iX%[%iX%_%iX%z%iX%{%iX!W%iX![%iX!Q%iX#[%iXt%iX!m%iX~P,eOz#dO{%hX!x%hX#g%hX%[%hX%_%hX%z%hX~Oo0cOv0qO~P'vO#g#gO%[#iO%_#iO~O%uWO~O!T#nO#u!VO#z!WO#}hO~OopO~P'vOV#sOa#tO%uWO{wP~OV#xOo0cOv0qO!Q#yO~P'vO{#{O!x$QO%z#|O#g!yX%[!yX%_!yX~OV#xOo0cOv0qO#g#SX%[#SX%_#SX~P'vOo0cOv0qO#g#WX%[#WX%_#WX~P'vOh$WO%uWO~O!f$YO!r$YO%uWO~OV$eO~P'vO!U$gO#s$hO#u$iO~O{$jO~OV$qO~P'vOS$sO%[$rO%_$rO%c$tO~OV$}Oa$}Og%POo0cOv0qO~P'vOo0cOv0qO{%SO~P'vO&Y%UO~Oa!bOh!iO!X!kO!f!mOVba_bakbalbambanbaobapbasbazba{ba!xba#gba%[ba%_ba%jba%kba%lba%mba%nba%oba%pba%qba%rba%sba%zbagba!Tba!Uba%{ba!Wba![ba!Qba#[batba!mba~On%ZO~Oo%ZO~P'vOo0cO~P'vOk0eOl0fOm0dOn0dOo0mOp0nOs0rOg%wX!T%wX!U%wX%{%wX!W%wX![%wX!Q%wX#[%wX!m%wX~P)pO%{%]Og%vXz%vX!T%vX!U%vX!W%vX{%vX~Og%_Oz%`O!T%dO!U%cO~Og%_O~Oz%gO!T%dO!U%cO!W&SX~O!W%kO~Oz%lO{%nO!T%dO!U%cO![%}X~O![%rO~O![%sO~OQ#XO%`#XO%a%uO~OV%wOo0cOv0qO!PrO~P'vOQ#^OR#[O%`#^O%a%zO~OV!qa_!qaa!qah!qak!qal!qam!qan!qao!qap!qas!qaz!qa{!qa!X!qa!f!qa!x!qa#g!qa%[!qa%_!qa%j!qa%k!qa%l!qa%m!qa%n!qa%o!qa%p!qa%q!qa%r!qa%s!qa%z!qag!qa!T!qa!U!qa%{!qa!W!qa![!qa!Q!qa#[!qat!qa!m!qa~P#yOz%|O{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~P%SOV&OOopOvqO{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~P'vOz%|O{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~OPdOVaOopOvqO!PrO!Q{O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO#g$zX%[$zX%_$zX~P'vO#g#gO%[&TO%_&TO~O!f&UOh&sX%[&sXz&sX#[&sX#g&sX%_&sX#Z&sXg&sX~Oh!iO%[&WO~Okealeameaneaoeapeaseazea{ea!xea#gea%[ea%_ea%zeagea!Tea!Uea%{ea!Wea![ea!Qea#[eatea!mea~P%SOsqazqa{qa#gqa%[qa%_qa%zqa~Ok!pOl!qOm!oOn!oOo!rOp!sO!xqa~PEcO%z&YOz%yX{%yX~O%uWOz%yX{%yX~Oz&]O{wX~O{&_O~Oz%lO#g%}X%[%}X%_%}Xg%}X{%}X![%}X!m%}X%z%}X~OV0lOo0cOv0qO!PrO~P'vO%z#|O#gUa%[Ua%_Ua~Oz&hO#g&PX%[&PX%_&PXn&PX~P%SOz&kO!Q&jO#g#Wa%[#Wa%_#Wa~Oz&lO#[&nO#g&rX%[&rX%_&rXg&rX~O!f$YO!r$YO#Z&qO%uWO~O#Z&qO~Oz&sO#g&tX%[&tX%_&tX~Oz&uO#g&pX%[&pX%_&pX{&pX~O!X&wO%z&xO~Oz&|On&wX~P%SOn'PO~OPdOVaOopOvqO!PrO!Q{O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO%['UO~P'vOt'YO#p'WO#q'XOP#naV#naf#nah#nao#nas#nav#na!P#na!Q#na!T#na!U#na!X#na!]#na!h#na!r#na!s#na!t#na!{#na!}#na#P#na#R#na#T#na#X#na#Z#na#^#na#_#na#a#na#c#na#l#na#o#na#s#na#u#na#z#na#}#na$P#na%X#na%o#na%p#na%t#na%u#na&Z#na&[#na&]#na&^#na&_#na&`#na&a#na&b#na&c#na&d#na&e#na&f#na&g#na&h#na&i#na&j#na%Z#na%_#na~Oz'ZO#[']O{&xX~Oh'_O!X&wO~Oh!iO{$jO!X&wO~O{'eO~P%SO%['hO%_'hO~OS'iO%['hO%_'hO~OV!aO_!aOa!bOh!iO!X!kO!f!mO%l!^O%m!_O%n!_O%o!`O%p!`O%q!aO%r!aO%s!aOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~O%k!]O~P!#uO%kWi~P!#uOV!aO_!aOa!bOh!iO!X!kO!f!mO%o!`O%p!`O%q!aO%r!aO%s!aOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%kWi%lWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~O%m!_O%n!_O~P!&pO%mWi%nWi~P!&pOa!bOh!iO!X!kO!f!mOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%kWi%lWi%mWi%nWi%oWi%pWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~OV!aO_!aO%q!aO%r!aO%s!aO~P!)nOVWi_Wi%qWi%rWi%sWi~P!)nO!T%dO!U%cOg&VXz&VX~O%z'kO%{'kO~P,eOz'mOg&UX~Og'oO~Oz'pO{'rO!W&XX~Oo0cOv0qOz'pO{'sO!W&XX~P'vO!W'uO~Om!oOn!oOo!rOp!sOkjisjizji{ji!xji#gji%[ji%_ji%zji~Ol!qO~P!.aOlji~P!.aOk0eOl0fOm0dOn0dOo0mOp0nO~Ot'wO~P!/jOV'|Og'}Oo0cOv0qO~P'vOg'}Oz(OO~Og(QO~O!U(SO~Og(TOz(OO!T%dO!U%cO~P%SOk0eOl0fOm0dOn0dOo0mOp0nOgqa!Tqa!Uqa%{qa!Wqa![qa!Qqa#[qatqa!mqa~PEcOV'|Oo0cOv0qO!W&Sa~P'vOz(WO!W&Sa~O!W(XO~Oz(WO!T%dO!U%cO!W&Sa~P%SOV(]Oo0cOv0qO![%}a#g%}a%[%}a%_%}ag%}a{%}a!m%}a%z%}a~P'vOz(^O![%}a#g%}a%[%}a%_%}ag%}a{%}a!m%}a%z%}a~O![(aO~Oz(^O!T%dO!U%cO![%}a~P%SOz(dO!T%dO!U%cO![&Ta~P%SOz(gO{&lX![&lX!m&lX%z&lX~O{(kO![(mO!m(nO%z(jO~OV&OOopOvqO{%hi!x%hi#g%hi%[%hi%_%hi%z%hi~P'vOz(pO{%hi!x%hi#g%hi%[%hi%_%hi%z%hi~O!f&UOh&sa%[&saz&sa#[&sa#g&sa%_&sa#Z&sag&sa~O%[(uO~OV#sOa#tO%uWO~Oz&]O{wa~OopOvqO~P'vOz(^O#g%}a%[%}a%_%}ag%}a{%}a![%}a!m%}a%z%}a~P%SOz(zO#g%hX%[%hX%_%hX%z%hX~O%z#|O#gUi%[Ui%_Ui~O#g&Pa%[&Pa%_&Pan&Pa~P'vOz(}O#g&Pa%[&Pa%_&Pan&Pa~O%uWO#g&ra%[&ra%_&rag&ra~Oz)SO#g&ra%[&ra%_&rag&ra~Og)VO~OV)WOh$WO%uWO~O#Z)XO~O%uWO#g&ta%[&ta%_&ta~Oz)ZO#g&ta%[&ta%_&ta~Oo0cOv0qO#g&pa%[&pa%_&pa{&pa~P'vOz)^O#g&pa%[&pa%_&pa{&pa~OV)`Oa)`O%uWO~O%z)eO~Ot)hO#j)gOP#hiV#hif#hih#hio#his#hiv#hi!P#hi!Q#hi!T#hi!U#hi!X#hi!]#hi!h#hi!r#hi!s#hi!t#hi!{#hi!}#hi#P#hi#R#hi#T#hi#X#hi#Z#hi#^#hi#_#hi#a#hi#c#hi#l#hi#o#hi#s#hi#u#hi#z#hi#}#hi$P#hi%X#hi%o#hi%p#hi%t#hi%u#hi&Z#hi&[#hi&]#hi&^#hi&_#hi&`#hi&a#hi&b#hi&c#hi&d#hi&e#hi&f#hi&g#hi&h#hi&i#hi&j#hi%Z#hi%_#hi~Ot)iOP#kiV#kif#kih#kio#kis#kiv#ki!P#ki!Q#ki!T#ki!U#ki!X#ki!]#ki!h#ki!r#ki!s#ki!t#ki!{#ki!}#ki#P#ki#R#ki#T#ki#X#ki#Z#ki#^#ki#_#ki#a#ki#c#ki#l#ki#o#ki#s#ki#u#ki#z#ki#}#ki$P#ki%X#ki%o#ki%p#ki%t#ki%u#ki&Z#ki&[#ki&]#ki&^#ki&_#ki&`#ki&a#ki&b#ki&c#ki&d#ki&e#ki&f#ki&g#ki&h#ki&i#ki&j#ki%Z#ki%_#ki~OV)kOn&wa~P'vOz)lOn&wa~Oz)lOn&wa~P%SOn)pO~O%Y)tO~Ot)wO#p'WO#q)vOP#niV#nif#nih#nio#nis#niv#ni!P#ni!Q#ni!T#ni!U#ni!X#ni!]#ni!h#ni!r#ni!s#ni!t#ni!{#ni!}#ni#P#ni#R#ni#T#ni#X#ni#Z#ni#^#ni#_#ni#a#ni#c#ni#l#ni#o#ni#s#ni#u#ni#z#ni#}#ni$P#ni%X#ni%o#ni%p#ni%t#ni%u#ni&Z#ni&[#ni&]#ni&^#ni&_#ni&`#ni&a#ni&b#ni&c#ni&d#ni&e#ni&f#ni&g#ni&h#ni&i#ni&j#ni%Z#ni%_#ni~OV)zOo0cOv0qO{$jO~P'vOo0cOv0qO{&xa~P'vOz*OO{&xa~OV*SOa*TOg*WO%q*UO%uWO~O{$jO&{*YO~Oh'_O~Oh!iO{$jO~O%[*_O~O%[*aO%_*aO~OV$}Oa$}Oo0cOv0qOg&Ua~P'vOz*dOg&Ua~Oo0cOv0qO{*gO!W&Xa~P'vOz*hO!W&Xa~Oo0cOv0qOz*hO{*kO!W&Xa~P'vOo0cOv0qOz*hO!W&Xa~P'vOz*hO{*kO!W&Xa~Om0dOn0dOo0mOp0nOgjikjisjizji!Tji!Uji%{ji!Wji{ji![ji#gji%[ji%_ji!Qji#[jitji!mji%zji~Ol0fO~P!NkOlji~P!NkOV'|Og*pOo0cOv0qO~P'vOn*rO~Og*pOz*tO~Og*uO~OV'|Oo0cOv0qO!W&Si~P'vOz*vO!W&Si~O!W*wO~OV(]Oo0cOv0qO![%}i#g%}i%[%}i%_%}ig%}i{%}i!m%}i%z%}i~P'vOz*zO!T%dO!U%cO![&Ti~Oz*}O![%}i#g%}i%[%}i%_%}ig%}i{%}i!m%}i%z%}i~O![+OO~Oa+QOo0cOv0qO![&Ti~P'vOz*zO![&Ti~O![+SO~OV+UOo0cOv0qO{&la![&la!m&la%z&la~P'vOz+VO{&la![&la!m&la%z&la~O!]+YO&n+[O![!nX~O![+^O~O{(kO![+_O~O{(kO![+_O!m+`O~OV&OOopOvqO{%hq!x%hq#g%hq%[%hq%_%hq%z%hq~P'vOz$ri{$ri!x$ri#g$ri%[$ri%_$ri%z$ri~P%SOV&OOopOvqO~P'vOV&OOo0cOv0qO#g%ha%[%ha%_%ha%z%ha~P'vOz+aO#g%ha%[%ha%_%ha%z%ha~Oz$ia#g$ia%[$ia%_$ian$ia~P%SO#g&Pi%[&Pi%_&Pin&Pi~P'vOz+dO#g#Wq%[#Wq%_#Wq~O#[+eOz$va#g$va%[$va%_$vag$va~O%uWO#g&ri%[&ri%_&rig&ri~Oz+gO#g&ri%[&ri%_&rig&ri~OV+iOh$WO%uWO~O%uWO#g&ti%[&ti%_&ti~Oo0cOv0qO#g&pi%[&pi%_&pi{&pi~P'vO{#{Oz#eX!W#eX~Oz+mO!W&uX~O!W+oO~Ot+rO#j)gOP#hqV#hqf#hqh#hqo#hqs#hqv#hq!P#hq!Q#hq!T#hq!U#hq!X#hq!]#hq!h#hq!r#hq!s#hq!t#hq!{#hq!}#hq#P#hq#R#hq#T#hq#X#hq#Z#hq#^#hq#_#hq#a#hq#c#hq#l#hq#o#hq#s#hq#u#hq#z#hq#}#hq$P#hq%X#hq%o#hq%p#hq%t#hq%u#hq&Z#hq&[#hq&]#hq&^#hq&_#hq&`#hq&a#hq&b#hq&c#hq&d#hq&e#hq&f#hq&g#hq&h#hq&i#hq&j#hq%Z#hq%_#hq~On$|az$|a~P%SOV)kOn&wi~P'vOz+yOn&wi~Oz,TO{$jO#[,TO~O#q,VOP#nqV#nqf#nqh#nqo#nqs#nqv#nq!P#nq!Q#nq!T#nq!U#nq!X#nq!]#nq!h#nq!r#nq!s#nq!t#nq!{#nq!}#nq#P#nq#R#nq#T#nq#X#nq#Z#nq#^#nq#_#nq#a#nq#c#nq#l#nq#o#nq#s#nq#u#nq#z#nq#}#nq$P#nq%X#nq%o#nq%p#nq%t#nq%u#nq&Z#nq&[#nq&]#nq&^#nq&_#nq&`#nq&a#nq&b#nq&c#nq&d#nq&e#nq&f#nq&g#nq&h#nq&i#nq&j#nq%Z#nq%_#nq~O#[,WOz%Oa{%Oa~Oo0cOv0qO{&xi~P'vOz,YO{&xi~O{#{O%z,[Og&zXz&zX~O%uWOg&zXz&zX~Oz,`Og&yX~Og,bO~O%Y,eO~O!T%dO!U%cOg&Viz&Vi~OV$}Oa$}Oo0cOv0qOg&Ui~P'vO{,hOz$la!W$la~Oo0cOv0qO{,iOz$la!W$la~P'vOo0cOv0qO{*gO!W&Xi~P'vOz,lO!W&Xi~Oo0cOv0qOz,lO!W&Xi~P'vOz,lO{,oO!W&Xi~Og$hiz$hi!W$hi~P%SOV'|Oo0cOv0qO~P'vOn,qO~OV'|Og,rOo0cOv0qO~P'vOV'|Oo0cOv0qO!W&Sq~P'vOz$gi![$gi#g$gi%[$gi%_$gig$gi{$gi!m$gi%z$gi~P%SOV(]Oo0cOv0qO~P'vOa+QOo0cOv0qO![&Tq~P'vOz,sO![&Tq~O![,tO~OV(]Oo0cOv0qO![%}q#g%}q%[%}q%_%}qg%}q{%}q!m%}q%z%}q~P'vO{,uO~OV+UOo0cOv0qO{&li![&li!m&li%z&li~P'vOz,zO{&li![&li!m&li%z&li~O!]+YO&n+[O![!na~O{(kO![,}O~OV&OOo0cOv0qO#g%hi%[%hi%_%hi%z%hi~P'vOz-OO#g%hi%[%hi%_%hi%z%hi~O%uWO#g&rq%[&rq%_&rqg&rq~Oz-RO#g&rq%[&rq%_&rqg&rq~OV)`Oa)`O%uWO!W&ua~Oz-TO!W&ua~On$|iz$|i~P%SOV)kO~P'vOV)kOn&wq~P'vOt-XOP#myV#myf#myh#myo#mys#myv#my!P#my!Q#my!T#my!U#my!X#my!]#my!h#my!r#my!s#my!t#my!{#my!}#my#P#my#R#my#T#my#X#my#Z#my#^#my#_#my#a#my#c#my#l#my#o#my#s#my#u#my#z#my#}#my$P#my%X#my%o#my%p#my%t#my%u#my&Z#my&[#my&]#my&^#my&_#my&`#my&a#my&b#my&c#my&d#my&e#my&f#my&g#my&h#my&i#my&j#my%Z#my%_#my~O%Z-]O%_-]O~P`O#q-^OP#nyV#nyf#nyh#nyo#nys#nyv#ny!P#ny!Q#ny!T#ny!U#ny!X#ny!]#ny!h#ny!r#ny!s#ny!t#ny!{#ny!}#ny#P#ny#R#ny#T#ny#X#ny#Z#ny#^#ny#_#ny#a#ny#c#ny#l#ny#o#ny#s#ny#u#ny#z#ny#}#ny$P#ny%X#ny%o#ny%p#ny%t#ny%u#ny&Z#ny&[#ny&]#ny&^#ny&_#ny&`#ny&a#ny&b#ny&c#ny&d#ny&e#ny&f#ny&g#ny&h#ny&i#ny&j#ny%Z#ny%_#ny~Oz-aO{$jO#[-aO~Oo0cOv0qO{&xq~P'vOz-dO{&xq~O%z,[Og&zaz&za~O{#{Og&zaz&za~OV*SOa*TO%q*UO%uWOg&ya~Oz-hOg&ya~O$S-lO~OV$}Oa$}Oo0cOv0qO~P'vOo0cOv0qO{-mOz$li!W$li~P'vOo0cOv0qOz$li!W$li~P'vO{-mOz$li!W$li~Oo0cOv0qO{*gO~P'vOo0cOv0qO{*gO!W&Xq~P'vOz-pO!W&Xq~Oo0cOv0qOz-pO!W&Xq~P'vOs-sO!T%dO!U%cOg&Oq!W&Oq![&Oqz&Oq~P!/jOa+QOo0cOv0qO![&Ty~P'vOz$ji![$ji~P%SOa+QOo0cOv0qO~P'vOV+UOo0cOv0qO~P'vOV+UOo0cOv0qO{&lq![&lq!m&lq%z&lq~P'vO{(kO![-xO!m-yO%z-wO~OV&OOo0cOv0qO#g%hq%[%hq%_%hq%z%hq~P'vO%uWO#g&ry%[&ry%_&ryg&ry~OV)`Oa)`O%uWO!W&ui~Ot-}OP#m!RV#m!Rf#m!Rh#m!Ro#m!Rs#m!Rv#m!R!P#m!R!Q#m!R!T#m!R!U#m!R!X#m!R!]#m!R!h#m!R!r#m!R!s#m!R!t#m!R!{#m!R!}#m!R#P#m!R#R#m!R#T#m!R#X#m!R#Z#m!R#^#m!R#_#m!R#a#m!R#c#m!R#l#m!R#o#m!R#s#m!R#u#m!R#z#m!R#}#m!R$P#m!R%X#m!R%o#m!R%p#m!R%t#m!R%u#m!R&Z#m!R&[#m!R&]#m!R&^#m!R&_#m!R&`#m!R&a#m!R&b#m!R&c#m!R&d#m!R&e#m!R&f#m!R&g#m!R&h#m!R&i#m!R&j#m!R%Z#m!R%_#m!R~Oo0cOv0qO{&xy~P'vOV*SOa*TO%q*UO%uWOg&yi~O$S-lO%Z.VO%_.VO~OV.aOh._O!X.^O!].`O!h.YO!s.[O!t.[O%p.XO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O~Oo0cOv0qOz$lq!W$lq~P'vO{.fOz$lq!W$lq~Oo0cOv0qO{*gO!W&Xy~P'vOz.gO!W&Xy~Oo0cOv.kO~P'vOs-sO!T%dO!U%cOg&Oy!W&Oy![&Oyz&Oy~P!/jO{(kO![.nO~O{(kO![.nO!m.oO~OV*SOa*TO%q*UO%uWO~Oh.tO!f.rOz$TX#[$TX%j$TXg$TX~Os$TX{$TX!W$TX![$TX~P$-bO%o.vO%p.vOs$UXz$UX{$UX#[$UX%j$UX!W$UXg$UX![$UX~O!h.xO~Oz.|O#[/OO%j.yOs&|X{&|X!W&|Xg&|X~Oa/RO~P$)zOh.tOs&}Xz&}X{&}X#[&}X%j&}X!W&}Xg&}X![&}X~Os/VO{$jO~Oo0cOv0qOz$ly!W$ly~P'vOo0cOv0qO{*gO!W&X!R~P'vOz/ZO!W&X!R~Og&RXs&RX!T&RX!U&RX!W&RX![&RXz&RX~P!/jOs-sO!T%dO!U%cOg&Qa!W&Qa![&Qaz&Qa~O{(kO![/^O~O!f.rOh$[as$[az$[a{$[a#[$[a%j$[a!W$[ag$[a![$[a~O!h/eO~O%o.vO%p.vOs$Uaz$Ua{$Ua#[$Ua%j$Ua!W$Uag$Ua![$Ua~O%j.yOs$Yaz$Ya{$Ya#[$Ya!W$Yag$Ya![$Ya~Os&|a{&|a!W&|ag&|a~P$)nOz/jOs&|a{&|a!W&|ag&|a~O!W/mO~Og/mO~O{/oO~O![/pO~Oo0cOv0qO{*gO!W&X!Z~P'vO{/sO~O%z/tO~P$-bOz/uO#[/OO%j.yOg'PX~Oz/uOg'PX~Og/wO~O!h/xO~O#[/OOs%Saz%Sa{%Sa%j%Sa!W%Sag%Sa![%Sa~O#[/OO%j.yOs%Waz%Wa{%Wa!W%Wag%Wa~Os&|i{&|i!W&|ig&|i~P$)nOz/zO#[/OO%j.yO!['Oa~Og'Pa~P$)nOz0SOg'Pa~Oa0UO!['Oi~P$)zOz0WO!['Oi~Oz0WO#[/OO%j.yO!['Oi~O#[/OO%j.yOg$biz$bi~O%z0ZO~P$-bO#[/OO%j.yOg%Vaz%Va~Og'Pi~P$)nO{0^O~Oa0UO!['Oq~P$)zOz0`O!['Oq~O#[/OO%j.yOz%Ui![%Ui~Oa0UO~P$)zOa0UO!['Oy~P$)zO#[/OO%j.yOg$ciz$ci~O#[/OO%j.yOz%Uq![%Uq~Oz+aO#g%ha%[%ha%_%ha%z%ha~P%SOV&OOo0cOv0qO~P'vOn0hO~Oo0hO~P'vO{0iO~Ot0jO~P!/jO&]&Z&j&h&i&g&f&d&e&c&b&`&a&_&^&[%u~",goto:"!=j'QPPPPPP'RP'Z*s+[+t,_,y-fP.SP'Z.r.r'ZPPP'Z2[PPPPPP2[5PPP5PP7b7k=sPP=v>h>kPP'Z'ZPP>zPP'Z'ZPP'Z'Z'Z'Z'Z?O?w'ZP?zP@QDXGuGyPG|HWH['ZPPPH_Hk'RP'R'RP'RP'RP'RP'RP'R'R'RP'RPP'RPP'RP'RPHqH}IVPI^IdPI^PI^I^PPPI^PKrPK{LVL]KrPI^LfPI^PLmLsPLwM]MzNeLwLwNkNxLwLwLwLw! ^! d! g! l! o! y!!P!!]!!o!!u!#P!#V!#s!#y!$P!$Z!$a!$g!$y!%T!%Z!%a!%k!%q!%w!%}!&T!&Z!&e!&k!&u!&{!'U!'[!'k!'s!'}!(UPPPPPPPPPPP!([!(_!(e!(n!(x!)TPPPPPPPPPPPP!-u!/Z!3^!6oPP!6w!7W!7a!8Y!8P!8c!8i!8l!8o!8r!8z!9jPPPPPPPPPPPPPPPPP!9m!9q!9wP!:]!:a!:m!:v!;S!;j!;m!;p!;v!;|!<S!<VP!<_!<h!=d!=g]eOn#g$j)t,P'}`OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0r{!cQ#c#p$R$d$p%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g}!dQ#c#p$R$d$p$u%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!P!eQ#c#p$R$d$p$u$v%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!R!fQ#c#p$R$d$p$u$v$w%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!T!gQ#c#p$R$d$p$u$v$w$x%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!V!hQ#c#p$R$d$p$u$v$w$x$y%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!Z!hQ!n#c#p$R$d$p$u$v$w$x$y$z%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g'}TOTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0r&eVOYZ[dnprxy}!P!Q!U!i!k!o!p!q!s!t#[#d#g#y#{#}$Q$h$j$}%S%Z%^%`%g%l%n%w%|&Z&_&j&k&u&x'P'W'Z'l'm'p'r's'w(O(W(^(d(g(p(r(z)^)e)g)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+U+V+Y+a+d+k,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0n0r%oXOYZ[dnrxy}!P!Q!U!i!k#[#d#g#y#{#}$Q$h$j$}%S%^%`%g%l%n%w%|&Z&_&j&k&u&x'P'W'Z'l'm'p'r's'w(O(W(^(d(g(p(r(z)^)e)g)p)t)z*O*Y*d*g*h*k*q*t*v*y*z*}+U+V+Y+a+d+k,P,X,Y,],g,h,i,k,l,o,s,u,w,y,z-O-d-f-m-p.f.g/V/Z0i0j0kQ#vqQ/[.kR0o0q't`OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0rh#jhz{$W$Z&l&q)S)X+f+g-RW#rq&].k0qQ$]|Q$a!OQ$n!VQ$o!WW$|!i'm*d,gS&[#s#tQ'S$iQ(s&UQ)U&nU)Y&s)Z+jW)a&w+m-T-{Q*Q']W*R'_,`-h.TQ+l)`S,_*S*TQ-Q+eQ-_,TQ-c,WQ.R-al.W-l.^._.a.z.|/R/j/o/t/y0U0Z0^Q/S.`Q/a.tQ/l/OU0P/u0S0[X0V/z0W0_0`R&Z#r!_!wYZ!P!Q!k%S%`%g'p'r's(O(W)g*g*h*k*q*t*v,h,i,k,l,o-m-p.f.g/ZR%^!vQ!{YQ%x#[Q&d#}Q&g$QR,{+YT.j-s/s!Y!jQ!n#c#p$R$d$p$u$v$w$x$y$z%e%j%p%q&`'O'g(q(|)j*o*x+w,v0gQ&X#kQ'c$oR*^'dR'l$|Q%V!mR/_.r'|_OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0rS#a_#b!P.[-l.^._.`.a.t.z.|/R/j/o/t/u/y/z0S0U0W0Z0[0^0_0`'|_OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0rT#a_#bT#^^#_R(o%xa(l%x(n(o+`,{-y-z.oT+[(k+]R-z,{Q$PsQ+l)aQ,^*RR-e,_X#}s$O$P&fQ&y$aQ'a$nQ'd$oR)s'SQ)b&wV-S+m-T-{ZgOn$j)t,PXkOn)t,PQ$k!TQ&z$bQ&{$cQ'^$mQ'b$oQ)q'RQ)x'WQ){'XQ)|'YQ*Z'`S*]'c'dQ+s)gQ+u)hQ+v)iQ+z)oS+|)r*[Q,Q)vQ,R)wS,S)y)zQ,d*^Q-V+rQ-W+tQ-Y+{S-Z+},OQ-`,UQ-b,VQ-|-XQ.O-[Q.P-^Q.Q-_Q.p-}Q.q.RQ/W.dR/r/XWkOn)t,PR#mjQ'`$nS)r'S'aR,O)sQ,]*RR-f,^Q*['`Q+})rR-[,OZiOjn)t,PQ'f$pR*`'gT-j,e-ku.c-l.^._.a.t.z.|/R/j/o/t/u/y0S0U0Z0[0^t.c-l.^._.a.t.z.|/R/j/o/t/u/y0S0U0Z0[0^Q/S.`X0V/z0W0_0`!P.Z-l.^._.`.a.t.z.|/R/j/o/t/u/y/z0S0U0W0Z0[0^0_0`Q.w.YR/f.xg.z.].{/b/i/n/|0O0Q0]0a0bu.b-l.^._.a.t.z.|/R/j/o/t/u/y0S0U0Z0[0^X.u.W.b/a0PR/c.tV0R/u0S0[R/X.dQnOS#on,PR,P)tQ&^#uR(x&^S%m#R#wS(_%m(bT(b%p&`Q%a!yQ%h!}W(P%a%h(U(YQ(U%eR(Y%jQ&i$RR)O&iQ(e%qQ*{(`T+R(e*{Q'n%OR*e'nS'q%R%SY*i'q*j,m-q.hU*j'r's'tU,m*k*l*mS-q,n,oR.h-rQ#Y]R%t#YQ#_^R%y#_Q(h%vS+W(h+XR+X(iQ+](kR,|+]Q#b_R%{#bQ#ebQ%}#cW&Q#e%}({+bQ({&cR+b0gQ$OsS&e$O&fR&f$PQ&v$_R)_&vQ&V#jR(t&VQ&m$VS)T&m+hR+h)UQ$Z{R&p$ZQ&t$]R)[&tQ+n)bR-U+nQ#hfR&S#hQ)f&zR+q)fQ&}$dS)m&})nR)n'OQ'V$kR)u'VQ'[$lS*P'[,ZR,Z*QQ,a*VR-i,aWjOn)t,PR#ljQ-k,eR.U-kd.{.]/b/i/n/|0O0Q0]0a0bR/h.{U.s.W/a0PR/`.sQ/{/nS0X/{0YR0Y/|S/v/b/cR0T/vQ.}.]R/k.}R!ZPXmOn)t,PWlOn)t,PR'T$jYfOn$j)t,PR&R#g[sOn#g$j)t,PR&d#}&dQOYZ[dnprxy}!P!Q!U!i!k!o!p!q!s!t#[#d#g#y#{#}$Q$h$j$}%S%Z%^%`%g%l%n%w%|&Z&_&j&k&u&x'P'W'Z'l'm'p'r's'w(O(W(^(d(g(p(r(z)^)e)g)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+U+V+Y+a+d+k,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0n0rQ!nTQ#caQ#poU$Rt%c(SS$d!R$gQ$p!XQ$u!cQ$v!dQ$w!eQ$x!fQ$y!gQ$z!hQ%e!zQ%j#OQ%p#SQ%q#TQ&`#xQ'O$eQ'g$qQ(q&OU(|&h(}+cW)j&|)l+x+yQ*o'|Q*x(]Q+w)kQ,v+QR0g0lQ!yYQ!}ZQ$b!PQ$c!QQ%R!kQ't%S^'{%`%g(O(W*q*t*v^*f'p*h,k,l-p.g/ZQ*l'rQ*m'sQ+t)gQ,j*gQ,n*kQ-n,hQ-o,iQ-r,oQ.e-mR/Y.f[bOn#g$j)t,P!^!vYZ!P!Q!k%S%`%g'p'r's(O(W)g*g*h*k*q*t*v,h,i,k,l,o-m-p.f.g/ZQ#R[Q#fdS#wrxQ$UyW$_}$Q'P)pS$l!U$hW${!i'm*d,gS%v#[+Y`&P#d%|(p(r(z+a-O0kQ&a#yQ&b#{Q&c#}Q'j$}Q'z%^W([%l(^*y*}Q(`%nQ(i%wQ(v&ZS(y&_0iQ)P&jQ)Q&kU)]&u)^+kQ)d&xQ)y'WY)}'Z*O,X,Y-dQ*b'lS*n'w0jW+P(d*z,s,wW+T(g+V,y,zQ+p)eQ,U)zQ,c*YQ,x+UQ-P+dQ-e,]Q-v,uQ.S-fR/q/VhUOn#d#g$j%|&_'w(p(r)t,P%U!uYZ[drxy}!P!Q!U!i!k#[#y#{#}$Q$h$}%S%^%`%g%l%n%w&Z&j&k&u&x'P'W'Z'l'm'p'r's(O(W(^(d(g(z)^)e)g)p)z*O*Y*d*g*h*k*q*t*v*y*z*}+U+V+Y+a+d+k,X,Y,],g,h,i,k,l,o,s,u,w,y,z-O-d-f-m-p.f.g/V/Z0i0j0kQ#qpW%W!o!s0d0nQ%X!pQ%Y!qQ%[!tQ%f0cS'v%Z0hQ'x0eQ'y0fQ,p*rQ-u,qS.i-s/sR0p0rU#uq.k0qR(w&][cOn#g$j)t,PZ!xY#[#}$Q+YQ#W[Q#zrR$TxQ%b!yQ%i!}Q%o#RQ'j${Q(V%eQ(Z%jQ(c%pQ(f%qQ*|(`Q,f*bQ-t,pQ.m-uR/].lQ$StQ(R%cR*s(SQ.l-sR/}/sR#QZR#V[R%Q!iQ%O!iV*c'm*d,g!Z!lQ!n#c#p$R$d$p$u$v$w$x$y$z%e%j%p%q&`'O'g(q(|)j*o*x+w,v0gR%T!kT#]^#_Q%x#[R,{+YQ(m%xS+_(n(oQ,}+`Q-x,{S.n-y-zR/^.oT+Z(k+]Q$`}Q&g$QQ)o'PR+{)pQ$XzQ)W&qR+i)XQ$XzQ&o$WQ)W&qR+i)XQ#khW$Vz$W&q)XQ$[{Q&r$ZZ)R&l)S+f+g-RR$^|R)c&wXlOn)t,PQ$f!RR'Q$gQ$m!UR'R$hR*X'_Q*V'_V-g,`-h.TQ.d-lQ/P.^R/Q._U.]-l.^._Q/U.aQ/b.tQ/g.zU/i.|/j/yQ/n/RQ/|/oQ0O/tU0Q/u0S0[Q0]0UQ0a0ZR0b0^R/T.`R/d.t",nodeNames:"\u26A0 print Escape { Comment Script AssignStatement * BinaryExpression BitOp BitOp BitOp BitOp ArithOp ArithOp @ ArithOp ** UnaryExpression ArithOp BitOp AwaitExpression await ) ( ParenthesizedExpression BinaryExpression or and CompareOp in not is UnaryExpression ConditionalExpression if else LambdaExpression lambda ParamList VariableName AssignOp , : NamedExpression AssignOp YieldExpression yield from TupleExpression ComprehensionExpression async for LambdaExpression ] [ ArrayExpression ArrayComprehensionExpression } { DictionaryExpression DictionaryComprehensionExpression SetExpression SetComprehensionExpression CallExpression ArgList AssignOp MemberExpression . PropertyName Number String FormatString FormatReplacement FormatSelfDoc FormatConversion FormatSpec FormatReplacement FormatSelfDoc ContinuedString Ellipsis None Boolean TypeDef AssignOp UpdateStatement UpdateOp ExpressionStatement DeleteStatement del PassStatement pass BreakStatement break ContinueStatement continue ReturnStatement return YieldStatement PrintStatement RaiseStatement raise ImportStatement import as ScopeStatement global nonlocal AssertStatement assert TypeDefinition type TypeParamList TypeParam StatementGroup ; IfStatement Body elif WhileStatement while ForStatement TryStatement try except finally WithStatement with FunctionDefinition def ParamList AssignOp TypeDef ClassDefinition class DecoratedStatement Decorator At MatchStatement match MatchBody MatchClause case CapturePattern LiteralPattern ArithOp ArithOp AsPattern OrPattern LogicOp AttributePattern SequencePattern MappingPattern StarPattern ClassPattern PatternArgList KeywordPattern KeywordPattern Guard",maxTerm:277,context:fS,nodeProps:[["isolate",-5,4,71,72,73,77,""],["group",-15,6,85,87,88,90,92,94,96,98,99,100,102,105,108,110,"Statement Statement",-22,8,18,21,25,40,49,50,56,57,60,61,62,63,64,67,70,71,72,79,80,81,82,"Expression",-10,114,116,119,121,122,126,128,133,135,138,"Statement",-9,143,144,147,148,150,151,152,153,154,"Pattern"],["openedBy",23,"(",54,"[",58,"{"],["closedBy",24,")",55,"]",59,"}"]],propSources:[uS],skippedNodes:[0,4],repeatNodeCount:34,tokenData:"!2|~R!`OX%TXY%oY[%T[]%o]p%Tpq%oqr'ars)Yst*xtu%Tuv,dvw-hwx.Uxy/tyz0[z{0r{|2S|}2p}!O3W!O!P4_!P!Q:Z!Q!R;k!R![>_![!]Do!]!^Es!^!_FZ!_!`Gk!`!aHX!a!b%T!b!cIf!c!dJU!d!eK^!e!hJU!h!i!#f!i!tJU!t!u!,|!u!wJU!w!x!.t!x!}JU!}#O!0S#O#P&o#P#Q!0j#Q#R!1Q#R#SJU#S#T%T#T#UJU#U#VK^#V#YJU#Y#Z!#f#Z#fJU#f#g!,|#g#iJU#i#j!.t#j#oJU#o#p!1n#p#q!1s#q#r!2a#r#s!2f#s$g%T$g;'SJU;'S;=`KW<%lOJU`%YT&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T`%lP;=`<%l%To%v]&n`%c_OX%TXY%oY[%T[]%o]p%Tpq%oq#O%T#O#P&o#P#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To&tX&n`OY%TYZ%oZ]%T]^%o^#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc'f[&n`O!_%T!_!`([!`#T%T#T#U(r#U#f%T#f#g(r#g#h(r#h#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc(cTmR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc(yT!mR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk)aV&n`&[ZOr%Trs)vs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk){V&n`Or%Trs*bs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk*iT&n`&^ZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To+PZS_&n`OY*xYZ%TZ]*x]^%T^#o*x#o#p+r#p#q*x#q#r+r#r;'S*x;'S;=`,^<%lO*x_+wTS_OY+rZ]+r^;'S+r;'S;=`,W<%lO+r_,ZP;=`<%l+ro,aP;=`<%l*xj,kV%rQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj-XT!xY&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj-oV%lQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk.]V&n`&ZZOw%Twx.rx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk.wV&n`Ow%Twx/^x#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk/eT&n`&]ZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk/{ThZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc0cTgR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk0yXVZ&n`Oz%Tz{1f{!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk1mVaR&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk2ZV%oZ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc2wTzR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To3_W%pZ&n`O!_%T!_!`-Q!`!a3w!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Td4OT&{S&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk4fX!fQ&n`O!O%T!O!P5R!P!Q%T!Q![6T![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk5WV&n`O!O%T!O!P5m!P#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk5tT!rZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti6[a!hX&n`O!Q%T!Q![6T![!g%T!g!h7a!h!l%T!l!m9s!m#R%T#R#S6T#S#X%T#X#Y7a#Y#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti7fZ&n`O{%T{|8X|}%T}!O8X!O!Q%T!Q![8s![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti8^V&n`O!Q%T!Q![8s![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti8z]!hX&n`O!Q%T!Q![8s![!l%T!l!m9s!m#R%T#R#S8s#S#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti9zT!hX&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk:bX%qR&n`O!P%T!P!Q:}!Q!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj;UV%sQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti;ro!hX&n`O!O%T!O!P=s!P!Q%T!Q![>_![!d%T!d!e?q!e!g%T!g!h7a!h!l%T!l!m9s!m!q%T!q!rA]!r!z%T!z!{Bq!{#R%T#R#S>_#S#U%T#U#V?q#V#X%T#X#Y7a#Y#^%T#^#_9s#_#c%T#c#dA]#d#l%T#l#mBq#m#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti=xV&n`O!Q%T!Q![6T![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti>fc!hX&n`O!O%T!O!P=s!P!Q%T!Q![>_![!g%T!g!h7a!h!l%T!l!m9s!m#R%T#R#S>_#S#X%T#X#Y7a#Y#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti?vY&n`O!Q%T!Q!R@f!R!S@f!S#R%T#R#S@f#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti@mY!hX&n`O!Q%T!Q!R@f!R!S@f!S#R%T#R#S@f#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiAbX&n`O!Q%T!Q!YA}!Y#R%T#R#SA}#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiBUX!hX&n`O!Q%T!Q!YA}!Y#R%T#R#SA}#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiBv]&n`O!Q%T!Q![Co![!c%T!c!iCo!i#R%T#R#SCo#S#T%T#T#ZCo#Z#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiCv]!hX&n`O!Q%T!Q![Co![!c%T!c!iCo!i#R%T#R#SCo#S#T%T#T#ZCo#Z#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%ToDvV{_&n`O!_%T!_!`E]!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TcEdT%{R&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkEzT#gZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkFbXmR&n`O!^%T!^!_F}!_!`([!`!a([!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TjGUV%mQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkGrV%zZ&n`O!_%T!_!`([!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkH`WmR&n`O!_%T!_!`([!`!aHx!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TjIPV%nQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkIoV_Q#}P&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%ToJ_]&n`&YS%uZO!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUoKZP;=`<%lJUoKge&n`&YS%uZOr%Trs)Ysw%Twx.Ux!Q%T!Q![JU![!c%T!c!tJU!t!uLx!u!}JU!}#R%T#R#SJU#S#T%T#T#fJU#f#gLx#g#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUoMRa&n`&YS%uZOr%TrsNWsw%Twx! vx!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUkN_V&n`&`ZOr%TrsNts#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkNyV&n`Or%Trs! `s#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk! gT&n`&bZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk! }V&n`&_ZOw%Twx!!dx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!!iV&n`Ow%Twx!#Ox#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!#VT&n`&aZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!#oe&n`&YS%uZOr%Trs!%Qsw%Twx!&px!Q%T!Q![JU![!c%T!c!tJU!t!u!(`!u!}JU!}#R%T#R#SJU#S#T%T#T#fJU#f#g!(`#g#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!%XV&n`&dZOr%Trs!%ns#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!%sV&n`Or%Trs!&Ys#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!&aT&n`&fZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!&wV&n`&cZOw%Twx!'^x#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!'cV&n`Ow%Twx!'xx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!(PT&n`&eZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!(ia&n`&YS%uZOr%Trs!)nsw%Twx!+^x!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!)uV&n`&hZOr%Trs!*[s#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!*aV&n`Or%Trs!*vs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!*}T&n`&jZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!+eV&n`&gZOw%Twx!+zx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!,PV&n`Ow%Twx!,fx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!,mT&n`&iZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!-Vi&n`&YS%uZOr%TrsNWsw%Twx! vx!Q%T!Q![JU![!c%T!c!dJU!d!eLx!e!hJU!h!i!(`!i!}JU!}#R%T#R#SJU#S#T%T#T#UJU#U#VLx#V#YJU#Y#Z!(`#Z#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUo!.}a&n`&YS%uZOr%Trs)Ysw%Twx.Ux!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!0ZT!XZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc!0qT!WR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj!1XV%kQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T~!1sO!]~k!1zV%jR&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T~!2fO![~i!2mT%tX&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T",tokenizers:[hS,oS,rS,cS,0,1,2,3,4],topRules:{Script:[0,5]},specialized:[{term:221,get:n=>pS[n]||-1}],tokenPrec:7668});var Eo=class{constructor(e,t,i,s){this.state=e,this.pos=t,this.explicit=i,this.view=s,this.abortListeners=[],this.abortOnDocChange=!1}tokenBefore(e){let t=Be(this.state).resolveInner(this.pos,-1);for(;t&&e.indexOf(t.name)<0;)t=t.parent;return t?{from:t.from,to:this.pos,text:this.state.sliceDoc(t.from,this.pos),type:t.type}:null}matchBefore(e){let t=this.state.doc.lineAt(this.pos),i=Math.max(t.from,this.pos-250),s=t.text.slice(i-t.from,this.pos-t.from),r=s.search(Vg(e,!1));return r<0?null:{from:i+r,to:this.pos,text:s.slice(r)}}get aborted(){return this.abortListeners==null}addEventListener(e,t,i){e=="abort"&&this.abortListeners&&(this.abortListeners.push(t),i&&i.onDocChange&&(this.abortOnDocChange=!0))}};function Lg(n){let e=Object.keys(n).join(""),t=/\w/.test(e);return t&&(e=e.replace(/\w/g,"")),`[${t?"\\w":""}${e.replace(/[^\w\s]/g,"\\$&")}]`}function mS(n){let e=Object.create(null),t=Object.create(null);for(let{label:s}of n){e[s[0]]=!0;for(let r=1;r<s.length;r++)t[s[r]]=!0}let i=Lg(e)+Lg(t)+"*$";return[new RegExp("^"+i),new RegExp(i)]}function eh(n){let e=n.map(s=>typeof s=="string"?{label:s}:s),[t,i]=e.every(s=>/^\w+$/.test(s.label))?[/\w*$/,/\w+$/]:mS(e);return s=>{let r=s.matchBefore(i);return r||s.explicit?{from:r?r.from:s.pos,options:e,validFor:t}:null}}function jg(n,e){return t=>{for(let i=Be(t.state).resolveInner(t.pos,-1);i;i=i.parent){if(n.indexOf(i.name)>-1)return null;if(i.type.isTop)break}return e(t)}}var Ao=class{constructor(e,t,i,s){this.completion=e,this.source=t,this.match=i,this.score=s}};function fs(n){return n.selection.main.from}function Vg(n,e){var t;let{source:i}=n,s=e&&i[0]!="^",r=i[i.length-1]!="$";return!s&&!r?n:new RegExp(`${s?"^":""}(?:${i})${r?"$":""}`,(t=n.flags)!==null&&t!==void 0?t:n.ignoreCase?"i":"")}var th=lt.define();function gS(n,e,t,i){let{main:s}=n.selection,r=t-s.from,o=i-s.from;return{...n.changeByRange(l=>{if(l!=s&&t!=i&&n.sliceDoc(l.from+r,l.from+o)!=n.sliceDoc(t,i))return{range:l};let a=n.toText(e);return{changes:{from:l.from+r,to:i==s.from?l.to:l.from+o,insert:a},range:M.cursor(l.from+r+a.length)}}),scrollIntoView:!0,userEvent:"input.complete"}}var Qg=new WeakMap;function _S(n){if(!Array.isArray(n))return n;let e=Qg.get(n);return e||Qg.set(n,e=eh(n)),e}var Ro=ne.define(),Fn=ne.define(),Vf=class{constructor(e){this.pattern=e,this.chars=[],this.folded=[],this.any=[],this.precise=[],this.byWord=[],this.score=0,this.matched=[];for(let t=0;t<e.length;){let i=Ge(e,t),s=ct(i);this.chars.push(i);let r=e.slice(t,t+s),o=r.toUpperCase();this.folded.push(Ge(o==r?r.toLowerCase():o,0)),t+=s}this.astral=e.length!=this.chars.length}ret(e,t){return this.score=e,this.matched=t,this}match(e){if(this.pattern.length==0)return this.ret(-100,[]);if(e.length<this.pattern.length)return null;let{chars:t,folded:i,any:s,precise:r,byWord:o}=this;if(t.length==1){let T=Ge(e,0),P=ct(T),I=P==e.length?0:-100;if(T!=t[0])if(T==i[0])I+=-200;else return null;return this.ret(I,[0,P])}let l=e.indexOf(this.pattern);if(l==0)return this.ret(e.length==this.pattern.length?0:-100,[0,this.pattern.length]);let a=t.length,f=0;if(l<0){for(let T=0,P=Math.min(e.length,200);T<P&&f<a;){let I=Ge(e,T);(I==t[f]||I==i[f])&&(s[f++]=T),T+=ct(I)}if(f<a)return null}let c=0,u=0,p=!1,y=0,v=-1,b=-1,O=/[a-z]/.test(e),k=!0;for(let T=0,P=Math.min(e.length,200),I=0;T<P&&u<a;){let E=Ge(e,T);l<0&&(c<a&&E==t[c]&&(r[c++]=T),y<a&&(E==t[y]||E==i[y]?(y==0&&(v=T),b=T+1,y++):y=0));let R,N=E<255?E>=48&&E<=57||E>=97&&E<=122?2:E>=65&&E<=90?1:0:(R=cn(E))!=R.toLowerCase()?1:R!=R.toUpperCase()?2:0;(!T||N==1&&O||I==0&&N!=0)&&(t[u]==E||i[u]==E&&(p=!0)?o[u++]=T:o.length&&(k=!1)),I=N,T+=ct(E)}return u==a&&o[0]==0&&k?this.result(-100+(p?-200:0),o,e):y==a&&v==0?this.ret(-200-e.length+(b==e.length?0:-100),[0,b]):l>-1?this.ret(-700-e.length,[l,l+this.pattern.length]):y==a?this.ret(-900-e.length,[v,b]):u==a?this.result(-100+(p?-200:0)+-700+(k?0:-1100),o,e):t.length==2?null:this.result((s[0]?-700:0)+-200+-1100,s,e)}result(e,t,i){let s=[],r=0;for(let o of t){let l=o+(this.astral?ct(Ge(i,o)):1);r&&s[r-1]==o?s[r-1]=l:(s[r++]=o,s[r++]=l)}return this.ret(e-i.length,s)}},Hf=class{constructor(e){this.pattern=e,this.matched=[],this.score=0,this.folded=e.toLowerCase()}match(e){if(e.length<this.pattern.length)return null;let t=e.slice(0,this.pattern.length),i=t==this.pattern?0:t.toLowerCase()==this.folded?-200:null;return i==null?null:(this.matched=[0,t.length],this.score=i+(e.length==this.pattern.length?0:-100),this)}},$e=W.define({combine(n){return wt(n,{activateOnTyping:!0,activateOnCompletion:()=>!1,activateOnTypingDelay:100,selectOnOpen:!0,override:null,closeOnBlur:!0,maxRenderedOptions:100,defaultKeymap:!0,tooltipClass:()=>"",optionClass:()=>"",aboveCursor:!1,icons:!0,addToOptions:[],positionInfo:yS,filterStrict:!1,compareCompletions:(e,t)=>(e.sortText||e.label).localeCompare(t.sortText||t.label),interactionDelay:75,updateSyncTime:100},{defaultKeymap:(e,t)=>e&&t,closeOnBlur:(e,t)=>e&&t,icons:(e,t)=>e&&t,tooltipClass:(e,t)=>i=>qg(e(i),t(i)),optionClass:(e,t)=>i=>qg(e(i),t(i)),addToOptions:(e,t)=>e.concat(t),filterStrict:(e,t)=>e||t})}});function qg(n,e){return n?e?n+" "+e:n:e}function yS(n,e,t,i,s,r){let o=n.textDirection==_e.RTL,l=o,a=!1,f="top",c,u,p=e.left-s.left,y=s.right-e.right,v=i.right-i.left,b=i.bottom-i.top;if(l&&p<Math.min(v,y)?l=!1:!l&&y<Math.min(v,p)&&(l=!0),v<=(l?p:y))c=Math.max(s.top,Math.min(t.top,s.bottom-b))-e.top,u=Math.min(400,l?p:y);else{a=!0,u=Math.min(400,(o?e.right:s.right-e.left)-30);let T=s.bottom-e.bottom;T>=b||T>e.top?c=t.bottom-e.top:(f="bottom",c=e.bottom-t.top)}let O=(e.bottom-e.top)/r.offsetHeight,k=(e.right-e.left)/r.offsetWidth;return{style:`${f}: ${c/O}px; max-width: ${u/k}px`,class:"cm-completionInfo-"+(a?o?"left-narrow":"right-narrow":l?"left":"right")}}var ih=ne.define();function bS(n){let e=n.addToOptions.slice();return n.icons&&e.push({render(t){let i=document.createElement("div");return i.classList.add("cm-completionIcon"),t.type&&i.classList.add(...t.type.split(/\s+/g).map(s=>"cm-completionIcon-"+s)),i.setAttribute("aria-hidden","true"),i},position:20}),e.push({render(t,i,s,r){let o=document.createElement("span");o.className="cm-completionLabel";let l=t.displayLabel||t.label,a=0;for(let f=0;f<r.length;){let c=r[f++],u=r[f++];c>a&&o.appendChild(document.createTextNode(l.slice(a,c)));let p=o.appendChild(document.createElement("span"));p.appendChild(document.createTextNode(l.slice(c,u))),p.className="cm-completionMatchedText",a=u}return a<l.length&&o.appendChild(document.createTextNode(l.slice(a))),o},position:50},{render(t){if(!t.detail)return null;let i=document.createElement("span");return i.className="cm-completionDetail",i.textContent=t.detail,i},position:80}),e.sort((t,i)=>t.position-i.position).map(t=>t.render)}function Wf(n,e,t){if(n<=t)return{from:0,to:n};if(e<0&&(e=0),e<=n>>1){let s=Math.floor(e/t);return{from:s*t,to:(s+1)*t}}let i=Math.ceil((n-e)/t);return{from:n-i*t,to:n-(i-1)*t}}var Uf=class{constructor(e,t,i){this.view=e,this.stateField=t,this.applyCompletion=i,this.info=null,this.infoDestroy=null,this.placeInfoReq={read:()=>this.measureInfo(),write:a=>this.placeInfo(a),key:this},this.space=null,this.currentClass="";let s=e.state.field(t),{options:r,selected:o}=s.open,l=e.state.facet($e);this.optionContent=bS(l),this.optionClass=l.optionClass,this.tooltipClass=l.tooltipClass,this.range=Wf(r.length,o,l.maxRenderedOptions),this.dom=document.createElement("div"),this.dom.className="cm-tooltip-autocomplete",this.updateTooltipClass(e.state),this.dom.addEventListener("mousedown",a=>{let{options:f}=e.state.field(t).open;for(let c=a.target,u;c&&c!=this.dom;c=c.parentNode)if(c.nodeName=="LI"&&(u=/-(\d+)$/.exec(c.id))&&+u[1]<f.length){this.applyCompletion(e,f[+u[1]]),a.preventDefault();return}if(a.target==this.list){let c=this.list.classList.contains("cm-completionListIncompleteTop")&&a.clientY<this.list.firstChild.getBoundingClientRect().top?this.range.from-1:this.list.classList.contains("cm-completionListIncompleteBottom")&&a.clientY>this.list.lastChild.getBoundingClientRect().bottom?this.range.to:null;c!=null&&(e.dispatch({effects:ih.of(c)}),a.preventDefault())}}),this.dom.addEventListener("focusout",a=>{let f=e.state.field(this.stateField,!1);f&&f.tooltip&&e.state.facet($e).closeOnBlur&&a.relatedTarget!=e.contentDOM&&e.dispatch({effects:Fn.of(null)})}),this.showOptions(r,s.id)}mount(){this.updateSel()}showOptions(e,t){this.list&&this.list.remove(),this.list=this.dom.appendChild(this.createListBox(e,t,this.range)),this.list.addEventListener("scroll",()=>{this.info&&this.view.requestMeasure(this.placeInfoReq)})}update(e){var t;let i=e.state.field(this.stateField),s=e.startState.field(this.stateField);if(this.updateTooltipClass(e.state),i!=s){let{options:r,selected:o,disabled:l}=i.open;(!s.open||s.open.options!=r)&&(this.range=Wf(r.length,o,e.state.facet($e).maxRenderedOptions),this.showOptions(r,i.id)),this.updateSel(),l!=((t=s.open)===null||t===void 0?void 0:t.disabled)&&this.dom.classList.toggle("cm-tooltip-autocomplete-disabled",!!l)}}updateTooltipClass(e){let t=this.tooltipClass(e);if(t!=this.currentClass){for(let i of this.currentClass.split(" "))i&&this.dom.classList.remove(i);for(let i of t.split(" "))i&&this.dom.classList.add(i);this.currentClass=t}}positioned(e){this.space=e,this.info&&this.view.requestMeasure(this.placeInfoReq)}updateSel(){let e=this.view.state.field(this.stateField),t=e.open;(t.selected>-1&&t.selected<this.range.from||t.selected>=this.range.to)&&(this.range=Wf(t.options.length,t.selected,this.view.state.facet($e).maxRenderedOptions),this.showOptions(t.options,e.id));let i=this.updateSelectedOption(t.selected);if(i){this.destroyInfo();let{completion:s}=t.options[t.selected],{info:r}=s;if(!r)return;let o=typeof r=="string"?document.createTextNode(r):r(s);if(!o)return;"then"in o?o.then(l=>{l&&this.view.state.field(this.stateField,!1)==e&&this.addInfoPane(l,s)}).catch(l=>tt(this.view.state,l,"completion info")):(this.addInfoPane(o,s),i.setAttribute("aria-describedby",this.info.id))}}addInfoPane(e,t){this.destroyInfo();let i=this.info=document.createElement("div");if(i.className="cm-tooltip cm-completionInfo",i.id="cm-completionInfo-"+Math.floor(Math.random()*65535).toString(16),e.nodeType!=null)i.appendChild(e),this.infoDestroy=null;else{let{dom:s,destroy:r}=e;i.appendChild(s),this.infoDestroy=r||null}this.dom.appendChild(i),this.view.requestMeasure(this.placeInfoReq)}updateSelectedOption(e){let t=null;for(let i=this.list.firstChild,s=this.range.from;i;i=i.nextSibling,s++)i.nodeName!="LI"||!i.id?s--:s==e?i.hasAttribute("aria-selected")||(i.setAttribute("aria-selected","true"),t=i):i.hasAttribute("aria-selected")&&(i.removeAttribute("aria-selected"),i.removeAttribute("aria-describedby"));return t&&OS(this.list,t),t}measureInfo(){let e=this.dom.querySelector("[aria-selected]");if(!e||!this.info)return null;let t=this.dom.getBoundingClientRect(),i=this.info.getBoundingClientRect(),s=e.getBoundingClientRect(),r=this.space;if(!r){let o=this.dom.ownerDocument.documentElement;r={left:0,top:0,right:o.clientWidth,bottom:o.clientHeight}}return s.top>Math.min(r.bottom,t.bottom)-10||s.bottom<Math.max(r.top,t.top)+10?null:this.view.state.facet($e).positionInfo(this.view,t,s,i,r,this.dom)}placeInfo(e){this.info&&(e?(e.style&&(this.info.style.cssText=e.style),this.info.className="cm-tooltip cm-completionInfo "+(e.class||"")):this.info.style.cssText="top: -1e6px")}createListBox(e,t,i){let s=document.createElement("ul");s.id=t,s.setAttribute("role","listbox"),s.setAttribute("aria-expanded","true"),s.setAttribute("aria-label",this.view.state.phrase("Completions")),s.addEventListener("mousedown",o=>{o.target==s&&o.preventDefault()});let r=null;for(let o=i.from;o<i.to;o++){let{completion:l,match:a}=e[o],{section:f}=l;if(f){let p=typeof f=="string"?f:f.name;if(p!=r&&(o>i.from||i.from==0))if(r=p,typeof f!="string"&&f.header)s.appendChild(f.header(f));else{let y=s.appendChild(document.createElement("completion-section"));y.textContent=p}}let c=s.appendChild(document.createElement("li"));c.id=t+"-"+o,c.setAttribute("role","option");let u=this.optionClass(l);u&&(c.className=u);for(let p of this.optionContent){let y=p(l,this.view.state,this.view,a);y&&c.appendChild(y)}}return i.from&&s.classList.add("cm-completionListIncompleteTop"),i.to<e.length&&s.classList.add("cm-completionListIncompleteBottom"),s}destroyInfo(){this.info&&(this.infoDestroy&&this.infoDestroy(),this.info.remove(),this.info=null)}destroy(){this.destroyInfo()}};function vS(n,e){return t=>new Uf(t,n,e)}function OS(n,e){let t=n.getBoundingClientRect(),i=e.getBoundingClientRect(),s=t.height/n.offsetHeight;i.top<t.top?n.scrollTop-=(t.top-i.top)/s:i.bottom>t.bottom&&(n.scrollTop+=(i.bottom-t.bottom)/s)}function Bg(n){return(n.boost||0)*100+(n.apply?10:0)+(n.info?5:0)+(n.type?1:0)}function wS(n,e){let t=[],i=null,s=null,r=c=>{t.push(c);let{section:u}=c.completion;if(u){i||(i=[]);let p=typeof u=="string"?u:u.name;i.some(y=>y.name==p)||i.push(typeof u=="string"?{name:p}:u)}},o=e.facet($e);for(let c of n)if(c.hasResult()){let u=c.result.getMatch;if(c.result.filter===!1)for(let p of c.result.options)r(new Ao(p,c.source,u?u(p):[],1e9-t.length));else{let p=e.sliceDoc(c.from,c.to),y,v=o.filterStrict?new Hf(p):new Vf(p);for(let b of c.result.options)if(y=v.match(b.label)){let O=b.displayLabel?u?u(b,y.matched):[]:y.matched,k=y.score+(b.boost||0);if(r(new Ao(b,c.source,O,k)),typeof b.section=="object"&&b.section.rank==="dynamic"){let{name:T}=b.section;s||(s=Object.create(null)),s[T]=Math.max(k,s[T]||-1e9)}}}}if(i){let c=Object.create(null),u=0,p=(y,v)=>(y.rank==="dynamic"&&v.rank==="dynamic"?s[v.name]-s[y.name]:0)||(typeof y.rank=="number"?y.rank:1e9)-(typeof v.rank=="number"?v.rank:1e9)||(y.name<v.name?-1:1);for(let y of i.sort(p))u-=1e5,c[y.name]=u;for(let y of t){let{section:v}=y.completion;v&&(y.score+=c[typeof v=="string"?v:v.name])}}let l=[],a=null,f=o.compareCompletions;for(let c of t.sort((u,p)=>p.score-u.score||f(u.completion,p.completion))){let u=c.completion;!a||a.label!=u.label||a.detail!=u.detail||a.type!=null&&u.type!=null&&a.type!=u.type||a.apply!=u.apply||a.boost!=u.boost?l.push(c):Bg(c.completion)>Bg(a)&&(l[l.length-1]=c),a=c.completion}return l}var Gf=class n{constructor(e,t,i,s,r,o){this.options=e,this.attrs=t,this.tooltip=i,this.timestamp=s,this.selected=r,this.disabled=o}setSelected(e,t){return e==this.selected||e>=this.options.length?this:new n(this.options,$g(t,e),this.tooltip,this.timestamp,e,this.disabled)}static build(e,t,i,s,r,o){if(s&&!o&&e.some(f=>f.isPending))return s.setDisabled();let l=wS(e,t);if(!l.length)return s&&e.some(f=>f.isPending)?s.setDisabled():null;let a=t.facet($e).selectOnOpen?0:-1;if(s&&s.selected!=a&&s.selected!=-1){let f=s.options[s.selected].completion;for(let c=0;c<l.length;c++)if(l[c].completion==f){a=c;break}}return new n(l,$g(i,a),{pos:e.reduce((f,c)=>c.hasResult()?Math.min(f,c.from):f,1e8),create:CS,above:r.aboveCursor},s?s.timestamp:Date.now(),a,!1)}map(e){return new n(this.options,this.attrs,{...this.tooltip,pos:e.mapPos(this.tooltip.pos)},this.timestamp,this.selected,this.disabled)}setDisabled(){return new n(this.options,this.attrs,this.tooltip,this.timestamp,this.selected,!0)}},Xf=class n{constructor(e,t,i){this.active=e,this.id=t,this.open=i}static start(){return new n(TS,"cm-ac-"+Math.floor(Math.random()*2e6).toString(36),null)}update(e){let{state:t}=e,i=t.facet($e),r=(i.override||t.languageDataAt("autocomplete",fs(t)).map(_S)).map(a=>(this.active.find(c=>c.source==a)||new pi(a,this.active.some(c=>c.state!=0)?1:0)).update(e,i));r.length==this.active.length&&r.every((a,f)=>a==this.active[f])&&(r=this.active);let o=this.open,l=e.effects.some(a=>a.is(sh));o&&e.docChanged&&(o=o.map(e.changes)),e.selection||r.some(a=>a.hasResult()&&e.changes.touchesRange(a.from,a.to))||!kS(r,this.active)||l?o=Gf.build(r,t,this.id,o,i,l):o&&o.disabled&&!r.some(a=>a.isPending)&&(o=null),!o&&r.every(a=>!a.isPending)&&r.some(a=>a.hasResult())&&(r=r.map(a=>a.hasResult()?new pi(a.source,0):a));for(let a of e.effects)a.is(ih)&&(o=o&&o.setSelected(a.value,this.id));return r==this.active&&o==this.open?this:new n(r,this.id,o)}get tooltip(){return this.open?this.open.tooltip:null}get attrs(){return this.open?this.open.attrs:this.active.length?xS:SS}};function kS(n,e){if(n==e)return!0;for(let t=0,i=0;;){for(;t<n.length&&!n[t].hasResult();)t++;for(;i<e.length&&!e[i].hasResult();)i++;let s=t==n.length,r=i==e.length;if(s||r)return s==r;if(n[t++].result!=e[i++].result)return!1}}var xS={"aria-autocomplete":"list"},SS={};function $g(n,e){let t={"aria-autocomplete":"list","aria-haspopup":"listbox","aria-controls":n};return e>-1&&(t["aria-activedescendant"]=n+"-"+e),t}var TS=[];function Hg(n,e){if(n.isUserEvent("input.complete")){let i=n.annotation(th);if(i&&e.activateOnCompletion(i))return 12}let t=n.isUserEvent("input.type");return t&&e.activateOnTyping?5:t?1:n.isUserEvent("delete.backward")?2:n.selection?8:n.docChanged?16:0}var pi=class n{constructor(e,t,i=!1){this.source=e,this.state=t,this.explicit=i}hasResult(){return!1}get isPending(){return this.state==1}update(e,t){let i=Hg(e,t),s=this;(i&8||i&16&&this.touches(e))&&(s=new n(s.source,0)),i&4&&s.state==0&&(s=new n(this.source,1)),s=s.updateFor(e,i);for(let r of e.effects)if(r.is(Ro))s=new n(s.source,1,r.value);else if(r.is(Fn))s=new n(s.source,0);else if(r.is(sh))for(let o of r.value)o.source==s.source&&(s=o);return s}updateFor(e,t){return this.map(e.changes)}map(e){return this}touches(e){return e.changes.touchesRange(fs(e.state))}},Mo=class n extends pi{constructor(e,t,i,s,r,o){super(e,3,t),this.limit=i,this.result=s,this.from=r,this.to=o}hasResult(){return!0}updateFor(e,t){var i;if(!(t&3))return this.map(e.changes);let s=this.result;s.map&&!e.changes.empty&&(s=s.map(s,e.changes));let r=e.changes.mapPos(this.from),o=e.changes.mapPos(this.to,1),l=fs(e.state);if(l>o||!s||t&2&&(fs(e.startState)==this.from||l<this.limit))return new pi(this.source,t&4?1:0);let a=e.changes.mapPos(this.limit);return PS(s.validFor,e.state,r,o)?new n(this.source,this.explicit,a,s,r,o):s.update&&(s=s.update(s,r,o,new Eo(e.state,l,!1)))?new n(this.source,this.explicit,a,s,s.from,(i=s.to)!==null&&i!==void 0?i:fs(e.state)):new pi(this.source,1,this.explicit)}map(e){if(e.empty)return this;let t=this.result.map?this.result.map(this.result,e):this.result;return t?new n(this.source,this.explicit,e.mapPos(this.limit),t,e.mapPos(this.from),e.mapPos(this.to,1)):new pi(this.source,0)}touches(e){return e.changes.touchesRange(this.from,this.to)}};function PS(n,e,t,i){if(!n)return!1;let s=e.sliceDoc(t,i);return typeof n=="function"?n(s,t,i,e):Vg(n,!0).test(s)}var sh=ne.define({map(n,e){return n.map(t=>t.map(e))}}),ft=Qe.define({create(){return Xf.start()},update(n,e){return n.update(e)},provide:n=>[Ha.from(n,e=>e.tooltip),z.contentAttributes.from(n,e=>e.attrs)]});function nh(n,e){let t=e.completion.apply||e.completion.label,i=n.state.field(ft).active.find(s=>s.source==e.source);return i instanceof Mo?(typeof t=="string"?n.dispatch({...gS(n.state,t,i.from,i.to),annotations:th.of(e.completion)}):t(n,e.completion,i.from,i.to),!0):!1}var CS=vS(ft,nh);function Co(n,e="option"){return t=>{let i=t.state.field(ft,!1);if(!i||!i.open||i.open.disabled||Date.now()-i.open.timestamp<t.state.facet($e).interactionDelay)return!1;let s=1,r;e=="page"&&(r=Ua(t,i.open.tooltip))&&(s=Math.max(2,Math.floor(r.dom.offsetHeight/r.dom.querySelector("li").offsetHeight)-1));let{length:o}=i.open.options,l=i.open.selected>-1?i.open.selected+s*(n?1:-1):n?0:o-1;return l<0?l=e=="page"?0:o-1:l>=o&&(l=e=="page"?o-1:0),t.dispatch({effects:ih.of(l)}),!0}}var ES=n=>{let e=n.state.field(ft,!1);return n.state.readOnly||!e||!e.open||e.open.selected<0||e.open.disabled||Date.now()-e.open.timestamp<n.state.facet($e).interactionDelay?!1:nh(n,e.open.options[e.open.selected])},zf=n=>n.state.field(ft,!1)?(n.dispatch({effects:Ro.of(!0)}),!0):!1,AS=n=>{let e=n.state.field(ft,!1);return!e||!e.active.some(t=>t.state!=0)?!1:(n.dispatch({effects:Fn.of(null)}),!0)},Jf=class{constructor(e,t){this.active=e,this.context=t,this.time=Date.now(),this.updates=[],this.done=void 0}},RS=50,MS=1e3,NS=qe.fromClass(class{constructor(n){this.view=n,this.debounceUpdate=-1,this.running=[],this.debounceAccept=-1,this.pendingStart=!1,this.composing=0;for(let e of n.state.field(ft).active)e.isPending&&this.startQuery(e)}update(n){let e=n.state.field(ft),t=n.state.facet($e);if(!n.selectionSet&&!n.docChanged&&n.startState.field(ft)==e)return;let i=n.transactions.some(r=>{let o=Hg(r,t);return o&8||(r.selection||r.docChanged)&&!(o&3)});for(let r=0;r<this.running.length;r++){let o=this.running[r];if(i||o.context.abortOnDocChange&&n.docChanged||o.updates.length+n.transactions.length>RS&&Date.now()-o.time>MS){for(let l of o.context.abortListeners)try{l()}catch(a){tt(this.view.state,a)}o.context.abortListeners=null,this.running.splice(r--,1)}else o.updates.push(...n.transactions)}this.debounceUpdate>-1&&clearTimeout(this.debounceUpdate),n.transactions.some(r=>r.effects.some(o=>o.is(Ro)))&&(this.pendingStart=!0);let s=this.pendingStart?50:t.activateOnTypingDelay;if(this.debounceUpdate=e.active.some(r=>r.isPending&&!this.running.some(o=>o.active.source==r.source))?setTimeout(()=>this.startUpdate(),s):-1,this.composing!=0)for(let r of n.transactions)r.isUserEvent("input.type")?this.composing=2:this.composing==2&&r.selection&&(this.composing=3)}startUpdate(){this.debounceUpdate=-1,this.pendingStart=!1;let{state:n}=this.view,e=n.field(ft);for(let t of e.active)t.isPending&&!this.running.some(i=>i.active.source==t.source)&&this.startQuery(t);this.running.length&&e.open&&e.open.disabled&&(this.debounceAccept=setTimeout(()=>this.accept(),this.view.state.facet($e).updateSyncTime))}startQuery(n){let{state:e}=this.view,t=fs(e),i=new Eo(e,t,n.explicit,this.view),s=new Jf(n,i);this.running.push(s),Promise.resolve(n.source(i)).then(r=>{s.context.aborted||(s.done=r||null,this.scheduleAccept())},r=>{this.view.dispatch({effects:Fn.of(null)}),tt(this.view.state,r)})}scheduleAccept(){this.running.every(n=>n.done!==void 0)?this.accept():this.debounceAccept<0&&(this.debounceAccept=setTimeout(()=>this.accept(),this.view.state.facet($e).updateSyncTime))}accept(){var n;this.debounceAccept>-1&&clearTimeout(this.debounceAccept),this.debounceAccept=-1;let e=[],t=this.view.state.facet($e),i=this.view.state.field(ft);for(let s=0;s<this.running.length;s++){let r=this.running[s];if(r.done===void 0)continue;if(this.running.splice(s--,1),r.done){let l=fs(r.updates.length?r.updates[0].startState:this.view.state),a=Math.min(l,r.done.from+(r.active.explicit?0:1)),f=new Mo(r.active.source,r.active.explicit,a,r.done,r.done.from,(n=r.done.to)!==null&&n!==void 0?n:l);for(let c of r.updates)f=f.update(c,t);if(f.hasResult()){e.push(f);continue}}let o=i.active.find(l=>l.source==r.active.source);if(o&&o.isPending)if(r.done==null){let l=new pi(r.active.source,0);for(let a of r.updates)l=l.update(a,t);l.isPending||e.push(l)}else this.startQuery(o)}(e.length||i.open&&i.open.disabled)&&this.view.dispatch({effects:sh.of(e)})}},{eventHandlers:{blur(n){let e=this.view.state.field(ft,!1);if(e&&e.tooltip&&this.view.state.facet($e).closeOnBlur){let t=e.open&&Ua(this.view,e.open.tooltip);(!t||!t.dom.contains(n.relatedTarget))&&setTimeout(()=>this.view.dispatch({effects:Fn.of(null)}),10)}},compositionstart(){this.composing=1},compositionend(){this.composing==3&&setTimeout(()=>this.view.dispatch({effects:Ro.of(!1)}),20),this.composing=0}}}),DS=typeof navigator=="object"&&/Win/.test(navigator.platform),IS=Ot.highest(z.domEventHandlers({keydown(n,e){let t=e.state.field(ft,!1);if(!t||!t.open||t.open.disabled||t.open.selected<0||n.key.length>1||n.ctrlKey&&!(DS&&n.altKey)||n.metaKey)return!1;let i=t.open.options[t.open.selected],s=t.active.find(o=>o.source==i.source),r=i.completion.commitCharacters||s.result.commitCharacters;return r&&r.indexOf(n.key)>-1&&nh(e,i),!1}})),Ug=z.baseTheme({".cm-tooltip.cm-tooltip-autocomplete":{"& > ul":{fontFamily:"monospace",whiteSpace:"nowrap",overflow:"hidden auto",maxWidth_fallback:"700px",maxWidth:"min(700px, 95vw)",minWidth:"250px",maxHeight:"10em",height:"100%",listStyle:"none",margin:0,padding:0,"& > li, & > completion-section":{padding:"1px 3px",lineHeight:1.2},"& > li":{overflowX:"hidden",textOverflow:"ellipsis",cursor:"pointer"},"& > completion-section":{display:"list-item",borderBottom:"1px solid silver",paddingLeft:"0.5em",opacity:.7}}},"&light .cm-tooltip-autocomplete ul li[aria-selected]":{background:"#17c",color:"white"},"&light .cm-tooltip-autocomplete-disabled ul li[aria-selected]":{background:"#777"},"&dark .cm-tooltip-autocomplete ul li[aria-selected]":{background:"#347",color:"white"},"&dark .cm-tooltip-autocomplete-disabled ul li[aria-selected]":{background:"#444"},".cm-completionListIncompleteTop:before, .cm-completionListIncompleteBottom:after":{content:'"\xB7\xB7\xB7"',opacity:.5,display:"block",textAlign:"center",cursor:"pointer"},".cm-tooltip.cm-completionInfo":{position:"absolute",padding:"3px 9px",width:"max-content",maxWidth:"400px",boxSizing:"border-box",whiteSpace:"pre-line"},".cm-completionInfo.cm-completionInfo-left":{right:"100%"},".cm-completionInfo.cm-completionInfo-right":{left:"100%"},".cm-completionInfo.cm-completionInfo-left-narrow":{right:"30px"},".cm-completionInfo.cm-completionInfo-right-narrow":{left:"30px"},"&light .cm-snippetField":{backgroundColor:"#00000022"},"&dark .cm-snippetField":{backgroundColor:"#ffffff22"},".cm-snippetFieldPosition":{verticalAlign:"text-top",width:0,height:"1.15em",display:"inline-block",margin:"0 -0.7px -.7em",borderLeft:"1.4px dotted #888"},".cm-completionMatchedText":{textDecoration:"underline"},".cm-completionDetail":{marginLeft:"0.5em",fontStyle:"italic"},".cm-completionIcon":{fontSize:"90%",width:".8em",display:"inline-block",textAlign:"center",paddingRight:".6em",opacity:"0.6",boxSizing:"content-box"},".cm-completionIcon-function, .cm-completionIcon-method":{"&:after":{content:"'\u0192'"}},".cm-completionIcon-class":{"&:after":{content:"'\u25CB'"}},".cm-completionIcon-interface":{"&:after":{content:"'\u25CC'"}},".cm-completionIcon-variable":{"&:after":{content:"'\u{1D465}'"}},".cm-completionIcon-constant":{"&:after":{content:"'\u{1D436}'"}},".cm-completionIcon-type":{"&:after":{content:"'\u{1D461}'"}},".cm-completionIcon-enum":{"&:after":{content:"'\u222A'"}},".cm-completionIcon-property":{"&:after":{content:"'\u25A1'"}},".cm-completionIcon-keyword":{"&:after":{content:"'\u{1F511}\uFE0E'"}},".cm-completionIcon-namespace":{"&:after":{content:"'\u25A2'"}},".cm-completionIcon-text":{"&:after":{content:"'abc'",fontSize:"50%",verticalAlign:"middle"}}}),Yf=class{constructor(e,t,i,s){this.field=e,this.line=t,this.from=i,this.to=s}},Kf=class n{constructor(e,t,i){this.field=e,this.from=t,this.to=i}map(e){let t=e.mapPos(this.from,-1,Le.TrackDel),i=e.mapPos(this.to,1,Le.TrackDel);return t==null||i==null?null:new n(this.field,t,i)}},Zf=class n{constructor(e,t){this.lines=e,this.fieldPositions=t}instantiate(e,t){let i=[],s=[t],r=e.doc.lineAt(t),o=/^\s*/.exec(r.text)[0];for(let a of this.lines){if(i.length){let f=o,c=/^\t*/.exec(a)[0].length;for(let u=0;u<c;u++)f+=e.facet(Ti);s.push(t+f.length-c),a=f+a.slice(c)}i.push(a),t+=a.length+1}let l=this.fieldPositions.map(a=>new Kf(a.field,s[a.line]+a.from,s[a.line]+a.to));return{text:i,ranges:l}}static parse(e){let t=[],i=[],s=[],r;for(let o of e.split(/\r\n?|\n/)){for(;r=/[#$]\{(?:(\d+)(?::([^{}]*))?|((?:\\[{}]|[^{}])*))\}/.exec(o);){let l=r[1]?+r[1]:null,a=r[2]||r[3]||"",f=-1;l===0&&(l=1e9);let c=a.replace(/\\[{}]/g,u=>u[1]);for(let u=0;u<t.length;u++)(l!=null?t[u].seq==l:c&&t[u].name==c)&&(f=u);if(f<0){let u=0;for(;u<t.length&&(l==null||t[u].seq!=null&&t[u].seq<l);)u++;t.splice(u,0,{seq:l,name:c}),f=u;for(let p of s)p.field>=f&&p.field++}for(let u of s)if(u.line==i.length&&u.from>r.index){let p=r[2]?3+(r[1]||"").length:2;u.from-=p,u.to-=p}s.push(new Yf(f,i.length,r.index,r.index+c.length)),o=o.slice(0,r.index)+a+o.slice(r.index+r[0].length)}o=o.replace(/\\([{}])/g,(l,a,f)=>{for(let c of s)c.line==i.length&&c.from>f&&(c.from--,c.to--);return a}),i.push(o)}return new n(i,s)}},LS=K.widget({widget:new class extends li{toDOM(){let n=document.createElement("span");return n.className="cm-snippetFieldPosition",n}ignoreEvent(){return!1}}}),QS=K.mark({class:"cm-snippetField"}),Xs=class n{constructor(e,t){this.ranges=e,this.active=t,this.deco=K.set(e.map(i=>(i.from==i.to?LS:QS).range(i.from,i.to)),!0)}map(e){let t=[];for(let i of this.ranges){let s=i.map(e);if(!s)return null;t.push(s)}return new n(t,this.active)}selectionInsideField(e){return e.ranges.every(t=>this.ranges.some(i=>i.field==this.active&&i.from<=t.from&&i.to>=t.to))}},jn=ne.define({map(n,e){return n&&n.map(e)}}),qS=ne.define(),Wn=Qe.define({create(){return null},update(n,e){for(let t of e.effects){if(t.is(jn))return t.value;if(t.is(qS)&&n)return new Xs(n.ranges,t.value)}return n&&e.docChanged&&(n=n.map(e.changes)),n&&e.selection&&!n.selectionInsideField(e.selection)&&(n=null),n},provide:n=>z.decorations.from(n,e=>e?e.deco:K.none)});function rh(n,e){return M.create(n.filter(t=>t.field==e).map(t=>M.range(t.from,t.to)))}function BS(n){let e=Zf.parse(n);return(t,i,s,r)=>{let{text:o,ranges:l}=e.instantiate(t.state,s),{main:a}=t.state.selection,f={changes:{from:s,to:r==a.from?a.to:r,insert:oe.of(o)},scrollIntoView:!0,annotations:i?[th.of(i),Re.userEvent.of("input.complete")]:void 0};if(l.length&&(f.selection=rh(l,0)),l.some(c=>c.field>0)){let c=new Xs(l,0),u=f.effects=[jn.of(c)];t.state.field(Wn,!1)===void 0&&u.push(ne.appendConfig.of([Wn,jS,VS,Ug]))}t.dispatch(t.state.update(f))}}function Gg(n){return({state:e,dispatch:t})=>{let i=e.field(Wn,!1);if(!i||n<0&&i.active==0)return!1;let s=i.active+n,r=n>0&&!i.ranges.some(o=>o.field==s+n);return t(e.update({selection:rh(i.ranges,s),effects:jn.of(r?null:new Xs(i.ranges,s)),scrollIntoView:!0})),!0}}var $S=({state:n,dispatch:e})=>n.field(Wn,!1)?(e(n.update({effects:jn.of(null)})),!0):!1,FS=Gg(1),WS=Gg(-1);var zS=[{key:"Tab",run:FS,shift:WS},{key:"Escape",run:$S}],Fg=W.define({combine(n){return n.length?n[0]:zS}}),jS=Ot.highest($s.compute([Fg],n=>n.facet(Fg)));function At(n,e){return{...e,apply:BS(n)}}var VS=z.domEventHandlers({mousedown(n,e){let t=e.state.field(Wn,!1),i;if(!t||(i=e.posAtCoords({x:n.clientX,y:n.clientY}))==null)return!1;let s=t.ranges.find(r=>r.from<=i&&r.to>=i);return!s||s.field==t.active?!1:(e.dispatch({selection:rh(t.ranges,s.field),effects:jn.of(t.ranges.some(r=>r.field>s.field)?new Xs(t.ranges,s.field):null),scrollIntoView:!0}),!0)}});var zn={brackets:["(","[","{","'",'"'],before:")]}:;>",stringPrefixes:[]},as=ne.define({map(n,e){let t=e.mapPos(n,-1,Le.TrackAfter);return t??void 0}}),oh=new class extends vt{};oh.startSide=1;oh.endSide=-1;var Xg=Qe.define({create(){return ce.empty},update(n,e){if(n=n.map(e.changes),e.selection){let t=e.state.doc.lineAt(e.selection.main.head);n=n.update({filter:i=>i>=t.from&&i<=t.to})}for(let t of e.effects)t.is(as)&&(n=n.update({add:[oh.range(t.value,t.value+1)]}));return n}});function Jg(){return[US,Xg]}var jf="()[]{}<>\xAB\xBB\xBB\xAB\uFF3B\uFF3D\uFF5B\uFF5D";function Yg(n){for(let e=0;e<jf.length;e+=2)if(jf.charCodeAt(e)==n)return jf.charAt(e+1);return cn(n<128?n:n+1)}function Kg(n,e){return n.languageDataAt("closeBrackets",e)[0]||zn}var HS=typeof navigator=="object"&&/Android\b/.test(navigator.userAgent),US=z.inputHandler.of((n,e,t,i)=>{if((HS?n.composing:n.compositionStarted)||n.state.readOnly)return!1;let s=n.state.selection.main;if(i.length>2||i.length==2&&ct(Ge(i,0))==1||e!=s.from||t!=s.to)return!1;let r=XS(n.state,i);return r?(n.dispatch(r),!0):!1}),GS=({state:n,dispatch:e})=>{if(n.readOnly)return!1;let i=Kg(n,n.selection.main.head).brackets||zn.brackets,s=null,r=n.changeByRange(o=>{if(o.empty){let l=JS(n.doc,o.head);for(let a of i)if(a==l&&No(n.doc,o.head)==Yg(Ge(a,0)))return{changes:{from:o.head-a.length,to:o.head+a.length},range:M.cursor(o.head-a.length)}}return{range:s=o}});return s||e(n.update(r,{scrollIntoView:!0,userEvent:"delete.backward"})),!s},Zg=[{key:"Backspace",run:GS}];function XS(n,e){let t=Kg(n,n.selection.main.head),i=t.brackets||zn.brackets;for(let s of i){let r=Yg(Ge(s,0));if(e==s)return r==s?ZS(n,s,i.indexOf(s+s+s)>-1,t):YS(n,s,r,t.before||zn.before);if(e==r&&e0(n,n.selection.main.from))return KS(n,s,r)}return null}function e0(n,e){let t=!1;return n.field(Xg).between(0,n.doc.length,i=>{i==e&&(t=!0)}),t}function No(n,e){let t=n.sliceString(e,e+2);return t.slice(0,ct(Ge(t,0)))}function JS(n,e){let t=n.sliceString(e-2,e);return ct(Ge(t,0))==t.length?t:t.slice(1)}function YS(n,e,t,i){let s=null,r=n.changeByRange(o=>{if(!o.empty)return{changes:[{insert:e,from:o.from},{insert:t,from:o.to}],effects:as.of(o.to+e.length),range:M.range(o.anchor+e.length,o.head+e.length)};let l=No(n.doc,o.head);return!l||/\s/.test(l)||i.indexOf(l)>-1?{changes:{insert:e+t,from:o.head},effects:as.of(o.head+e.length),range:M.cursor(o.head+e.length)}:{range:s=o}});return s?null:n.update(r,{scrollIntoView:!0,userEvent:"input.type"})}function KS(n,e,t){let i=null,s=n.changeByRange(r=>r.empty&&No(n.doc,r.head)==t?{changes:{from:r.head,to:r.head+t.length,insert:t},range:M.cursor(r.head+t.length)}:i={range:r});return i?null:n.update(s,{scrollIntoView:!0,userEvent:"input.type"})}function ZS(n,e,t,i){let s=i.stringPrefixes||zn.stringPrefixes,r=null,o=n.changeByRange(l=>{if(!l.empty)return{changes:[{insert:e,from:l.from},{insert:e,from:l.to}],effects:as.of(l.to+e.length),range:M.range(l.anchor+e.length,l.head+e.length)};let a=l.head,f=No(n.doc,a),c;if(f==e){if(Wg(n,a))return{changes:{insert:e+e,from:a},effects:as.of(a+e.length),range:M.cursor(a+e.length)};if(e0(n,a)){let p=t&&n.sliceDoc(a,a+e.length*3)==e+e+e?e+e+e:e;return{changes:{from:a,to:a+p.length,insert:p},range:M.cursor(a+p.length)}}}else{if(t&&n.sliceDoc(a-2*e.length,a)==e+e&&(c=zg(n,a-2*e.length,s))>-1&&Wg(n,c))return{changes:{insert:e+e+e+e,from:a},effects:as.of(a+e.length),range:M.cursor(a+e.length)};if(n.charCategorizer(a)(f)!=be.Word&&zg(n,a,s)>-1&&!e2(n,a,e,s))return{changes:{insert:e+e,from:a},effects:as.of(a+e.length),range:M.cursor(a+e.length)}}return{range:r=l}});return r?null:n.update(o,{scrollIntoView:!0,userEvent:"input.type"})}function Wg(n,e){let t=Be(n).resolveInner(e+1);return t.parent&&t.from==e}function e2(n,e,t,i){let s=Be(n).resolveInner(e,-1),r=i.reduce((o,l)=>Math.max(o,l.length),0);for(let o=0;o<5;o++){let l=n.sliceDoc(s.from,Math.min(s.to,s.from+t.length+r)),a=l.indexOf(t);if(!a||a>-1&&i.indexOf(l.slice(0,a))>-1){let c=s.firstChild;for(;c&&c.from==s.from&&c.to-c.from>t.length+a;){if(n.sliceDoc(c.to-t.length,c.to)==t)return!1;c=c.firstChild}return!0}let f=s.to==e&&s.parent;if(!f)break;s=f}return!1}function zg(n,e,t){let i=n.charCategorizer(e);if(i(n.sliceDoc(e-1,e))!=be.Word)return e;for(let s of t){let r=e-s.length;if(n.sliceDoc(r,e)==s&&i(n.sliceDoc(r-1,r))!=be.Word)return r}return-1}function t0(n={}){return[IS,ft,$e.of(n),NS,t2,Ug]}var lh=[{key:"Ctrl-Space",run:zf},{mac:"Alt-`",run:zf},{mac:"Alt-i",run:zf},{key:"Escape",run:AS},{key:"ArrowDown",run:Co(!0)},{key:"ArrowUp",run:Co(!1)},{key:"PageDown",run:Co(!0,"page")},{key:"PageUp",run:Co(!1,"page")},{key:"Enter",run:ES}],t2=Ot.highest($s.computeN([$e],n=>n.facet($e).defaultKeymap?[lh]:[]));var i0=new to,n0=new Set(["Script","Body","FunctionDefinition","ClassDefinition","LambdaExpression","ForStatement","MatchClause"]);function Do(n){return(e,t,i)=>{if(i)return!1;let s=e.node.getChild("VariableName");return s&&t(s,n),!0}}var i2={FunctionDefinition:Do("function"),ClassDefinition:Do("class"),ForStatement(n,e,t){if(t){for(let i=n.node.firstChild;i;i=i.nextSibling)if(i.name=="VariableName")e(i,"variable");else if(i.name=="in")break}},ImportStatement(n,e){var t,i;let{node:s}=n,r=((t=s.firstChild)===null||t===void 0?void 0:t.name)=="from";for(let o=s.getChild("import");o;o=o.nextSibling)o.name=="VariableName"&&((i=o.nextSibling)===null||i===void 0?void 0:i.name)!="as"&&e(o,r?"variable":"namespace")},AssignStatement(n,e){for(let t=n.node.firstChild;t;t=t.nextSibling)if(t.name=="VariableName")e(t,"variable");else if(t.name==":"||t.name=="AssignOp")break},ParamList(n,e){for(let t=null,i=n.node.firstChild;i;i=i.nextSibling)i.name=="VariableName"&&(!t||!/\*|AssignOp/.test(t.name))&&e(i,"variable"),t=i},CapturePattern:Do("variable"),AsPattern:Do("variable"),__proto__:null};function r0(n,e){let t=i0.get(e);if(t)return t;let i=[],s=!0;function r(o,l){let a=n.sliceString(o.from,o.to);i.push({label:a,type:l})}return e.cursor(xe.IncludeAnonymous).iterate(o=>{if(o.name){let l=i2[o.name];if(l&&l(o,r,s)||!s&&n0.has(o.name))return!1;s=!1}else if(o.to-o.from>8192){for(let l of r0(n,o.node))i.push(l);return!1}}),i0.set(e,i),i}var s0=/^[\w\xa1-\uffff][\w\d\xa1-\uffff]*$/,o0=["String","FormatString","Comment","PropertyName"];function s2(n){let e=Be(n.state).resolveInner(n.pos,-1);if(o0.indexOf(e.name)>-1)return null;let t=e.name=="VariableName"||e.to-e.from<20&&s0.test(n.state.sliceDoc(e.from,e.to));if(!t&&!n.explicit)return null;let i=[];for(let s=e;s;s=s.parent)n0.has(s.name)&&(i=i.concat(r0(n.state.doc,s)));return{options:i,from:t?e.from:n.pos,validFor:s0}}var n2=["__annotations__","__builtins__","__debug__","__doc__","__import__","__name__","__loader__","__package__","__spec__","False","None","True"].map(n=>({label:n,type:"constant"})).concat(["ArithmeticError","AssertionError","AttributeError","BaseException","BlockingIOError","BrokenPipeError","BufferError","BytesWarning","ChildProcessError","ConnectionAbortedError","ConnectionError","ConnectionRefusedError","ConnectionResetError","DeprecationWarning","EOFError","Ellipsis","EncodingWarning","EnvironmentError","Exception","FileExistsError","FileNotFoundError","FloatingPointError","FutureWarning","GeneratorExit","IOError","ImportError","ImportWarning","IndentationError","IndexError","InterruptedError","IsADirectoryError","KeyError","KeyboardInterrupt","LookupError","MemoryError","ModuleNotFoundError","NameError","NotADirectoryError","NotImplemented","NotImplementedError","OSError","OverflowError","PendingDeprecationWarning","PermissionError","ProcessLookupError","RecursionError","ReferenceError","ResourceWarning","RuntimeError","RuntimeWarning","StopAsyncIteration","StopIteration","SyntaxError","SyntaxWarning","SystemError","SystemExit","TabError","TimeoutError","TypeError","UnboundLocalError","UnicodeDecodeError","UnicodeEncodeError","UnicodeError","UnicodeTranslateError","UnicodeWarning","UserWarning","ValueError","Warning","ZeroDivisionError"].map(n=>({label:n,type:"type"}))).concat(["bool","bytearray","bytes","classmethod","complex","float","frozenset","int","list","map","memoryview","object","range","set","staticmethod","str","super","tuple","type"].map(n=>({label:n,type:"class"}))).concat(["abs","aiter","all","anext","any","ascii","bin","breakpoint","callable","chr","compile","delattr","dict","dir","divmod","enumerate","eval","exec","exit","filter","format","getattr","globals","hasattr","hash","help","hex","id","input","isinstance","issubclass","iter","len","license","locals","max","min","next","oct","open","ord","pow","print","property","quit","repr","reversed","round","setattr","slice","sorted","sum","vars","zip"].map(n=>({label:n,type:"function"}))),r2=[At("def ${name}(${params}):\n	${}",{label:"def",detail:"function",type:"keyword"}),At("for ${name} in ${collection}:\n	${}",{label:"for",detail:"loop",type:"keyword"}),At("while ${}:\n	${}",{label:"while",detail:"loop",type:"keyword"}),At("try:\n	${}\nexcept ${error}:\n	${}",{label:"try",detail:"/ except block",type:"keyword"}),At(`if \${}:
	
`,{label:"if",detail:"block",type:"keyword"}),At("if ${}:\n	${}\nelse:\n	${}",{label:"if",detail:"/ else block",type:"keyword"}),At("class ${name}:\n	def __init__(self, ${params}):\n			${}",{label:"class",detail:"definition",type:"keyword"}),At("import ${module}",{label:"import",detail:"statement",type:"keyword"}),At("from ${module} import ${names}",{label:"from",detail:"import",type:"keyword"})],o2=jg(o0,eh(n2.concat(r2)));function ah(n){let{node:e,pos:t}=n,i=n.lineIndent(t,-1),s=null;for(;;){let r=e.childBefore(t);if(r)if(r.name=="Comment")t=r.from;else if(r.name=="Body"||r.name=="MatchBody")n.baseIndentFor(r)+n.unit<=i&&(s=r),e=r;else if(r.name=="MatchClause")e=r;else if(r.type.is("Statement"))e=r;else break;else break}return s}function fh(n,e){let t=n.baseIndentFor(e),i=n.lineAt(n.pos,-1),s=i.from+i.text.length;return/^\s*($|#)/.test(i.text)&&n.node.to<s+100&&!/\S/.test(n.state.sliceDoc(s,n.node.to))&&n.lineIndent(n.pos,-1)<=t||/^\s*(else:|elif |except |finally:|case\s+[^=:]+:)/.test(n.textAfter)&&n.lineIndent(n.pos,-1)>t?null:t+n.unit}var hh=lo.define({name:"python",parser:Ig.configure({props:[_f.add({Body:n=>{var e;let t=/^\s*(#|$)/.test(n.textAfter)&&ah(n)||n.node;return(e=fh(n,t))!==null&&e!==void 0?e:n.continue()},MatchBody:n=>{var e;let t=ah(n);return(e=fh(n,t||n.node))!==null&&e!==void 0?e:n.continue()},IfStatement:n=>/^\s*(else:|elif )/.test(n.textAfter)?n.baseIndent:n.continue(),"ForStatement WhileStatement":n=>/^\s*else:/.test(n.textAfter)?n.baseIndent:n.continue(),TryStatement:n=>/^\s*(except[ :]|finally:|else:)/.test(n.textAfter)?n.baseIndent:n.continue(),MatchStatement:n=>/^\s*case /.test(n.textAfter)?n.baseIndent+n.unit:n.continue(),"TupleExpression ComprehensionExpression ParamList ArgList ParenthesizedExpression":ho({closing:")"}),"DictionaryExpression DictionaryComprehensionExpression SetExpression SetComprehensionExpression":ho({closing:"}"}),"ArrayExpression ArrayComprehensionExpression":ho({closing:"]"}),MemberExpression:n=>n.baseIndent+n.unit,"String FormatString":()=>null,Script:n=>{var e;let t=ah(n);return(e=t&&fh(n,t))!==null&&e!==void 0?e:n.continue()}}),km.add({"ArrayExpression DictionaryExpression SetExpression TupleExpression":xm,Body:(n,e)=>({from:n.from+1,to:n.to-(n.to==e.doc.length?0:1)}),"String FormatString":(n,e)=>({from:e.doc.lineAt(n.from).to,to:n.to})})]}),languageData:{closeBrackets:{brackets:["(","[","{","'",'"',"'''",'"""'],stringPrefixes:["f","fr","rf","r","u","b","br","rb","F","FR","RF","R","U","B","BR","RB"]},commentTokens:{line:"#"},indentOnInput:/^\s*([\}\]\)]|else:|elif |except |finally:|case\s+[^:]*:?)$/}});function l0(){return new ao(hh,[hh.data.of({autocomplete:s2}),hh.data.of({autocomplete:o2})])}var a0=typeof String.prototype.normalize=="function"?n=>n.normalize("NFKD"):n=>n,Ai=class{constructor(e,t,i=0,s=e.length,r,o){this.test=o,this.value={from:0,to:0,precise:!1},this.done=!1,this.matches=[],this.buffer="",this.bufferPos=0,this.iter=e.iterRange(i,s),this.bufferStart=i,this.normalize=r?l=>r(a0(l)):a0,this.query=this.normalize(t)}peek(){if(this.bufferPos==this.buffer.length){if(this.bufferStart+=this.buffer.length,this.iter.next(),this.iter.done)return-1;this.bufferPos=0,this.buffer=this.iter.value}return Ge(this.buffer,this.bufferPos)}next(){for(;this.matches.length;)this.matches.pop();return this.nextOverlapping()}nextOverlapping(){for(;;){let e=this.peek();if(e<0)return this.done=!0,this;let t=cn(e),i=this.bufferStart+this.bufferPos;this.bufferPos+=ct(e);let s=this.normalize(t);if(s.length)for(let r=0,o=i,l=!0;;r++){let a=s.charCodeAt(r),f=this.match(a,o,l,this.bufferPos+this.bufferStart,r==s.length-1);if(f)return this.value=f,this;if(r==s.length-1)break;l&&r<t.length&&t.charCodeAt(r)==a?o++:l=!1}}}match(e,t,i,s,r){let o=null;for(let l=0;l<this.matches.length;){let a=this.matches[l],f=!1;this.query.charCodeAt(a.index)==e&&(a.index==this.query.length-1?o={from:a.from,to:s,precise:r&&a.precise}:(a.index++,f=!0)),f?l++:this.matches.splice(l,1)}return this.query.charCodeAt(0)==e&&(this.query.length==1?o={from:t,to:s,precise:i&&r}:this.matches.push({from:t,index:1,precise:i})),o&&this.test&&!this.test(o.from,o.to,this.buffer,this.bufferStart)&&(o=null),o}};typeof Symbol<"u"&&(Ai.prototype[Symbol.iterator]=function(){return this});var c0={from:-1,to:-1,match:/.*/.exec(""),precise:!0},gh="gm"+(/x/.unicode==null?"":"u"),Qo=class{constructor(e,t,i,s=0,r=e.length){if(this.text=e,this.to=r,this.curLine="",this.done=!1,this.value=c0,/\\[sWDnr]|\n|\r|\[\^/.test(t))return new Bo(e,t,i,s,r);this.re=new RegExp(t,gh+(i!=null&&i.ignoreCase?"i":"")),this.test=i==null?void 0:i.test,this.iter=e.iter();let o=e.lineAt(s);this.curLineStart=o.from,this.matchPos=$o(e,s),this.getLine(this.curLineStart)}getLine(e){this.iter.next(e),this.iter.lineBreak?this.curLine="":(this.curLine=this.iter.value,this.curLineStart+this.curLine.length>this.to&&(this.curLine=this.curLine.slice(0,this.to-this.curLineStart)),this.iter.next())}nextLine(){this.curLineStart=this.curLineStart+this.curLine.length+1,this.curLineStart>this.to?this.curLine="":this.getLine(0)}next(){for(let e=this.matchPos-this.curLineStart;;){this.re.lastIndex=e;let t=this.matchPos<=this.to&&this.re.exec(this.curLine);if(t){let i=this.curLineStart+t.index,s=i+t[0].length;if(this.matchPos=$o(this.text,s+(i==s?1:0)),i==this.curLineStart+this.curLine.length&&this.nextLine(),(i<s||i>this.value.to)&&(!this.test||this.test(i,s,t)))return this.value={from:i,to:s,precise:!0,match:t},this;e=this.matchPos-this.curLineStart}else if(this.curLineStart+this.curLine.length<this.to)this.nextLine(),e=0;else return this.done=!0,this}}},ch=new WeakMap,qo=class n{constructor(e,t){this.from=e,this.text=t}get to(){return this.from+this.text.length}static get(e,t,i){let s=ch.get(e);if(!s||s.from>=i||s.to<=t){let l=new n(t,e.sliceString(t,i));return ch.set(e,l),l}if(s.from==t&&s.to==i)return s;let{text:r,from:o}=s;return o>t&&(r=e.sliceString(t,o)+r,o=t),s.to<i&&(r+=e.sliceString(s.to,i)),ch.set(e,new n(o,r)),new n(t,r.slice(t-o,i-o))}},Bo=class{constructor(e,t,i,s,r){this.text=e,this.to=r,this.done=!1,this.value=c0,this.matchPos=$o(e,s),this.re=new RegExp(t,gh+(i!=null&&i.ignoreCase?"i":"")),this.test=i==null?void 0:i.test,this.flat=qo.get(e,s,this.chunkEnd(s+5e3))}chunkEnd(e){return e>=this.to?this.to:this.text.lineAt(e).to}next(){for(;;){let e=this.re.lastIndex=this.matchPos-this.flat.from,t=this.re.exec(this.flat.text);if(t&&!t[0]&&t.index==e&&(this.re.lastIndex=e+1,t=this.re.exec(this.flat.text)),t){let i=this.flat.from+t.index,s=i+t[0].length;if((this.flat.to>=this.to||t.index+t[0].length<=this.flat.text.length-10)&&(!this.test||this.test(i,s,t)))return this.value={from:i,to:s,precise:!0,match:t},this.matchPos=$o(this.text,s+(i==s?1:0)),this}if(this.flat.to==this.to)return this.done=!0,this;this.flat=qo.get(this.text,this.flat.from,this.chunkEnd(this.flat.from+this.flat.text.length*2))}}};typeof Symbol<"u"&&(Qo.prototype[Symbol.iterator]=Bo.prototype[Symbol.iterator]=function(){return this});function l2(n){try{return new RegExp(n,gh),!0}catch{return!1}}function $o(n,e){if(e>=n.length)return e;let t=n.lineAt(e),i;for(;e<t.to&&(i=t.text.charCodeAt(e-t.from))>=56320&&i<57344;)e++;return e}var a2=n=>{let e=Zp(n,"cm-goto-line");if(e){let o=e.dom.querySelector("input[type=text]");return o&&o.select(),!0}let{state:t}=n,i=String(t.doc.lineAt(n.state.selection.main.head).number),{close:s,result:r}=Kp(n,{class:"cm-goto-line",label:t.phrase("Go to line"),input:{type:"text",name:"line",value:i},focus:!0,submitLabel:t.phrase("go")});return r.then(o=>{let l=o&&/^([+-])?(\d+)?(:\d+)?(%)?$/.exec(o.elements.line.value);if(!l){n.dispatch({effects:s});return}let a=t.doc.lineAt(t.selection.main.head),[,f,c,u,p]=l,y=u?+u.slice(1):0,v=c?+c:a.number;if(c&&p){let k=v/100;f&&(k=k*(f=="-"?-1:1)+a.number/t.doc.lines),v=Math.round(t.doc.lines*k)}else c&&f&&(v=v*(f=="-"?-1:1)+a.number);let b=t.doc.line(Math.max(1,Math.min(t.doc.lines,v))),O=M.cursor(b.from+Math.max(0,Math.min(y,b.length)));n.dispatch({effects:[s,z.scrollIntoView(O.from,{y:"center"})],selection:O})}),!0},f2={highlightWordAroundCursor:!1,minSelectionLength:1,maxMatches:100,wholeWords:!1},d0=W.define({combine(n){return wt(n,f2,{highlightWordAroundCursor:(e,t)=>e||t,minSelectionLength:Math.min,maxMatches:Math.min})}});function u0(n){let e=[p2,u2];return n&&e.push(d0.of(n)),e}var h2=K.mark({class:"cm-selectionMatch"}),c2=K.mark({class:"cm-selectionMatch cm-selectionMatch-main"});function f0(n,e,t,i){return(t==0||n(e.sliceDoc(t-1,t))!=be.Word)&&(i==e.doc.length||n(e.sliceDoc(i,i+1))!=be.Word)}function d2(n,e,t,i){return n(e.sliceDoc(t,t+1))==be.Word&&n(e.sliceDoc(i-1,i))==be.Word}var u2=qe.fromClass(class{constructor(n){this.decorations=this.getDeco(n)}update(n){(n.selectionSet||n.docChanged||n.viewportChanged)&&(this.decorations=this.getDeco(n.view))}getDeco(n){let e=n.state.facet(d0),{state:t}=n,i=t.selection;if(i.ranges.length>1)return K.none;let s=i.main,r,o=null;if(s.empty){if(!e.highlightWordAroundCursor)return K.none;let a=t.wordAt(s.head);if(!a)return K.none;o=t.charCategorizer(s.head),r=t.sliceDoc(a.from,a.to)}else{let a=s.to-s.from;if(a<e.minSelectionLength||a>200)return K.none;if(e.wholeWords){if(r=t.sliceDoc(s.from,s.to),o=t.charCategorizer(s.head),!(f0(o,t,s.from,s.to)&&d2(o,t,s.from,s.to)))return K.none}else if(r=t.sliceDoc(s.from,s.to),!r)return K.none}let l=[];for(let a of n.visibleRanges){let f=new Ai(t.doc,r,a.from,a.to);for(;!f.next().done;){let{from:c,to:u}=f.value;if((!o||f0(o,t,c,u))&&(s.empty&&c<=s.from&&u>=s.to?l.push(c2.range(c,u)):(c>=s.to||u<=s.from)&&l.push(h2.range(c,u)),l.length>e.maxMatches))return K.none}}return K.set(l)}},{decorations:n=>n.decorations}),p2=z.baseTheme({".cm-selectionMatch":{backgroundColor:"#99ff7780"},".cm-searchMatch .cm-selectionMatch":{backgroundColor:"transparent"}}),m2=({state:n,dispatch:e})=>{let{selection:t}=n,i=M.create(t.ranges.map(s=>n.wordAt(s.head)||M.cursor(s.head)),t.mainIndex);return i.eq(t)?!1:(e(n.update({selection:i})),!0)};function g2(n,e){let{main:t,ranges:i}=n.selection,s=n.wordAt(t.head),r=s&&s.from==t.from&&s.to==t.to;for(let o=!1,l=new Ai(n.doc,e,i[i.length-1].to);;)if(l.next(),l.done){if(o)return null;l=new Ai(n.doc,e,0,Math.max(0,i[i.length-1].from-1)),o=!0}else{if(o&&i.some(a=>a.from==l.value.from))continue;if(r){let a=n.wordAt(l.value.from);if(!a||a.from!=l.value.from||a.to!=l.value.to)continue}return l.value}}var _2=({state:n,dispatch:e})=>{let{ranges:t}=n.selection;if(t.some(r=>r.from===r.to))return m2({state:n,dispatch:e});let i=n.sliceDoc(t[0].from,t[0].to);if(n.selection.ranges.some(r=>n.sliceDoc(r.from,r.to)!=i))return!1;let s=g2(n,i);return s?(e(n.update({selection:n.selection.addRange(M.range(s.from,s.to),!1),effects:z.scrollIntoView(s.to)})),!0):!1},Ks=W.define({combine(n){return wt(n,{top:!1,caseSensitive:!1,literal:!1,regexp:!1,wholeWord:!1,createPanel:e=>new mh(e),scrollToMatch:e=>z.scrollIntoView(e)})}});var Fo=class{constructor(e){this.search=e.search,this.caseSensitive=!!e.caseSensitive,this.literal=!!e.literal,this.regexp=!!e.regexp,this.replace=e.replace||"",this.valid=!!this.search&&(!this.regexp||l2(this.search)),this.unquoted=this.unquote(this.search),this.wholeWord=!!e.wholeWord,this.test=e.test}unquote(e){return this.literal?e:e.replace(/\\([nrt\\])/g,(t,i)=>i=="n"?`
`:i=="r"?"\r":i=="t"?"	":"\\")}eq(e){return this.search==e.search&&this.replace==e.replace&&this.caseSensitive==e.caseSensitive&&this.regexp==e.regexp&&this.wholeWord==e.wholeWord&&this.test==e.test}create(){return this.regexp?new uh(this):new dh(this)}getCursor(e,t=0,i){let s=e.doc?e:pe.create({doc:e});return i==null&&(i=s.doc.length),this.regexp?Ys(this,s,t,i):Js(this,s,t,i)}},Wo=class{constructor(e){this.spec=e}};function y2(n,e,t){return(i,s,r,o)=>{if(t&&!t(i,s,r,o))return!1;let l=i>=o&&s<=o+r.length?r.slice(i-o,s-o):e.doc.sliceString(i,s);return n(l,e,i,s)}}function Js(n,e,t,i){let s;return n.wholeWord&&(s=b2(e.doc,e.charCategorizer(e.selection.main.head))),n.test&&(s=y2(n.test,e,s)),new Ai(e.doc,n.unquoted,t,i,n.caseSensitive?void 0:r=>r.toLowerCase(),s)}function b2(n,e){return(t,i,s,r)=>((r>t||r+s.length<i)&&(r=Math.max(0,t-2),s=n.sliceString(r,Math.min(n.length,i+2))),(e(zo(s,t-r))!=be.Word||e(jo(s,t-r))!=be.Word)&&(e(jo(s,i-r))!=be.Word||e(zo(s,i-r))!=be.Word))}var dh=class extends Wo{constructor(e){super(e)}nextMatch(e,t,i){let s=Js(this.spec,e,i,e.doc.length).nextOverlapping();if(s.done){let r=Math.min(e.doc.length,t+this.spec.unquoted.length);s=Js(this.spec,e,0,r).nextOverlapping()}return s.done||s.value.from==t&&s.value.to==i?null:s.value}prevMatchInRange(e,t,i){for(let s=i;;){let r=Math.max(t,s-1e4-this.spec.unquoted.length),o=Js(this.spec,e,r,s),l=null;for(;!o.nextOverlapping().done;)l=o.value;if(l)return l;if(r==t)return null;s-=1e4}}prevMatch(e,t,i){let s=this.prevMatchInRange(e,0,t);return s||(s=this.prevMatchInRange(e,Math.max(0,i-this.spec.unquoted.length),e.doc.length)),s&&(s.from!=t||s.to!=i)?s:null}getReplacement(e){return this.spec.unquote(this.spec.replace)}matchAll(e,t){let i=Js(this.spec,e,0,e.doc.length),s=[];for(;!i.next().done;){if(s.length>=t)return null;s.push(i.value)}return s}highlight(e,t,i,s){let r=Js(this.spec,e,Math.max(0,t-this.spec.unquoted.length),Math.min(i+this.spec.unquoted.length,e.doc.length));for(;!r.next().done;)s(r.value.from,r.value.to)}};function v2(n,e,t){return(i,s,r)=>(!t||t(i,s,r))&&n(r[0],e,i,s)}function Ys(n,e,t,i){let s;return n.wholeWord&&(s=O2(e.charCategorizer(e.selection.main.head))),n.test&&(s=v2(n.test,e,s)),new Qo(e.doc,n.search,{ignoreCase:!n.caseSensitive,test:s},t,i)}function zo(n,e){return n.slice(Ee(n,e,!1),e)}function jo(n,e){return n.slice(e,Ee(n,e))}function O2(n){return(e,t,i)=>!i[0].length||(n(zo(i.input,i.index))!=be.Word||n(jo(i.input,i.index))!=be.Word)&&(n(jo(i.input,i.index+i[0].length))!=be.Word||n(zo(i.input,i.index+i[0].length))!=be.Word)}var uh=class extends Wo{nextMatch(e,t,i){let s=Ys(this.spec,e,i,e.doc.length).next();return s.done&&(s=Ys(this.spec,e,0,t).next()),s.done?null:s.value}prevMatchInRange(e,t,i){for(let s=1;;s++){let r=Math.max(t,i-s*1e4),o=Ys(this.spec,e,r,i),l=null;for(;!o.next().done;)l=o.value;if(l&&(r==t||l.from>r+10))return l;if(r==t)return null}}prevMatch(e,t,i){return this.prevMatchInRange(e,0,t)||this.prevMatchInRange(e,i,e.doc.length)}getReplacement(e){return this.spec.unquote(this.spec.replace).replace(/\$([$&]|\d+)/g,(t,i)=>{if(i=="&")return e.match[0];if(i=="$")return"$";for(let s=i.length;s>0;s--){let r=+i.slice(0,s);if(r>0&&r<e.match.length)return e.match[r]+i.slice(s)}return t})}matchAll(e,t){let i=Ys(this.spec,e,0,e.doc.length),s=[];for(;!i.next().done;){if(s.length>=t)return null;s.push(i.value)}return s}highlight(e,t,i,s){let r=Ys(this.spec,e,Math.max(0,t-250),Math.min(i+250,e.doc.length));for(;!r.next().done;)s(r.value.from,r.value.to)}},Hn=ne.define(),_h=ne.define(),Ei=Qe.define({create(n){return new Vn(ph(n).create(),null)},update(n,e){for(let t of e.effects)t.is(Hn)?n=new Vn(t.value.create(),n.panel):t.is(_h)&&(n=new Vn(n.query,t.value?yh:null));return n},provide:n=>Tn.from(n,e=>e.panel)});var Vn=class{constructor(e,t){this.query=e,this.panel=t}},w2=K.mark({class:"cm-searchMatch"}),k2=K.mark({class:"cm-searchMatch cm-searchMatch-selected"}),x2=qe.fromClass(class{constructor(n){this.view=n,this.decorations=this.highlight(n.state.field(Ei))}update(n){let e=n.state.field(Ei);(e!=n.startState.field(Ei)||n.docChanged||n.selectionSet||n.viewportChanged)&&(this.decorations=this.highlight(e))}highlight({query:n,panel:e}){if(!e||!n.spec.valid)return K.none;let{view:t}=this,i=new Gt;for(let s=0,r=t.visibleRanges,o=r.length;s<o;s++){let{from:l,to:a}=r[s];for(;s<o-1&&a>r[s+1].from-2*250;)a=r[++s].to;n.highlight(t.state,l,a,(f,c)=>{let u=t.state.selection.ranges.some(p=>p.from==f&&p.to==c);i.add(f,c,u?k2:w2)})}return i.finish()}},{decorations:n=>n.decorations});function Un(n){return e=>{let t=e.state.field(Ei,!1);return t&&t.query.spec.valid?n(e,t):Uo(e)}}var Vo=Un((n,{query:e})=>{let{to:t}=n.state.selection.main,i=e.nextMatch(n.state,t,t);if(!i)return!1;let s=M.single(i.from,i.to),r=n.state.facet(Ks);return n.dispatch({selection:s,effects:[bh(n,i),r.scrollToMatch(s.main,n)],userEvent:"select.search"}),m0(n),!0}),Ho=Un((n,{query:e})=>{let{state:t}=n,{from:i}=t.selection.main,s=e.prevMatch(t,i,i);if(!s)return!1;let r=M.single(s.from,s.to),o=n.state.facet(Ks);return n.dispatch({selection:r,effects:[bh(n,s),o.scrollToMatch(r.main,n)],userEvent:"select.search"}),m0(n),!0}),S2=Un((n,{query:e})=>{let t=e.matchAll(n.state,1e3);return!t||!t.length?!1:(n.dispatch({selection:M.create(t.map(i=>M.range(i.from,i.to))),userEvent:"select.search.matches"}),!0)}),T2=({state:n,dispatch:e})=>{let t=n.selection;if(t.ranges.length>1||t.main.empty)return!1;let{from:i,to:s}=t.main,r=[],o=0;for(let l=new Ai(n.doc,n.sliceDoc(i,s));!l.next().done;){if(r.length>1e3)return!1;l.value.from==i&&(o=r.length),r.push(M.range(l.value.from,l.value.to))}return e(n.update({selection:M.create(r,o),userEvent:"select.search.matches"})),!0},h0=Un((n,{query:e})=>{let{state:t}=n,{from:i,to:s}=t.selection.main;if(t.readOnly)return!1;let r=e.nextMatch(t,i,i);if(!r)return!1;let o=r,l=[],a,f,c=[];o.precise?o.from==i&&o.to==s&&(f=t.toText(e.getReplacement(o)),l.push({from:o.from,to:o.to,insert:f}),o=e.nextMatch(t,o.from,o.to),c.push(z.announce.of(t.phrase("replaced match on line $",t.doc.lineAt(i).number)+"."))):o=e.nextMatch(t,o.from,o.to);let u=n.state.changes(l);return o&&(a=M.single(o.from,o.to).map(u),c.push(bh(n,o)),c.push(t.facet(Ks).scrollToMatch(a.main,n))),n.dispatch({changes:u,selection:a,effects:c,userEvent:"input.replace"}),!0}),P2=Un((n,{query:e})=>{if(n.state.readOnly)return!1;let t=[];for(let s of e.matchAll(n.state,1e9)){let{from:r,to:o,precise:l}=s;l&&t.push({from:r,to:o,insert:e.getReplacement(s)})}if(!t.length)return!1;let i=n.state.phrase("replaced $ matches",t.length)+".";return n.dispatch({changes:t,effects:z.announce.of(i),userEvent:"input.replace.all"}),!0});function yh(n){return n.state.facet(Ks).createPanel(n)}function ph(n,e){var t,i,s,r,o;let l=n.selection.main,a=l.empty||l.to>l.from+100?"":n.sliceDoc(l.from,l.to);if(e&&!a)return e;let f=n.facet(Ks);return new Fo({search:((t=e==null?void 0:e.literal)!==null&&t!==void 0?t:f.literal)?a:a.replace(/\n/g,"\\n"),caseSensitive:(i=e==null?void 0:e.caseSensitive)!==null&&i!==void 0?i:f.caseSensitive,literal:(s=e==null?void 0:e.literal)!==null&&s!==void 0?s:f.literal,regexp:(r=e==null?void 0:e.regexp)!==null&&r!==void 0?r:f.regexp,wholeWord:(o=e==null?void 0:e.wholeWord)!==null&&o!==void 0?o:f.wholeWord})}function p0(n){let e=Yr(n,yh);return e&&e.dom.querySelector("[main-field]")}function m0(n){let e=p0(n);e&&e==n.root.activeElement&&e.select()}var Uo=n=>{let e=n.state.field(Ei,!1);if(e&&e.panel){let t=p0(n);if(t&&t!=n.root.activeElement){let i=ph(n.state,e.query.spec);i.valid&&n.dispatch({effects:Hn.of(i)}),t.focus(),t.select()}}else n.dispatch({effects:[_h.of(!0),e?Hn.of(ph(n.state,e.query.spec)):ne.appendConfig.of(E2)]});return!0},g0=n=>{let e=n.state.field(Ei,!1);if(!e||!e.panel)return!1;let t=Yr(n,yh);return t&&t.dom.contains(n.root.activeElement)&&n.focus(),n.dispatch({effects:_h.of(!1)}),!0},_0=[{key:"Mod-f",run:Uo,scope:"editor search-panel"},{key:"F3",run:Vo,shift:Ho,scope:"editor search-panel",preventDefault:!0},{key:"Mod-g",run:Vo,shift:Ho,scope:"editor search-panel",preventDefault:!0},{key:"Escape",run:g0,scope:"editor search-panel"},{key:"Mod-Shift-l",run:T2},{key:"Mod-Alt-g",run:a2},{key:"Mod-d",run:_2,preventDefault:!0}],mh=class{constructor(e){this.view=e;let t=this.query=e.state.field(Ei).query.spec;this.commit=this.commit.bind(this),this.searchField=Ae("input",{value:t.search,placeholder:mt(e,"Find"),"aria-label":mt(e,"Find"),class:"cm-textfield",name:"search",form:"","main-field":"true",onchange:this.commit,onkeyup:this.commit}),this.replaceField=Ae("input",{value:t.replace,placeholder:mt(e,"Replace"),"aria-label":mt(e,"Replace"),class:"cm-textfield",name:"replace",form:"",onchange:this.commit,onkeyup:this.commit}),this.caseField=Ae("input",{type:"checkbox",name:"case",form:"",checked:t.caseSensitive,onchange:this.commit}),this.reField=Ae("input",{type:"checkbox",name:"re",form:"",checked:t.regexp,onchange:this.commit}),this.wordField=Ae("input",{type:"checkbox",name:"word",form:"",checked:t.wholeWord,onchange:this.commit});function i(s,r,o){return Ae("button",{class:"cm-button",name:s,onclick:r,type:"button"},o)}this.dom=Ae("div",{onkeydown:s=>this.keydown(s),class:"cm-search"},[this.searchField,i("next",()=>Vo(e),[mt(e,"next")]),i("prev",()=>Ho(e),[mt(e,"previous")]),i("select",()=>S2(e),[mt(e,"all")]),Ae("label",null,[this.caseField,mt(e,"match case")]),Ae("label",null,[this.reField,mt(e,"regexp")]),Ae("label",null,[this.wordField,mt(e,"by word")]),...e.state.readOnly?[]:[Ae("br"),this.replaceField,i("replace",()=>h0(e),[mt(e,"replace")]),i("replaceAll",()=>P2(e),[mt(e,"replace all")])],Ae("button",{name:"close",onclick:()=>g0(e),"aria-label":mt(e,"close"),type:"button"},["\xD7"])])}commit(){let e=new Fo({search:this.searchField.value,caseSensitive:this.caseField.checked,regexp:this.reField.checked,wholeWord:this.wordField.checked,replace:this.replaceField.value});e.eq(this.query)||(this.query=e,this.view.dispatch({effects:Hn.of(e)}))}keydown(e){zp(this.view,e,"search-panel")?e.preventDefault():e.keyCode==13&&e.target==this.searchField?(e.preventDefault(),(e.shiftKey?Ho:Vo)(this.view)):e.keyCode==13&&e.target==this.replaceField&&(e.preventDefault(),h0(this.view))}update(e){for(let t of e.transactions)for(let i of t.effects)i.is(Hn)&&!i.value.eq(this.query)&&this.setQuery(i.value)}setQuery(e){this.query=e,this.searchField.value=e.search,this.replaceField.value=e.replace,this.caseField.checked=e.caseSensitive,this.reField.checked=e.regexp,this.wordField.checked=e.wholeWord}mount(){this.searchField.select()}get pos(){return 80}get top(){return this.view.state.facet(Ks).top}};function mt(n,e){return n.state.phrase(e)}var Io=30,Lo=/[\s\.,:;?!]/;function bh(n,{from:e,to:t}){let i=n.state.doc.lineAt(e),s=n.state.doc.lineAt(t).to,r=Math.max(i.from,e-Io),o=Math.min(s,t+Io),l=n.state.sliceDoc(r,o);if(r!=i.from){for(let a=0;a<Io;a++)if(!Lo.test(l[a+1])&&Lo.test(l[a])){l=l.slice(a);break}}if(o!=s){for(let a=l.length-1;a>l.length-Io;a--)if(!Lo.test(l[a-1])&&Lo.test(l[a])){l=l.slice(0,a);break}}return z.announce.of(`${n.state.phrase("current match")}. ${l} ${n.state.phrase("on line")} ${i.number}.`)}var C2=z.baseTheme({".cm-panel.cm-search":{padding:"2px 6px 4px",position:"relative","& [name=close]":{position:"absolute",top:"0",right:"4px",backgroundColor:"inherit",border:"none",font:"inherit",padding:0,margin:0},"& input, & button, & label":{margin:".2em .6em .2em 0"},"& input[type=checkbox]":{marginRight:".2em"},"& label":{fontSize:"80%",whiteSpace:"pre"}},"&light .cm-searchMatch":{backgroundColor:"#ffff0054"},"&dark .cm-searchMatch":{backgroundColor:"#00ffff8a"},"&light .cm-searchMatch-selected":{backgroundColor:"#ff6a0054"},"&dark .cm-searchMatch-selected":{backgroundColor:"#ff00ff8a"}}),E2=[Ei,Ot.low(x2),C2];var Gn=se(ii(),1),Xn=se(Qi(),1),A2=z.theme({"&":{color:"#e6edf7",backgroundColor:"transparent",height:"100%",fontSize:"var(--code-size, 14px)"},".cm-scroller":{fontFamily:'"JetBrains Mono", "Fira Code", monospace',lineHeight:"1.55",overflow:"auto"},".cm-content":{caretColor:"#ffd92e",padding:"10px 0 30vh"},".cm-cursor, .cm-dropCursor":{borderLeftColor:"#ffd92e",borderLeftWidth:"2px"},"&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection":{backgroundColor:"rgba(109,140,255,.32) !important"},".cm-gutters":{backgroundColor:"rgba(9,13,32,.85)",color:"#4b5b7a",border:"none",borderRight:"1px solid rgba(170,185,255,.08)"},".cm-activeLineGutter":{backgroundColor:"rgba(255,217,46,.08)",color:"#9fb4d8"},".cm-activeLine":{backgroundColor:"rgba(170,185,255,.06)"},".cm-matchingBracket":{backgroundColor:"rgba(255,217,46,.2)",outline:"1px solid rgba(255,217,46,.5)"},".cm-tooltip":{backgroundColor:"#171e42",color:"#e6edf7",border:"1px solid rgba(170,185,255,.18)",borderRadius:"12px",overflow:"hidden"},".cm-tooltip-autocomplete > ul > li":{padding:"6px 10px !important"},".cm-tooltip-autocomplete > ul > li[aria-selected]":{backgroundColor:"rgba(109,140,255,.3)",color:"#fff"},".cm-completionDetail":{color:"#7c8db0",fontStyle:"normal",marginLeft:"8px"},".cm-panels":{backgroundColor:"#131a3b",color:"#e6edf7"},".cm-searchMatch":{backgroundColor:"rgba(245,158,11,.3)"},".cm-err-line":{backgroundColor:"rgba(239,68,68,.16)"}},{dark:!0}),R2=js.define([{tag:[A.keyword,A.controlKeyword,A.definitionKeyword,A.moduleKeyword,A.operatorKeyword],color:"#c792ea"},{tag:[A.bool,A.null,A.self],color:"#f78c6c"},{tag:[A.string,A.special(A.string)],color:"#c3e88d"},{tag:A.comment,color:"#5c6f94",fontStyle:"italic"},{tag:A.number,color:"#f78c6c"},{tag:[A.function(A.definition(A.variableName)),A.definition(A.className)],color:"#ffb86c",fontWeight:"600"},{tag:A.function(A.variableName),color:"#ffb86c"},{tag:A.className,color:"#ffcb6b"},{tag:A.propertyName,color:"#82aaff"},{tag:A.meta,color:"#ff79c6"},{tag:A.operator,color:"#89ddff"}]),M2={module:["gpiozero","RPi.GPIO","time","machine","utime","random","math","neopixel","dht","network","rp2","board","adafruit_dht","signal","os","sys","json","collections","datetime"],class:["LED","PWMLED","Button","Buzzer","TonalBuzzer","RGBLED","Motor","Robot","Servo","AngularServo","DistanceSensor","MotionSensor","LightSensor","LineSensor","MCP3008","TrafficLights","LEDBoard","LEDBarGraph","OutputDevice","DigitalInputDevice","CPUTemperature","Pin","PWM","ADC","Timer","I2C","SPI","UART","RTC","WDT","NeoPixel","DHT11","DHT22","WLAN","Signal"],function:["print","input","range","len","int","float","str","list","dict","tuple","set","abs","min","max","sum","round","sorted","enumerate","zip","isinstance","open","help","dir","type","sleep","sleep_ms","sleep_us","ticks_ms","ticks_us","ticks_diff","pause","setmode","setup","output","cleanup","setwarnings","add_event_detect","wait_for_edge","event_detected","on","off","toggle","blink","pulse","value","when_pressed","when_released","when_held","when_motion","wait_for_press","wait_for_release","is_pressed","distance","forward","backward","stop","freq","duty_u16","read_u16","irq","init","deinit","write","scan","measure","temperature","humidity","connect","isconnected","ifconfig"],constant:["BCM","BOARD","OUT","IN","HIGH","LOW","PUD_UP","PUD_DOWN","RISING","FALLING","BOTH","IRQ_RISING","IRQ_FALLING","PULL_UP","PULL_DOWN","OUT","True","False","None"]},N2=[["while True","while True:\n    ${}","loop forever"],["for in range","for ${i} in range(${10}):\n    ${}","counted loop"],["def","def ${name}(${}):\n    ${pass}","function"],["if","if ${cond}:\n    ${}","if block"],["try except",`try:
    \${}
except KeyboardInterrupt:
    \${pass}`,"stop with Ctrl+C"],["from gpiozero import","from gpiozero import ${LED}","gpiozero"],["import RPi.GPIO as GPIO","import RPi.GPIO as GPIO","RPi.GPIO"],["from machine import Pin","from machine import Pin","Pico"]];function D2(n){let e=n.matchBefore(/[\w.]*/);if(!e||e.from===e.to&&!n.explicit)return null;let t=[];for(let[s,r,o]of N2)t.push(At(r,{label:s,detail:o,type:"keyword",boost:1}));for(let[s,r]of Object.entries(M2))for(let o of r)t.push({label:o,type:s==="module"?"namespace":s});for(let s of["import","from","def","class","return","while","for","in","if","elif","else","try","except","finally","with","as","pass","break","continue","lambda","global","nonlocal","and","or","not","is","yield","async","await","raise","assert","del"])t.push({label:s,type:"keyword"});let i=new Set(t.map(s=>s.label));for(let s of n.state.doc.toString().matchAll(/\b[A-Za-z_]\w{2,}\b/g))i.has(s[0])||(i.add(s[0]),t.push({label:s[0],type:"variable"}));return{from:e.from+(e.text.lastIndexOf(".")+1),options:t,validFor:/^\w*$/}}var Go=class{constructor(e,{code:t="",onChange:i,fontSize:s=14}={}){this.onChange=i,this.ro=new Ss,this.wrap=(0,Gn.h)("div",{class:"code-wrap py-wrap"}),this.cmHost=(0,Gn.h)("div",{class:"code-cm py-cm"}),this.wrap.append(this.cmHost,this.symbolBar()),e.appendChild(this.wrap),this.setFontSize(s),this.view=new z({parent:this.cmHost,state:this.makeState(t)})}makeState(e){return pe.create({doc:e,extensions:[im(),sm(),Wm(),Up(),wm(),Am(),Jg(),t0({override:[D2],icons:!1}),Xp(),u0(),Ti.of("    "),pe.tabSize.of(4),$s.of([...Zg,...mg,..._0,...Vm,...lh,gg,{key:"Mod-/",run:wf}]),l0(),Tm(R2),A2,z.lineWrapping,this.ro.of(pe.readOnly.of(!1)),z.updateListener.of(t=>{t.docChanged&&this.onChange&&!this.silent&&this.onChange(t.state.doc.toString())}),z.domEventHandlers({focus:()=>this.wrap.classList.add("focused"),blur:()=>setTimeout(()=>{this.view.hasFocus||this.wrap.classList.remove("focused")},150)})]})}symbolBar(){let e=(0,Gn.h)("div",{class:"symbol-bar"}),t=r=>r.preventDefault(),i=r=>()=>{this.view.dispatch(this.view.state.replaceSelection(r)),this.view.focus()},s=(r,o,l="")=>{let a=(0,Gn.h)("button",{class:"sym "+l,onclick:o});return r.startsWith("<svg")?a.innerHTML=r:a.textContent=r,a.addEventListener("pointerdown",t),a.addEventListener("mousedown",t),a};return e.append(s("\u21E5",()=>{vo(this.view),this.view.focus()}),s("\u21E4",()=>{Oo(this.view),this.view.focus()}),s((0,Xn.icon)("arrowLeft",18),()=>{go(this.view),this.view.focus()},"sym-icon"),s((0,Xn.icon)("forward",18),()=>{_o(this.view),this.view.focus()},"sym-icon"),...[":","(",")",'"',"'","=","[","]","_",".",",","#","+","-","*","/","<",">","{","}"].map(r=>s(r,i(r))),s((0,Xn.icon)("undo",18),()=>{Qn(this.view),this.view.focus()},"sym-icon"),s((0,Xn.icon)("redo",18),()=>{Hs(this.view),this.view.focus()},"sym-icon")),e}get value(){return this.view.state.doc.toString()}load(e){this.silent=!0,this.view.setState(this.makeState(e)),this.silent=!1}setFontSize(e){this.wrap.style.setProperty("--code-size",e+"px"),this.fontSize=e}setReadOnly(e){this.view.dispatch({effects:this.ro.reconfigure(pe.readOnly.of(e))})}focus(){this.view.focus()}search(){Uo(this.view)}undo(){Qn(this.view)}redo(){Hs(this.view)}gotoLine(e){if(!(e>0&&e<=this.view.state.doc.lines))return;let t=this.view.state.doc.line(e);this.view.dispatch({selection:{anchor:t.from,head:t.to},scrollIntoView:!0})}refresh(){this.view.requestMeasure()}};var st=se(ii(),1);var cs=se($i(),1),vh="pi",hs="raspberrypi",Xo=["apt","apt-get","basename","cal","cat","cd","chmod","clear","cp","date","df","dirname","echo","env","exit","export","false","fastfetch","find","free","grep","head","help","history","hostname","i2cdetect","id","ifconfig","ip","kill","logout","ls","lsb_release","lscpu","man","mkdir","mv","nano","neofetch","pinctrl","pinout","ping","pip","pip3","poweroff","ps","pwd","python","python3","raspi-config","raspi-gpio","reboot","rm","rmdir","rpicam-hello","shutdown","sleep","sudo","tail","thonny","top","touch","tree","true","uname","uptime","vcgencmd","vi","vim","wc","whoami","which","xdg-open","curl","wget","nslookup","iwgetid","nmcli","chromium-browser","chromium","mosquitto_pub","mosquitto_sub","systemctl"],Jo=class{constructor(e){this.ctx=e,this.sys=e.sys,this.cwd="/home/pi",this.prevCwd=this.cwd,this.env={HOME:"/home/pi",USER:vh,SHELL:"/bin/bash",PATH:"/home/pi/.local/bin:/usr/local/bin:/usr/bin:/bin",LANG:"en_GB.UTF-8",TERM:"xterm-256color"},this.status=0,this.hist=[],this.con=new bs({cls:"term",onKey:t=>this.key(t),extraKeys:[["Ctrl+C",()=>this.ctrlC()],["Tab",()=>this.complete()],["\u2191",t=>t.histMove(-1)],["\u2193",t=>t.histMove(1)],["Ctrl+D",()=>this.ctrlD()],["Ctrl+L",()=>{this.con.clear()}],["|",t=>t.insert("|")],["/",t=>t.insert("/")],["-",t=>t.insert("-")],["~",t=>t.insert("~")],['"',t=>t.insert('"')]]}),this.el=(0,st.h)("div",{class:"term-app"},this.con.el),this.alive=!0,this.banner(),this.loop()}get fs(){return this.sys.piFs}banner(){let e=cs.BOARDS[this.sys.board.startsWith("pico")?"pi5":this.sys.board],t=new Date(Date.now()-36e5);this.con.writeln(`Linux ${hs} ${e.kernel} #1 SMP PREEMPT Debian 1:6.6.51-1+rpt3 (2024-10-08) aarch64`),this.con.writeln(""),this.con.writeln("The programs included with the Debian GNU/Linux system are free software;"),this.con.writeln("the exact distribution terms for each program are described in the"),this.con.writeln("individual files in /usr/share/doc/*/copyright."),this.con.writeln(""),this.con.writeln("Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extent"),this.con.writeln("permitted by applicable law."),this.con.writeln(`Last login: ${t.toDateString().replace(/ (\d{4})$/,"")} ${t.toTimeString().slice(0,8)} ${t.getFullYear()} from 192.168.1.10`),this.con.writeln('Type "help" to see the commands of this simulated shell.',"fg-K")}promptSegs(){let e=this.env.HOME,t=this.cwd===e?"~":this.cwd.startsWith(e+"/")?"~"+this.cwd.slice(e.length):this.cwd;return[[`${vh}@${hs}`,"fg-G bold"],[":",""],[t,"fg-B bold"],[" $ ",""]]}async loop(){for(;this.alive;){let e=await this.con.prompt(this.promptSegs());if(e!==null){e.trim()&&this.hist.push(e);try{await this.run(e)}catch(t){this.con.writeln(String(t.message||t),"err"),this.status=1}}}}key(e){return e.key==="Tab"?(this.complete(),!0):e.ctrlKey&&(e.key==="c"||e.key==="C")?(this.ctrlC(),!0):e.ctrlKey&&(e.key==="d"||e.key==="D")?(this.ctrlD(),!0):e.ctrlKey&&(e.key==="l"||e.key==="L")?(this.con.clear(),!0):!1}ctrlC(){if(this.fg&&this.fg.interrupt){this.fg.interrupt();return}this.con.cancel("^C")}ctrlD(){if(this.fg&&this.fg.eof){this.fg.eof();return}this.con.input.value||(this.con.cancel(""),this.con.writeln("logout"),this.exit())}exit(){this.alive=!1,this.con.hideInput(),this.ctx.onExit?this.ctx.onExit():(this.con.writeln("[Process completed \u2014 tap to start a new shell]","fg-K"),this.el.addEventListener("click",()=>this.restart(),{once:!0}))}restart(){this.alive=!0,this.cwd=this.env.HOME,this.con.clear(),this.loop()}complete(){let e=this.con.input.value,i=/(\S*)$/.exec(e)[1],s=!e.trim().includes(" "),r=[];if(s&&!i.includes("/"))r=Xo.filter(o=>o.startsWith(i));else{let o=i.includes("/")?ue(i.slice(0,i.lastIndexOf("/")+1)||"/",this.cwd):this.cwd,l=i.slice(i.lastIndexOf("/")+1);try{r=this.fs.list(o).filter(a=>a.startsWith(l)&&(l.startsWith(".")||!a.startsWith("."))).map(a=>i.slice(0,i.lastIndexOf("/")+1)+a+(this.fs.isDir(ue(a,o))?"/":""))}catch{r=[]}}if(r.length===1)this.con.input.value=e.slice(0,e.length-i.length)+r[0]+(r[0].endsWith("/")?"":" ");else if(r.length>1){let o=r[0];for(let l of r)for(;!l.startsWith(o);)o=o.slice(0,-1);o.length>i.length?this.con.input.value=e.slice(0,e.length-i.length)+o:this.con.writeln(r.map(l=>Te(l.replace(/\/$/,""))+(l.endsWith("/")?"/":"")).join("  "))}this.con.focus()}tokenize(e){let t=[],i="",s=null,r=!1;for(let o=0;o<e.length;o++){let l=e[o];if(s){l===s?s=null:l==="\\"&&s==='"'&&o+1<e.length&&'$`"\\'.includes(e[o+1])?i+=e[++o]:l==="$"&&s==='"'&&this.expandVar(e,o,(a,f)=>{i+=a,o+=f-1})||(i+=l);continue}if(l==='"'||l==="'"){s=l,r=!0;continue}if(l==="\\"&&o+1<e.length){i+=e[++o],r=!0;continue}if(/\s/.test(l)){(i||r)&&t.push(i),i="",r=!1;continue}if(l==="|"||l===";"||l===">"||l==="&"){(i||r)&&t.push(i),i="",r=!1,(l===">"||l==="&"||l==="|")&&e[o+1]===l?(t.push({op:l+l}),o++):t.push({op:l});continue}l==="$"&&this.expandVar(e,o,(a,f)=>{i+=a,o+=f-1})||(i+=l)}if(s)throw new Error("bash: unexpected EOF while looking for matching `"+s+"'");return(i||r)&&t.push(i),t}expandVar(e,t,i){let s=/^\$(\?|\w+|\{\w+\})/.exec(e.slice(t));if(!s)return!1;let r=s[1].replace(/[{}]/g,"");return i(r==="?"?String(this.status):r==="PWD"?this.cwd:this.env[r]??"",s[0].length),!0}async run(e){if(!e.trim()||e.trim().startsWith("#"))return;let t=this.tokenize(e),i=[],s=[];for(let o of t)typeof o=="object"&&(o.op===";"||o.op==="&&"||o.op==="||")?(i.push({cmd:s,next:o.op}),s=[]):s.push(o);i.push({cmd:s,next:null});let r=null;for(let o of i){if(r==="&&"&&this.status!==0){r=o.next;continue}if(r==="||"&&this.status===0){r=o.next;continue}o.cmd.length&&await this.pipeline(o.cmd),r=o.next}}async pipeline(e){let t=[[]],i=null;for(let r=0;r<e.length;r++){let o=e[r];typeof o=="object"&&o.op==="|"?t.push([]):typeof o=="object"&&(o.op===">"||o.op===">>")?(i={append:o.op===">>",file:e[r+1]},r++):typeof o=="object"&&o.op==="&"||t[t.length-1].push(o)}let s=null;for(let r=0;r<t.length;r++){let l=!(r===t.length-1)||!!i;s=await this.command(t[r],{input:s,capture:l})}if(i){if(!i.file)throw new Error("bash: syntax error near unexpected token `newline'");let r=ue(i.file,this.cwd),o=i.append&&this.fs.isFile(r)?this.fs.read(r):"";this.fs.write(r,o+(s||""))||(this.con.writeln(`bash: ${i.file}: write error: No space left on device`,"err"),this.status=1)}else s&&this.con.write(s)}async command(e,{input:t,capture:i}){let s="",r=b=>{s+=b},o=(b="")=>{s+=b+`
`},l=b=>{this.con.writeln(b,"err"),this.status=1},a=()=>i?s:(this.con.write(s),null),[f,...c]=e;if(f==="sudo"&&([f,...c]=c,!f))return l("usage: sudo command"),a();f&&f.startsWith("./")&&(c=[f,...c],f="python3"),this.status=0;let u=b=>ue(b,this.cwd,this.env.HOME),p=b=>c.filter(O=>O.startsWith("-")&&O.length>1).join("").replace(/-/g,""),y=()=>c.filter(b=>!b.startsWith("-")||b==="-"),v=b=>{let O=u(b);if(this.fs.isDir(O))throw new Error(`${f}: ${b}: Is a directory`);return O.startsWith("/proc/")?this.procFile(O):this.fs.read(O).replace(/^/,"")};switch(f){case"help":o("RaptiAuto virtual Raspberry Pi \u2014 simulated bash. Commands:");for(let b=0;b<Xo.length;b+=8)o("  "+Xo.slice(b,b+8).map(O=>O.padEnd(12)).join(""));o(""),o("Try:  pinout \xB7 python3 blink.py \xB7 python3 \xB7 nano hello.py \xB7 pinctrl get 17 \xB7 vcgencmd measure_temp");break;case"pwd":o(this.cwd);break;case"cd":{let b=c[0]||this.env.HOME;b==="-"&&(b=this.prevCwd,o(b));let O=u(b);if(!this.fs.exists(O)){l(`bash: cd: ${c[0]}: No such file or directory`);break}if(!this.fs.isDir(O)){l(`bash: cd: ${c[0]}: Not a directory`);break}this.prevCwd=this.cwd,this.cwd=O;break}case"ls":case"ll":case"dir":{let b=p()+(f==="ll"?"l":""),O=y().length?y():["."];for(let k of O){let T=u(k);if(!this.fs.exists(T)){l(`ls: cannot access '${k}': No such file or directory`);continue}O.length>1&&o(k+":");let P=this.fs.isDir(T)?this.fs.list(T):[Te(T)];b.includes("a")?P=[".","..",...P]:P=P.filter(R=>!R.startsWith("."));let I=this.fs.isDir(T)?T:Dt(T),E=R=>{let N=ue(R,I),B=this.fs.stat(N);return!B||B.dir||R==="."||R===".."?"fg-B bold":B.x||R.endsWith(".sh")?"fg-G bold":""};if(b.includes("l")){o(`total ${P.length*4}`);for(let R of P){let N=ue(R,I),B=this.fs.stat(N)||{dir:!0,size:4096,mtime:0},J=new Date(B.mtime||Date.now()-864e5*3),fe=b.includes("h")?I2(B.size):String(B.size),Z=`${B.dir?"d":"-"}rw${B.dir||B.x?"x":"-"}r-${B.dir||B.x?"x":"-"}r-${B.dir||B.x?"x":"-"} ${B.dir?2:1} pi pi ${fe.padStart(6)} ${J.toDateString().slice(4,10)} ${String(J.getHours()).padStart(2,"0")}:${String(J.getMinutes()).padStart(2,"0")} `;i?o(Z+R):(this.con.write(s+Z),s="",this.con.writeln(R,E(R)))}}else if(i)for(let R of P)o(R);else this.con.write(s),s="",P.forEach((R,N)=>{this.con.write(R,E(R)),this.con.write(N<P.length-1?"  ":`
`)})}break}case"cat":{if(!y().length&&t!=null){r(t);break}for(let b of y())try{let O=v(b);r(O)}catch(O){l(O.message.startsWith("cat")?O.message:`cat: ${b}: No such file or directory`)}break}case"echo":{let b=!1,O=!1,k=0;for(;k<c.length&&/^-[neE]+$/.test(c[k]);){for(let P of c[k].slice(1))P==="n"?b=!0:O=P==="e";k++}let T=c.slice(k).join(" ");if(O){let P={n:`
`,t:"	",r:"\r",a:"\x07",b:"\b",f:"\f",v:"\v",e:"\x1B","\\":"\\"},I="";for(let E=0;E<T.length;E++){let R=T[E];if(R!=="\\"||E+1>=T.length){I+=R;continue}let N=T[E+1],B=N==="0"?/^[0-7]{0,3}/.exec(T.slice(E+2)):N==="x"?/^[0-9a-fA-F]{1,2}/.exec(T.slice(E+2)):null;if(N==="c"){b=!0;break}if(N==="0"){I+=String.fromCharCode(parseInt(B[0]||"0",8)),E+=1+B[0].length;continue}if(N==="x"&&B){I+=String.fromCharCode(parseInt(B[0],16)),E+=1+B[0].length;continue}if(N in P){I+=P[N],E++;continue}I+=R}T=I}r(T+(b?"":`
`));break}case"touch":for(let b of y()){let O=u(b);(this.fs.exists(O)?!this.fs.isFile(O)||this.fs.write(O,this.fs.read(O)):this.fs.write(O,""))||l(`touch: cannot touch '${b}': No space left on device`)}break;case"mkdir":for(let b of y())try{if(this.fs.exists(u(b))&&!p().includes("p"))throw new Error(`mkdir: cannot create directory '${b}': File exists`);this.fs.mkdir(u(b),p().includes("p"))}catch(O){l(O.message.startsWith("mkdir")?O.message:"mkdir: "+O.message)}break;case"rmdir":for(let b of y())try{if(this.fs.list(u(b)).length)throw new Error(`rmdir: failed to remove '${b}': Directory not empty`);this.fs.remove(u(b),!0)}catch(O){l(O.message)}break;case"rm":{let b=p();for(let O of y()){let k=u(O);if(!this.fs.exists(k)){b.includes("f")||l(`rm: cannot remove '${O}': No such file or directory`);continue}if(this.fs.isDir(k)&&!b.includes("r")&&!b.includes("R")){l(`rm: cannot remove '${O}': Is a directory`);continue}if(k==="/"||k==="/home"||k==="/home/pi"){l(`rm: refusing to remove '${O}'`);continue}this.fs.remove(k,!0)}break}case"cp":case"mv":{let b=y();if(b.length<2){l(`${f}: missing destination file operand after '${b[0]||""}'`);break}let O=u(b[b.length-1]);for(let k of b.slice(0,-1)){let T=u(k);if(!this.fs.exists(T)){l(`${f}: cannot stat '${k}': No such file or directory`);continue}if(f==="cp"&&this.fs.isDir(T)&&!/r/i.test(p())){l(`cp: -r not specified; omitting directory '${k}'`);continue}f==="cp"?this.fs.copy(T,O):this.fs.move(T,O)}break}case"chmod":{let b=c[0]||"";for(let O of c.slice(1)){let k=u(O);if(!this.fs.isFile(k)){l(`chmod: cannot access '${O}': No such file or directory`);continue}b.includes("+x")||/^7/.test(b)?this.fs.chmodX(k,!0):b.includes("-x")&&this.fs.chmodX(k,!1)}break}case"head":case"tail":{let b=c.indexOf("-n"),O=b>=0?Number(c[b+1]):10,k=c.find(R=>/^-\d+$/.test(R));k&&(O=Number(k.slice(1)));let T=c.filter((R,N)=>!R.startsWith("-")&&(b<0||N!==b+1)),P=T.length?T.map(R=>{try{return v(R)}catch{return l(`${f}: cannot open '${R}' for reading: No such file or directory`),""}}).join(""):t||"",I=P.replace(/\n$/,"").split(`
`),E=f==="head"?I.slice(0,O):I.slice(-O);P&&o(E.join(`
`));break}case"wc":{let b=y(),O=b.length?b.map(E=>{try{return v(E)}catch{return""}}).join(""):t||"",k=(O.match(/\n/g)||[]).length,T=O.split(/\s+/).filter(Boolean).length,P=new TextEncoder().encode(O).length,I=p();o(I==="l"?`${k}${b[0]?" "+b[0]:""}`:I==="w"?String(T):I==="c"?String(P):`${String(k).padStart(3)} ${String(T).padStart(4)} ${String(P).padStart(5)}${b[0]?" "+b[0]:""}`);break}case"grep":{let b=p(),O=c.filter(E=>!E.startsWith("-")),k=O[0];if(k==null){l("Usage: grep [OPTION]... PATTERNS [FILE]...");break}let T;try{T=new RegExp(k,b.includes("i")?"i":"")}catch{T=new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),b.includes("i")?"i":"")}let P=O.slice(1),I=(E,R)=>{E.split(`
`).forEach((N,B)=>{T.test(N)!==b.includes("v")&&N!==""&&o((P.length>1?R+":":"")+(b.includes("n")?B+1+":":"")+N)})};if(P.length)for(let E of P)try{I(v(E),E)}catch{l(`grep: ${E}: No such file or directory`)}else I(t||"","");s||(this.status=1);break}case"find":{let b=u(c.find(P=>!P.startsWith("-")&&c[c.indexOf(P)-1]!=="-name")||"."),O=c.indexOf("-name"),k=O>=0?new RegExp("^"+c[O+1].replace(/[.+^${}()|[\]\\]/g,"\\$&").replace(/\*/g,".*").replace(/\?/g,".")+"$"):null,T=P=>{for(let I of this.fs.list(P)){let E=ue(I,P);(!k||k.test(I))&&o((c[0]&&!c[0].startsWith("-")?c[0].replace(/\/$/,""):".")+E.slice(b.length)),this.fs.isDir(E)&&T(E)}};try{k||o(c[0]&&!c[0].startsWith("-")?c[0]:"."),T(b)}catch{l(`find: '${c[0]}': No such file or directory`)}break}case"tree":{let b=u(y()[0]||"."),O=0,k=0;o(y()[0]||".");let T=(P,I)=>{let E=this.fs.list(P).filter(R=>!R.startsWith("."));E.forEach((R,N)=>{let B=ue(R,P),J=N===E.length-1;o(I+(J?"\u2514\u2500\u2500 ":"\u251C\u2500\u2500 ")+R),this.fs.isDir(B)?(O++,T(B,I+(J?"    ":"\u2502   "))):k++})};try{T(b,""),o(`
${O} directories, ${k} files`)}catch(P){l(P.message)}break}case"basename":o(Te(c[0]||""));break;case"dirname":o(Dt(c[0]||""));break;case"clear":this.con.clear();break;case"history":this.hist.forEach((b,O)=>o(`${String(O+1).padStart(5)}  ${b}`));break;case"whoami":o(vh);break;case"id":o("uid=1000(pi) gid=1000(pi) groups=1000(pi),4(adm),20(dialout),24(cdrom),27(sudo),29(audio),44(video),46(plugdev),60(games),100(users),104(input),106(render),108(netdev),997(gpio),998(i2c),999(spi)");break;case"hostname":o(c.includes("-I")?this.netIp()+" ":hs);break;case"uname":{let b=this.piInfo();o(c.includes("-a")?`Linux ${hs} ${b.kernel} #1 SMP PREEMPT Debian 1:6.6.51-1+rpt3 (2024-10-08) aarch64 GNU/Linux`:c.includes("-r")?b.kernel:c.includes("-m")?"aarch64":"Linux");break}case"lsb_release":o(`No LSB modules are available.
Distributor ID:	Debian
Description:	Debian GNU/Linux 12 (bookworm)
Release:	12
Codename:	bookworm`);break;case"date":o(new Date().toString().replace(/ GMT.*$/,"")+" "+new Date().getFullYear());break;case"cal":o(q2());break;case"uptime":{let b=Math.floor(performance.now()/6e4);o(` ${new Date().toTimeString().slice(0,8)} up ${b<60?b+" min":Math.floor(b/60)+":"+String(b%60).padStart(2,"0")},  1 user,  load average: 0.${this.sys.running?"98":"08"}, 0.12, 0.09`);break}case"free":{let b=this.sys.board==="pi5";c.includes("-h")?o(`               total        used        free      shared  buff/cache   available
Mem:           ${b?"7.9Gi":"3.7Gi"}       812Mi       ${b?"6.4Gi":"2.3Gi"}        52Mi       847Mi       ${b?"7.1Gi":"2.9Gi"}
Swap:          511Mi          0B       511Mi`):o(`               total        used        free      shared  buff/cache   available
Mem:         ${b?"8245104":"3884096"}      831488     ${b?"6545916":"2185432"}       53248      867700     ${b?"7413616":"3052608"}
Swap:         524284           0      524284`);break}case"df":o(`Filesystem      Size  Used Avail Use% Mounted on
udev            3.8G     0  3.8G   0% /dev
tmpfs           806M  6.6M  799M   1% /run
/dev/mmcblk0p2   29G  5.2G   22G  20% /
tmpfs           4.0G  208K  4.0G   1% /dev/shm
/dev/mmcblk0p1  510M   75M  436M  15% /boot/firmware`);break;case"ps":{o("    PID TTY          TIME CMD"),o("   1842 pts/0    00:00:00 bash"),this.sys.proc&&!this.sys.proc.dead&&o("   2051 pts/0    00:00:01 python3"),o(`   ${2100+this.hist.length} pts/0    00:00:00 ps`);break}case"top":{let b=this.sys.gpio.cpuTemp();o(`top - ${new Date().toTimeString().slice(0,8)} up 1:12,  1 user,  load average: 0.21, 0.15, 0.10`),o("Tasks: 187 total,   1 running, 186 sleeping,   0 stopped,   0 zombie"),o(`%Cpu(s):  ${this.sys.running?"24.6":" 1.3"} us,  0.8 sy,  0.0 ni, ${this.sys.running?"74.1":"97.6"} id,  0.0 wa,  0.0 hi,  0.3 si,  0.0 st`),o("MiB Mem :   8052.0 total,   6392.4 free,    812.2 used,    847.4 buff/cache"),o(""),o("    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND"),this.sys.proc&&!this.sys.proc.dead&&o("   2051 pi        20   0   27812  14336   7680 S  24.3   0.2   0:01.82 python3"),o("    987 pi        20   0  418924  98112  71424 S   1.3   1.2   0:12.40 labwc"),o("   1012 pi        20   0  320188  51200  38912 S   0.7   0.6   0:03.11 wf-panel-pi"),o("   1840 pi        20   0  402560  60416  45056 S   0.3   0.7   0:01.05 lxterminal"),o("      1 root      20   0  168696  12032   8960 S   0.0   0.1   0:02.31 systemd"),o(`(snapshot \xB7 CPU ${b}\xB0C)`);break}case"lscpu":{let b=this.piInfo(),O=this.sys.board==="pi5";o(`Architecture:            aarch64
  CPU op-mode(s):        32-bit, 64-bit
  Byte Order:            Little Endian
CPU(s):                  4
  On-line CPU(s) list:   0-3
Vendor ID:               ARM
  Model name:            ${O?"Cortex-A76":"Cortex-A72"}
    Thread(s) per core:  1
    Core(s) per cluster: 4
    CPU max MHz:         ${O?"2400.0000":"1800.0000"}
    CPU min MHz:         ${O?"1500.0000":"600.0000"}
Model:                   ${b.model}`);break}case"env":case"printenv":for(let[b,O]of Object.entries(this.env))o(`${b}=${O}`);o(`PWD=${this.cwd}`);break;case"export":for(let b of c){let O=/^(\w+)=(.*)$/.exec(b);O&&(this.env[O[1]]=O[2])}break;case"which":for(let b of c)Xo.includes(b)?o(b==="python"||b==="python3"?"/usr/bin/python3":"/usr/bin/"+b):this.status=1;break;case"true":break;case"false":this.status=1;break;case"man":o(c[0]?`No manual entry for ${c[0]} (this is a simulated shell; try "help").`:`What manual page do you want?
For example, try 'man man'.`);break;case"kill":o("");break;case"exit":case"logout":this.exit();break;case"sleep":this.con.write(s),s="",await this.wait(Number(c[0]||1)*1e3);break;case"ping":this.con.write(s),s="",await this.ping(c);break;case"ifconfig":case"ip":o(B2(f==="ip",this.netIp(),this.netMac()));break;case"curl":await this.curl(c,{wl:o,w:r,err:l});break;case"wget":await this.wget(c,{wl:o,w:r,err:l});break;case"nslookup":{let b=c[0],O=b&&this.sys.net.resolve(b,this.sys.netDev);o(`Server:		192.168.1.1
Address:	192.168.1.1#53
`),O?o(`Non-authoritative answer:
Name:	${b}
Address: ${O}`):(o(`** server can't find ${b}: NXDOMAIN`),this.status=1);break}case"iwgetid":o(this.sys.net.online(this.sys.netDev)?c.includes("-r")?this.sys.netDev.ssid:`wlan0     ESSID:"${this.sys.netDev.ssid}"`:"");break;case"nmcli":o(this.nmcli(c));break;case"chromium-browser":case"chromium":this.ctx.openUrl?this.ctx.openUrl(c.find(b=>!b.startsWith("-"))||""):l("chromium: cannot open display");break;case"mosquitto_pub":this.con.write(s),s="",this.mosquittoPub(c);break;case"mosquitto_sub":this.con.write(s),s="",await this.mosquittoSub(c);break;case"systemctl":o(c[0]==="status"?`\u25CF ${c[1]||"unknown"}.service
     Loaded: loaded
     Active: active (running)`:"");break;case"vcgencmd":o(this.vcgencmd(c)),/^error/.test(s)&&(this.status=1);break;case"pinout":this.con.write(s),s="",this.pinout();break;case"pinctrl":o(this.pinctrl(c));break;case"raspi-gpio":o(this.raspiGpio(c));break;case"gpio":l("bash: gpio: command not found (wiringPi is deprecated \u2014 use pinctrl or gpiozero)");break;case"i2cdetect":o(this.i2cdetect(c));break;case"neofetch":case"fastfetch":this.con.write(s),s="",this.neofetch();break;case"raspi-config":o("raspi-config needs a full-screen text terminal. Open the Raspberry Pi menu \u2192 Preferences \u2192 Raspberry Pi Configuration on the Desktop tab.");break;case"rpicam-hello":case"libcamera-hello":case"rpicam-still":l("ERROR: *** no cameras available ***");break;case"apt":case"apt-get":this.con.write(s),s="",await this.apt(c);break;case"pip":case"pip3":o(v0(c)),c[0]==="install"&&(this.status=1);break;case"nano":case"vi":case"vim":case"mousepad":case"geany":await this.nano(c.filter(b=>!b.startsWith("-"))[0]);break;case"thonny":this.ctx.openThonny?this.ctx.openThonny(c[0]?u(c[0]):null):l("thonny: cannot open display");break;case"xdg-open":case"open":/^[a-z]+:\/\//i.test(c[0]||"")&&this.ctx.openUrl?this.ctx.openUrl(c[0]):c[0]&&this.ctx.openFile&&this.ctx.openFile(u(c[0]));break;case"reboot":await this.reboot();break;case"shutdown":case"poweroff":case"halt":this.con.writeln(`Broadcast message from root@${hs} on pts/0:

The system will power off now!`,"fg-Y"),this.sys.killProcess(),await this.wait(800),this.con.writeln("Connection to raspberrypi closed."),this.exit();break;case"python":case"python3":case"python3.11":this.con.write(s),s="",await this.python(c);break;case void 0:break;default:{let b=/^(\w+)=(.*)$/.exec(f);if(b){this.env[b[1]]=b[2];break}if(f.endsWith(".py")&&this.fs.isFile(u(f))){l(`bash: ${f}: command not found \u2014 run it with: python3 ${f}`),this.status=127;break}l(`bash: ${f}: command not found`),this.status=127}}return a()}wait(e){return new Promise(t=>{let i=setTimeout(()=>{this.fg=null,t()},e);this.fg={interrupt:()=>{clearTimeout(i),this.con.writeln("^C"),this.fg=null,this.status=130,t()}}})}piInfo(){return cs.BOARDS[this.sys.board.startsWith("pico")?"pi5":this.sys.board]}procFile(e){let t=this.piInfo(),i=this.sys.board==="pi5";if(e==="/proc/cpuinfo"){let s="";for(let r=0;r<4;r++)s+=`processor	: ${r}
BogoMIPS	: 108.00
Features	: fp asimd evtstrm aes pmull sha1 sha2 crc32 atomics fphp asimdhp cpuid asimdrdm lrcpc dcpop asimddp
CPU implementer	: 0x41
CPU architecture: 8
CPU variant	: ${i?"0x4":"0x0"}
CPU part	: ${i?"0xd0b":"0xd08"}
CPU revision	: ${i?"1":"3"}

`;return s+`Revision	: ${t.revision}
Serial		: 1a2b3c4d5e6f7a8b
Model		: ${t.model}
`}if(e==="/proc/meminfo")return`MemTotal:        ${i?"8245104":"3884096"} kB
MemFree:         ${i?"6545916":"2185432"} kB
MemAvailable:    ${i?"7413616":"3052608"} kB
`;if(e==="/proc/device-tree/model")return t.model+`
`;if(e==="/proc/version")return`Linux version ${t.kernel} (gcc-12 (Debian 12.2.0-14) 12.2.0) #1 SMP PREEMPT Debian 1:6.6.51-1+rpt3 (2024-10-08)
`;throw new Error(`cat: ${e}: No such file or directory`)}vcgencmd(e){let t=this.sys.board==="pi5";switch(e[0]){case"measure_temp":return`temp=${this.sys.gpio.cpuTemp().toFixed(1)}'C`;case"get_throttled":return"throttled=0x0";case"measure_clock":return e[1]==="arm"||!e[1]?`frequency(0)=${t?this.sys.running?24e8:15e8:this.sys.running?18e8:6e8}`:`frequency(0)=${t?96e7:5e8}`;case"measure_volts":return`volt=${t?"0.7200":"0.8500"}V`;case"get_mem":return e[1]==="gpu"?"gpu=8M":`arm=${t?8064:3968}M`;case"version":return`2024/09/23 14:02:56
Copyright (c) 2012 Broadcom
version 26826259 (release) (embedded)`;case"commands":return'commands="measure_temp, get_throttled, measure_clock, measure_volts, get_mem, version"';default:return e[0]?'error=1 error_msg="Command not registered"':"Usage: vcgencmd measure_temp | get_throttled | measure_clock arm | measure_volts | get_mem arm | version"}}pinout(){let e=this.piInfo(),t=this.sys.board==="pi5",i="fg-G",s="fg-Y",r="fg-R",o="fg-K",l="fg-C",a=t?[",--------------------------------.","| oooooooooooooooooooo J8   : +====","| 1ooooooooooooooooooo      : |USB2","|  Wi    +---+      +----+  : +====","|  Fi    |RAM|      |RP1 |    +====","||p      +---+      +----+    |USB3","||c       ------              +====","||i       |SoC|               +======","||e       ------  J14         |   Net","| pwr      |hd|   |hd| |cd|   +======","`-| |------| |-----| |--------------'"]:[",--------------------------------.","| oooooooooooooooooooo J8   +======","| 1ooooooooooooooooooo  PoE |   Net","|  Wi                    1o +======","|  Fi  Pi Model 4B  V1.5 oo      |","|        ,----. +---+         +====","| |D|    |SoC | |RAM|         |USB3","| |S|    |    | |   |         +====","| |I|    `----' +---+            |","|                   |C|       +====","|                   |S|       |USB2","| pwr   |hd|   |hd| |I||A|    +====","`-| |---|m0|---|m1|----|V|-------'"];for(let u of a)this.con.writeln(u,i);this.con.writeln("");let f=(u,p)=>{this.con.write(u.padEnd(19),"bold"),this.con.writeln(": "+p)};f("Revision",e.revision),f("SoC",e.soc.replace("Broadcom ","")),f("RAM",t?"8GB":"4GB"),f("Storage","MicroSD"),f("USB ports","4 (of which 2 USB3)"),f("Ethernet ports","1 (1000Mbps max. speed)"),f("Wi-fi","True"),f("Bluetooth","True"),f("Camera ports (CSI)",t?"2":"1"),f("Display ports (DSI)",t?"2":"1"),this.con.writeln(""),this.con.writeln("J8:","bold");let c=u=>u.type==="power3"?s:u.type==="power5"?r:u.type==="gnd"?o:u.type==="gpio"?i:l;for(let u=1;u<=40;u+=2){let p=cs.PI_HEADER[u-1],y=cs.PI_HEADER[u];this.con.write(p.name.padStart(8),c(p)),this.con.write(` (${u}) `.padStart(6)),this.con.write(`(${u+1})`.padEnd(5)),this.con.writeln(" "+y.name,c(y))}this.con.writeln(""),this.con.writeln("For further information, please refer to https://pinout.xyz/",o)}pinState(e){let t=this.sys.gpio,i=t.pins.get(e),s=t.read(e);return{pn:i,lvl:s}}pinctrl(e){this.sys.board==="pi4"&&e[0];let t=s=>{let{pn:r,lvl:o}=this.pinState(s),l=r.mode==="out"?"op":r.mode==="pwm"?"a0":"ip",a=r.pull==="up"?"pu":r.pull==="down"?"pd":"pn",f=cs.PI_HEADER.find(c=>c.gpio===s);return`${String(s).padStart(2)}: ${l}    ${a} | ${o?"hi":"lo"} // ${f?"GPIO"+s:""} = ${r.mode==="out"?"output":r.mode==="pwm"?"PWM":"input"}`},i=e[0];if(!i||i==="get")return(e.slice(1).length?e.slice(1):[...Array(28).keys()].map(String)).flatMap(r=>r.includes("-")?y0(r):[Number(r)]).filter(r=>r>=0&&r<=27).map(t).join(`
`);if(i==="set"){let s=Number(e[1]),r=e.slice(2);if(!(s>=0&&s<=27))return"pinctrl: invalid GPIO";let o=this.sys.gpio;return r.includes("op")&&o.setup(s,"out"),r.includes("ip")&&o.setup(s,"in",o.pins.get(s).pull),r.includes("pu")&&o.setPull(s,"up"),r.includes("pd")&&o.setPull(s,"down"),r.includes("pn")&&o.setPull(s,"none"),r.includes("dh")&&(o.pins.get(s).mode!=="out"&&o.setup(s,"out"),o.write(s,1)),r.includes("dl")&&(o.pins.get(s).mode!=="out"&&o.setup(s,"out"),o.write(s,0)),""}return i==="help"||i==="-h"?`Use:
  pinctrl [get] [GPIO]          show the state of pins
  pinctrl set GPIO [op|ip] [pu|pd|pn] [dh|dl]

  op = output, ip = input, pu/pd/pn = pull up / down / none, dh/dl = drive high / low`:this.pinctrl(["get",...e])}raspiGpio(e){return this.sys.board==="pi5"?"raspi-gpio is not supported on Pi 5 - use `pinctrl`":e[0]==="get"?(e[1]?e.slice(1).flatMap(i=>i.includes("-")?y0(i):[Number(i)]):[...Array(28).keys()]).map(i=>{let{pn:s,lvl:r}=this.pinState(i);return`GPIO ${i}: level=${r} fsel=${s.mode==="out"?1:0} func=${s.mode==="out"?"OUTPUT":"INPUT"} pull=${(s.pull||"none").toUpperCase()}`}).join(`
`):e[0]==="set"?this.pinctrl(e):"Usage: raspi-gpio get [GPIO]  |  raspi-gpio set <GPIO> [op|ip] [pu|pd|pn] [dh|dl]"}i2cdetect(e){if(!e.includes("-y"))return"Usage: i2cdetect -y 1";let t="     0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f",i=new Set(this.sys.gpio.parts.filter(s=>s.type==="lcd").map(s=>Number(s.props.addr??39)));for(let s=0;s<8;s++){t+=`
${(s*16).toString(16).padStart(2,"0")}: `;for(let r=0;r<16;r++){let o=s*16+r;t+=o<3||o>119?"   ":i.has(o)?o.toString(16).padStart(2,"0")+" ":"-- "}}return t}neofetch(){let e=this.piInfo(),t=["   .~~.   .~~.  ","  '. \\ ' ' / .'  ","   .~ .~~~..~.   ","  : .~.'~'.~. :  "," ~ (   ) (   ) ~ ","( : '~'.~.'~' : )"," ~ .~ (   ) ~. ~ ","  (  : '~' :  )  ","   '~ .~~~. ~'   ","       '~'       "],i=[["pi@raspberrypi",""],["--------------",""],["OS","Debian GNU/Linux 12 (bookworm) aarch64"],["Host",e.model],["Kernel",e.kernel],["Uptime",Math.floor(performance.now()/6e4)+" mins"],["Shell","bash 5.2.15"],["DE","labwc (Wayland)"],["Terminal","lxterminal"],["CPU",`${e.soc.replace("Broadcom ","")} (4) @ ${this.sys.board==="pi5"?"2.400":"1.800"}GHz`],["Memory",`812MiB / ${this.sys.board==="pi5"?"8052":"3793"}MiB`],["Temp",this.sys.gpio.cpuTemp()+"\xB0C"]];for(let s=0;s<Math.max(t.length,i.length);s++){this.con.write((t[s]||"").padEnd(20),s<2?"fg-G bold":"fg-R bold");let r=i[s];r&&(r[1]?(this.con.write(r[0],"fg-R bold"),this.con.write(": "+r[1])):this.con.write(r[0],"fg-G bold")),this.con.write(`
`)}}netIp(){let e=this.sys.netDev;return this.sys.net&&e&&e.ip&&this.sys.net.online(e)?e.ip:"192.168.1.50"}netMac(){let e=this.sys.netDev;return e&&this.sys.net?this.sys.net.macString(e,":").toLowerCase():"d8:3a:dd:12:34:57"}async ping(e){let t=e.filter(p=>!p.startsWith("-")&&e[e.indexOf(p)-1]!=="-c")[0];if(!t){this.con.writeln("ping: usage error: Destination address required","err"),this.status=1;return}let i=this.sys.net,s=this.sys.netDev;if(!i.online(s)){this.con.writeln("ping: connect: Network is unreachable","err"),this.status=2;return}let r=i.resolve(t,s);if(!r){this.con.writeln(`ping: ${t}: Temporary failure in name resolution`,"err"),this.status=2;return}let o=e.indexOf("-c"),l=o>=0?Number(e[o+1]):1/0,a=/^(127\.|192\.168\.)/.test(r);this.con.writeln(`PING ${t} (${r}) 56(84) bytes of data.`);let f=0,c=!1,u=[];for(this.fg={interrupt:()=>{c=!0}};!c&&f<l;){f++;let p=a?.2+Math.random()*3:8+Math.random()*14;u.push(p),this.con.writeln(`64 bytes from ${r}: icmp_seq=${f} ttl=${a?64:117} time=${p.toFixed(a?3:1)} ms`),await new Promise(y=>{let v=setTimeout(y,1e3);this.fg.interrupt=()=>{c=!0,clearTimeout(v),y()}})}this.fg=null,c&&this.con.writeln("^C"),this.con.writeln(`
--- ${t} ping statistics ---
${f} packets transmitted, ${f} received, 0% packet loss, time ${f*1001}ms
rtt min/avg/max/mdev = ${Math.min(...u).toFixed(3)}/${(u.reduce((p,y)=>p+y,0)/f).toFixed(3)}/${Math.max(...u).toFixed(3)}/2.114 ms`)}async curl(e,{wl:t,w:i,err:s}){let r="",o="",l="",a=!1,f=!1,c=!1,u={};for(let b=0;b<e.length;b++){let O=e[b];if(O==="-X"||O==="--request")r=e[++b];else if(O==="-d"||O==="--data"||O==="--data-raw")o=e[++b]||"";else if(O==="-H"||O==="--header"){let[k,...T]=String(e[++b]||"").split(":");u[k.trim()]=T.join(":").trim()}else O==="-I"||O==="--head"?a=!0:O==="-i"||O==="--include"?f=!0:O==="-s"||O==="--silent"||O==="-sS"||O==="-S"?c=!0:O==="-o"||O==="-u"||O==="-A"||O==="-m"?b++:O.startsWith("-")||(l=O)}if(!l){s("curl: try 'curl --help' for more information"),this.status=2;return}/^[a-z]+:\/\//i.test(l)||(l="http://"+l),o&&!r&&(r="POST"),o&&!u["Content-Type"]&&(u["Content-Type"]=/^\s*[{[]/.test(o)?"application/json":"application/x-www-form-urlencoded");let p=this.sys.net,y=this.sys.netDev,v=await p.request({method:a?"HEAD":r||"GET",url:l,headers:{"user-agent":"curl/7.88.1",...u},body:o,fromName:y.name},y);if(v.failed){let b={ERR_NAME_NOT_RESOLVED:["6",`Could not resolve host: ${new URL(l).hostname}`],ERR_CONNECTION_REFUSED:["7",`Failed to connect to ${new URL(l).hostname} port ${new URL(l).port||80} after 2 ms: Couldn't connect to server`]}[v.error]||["28",v.statusText||v.error];s(`curl: (${b[0]}) ${b[1]}`),this.status=+b[0];return}if(a||f){t(`HTTP/1.1 ${v.status} ${v.statusText}`);for(let[b,O]of Object.entries(v.headers))t(`${b.replace(/(^|-)(\w)/g,(k,T,P)=>T+P.toUpperCase())}: ${O}`);t("")}a||i(v.body+(v.body.endsWith(`
`)?"":`
`))}async wget(e,{wl:t,w:i,err:s}){let r=e.find(p=>!p.startsWith("-"));if(!r){s("wget: missing URL");return}/^[a-z]+:\/\//i.test(r)||(r="http://"+r);let o=e.indexOf("-O"),l=this.sys.net,a=this.sys.netDev,f=new URL(r);t(`--${new Date().toISOString().replace("T"," ").slice(0,19)}--  ${r}`),t(`Resolving ${f.hostname}... ${l.resolve(f.hostname,a)||"failed: Name or service not known."}`);let c=await l.request({method:"GET",url:r,headers:{"user-agent":"Wget/1.21.3"},fromName:a.name},a);if(c.failed){s(`wget: unable to resolve host address '${f.hostname}'`),this.status=4;return}if(t(`HTTP request sent, awaiting response... ${c.status} ${c.statusText}`),c.status>=400){s(`${new Date().toISOString().replace("T"," ").slice(0,19)} ERROR ${c.status}: ${c.statusText}.`),this.status=8;return}let u=o>=0?e[o+1]:f.pathname.split("/").filter(Boolean).pop()||"index.html";if(!this.fs.write(ue(u,this.cwd,this.env.HOME),c.body)){s(`wget: ${u}: No space left on device`),this.status=3;return}this.sys.emit("files"),t(`Length: ${c.body.length} [${c.headers["content-type"]||"text/plain"}]
Saving to: '${u}'

${u}      100%[===================>]  ${c.body.length} B  --.-KB/s    in 0s

'${u}' saved [${c.body.length}/${c.body.length}]`)}nmcli(e){let t=this.sys.net,i=this.sys.netDev;return e[0]==="dev"||e[0]==="device"?e[1]==="wifi"?`IN-USE  BSSID              SSID          MODE   CHAN  RATE        SIGNAL  BARS  SECURITY
`+t.scan().map(r=>`${r.ssid===i.ssid&&t.online(i)?"*":" "}       02:1A:2B:3C:4D:0${r.ch%10}  ${r.ssid.padEnd(12)}  Infra  ${String(r.ch).padEnd(4)}  130 Mbit/s  ${100+r.rssi+20}      \u2582\u2584\u2586\u2588  ${r.enc==="open"?"--":"WPA2"}`).join(`
`):`DEVICE  TYPE      STATE      CONNECTION
wlan0   wifi      ${t.online(i)?"connected":"disconnected"}  ${t.online(i)?i.ssid:"--"}
eth0    ethernet  unavailable  --
lo      loopback  unmanaged  --`:'nmcli: use "nmcli dev wifi" to list the Wi-Fi networks'}mosquittoPub(e){let t=c=>{let u=e.indexOf(c);return u>=0?e[u+1]:""},i=t("-h")||"localhost",s=t("-t"),r=t("-m"),o=Number(t("-p"))||1883;if(!s){this.con.writeln("Error: You must specify a topic to publish to.","err"),this.status=1;return}let l=this.sys.net.mqtt,a=this.sys.netDev,f=l.connect("mosquitto_pub_"+Date.now(),i,o,{},a);if(!f.ok){this.con.writeln(`Error: ${f.reason==="refused"?"Connection refused":"Unknown host"}`,"err"),this.status=1;return}l.publish(f.client,s,r,e.includes("-r")),l.disconnect(f.client)}async mosquittoSub(e){let t=u=>{let p=e.indexOf(u);return p>=0?e[p+1]:""},i=t("-h")||"localhost",s=t("-t"),r=Number(t("-p"))||1883;if(!s){this.con.writeln("Error: You must specify a topic to subscribe to.","err"),this.status=1;return}let o=this.sys.net.mqtt,l=this.sys.netDev,a=o.connect("mosquitto_sub_"+Date.now(),i,r,{},l);if(!a.ok){this.con.writeln(`Error: ${a.reason==="refused"?"Connection refused":"Unknown host"}`,"err"),this.status=1;return}o.subscribe(a.client,s);let f=!1,c=e.includes("-v");for(this.fg={interrupt:()=>{f=!0}};!f;){let u;for(;u=o.poll(a.client);)this.con.writeln(c?`${u.topic} ${u.payload}`:u.payload);await new Promise(p=>{let y=setTimeout(p,150);this.fg.interrupt=()=>{f=!0,clearTimeout(y),p()}})}o.disconnect(a.client),this.fg=null,this.con.writeln("^C")}async apt(e){let t=e.find(r=>!r.startsWith("-")),i=e.filter(r=>!r.startsWith("-")).slice(1),s=(r,o=250)=>(this.con.writeln(r),this.wait(o));if(t==="update")for(let r of["Hit:1 http://deb.debian.org/debian bookworm InRelease","Hit:2 http://deb.debian.org/debian-security bookworm-security InRelease","Hit:3 http://deb.debian.org/debian bookworm-updates InRelease","Hit:4 http://archive.raspberrypi.com/debian bookworm InRelease","Reading package lists... Done","Building dependency tree... Done","Reading state information... Done","All packages are up to date."])await s(r,280);else if(t==="install"||t==="upgrade"||t==="full-upgrade"){if(await s("Reading package lists... Done"),await s("Building dependency tree... Done"),await s("Reading state information... Done"),t!=="install"||!i.length){await s("Calculating upgrade... Done"),await s("0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.");return}let r={"python3-gpiozero":1,"python3-rpi.gpio":1,"python3-rpi-lgpio":1,python3:1,thonny:1,"python3-pip":1,mosquitto:1,"mosquitto-clients":1,"python3-flask":1,"python3-paho-mqtt":1,"python3-requests":1,curl:1,wget:1,git:1,"python3-psutil":1,chromium:1,"chromium-browser":1};for(let o of i)r[o]?await s(`${o} is already the newest version.`):(this.con.writeln(`E: Unable to locate package ${o}`,"err"),this.con.writeln("   (Built in: gpiozero, RPi.GPIO, requests, flask, paho-mqtt, mosquitto, curl, neopixel, adafruit_dht.)","fg-K"),this.status=100);this.status||await s("0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.")}else this.con.writeln(`apt 2.6.1 (arm64)
Usage: apt [options] command

Most used commands:
  update - retrieve new lists of packages
  upgrade - upgrade the system by installing/upgrading packages
  install - install packages`)}async nano(e){e||(e="New Buffer");let t=e==="New Buffer"?null:ue(e,this.cwd,this.env.HOME);if(t&&this.fs.isDir(t)){this.con.writeln(`"${e}" is a directory`,"err");return}let i=t&&this.fs.isFile(t)?this.fs.read(t):"";await new Promise(s=>{let r=(0,st.h)("textarea",{class:"nano-text",spellcheck:"false",autocapitalize:"off",autocorrect:"off"});r.value=i;let o=(0,st.h)("div",{class:"nano-status"},t&&!this.fs.isFile(t)?"[ New File ]":`[ Read ${i.split(`
`).length-1} lines ]`),l=!1;r.addEventListener("input",()=>{l=!0,u.lastChild.textContent="Modified"});let a=()=>t?this.fs.write(t,r.value)?(l=!1,u.lastChild.textContent="",o.textContent=`[ Wrote ${r.value.split(`
`).length-(r.value.endsWith(`
`)?1:0)} lines ]`,!0):(o.textContent=`[ Error writing ${Te(t)}: No space left on device ]`,!1):(o.textContent="[ No file name: open nano with a file name ]",!1),f=()=>{v.remove(),this.con.focus(),s()},c=()=>{if(!l)return f();o.innerHTML="",o.append("Save modified buffer? ",(0,st.h)("button",{class:"nano-btn",onclick:()=>{a()&&f()}},"Y Yes"),(0,st.h)("button",{class:"nano-btn",onclick:f},"N No"),(0,st.h)("button",{class:"nano-btn",onclick:()=>{o.textContent=""}},"^C Cancel"))},u=(0,st.h)("div",{class:"nano-title"},(0,st.h)("span",{},"  GNU nano 7.2"),(0,st.h)("b",{},t?Te(t):"New Buffer"),(0,st.h)("span",{},"")),p=(b,O,k)=>(0,st.h)("button",{class:"nano-key",onclick:k},(0,st.h)("b",{},b)," "+O),y=(0,st.h)("div",{class:"nano-foot"},p("^O","Write Out",a),p("^X","Exit",c),p("^K","Cut",()=>L2(r)),p("^U","Paste",()=>Q2(r)),p("Tab","Indent",()=>Oh(r,"    ")),p("^W","Where Is",()=>{let b=prompt("Search:");if(b){let O=r.value.indexOf(b,r.selectionEnd);O>=0&&(r.setSelectionRange(O,O+b.length),r.focus())}}));r.addEventListener("keydown",b=>{b.ctrlKey&&(b.key==="o"||b.key==="s")?(b.preventDefault(),a()):b.ctrlKey&&b.key==="x"?(b.preventDefault(),c()):b.key==="Tab"&&(b.preventDefault(),Oh(r,"    "))});let v=(0,st.h)("div",{class:"nano"},u,r,o,y);this.el.appendChild(v),setTimeout(()=>r.focus(),50)})}async reboot(){this.sys.killProcess(),this.sys.gpio.reset(),this.con.writeln(`Broadcast message from root@${hs} on pts/0:

The system will reboot now!`,"fg-Y"),await this.wait(700),this.con.clear();let e=["[    0.000000] Booting Linux on physical CPU 0x0000000000 [0x414fd0b1]",`[    0.000000] Linux version ${this.piInfo().kernel}`,`[    0.000000] Machine model: ${this.piInfo().model}`,"[    1.023112] mmc0: new ultra high speed DDR50 SDXC card at address aaaa","[    1.511904] EXT4-fs (mmcblk0p2): mounted filesystem","[  OK  ] Started systemd-udevd.service","[  OK  ] Reached target network.target","[  OK  ] Started ssh.service - OpenBSD Secure Shell server","[  OK  ] Started lightdm.service","",`Raspberry Pi OS (Debian GNU/Linux 12) ${hs} tty1`,""];for(let t of e)this.con.writeln(t,t.includes("OK")?"fg-G":""),await this.wait(90);this.cwd=this.env.HOME,this.banner()}async python(e){if(e[0]==="--version"||e[0]==="-V"){this.con.writeln("Python 3.11.2 (simulated by MicroPython 1.29.0)");return}if(e[0]==="-m"&&e[1]==="pip"){this.con.writeln(v0(e.slice(2)));return}if(e[0]==="-m"&&e[1]==="venv"){this.con.writeln(`Created virtual environment ${e[2]||""} (simulated)`);return}let t=this.sys;if(t.isPico){this.con.writeln("python3: switch the board to a Raspberry Pi 4 / 5 to use the terminal","err");return}let i=null,s=null;if(e[0]==="-c")i=e[1]||"";else if(e[0]&&!e[0].startsWith("-")&&(s=ue(e[0],this.cwd,this.env.HOME),!this.fs.isFile(s))){this.con.writeln(`python3: can't open file '${s}': [Errno 2] No such file or directory`,"err"),this.status=2;return}let r=await t.spawn({owner:this,cwd:this.cwd,out:(l,a)=>this.con.write(l,a==="err"?"err":""),readLine:l=>this.con.prompt(l,{keepHistory:!1}).then(a=>a??"")});if(this.fg={interrupt:()=>{r.busy?r.interrupt():this.con.cancel("^C")},eof:()=>{this.replEof=!0,this.con.cancel("")}},s||i!=null){await r.exec(`import sys
sys.argv = ${JSON.stringify([s||"-c",...e.slice(1)])}`);let l=s?await r.runFile(s):await r.runSource(i,"<string>");this.status=l,this.fg=null,t.proc===r&&t.killProcess();return}this.con.writeln("Python 3.11.2 \xB7 MicroPython 1.29.0 engine (RaptiAuto virtual Raspberry Pi) on linux"),this.con.writeln('Type "help()" for more information, exit() or Ctrl+D to leave.'),this.replEof=!1;let o=[];for(;!r.dead&&t.proc===r;){let l=o.length?o[o.length-1]:"",a=o.length?/^(\s*)/.exec(l)[1]+(/:\s*$/.test(l)?"    ":""):"",f=await this.con.prompt(o.length?"... ":">>> ",{value:a});if(this.replEof)break;if(f==null){if(o=[],r.busy)continue;this.con.writeln("KeyboardInterrupt","err");continue}if(!o.length&&/^\s*(exit|quit)\(\)\s*$/.test(f))break;if(!o.length&&!f.trim()||(o.push(f),kh(o,f)))continue;let c=o.join(`
`).replace(/\s+$/,"")+`
`;o=[],await r.replExec(c)}this.fg=null,t.proc===r&&t.killProcess()}};function kh(n,e){let t=n.join(`
`),i=0,s=null,r=!1;for(let o=0;o<t.length;o++){let l=t[o];if(s){r&&t.startsWith(s.repeat(3),o)?(s=null,r=!1,o+=2):!r&&l===s?s=null:l==="\\"&&o++;continue}if(l==="#"){for(;o<t.length&&t[o]!==`
`;)o++;continue}if(l==='"'||l==="'"){t.startsWith(l.repeat(3),o)?(s=l,r=!0,o+=2):s=l;continue}"([{".includes(l)?i++:")]}".includes(l)&&i--}return s&&r||i>0?!0:n.length===1?/:\s*(#.*)?$/.test(e)||/^\s*@/.test(e):e.trim()!==""}function y0(n){let[e,t]=n.split("-").map(Number),i=[];for(let s=e;s<=t;s++)i.push(s);return i}function I2(n){return n<1024?String(n):n<1048576?(n/1024).toFixed(1)+"K":(n/1048576).toFixed(1)+"M"}function Oh(n,e){let t=n.selectionStart,i=n.selectionEnd;n.value=n.value.slice(0,t)+e+n.value.slice(i),n.setSelectionRange(t+e.length,t+e.length),n.dispatchEvent(new Event("input")),n.focus()}var wh="";function L2(n){let e=n.value,t=e.lastIndexOf(`
`,n.selectionStart-1)+1,i=e.indexOf(`
`,n.selectionStart);i=i<0?e.length:i+1,wh=e.slice(t,i),n.value=e.slice(0,t)+e.slice(i),n.setSelectionRange(t,t),n.dispatchEvent(new Event("input")),n.focus()}function Q2(n){wh&&Oh(n,wh)}function q2(){let n=new Date,e=n.getFullYear(),t=n.getMonth(),i=n.toLocaleString("en",{month:"long"})+" "+e,s=i.padStart(10+Math.ceil(i.length/2))+`
Su Mo Tu We Th Fr Sa
`,r=new Date(e,t,1).getDay(),o=new Date(e,t+1,0).getDate();s+="   ".repeat(r);for(let l=1;l<=o;l++)s+=String(l).padStart(2)+((r+l)%7?" ":`
`);return s.trimEnd()}function B2(n,e="192.168.1.50",t="d8:3a:dd:12:34:57"){return n?`1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN
    inet 127.0.0.1/8 scope host lo
2: eth0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 state DOWN
    link/ether d8:3a:dd:12:34:56 brd ff:ff:ff:ff:ff:ff
3: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 state UP
    link/ether ${t} brd ff:ff:ff:ff:ff:ff
    inet ${e}/24 brd 192.168.1.255 scope global dynamic noprefixroute wlan0`:`eth0: flags=4099<UP,BROADCAST,MULTICAST>  mtu 1500
        ether d8:3a:dd:12:34:56  txqueuelen 1000  (Ethernet)

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0

wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet ${e}  netmask 255.255.255.0  broadcast 192.168.1.255
        ether ${t}  txqueuelen 1000  (Ethernet)`}var b0={requests:"2.31.0",flask:"2.2.2","paho-mqtt":"2.1.0",psutil:"5.9.4",gpiozero:"2.0.1","rpi.gpio":"0.7.1",pyserial:"3.5",smbus2:"0.4.3",numpy:"1.24.2",pillow:"9.4.0"};function v0(n){if(n[0]==="install"){let e=n.slice(1).filter(t=>!t.startsWith("-"));if(e.length&&e.every(t=>b0[t.toLowerCase().replace(/[=<>].*$/,"").replace("_","-")]))return e.map(t=>{let i=t.toLowerCase().replace(/[=<>].*$/,"");return`Requirement already satisfied: ${i} in /usr/lib/python3/dist-packages (${b0[i]})`}).join(`
`);if(e.length)return e.map(t=>`ERROR: Could not find a version that satisfies the requirement ${t} (from versions: none)
ERROR: No matching distribution found for ${t}`).join(`
`)+`
(RaptiAuto: built in: requests, flask, paho-mqtt, psutil, gpiozero, RPi.GPIO, smbus2, pyserial, neopixel, adafruit_dht, board.)`}return n[0]==="install"?`error: externally-managed-environment

\xD7 This environment is externally managed
\u2570\u2500> To install Python packages system-wide, try apt install
    python3-xyz, where xyz is the package you are trying to
    install.

(RaptiAuto: the virtual Pi is offline. Built in: gpiozero, RPi.GPIO, smbus2, pyserial, neopixel, adafruit_dht, board.)`:n[0]==="list"?`Package    Version
---------- -------
gpiozero   2.0.1
RPi.GPIO   0.7.1
adafruit-circuitpython-dht 4.0.4
adafruit-circuitpython-neopixel 6.3.12
pyserial   3.5
smbus2     0.4.3`:"pip 23.0.1 from /usr/lib/python3/dist-packages/pip (python 3.11)"}var Sh=se($i(),1),Ko=se(rr(),1),$2={new:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M6 2.5h8l4.5 4.5v14.5H6z" fill="#fff" stroke="#6b7280" stroke-width="1.3"/><path d="M14 2.5V7h4.5" fill="#e5e7eb" stroke="#6b7280" stroke-width="1.3"/><circle cx="17.5" cy="17.5" r="4.5" fill="#22a33a"/><path d="M17.5 15v5M15 17.5h5" stroke="#fff" stroke-width="1.8"/></svg>',load:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M2.5 6.5h7l2 2h10v11h-19z" fill="#f2c14e" stroke="#b7862a" stroke-width="1.2"/><path d="M2.5 10h19" stroke="#d9a63a" stroke-width="1.2"/></svg>',save:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M3.5 3.5h14l3 3v14h-17z" fill="#3b6fd8" stroke="#24479a" stroke-width="1.2"/><rect x="7" y="3.5" width="9" height="6" fill="#e8eefc"/><rect x="6.5" y="13" width="11" height="7.5" rx="1" fill="#fff"/></svg>',run:'<svg viewBox="0 0 24 24" width="28" height="28"><circle cx="12" cy="12" r="10" fill="#2fa84f" stroke="#1d7a37" stroke-width="1.2"/><path d="M9.5 7.5v9l7.5-4.5z" fill="#fff"/></svg>',stop:'<svg viewBox="0 0 24 24" width="28" height="28"><path d="M8 2.5h8l5.5 5.5v8L16 21.5H8L2.5 16V8z" fill="#d93a3a" stroke="#a52222" stroke-width="1.2"/><rect x="7.5" y="10.5" width="9" height="3" rx=".6" fill="#fff"/></svg>',examples:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M4 4.5h7a2 2 0 0 1 2 2v14a2 2 0 0 0-2-2H4z" fill="#8b5cf6" stroke="#5b34c2" stroke-width="1.1"/><path d="M20 4.5h-7a2 2 0 0 0-2 2v14a2 2 0 0 1 2-2h7z" fill="#a78bfa" stroke="#5b34c2" stroke-width="1.1"/></svg>',files:'<svg viewBox="0 0 24 24" width="26" height="26"><rect x="3" y="4" width="18" height="16" rx="2" fill="#fff" stroke="#6b7280" stroke-width="1.3"/><path d="M6 8h12M6 12h12M6 16h8" stroke="#3b6fd8" stroke-width="1.6"/></svg>',zoom:'<svg viewBox="0 0 24 24" width="26" height="26"><circle cx="10.5" cy="10.5" r="6.5" fill="#fff" stroke="#6b7280" stroke-width="1.6"/><path d="M15.5 15.5l5 5" stroke="#6b7280" stroke-width="2.2"/><path d="M8 10.5h5M10.5 8v5" stroke="#2fa84f" stroke-width="1.8"/></svg>'},Yo=class{constructor(e){this.ctx=e,this.sys=e.sys,this.proc=null,this.buf=[],this.pid=0,this.running=!1,this.font=Number(localStorage.getItem("rapti.pi.thonny.font"))||14,this.build(),this.loadTabs(),this.sys.on(t=>this.onSys(t))}get kind(){return this.sys.isPico?"pico":"pi"}get fs(){return this.sys.fs}get cur(){return this.tabs[this.ti]}build(){let e=(i,s,r,o="")=>(0,V.h)("button",{class:"th-tb "+o,title:s,onclick:r},(0,V.h)("i",{html:$2[i]}),(0,V.h)("span",{},s));this.runB=e("run","Run",()=>this.run(),"th-run"),this.stopB=e("stop","Stop",()=>this.stop(),"th-stop"),this.toolbar=(0,V.h)("div",{class:"th-toolbar"},e("new","New",()=>this.newTab()),e("load","Load",()=>this.loadDialog()),e("save","Save",()=>this.save()),(0,V.h)("span",{class:"th-sep"}),this.runB,this.stopB,(0,V.h)("span",{class:"th-sep"}),e("examples","Examples",()=>this.examples()),e("files","Files",()=>this.loadDialog()),(0,V.h)("span",{class:"th-flex"}),(0,V.h)("button",{class:"th-tb th-more",title:"More",html:(0,Jn.icon)("dots",20),onclick:i=>this.menu(i.currentTarget)})),this.tabBar=(0,V.h)("div",{class:"th-tabs"}),this.edHost=(0,V.h)("div",{class:"th-editor"}),this.editor=new Go(this.edHost,{fontSize:this.font,onChange:i=>this.edited(i)}),this.con=new bs({cls:"th-con",onKey:i=>i.ctrlKey&&(i.key==="c"||i.key==="C")&&!window.getSelection().toString()?(this.interrupt(),!0):i.ctrlKey&&(i.key==="d"||i.key==="D")?(this.softReboot(),!0):!1,extraKeys:[["Ctrl+C",()=>this.interrupt()],["Ctrl+D",()=>this.softReboot()],["\u2191",i=>i.histMove(-1)],["\u2193",i=>i.histMove(1)],["Tab",i=>i.insert("    ")],[":",i=>i.insert(":")],["(",i=>i.insert("(")],[")",i=>i.insert(")")],['"',i=>i.insert('"')]]});let t=(0,V.h)("div",{class:"th-grip"},(0,V.h)("span"));this.shellHead=(0,V.h)("div",{class:"th-shell-head"},(0,V.h)("b",{},"Output \xB7 Shell"),(0,V.h)("button",{class:"th-clear",onclick:()=>{this.con.clear(),this.showPrompt()}},"Clear")),this.shell=(0,V.h)("div",{class:"th-shell"},this.shellHead,this.con.el),this.status=(0,V.h)("div",{class:"th-status"}),this.grip=t,this.el=(0,V.h)("div",{class:"thonny"}),this.codeEl=(0,V.h)("div",{class:"thonny th-code"}),this.outEl=(0,V.h)("div",{class:"thonny th-out"}),this.join(),this.dragGrip(t),this.updateStatus()}joined(){return this.join(),this.el}join(){this.mode!=="joined"&&(this.mode="joined",xh(this.el,this.toolbar,this.tabBar,this.edHost,this.grip,this.shell,this.status))}splitInto(e,t){this.mode!=="split"&&(this.mode="split",this.shell.style.flex="",xh(this.codeEl,this.toolbar,this.tabBar,this.edHost,this.status),xh(this.outEl,this.shell)),this.codeEl.parentNode!==e&&e.appendChild(this.codeEl),this.outEl.parentNode!==t&&t.appendChild(this.outEl)}dragGrip(e){let t=null,i=0;e.addEventListener("pointerdown",r=>{t=r.clientY,i=this.shell.getBoundingClientRect().height,e.setPointerCapture(r.pointerId)}),e.addEventListener("pointermove",r=>{if(t==null)return;let o=this.el.getBoundingClientRect().height,l=Math.max(90,Math.min(o-160,i-(r.clientY-t)));this.shell.style.flex=`0 0 ${l}px`});let s=()=>{t=null,this.editor.refresh()};e.addEventListener("pointerup",s),e.addEventListener("pointercancel",s)}updateStatus(){let e=Sh.BOARDS[this.sys.board];this.status.innerHTML="",this.sys.isPico?this.status.append((0,V.h)("span",{},`MicroPython (${e.name})`),(0,V.h)("span",{class:"th-port"},"\u2022 Board CDC @ /dev/ttyACM0")):this.status.append((0,V.h)("span",{},"Local Python 3"),(0,V.h)("span",{class:"th-port"},"\u2022 /usr/bin/python3")),this.runB.classList.toggle("busy",this.running)}tabsKey(){return"rapti.pi.thonny."+this.kind}loadTabs(){this.loadedKind=this.kind;let e=null;try{e=JSON.parse(localStorage.getItem(this.tabsKey())||"null")}catch{e=null}if(this.tabs=[],e&&Array.isArray(e.tabs)){for(let t of e.tabs)t.path&&this.fs.isFile(t.path)?this.tabs.push({path:t.path,name:Te(t.path),text:t.dirty?t.text:this.fs.read(t.path),dirty:!!t.dirty}):t.path||this.tabs.push({path:null,name:t.name||"<untitled>",text:t.text||"",dirty:!!t.dirty});this.ti=Math.min(e.ti||0,this.tabs.length-1)}if(!this.tabs.length){let t=this.sys.isPico?"/main.py":"/home/pi/blink.py";this.fs.isFile(t)?this.tabs.push({path:t,name:Te(t),text:this.fs.read(t),dirty:!1}):this.tabs.push({path:null,name:"<untitled>",text:"",dirty:!1}),this.ti=0}this.showTab(this.ti)}saveTabs(){let e={ti:this.ti,tabs:this.tabs.map(t=>({path:t.path,name:t.name,dirty:t.dirty,text:t.dirty||!t.path?t.text:void 0}))};try{localStorage.setItem(this.tabsKey(),JSON.stringify(e))}catch{}}drawTabs(){this.tabBar.innerHTML="",this.tabs.forEach((e,t)=>{let i=(0,V.h)("button",{class:"th-tab-x","aria-label":"Close",onclick:r=>{r.stopPropagation(),this.closeTab(t)}},"\xD7"),s=(this.sys.isPico&&e.path?"[ "+e.name+" ]":e.name)+(e.dirty?" *":"");this.tabBar.appendChild((0,V.h)("div",{class:"th-tab"+(t===this.ti?" active":""),onclick:()=>this.showTab(t)},(0,V.h)("span",{},s),i))})}showTab(e){this.cur&&this.ti!==e&&(this.cur.text=this.editor.value),this.ti=e,this.editor.load(this.cur.text),this.drawTabs(),this.saveTabs()}edited(e){let t=this.cur;t.text=e,t.dirty||(t.dirty=!0,this.drawTabs()),clearTimeout(this.tabSaveT),this.tabSaveT=setTimeout(()=>this.saveTabs(),600)}newTab(e="<untitled>",t="",i=null){this.cur&&(this.cur.text=this.editor.value),this.tabs.push({path:i,name:e,text:t,dirty:!i&&!!t}),this.showTab(this.tabs.length-1)}async closeTab(e){let t=this.tabs[e];e===this.ti&&(t.text=this.editor.value),!(t.dirty&&t.text.trim()&&!await(0,V.confirmDialog)("Close tab",`Close ${t.name} without saving?`,"Close",!0))&&(this.tabs.splice(e,1),this.tabs.length||this.tabs.push({path:null,name:"<untitled>",text:"",dirty:!1}),this.ti=Math.min(this.ti>=e?Math.max(0,this.ti-1):this.ti,this.tabs.length-1),this.editor.load(this.cur.text),this.drawTabs(),this.saveTabs())}open(e){let t=this.tabs.findIndex(s=>s.path===e);if(t>=0){this.showTab(t);return}if(!this.fs.isFile(e)){(0,V.toast)("File not found: "+e,"error");return}let i=this.cur;if(i&&!i.path&&!i.dirty&&!this.editor.value.trim()){i.path=e,i.name=Te(e),i.text=this.fs.read(e),i.dirty=!1,this.showTab(this.ti),this.editor.load(i.text);return}this.newTab(Te(e),this.fs.read(e),e),this.cur.dirty=!1,this.drawTabs()}async save(e=!1){let t=this.cur;t.text=this.editor.value;let i=t.path;if(!i||e){let s=this.sys.isPico?"Raspberry Pi Pico":"/home/pi",r=await(0,V.promptDialog)(`Save to ${s} as`,t.path?Te(t.path):t.name.startsWith("<")?"untitled.py":t.name);if(!r||(i=ue(r.endsWith(".py")||r.includes(".")?r:r+".py",this.sys.home),this.fs.isFile(i)&&i!==t.path&&!await(0,V.confirmDialog)("Replace file",`${Te(i)} already exists. Replace it?`,"Replace",!0)))return!1}try{if(!this.fs.write(i,t.text))return(0,V.toast)(`Storage is full: ${Te(i)} could not be saved. Delete some files and save again.`,"error",6e3),!1}catch(s){return(0,V.toast)(s.message,"error"),!1}return t.path=i,t.name=Te(i),t.dirty=!1,this.drawTabs(),this.saveTabs(),this.sys.emit("files"),!0}loadDialog(){let e=this.fs,t=this.cur&&this.cur.path?Dt(this.cur.path):this.sys.home,i=(0,V.h)("div",{class:"th-files"}),s=(0,V.h)("div",{class:"th-files-path"}),r=()=>{i.innerHTML="",s.textContent=this.sys.isPico?"Raspberry Pi Pico: "+t:"This computer: "+t,t!=="/"&&i.appendChild((0,V.h)("button",{class:"th-file dir",onclick:()=>{t=Dt(t),r()}},(0,V.h)("i",{html:(0,Jn.icon)("back",18)}),(0,V.h)("span",{},"..")));let l=e.list(t).filter(a=>!a.startsWith("."));l.sort((a,f)=>e.isDir(ue(f,t))-e.isDir(ue(a,t))||a.localeCompare(f));for(let a of l){let f=ue(a,t),c=e.isDir(f),u=(0,V.h)("div",{class:"th-file-row"},(0,V.h)("button",{class:"th-file"+(c?" dir":""),onclick:()=>{c?(t=f,r()):(o.close(),this.open(f))}},(0,V.h)("i",{html:(0,Jn.icon)(c?"folder":a.endsWith(".py")?"code":"book",18)}),(0,V.h)("span",{},a),c?null:(0,V.h)("small",{},F2(e.stat(f).size))),c?null:(0,V.h)("button",{class:"icon-btn","aria-label":"Delete",html:(0,Jn.icon)("trash",17),onclick:async()=>{await(0,V.confirmDialog)("Delete",`Delete ${a}?`,"Delete",!0)&&(e.remove(f),this.sys.emit("files"),r())}}));i.appendChild(u)}l.length||i.appendChild((0,V.h)("p",{class:"muted th-empty"},"Empty folder"))};r();let o=new V.Sheet({title:this.sys.isPico?"Open from Raspberry Pi Pico":"Open file",icon:"folder",content:(0,V.h)("div",{},s,i)}).open()}examples(){let e=this.sys.isPico,t=(e?Ko.PICO_EXAMPLES:Ko.PI_EXAMPLES).filter(r=>!r.boards||r.boards.includes(this.sys.board)),i=(0,V.h)("div",{class:"th-ex-list"});for(let r of t)i.appendChild((0,V.h)("button",{class:"th-ex",onclick:()=>{s.close(),this.openExample(r)}},(0,V.h)("b",{},r.title),(0,V.h)("span",{},r.file+" \xB7 "+r.tags.join(", "))));let s=new V.Sheet({title:e?"MicroPython examples":"Python examples",icon:"book",content:i,height:"78vh"}).open()}async openExample(e){if(this.sys.isPico)this.newTab(e.file,e.code);else{let t="/home/pi/"+e.file;this.fs.isFile(t)||this.fs.write(t,e.code),this.open(t)}if(e.circuit)this.ctx.wire&&this.ctx.wire(e),(0,V.toast)("The circuit is built on the Circuit tab","ok");else if(e.parts&&e.parts.length){let t=e.parts.map(i=>i.type).join(", ");this.ctx.wire&&this.ctx.wire(e),(0,V.toast)(`Wired on the Circuit tab: ${t}`,"ok")}}menu(e){let t=this.sys.isPico;(0,V.popupMenu)(e,[{icon:"save",label:"Save as\u2026",action:()=>this.save(!0)},{icon:"close",label:"Close tab",action:()=>this.closeTab(this.ti)},{icon:"search",label:"Find in file",action:()=>this.editor.search()},"-",{icon:"plus",label:"Zoom in",action:()=>this.zoom(1)},{icon:"minus",label:"Zoom out",action:()=>this.zoom(-1)},"-",{icon:"stop",label:"Interrupt execution",hint:"Ctrl+C",action:()=>this.interrupt()},{icon:"restart",label:t?"Send EOF / Soft reboot":"Restart backend",hint:"Ctrl+D",action:()=>this.softReboot()},{icon:"eraser",label:"Clear shell",action:()=>{this.con.clear(),this.showPrompt()}}])}zoom(e){this.font=Math.max(10,Math.min(24,this.font+e)),this.editor.setFontSize(this.font),this.el.style.setProperty("--th-font",this.font+"px");try{localStorage.setItem("rapti.pi.thonny.font",this.font)}catch{}}onSys(e){e==="board"?(this.cur&&(this.cur.text=this.editor.value),this.saveTabs(),this.proc=null,this.buf=[],this.running=!1,this.con.hideInput(),this.con.clear(),this.loadTabs(),this.updateStatus(),this.visible&&this.ensureBackend()):e==="proc"&&this.proc&&this.sys.proc!==this.proc&&(this.proc=null,this.buf=[],this.running=!1,++this.pid,this.con.hideInput(),this.con.writeln(""),this.con.writeln(this.sys.isPico?"Connection lost (board reset). Press Stop to reconnect.":"Backend terminated. Press Stop to restart.","fg-K"),this.updateStatus())}banner(){if(this.sys.isPico){let e=Sh.BOARDS[this.sys.board];return`MicroPython v1.29.0 on 2026-10-10; ${{pico:"Raspberry Pi Pico",picow:"Raspberry Pi Pico W",pico2:"Raspberry Pi Pico2",pico2w:"Raspberry Pi Pico 2 W"}[e.id]} with ${e.mcu}
Type "help()" for more information.`}return"Python 3.11.2 (/usr/bin/python3)"}async ensureBackend(e=!1){if(this.proc&&!this.proc.dead&&this.sys.proc===this.proc)return this.proc;if(this.starting)return this.starting;this.proc&&(this.proc.dead||this.sys.proc!==this.proc)&&(this.proc=null),this.starting=(async()=>{++this.pid,this.con.hideInput();let i=await this.sys.spawn({owner:this,cwd:this.sys.home,out:(s,r)=>{this.proc===i&&(this.con.write(s,r==="err"?"err":""),r==="err"&&(this.errText+=s))},readLine:s=>(++this.pid,this.sys.emit("input"),this.con.prompt(s,{keepHistory:!1}).then(r=>r??""))});return this.proc=i,e||this.con.writeln(this.banner()),i})().finally(()=>{this.starting=null});let t=await this.starting;return e||this.showPrompt(),t}showPrompt(){let e=this.proc;if(!e||e.dead||this.running)return;let t=++this.pid,i=this.buf.length?this.buf[this.buf.length-1]:"",s=this.buf.length?/^(\s*)/.exec(i)[1]+(/:\s*(#.*)?$/.test(i)?"    ":""):"";this.con.prompt(this.buf.length?"... ":">>> ",{value:s,focus:!1}).then(r=>this.onLine(t,r))}async onLine(e,t){if(e!==this.pid)return;if(t==null){this.buf=[],this.showPrompt();return}if(!this.buf.length&&!t.trim()){this.showPrompt();return}if(this.buf.push(t),kh(this.buf,t)){this.showPrompt();return}let i=this.buf.join(`
`).replace(/\s+$/,"")+`
`;this.buf=[];let s=/^%Run\s+(\S+)/.exec(i.trim());if(s){let o=ue(s[1],this.sys.home);if(this.fs.isFile(o))return this.open(o),this.run(!0);this.con.writeln(`%Run: file not found: ${s[1]}`,"err"),this.showPrompt();return}if(/^%?(cd|ls|clear)\b/.test(i.trim())){/clear/.test(i)?this.con.clear():this.con.writeln(this.fs.list(this.sys.home).join("  ")),this.showPrompt();return}let r=this.proc;this.running=!0,this.updateStatus(),await r.replExec(i),r===this.proc&&(this.running=!1,this.updateStatus(),this.showPrompt())}async run(e=!1){this.running&&this.proc&&this.sys.isPico&&await this.stopRun();let t=this.cur;t.text=this.editor.value,!e&&this.ctx.onRun&&this.ctx.onRun();let i=this.sys.isPico;if(!i&&(!t.path||t.dirty)&&!await this.save())return;let s=i?t.name.startsWith("<")?"<stdin>":t.name:t.path;++this.pid,this.con.hideInput(),this.buf=[],this.dropBackend(),i&&this.con.writeln("MPY: soft reboot","fg-K");let r=await this.ensureBackend(!0);e||this.con.write(">>> "),this.con.writeln(i?(t.path,"%Run -c $EDITOR_CONTENT"):`%Run ${Te(t.path)}`,"th-magic"),this.running=!0,this.errText="",this.updateStatus(),this.sys.emit("run");let o;if(i?o=await r.runSource(t.text,s==="<stdin>"?"main.py":s):(await r.exec(`import sys, os
sys.argv = [${JSON.stringify(t.path)}]
os.chdir(${JSON.stringify(Dt(t.path))})`),o=await r.runFile(t.path)),r===this.proc){if(this.running=!1,this.updateStatus(),this.sys.emit("run"),o===1){let l=new RegExp(`File "${(i?s==="<stdin>"?"main.py":s:t.path).replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}", line (\\d+)`,"g"),a,f=null;for(;a=l.exec(this.errText);)f=Number(a[1]);f&&this.editor.gotoLine(f)}this.sys.syncBack(r),this.showPrompt()}}dropBackend(){let e=this.proc;this.proc=null,e&&!e.dead&&this.sys.proc===e&&this.sys.killProcess()}interrupt(){if(this.proc&&this.proc.busy){this.proc.interrupt();return}this.con.waiting&&(this.buf=[],this.con.cancel("^C"),this.proc&&!this.running&&this.con.writeln("KeyboardInterrupt","err"),this.showPrompt())}async stopRun(){let e=this.proc;e&&await e.stop(800)}async stop(){++this.pid,this.con.hideInput(),this.sys.isPico&&this.proc&&this.proc.busy&&(this.proc.interrupt(),await new Promise(e=>setTimeout(e,150))),this.dropBackend(),this.running=!1,this.buf=[],this.updateStatus(),this.sys.emit("run"),this.con.writeln(""),this.sys.isPico&&this.con.writeln("MPY: soft reboot","fg-K"),await this.ensureBackend()}async softReboot(){if(!this.sys.isPico)return this.stop();++this.pid,this.con.hideInput(),this.dropBackend(),this.running=!1,this.buf=[],this.con.writeln("MPY: soft reboot","fg-K");let e=await this.ensureBackend(!0);if(this.fs.isFile("/main.py")){if(this.running=!0,this.updateStatus(),this.sys.emit("run"),await e.runFile("/main.py"),e!==this.proc)return;this.running=!1,this.updateStatus(),this.sys.emit("run")}this.con.writeln(this.banner()),this.showPrompt()}shown(){this.visible=!0,this.loadedKind!==this.kind&&this.onSys("board"),this.editor.refresh(),(!this.proc||this.proc.dead||this.sys.proc!==this.proc)&&(!this.sys.proc||this.sys.owner===this||this.sys.owner==null)&&this.ensureBackend()}hidden(){this.visible=!1,this.cur&&(this.cur.text=this.editor.value),this.saveTabs()}};function F2(n){return n<1024?n+" B":(n/1024).toFixed(1)+" KB"}function xh(n,...e){for(;n.firstChild;)n.removeChild(n.firstChild);n.append(...e)}var L=se(ii(),1),Zo=se(Qi(),1);var x0=se($i(),1),S0=se(w0(),1),k0='<svg viewBox="0 0 32 32" width="22" height="22"><path d="M10 5c-2-1.5-5-.5-4.5 1.5.8 2 3 2.6 5.2 2.5zM22 5c2-1.5 5-.5 4.5 1.5-.8 2-3 2.6-5.2 2.5z" fill="#3ec43e"/><g fill="#c51a4a"><circle cx="16" cy="12" r="4"/><circle cx="10" cy="15.5" r="3.8"/><circle cx="22" cy="15.5" r="3.8"/><circle cx="12.6" cy="21" r="3.8"/><circle cx="19.4" cy="21" r="3.8"/><circle cx="16" cy="26" r="3.3"/><circle cx="7.5" cy="21.5" r="2.5"/><circle cx="24.5" cy="21.5" r="2.5"/></g></svg>',ds={terminal:'<svg viewBox="0 0 24 24" width="100%" height="100%"><rect x="2" y="3.5" width="20" height="17" rx="2.5" fill="#2d2d2d" stroke="#111"/><path d="M6 9l3.5 3L6 15" stroke="#7ee787" stroke-width="1.8" fill="none"/><path d="M11 15.5h6" stroke="#ddd" stroke-width="1.8"/></svg>',thonny:'<svg viewBox="0 0 24 24" width="100%" height="100%"><rect x="2" y="2" width="20" height="20" rx="5" fill="#3a7bd5"/><text x="12" y="17" text-anchor="middle" font-size="14" font-weight="700" fill="#fff" font-family="sans-serif">Th</text></svg>',files:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M2 6h7.5l2 2.2H22V20H2z" fill="#4a90d9"/><path d="M2 9.5h20V20H2z" fill="#6aaef0"/></svg>',editor:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 2.5h10l4.5 4.5v14.5H5z" fill="#fff" stroke="#888"/><path d="M8 10h8M8 13h8M8 16h5" stroke="#3a7bd5" stroke-width="1.4"/></svg>',chromium:'<svg viewBox="0 0 24 24" width="100%" height="100%"><circle cx="12" cy="12" r="10" fill="#4285f4"/><path d="M12 2a10 10 0 0 1 8.7 5H12z" fill="#ea4335"/><path d="M3.3 7A10 10 0 0 0 7.6 21l4.4-7.5L7.7 7z" fill="#34a853" opacity=".9"/><circle cx="12" cy="12" r="4.4" fill="#fff"/><circle cx="12" cy="12" r="3.3" fill="#4285f4"/></svg>',calc:'<svg viewBox="0 0 24 24" width="100%" height="100%"><rect x="4" y="2" width="16" height="20" rx="2.5" fill="#555"/><rect x="6.5" y="4.5" width="11" height="4" rx="1" fill="#b9f6ca"/><g fill="#ddd"><rect x="6.5" y="11" width="3" height="2.5" rx=".5"/><rect x="10.5" y="11" width="3" height="2.5" rx=".5"/><rect x="14.5" y="11" width="3" height="2.5" rx=".5"/><rect x="6.5" y="15" width="3" height="2.5" rx=".5"/><rect x="10.5" y="15" width="3" height="2.5" rx=".5"/></g><rect x="14.5" y="15" width="3" height="5.5" rx=".5" fill="#ff9f43"/></svg>',config:'<svg viewBox="0 0 24 24" width="100%" height="100%"><circle cx="12" cy="12" r="10" fill="#c51a4a"/><path d="M12 7.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 2.3a2.2 2.2 0 1 1 0 4.4 2.2 2.2 0 0 1 0-4.4z" fill="#fff"/><g stroke="#fff" stroke-width="2"><path d="M12 3.5v2.5M12 18v2.5M3.5 12H6M18 12h2.5M6 6l1.8 1.8M16.2 16.2L18 18M6 18l1.8-1.8M16.2 7.8L18 6"/></g></svg>',trash:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 7h14l-1.3 14H6.3z" fill="#e8e8e8" stroke="#999"/><rect x="4" y="4.5" width="16" height="2.5" rx="1" fill="#bbb"/><path d="M9.5 10v8M12 10v8M14.5 10v8" stroke="#aaa"/></svg>',py:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 2.5h10l4.5 4.5v14.5H5z" fill="#fff" stroke="#999"/><path d="M12 8c-2.5 0-2.4 1-2.4 1v1.3h2.5v.5H8.6S7 10.6 7 13.2s1.4 2.5 1.4 2.5h.9v-1.2s0-1.4 1.4-1.4h2.4s1.3 0 1.3-1.3V9.4S14.6 8 12 8z" fill="#3776ab"/><path d="M12 19c2.5 0 2.4-1 2.4-1v-1.3h-2.5v-.5h3.5s1.6.2 1.6-2.4-1.4-2.5-1.4-2.5h-.9v1.2s0 1.4-1.4 1.4H11s-1.3 0-1.3 1.3v2.4S9.4 19 12 19z" fill="#ffd43b"/></svg>',txt:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 2.5h10l4.5 4.5v14.5H5z" fill="#fff" stroke="#999"/><path d="M8 10h8M8 13h8M8 16h8" stroke="#999" stroke-width="1.2"/></svg>',folder:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M2 5.5h7.5l2 2.2H22V20H2z" fill="#4a90d9"/><path d="M2 9h20v11H2z" fill="#6aaef0"/></svg>'},Yn={terminal:{title:"Terminal",ic:"terminal",multi:!0,w:640,h:400},thonny:{title:"Thonny",ic:"thonny",w:760,h:560},files:{title:"File Manager",ic:"files",w:620,h:440},editor:{title:"Text Editor",ic:"editor",multi:!0,w:560,h:420},chromium:{title:"Chromium",ic:"chromium",w:720,h:480},calc:{title:"Calculator",ic:"calc",w:280,h:390},config:{title:"Raspberry Pi Configuration",ic:"config",w:520,h:460}},W2=[["Programming",["thonny"]],["Internet",["chromium"]],["Accessories",["files","terminal","editor","calc"]],["Preferences",["config"]]],el=class{constructor(e){this.ctx=e,this.sys=e.sys,this.wins=[],this.z=10,this.build()}get fs(){return this.sys.piFs}build(){this.menuBtn=(0,L.h)("button",{class:"dk-pbtn dk-rasp","aria-label":"Menu",html:k0,onclick:i=>{i.stopPropagation(),this.toggleMenu()}});let e=i=>(0,L.h)("button",{class:"dk-pbtn",title:Yn[i].title,html:`<i class="dk-ic">${ds[Yn[i].ic]}</i>`,onclick:()=>this.open(i)});this.taskbar=(0,L.h)("div",{class:"dk-tasks"}),this.clock=(0,L.h)("span",{class:"dk-clock"});let t=(0,L.h)("div",{class:"dk-tray"},(0,L.h)("span",{class:"dk-tr",title:"Bluetooth",html:'<svg viewBox="0 0 24 24" width="17" height="17"><path d="M7 7l10 10-5 4V3l5 4L7 17" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>'}),(0,L.h)("span",{class:"dk-tr",title:"Wi-Fi: connected to RaptiNet",html:'<svg viewBox="0 0 24 24" width="17" height="17"><path d="M2 9a15 15 0 0 1 20 0M5 12.5a10.5 10.5 0 0 1 14 0M8.5 16a5.5 5.5 0 0 1 7 0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="19.5" r="1.6" fill="currentColor"/></svg>'}),(0,L.h)("span",{class:"dk-tr",title:"Volume",html:'<svg viewBox="0 0 24 24" width="17" height="17"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'}),this.clock);this.panel=(0,L.h)("div",{class:"dk-panel"},this.menuBtn,e("chromium"),e("files"),e("terminal"),(0,L.h)("span",{class:"dk-psep"}),this.taskbar,t),this.menu=(0,L.h)("div",{class:"dk-menu hidden"}),this.drawMenu(),this.icons=(0,L.h)("div",{class:"dk-icons"}),this.area=(0,L.h)("div",{class:"dk-area"},this.icons),this.area.addEventListener("click",()=>this.closeMenu()),this.el=(0,L.h)("div",{class:"desktop"},this.panel,this.area,this.menu),this.drawIcons(),this.sys.on(i=>{i==="files"&&(this.drawIcons(),this.wins.forEach(s=>s.app.refresh&&s.app.refresh()))}),this.tick()}tick(){let e=new Date;this.clock.textContent=`${String(e.getHours()).padStart(2,"0")}:${String(e.getMinutes()).padStart(2,"0")}`,clearTimeout(this.clockT),this.clockT=setTimeout(()=>this.tick(),(60-e.getSeconds())*1e3+50)}drawMenu(){this.menu.innerHTML="";for(let[e,t]of W2){let i=(0,L.h)("div",{class:"dk-sub"});for(let s of t)i.appendChild((0,L.h)("button",{class:"dk-mi",onclick:()=>{this.closeMenu(),this.open(s)}},(0,L.h)("i",{class:"dk-ic",html:ds[Yn[s].ic]}),(0,L.h)("span",{},Yn[s].title)));this.menu.appendChild((0,L.h)("div",{class:"dk-cat"},(0,L.h)("div",{class:"dk-cat-t"},e),i))}this.menu.appendChild((0,L.h)("div",{class:"dk-msep"})),this.menu.appendChild((0,L.h)("button",{class:"dk-mi",onclick:()=>{this.closeMenu(),this.help()}},(0,L.h)("i",{class:"dk-ic",html:(0,Zo.icon)("help",20)}),(0,L.h)("span",{},"Help"))),this.menu.appendChild((0,L.h)("button",{class:"dk-mi",onclick:()=>{this.closeMenu(),this.shutdownDialog()}},(0,L.h)("i",{class:"dk-ic",html:(0,Zo.icon)("power",20)}),(0,L.h)("span",{},"Shutdown\u2026")))}toggleMenu(){this.menu.classList.toggle("hidden")}closeMenu(){this.menu.classList.add("hidden")}drawIcons(){this.icons.innerHTML="";let e=(t,i,s)=>(0,L.h)("button",{class:"dk-dicon",ondblclick:s,onclick:r=>{r.detail<=1&&(this.icons.querySelectorAll(".sel").forEach(o=>o.classList.remove("sel")),r.currentTarget.classList.add("sel"))},onpointerup:r=>{r.pointerType==="touch"&&s()}},(0,L.h)("i",{html:ds[t]}),(0,L.h)("span",{},i));this.icons.appendChild(e("trash","Wastebasket",()=>(0,L.toast)("The wastebasket is empty"))),this.icons.appendChild(e("folder","pi",()=>this.open("files","/home/pi")));for(let t of this.fs.list("/home/pi/Desktop")){let i="/home/pi/Desktop/"+t;this.icons.appendChild(e(this.fs.isDir(i)?"folder":t.endsWith(".py")?"py":"txt",t,()=>this.openPath(i)))}}get phone(){return this.el.clientWidth<700}open(e,t){let i=Yn[e];if(!i.multi){let c=this.wins.find(u=>u.id===e);if(c)return this.focus(c),c.app.openArg&&c.app.openArg(t),c}let s=(0,L.h)("div",{class:"dk-wbody"}),r=(0,L.h)("span",{class:"dk-wtitle"},i.title),o={id:e,def:i,body:s,titleEl:r,el:null,app:null,max:!0},l=(c,u,p,y)=>(0,L.h)("button",{class:"dk-wbtn "+c,"aria-label":y,html:u,onclick:v=>{v.stopPropagation(),p()}}),a=(0,L.h)("div",{class:"dk-wbar"},(0,L.h)("i",{class:"dk-ic",html:ds[i.ic]}),r,l("min",'<svg viewBox="0 0 12 12" width="12" height="12"><path d="M2 9h8" stroke="currentColor" stroke-width="1.6"/></svg>',()=>this.minimize(o),"Minimise"),l("max",'<svg viewBox="0 0 12 12" width="12" height="12"><rect x="2" y="2" width="8" height="8" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>',()=>this.toggleMax(o),"Maximise"),l("close",'<svg viewBox="0 0 12 12" width="12" height="12"><path d="M2.5 2.5l7 7M9.5 2.5l-7 7" stroke="currentColor" stroke-width="1.6"/></svg>',()=>this.close(o),"Close"));o.el=(0,L.h)("div",{class:"dk-win"},a,s),o.el.addEventListener("pointerdown",()=>this.focus(o),!0),this.dragWin(o,a);let f=this.wins.length;return Object.assign(o.el.style,{width:i.w+"px",height:i.h+"px",left:30+f*26+"px",top:14+f*22+"px"}),o.max=this.phone||i.w>this.el.clientWidth-20,o.el.classList.toggle("max",o.max),this.area.appendChild(o.el),this.wins.push(o),o.task=(0,L.h)("button",{class:"dk-task",onclick:()=>o.el.classList.contains("min")||this.top!==o?this.focus(o):this.minimize(o)},(0,L.h)("i",{class:"dk-ic",html:ds[i.ic]}),(0,L.h)("span",{},i.title)),this.taskbar.appendChild(o.task),o.app=this.makeApp(e,o,t),this.focus(o),o}makeApp(e,t,i){let s=r=>{t.titleEl.textContent=r,t.task.lastChild.textContent=r};switch(e){case"terminal":{let r=new Jo({sys:this.sys,onExit:()=>this.close(t),openThonny:o=>this.openThonny(o),openFile:o=>this.openPath(o),openUrl:o=>this.open("chromium",o||"http://start.rapti.net/")});return t.body.appendChild(r.el),s("pi@raspberrypi: ~"),setTimeout(()=>r.con.focus(),60),{term:r,destroy:()=>{r.alive=!1,r.con.hideInput(),this.sys.owner===r&&this.sys.killProcess()}}}case"thonny":{let r=this.ctx.thonny;return t.body.appendChild(r.joined()),r.shown(),i&&r.open(i),s("Thonny  -  "+(r.cur&&r.cur.path?r.cur.path:"<untitled>")),{openArg:o=>{o&&r.open(o)},destroy:()=>{r.hidden()},thonny:!0}}case"files":return this.fileManager(t,i||"/home/pi",s);case"editor":return this.textEditor(t,i,s);case"chromium":return this.chromium(t,i,s);case"calc":return this.calculator(t);case"config":return this.configApp(t);default:return{}}}dragWin(e,t){let i=0,s=0,r=0,o=0,l=!1;t.addEventListener("pointerdown",a=>{e.max||a.target.closest("button")||(l=!0,i=a.clientX,s=a.clientY,r=e.el.offsetLeft,o=e.el.offsetTop,t.setPointerCapture(a.pointerId))}),t.addEventListener("pointermove",a=>{l&&(e.el.style.left=Math.max(-200,r+a.clientX-i)+"px",e.el.style.top=Math.max(0,o+a.clientY-s)+"px")}),t.addEventListener("pointerup",()=>{l=!1}),t.addEventListener("dblclick",()=>this.toggleMax(e))}focus(e){e.el.classList.remove("min"),e.el.style.zIndex=++this.z,this.top=e,this.wins.forEach(t=>t.task.classList.toggle("active",t===e)),e.app&&e.app.thonny&&this.ctx.thonny.editor.refresh()}minimize(e){e.el.classList.add("min"),e.task.classList.remove("active");let t=this.wins.filter(i=>i!==e&&!i.el.classList.contains("min"));this.top=t[t.length-1]||null}toggleMax(e){e.max=!e.max,e.el.classList.toggle("max",e.max),e.app&&e.app.thonny&&this.ctx.thonny.editor.refresh()}close(e){e.app&&e.app.destroy&&e.app.destroy(),e.el.remove(),e.task.remove(),this.wins=this.wins.filter(t=>t!==e)}thonnyWin(){return this.wins.find(e=>e.id==="thonny")}reclaimThonny(){let e=this.thonnyWin();e&&!e.body.contains(this.ctx.thonny.el)&&e.body.appendChild(this.ctx.thonny.joined())}openThonny(e){this.open("thonny",e)}openPath(e){this.fs.isDir(e)?this.open("files",e):e.endsWith(".py")?this.openThonny(e):this.open("editor",e)}fileManager(e,t,i){let s=t,r=[],o=this.fs,l=(0,L.h)("input",{class:"fm-path",value:s,onkeydown:O=>{O.key==="Enter"&&v(ue(l.value,s))}}),a=(0,L.h)("div",{class:"fm-list"}),f=(0,L.h)("div",{class:"fm-side"});for(let[O,k]of[["Home","/home/pi"],["Desktop","/home/pi/Desktop"],["Documents","/home/pi/Documents"],["Downloads","/home/pi/Downloads"],["projects","/home/pi/projects"],["Filesystem root","/"]])f.appendChild((0,L.h)("button",{class:"fm-place",onclick:()=>v(k)},(0,L.h)("i",{class:"dk-ic",html:ds.folder}),(0,L.h)("span",{},O)));let c=(O,k,T)=>(0,L.h)("button",{class:"fm-tb",title:k,html:(0,Zo.icon)(O,18),onclick:T}),u=(0,L.h)("div",{class:"fm-status"}),p=()=>{l.value=s,i(s==="/home/pi"?"pi":Te(s)||"/"),a.innerHTML="";let O=[];try{O=o.list(s).filter(k=>!k.startsWith("."))}catch{O=[]}O.sort((k,T)=>o.isDir(ue(T,s))-o.isDir(ue(k,s))||k.localeCompare(T));for(let k of O){let T=ue(k,s),P=o.isDir(T),I=(0,L.h)("button",{class:"fm-item",onclick:()=>P?v(T):this.openPath(T)},(0,L.h)("i",{html:ds[P?"folder":k.endsWith(".py")?"py":"txt"]}),(0,L.h)("span",{},k));I.addEventListener("contextmenu",R=>{R.preventDefault(),y(T,k)});let E;I.addEventListener("pointerdown",()=>{E=setTimeout(()=>{E=null,y(T,k)},600)}),I.addEventListener("pointerup",()=>clearTimeout(E)),I.addEventListener("pointerleave",()=>clearTimeout(E)),a.appendChild(I)}u.textContent=`${O.length} items \xB7 Free space: 22.4 GB (Total: 29.0 GB)`},y=async(O,k)=>{let T=await(0,L.dialog)({title:k,body:"<p>What do you want to do?</p>",actions:[{label:"Rename",value:"ren",cls:"btn-ghost"},{label:"Delete",value:"del",cls:"btn-danger"},{label:"Cancel",value:null,cls:"btn-ghost"}]});if(T==="del")await(0,L.confirmDialog)("Delete",`Delete ${k}?`,"Delete",!0)&&(o.remove(O,!0),this.sys.emit("files"));else if(T==="ren"){let P=await(0,L.promptDialog)("Rename",k);P&&P!==k&&(o.move(O,ue(P,Dt(O))),this.sys.emit("files"))}},v=O=>{if(!o.isDir(O)){(0,L.toast)("Not a folder","error");return}O!==s&&r.push(s),s=O,p()},b=(0,L.h)("div",{class:"fm-bar"},c("arrowLeft","Back",()=>{r.length&&(s=r.pop(),p())}),c("back","Up",()=>v(Dt(s))),c("home","Home",()=>v("/home/pi")),l,c("folder","New folder",async()=>{let O=await(0,L.promptDialog)("New folder","New Folder");O&&(o.mkdir(ue(O,s),!0),this.sys.emit("files"))}),c("plus","New file",async()=>{let O=await(0,L.promptDialog)("New file","new.py");if(O){let k=ue(O,s);o.exists(k)||o.write(k,""),this.sys.emit("files"),this.openPath(k)}}));return e.body.appendChild((0,L.h)("div",{class:"fm"},b,(0,L.h)("div",{class:"fm-main"},f,a),u)),p(),{refresh:p,openArg:O=>{O&&v(O)}}}textEditor(e,t,i){let s=this.fs,r=(0,L.h)("textarea",{class:"te-text",spellcheck:"false",autocapitalize:"off"}),o=t||null,l=!1,a=()=>i(`${l?"*":""}${o?Te(o):"Untitled"} - Text Editor`);o&&s.isFile(o)&&(r.value=s.read(o)),r.addEventListener("input",()=>{l||(l=!0,a())});let f=async()=>{if(!o){let p=await(0,L.promptDialog)("Save as","/home/pi/Documents/untitled.txt");if(!p)return;o=ue(p,"/home/pi")}if(!s.write(o,r.value)){(0,L.toast)(`Storage is full: ${Te(o)} could not be saved`,"error",6e3);return}l=!1,a(),this.sys.emit("files"),(0,L.toast)("Saved "+Te(o),"ok")},c=async()=>{let p=await(0,L.promptDialog)("Open file",o||"/home/pi/Documents/notes.txt");if(!p)return;let y=ue(p,"/home/pi");if(!s.isFile(y)){(0,L.toast)("No such file","error");return}o=y,r.value=s.read(y),l=!1,a()},u=(p,y)=>(0,L.h)("button",{class:"te-mb",onclick:y},p);return e.body.appendChild((0,L.h)("div",{class:"te"},(0,L.h)("div",{class:"te-menu"},u("New",()=>{o=null,r.value="",l=!1,a()}),u("Open",c),u("Save",f),u("Save As",async()=>{let p=o;o=null,await f(),o||(o=p)})),r)),r.addEventListener("keydown",p=>{p.ctrlKey&&p.key==="s"&&(p.preventDefault(),f())}),a(),{}}chromium(e,t,i){let s=this.sys.net,r=new S0.VirtualBrowser({net:s,origin:this.sys.netDev,home:"http://start.rapti.net/",start:!1,bookmarks:[["Start","http://start.rapti.net/"],["RAPTI","http://rapti.net/"],["Google","https://www.google.com/"],["Wikipedia","https://en.wikipedia.org/"],["Dashboard","http://dashboard.rapti.net/"],["localhost:5000","http://localhost:5000/"],["localhost:8000","http://localhost:8000/"],["Weather","http://wttr.in/Dhaka"],["HiveMQ","http://www.hivemq.com/demos/websocket-client/"],["Docs","http://docs.rapti.net/"]],onTitle:o=>i("Chromium \u2014 "+(o||"New Tab"))});return e.body.appendChild(r.el),r.go(t||"http://start.rapti.net/"),{openArg:o=>{o&&r.go(/^[a-z]+:\/\//i.test(o)?o:r.fixUrl(o))},destroy:()=>r.destroy()}}calculator(e){let t=(0,L.h)("div",{class:"calc-disp"},"0"),i="",s=o=>{if(o==="C")i="";else if(o==="\u232B")i=i.slice(0,-1);else if(o==="=")try{if(!/^[\d+\-*/().% ]*$/.test(i))throw new Error;let l=Function(`"use strict";return (${i.replace(/%/g,"/100")})`)();i=Number.isFinite(l)?String(Math.round(l*1e10)/1e10):"Error"}catch{i="Error"}else i==="Error"&&(i=""),i+=o;t.textContent=i||"0"},r=["C","\u232B","%","/","7","8","9","*","4","5","6","-","1","2","3","+","0",".","(",")","="];return e.body.appendChild((0,L.h)("div",{class:"calc"},t,(0,L.h)("div",{class:"calc-keys"},...r.map(o=>(0,L.h)("button",{class:"calc-k"+(/[=]/.test(o)?" eq":/[+\-*/%]/.test(o)?" op":""),onclick:()=>s(o)},o))))),{}}configApp(e){let t="/boot/firmware/config.txt",i=this.fs,s=()=>i.isFile(t)?i.read(t):"",r=k=>k.test(s()),o=(k,T)=>{let P=s(),I=new RegExp(`^#?${k.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}=on\\s*$`,"m");I.test(P)?P=P.replace(I,T?`${k}=on`:`#${k}=on`):T&&(P+=`${k}=on
`),i.write(t,P)},l=(()=>{try{return JSON.parse(localStorage.getItem("rapti.pi.config")||"{}")}catch{return{}}})(),a=()=>{try{localStorage.setItem("rapti.pi.config",JSON.stringify(l))}catch{}},f=(k,T,P)=>{let I=(0,L.h)("button",{class:"cfg-radio"+(T()?" on":"")},"On"),E=(0,L.h)("button",{class:"cfg-radio"+(T()?"":" on")},"Off"),R=()=>{I.classList.toggle("on",T()),E.classList.toggle("on",!T())};return I.onclick=()=>{P(!0),R()},E.onclick=()=>{P(!1),R()},(0,L.h)("div",{class:"cfg-row"},(0,L.h)("span",{},k),(0,L.h)("div",{class:"cfg-tog"},I,E))},c=(k,T)=>[()=>l[k]??T,P=>{l[k]=P,a()}],u=(k,T)=>(0,L.h)("div",{class:"cfg-row"},(0,L.h)("span",{},k),(0,L.h)("b",{},T)),p=x0.BOARDS[this.sys.board.startsWith("pico")?"pi5":this.sys.board],y={System:()=>[u("Password:","\u2022\u2022\u2022\u2022\u2022\u2022"),u("Hostname:","raspberrypi"),f("Boot to desktop:",...c("desktop",!0)),f("Auto login:",...c("autologin",!0)),f("Splash screen:",...c("splash",!0)),u("Board:",p.model)],Display:()=>[f("Screen blanking:",...c("blank",!1)),u("Resolution:","1920 \xD7 1080 (HDMI-A-1)")],Interfaces:()=>[f("SSH:",...c("ssh",!1)),f("VNC:",...c("vnc",!1)),f("SPI:",()=>r(/^dtparam=spi=on/m),k=>o("dtparam=spi",k)),f("I2C:",()=>r(/^dtparam=i2c_arm=on/m),k=>o("dtparam=i2c_arm",k)),f("Serial Port:",...c("serial",!1)),f("Serial Console:",...c("serialc",!1)),f("1-Wire:",...c("onewire",!1)),f("Remote GPIO:",...c("rgpio",!1))],Performance:()=>[u("Overlay File System:","Disabled"),u("Fan:",this.sys.board==="pi5"?"Automatic (Active Cooler)":"Not fitted")],Localisation:()=>[u("Locale:","en_GB.UTF-8"),u("Timezone:",Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC"),u("Keyboard:","English (US)"),u("WLAN Country:","BD Bangladesh")]},v=(0,L.h)("div",{class:"cfg-tabs"}),b=(0,L.h)("div",{class:"cfg-body"}),O=k=>{v.querySelectorAll("button").forEach(T=>T.classList.toggle("on",T.textContent===k)),b.innerHTML="",b.append(...y[k]())};for(let k of Object.keys(y))v.appendChild((0,L.h)("button",{onclick:()=>O(k)},k));return e.body.appendChild((0,L.h)("div",{class:"cfg"},v,b,(0,L.h)("div",{class:"cfg-foot"},(0,L.h)("button",{class:"cfg-btn",onclick:()=>this.close(e)},"Cancel"),(0,L.h)("button",{class:"cfg-btn pri",onclick:()=>{(0,L.toast)("Settings saved (some take effect after a reboot)","ok"),this.close(e)}},"OK")))),O("System"),{}}help(){let e=this.open("editor"),t=e.body.querySelector("textarea");t.value=`RaptiAuto virtual Raspberry Pi \u2014 help

\u2022 Terminal: a simulated bash. Try: ls, cd, cat, nano, pinout, pinctrl get 17,
  vcgencmd measure_temp, python3 blink.py, python3 (interactive).
\u2022 Thonny: write Python, press Run. Stop restarts the program.
\u2022 Python runs on a real MicroPython 1.29 engine with gpiozero, RPi.GPIO,
  neopixel and adafruit_dht libraries made for this simulator.
\u2022 The Board tab shows the GPIO header live and the parts you wired.
\u2022 There is no internet and no apt / pip installs; files are kept on this phone.
`,e.titleEl.textContent="Help - Text Editor"}async shutdownDialog(){let e=await(0,L.dialog)({title:"Shutdown options",body:"<p>What do you want to do?</p>",actions:[{label:"Shutdown",value:"off",cls:"btn-danger"},{label:"Reboot",value:"reboot",cls:"btn-ghost"},{label:"Logout",value:"logout",cls:"btn-ghost"},{label:"Cancel",value:null,cls:"btn-ghost"}]});if(!e)return;for(let s of[...this.wins])s.id!=="thonny"&&this.close(s);let t=this.thonnyWin();t&&this.close(t),this.sys.killProcess(),e!=="logout"&&this.sys.gpio.reset();let i=(0,L.h)("div",{class:"dk-veil"},(0,L.h)("div",{class:"dk-veil-logo",html:k0.replace(/width="22" height="22"/,'width="90" height="90"')}),(0,L.h)("p",{},e==="off"?"Power off":e==="reboot"?"Rebooting\u2026":"Logging out\u2026"));this.el.appendChild(i),e==="off"?(i.appendChild((0,L.h)("button",{class:"btn btn-primary dk-power",onclick:()=>{i.querySelector("p").textContent="Starting\u2026",i.querySelector(".dk-power").remove(),setTimeout(()=>i.remove(),1500)}},"Power on")),this.ctx.onShutdown&&this.ctx.onShutdown()):setTimeout(()=>i.remove(),e==="reboot"?2200:900)}shown(){this.reclaimThonny(),this.tick(),this.thonnyWin()&&this.ctx.thonny.shown()}hidden(){this.closeMenu()}};var G0=se(P0(),1);var q0=se(E0(),1),B0=se(R0(),1),$0=se(N0(),1),jt=se(ii(),1),Ph=se(Qi(),1),Vt=se(I0(),1),F0=se(Q0(),1),Kn=se(ml(),1),Th=null,tl=class extends q0.Editor{constructor(e,t,i){Th=i,super(e,t),Th=null}build(){this.pi=Th,this.root=(0,jt.h)("section",{class:"pane pane-circuit pi-circuit"}),this.circuitPane=this.root,this.canvasHost=(0,jt.h)("div",{class:"canvas-host"}),this.root.appendChild(this.canvasHost),this.canvas=new B0.CircuitCanvas(this.canvasHost,this),this.buildCircuitOverlay(),this.status=(0,jt.h)("div",{class:"sim-status pi-sim-status hidden"}),this.stale=(0,jt.h)("div",{class:"stale-banner hidden",html:`${(0,Ph.icon)("restart",16)}<span>Circuit changed \u2014 Stop and Run again to apply</span>`,onclick:()=>this.pi.restart()}),this.root.append(this.status,this.stale)}boardPart(){return this.project.parts.find(e=>(0,Vt.getDef)(e.type)&&(0,Vt.getDef)(e.type).board)}mount(e){e.appendChild(this.root),this.canvas.render(),requestAnimationFrame(()=>this.canvas.fit(!1))}shown(){requestAnimationFrame(()=>{this.canvas.applyView(),this.canvas.render()})}unmount(){this.stopEngine(),this.canvas.destroy(),this.audio.close(),this.root.remove()}updateLayout(){}setTab(){}setFullscreen(e){this.pi.setFullscreen(e)}setChrome(e){this.pi.setChrome(e)}leave(){this.pi.leave()}saveNow(){this.pi.saveCircuit()}showBoardInfo(){this.pi.boardSheet()}load(e,{undoable:t=!0}={}){t?(this.history.push(this.snapshot),this.future=[]):(this.history=[],this.future=[]),this.project.parts=e.parts,this.project.wires=e.wires,this.snapshot=this.serialize(),this.canvas.selection=null,this.canvas.render(),this.selectionChanged(null),requestAnimationFrame(()=>this.canvas.fit(!1))}addComponent(){if(this.engine){(0,jt.toast)("Stop the program to change the circuit","warn");return}(0,$0.openLibrary)({onPick:e=>this.placePartNow(e),noBoards:!0,title:"Add a part to the Pi"})}placePartNow(e){let t=this.boardPart();if(!t||e.layer===-1){super.placePartNow(e);return}let i=typeof e.box=="function"?e.box((0,Vt.defaultProps)(e)):e.box,s=i[2]-i[0],r=i[3]-i[1],[o,l,a]=(0,Vt.worldBox)(t),f=this.project.parts.map(R=>(0,Vt.worldBox)(R)),c=(R,N)=>!f.some(([B,J,fe,Z])=>R<fe+12&&R+s>B-12&&N<Z+12&&N+r>J-12),u=null;for(let R=0;R<8&&!u;R++){let N=l-50-r-R*(r+40);for(let B=o;B<=Math.max(a,o+200)&&!u;B+=20)c(B,N)&&(u=[B,N])}if(!u){super.placePartNow(e);return}let p={id:(0,Vt.newId)("p"),type:e.type,x:Math.round((u[0]-i[0])/10)*10,y:Math.round((u[1]-i[1])/10)*10,rot:0,props:{}};this.project.parts.push(p),this.commit("Add "+e.name),this.canvas.select({kind:"part",id:p.id});let y=this.canvasHost.getBoundingClientRect(),[v,b,O,k]=(0,Vt.worldBox)(p),[T,P]=this.canvas.worldToScreen(v,b),[I,E]=this.canvas.worldToScreen(O,k);(T<y.left||P<y.top||I>y.right||E>y.bottom)&&this.canvas.fit(),this.showHint("Drag to move. Tap one of its pins, then a pin of the Pi header, to draw a wire."),Kn.Native.vibrate(10)}deleteSelected(){let e=this.canvas.selection,t=this.boardPart();if(e&&t&&e.kind==="part"&&e.id===t.id){(0,jt.toast)("The board stays \u2014 change it with the board chip at the top","info");return}e&&t&&e.kind==="multi"&&e.parts.includes(t.id)&&(e.parts=e.parts.filter(i=>i!==t.id)),super.deleteSelected()}startEngine(){if(this.engine)return this.engine;this.canvas.wiring&&this.canvas.cancelWiring(),this.canvas.select(null),this.warnings=[],this.audio.resume();let e=new F0.SimEngine(this.project,{external:!0,onWarning:s=>this.addWarning(s),onError:s=>this.runtimeError(s),onSound:(s,r,o)=>this.audio.set(s,r,this.settings.sound===!1?0:o),onBurn:()=>{Kn.Native.vibrate(40),this.settings.sound!==!1&&this.audio.pop()}}),t=e.start();if(!t.ok)return(0,jt.toast)(t.error&&t.error.message||"The circuit could not start","error"),null;this.engine=e,this.pi.root.classList.add("simulating"),this.canvas.setMode("sim"),this.selectionChanged(null),this.status.classList.remove("hidden"),Kn.Native.keepScreenOn(!0),this.lastFrame=performance.now();let i=s=>{if(!this.engine)return;let r=Math.min(.1,(s-this.lastFrame)/1e3);this.lastFrame=s,this.engine.tick(this.engine.lastWall!=null?Math.max(s,this.engine.lastWall):s),this.engine&&(this.pi.onCircuitFrame&&this.pi.onCircuitFrame(r),this.pi.tab==="circuit"&&(this.canvas.frame(r),this.updateStatus()),this.raf=requestAnimationFrame(i))};return this.raf=requestAnimationFrame(i),e}stopEngine(){this.engine&&(cancelAnimationFrame(this.raf),this.engine.stop(),this.engine=null,this.audio.stopAll(),this.simSheet&&(this.simSheet.close(),this.simSheet=null),this.pi.root.classList.remove("simulating"),this.canvas.setMode("edit"),this.status.classList.add("hidden"),this.stale.classList.add("hidden"),Kn.Native.keepScreenOn(!1))}run(){this.pi.runProgram()}stop(){this.pi.stopAll()}toggleRun(){this.pi.toggleRun()}restart(){this.pi.restart()}updateStatus(){if(!this.engine)return;let i=`<span class="dot live"></span><b>${this.pi.programRunning()?"Python running":"Powered"}</b><span class="speed">${this.pi.sys.info.short}</span>`+(this.warnings.length?`<button class="warn-pill" id="warnpill">${(0,Ph.icon)("warning",14)}<span>${this.warnings.length}</span></button>`:"");if(i!==this._st){this._st=i,this.status.innerHTML=i;let s=this.status.querySelector("#warnpill");s&&(s.onclick=()=>this.showWarnings())}}runtimeError(e){let t=e||{message:"Unknown error"};this.pi.stopAll(),(0,jt.dialog)({title:t.electrical?"\u26A1 Power cut":"Circuit error",body:`<p>${String(t.message).replace(/[&<>]/g,i=>({"&":"&amp;","<":"&lt;",">":"&gt;"})[i])}</p>`,actions:[{label:"OK",value:!0,cls:"btn-primary"}]})}};var Zn=()=>typeof performance<"u"?performance.now():Date.now(),il=class{constructor(e){this.engine=e,this.warned=new Set,this.rx={},e.opts.onUart=(t,i)=>{this.rx[t]=((this.rx[t]||"")+i).slice(-4096)}}has(e){return!!(this.engine.pins&&this.engine.pins.has(e))}advance(){this.pace(),this.engine.advanceTo(Zn())}quietForEcho(){if(!this.quiet)return;let e=this.engine,t=e.time(),i=0;for(let s of e.parts.values())s&&s.def&&s.def.type==="hc-sr04"&&s.pending&&(i=Math.max(i,s.pending.start+s.pending.width));i>t&&this.quiet(Zn()+(i-t)/1e3+6)}pace(){let e=Zn();if(this.lastAccess!=null){let i=(e-this.lastAccess)*1e3;i<5e3&&(this.gapUs=this.gapUs?this.gapUs*.8+i*.2:i)}this.lastAccess=e;let t=Math.max(450,Math.min(2e4,6*(this.gapUs||0)));for(let i of this.engine.parts.values())i&&i.def&&i.def.type==="hc-sr04"&&(i.echoDelayUs=t)}syncPin(e){let t=this.engine,i=e.n,s=t.pins&&t.pins.get(i);if(s)if(t.lastWall!=null?t.advanceTo(Math.max(Zn(),t.lastWall+.01)):this.advance(),e.mode==="out")s.servoUs!=null&&t.setServo(i,null),s.tone&&t.noTone(i),s.mode!==1&&t.pinMode(i,1),t.digitalWrite(i,e.out?1:0),e.out||this.quietForEcho();else if(e.mode==="pwm"){let r=e.freq||0,o=Math.max(0,Math.min(1,e.duty));s.mode!==1&&t.pinMode(i,1),r>=40&&r<=330&&o>0&&o<.2&&this.on(i,"servo","PWM")?(s.tone&&t.noTone(i),t.setServo(i,o*1e6/r)):r>=20&&this.on(i,"buzzer")&&this.passive(i)?(s.servoUs!=null&&t.setServo(i,null),o>.02&&o<.98?t.tone(i,r,0):(t.noTone(i),t.digitalWrite(i,o>=.98?1:0))):(s.servoUs!=null&&t.setServo(i,null),s.tone&&t.noTone(i),t.analogWrite(i,o,Math.round(o*255),255))}else{let r=e.pull==="up"?2:e.pull==="down"?3:0;s.servoUs!=null&&t.setServo(i,null),s.tone&&t.noTone(i),s.mode!==r&&t.pinMode(i,r)}}read(e){let t=this.engine;if(!this.has(e))return 0;this.advance();let i=t.digitalRead(e),s=t.pins.get(e);return s&&s.node>=0&&s.mode!==1&&t.vAvg(s.node)-t.vAvg(t.gnd)>3.9&&this.warnOnce("5v"+e,`${s.id} sees ${(t.vAvg(s.node)-t.vAvg(t.gnd)).toFixed(1)} V \u2014 Raspberry Pi GPIOs are 3.3 V only! Use a voltage divider (e.g. 1 k\u03A9 + 2 k\u03A9) on 5 V signals such as the HC-SR04 ECHO.`),i}partsOn(e,t,i=null){let s=this.engine;return this.has(e)?s.partsOnPin(e,r=>r.def&&r.def.type===t,i).map(r=>r.rt):[]}on(e,t,i=null){return this.partsOn(e,t,i).length>0}partsBehind(e,t,i=null){let s=this.partsOn(e,t,i);if(s.length)return s;let r=this.engine;if(!this.has(e))return[];let o=[];for(let l of r.resistiveNeighbours(r.pinNode(e)))o.push(...r.partsOnNode(l,a=>a.def&&a.def.type===t,i).map(a=>a.rt));return o}passive(e){return this.partsOn(e,"buzzer").some(t=>(t.part.props||{}).kind!=="active")}adc(e){let t=26+e;return e>2||!this.has(t)?null:(this.advance(),Math.max(0,Math.min(1,this.engine.analogRead(t)/3.3)))}mcp3008(e){let t=this.engine;this.advance(),t.ensureSolved();let i=s=>t.pinNode(s);for(let s of t.parts.values()){if(!s.mcp3008)continue;let r=s.part.id,o=t.nodeOf(r,"CLK")===i(11)&&t.nodeOf(r,"DOUT")===i(9)&&t.nodeOf(r,"DIN")===i(10),l=[i(8),i(7)].includes(t.nodeOf(r,"CS"));if(!o||!l){this.warnOnce("mcpwire","MCP3008: wire CLK \u2192 GPIO11 (SCLK), DOUT \u2192 GPIO9 (MISO), DIN \u2192 GPIO10 (MOSI) and CS \u2192 GPIO8 (CE0)");continue}return s.powered()?s.read(e):(this.warnOnce("mcppwr","MCP3008 has no power: VDD and VREF to 3V3, AGND and DGND to GND"),0)}return this.warnOnce("mcpnone","gpiozero MCP3008: add an MCP3008 ADC to the circuit (the Pi has no analog inputs)"),0}distance(e){let t=this.partsBehind(e,"hc-sr04","ECHO")[0];return t?t.powered()?(t.visual.ping=Zn(),Math.max(.02,Math.min(4,t.distance/100))):(this.warnOnce("srpwr","HC-SR04 has no power: VCC to 5V, GND to GND"),-1):-1}dht(e,t){let i=this.partsOn(e,"dht22","DATA")[0];if(!i||i.powered&&!i.powered())return-999;let s=i.read();return t?s.h:s.t}light(e){let t=this.partsOn(e,"ldr-module","DO")[0]||this.partsOn(e,"ldr-module","AO")[0];return t?Math.max(0,Math.min(1,Math.log10(1+t.values.lux)/Math.log10(1001))):this.read(e)?0:1}neo(e,t){this.has(e)&&this.engine.sendWs2812(e,t)}uartWrite(e,t){return this.advance(),this.engine.externalUartOut(e,t)}uartWired(e){let t=this.engine,i=(t.board&&t.board.uart||{})[e];if(!i)return!1;let s=t.pinNode(i.rx),r=t.pinNode(i.tx);return(t.boards||[]).slice(1).some(o=>Object.values(o.board.uart||{s:{rx:0,tx:1}}).some(l=>o.pinNode(l.rx)===r||o.pinNode(l.tx)===s))}uartAny(e){return(this.rx[e]||"").length}uartRead(e,t){let i=this.rx[e]||"",s=t<0?i.length:Math.min(t,i.length);return this.rx[e]=i.slice(s),i.slice(0,s)}i2cBus(e,t){let i=this.engine.board&&this.engine.board.i2c||{};return{sda:e==null||e<0?i.sda:e,scl:t==null||t<0?i.scl:t}}i2cDevices(e,t,i){let s=this.engine,r=this.i2cBus(e,t),o=s.pinNode(r.sda),l=s.pinNode(r.scl),a=[];for(let f of s.parts.values()){if(!f.i2c||f===s.boardRt)continue;let c=f.i2cPins||f.def.i2cPins||{sda:"SDA",scl:"SCL"},u=s.nodeOf(f.part.id,c.sda),p=s.nodeOf(f.part.id,c.scl);(u>=0&&p>=0&&u===o&&p===l||i)&&a.push(f)}return a}i2cMissing(e,t,i){let s=this.engine,r=this.i2cBus(t,i),o=new Set(this.i2cDevices(t,i)),l=new Set([...s.pins.values()].map(c=>c.node).filter(c=>c>=0)),a=c=>{let u=s.pins.get(c);return u?u.id:"GPIO"+c},f=/^GP\d/.test(a(r.sda));for(let c of this.i2cDevices(t,i,!0)){if(o.has(c)||e!=null&&c.i2c.address!==e)continue;let u=c.i2cPins||c.def.i2cPins||{sda:"SDA",scl:"SCL"},p=s.nodeOf(c.part.id,u.sda),y=s.nodeOf(c.part.id,u.scl);if(!l.has(p)&&!l.has(y))continue;let v=`${c.def.name||c.def.type} at I\xB2C address 0x${c.i2c.address.toString(16).toUpperCase().padStart(2,"0")}`,b=p===s.pinNode(r.scl)&&y===s.pinNode(r.sda),O=f?`the I2C bus of your program (sda=Pin(${r.sda}), scl=Pin(${r.scl}))`:"the Raspberry Pi's I\xB2C bus (SDA = GPIO2 / pin 3, SCL = GPIO3 / pin 5)";this.warnOnce(`i2cpins:${c.part.id}:${r.sda}:${r.scl}`,b?`${v}: SDA and SCL are swapped \u2014 wire ${u.sda} \u2192 ${a(r.sda)} and ${u.scl} \u2192 ${a(r.scl)}`:`${v} is not on ${O}: wire ${u.sda} \u2192 ${a(r.sda)} and ${u.scl} \u2192 ${a(r.scl)}`)}}i2cOn(e,t,i){let s=this.i2cDevices(t,i).find(r=>r.i2c.address===e);return s||this.i2cMissing(e,t,i),s}i2cHas(e,t,i){this.engine.ensureSolved();let s=this.i2cOn(e,t,i);return!!s&&(!s.powered||s.powered())}i2cScan(e,t){this.engine.ensureSolved();let i=this.i2cDevices(e,t).filter(s=>!s.powered||s.powered()).map(s=>s.i2c.address).sort((s,r)=>s-r);return i.length||this.i2cMissing(null,e,t),i}i2cRead(e,t,i,s){this.advance();let r=this.i2cOn(e,i,s);if(r&&r.i2cRead){let o=r.i2cRead(t);return this.engine.dirty=!0,o}return new Array(t).fill(r?0:255)}i2cWrite(e,t,i,s){let r=this.i2cOn(e,i,s);if(r&&r.i2cWrite){this.advance(),r.i2cWrite(t),this.engine.dirty=!0;return}if(r&&r.ssd1306){this.advance(),this.ssd1306Write(r,t);return}if(!r||!r.hd44780)return;let o=r.hd44780,l=r._pcf||(r._pcf={en:0,hi:null,rs:0,mode8:!0,cg:-1});for(let a of t){o.backlight=!!(a&8);let f=a>>2&1;if(l.en&&!f){let c=a>>4,u=a&1;if(l.mode8)c===2&&(l.mode8=!1);else if(l.hi===null)l.hi=c,l.rs=u;else{let p=l.hi<<4|c;l.hi=null,l.rs?this.lcdData(o,l,p):this.lcdCmd(o,l,p)}}l.en=f}o.touch(),this.engine.dirty=!0}lcdCmd(e,t,i){i&128?(e.addr=i&127,t.cg=-1):i&64?t.cg=i&63:i&32?(e.initialized||e.init(),(i&16)===16&&(t.mode8=!0)):i&16?i&8?e.scroll(i&4?1:-1):e.step(i&4?1:-1):i&8?(e.on=!!(i&4),e.cursor=!!(i&2),e.blink=!!(i&1),e.initialized||e.init()):i&4?(e.inc=!!(i&2),e.autoShift=!!(i&1)):i&2?e.home():i&1&&(e.initialized||e.init(),e.clear())}lcdData(e,t,i){if(t.cg>=0){e.cgram[t.cg&63]=i&31,t.cg=t.cg+1&63;return}e.initialized||e.init(),e.write(i)}ssd1306Write(e,t){let i=e.ssd1306;if(e.powered&&!e.powered())return;let s=e._ssd||(e._ssd={mode:0,col:0,pg:0,c0:0,c1:127,p0:0,p1:7,need:0,cur:0,args:[]}),r=0;for(;r<t.length;){let o=t[r++],l=o&64;if(o&128)r<t.length&&this.ssdItem(i,s,l,t[r++]);else for(;r<t.length;)this.ssdItem(i,s,l,t[r++])}i.version++,this.engine.dirty=!0}ssdItem(e,t,i,s){if(i){if(t.pg>=0&&t.pg<e.h/8&&t.col>=0&&t.col<e.w)for(let r=0;r<8;r++)e.fb[(t.pg*8+r)*e.w+t.col]=s>>r&1;t.mode===1?++t.pg>t.p1&&(t.pg=t.p0,++t.col>t.c1&&(t.col=t.c0)):t.mode===2?t.col=(t.col+1)%e.w:++t.col>t.c1&&(t.col=t.c0,++t.pg>t.p1&&(t.pg=t.p0));return}if(t.need){if(t.args.push(s),--t.need)return;let r=t.args;switch(t.cur){case 32:t.mode=r[0]&3;break;case 33:t.c0=r[0]&127,t.c1=r[1]&127,t.col=t.c0;break;case 34:t.p0=r[0]&7,t.p1=r[1]&7,t.pg=t.p0;break;case 129:e.contrast=r[0]/255;break;default:break}return}if([32,129,211,213,217,218,219,141,168,173].includes(s)){t.cur=s,t.need=1,t.args=[];return}if(s===33||s===34){t.cur=s,t.need=2,t.args=[];return}if(s===38||s===39){t.cur=s,t.need=6,t.args=[];return}if(s===41||s===42){t.cur=s,t.need=5,t.args=[];return}if(s===163){t.cur=s,t.need=2,t.args=[];return}s===174?e.on=!1:s===175?e.on=!0:s===166?e.invert=!1:s===167?e.invert=!0:s>=176&&s<=183?t.pg=s&7:s<=15?(t.col=t.col&112|s&15,t.mode===2&&(t.c0=0)):s>=16&&s<=31&&(t.col=t.col&15|(s&7)<<4)}dispTm1637(e,t,i,s,r){let o=this.partsOn(e,"tm1637","CLK").find(a=>this.partsOn(t,"tm1637","DIO").includes(a));if(!o)return this.warnOnce("tmwire",`TM1637 display not found on CLK=GPIO${e}, DIO=GPIO${t}. Wire CLK, DIO, VCC and GND.`),0;if(o.powered&&!o.powered())return this.warnOnce("tmpwr","TM1637 has no power: VCC to 3V3 / 5V, GND to GND"),0;let l=o.tm1637;return l.brightness=s&7,l.on=!!r,i.length&&l.set(0,i),l.version++,this.engine.dirty=!0,1}spiXfer(e,t,i){this.advance();let s=new Array(i.length).fill(0);for(let r of this.partsOn(t,"max7219","DIN")){if(!this.partsOn(e,"max7219","CLK").includes(r))continue;if(r.powered&&!r.powered()){this.warnOnce("mxpwr","MAX7219 has no power: VCC to 5V, GND to GND");continue}let o=r.max7219,l=o.length;for(let a=0;a+1<i.length;a+=2){let f=o[l-1-a/2%l],c=i[a]&15,u=i[a+1]&255;c>=1&&c<=8?f.rows[c-1]=u:c===10?f.intensity=u&15:c===12&&(f.shutdown=!(u&1)),f.version++}return this.engine.dirty=!0,s}if(i.length===3&&i[0]===1&&i[1]&128){let r=Math.round(Math.max(0,Math.min(1,this.mcp3008(i[1]>>4&7)))*1023);return[0,r>>8&3,r&255]}return s}pinStates(e){let t=new Map;for(let i of e.pins.values()){if(!this.has(i.n))continue;let s=i.mode==="out"?i.out:i.mode==="pwm"?i.duty>=.5?1:0:i.used||i.watch?this.quietLevel(i.n):null;t.set(i.n,i.mode==="pwm"?"pwm":i.mode==="out"?i.out?"ohi":"olo":s==null?"":s?"ihi":"ilo")}return t}quietLevel(e){let t=this.engine,i=t.pins.get(e);return!i||i.node<0?0:t.vAvg(i.node)-t.vAvg(t.gnd)>1.65?1:0}warnOnce(e,t){this.warned.has(e)||(this.warned.add(e),this.engine.warn(t,null,"pi:"+e))}};var Mi=se(z0(),1),nl=se(rr(),1),X0=se(V0(),1),j2=[["circuit","circuit","Circuit"],["board","chip","Pinout"],["desktop","screen","Desktop"],["thonny","code","Thonny"],["output","list","Output"]],V2=[["circuit","circuit","Circuit"],["board","chip","Pinout"],["thonny","code","Thonny"],["output","list","Output"]],H0=n=>"rapti.pi.circuit.v1."+n,sl=class{constructor(e){this.app=e;let t="pi5";try{t=localStorage.getItem("rapti.pi.board")||"pi5"}catch{}nt.BOARDS[t]||(t="pi5"),this.sys=new or(t,qd),this.sys.gpio.parts=[],this.audio=new U0.AudioEngine;try{this.audio.enabled=localStorage.getItem("rapti.pi.mute")!=="1"}catch{}this.tab="circuit",this.panes=null,this.vis=["circuit"],this.fullscreen=!1,this.build(),this.offSys=this.sys.on(i=>this.onSys(i)),this.offGpio=this.sys.gpio.on(()=>this.refresh())}get isPico(){return this.sys.isPico}get settings(){return this.app.settings}build(){this.root=(0,Q.h)("div",{class:"screen pi-screen editor"});let e=(0,Q.h)("button",{class:"icon-btn","aria-label":"Back",html:(0,Fe.icon)("back"),onclick:()=>this.leave()});this.boardChip=(0,Q.h)("button",{class:"board-chip",onclick:()=>this.boardSheet()}),this.runDot=(0,Q.h)("span",{class:"pi-run-dot"}),this.runBtn=(0,Q.h)("button",{class:"run-btn pi-runbtn",onclick:()=>this.toggleRun()});let t=(0,Q.h)("button",{class:"icon-btn","aria-label":"Menu",html:(0,Fe.icon)("dots"),onclick:s=>this.menu(s.currentTarget)});this.top=(0,Q.h)("header",{class:"ed-top pi-top"},e,(0,Q.h)("div",{class:"ed-titles"},(0,Q.h)("div",{class:"pi-title"},"Raspberry Pi Lab",this.runDot),this.boardChip),this.runBtn,t),this.main=(0,Q.h)("main",{class:"pi-main"}),this.panes_={circuit:(0,Q.h)("div",{class:"pi-pane pane-pcircuit"}),board:(0,Q.h)("div",{class:"pi-pane pane-board"}),desktop:(0,Q.h)("div",{class:"pi-pane pane-desktop"}),thonny:(0,Q.h)("div",{class:"pi-pane pane-thonny"}),output:(0,Q.h)("div",{class:"pi-pane pane-output"})};for(let s of Object.values(this.panes_))this.main.appendChild(s);this.nav=(0,Q.h)("nav",{class:"ed-nav pi-nav"});let i=(s,r,o,l={})=>(0,Q.h)("button",{class:"fs-btn",title:r,"aria-label":r,html:(0,Fe.icon)(s,20),onclick:o,...l});this.fsRun=i("play","Run",()=>this.toggleRun(),{class:"fs-btn fs-run"}),this.fsBar=(0,Q.h)("div",{class:"fs-bar pi-fsbar"},i("fullscreenExit","Exit full screen",()=>this.setFullscreen(!1)),this.fsRun,i("circuit","Circuit",()=>this.toggleTab("circuit"),{"data-tab":"circuit"}),i("code","Thonny",()=>this.toggleTab("thonny"),{"data-tab":"thonny"}),i("list","Output",()=>this.toggleTab("output"),{"data-tab":"output"}),i("chip","Pinout",()=>this.toggleTab("board"),{"data-tab":"board"})),this.fsHandle=(0,Q.h)("button",{class:"fs-handle","aria-label":"Show menus",title:"Show menus",html:(0,Fe.icon)("menu",19)}),this.root.append(this.top,this.main,this.nav,this.fsBar),this.dock=new X0.FsDock({root:this.root,bar:this.fsBar,handle:this.fsHandle,key:"pi",orient:"col",home:{fx:0,fy:1},settings:this.settings,save:()=>this.app.saveSettings(),toggle:()=>this.setChrome(this.root.classList.contains("fs-clean"))}),this.thonny=new Yo({sys:this.sys,wire:s=>this.wireExample(s),onRun:()=>this.revealOutput()}),this.desktop=new el({sys:this.sys,thonny:this.thonny}),this.panes_.desktop.appendChild(this.desktop.el),this.buildCircuitPane(),this.buildBoardPane(),this.drawNav(),this.drawBoard(),this.updateRun(),this.ro=new ResizeObserver(()=>this.updateLayout()),this.ro.observe(this.root)}drawNav(){this.nav.innerHTML="";for(let[e,t,i]of this.isPico?V2:j2)this.nav.appendChild((0,Q.h)("button",{class:"nav-tab"+(e===this.tab?" active":""),"data-tab":e,onclick:()=>this.toggleTab(e),html:`${(0,Fe.icon)(t,22)}<span>${i}</span>`}));this.fsBar.querySelector('[data-tab="thonny"]').hidden=!1}visibleTabs(){return this.wide&&this.panes&&this.panes.includes(this.tab)?this.panes:[this.tab]}toggleTab(e){if(this.isPico&&e==="desktop"&&(e="circuit"),!this.wide){this.setTab(e);return}let t=[...this.visibleTabs()];if(t.includes(e)){if(t.length<2){Ri.Native.vibrate(5);return}t=t.filter(i=>i!==e)}else t.length<2&&!this.clash(t[0],e)?t.push(e):t.length<2?t=[e]:t[1]=e;t.length>1&&this.clash(t[0],t[1])&&(t=[e]),this.panes=t,this.setTab(t[t.length-1]),Ri.Native.vibrate(8)}clash(e,t){let i=s=>s==="thonny"||s==="output";return e==="desktop"&&i(t)||t==="desktop"&&i(e)}showOutput(){this.vis.includes("output")||(this.wide&&this.vis.length<2&&this.vis.includes("thonny")?this.toggleTab("output"):this.setTab("output"))}revealOutput(){if(!(this.vis.includes("output")||this.vis.includes("desktop"))){if(!this.wide){(0,Q.toast)("Running \u2014 the output is on the Output tab");return}if(this.vis.length<2){this.toggleTab("output");return}this.fromRunBtn&&this.vis.includes("circuit")&&(this.panes=this.vis.map(e=>e==="circuit"?e:"output"),this.setTab("output"))}}updateLayout(){let e=this.root.getBoundingClientRect(),t=e.width>=760&&e.width>e.height*1.05;t!==this.wide&&(this.wide=t,this.root.classList.toggle("wide",t),this.setTab(this.tab))}setTab(e){if(this.isPico&&e==="desktop"&&(e="circuit"),this.panes){if(!this.wide)this.panes=null;else if(!this.panes.includes(e)){let c=this.panes.indexOf(this.tab);this.panes=c>=0&&this.panes.length>1?this.panes.map((u,p)=>p===c?e:u):[e]}}let t=this.vis||[this.tab];this.tab=e;let i=this.visibleTabs();this.vis=i;let s=c=>t.includes(c),r=c=>i.includes(c),o=i.length>1;this.root.classList.toggle("pi-split",o);let l=Object.keys(this.panes_).filter(c=>r(c));for(let[c,u]of Object.entries(this.panes_))u.classList.toggle("active",r(c)),u.classList.toggle("first",c===l[0]),u.classList.toggle("last",c===l[l.length-1]);this.nav.querySelectorAll(".nav-tab").forEach(c=>c.classList.toggle("active",r(c.dataset.tab))),this.fsBar.querySelectorAll("[data-tab]").forEach(c=>c.classList.toggle("active",r(c.dataset.tab))),this.root.dataset.tab=e,s("desktop")&&!r("desktop")&&this.desktop.hidden();let a=r("thonny")||r("output"),f=s("thonny")||s("output");a?(this.thonny.splitInto(this.panes_.thonny,this.panes_.output),(!f||e==="thonny"||e==="output")&&(this.thonny.shown(),r("output")&&this.thonny.con.scrollEnd())):(f||s("desktop")&&!r("desktop")&&!this.desktop.thonnyWin())&&this.thonny.hidden(),r("desktop")&&(!s("desktop")||e==="desktop")&&this.desktop.shown(),r("circuit")&&(!s("circuit")||e==="circuit")&&this.circuit.shown(),r("board")&&(!s("board")||e==="board")&&this.refresh(!0),!r("circuit")&&this.circuit&&this.circuit.canvas.wiring&&this.circuit.canvas.cancelWiring(),i.join()!==t.join()&&this.circuit&&setTimeout(()=>{this.circuit.canvas.applyView(),this.thonny.editor&&this.thonny.editor.refresh()},60)}buildCircuitPane(){this.circuit=new tl(this.app,{name:"Pi circuit",parts:[],wires:[],code:""},this),this.circuit.load(this.loadCircuit(this.sys.board),{undoable:!1}),this.circuit.mount(this.panes_.circuit),this.fileChip=(0,Q.h)("button",{class:"pi-filechip",onclick:()=>this.fileSheet()}),this.circuit.root.append(this.fileChip),this.drawFileChip()}loadCircuit(e){try{let t=JSON.parse(localStorage.getItem(H0(e))||"null");if(t&&Array.isArray(t.parts)&&t.parts.some(i=>i.type===G0.CIRCUIT_TYPE[e]))return{parts:t.parts,wires:t.wires||[]}}catch{}return(0,Mi.defaultCircuit)(e)}saveCircuit(){try{localStorage.setItem(H0(this.sys.board),JSON.stringify({parts:this.circuit.project.parts,wires:this.circuit.project.wires}))}catch{(0,Q.toast)("Storage is full \u2014 the circuit could not be saved","error")}}wireExample(e){e.circuit&&this.sys.isPico||!e.circuit&&(!e.parts||!e.parts.length)||(this.stopCircuit(),this.circuit.load(e.circuit?e.circuit(this.sys.board):(0,Mi.autowire)(this.sys.board,e.parts)),this.isPico||(this.chosenFile="/home/pi/"+e.file,this.drawFileChip()),this.saveCircuit())}onCircuitFrame(){let e=this.sys.gpio,t=e.hw;if(!t)return;if(e.pins){for(let s of e.pins.values())if(s.watch){e.inputsChanged();break}}let i=this.circuit.engine&&this.circuit.engine.boardRt;if(i&&(this.fr=(this.fr||0)+1)%3===0){i.visual.pinSt=t.pinStates(e);let s=performance.now();i.visual.act=this.sys.running?Math.sin(s/37)+Math.sin(s/13)>.4:s%4e3<90;let r=this.sys.info.led;i.visual.L=r!=null&&e.pins.has(r)&&e.drive(r)||0}}powerOn(){if(this.circuit.engine)return!0;let e=this.circuit.startEngine();return e?(this.sys.gpio.attachHw(new il(e)),this.updateRun(),!0):(this.noAutoUntil=performance.now()+5e3,!1)}stopCircuit(){this.circuit.engine&&(this.sys.gpio.attachHw(null),this.circuit.stopEngine(),this.updateRun())}programRunning(){return!!(this.thonny.running||this.sys.running)}async toggleRun(){if(this.circuit.engine||this.programRunning()){await this.stopAll();return}await this.runProgram()}async runProgram(){let e=this.runFile();if(!e){(0,Q.toast)("No Python file yet: write one in Thonny","warn");return}this.audio.resume(),this.powerOn()&&(this.thonny.open(e),this.fromRunBtn=!0,this.thonny.run(),this.fromRunBtn=!1,this.updateRun())}async stopAll(){this.noAutoUntil=performance.now()+900,this.programRunning()&&await this.thonny.stop(),this.stopCircuit(),this.updateRun()}async restart(){await this.stopAll(),await this.runProgram()}updateRun(){let e=!!(this.circuit&&this.circuit.engine)||this.programRunning();this.runDot.classList.toggle("on",this.programRunning()),this.runBtn.classList.toggle("running",e),this.runBtn.innerHTML=e?`${(0,Fe.icon)("stop",18)}<span>Stop</span>`:`${(0,Fe.icon)("play",20)}<span>Run</span>`,this.fsRun.innerHTML=(0,Fe.icon)(e?"stop":"play",20),this.fsRun.classList.toggle("running",e)}runFile(){let e=this.pyFiles(),t=this.chosenFile&&e.includes(this.chosenFile)?this.chosenFile:null;return!t&&this.thonny.cur&&e.includes(this.thonny.cur.path)&&(t=this.thonny.cur.path),t||(t=e.includes(this.isPico?"/main.py":"/home/pi/blink.py")?this.isPico?"/main.py":"/home/pi/blink.py":e[0]),t||null}pyFiles(){let e=this.sys.fs,t=[],i=(s,r)=>{for(let o of e.list(s)){let l=ue(o,s);o.startsWith(".")||(e.isDir(l)?r<2&&i(l,r+1):o.endsWith(".py")&&t.push(l))}};try{i(this.sys.home,0)}catch{}return t}drawFileChip(){let e=this.runFile();this.fileChip.innerHTML=`${(0,Fe.icon)("code",15)}<span>${e?this.isPico?e.replace(/^\//,""):e.replace("/home/pi/",""):"no .py file"}</span>${(0,Fe.icon)("forward",12)}`}fileSheet(){let e=(0,Q.h)("div",{class:"pin-pick"}),t=this.runFile();for(let s of this.pyFiles())e.appendChild((0,Q.h)("button",{class:"pin-opt"+(s===t?" active":""),onclick:()=>{i.close(),this.chosenFile=s,this.drawFileChip()}},(0,Q.h)("b",{},this.isPico?s.replace(/^\//,""):s.replace("/home/pi/","")),(0,Q.h)("span",{},"Run this file")));e.appendChild((0,Q.h)("button",{class:"btn btn-ghost",html:`${(0,Fe.icon)("code",16)}<span>Open in Thonny</span>`,onclick:()=>{i.close();let s=this.runFile();this.setTab("thonny"),s&&this.thonny.open(s)}}));let i=new Q.Sheet({title:"Program to run",icon:"code",content:e,height:"70vh"}).open()}setFullscreen(e){this.fullscreen=e,this.circuit.fullscreen=e,(0,Q.smoothSwap)(()=>{this.root.classList.toggle("fs",e),this.setChrome(!e,!1),Ri.Native.setImmersive(e)},()=>{this.circuit.canvas.applyView(),setTimeout(()=>{this.circuit.canvas.applyView(),this.thonny.editor&&this.thonny.editor.refresh()},80)}),e&&!this.settings.piFsHinted&&(this.settings.piFsHinted=!0,this.app.saveSettings(),(0,Q.toast)("Full screen \u2014 tap \u2630 for the menus, drag it to move it")),Ri.Native.vibrate(8)}setChrome(e,t=!0){this.root.classList.toggle("fs-clean",!e),this.fsHandle.innerHTML=(0,Fe.icon)(e?"close":"menu",19),this.fsHandle.setAttribute("aria-label",e?"Hide menus":"Show menus"),this.dock&&this.dock.place(),t&&Ri.Native.vibrate(6),setTimeout(()=>this.circuit.canvas.applyView(),30)}buildBoardPane(){let e=this.panes_.board;this.svgWrap=(0,Q.h)("div",{class:"pb-svg"}),this.zoom=1;let t=(s,r)=>(0,Q.h)("button",{class:"pb-zoom",html:(0,Fe.icon)(s,18),onclick:()=>{this.zoom=Math.max(1,Math.min(2.6,this.zoom+r)),this.svgWrap.style.setProperty("--z",this.zoom)}});this.zooms=(0,Q.h)("div",{class:"pb-zooms"},t("minus",-.4),t("plus",.4)),this.strip=(0,Q.h)("div",{class:"pb-strip"}),this.boardBox=(0,Q.h)("div",{class:"pb-board"},this.svgWrap,this.strip),this.legend=(0,Q.h)("div",{class:"pb-legend"}),this.legendRow=(0,Q.h)("div",{class:"pb-legrow"},this.legend,this.zooms),this.pinoutNote=(0,Q.h)("div",{class:"pb-note"},(0,Q.h)("span",{html:(0,Fe.icon)("circuit",18)}),(0,Q.h)("div",{},(0,Q.h)("b",{},"Wire parts in the Circuit tab"),(0,Q.h)("small",{},"Add LEDs, buttons, sensors, motors \u2026 with \uFF0B, tap a pin then another pin to draw a wire, then Run. Tap a pin here for its functions.")),(0,Q.h)("button",{class:"btn btn-primary sm",onclick:()=>this.setTab("circuit")},"Circuit")),this.specs=(0,Q.h)("div",{class:"pb-specs"}),e.append((0,Q.h)("div",{class:"pb-inner"},this.boardBox,this.legendRow,this.pinoutNote,this.specs));let i=s=>{let r=s.target.closest("[data-phys]");r&&this.pinSheet(Number(r.dataset.phys))};this.svgWrap.addEventListener("click",i),this.strip.addEventListener("click",i)}drawBoard(){let e=this.sys.info;if(this.boardChip.innerHTML=`${(0,Fe.icon)("chip",14)}<span>${e.name}</span>${(0,Fe.icon)("forward",12)}`,this.svgWrap.innerHTML=(0,nt.boardSVG)(this.sys.board,"po-"),this.svg=this.svgWrap.querySelector("svg"),this.pinEls=new Map,this.svg.querySelectorAll(".hp[data-gpio]").forEach(r=>this.pinEls.set(Number(r.dataset.gpio),r)),this.strip.innerHTML="",this.stripEls=new Map,this.strip.hidden=this.isPico,!this.isPico){let r=(0,nt.headerOf)(this.sys.board),o=l=>(0,Q.h)("div",{class:"ps-row"},...r.filter(a=>a.phys%2===1===l).map(a=>{let f=(0,Q.h)("button",{class:"ps-pin t-"+a.type,"data-phys":a.phys},(0,Q.h)("i"),(0,Q.h)("b",{},a.gpio!=null?String(a.gpio):a.name.replace("GND","\u23DA")),(0,Q.h)("small",{},String(a.phys)));return a.gpio!=null&&this.stripEls.set(a.gpio,f),f}));this.strip.append(o(!1),o(!0))}this.actLed=this.svg.querySelector(".led-act"),this.userLed=this.svg.querySelector(".led-user");let t=this.svg.querySelector(".bootsel");if(t){let r=l=>{l.preventDefault(),this.sys.gpio.bootsel=1,t.classList.add("down"),Ri.Native.vibrate(8)},o=()=>{this.sys.gpio.bootsel=0,t.classList.remove("down")};t.addEventListener("pointerdown",r),t.addEventListener("pointerup",o),t.addEventListener("pointerleave",o),t.addEventListener("pointercancel",o)}let i=this.svg.querySelector(".pwr-btn");i&&i.addEventListener("click",()=>{this.setTab("desktop"),this.desktop.shutdownDialog()}),this.legend.innerHTML="";let s=(r,o)=>(0,Q.h)("span",{class:"lg "+r},(0,Q.h)("i"),o);this.legend.append(s("l-3v3","3V3"),s("l-5v","5V"),s("l-gnd","GND"),s("l-gpio","GPIO"),s("l-hi","HIGH"),s("l-pwm","PWM"),s("l-in","Input")),this.drawSpecs(),this.drawFileChip(),this.refresh(!0)}drawSpecs(){let e=this.sys.info,t=(i,s)=>s?(0,Q.h)("div",{class:"spec"},(0,Q.h)("span",{},i),(0,Q.h)("b",{},s)):null;this.specs.innerHTML="",this.specs.append(...[(0,Q.h)("div",{class:"pb-sec"},(0,Q.h)("b",{},e.name),(0,Q.h)("span",{class:"muted"},` \xB7 ${e.year}`)),t(e.kind==="pico"?"MCU":"SoC",e.mcu||e.soc),t("CPU",e.cpu),t("Memory",e.ram),t("Flash",e.flash),t("GPU",e.gpu),t("I/O",e.io),t("Runs",e.kind==="pico"?"MicroPython 1.29 (machine, rp2"+(e.wifi?", network":"")+", neopixel, dht, i2c_lcd)":"Python 3 programs (gpiozero, RPi.GPIO, neopixel, adafruit_dht, i2c_lcd) on a MicroPython 1.29 engine")].filter(Boolean))}refresh(e){if(this.tab!=="board"&&!e)return;let t=this.sys.gpio,i=t.hw;for(let[s,r]of this.pinEls||[]){let o=t.pins.get(s);if(!o)continue;let l=o.mode!=="in"?t.level(s):i&&i.has(s)?i.quietLevel(s):t.read(s),a=o.mode==="pwm"?"pwm":o.mode==="out"?o.out?"ohi":"olo":o.used||o.watch?l?"ihi":"ilo":l?"fhi":"flo";r.dataset.st!==a&&(r.dataset.st=a);let f=this.stripEls&&this.stripEls.get(s);f&&f.dataset.st!==a&&(f.dataset.st=a),a==="pwm"?r.querySelector(".pst").style.opacity=String(.25+o.duty*.75):r.querySelector(".pst").style.opacity=""}if(this.userLed){let s=this.sys.info.led,r=t.pins.has(s)&&t.drive(s)||0;this.userLed.style.setProperty("--on",String(r)),this.userLed.classList.toggle("on",r>.02)}}loop(){this.raf=requestAnimationFrame(()=>this.loop());let e=performance.now();if(this.actLed&&this.tab==="board"){let s=this.sys.running?Math.sin(e/37)+Math.sin(e/13)>.4:e%4e3<90;s!==this.actOn&&(this.actOn=s,this.actLed.classList.toggle("on",s))}!this.circuit.engine&&this.sys.running&&!(this.noAutoUntil>e)&&this.powerOn();let t=this.programRunning();t!==this.lastRunning&&(this.lastRunning=t,this.updateRun())}boardSheet(){let e=(0,Q.h)("div",{class:"pi-boards"});for(let i of nt.BOARD_ORDER){let s=nt.BOARDS[i];e.appendChild((0,Q.h)("button",{class:"pi-bopt"+(i===this.sys.board?" active":""),onclick:()=>{t.close(),i!==this.sys.board&&this.switchBoard(i)}},(0,Q.h)("div",{class:"pi-bthumb",html:(0,nt.boardSVG)(i,`th-${i}-`)}),(0,Q.h)("div",{},(0,Q.h)("b",{},s.name),(0,Q.h)("small",{},`${s.cpu} \xB7 ${s.ram}`),(0,Q.h)("small",{class:"muted"},s.kind==="pico"?"MicroPython \xB7 Thonny":"Desktop (with Terminal) \xB7 Thonny \xB7 Python 3"))))}let t=new Q.Sheet({title:"Choose a board",icon:"chip",content:e,height:"80vh"}).open()}start(e={}){if(e.board&&nt.BOARDS[e.board]&&e.board!==this.sys.board&&this.switchBoard(e.board,!0),e.example){let t=(this.isPico?nl.PICO_EXAMPLES:nl.PI_EXAMPLES).find(i=>i.file===e.example);if(!t)return;this.thonny.openExample(t),this.isPico&&(this.chosenFile=null),this.drawFileChip(),this.setTab(t.circuit||t.parts&&t.parts.length?"circuit":"thonny")}else e.newProject&&this.newProject()}newProject(){this.stopCircuit(),this.saveCircuit(),this.circuit.load((0,Mi.boardOnly)(this.sys.board)),this.saveCircuit();let e=this.sys.fs,t=this.isPico?"":"/home/pi",i=1;for(;e.isFile(`${t}/project${i}.py`);)i++;let s=`${t}/project${i}.py`;e.write(s,this.isPico?U2:H2),this.chosenFile=s,this.drawFileChip(),this.thonny.open(s),this.setTab("circuit"),(0,Q.toast)(`New project: add parts with \uFF0B, then write project${i}.py in Thonny`,"ok")}switchBoard(e,t=!1){this.stopCircuit(),this.saveCircuit(),this.sys.setBoard(e),t||(0,Q.toast)(`${nt.BOARDS[e].name} ready`,"ok")}pinSheet(e){let t=(0,nt.headerOf)(this.sys.board).find(l=>l.phys===e);if(!t)return;let i=this.sys.gpio,s=[["Physical pin",String(e)],["Type",{power3:"3.3 V power",power5:"5 V power",gnd:"Ground",gpio:"GPIO",i2c:"GPIO (I\xB2C)",spi:"GPIO (SPI)",uart:"GPIO (UART)",id:"GPIO (HAT ID EEPROM)",adc:"GPIO + ADC",sys:"System pin"}[t.type]]];if(t.gpio!=null){let l=i.pins.get(t.gpio);s.push([this.isPico?"GP number":"BCM number",String(t.gpio)]),t.alt&&s.push(["Alt functions",t.alt]),s.push(["Mode",l.mode==="pwm"?`PWM ${l.freq} Hz, ${Math.round(l.duty*100)}%`:l.mode==="out"?"Output":"Input"]),s.push(["Level",(l.mode!=="in"?i.level(t.gpio):i.hw&&i.hw.has(t.gpio)?i.hw.quietLevel(t.gpio):i.read(t.gpio))?"HIGH (3.3 V)":"LOW (0 V)"]),l.mode==="in"&&s.push(["Pull",l.pull==="up"?"Pull-up":l.pull==="down"?"Pull-down":"None (floating)"]);let a=(this.isPico?"GP":"GPIO")+t.gpio,f=this.circuit.boardPart(),c=f?this.circuit.project.wires.filter(u=>u.from.part===f.id&&u.from.pin===a||u.to.part===f.id&&u.to.pin===a).length:0;s.push(["Wires on the canvas",String(c)]),s.push(["Python",this.isPico?`Pin(${t.gpio})`:`LED(${t.gpio}) \xB7 Button(${t.gpio}) \xB7 GPIO.setup(${t.gpio}, \u2026)`])}else t.type==="power3"?s.push(["Note","Max ~50 mA from the 3V3 pins."]):t.type==="power5"&&s.push(["Note","Straight from the power supply. Never connect 5 V to a GPIO pin!"]);let r=(0,Q.h)("div",{class:"pin-info"},...s.map(([l,a])=>(0,Q.h)("div",{class:"spec"},(0,Q.h)("span",{},l),(0,Q.h)("b",{},a))));r.appendChild((0,Q.h)("button",{class:"btn btn-ghost",html:`${(0,Fe.icon)("circuit",16)}<span>Wire it in the Circuit tab</span>`,onclick:()=>{o.close(),this.setTab("circuit")}}));let o=new Q.Sheet({title:t.gpio!=null?`${(0,nt.pinLabel)(this.sys.board,t.gpio)} \xB7 pin ${e}`:`${t.name} \xB7 pin ${e}`,icon:"pin",content:r}).open()}menu(e){(0,Q.popupMenu)(e,[{icon:"chip",label:"Change board",action:()=>this.boardSheet()},{icon:"fullscreen",label:this.fullscreen?"Exit full screen":"Full screen",action:()=>this.setFullscreen(!this.fullscreen)},{icon:this.audio.enabled?"bell":"close",label:this.audio.enabled?"Mute buzzer sound":"Turn buzzer sound on",action:()=>{this.audio.enabled=!this.audio.enabled,this.audio.enabled||this.audio.stopAll();try{localStorage.setItem("rapti.pi.mute",this.audio.enabled?"0":"1")}catch{}}},"-",{icon:"restart",label:"Default circuit",action:async()=>{await(0,Q.confirmDialog)("Default circuit","Replace the circuit with the default parts? (Undo brings it back.)","Replace")&&(this.stopCircuit(),this.circuit.load((0,Mi.defaultCircuit)(this.sys.board)),this.saveCircuit(),this.setTab("circuit"))}},{icon:"trash",label:"Clear the circuit (keep the board)",danger:!0,action:async()=>{await(0,Q.confirmDialog)("Clear the circuit","Remove every part and wire except the board? (Undo brings them back.)","Clear",!0)&&(this.stopCircuit(),this.circuit.load((0,Mi.boardOnly)(this.sys.board)),this.saveCircuit(),this.setTab("circuit"))}},{icon:"trash",label:this.isPico?"Erase the Pico flash":"Reset the SD card (files)",danger:!0,action:()=>this.resetFiles()},"-",{icon:"info",label:"About the simulator",action:()=>this.about()}])}async resetFiles(){await(0,Q.confirmDialog)(this.isPico?"Erase the flash":"Reset the SD card","All your files on this board go back to the examples. Continue?","Reset",!0)&&(this.sys.resetFs(),this.thonny.onSys("board"),(0,Q.toast)(this.isPico?"Flash erased":"SD card reset","ok"))}about(){let e=(0,Q.h)("div",{class:"dialog-body pi-about"},(0,Q.h)("p",{},"Python runs on a real MicroPython 1.29 interpreter compiled to WebAssembly, inside the app (it needs no real internet: the simulated Wi-Fi network is built in)."),(0,Q.h)("p",{},"The Circuit tab uses the same parts and circuit solver as the Arduino simulator: wire LEDs with resistors, buttons, sensors, motors, displays \u2026 to the header, and the GPIOs drive and read the real circuit (3.3 V logic, ~16 mA per pin, pull-ups, 5 V warnings)."),(0,Q.h)("p",{},"Raspberry Pi 5 / 4: Python 3 style programs with gpiozero, RPi.GPIO, neopixel, adafruit_dht, RPLCD / i2c_lcd, adafruit_ssd1306 (OLED), tm1637, max7219 + spidev, requests, flask, http.server, socket, paho-mqtt and psutil. Pico boards: MicroPython machine (I2C, SPI), rp2, neopixel, dht, ssd1306, tm1637, max7219, i2c_lcd and \u2014 on the Pico W \u2014 network, urequests, umqtt and ntptime."),(0,Q.h)("p",{class:"muted"},"Not simulated: a real Linux kernel, real apt / pip installs, the camera, PIO programs, CPython-only libraries such as numpy or OpenCV."));new Q.Sheet({title:"About the Raspberry Pi Lab",icon:"info",content:e}).open()}onSys(e){e==="board"?(this.isPico&&this.tab==="desktop"&&this.setTab("circuit"),this.sys.gpio.parts=[],this.drawNav(),this.drawBoard(),this.circuit.load(this.loadCircuit(this.sys.board),{undoable:!1}),this.chosenFile=null,this.drawFileChip(),this.panes_.board.scrollTop=0):e==="files"?this.drawFileChip():e==="input"?(this.tab==="circuit"||this.tab==="board"||this.tab==="desktop"&&!this.desktop.thonnyWin()||this.tab==="thonny"&&!this.vis.includes("output"))&&this.showOutput():(e==="run"||e==="proc")&&(this.updateRun(),this.drawFileChip())}mount(e){e.appendChild(this.root),this.unback=(0,Q.pushBack)(()=>this.onBack()),this.setTab(this.tab),this.loop(),this.audioResume=()=>{this.audio.resume(),this.circuit.audio.resume()},this.root.addEventListener("pointerdown",this.audioResume),this.circuit.project.parts.length<=1&&this.circuit.showHint("Tap \uFF0B to add parts, tap a pin and then another pin to draw a wire, then Run.")}onBack(){let e=()=>{this.unback=(0,Q.pushBack)(()=>this.onBack())};if(this.fullscreen){this.setFullscreen(!1),e();return}if(this.tab==="circuit"&&this.circuit.canvas.wiring){this.circuit.canvas.cancelWiring(),e();return}if(this.tab==="circuit"&&this.circuit.canvas.selection){this.circuit.canvas.select(null),e();return}if(this.tab==="desktop"&&this.desktop.top&&this.desktop.wins.length){this.desktop.close(this.desktop.top),e();return}if(this.tab!=="circuit"){this.setTab("circuit"),e();return}this.unback=null,this.leave()}leave(){this.fullscreen&&this.setFullscreen(!1),this.saveCircuit(),this.app.showHome()}unmount(){cancelAnimationFrame(this.raf),this.ro&&this.ro.disconnect(),this.unback&&this.unback(),this.unback=null,this.thonny.hidden(),this.sys.gpio.attachHw(null),this.circuit.unmount(),this.sys.killProcess(),this.audio.stopAll(),this.audio.close&&this.audio.close(),this.offSys(),this.offGpio(),this.fullscreen&&Ri.Native.setImmersive(!1),clearTimeout(this.desktop.clockT);try{this.thonny.editor.view.destroy()}catch{}this.root.remove()}saveNow(){this.thonny.cur&&(this.thonny.cur.text=this.thonny.editor.value,this.thonny.saveTabs()),this.saveCircuit()}onPause(){this.saveNow(),this.audio.suspend(),this.circuit.audio.suspend(),this.circuit.engine&&(this.circuit.engine.paused=!0)}onResume(){this.circuit.engine&&(this.circuit.engine.paused=!1,this.circuit.engine.lastWall=null)}};var H2=`# My Raspberry Pi project
# 1. Circuit tab: add parts with +, then wire them to the header pins
# 2. Write the program here and press Run
from gpiozero import LED
from time import sleep

led = LED(17)          # GPIO17 = pin 11

while True:
    led.toggle()
    sleep(0.5)
`,U2=`# My Raspberry Pi Pico project (MicroPython)
# 1. Circuit tab: add parts with +, then wire them to the GP pins
# 2. Write the program here and press Run
from machine import Pin
import time

led = Pin(15, Pin.OUT)

while True:
    led.toggle()
    time.sleep(0.5)
`;window.__raptiPi={PiScreen:sl};})();
