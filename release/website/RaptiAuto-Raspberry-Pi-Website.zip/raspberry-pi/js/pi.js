(()=>{var gb=Object.create;var mc=Object.defineProperty;var _b=Object.getOwnPropertyDescriptor;var yb=Object.getOwnPropertyNames;var bb=Object.getPrototypeOf,Ob=Object.prototype.hasOwnProperty;var vb=(r=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(r,{get:(e,t)=>(typeof require<"u"?require:e)[t]}):r)(function(r){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+r+'" is not supported')});var Ie=(r,e)=>()=>(e||r((e={exports:{}}).exports,e),e.exports);var wb=(r,e,t,i)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of yb(e))!Ob.call(r,s)&&s!==t&&mc(r,s,{get:()=>e[s],enumerable:!(i=_b(e,s))||i.enumerable});return r};var se=(r,e,t)=>(t=r!=null?gb(bb(r)):{},wb(e||!r||!r.__esModule?mc(t,"default",{value:r,enumerable:!0}):t,r));var ii=Ie((U2,gc)=>{gc.exports=window.__raptiMods["src/ui/widgets.js"]});var Qi=Ie((G2,_c)=>{_c.exports=window.__raptiMods["src/ui/icons.js"]});var ml=Ie((X2,yc)=>{yc.exports=window.__raptiMods["src/native.js"]});var Oc=Ie((J2,bc)=>{bc.exports=window.__raptiMods["src/ui/audio.js"]});var en=Ie((Y2,vc)=>{vc.exports=window.__raptiMods["src/pi/gpio.js"]});var Tc=Ie((sT,Sc)=>{Sc.exports=window.__raptiMods["src/site.js"]});var $i=Ie((aT,Ec)=>{Ec.exports=window.__raptiMods["src/pi/boards.js"]});var rn=Ie((hT,Ac)=>{Ac.exports=window.__raptiMods["src/pi/examples.js"]});var Dc=Ie((cT,Mc)=>{Mc.exports=window.__raptiMods["src/net/network.js"]});var O0=Ie((WE,b0)=>{b0.exports=window.__raptiMods["src/ui/browser.js"]});var S0=Ie((VE,x0)=>{x0.exports=window.__raptiMods["src/pi/circuit-parts.js"]});var P0=Ie((UE,T0)=>{T0.exports=window.__raptiMods["src/ui/editor.js"]});var E0=Ie((GE,C0)=>{C0.exports=window.__raptiMods["src/ui/canvas.js"]});var R0=Ie((XE,A0)=>{A0.exports=window.__raptiMods["src/ui/library.js"]});var D0=Ie((JE,M0)=>{M0.exports=window.__raptiMods["src/components/registry.js"]});var I0=Ie((YE,N0)=>{N0.exports=window.__raptiMods["src/sim/engine.js"]});var F0=Ie((eA,$0)=>{$0.exports=window.__raptiMods["src/pi/autowire.js"]});var z0=Ie((tA,W0)=>{W0.exports=window.__raptiMods["src/ui/fsdock.js"]});var L=se(ii(),1),Fe=se(Qi(),1),Ri=se(ml(),1),H0=se(Oc(),1);var Lc=se(en(),1);var gl={};async function kb(r={}){var dc,uc,pc;var e=r,t=!!globalThis.window,i=!!globalThis.WorkerGlobalScope,s=((uc=(dc=globalThis.process)==null?void 0:dc.versions)==null?void 0:uc.node)&&((pc=globalThis.process)==null?void 0:pc.type)!="renderer";if(s){let{createRequire:f}=await import("node:module");var n=f(gl.url)}var o=[],l="./this.program",a=(f,d)=>{throw d},h=gl.url,c="";function u(f){return e.locateFile?e.locateFile(f,c):c+f}var p,y;if(s){var O=n("node:fs");h.startsWith("file:")&&(c=n("node:path").dirname(n("node:url").fileURLToPath(h))+"/"),y=f=>{f=Q(f)?new URL(f):f;var d=O.readFileSync(f);return d},p=async(f,d=!0)=>{f=Q(f)?new URL(f):f;var m=O.readFileSync(f,d?void 0:"utf8");return m},process.argv.length>1&&(l=process.argv[1].replace(/\\/g,"/")),o=process.argv.slice(2),a=(f,d)=>{throw process.exitCode=f,d}}else if(t||i){try{c=new URL(".",h).href}catch{}i&&(y=f=>{var d=new XMLHttpRequest;return d.open("GET",f,!1),d.responseType="arraybuffer",d.send(null),new Uint8Array(d.response)}),p=async f=>{var d=await fetch(f,{credentials:"same-origin"});if(d.ok)return d.arrayBuffer();throw new Error(d.status+" : "+d.url)}}var b=console.log.bind(console),v=console.error.bind(console),k,T=!1,C,Q=f=>f.startsWith("file://");class A{}class R extends A{}var D=!1;function F(){return Zr.buffer}function J(){var d;if(!((d=Oe==null?void 0:Oe.buffer)!=null&&d.resizable)){var f=F();Oe=new Int8Array(f),_i=new Int16Array(f),e.HEAPU8=ps=new Uint8Array(f),Mt=new Int32Array(f),me=new Uint32Array(f),fl=new Float32Array(f),cl=new Float64Array(f),Ve=new BigInt64Array(f)}}function he(){var f=e.preRun;f&&(typeof f=="function"&&(f=[f]),Di.push(...f)),Vt(Di)}function Z(){D=!0,!e.noFSInit&&!_.initialized&&_.init(),gi.init(),Li.__wasm_call_ctors(),_.ignorePermissions=!1}function U(){var f=e.postRun;f&&(typeof f=="function"&&(f=[f]),ei.push(...f)),Vt(ei)}function ee(f){var m;(m=e.onAbort)==null||m.call(e,f),f=`Aborted(${f})`,v(f),T=!0,f+=". Build with -sASSERTIONS for more info.";var d=new WebAssembly.RuntimeError(f);throw d}var le;function ye(){return e.locateFile?u("micropython.wasm"):new URL("micropython.wasm",gl.url).href}function We(f){if(y)return y(f);throw"both async and sync fetching of the wasm failed"}async function Ye(f){if(!k)try{var d=await p(f);return new Uint8Array(d)}catch{}return We(f)}async function gt(f,d){try{var m=await Ye(f),g=await WebAssembly.instantiate(m,d);return g}catch(w){v(`failed to asynchronously prepare wasm: ${w}`),ee(w)}}async function De(f,d,m){if(!f&&!s)try{var g=fetch(d,{credentials:"same-origin"}),w=await WebAssembly.instantiateStreaming(g,m);return w}catch(x){v(`wasm streaming compile failed: ${x}`),v("falling back to ArrayBuffer instantiation")}return gt(d,m)}function nt(){var f={env:cc,wasi_snapshot_preview1:cc};return f}async function Rt(){function f(S){return Li=S.exports,Li=j.instrumentWasmExports(Li),sb(Li),J(),Li}function d(S){return f(S.instance)}var m=nt(),g=e.instantiateWasm;if(g)return new Promise(S=>{g(m,P=>S(f(P)))});le??(le=ye());var w=await De(k,le,m),x=d(w);return x}class Ke{name="ExitStatus";constructor(d){this.message=`Program terminated with exit(${d})`,this.status=d}}var Oe,Vt=f=>{for(;f.length>0;)f.shift()(e)},ei=[],Di=[],Ne={},j2=(f,d,m)=>{f=f.replace(/p/g,"i");var g=Ne[f];return g(d,...m)},Pf=!0,_t=f=>Xf(f),yt=()=>Gf(),de={isAbs:f=>f.charAt(0)==="/",splitPath:f=>{var d=/^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;return d.exec(f).slice(1)},normalizeArray:(f,d)=>{for(var m=0,g=f.length-1;g>=0;g--){var w=f[g];w==="."?f.splice(g,1):w===".."?(f.splice(g,1),m++):m&&(f.splice(g,1),m--)}if(d)for(;m;m--)f.unshift("..");return f},normalize:f=>{var d=de.isAbs(f),m=f.slice(-1)==="/";return f=de.normalizeArray(f.split("/").filter(g=>!!g),!d).join("/"),!f&&!d&&(f="."),f&&m&&(f+="/"),(d?"/":"")+f},dirname:f=>{var d=de.splitPath(f),m=d[0],g=d[1];return!m&&!g?".":(g&&(g=g.slice(0,-1)),m+g)},basename:f=>f&&f.match(/([^\/]+|\/)\/*$/)[1],join:(...f)=>de.normalize(f.join("/")),join2:(f,d)=>de.normalize(f+"/"+d)},G0=()=>{if(s){var f=n("node:crypto");return d=>(f.randomFillSync(d),0)}return d=>(crypto.getRandomValues(d),0)},Cf=f=>(Cf=G0())(f),Ni={resolve:(...f)=>{for(var d="",m=!1,g=f.length-1;g>=-1&&!m;g--){var w=g>=0?f[g]:_.cwd();if(typeof w!="string")throw new TypeError("Arguments to path.resolve must be strings");if(!w)return"";d=w+"/"+d,m=de.isAbs(w)}return d=de.normalizeArray(d.split("/").filter(x=>!!x),!m).join("/"),(m?"/":"")+d||"."},relative:(f,d)=>{f=Ni.resolve(f).slice(1),d=Ni.resolve(d).slice(1);function m(q){for(var Y=0;Y<q.length&&q[Y]==="";Y++);for(var te=q.length-1;te>=0&&q[te]==="";te--);return Y>te?[]:q.slice(Y,te-Y+1)}for(var g=m(f.split("/")),w=m(d.split("/")),x=Math.min(g.length,w.length),S=x,P=0;P<x;P++)if(g[P]!==w[P]){S=P;break}for(var N=[],P=S;P<g.length;P++)N.push("..");return N=N.concat(w.slice(S)),N.join("/")}},Ef=globalThis.TextDecoder&&new TextDecoder,X0=(f,d,m,g)=>{var w=d+m;if(g)return w;for(;f[d]&&!(d>=w);)++d;return d},us=(f,d=0,m,g)=>{var w=X0(f,d,m,g);if(w-d>16&&f.buffer&&Ef)return Ef.decode(f.subarray(d,w));for(var x="";d<w;){var S=f[d++];if(!(S&128)){x+=String.fromCharCode(S);continue}var P=f[d++]&63;if((S&224)==192){x+=String.fromCharCode((S&31)<<6|P);continue}var N=f[d++]&63;if((S&240)==224?S=(S&15)<<12|P<<6|N:S=(S&7)<<18|P<<12|N<<6|f[d++]&63,S<65536)x+=String.fromCharCode(S);else{var q=S-65536;x+=String.fromCharCode(55296|q>>10,56320|q&1023)}}return x},nl=[],Zs=f=>{for(var d=0,m=0;m<f.length;++m){var g=f.charCodeAt(m);g<=127?d++:g<=2047?d+=2:g>=55296&&g<=57343?(d+=4,++m):d+=3}return d},Af=(f,d,m,g)=>{if(!(g>0))return 0;for(var w=m,x=m+g-1,S=0;S<f.length;++S){var P=f.codePointAt(S);if(P<=127){if(m>=x)break;d[m++]=P}else if(P<=2047){if(m+1>=x)break;d[m++]=192|P>>6,d[m++]=128|P&63}else if(P<=65535){if(m+2>=x)break;d[m++]=224|P>>12,d[m++]=128|P>>6&63,d[m++]=128|P&63}else{if(m+3>=x)break;d[m++]=240|P>>18,d[m++]=128|P>>12&63,d[m++]=128|P>>6&63,d[m++]=128|P&63,S++}}return d[m]=0,m-w},ol=(f,d,m)=>{var g=m>0?m:Zs(f)+1,w=new Array(g),x=Af(f,w,0,w.length);return d&&(w.length=x),w},J0=()=>{var w;if(!nl.length){var f=null;if(s){var d=256,m=Buffer.alloc(d),g=0;try{g=O.readSync(process.stdin.fd,m,0,d)}catch(x){if(x.toString().includes("EOF"))g=0;else throw x}g>0&&(f=m.toString("utf-8",0,g))}else(w=globalThis.window)!=null&&w.prompt&&(f=window.prompt("Input: "),f!==null&&(f+=`
`));if(!f)return null;nl=ol(f,!0)}return nl.shift()},gi={ttys:[],init(){},shutdown(){},register(f,d){gi.ttys[f]={input:[],output:[],ops:d},_.registerDevice(f,gi.stream_ops)},stream_ops:{open(f){var d=gi.ttys[f.node.rdev];if(!d)throw new _.ErrnoError(43);f.tty=d,f.seekable=!1},close(f){f.tty.ops.fsync(f.tty)},fsync(f){f.tty.ops.fsync(f.tty)},read(f,d,m,g,w){if(!f.tty||!f.tty.ops.get_char)throw new _.ErrnoError(60);for(var x=0,S=0;S<g;S++){var P;try{P=f.tty.ops.get_char(f.tty)}catch{throw new _.ErrnoError(29)}if(P===void 0&&!x)throw new _.ErrnoError(6);if(P==null||(x++,d[m+S]=P,P===10))break}return x&&(f.node.atime=Date.now()),x},write(f,d,m,g,w){if(!f.tty||!f.tty.ops.put_char)throw new _.ErrnoError(60);try{for(var x=0;x<g;x++)f.tty.ops.put_char(f.tty,d[m+x])}catch{throw new _.ErrnoError(29)}return g&&(f.node.mtime=f.node.ctime=Date.now()),x}},default_tty_ops:{get_char(f){return J0()},put_char(f,d){d===null||d===10?(b(us(f.output)),f.output=[]):d!=0&&f.output.push(d)},fsync(f){var d;((d=f.output)==null?void 0:d.length)>0&&(b(us(f.output)),f.output=[])},ioctl_tcgets(f){return{c_iflag:25856,c_oflag:5,c_cflag:191,c_lflag:35387,c_cc:[3,28,127,21,4,0,1,0,17,19,26,0,18,15,23,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}},ioctl_tcsets(f,d,m){return 0},ioctl_tiocgwinsz(f){return[24,80]}},default_tty1_ops:{put_char(f,d){d===null||d===10?(v(us(f.output)),f.output=[]):d!=0&&f.output.push(d)},fsync(f){var d;((d=f.output)==null?void 0:d.length)>0&&(v(us(f.output)),f.output=[])}}},Rf=f=>{ee()},G={ops_table:null,mount(f){return G.createNode(null,"/",16895,0)},createNode(f,d,m,g){if(_.isBlkdev(m)||_.isFIFO(m))throw new _.ErrnoError(63);G.ops_table||(G.ops_table={dir:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr,lookup:G.node_ops.lookup,mknod:G.node_ops.mknod,rename:G.node_ops.rename,unlink:G.node_ops.unlink,rmdir:G.node_ops.rmdir,readdir:G.node_ops.readdir,symlink:G.node_ops.symlink},stream:{llseek:G.stream_ops.llseek}},file:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr},stream:{llseek:G.stream_ops.llseek,read:G.stream_ops.read,write:G.stream_ops.write,mmap:G.stream_ops.mmap,msync:G.stream_ops.msync}},link:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr,readlink:G.node_ops.readlink},stream:{}},chrdev:{node:{getattr:G.node_ops.getattr,setattr:G.node_ops.setattr},stream:_.chrdev_stream_ops}});var w=_.createNode(f,d,m,g);return _.isDir(w.mode)?(w.node_ops=G.ops_table.dir.node,w.stream_ops=G.ops_table.dir.stream,w.contents={}):_.isFile(w.mode)?(w.node_ops=G.ops_table.file.node,w.stream_ops=G.ops_table.file.stream,w.usedBytes=0,w.contents=G.emptyFileContents??(G.emptyFileContents=new Uint8Array(0))):_.isLink(w.mode)?(w.node_ops=G.ops_table.link.node,w.stream_ops=G.ops_table.link.stream):_.isChrdev(w.mode)&&(w.node_ops=G.ops_table.chrdev.node,w.stream_ops=G.ops_table.chrdev.stream),w.atime=w.mtime=w.ctime=Date.now(),f&&(f.contents[d]=w,f.atime=f.mtime=f.ctime=w.atime),w},getFileDataAsTypedArray(f){return f.contents.subarray(0,f.usedBytes)},expandFileStorage(f,d){var m=f.contents.length;if(!(m>=d)){var g=1024*1024;d=Math.max(d,m*(m<g?2:1.125)>>>0),m&&(d=Math.max(d,256));var w=G.getFileDataAsTypedArray(f);f.contents=new Uint8Array(d),f.contents.set(w)}},resizeFileStorage(f,d){if(f.usedBytes!=d){var m=f.contents;f.contents=new Uint8Array(d),f.contents.set(m.subarray(0,Math.min(d,f.usedBytes))),f.usedBytes=d}},node_ops:{getattr(f){var d={};return d.dev=_.isChrdev(f.mode)?f.id:1,d.ino=f.id,d.mode=f.mode,d.nlink=1,d.uid=0,d.gid=0,d.rdev=f.rdev,_.isDir(f.mode)?d.size=4096:_.isFile(f.mode)?d.size=f.usedBytes:_.isLink(f.mode)?d.size=f.link.length:d.size=0,d.atime=new Date(f.atime),d.mtime=new Date(f.mtime),d.ctime=new Date(f.ctime),d.atimeMs=f.atime,d.mtimeMs=f.mtime,d.ctimeMs=f.ctime,d.blksize=4096,d.blocks=Math.ceil(d.size/d.blksize),d},setattr(f,d){for(let m of["mode","atime","mtime","ctime"])d[m]!=null&&(f[m]=d[m]);d.size!==void 0&&G.resizeFileStorage(f,d.size)},lookup(f,d){throw G.doesNotExistError||(G.doesNotExistError=new _.ErrnoError(44),G.doesNotExistError.stack="<generic error, no stack>"),G.doesNotExistError},mknod(f,d,m,g){return G.createNode(f,d,m,g)},rename(f,d,m){var g;try{g=_.lookupNode(d,m)}catch{}if(g&&_.isDir(f.mode))for(var w in g.contents)throw new _.ErrnoError(55);delete f.parent.contents[f.name],d.contents[m]=f,f.name=m,d.ctime=d.mtime=f.parent.ctime=f.parent.mtime=Date.now()},unlink(f,d){delete f.contents[d],f.ctime=f.mtime=Date.now()},rmdir(f,d){var m=_.lookupNode(f,d);for(var g in m.contents)throw new _.ErrnoError(55);delete f.contents[d],f.ctime=f.mtime=Date.now()},readdir(f){return[".","..",...Object.keys(f.contents)]},symlink(f,d,m){var g=G.createNode(f,d,41471,0);return g.link=m,g},readlink(f){if(!_.isLink(f.mode))throw new _.ErrnoError(28);return f.link}},stream_ops:{read(f,d,m,g,w){var x=f.node.contents;if(w>=f.node.usedBytes)return 0;var S=Math.min(f.node.usedBytes-w,g);return d.set(x.subarray(w,w+S),m),S},write(f,d,m,g,w,x){if(d.buffer===Oe.buffer&&(x=!1),!g)return 0;var S=f.node;return S.mtime=S.ctime=Date.now(),x?(S.contents=d.subarray(m,m+g),S.usedBytes=g):!S.usedBytes&&!w?(S.contents=d.slice(m,m+g),S.usedBytes=g):(G.expandFileStorage(S,w+g),S.contents.set(d.subarray(m,m+g),w),S.usedBytes=Math.max(S.usedBytes,w+g)),g},llseek(f,d,m){var g=d;if(m===1?g+=f.position:m===2&&_.isFile(f.node.mode)&&(g+=f.node.usedBytes),g<0)throw new _.ErrnoError(28);return g},mmap(f,d,m,g,w){if(!_.isFile(f.node.mode))throw new _.ErrnoError(43);var x,S,P=f.node.contents;if(!(w&2)&&P.buffer===Oe.buffer)S=!1,x=P.byteOffset;else{if(S=!0,x=Rf(d),!x)throw new _.ErrnoError(48);P&&((m>0||m+d<P.length)&&(P.subarray?P=P.subarray(m,m+d):P=Array.prototype.slice.call(P,m,m+d)),Oe.set(P,x))}return{ptr:x,allocated:S}},msync(f,d,m,g,w){return G.stream_ops.write(f,d,0,g,m,!1),0}}},Y0=f=>{if(typeof f!="string")return f;var d={r:0,"r+":2,w:577,"w+":578,a:1089,"a+":1090},m=d[f];if(typeof m>"u")throw new Error(`Unknown file open mode: ${f}`);return m},Mf=f=>(typeof f=="string"&&(f=ol(f,!0)),f.subarray||(f=new Uint8Array(f)),f),ll=(f,d)=>{var m=0;return f&&(m|=365),d&&(m|=146),m},K0=async f=>{var d=await p(f);return new Uint8Array(d)},Z0=(...f)=>_.createDataFile(...f),e_=f=>f,Df=null,t_=async()=>Df,Ii=0,Nf=null,i_=f=>{var d;Ii--,(d=e.monitorRunDependencies)==null||d.call(e,Ii),Ii||Nf()},s_=f=>{var d;Ii||(Df=new Promise(m=>Nf=m)),Ii++,(d=e.monitorRunDependencies)==null||d.call(e,Ii)},r_=[],n_=async(f,d)=>{typeof Browser<"u"&&Browser.init();for(var m of r_)if(m.canHandle(d))return m.handle(f,d);return f},If=async(f,d,m,g,w,x,S,P)=>{var N=d?Ni.resolve(de.join2(f,d)):f,q=e_(`cp ${N}`);s_(q);try{var Y=m;typeof m=="string"&&(Y=await K0(m)),Y=await n_(Y,N),P==null||P(),x||Z0(f,d,Y,g,w,S)}finally{i_(q)}},o_=(f,d,m,g,w,x,S,P,N,q)=>{If(f,d,m,g,w,P,N,q).then(x).catch(S)},_={root:null,mounts:[],devices:{},streams:[],nextInode:1,nameTable:[],currentPath:"/",initialized:!1,ignorePermissions:!0,filesystems:null,syncFSRequests:0,ErrnoError:class{name="ErrnoError";constructor(f){this.errno=f}},FSStream:class{shared={};get object(){return this.node}set object(f){this.node=f}get isRead(){return(this.flags&2097155)!==1}get isWrite(){return(this.flags&2097155)!==0}get isAppend(){return this.flags&1024}get flags(){return this.shared.flags}set flags(f){this.shared.flags=f}get position(){return this.shared.position}set position(f){this.shared.position=f}},FSNode:class{node_ops={};stream_ops={};readMode=365;writeMode=146;mounted=null;constructor(f,d,m,g){f||(f=this),this.parent=f,this.mount=f.mount,this.id=_.nextInode++,this.name=d,this.mode=m,this.rdev=g,this.atime=this.mtime=this.ctime=Date.now()}get read(){return(this.mode&this.readMode)===this.readMode}set read(f){f?this.mode|=this.readMode:this.mode&=~this.readMode}get write(){return(this.mode&this.writeMode)===this.writeMode}set write(f){f?this.mode|=this.writeMode:this.mode&=~this.writeMode}get isFolder(){return _.isDir(this.mode)}get isDevice(){return _.isChrdev(this.mode)}addListener(f,d=!1){var m={cb:f,exclusive:d},g=this.listeners??(this.listeners=new Set);return g.add(m),{listeners:g,entry:m}}notifyListeners(f){if(this.listeners){var d;for(var m of this.listeners)m.exclusive?(d||(d=[])).push(m):m.cb(f);if(d){var g=(this.exclTurn||0)%d.length;this.exclTurn=g+1,d[g].cb(f)}}}},lookupPath(f,d={}){if(!f)throw new _.ErrnoError(44);d.follow_mount??(d.follow_mount=!0),de.isAbs(f)||(f=_.cwd()+"/"+f);e:for(var m=0;m<40;m++){for(var g=f.split("/").filter(q=>!!q),w=_.root,x="/",S=0;S<g.length;S++){var P=S===g.length-1;if(P&&d.parent)break;if(g[S]!=="."){if(g[S]===".."){if(x=de.dirname(x),_.isRoot(w)){f=x+"/"+g.slice(S+1).join("/"),m--;continue e}else w=w.parent;continue}x=de.join2(x,g[S]);try{w=_.lookupNode(w,g[S])}catch(q){if((q==null?void 0:q.errno)===44&&P&&d.noent_okay)return{path:x};throw q}if(_.isMountpoint(w)&&(!P||d.follow_mount)&&(w=w.mounted.root),_.isLink(w.mode)&&(!P||d.follow)){if(!w.node_ops.readlink)throw new _.ErrnoError(52);var N=w.node_ops.readlink(w);de.isAbs(N)||(N=de.dirname(x)+"/"+N),f=N+"/"+g.slice(S+1).join("/");continue e}}}return{path:x,node:w}}throw new _.ErrnoError(32)},getPath(f){for(var d;;){if(_.isRoot(f)){var m=f.mount.mountpoint;return d?m[m.length-1]!=="/"?`${m}/${d}`:m+d:m}d=d?`${f.name}/${d}`:f.name,f=f.parent}},hashName(f,d){for(var m=0,g=0;g<d.length;g++)m=(m<<5)-m+d.charCodeAt(g)|0;return(f+m>>>0)%_.nameTable.length},hashAddNode(f){var d=_.hashName(f.parent.id,f.name);f.name_next=_.nameTable[d],_.nameTable[d]=f},hashRemoveNode(f){var d=_.hashName(f.parent.id,f.name);if(_.nameTable[d]===f)_.nameTable[d]=f.name_next;else for(var m=_.nameTable[d];m;){if(m.name_next===f){m.name_next=f.name_next;break}m=m.name_next}},lookupNode(f,d){var m=_.mayLookup(f);if(m)throw new _.ErrnoError(m);for(var g=_.hashName(f.id,d),w=_.nameTable[g];w;w=w.name_next){var x=w.name;if(w.parent.id===f.id&&x===d)return w}return _.lookup(f,d)},createNode(f,d,m,g){var w=new _.FSNode(f,d,m,g);return _.hashAddNode(w),w},destroyNode(f){_.hashRemoveNode(f)},isRoot(f){return f===f.parent},isMountpoint(f){return!!f.mounted},isFile(f){return(f&61440)===32768},isDir(f){return(f&61440)===16384},isLink(f){return(f&61440)===40960},isChrdev(f){return(f&61440)===8192},isBlkdev(f){return(f&61440)===24576},isFIFO(f){return(f&61440)===4096},isSocket(f){return(f&49152)===49152},flagsToPermissionString(f){var d=["r","w","rw"][f&3];return f&512&&(d+="w"),d},nodePermissions(f,d){return _.ignorePermissions?0:d.includes("r")&&!(f.mode&292)||d.includes("w")&&!(f.mode&146)||d.includes("x")&&!(f.mode&73)?2:0},mayLookup(f){if(!_.isDir(f.mode))return 54;var d=_.nodePermissions(f,"x");return d||(f.node_ops.lookup?0:2)},mayCreate(f,d){if(!_.isDir(f.mode))return 54;try{var m=_.lookupNode(f,d);return 20}catch{}return _.nodePermissions(f,"wx")},mayDelete(f,d,m){var g;try{g=_.lookupNode(f,d)}catch(x){return x.errno}var w=_.nodePermissions(f,"wx");if(w)return w;if(m){if(!_.isDir(g.mode))return 54;if(_.isRoot(g)||_.getPath(g)===_.cwd())return 10}else if(_.isDir(g.mode))return 31;return 0},mayOpen(f,d){if(!f)return 44;if(_.isLink(f.mode))return 32;var m=_.flagsToPermissionString(d);return _.isDir(f.mode)&&(m!=="r"||d&576)?31:_.nodePermissions(f,m)},checkOpExists(f,d){if(!f)throw new _.ErrnoError(d);return f},MAX_OPEN_FDS:4096,nextfd(){for(var f=0;f<=_.MAX_OPEN_FDS;f++)if(!_.streams[f])return f;throw new _.ErrnoError(33)},getStreamChecked(f){var d=_.getStream(f);if(!d)throw new _.ErrnoError(8);return d},getStream:f=>_.streams[f],createStream(f,d=-1){return f=Object.assign(new _.FSStream,f),d==-1&&(d=_.nextfd()),f.fd=d,_.streams[d]=f,f},closeStream(f){_.streams[f]=null},dupStream(f,d=-1){var g,w;var m=_.createStream(f,d);return(w=(g=m.stream_ops)==null?void 0:g.dup)==null||w.call(g,m),m},doSetAttr(f,d,m){var g=f==null?void 0:f.stream_ops.setattr,w=g?f:d;g??(g=d.node_ops.setattr),_.checkOpExists(g,63);try{g(w,m)}catch(x){throw x instanceof RangeError?new _.ErrnoError(22):x}},chrdev_stream_ops:{open(f){var m,g;var d=_.getDevice(f.node.rdev);f.stream_ops=d.stream_ops,(g=(m=f.stream_ops).open)==null||g.call(m,f)},llseek(){throw new _.ErrnoError(70)}},major:f=>f>>8,minor:f=>f&255,makedev:(f,d)=>f<<8|d,registerDevice(f,d){_.devices[f]={stream_ops:d}},getDevice:f=>_.devices[f],getMounts(f){for(var d=[],m=[f];m.length;){var g=m.pop();d.push(g),m.push(...g.mounts)}return d},syncfs(f,d){typeof f=="function"&&(d=f,f=!1),_.syncFSRequests++,_.syncFSRequests>1&&v(`warning: ${_.syncFSRequests} FS.syncfs operations in flight at once, probably just doing extra work`);var m=_.getMounts(_.root.mount),g=0;function w(P){return _.syncFSRequests--,d(P)}function x(P){if(P)return x.errored?void 0:(x.errored=!0,w(P));++g>=m.length&&w(null)}for(var S of m)S.type.syncfs?S.type.syncfs(S,f,x):x(null)},mount(f,d,m){var g=m==="/",w=!m,x;if(g&&_.root)throw new _.ErrnoError(10);if(!g&&!w){var S=_.lookupPath(m,{follow_mount:!1});if(m=S.path,x=S.node,_.isMountpoint(x))throw new _.ErrnoError(10);if(!_.isDir(x.mode))throw new _.ErrnoError(54)}var P={type:f,opts:d,mountpoint:m,mounts:[]},N=f.mount(P);return N.mount=P,P.root=N,g?_.root=N:x&&(x.mounted=P,x.mount&&x.mount.mounts.push(P)),N},unmount(f){var d=_.lookupPath(f,{follow_mount:!1});if(!_.isMountpoint(d.node))throw new _.ErrnoError(28);var m=d.node,g=m.mounted,w=_.getMounts(g);for(var[x,S]of Object.entries(_.nameTable))for(;S;){var P=S.name_next;w.includes(S.mount)&&_.destroyNode(S),S=P}m.mounted=null;var N=m.mount.mounts.indexOf(g);m.mount.mounts.splice(N,1)},lookup(f,d){return f.node_ops.lookup(f,d)},mknod(f,d,m){var g=_.lookupPath(f,{parent:!0}),w=g.node,x=de.basename(f);if(!x)throw new _.ErrnoError(28);if(x==="."||x==="..")throw new _.ErrnoError(20);var S=_.mayCreate(w,x);if(S)throw new _.ErrnoError(S);if(!w.node_ops.mknod)throw new _.ErrnoError(63);return w.node_ops.mknod(w,x,d,m)},statfs(f){return _.statfsNode(_.lookupPath(f,{follow:!0}).node)},statfsStream(f){return _.statfsNode(f.node)},statfsNode(f){var d={bsize:4096,frsize:4096,blocks:1e6,bfree:5e5,bavail:5e5,files:_.nextInode,ffree:_.nextInode-1,fsid:42,flags:2,namelen:255};return f.node_ops.statfs&&Object.assign(d,f.node_ops.statfs(f.mount.opts.root)),d},create(f,d=438){return d&=4095,d|=32768,_.mknod(f,d,0)},mkdir(f,d=511){return d&=1023,d|=16384,_.mknod(f,d,0)},mkdirTree(f,d=511){var m=f.split("/"),g="";for(var w of m)if(w){(g||de.isAbs(f))&&(g+="/"),g+=w;try{_.mkdir(g,d)}catch(x){if(x.errno!=20)throw x}}},mkdev(f,d,m){return typeof m>"u"&&(m=d,d=438),d|=8192,_.mknod(f,d,m)},symlink(f,d){if(!Ni.resolve(f))throw new _.ErrnoError(44);var m=_.lookupPath(d,{parent:!0}),g=m.node;if(!g)throw new _.ErrnoError(44);var w=de.basename(d),x=_.mayCreate(g,w);if(x)throw new _.ErrnoError(x);if(!g.node_ops.symlink)throw new _.ErrnoError(63);return g.node_ops.symlink(g,w,f)},link(f,d,m){var g=_.lookupPath(d,{parent:!0}),w=g.node;if(!w)throw new _.ErrnoError(44);var x=de.basename(d),S=_.mayCreate(w,x);if(S)throw new _.ErrnoError(S);if(!w.node_ops.link)throw new _.ErrnoError(34);return w.node_ops.link(w,x,f,m)},rename(f,d){var m=de.dirname(f),g=de.dirname(d),w=de.basename(f),x=de.basename(d),S,P,N;if(S=_.lookupPath(f,{parent:!0}),P=S.node,S=_.lookupPath(d,{parent:!0}),N=S.node,!P||!N)throw new _.ErrnoError(44);if(P.mount!==N.mount)throw new _.ErrnoError(75);var q=_.lookupNode(P,w),Y=Ni.relative(f,g);if(Y.charAt(0)!==".")throw new _.ErrnoError(28);if(Y=Ni.relative(d,m),Y.charAt(0)!==".")throw new _.ErrnoError(55);var te;try{te=_.lookupNode(N,x)}catch{}if(q!==te){var X=_.isDir(q.mode),V=_.mayDelete(P,w,X);if(V)throw new _.ErrnoError(V);if(V=te?_.mayDelete(N,x,X):_.mayCreate(N,x),V)throw new _.ErrnoError(V);if(!P.node_ops.rename)throw new _.ErrnoError(63);if(_.isMountpoint(q)||te&&_.isMountpoint(te))throw new _.ErrnoError(10);if(N!==P&&(V=_.nodePermissions(P,"w"),V))throw new _.ErrnoError(V);_.hashRemoveNode(q);try{P.node_ops.rename(q,N,x),te&&_.hashRemoveNode(te),q.parent=N}catch(ne){throw ne}finally{_.hashAddNode(q)}}},rmdir(f){var d=_.lookupPath(f,{parent:!0}),m=d.node,g=de.basename(f),w=_.lookupNode(m,g),x=_.mayDelete(m,g,!0);if(x)throw new _.ErrnoError(x);if(!m.node_ops.rmdir)throw new _.ErrnoError(63);if(_.isMountpoint(w))throw new _.ErrnoError(10);m.node_ops.rmdir(m,g),_.destroyNode(w)},readdir(f){var d=_.lookupPath(f,{follow:!0}),m=d.node,g=_.checkOpExists(m.node_ops.readdir,54);return g(m)},unlink(f){var d=_.lookupPath(f,{parent:!0}),m=d.node;if(!m)throw new _.ErrnoError(44);var g=de.basename(f),w=_.lookupNode(m,g),x=_.mayDelete(m,g,!1);if(x)throw new _.ErrnoError(x);if(!m.node_ops.unlink)throw new _.ErrnoError(63);if(_.isMountpoint(w))throw new _.ErrnoError(10);m.node_ops.unlink(m,g),_.destroyNode(w)},readlink(f){var d=_.lookupPath(f),m=d.node;if(!m)throw new _.ErrnoError(44);if(!m.node_ops.readlink)throw new _.ErrnoError(28);return m.node_ops.readlink(m)},stat(f,d=!1){var m=_.lookupPath(f,{follow:!d}),g=m.node,w=_.checkOpExists(g.node_ops.getattr,63);return w(g)},fstat(f){var d=_.getStreamChecked(f),m=d.node,g=d.stream_ops.getattr,w=g?d:m;return g??(g=m.node_ops.getattr),_.checkOpExists(g,63),g(w)},lstat(f){return _.stat(f,!0)},doChmod(f,d,m,g=!1){_.doSetAttr(f,d,{mode:m&4095|d.mode&-4096,ctime:Date.now(),dontFollow:g})},chmod(f,d,m=!1){var g;if(typeof f=="string"){var w=_.lookupPath(f,{follow:!m});g=w.node}else g=f;_.doChmod(null,g,d,m)},lchmod(f,d){_.chmod(f,d,!0)},fchmod(f,d){var m=_.getStreamChecked(f);_.doChmod(m,m.node,d,!1)},doChown(f,d,m=!1){_.doSetAttr(f,d,{timestamp:Date.now(),dontFollow:m})},chown(f,d,m,g=!1){var w;if(typeof f=="string"){var x=_.lookupPath(f,{follow:!g});w=x.node}else w=f;_.doChown(null,w,g)},lchown(f,d,m){_.chown(f,d,m,!0)},fchown(f,d,m){var g=_.getStreamChecked(f);_.doChown(g,g.node,!1)},doTruncate(f,d,m){if(_.isDir(d.mode))throw new _.ErrnoError(31);if(!_.isFile(d.mode))throw new _.ErrnoError(28);var g=_.nodePermissions(d,"w");if(g)throw new _.ErrnoError(g);_.doSetAttr(f,d,{size:m,timestamp:Date.now()})},truncate(f,d){if(d<0)throw new _.ErrnoError(28);var m;if(typeof f=="string"){var g=_.lookupPath(f,{follow:!0});m=g.node}else m=f;_.doTruncate(null,m,d)},ftruncate(f,d){var m=_.getStreamChecked(f);if(d<0||!(m.flags&2097155))throw new _.ErrnoError(28);_.doTruncate(m,m.node,d)},utime(f,d,m,g=!1){var w=_.lookupPath(f,{follow:!g});_.doSetAttr(null,w.node,{atime:d,mtime:m,dontFollow:g})},open(f,d,m=438){if(f==="")throw new _.ErrnoError(44);d=Y0(d),d&64?m=m&4095|32768:m=0;var g,w;if(typeof f=="object")g=f;else{w=f.endsWith("/");var x=_.lookupPath(f,{follow:!(d&131072),noent_okay:!0});g=x.node,f=x.path}var S=!1;if(d&64)if(g){if(d&128)throw new _.ErrnoError(20)}else{if(w)throw new _.ErrnoError(31);g=_.mknod(f,m|511,0),S=!0}if(!g)throw new _.ErrnoError(44);if(_.isChrdev(g.mode)&&(d&=-513),d&65536&&!_.isDir(g.mode))throw new _.ErrnoError(54);if(!S){var P=_.mayOpen(g,d);if(P)throw new _.ErrnoError(P)}d&512&&!S&&_.truncate(g,0),d&=-131713;var N=_.createStream({node:g,path:_.getPath(g),flags:d,seekable:!0,position:0,stream_ops:g.stream_ops,ungotten:[],error:!1});return N.stream_ops.open&&N.stream_ops.open(N),S&&_.chmod(g,m&511),N},close(f){var d;if(_.isClosed(f))throw new _.ErrnoError(8);f.getdents&&(f.getdents=null),(d=f.node)==null||d.notifyListeners(32);try{f.stream_ops.close&&f.stream_ops.close(f)}catch(m){throw m}finally{_.closeStream(f.fd)}f.fd=null},isClosed(f){return f.fd===null},llseek(f,d,m){if(_.isClosed(f))throw new _.ErrnoError(8);if(!f.seekable||!f.stream_ops.llseek)throw new _.ErrnoError(70);if(m!=0&&m!=1&&m!=2)throw new _.ErrnoError(28);return f.position=f.stream_ops.llseek(f,d,m),f.ungotten=[],f.position},read(f,d,m,g,w){if(g<0||w<0)throw new _.ErrnoError(28);if(_.isClosed(f))throw new _.ErrnoError(8);if((f.flags&2097155)===1)throw new _.ErrnoError(8);if(_.isDir(f.node.mode))throw new _.ErrnoError(31);if(!f.stream_ops.read)throw new _.ErrnoError(28);var x=typeof w<"u";if(!x)w=f.position;else if(!f.seekable)throw new _.ErrnoError(70);var S=f.stream_ops.read(f,d,m,g,w);return x||(f.position+=S),S},write(f,d,m,g,w,x){if(g<0||w<0)throw new _.ErrnoError(28);if(_.isClosed(f))throw new _.ErrnoError(8);if(!(f.flags&2097155))throw new _.ErrnoError(8);if(_.isDir(f.node.mode))throw new _.ErrnoError(31);if(!f.stream_ops.write)throw new _.ErrnoError(28);f.seekable&&f.flags&1024&&_.llseek(f,0,2);var S=typeof w<"u";if(!S)w=f.position;else if(!f.seekable)throw new _.ErrnoError(70);var P=f.stream_ops.write(f,d,m,g,w,x);return S||(f.position+=P),P},mmap(f,d,m,g,w){if(g&2&&!(w&2)&&(f.flags&2097155)!==2)throw new _.ErrnoError(2);if((f.flags&2097155)===1)throw new _.ErrnoError(2);if(!f.stream_ops.mmap)throw new _.ErrnoError(43);if(!d)throw new _.ErrnoError(28);return f.stream_ops.mmap(f,d,m,g,w)},msync(f,d,m,g,w){return f.stream_ops.msync?f.stream_ops.msync(f,d,m,g,w):0},ioctl(f,d,m){if(!f.stream_ops.ioctl)throw new _.ErrnoError(59);return f.stream_ops.ioctl(f,d,m)},readFile(f,d={}){d.flags??(d.flags=0),d.encoding??(d.encoding="binary"),d.encoding!=="utf8"&&d.encoding!=="binary"&&ee(`Invalid encoding type "${d.encoding}"`);var m=_.open(f,d.flags),g=_.stat(f),w=g.size,x=new Uint8Array(w);return _.read(m,x,0,w,0),d.encoding==="utf8"&&(x=us(x)),_.close(m),x},writeFile(f,d,m={}){m.flags??(m.flags=577);var g=_.open(f,m.flags,m.mode);d=Mf(d),_.write(g,d,0,d.byteLength,void 0,m.canOwn),_.close(g)},cwd:()=>_.currentPath,chdir(f){var d=_.lookupPath(f,{follow:!0});if(d.node===null)throw new _.ErrnoError(44);if(!_.isDir(d.node.mode))throw new _.ErrnoError(54);var m=_.nodePermissions(d.node,"x");if(m)throw new _.ErrnoError(m);_.currentPath=d.path},createDefaultDirectories(){_.mkdir("/tmp"),_.mkdir("/home"),_.mkdir("/home/web_user")},createDefaultDevices(){_.mkdir("/dev"),_.registerDevice(_.makedev(1,3),{read:()=>0,write:(g,w,x,S,P)=>S,llseek:()=>0}),_.mkdev("/dev/null",_.makedev(1,3)),gi.register(_.makedev(5,0),gi.default_tty_ops),gi.register(_.makedev(6,0),gi.default_tty1_ops),_.mkdev("/dev/tty",_.makedev(5,0)),_.mkdev("/dev/tty1",_.makedev(6,0));var f=new Uint8Array(1024),d=0,m=()=>(d||(Cf(f),d=f.byteLength),f[--d]);_.createDevice("/dev","random",m),_.createDevice("/dev","urandom",m),_.mkdir("/dev/shm"),_.mkdir("/dev/shm/tmp")},createSpecialDirectories(){_.mkdir("/proc");var f=_.mkdir("/proc/self");_.mkdir("/proc/self/fd"),_.mount({mount(){var d=_.createNode(f,"fd",16895,73);return d.stream_ops={llseek:G.stream_ops.llseek},d.node_ops={lookup(m,g){var w=+g,x=_.getStreamChecked(w),S={parent:null,mount:{mountpoint:"fake"},node_ops:{readlink:()=>x.path},id:w+1};return S.parent=S,S},readdir(){return Array.from(_.streams.entries()).filter(([m,g])=>g).map(([m,g])=>m.toString())}},d}},{},"/proc/self/fd")},createStandardStreams(f,d,m){f?_.createDevice("/dev","stdin",f):_.symlink("/dev/tty","/dev/stdin"),d?_.createDevice("/dev","stdout",null,d):_.symlink("/dev/tty","/dev/stdout"),m?_.createDevice("/dev","stderr",null,m):_.symlink("/dev/tty1","/dev/stderr");var g=_.open("/dev/stdin",0),w=_.open("/dev/stdout",1),x=_.open("/dev/stderr",1)},staticInit(){_.nameTable.length=4096,_.mount(G,{},"/"),_.createDefaultDirectories(),_.createDefaultDevices(),_.createSpecialDirectories(),_.filesystems={MEMFS:G}},init(f,d,m){_.initialized=!0,f??(f=e.stdin),d??(d=e.stdout),m??(m=e.stderr),_.createStandardStreams(f,d,m)},quit(){_.initialized=!1;for(var f of _.streams)f&&_.close(f)},analyzePath(f,d=!1){try{var m=_.lookupPath(f,{follow:!d});f=m.path}catch{}var g={isRoot:!1,exists:!1,error:0,name:null,path:null,object:null,parentExists:!1,parentPath:null,parentObject:null};try{var m=_.lookupPath(f,{parent:!0});g.parentExists=!0,g.parentPath=m.path,g.parentObject=m.node,g.name=de.basename(f),m=_.lookupPath(f,{follow:!d}),g.exists=!0,g.path=m.path,g.object=m.node,g.name=m.node.name,g.isRoot=m.path==="/"}catch(w){g.error=w.errno}return g},createPath(f,d,m,g){f=typeof f=="string"?f:_.getPath(f);for(var w=d.split("/").reverse();w.length;){var x=w.pop();if(x){var S=de.join2(f,x);try{_.mkdir(S)}catch(P){if(P.errno!=20)throw P}f=S}}return S},createFile(f,d,m,g,w){var x=de.join2(typeof f=="string"?f:_.getPath(f),d),S=ll(g,w);return _.create(x,S)},createDataFile(f,d,m,g,w,x){var S=d;f&&(f=typeof f=="string"?f:_.getPath(f),S=d?de.join2(f,d):f);var P=ll(g,w),N=_.create(S,P);if(m){m=Mf(m),_.chmod(N,P|146);var q=_.open(N,577);_.write(q,m,0,m.length,0,x),_.close(q),_.chmod(N,P)}},createDevice(f,d,m,g){var P;var w=de.join2(typeof f=="string"?f:_.getPath(f),d),x=ll(!!m,!!g);(P=_.createDevice).major??(P.major=64);var S=_.makedev(_.createDevice.major++,0);return _.registerDevice(S,{open(N){N.seekable=!1},close(N){var q;(q=g==null?void 0:g.buffer)!=null&&q.length&&g(10)},read(N,q,Y,te,X){for(var V=0,ne=0;ne<te;ne++){var fe;try{fe=m()}catch{throw new _.ErrnoError(29)}if(fe===void 0&&!V)throw new _.ErrnoError(6);if(fe==null)break;V++,q[Y+ne]=fe}return V&&(N.node.atime=Date.now()),V},write(N,q,Y,te,X){for(var V=0;V<te;V++)try{g(q[Y+V])}catch{throw new _.ErrnoError(29)}return te&&(N.node.mtime=N.node.ctime=Date.now()),V}}),_.mkdev(w,x,S)},forceLoadFile(f){if(f.isDevice||f.isFolder||f.link||f.contents)return!0;if(globalThis.XMLHttpRequest)ee("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");else try{f.contents=y(f.url)}catch{throw new _.ErrnoError(29)}},createLazyFile(f,d,m,g,w){class x{lengthKnown=!1;chunks=[];get(X){if(!(X>this.length-1||X<0)){var V=X%this.chunkSize,ne=X/this.chunkSize|0;return this.getter(ne)[V]}}setDataGetter(X){this.getter=X}cacheLength(){var X=new XMLHttpRequest;X.open("HEAD",m,!1),X.send(null),X.status>=200&&X.status<300||X.status===304||ee(`Couldn't load ${m}. Status: ${X.status}`);var V=Number(X.getResponseHeader("Content-length")),ne,fe=(ne=X.getResponseHeader("Accept-Ranges"))&&ne==="bytes",ge=(ne=X.getResponseHeader("Content-Encoding"))&&ne==="gzip",ze=1024*1024;fe||(ze=V);var Dt=(Ut,_s)=>{Ut>_s&&ee(`invalid range (${Ut}, ${_s}) or no bytes requested!`),_s>V-1&&ee(`only ${V} bytes available! programmer error!`);var je=new XMLHttpRequest;return je.open("GET",m,!1),V!==ze&&je.setRequestHeader("Range",`bytes=${Ut}-${_s}`),je.responseType="arraybuffer",je.overrideMimeType&&je.overrideMimeType("text/plain; charset=x-user-defined"),je.send(null),je.status>=200&&je.status<300||je.status===304||ee(`Couldn't load ${m}. Status: ${je.status}`),je.response!==void 0?new Uint8Array(je.response||[]):ol(je.responseText??"",!0)},tr=this;tr.setDataGetter(Ut=>{var _s=Ut*ze,je=(Ut+1)*ze-1;return je=Math.min(je,V-1),typeof tr.chunks[Ut]>"u"&&(tr.chunks[Ut]=Dt(_s,je)),typeof tr.chunks[Ut]>"u"&&ee("doXHR failed!"),tr.chunks[Ut]}),(ge||!V)&&(ze=V=1,V=this.getter(0).length,ze=V,b("LazyFiles on gzip forces download of the whole file when length is accessed")),this._length=V,this._chunkSize=ze,this.lengthKnown=!0}get length(){return this.lengthKnown||this.cacheLength(),this._length}get chunkSize(){return this.lengthKnown||this.cacheLength(),this._chunkSize}}if(globalThis.XMLHttpRequest){i||ee("Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc");var S=new x,P={isDevice:!1,contents:S}}else var P={isDevice:!1,url:m};var N=_.createFile(f,d,P,g,w);P.contents?N.contents=P.contents:P.url&&(N.contents=null,N.url=P.url),Object.defineProperties(N,{usedBytes:{get:function(){return this.contents.length}}});var q={};for(let[te,X]of Object.entries(N.stream_ops))q[te]=(...V)=>(_.forceLoadFile(N),X(...V));function Y(te,X,V,ne,fe){var ge=te.node.contents;if(fe>=ge.length)return 0;var ze=Math.min(ge.length-fe,ne);if(ge.slice)for(var Dt=0;Dt<ze;Dt++)X[V+Dt]=ge[fe+Dt];else for(var Dt=0;Dt<ze;Dt++)X[V+Dt]=ge.get(fe+Dt);return ze}return q.read=(te,X,V,ne,fe)=>(_.forceLoadFile(N),Y(te,X,V,ne,fe)),q.mmap=(te,X,V,ne,fe)=>{_.forceLoadFile(N);var ge=Rf(X);if(!ge)throw new _.ErrnoError(48);return Y(te,Oe,ge,X,V),{ptr:ge,allocated:!0}},N.stream_ops=q,N}},ps,ti=(f,d,m)=>f?us(ps,f,d,m):"",Mt,me,Ve,ae={currentUmask:18,calculateAt(f,d,m=!1){if(de.isAbs(d))return d;var g;if(f===-100)g=_.cwd();else{var w=ae.getStreamFromFD(f);g=w.path}if(d.length==0){if(!m)throw new _.ErrnoError(44);return g}return g+"/"+d},writeStat(f,d){me[f>>2]=d.dev,me[f+4>>2]=d.mode,me[f+8>>2]=d.nlink,me[f+12>>2]=d.uid,me[f+16>>2]=d.gid,me[f+20>>2]=d.rdev,Ve[f+24>>3]=BigInt(d.size),Mt[f+32>>2]=4096,Mt[f+36>>2]=d.blocks;var m=d.atimeMs??d.atime.getTime(),g=d.mtimeMs??d.mtime.getTime(),w=d.ctimeMs??d.ctime.getTime();return Ve[f+40>>3]=BigInt(Math.floor(m/1e3)),me[f+48>>2]=Math.floor(m%1e3*1e6),Ve[f+56>>3]=BigInt(Math.floor(g/1e3)),me[f+64>>2]=Math.floor(g%1e3*1e6),Ve[f+72>>3]=BigInt(Math.floor(w/1e3)),me[f+80>>2]=Math.floor(w%1e3*1e6),Ve[f+88>>3]=BigInt(d.ino),0},writeStatFs(f,d){me[f+4>>2]=d.bsize,me[f+60>>2]=d.bsize,Ve[f+8>>3]=BigInt(d.blocks),Ve[f+16>>3]=BigInt(d.bfree),Ve[f+24>>3]=BigInt(d.bavail),Ve[f+32>>3]=BigInt(d.files),Ve[f+40>>3]=BigInt(d.ffree),me[f+48>>2]=d.fsid,me[f+64>>2]=d.flags,me[f+56>>2]=d.namelen},doMsync(f,d,m,g,w){if(!_.isFile(d.node.mode))throw new _.ErrnoError(43);if(g&2)return 0;var x=ps.subarray(f,f+m);_.msync(d,x,w,m,g)},getStreamFromFD(f){var d=_.getStreamChecked(f);return d},varargs:void 0,getStr(f){var d=ti(f);return d}};function l_(f){try{return f=ae.getStr(f),_.chdir(f),0}catch(d){if(typeof _>"u"||d.name!=="ErrnoError")throw d;return-d.errno}}function a_(f,d){try{return ae.writeStat(d,_.fstat(f))}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}var er=(f,d,m)=>Af(f,ps,d,m);function h_(f,d){try{if(!d)return-28;var m=_.cwd(),g=Zs(m)+1;return d<g?-68:(er(m,f,d),g)}catch(w){if(typeof _>"u"||w.name!=="ErrnoError")throw w;return-w.errno}}var _i;function f_(f,d,m){try{var g=ae.getStreamFromFD(f);g.getdents||(g.getdents=_.readdir(g.path));for(var w=280,x=0,S=_.llseek(g,0,1),P=Math.floor(S/w),N=Math.min(g.getdents.length,P+Math.floor(m/w)),q=P;q<N;q++){var Y,te,X=g.getdents[q];if(X===".")Y=g.node.id,te=4;else if(X===".."){var V=_.lookupPath(g.path,{parent:!0});Y=V.node.id,te=4}else{var ne;try{ne=_.lookupNode(g.node,X)}catch(fe){if((fe==null?void 0:fe.errno)===28)continue;throw fe}Y=ne.id,te=_.isChrdev(ne.mode)?2:_.isDir(ne.mode)?4:_.isLink(ne.mode)?10:8}Ve[d+x>>3]=BigInt(Y),Ve[d+x+8>>3]=BigInt((q+1)*w),_i[d+x+16>>1]=280,Oe[d+x+18]=te,er(X,d+x+19,256),x+=w}return _.llseek(g,q*w,0),x}catch(fe){if(typeof _>"u"||fe.name!=="ErrnoError")throw fe;return-fe.errno}}function c_(f,d){try{return f=ae.getStr(f),ae.writeStat(d,_.lstat(f))}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}function d_(f,d,m){try{return d=ae.getStr(d),d=ae.calculateAt(f,d),m&=~ae.currentUmask,_.mkdir(d,m),0}catch(g){if(typeof _>"u"||g.name!=="ErrnoError")throw g;return-g.errno}}function u_(f,d,m,g){try{d=ae.getStr(d);var w=g&256,x=g&4096;return g=g&-6401,d=ae.calculateAt(f,d,x),ae.writeStat(m,w?_.lstat(d):_.stat(d))}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return-S.errno}}var p_=()=>{var f=Mt[+ae.varargs>>2];return ae.varargs+=4,f};function m_(f,d,m,g){ae.varargs=g;try{d=ae.getStr(d),d=ae.calculateAt(f,d);var w=g?p_():0;return m&64&&(w&=~ae.currentUmask),_.open(d,m,w).fd}catch(x){if(typeof _>"u"||x.name!=="ErrnoError")throw x;return-x.errno}}var Lf=(f,d)=>{var w,x;var m=_.getStream(f);if(!m)return 32;var g=((x=(w=m.stream_ops)==null?void 0:w.poll)==null?void 0:x.call(w,m))??5;return g&(d|8|16|32)},Qf=(f,d)=>{for(var m=0,g=0,w=f;g<d;g++,w+=8){var x=Lf(Mt[w>>2],_i[w+4>>1]);x&&m++,_i[w+6>>1]=x}return m},g_=(f,d,m)=>new Promise(g=>{var w=[],x,S=!1;function P(){for(var V=0,ne=0,fe=f;ne<d;ne++,fe+=8){var ge=Lf(Mt[fe>>2],_i[fe+4>>1]);ge&&V++,_i[fe+6>>1]=ge}return V}function N(V){if(!S){S=!0;for(var ne of w)ne.listeners.delete(ne.entry);x&&clearTimeout(x),g(V)}}var q=P();if(q||!m)N(q);else{let V=function(){if(!S){var ne=P();ne&&N(ne)}};for(var Y=0,te=f;Y<d;Y++,te+=8){var X=_.getStream(Mt[te>>2]);X&&w.push(X.node.addListener(V))}m>0&&(x=setTimeout(()=>N(0),m))}}),qf=function(f,d,m){let g=()=>{try{return g_(f,d,m);var w}catch(x){if(typeof _>"u"||x.name!=="ErrnoError")throw x;return-x.errno}};return j.handleAsync(g)};qf.isAsync=!0;function __(f,d){try{return Qf(f,d)}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}function y_(f,d,m,g){try{return d=ae.getStr(d),g=ae.getStr(g),d=ae.calculateAt(f,d),g=ae.calculateAt(m,g),_.rename(d,g),0}catch(w){if(typeof _>"u"||w.name!=="ErrnoError")throw w;return-w.errno}}function b_(f){try{return f=ae.getStr(f),_.rmdir(f),0}catch(d){if(typeof _>"u"||d.name!=="ErrnoError")throw d;return-d.errno}}function O_(f,d){try{return f=ae.getStr(f),ae.writeStat(d,_.stat(f))}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return-m.errno}}function v_(f,d,m){try{return ae.writeStatFs(m,_.statfs(ae.getStr(f))),0}catch(g){if(typeof _>"u"||g.name!=="ErrnoError")throw g;return-g.errno}}function w_(f,d,m){try{if(d=ae.getStr(d),d=ae.calculateAt(f,d),!m)_.unlink(d);else if(m===512)_.rmdir(d);else return-28;return 0}catch(g){if(typeof _>"u"||g.name!=="ErrnoError")throw g;return-g.errno}}var k_=()=>{throw new R},x_=()=>performance.now(),S_=()=>2147483648,T_=(f,d)=>Math.ceil(f/d)*d,P_=f=>{var d=Zr.buffer.byteLength,m=(f-d+65535)/65536|0;try{return Zr.grow(m),J(),1}catch{}},C_=f=>{var d=ps.length;f>>>=0;var m=S_();if(f>m)return!1;for(var g=1;g<=4;g*=2){var w=d*(1+.2/g);w=Math.min(w,f+100663296);var x=Math.min(m,T_(Math.max(f,w),65536)),S=P_(x);if(S)return!0}return!1},Bf=f=>{if(f instanceof Ke||f=="unwind")return C;a(1,f)},al=0,$f=()=>Pf||al>0,E_=f=>{var d;C=f,$f()||((d=e.onExit)==null||d.call(e,f),T=!0),a(f,new Ke(f))},A_=(f,d)=>{C=f,E_(f)},R_=A_,M_=()=>{if(!$f())try{R_(C)}catch(f){Bf(f)}},hl=(f,...d)=>{if(!T)try{return f(...d)}catch(m){Bf(m)}finally{M_()}},ms=(f,d)=>{var m=ms.nextId++;return ms.pending.set(m,setTimeout(()=>{ms.pending.delete(m),hl(f)},d)),m},Ff=f=>j.handleSleep(d=>{ms(()=>{var m=j.currData+12,g=me[j.currData>>2];((w,x)=>pl(f,w,x))(m,g),d()},0)});Ff.isAsync=!0;var Wf=function(f){let d=()=>new Promise(m=>setTimeout(m,f));return j.handleAsync(d)};Wf.isAsync=!0;function D_(f){try{var d=ae.getStreamFromFD(f);return _.close(d),0}catch(m){if(typeof _>"u"||m.name!=="ErrnoError")throw m;return m.errno}}var N_=(f,d,m,g)=>{for(var w=0,x=0;x<m;x++){var S=me[d>>2],P=me[d+4>>2];d+=8;try{var N=_.read(f,Oe,S,P,g)}catch(q){if(w>0&&q instanceof _.ErrnoError&&(q.errno==6||q.errno==6))break;throw q}if(N<0)return-1;if(w+=N,N<P)break;typeof g<"u"&&(g+=N)}return w};function I_(f,d,m,g){try{var w=ae.getStreamFromFD(f),x=N_(w,d,m);return me[g>>2]=x,0}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return S.errno}}var L_=9007199254740992,Q_=-9007199254740992,q_=f=>f<Q_||f>L_?NaN:Number(f);function B_(f,d,m,g){d=q_(d);try{if(isNaN(d))return 22;var w=ae.getStreamFromFD(f);return _.llseek(w,d,m),Ve[g>>3]=BigInt(w.position),w.getdents&&!d&&m===0&&(w.getdents=null),0}catch(x){if(typeof _>"u"||x.name!=="ErrnoError")throw x;return x.errno}}var zf=function(f){let d=()=>{var w,x;try{var m=ae.getStreamFromFD(f),g=(x=(w=m.stream_ops)==null?void 0:w.fsync)==null?void 0:x.call(w,m);return new Promise(S=>{var P=m.node.mount;P!=null&&P.type.syncfs?P.type.syncfs(P,!1,N=>S(N?29:0)):S(g)})}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return S.errno}};return j.handleAsync(d)};zf.isAsync=!0;var $_=(f,d,m,g)=>{if(m==1)return _.write(f,Oe,me[d>>2],me[d+4>>2],g);for(var w=0,x=0,S=d;x<m;x++,S+=8)w+=me[S+4>>2];for(var P=new Uint8Array(w),N=0,x=0;x<m;x++,d+=8){var q=me[d>>2],Y=me[d+4>>2];P.set(ps.subarray(q,q+Y),N),N+=Y}return _.write(f,P,0,w,g)};function F_(f,d,m,g){try{var w=ae.getStreamFromFD(f),x=$_(w,d,m);return me[g>>2]=x,0}catch(S){if(typeof _>"u"||S.name!=="ErrnoError")throw S;return S.errno}}var W_=()=>globalThis.crypto.getRandomValues(new Uint32Array(1))[0],z_=()=>Date.now()-Y_,j_=()=>typeof performance<"u"&&performance.timeOrigin?performance.timeOrigin+performance.now():Date.now(),H2=[],Kr=f=>{try{return f()}catch(d){ee(d)}},H_=()=>{al+=1},V_=()=>{al-=1},j={instrumentWasmImports(f){var d=/^(invoke_.*|__asyncjs__.*)$/;for(let[m,g]of Object.entries(f))if(typeof g=="function"){let w=g.isAsync||d.test(m)}},instrumentFunction(f){var d=(...m)=>{j.exportCallStack.push(f);try{return f(...m)}finally{if(!T){var g=j.exportCallStack.pop();j.maybeStopUnwind()}}};return j.funcWrappers.set(f,d),d},instrumentWasmExports(f){var d={};for(let[g,w]of Object.entries(f))if(typeof w=="function"){var m=j.instrumentFunction(w);d[g]=m}else d[g]=w;return d},State:{Normal:0,Unwinding:1,Rewinding:2,Disabled:3},state:0,StackSize:65536,currData:null,handleSleepReturnValue:0,exportCallStack:[],callstackFuncToId:new Map,callStackIdToFunc:new Map,funcWrappers:new Map,callStackId:0,asyncPromiseHandlers:null,sleepCallbacks:[],getCallStackId(f){if(!j.callstackFuncToId.has(f)){var d=j.callStackId++;j.callstackFuncToId.set(f,d),j.callStackIdToFunc.set(d,f)}return j.callstackFuncToId.get(f)},maybeStopUnwind(){j.currData&&j.state===j.State.Unwinding&&!j.exportCallStack.length&&(j.state=j.State.Normal,Kr(ac),typeof Fibers<"u"&&Fibers.trampoline())},whenDone(){return new Promise((f,d)=>{j.asyncPromiseHandlers={resolve:f,reject:d}})},allocateData(){var f=ul(12+j.StackSize);return j.setDataHeader(f,f+12,j.StackSize),j.setDataRewindFunc(f),f},setDataHeader(f,d,m){me[f>>2]=d,me[f+4>>2]=d+m},setDataRewindFunc(f){var d=j.exportCallStack[0],m=j.getCallStackId(d);Mt[f+8>>2]=m},getDataRewindFunc(f){var d=Mt[f+8>>2],m=j.callStackIdToFunc.get(d);return m},doRewind(f){var d=j.getDataRewindFunc(f),m=j.funcWrappers.get(d);return hl(m)},handleSleep(f){if(!T){if(j.state===j.State.Normal){var d=!1,m=!1;f((w=0)=>{if(!T&&(j.handleSleepReturnValue=w,d=!0,!!m)){j.state=j.State.Rewinding,Kr(()=>hc(j.currData)),typeof MainLoop<"u"&&MainLoop.func&&MainLoop.resume();var x,S=!1;try{x=j.doRewind(j.currData)}catch(q){x=q,S=!0}var P=!1;if(!j.currData){var N=j.asyncPromiseHandlers;N&&(j.asyncPromiseHandlers=null,(S?N.reject:N.resolve)(x),P=!0)}if(S&&!P)throw x}}),m=!0,d||(j.state=j.State.Unwinding,j.currData=j.allocateData(),typeof MainLoop<"u"&&MainLoop.func&&MainLoop.pause(),Kr(()=>lc(j.currData)))}else if(j.state===j.State.Rewinding){j.state=j.State.Normal,Kr(fc),Uf(j.currData),j.currData=null;for(var g of j.sleepCallbacks)hl(g)}else ee(`invalid state: ${j.state}`);return j.handleSleepReturnValue}},handleAsync:f=>j.handleSleep(async d=>{d(await f())})},fl,cl;function U_(f,d,m="i8"){switch(m.endsWith("*")&&(m="*"),m){case"i1":Oe[f]=d;break;case"i8":Oe[f]=d;break;case"i16":_i[f>>1]=d;break;case"i32":Mt[f>>2]=d;break;case"i64":Ve[f>>3]=BigInt(d);break;case"float":fl[f>>2]=d;break;case"double":cl[f>>3]=d;break;case"*":me[f>>2]=d;break;default:ee(`invalid type for setValue: ${m}`)}}function dl(f,d="i8"){switch(d.endsWith("*")&&(d="*"),d){case"i1":return Oe[f];case"i8":return Oe[f];case"i16":return _i[f>>1];case"i32":return Mt[f>>2];case"i64":return Ve[f>>3];case"float":return fl[f>>2];case"double":return cl[f>>3];case"*":return me[f>>2];default:ee(`invalid type for getValue: ${d}`)}}var jf=f=>{var d=e["_"+f];return d},G_=(f,d)=>{Oe.set(f,d)},Hf=f=>Jf(f),X_=f=>{var d=Zs(f)+1,m=Hf(d);return er(f,m,d),m},Vf=(f,d,m,g,w)=>{var x={string:ge=>{var ze=0;return ge!=null&&ge!==0&&(ze=X_(ge)),ze},array:ge=>{var ze=Hf(ge.length);return G_(ge,ze),ze}};function S(ge){return d==="string"?ti(ge):d==="boolean"?!!ge:ge}var P=jf(f),N=[],q=0;if(g)for(var Y=0;Y<g.length;Y++){var te=x[m[Y]];te?(q||(q=yt()),N[Y]=te(g[Y])):N[Y]=g[Y]}var X=j.currData,V=P(...N);function ne(ge){return V_(),q&&_t(q),S(ge)}var fe=w==null?void 0:w.async;return H_(),j.currData!=X?j.whenDone().then(ne):(V=ne(V),fe?Promise.resolve(V):V)},J_=(f,d,m,g)=>{var w=!m||m.every(S=>S==="number"||S==="boolean"),x=d!=="string";return x&&w&&!g?jf(f):(...S)=>Vf(f,d,m,S,g)};_.createPreloadedFile=o_,_.preloadFile=If,_.staticInit(),ms.pending=new Map,ms.nextId=1,globalThis.crypto===void 0&&(globalThis.crypto=n("crypto"));var Y_=Date.now();{e.noExitRuntime&&(Pf=e.noExitRuntime),e.print&&(b=e.print),e.printErr&&(v=e.printErr),e.arguments&&(o=e.arguments),e.thisProgram&&(l=e.thisProgram);var gs=e.preInit;if(gs)for(typeof gs=="function"&&(e.preInit=gs=[gs]);gs.length>0;)gs.shift()()}e.ccall=Vf,e.cwrap=J_,e.setValue=U_,e.getValue=dl,e.PATH=de,e.PATH_FS=Ni,e.UTF8ToString=ti,e.stringToUTF8=er,e.lengthBytesUTF8=Zs,e.FS=_;function K_(){return-new Date().getTimezoneOffset()*60}function Z_(){return e.raptiPending?e.raptiPending()|0:0}function ey(){return e.raptiShouldYield?e.raptiShouldYield()|0:0}function ty(f){return j.handleAsync(async()=>{let d=ti(f),m=e.raptiReadLine?await e.raptiReadLine(d):"",g=m==null?"":String(m),w=Zs(g)+1,x=ul(w);return er(g,x,w),x})}function iy(){return e.raptiDead?1:0}function sy(){return j.handleAsync(async()=>{await new Promise(()=>{})})}function ry(f){let d=ve(f);Xb(d,f)}function ny(f){let d=ve(f),m=Bi.toJs(d);Pe(m,f)}function oy(f){let d=0;for(let m of proxy_js_ref)m!==void 0&&++d;e.setValue(f,proxy_js_ref.length,"i32"),e.setValue(f+4,d,"i32")}function ly(f,d){let m=proxy_js_ref[f];return ti(d)in m}function ay(f,d,m){let g=proxy_js_ref[f],w=ti(d),x=g[w];return x!==void 0||w in g?(Pe(x,m),typeof x=="function"&&!("_ref"in x)?2:1):0}function hy(f,d,m){let g=ti(d),w=ve(m);proxy_js_ref[f][g]=w}function fy(f,d){let m=proxy_js_ref[f],g=m();Pe(g,d)}function cy(f,d,m,g){let w=ve(m),x=proxy_js_ref[f],S;d?S=x.call(w):S=x(w),Pe(S,g)}function dy(f,d,m,g,w){let x=ve(m),S=ve(g),P=proxy_js_ref[f],N;d?N=P.call(x,S):N=P(x,S),Pe(N,w)}function uy(f,d,m,g,w){let x=proxy_js_ref[f],S=[];for(let N=0;N<m;++N){let q=ve(g+N*3*4);S.push(q)}let P;d?P=x.call(...S):P=x(...S),Pe(P,w)}function py(f,d,m,g,w,x){let S=proxy_js_ref[f],P={};for(let q=0;q<m;++q){let Y=ti(dl(g+q*4,"i32")),te=ve(w+q*3*4);P[Y]=te}let N;d?N=S.call(P):N=S(P),Pe(N,x)}function my(f,d,m,g,w,x,S,P){let N=proxy_js_ref[f],q=[];for(let X=0;X<m;++X){let V=ve(g+X*3*4);q.push(V)}let Y={};for(let X=0;X<w;++X){let V=ti(dl(x+X*4,"i32")),ne=ve(S+X*3*4);Y[V]=ne}let te;d?te=N.call(...q,Y):te=N(...q,Y),Pe(te,P)}function gy(f,d,m,g){let w=proxy_js_ref[f],x=[];for(let P=0;P<d;++P)x.push(ve(m+P*3*4));let S=Reflect.construct(w,x);Pe(S,g)}function _y(f,d){let g=proxy_js_ref[f][Symbol.iterator]();Pe(g,d)}function yy(f,d){let g=proxy_js_ref[f].next();return g.done?!1:(Pe(g.value,d),!0)}function by(f,d,m){let g=proxy_js_ref[f],w=Jb(g,ve(d)),x=g[w];Pe(x,m)}function Oy(f,d,m){let g=proxy_js_ref[f];g[ve(d)]=ve(m)}function vy(f){f>=wc&&(proxy_js_ref_map.delete(proxy_js_ref[f]),proxy_js_ref[f]=void 0,f<proxy_js_ref_next&&(proxy_js_ref_next=f))}function wy(f){return Vb(f)}function ky(f,d,m){let g=proxy_js_ref[f];Pe(g.name,d),Pe(g.message,m)}function xy(f,d){let m=ve(f);ve(d)(m)}function Sy(f,d){let m;try{m=ve(f)}catch(w){m=w}ve(d)(m)}function Ty(f,d,m,g,w){let x=ve(d),S=ve(m),P=ve(g),N=proxy_js_ref[f].then(q=>{x(q,null,S,P)},q=>{x(null,q,S,P)});Pe(N,w)}function Py(f,d){let m=ve(f),g=new Promise(m);Pe(g,d)}var Cy,Uf,Ey,ul,Ay,Ry,My,Dy,Ny,Iy,Ly,Qy,qy,By,$y,Fy,Wy,zy,jy,Hy,Vy,Uy,Gy,Xy,Gf,bt,Xf,Jf,Yf,Kf,Zf,ec,tc,pl,ic,sc,rc,nc,Jy,Yy,Ky,oc,Zy,lc,ac,hc,fc,eb,tb,Zr,ib;function sb(f){Cy=e._mp_sched_keyboard_interrupt=f.mp_sched_keyboard_interrupt,Uf=e._free=f.free,Ey=e._mp_js_init=f.mp_js_init,ul=e._malloc=f.malloc,Ay=e._mp_js_register_js_module=f.mp_js_register_js_module,Ry=e._mp_js_do_import=f.mp_js_do_import,My=e._proxy_convert_mp_to_js_obj_cside=f.proxy_convert_mp_to_js_obj_cside,Dy=e._mp_js_do_exec=f.mp_js_do_exec,Ny=e._mp_js_do_exec_async=f.mp_js_do_exec_async,Iy=e._mp_js_repl_init=f.mp_js_repl_init,Ly=e._mp_js_repl_process_char=f.mp_js_repl_process_char,Qy=e._mp_hal_get_interrupt_char=f.mp_hal_get_interrupt_char,qy=e._proxy_c_init=f.proxy_c_init,By=e._proxy_c_free_obj=f.proxy_c_free_obj,$y=e._proxy_c_to_js_call=f.proxy_c_to_js_call,Fy=e._proxy_c_to_js_dir=f.proxy_c_to_js_dir,Wy=e._proxy_c_to_js_has_attr=f.proxy_c_to_js_has_attr,zy=e._proxy_c_to_js_lookup_attr=f.proxy_c_to_js_lookup_attr,jy=e._proxy_c_to_js_store_attr=f.proxy_c_to_js_store_attr,Hy=e._proxy_c_to_js_delete_attr=f.proxy_c_to_js_delete_attr,Vy=e._proxy_c_to_js_get_type_and_data=f.proxy_c_to_js_get_type_and_data,Uy=e._proxy_c_to_js_get_iter=f.proxy_c_to_js_get_iter,Gy=e._proxy_c_to_js_iternext=f.proxy_c_to_js_iternext,Xy=e._proxy_c_to_js_resume=f.proxy_c_to_js_resume,Gf=f.emscripten_stack_get_current,bt=f.setThrew,Xf=f._emscripten_stack_restore,Jf=f._emscripten_stack_alloc,Yf=Ne.viii=f.dynCall_viii,Kf=Ne.vi=f.dynCall_vi,Zf=Ne.ii=f.dynCall_ii,ec=Ne.iiii=f.dynCall_iiii,tc=Ne.v=f.dynCall_v,pl=Ne.vii=f.dynCall_vii,ic=Ne.iii=f.dynCall_iii,sc=Ne.viiii=f.dynCall_viiii,rc=Ne.iiiii=f.dynCall_iiiii,nc=Ne.i=f.dynCall_i,Jy=Ne.dd=f.dynCall_dd,Yy=Ne.ddd=f.dynCall_ddd,Ky=Ne.viiiiii=f.dynCall_viiiiii,oc=Ne.iiiiii=f.dynCall_iiiiii,Zy=Ne.iidiiiii=f.dynCall_iidiiiii,lc=f.asyncify_start_unwind,ac=f.asyncify_stop_unwind,hc=f.asyncify_start_rewind,fc=f.asyncify_stop_rewind,eb=Zr=f.memory,tb=ib=f.__indirect_function_table}var cc={__asyncjs__rapti_js_park:sy,__asyncjs__rapti_js_readline:ty,__syscall_chdir:l_,__syscall_fstat64:a_,__syscall_getcwd:h_,__syscall_getdents64:f_,__syscall_lstat64:c_,__syscall_mkdirat:d_,__syscall_newfstatat:u_,__syscall_openat:m_,__syscall_poll:qf,__syscall_poll_nonblocking:__,__syscall_renameat:y_,__syscall_rmdir:b_,__syscall_stat64:O_,__syscall_statfs64:v_,__syscall_unlinkat:w_,_emscripten_throw_longjmp:k_,call0:fy,call0_kwarg:py,call1:cy,call2:dy,calln:uy,calln_kwarg:my,create_promise:Py,emscripten_get_now:x_,emscripten_resize_heap:C_,emscripten_scan_registers:Ff,emscripten_sleep:Wf,fd_close:D_,fd_read:I_,fd_seek:B_,fd_sync:zf,fd_write:F_,has_attr:ly,invoke_i:db,invoke_ii:rb,invoke_iii:hb,invoke_iiii:nb,invoke_iiiii:ab,invoke_iiiiii:pb,invoke_v:ob,invoke_vi:fb,invoke_vii:cb,invoke_viii:lb,invoke_viiii:ub,js_check_existing:wy,js_get_error_info:ky,js_get_iter:_y,js_get_proxy_js_ref_info:oy,js_iter_next:yy,js_reflect_construct:gy,js_subscr_load:by,js_subscr_store:Oy,js_then_continue:Ty,js_then_reject:Sy,js_then_resolve:xy,lookup_attr:ay,mp_js_random_u32:W_,mp_js_ticks_ms:z_,mp_js_time_ms:j_,mp_js_tz_offset_s:K_,proxy_convert_mp_to_js_then_js_to_js_then_js_to_mp_obj_jsside:ny,proxy_convert_mp_to_js_then_js_to_mp_obj_jsside:ry,proxy_js_free_obj:vy,rapti_js_dead:iy,rapti_js_pending:Z_,rapti_js_should_yield:ey,store_attr:hy};function rb(f,d){var m=yt();try{return Zf(f,d)}catch(g){if(_t(m),!(g instanceof A))throw g;bt(1,0)}}function nb(f,d,m,g){var w=yt();try{return ec(f,d,m,g)}catch(x){if(_t(w),!(x instanceof A))throw x;bt(1,0)}}function ob(f){var d=yt();try{tc(f)}catch(m){if(_t(d),!(m instanceof A))throw m;bt(1,0)}}function lb(f,d,m,g){var w=yt();try{Yf(f,d,m,g)}catch(x){if(_t(w),!(x instanceof A))throw x;bt(1,0)}}function ab(f,d,m,g,w){var x=yt();try{return rc(f,d,m,g,w)}catch(S){if(_t(x),!(S instanceof A))throw S;bt(1,0)}}function hb(f,d,m){var g=yt();try{return ic(f,d,m)}catch(w){if(_t(g),!(w instanceof A))throw w;bt(1,0)}}function fb(f,d){var m=yt();try{Kf(f,d)}catch(g){if(_t(m),!(g instanceof A))throw g;bt(1,0)}}function cb(f,d,m){var g=yt();try{pl(f,d,m)}catch(w){if(_t(g),!(w instanceof A))throw w;bt(1,0)}}function db(f){var d=yt();try{return nc(f)}catch(m){if(_t(d),!(m instanceof A))throw m;bt(1,0)}}function ub(f,d,m,g,w){var x=yt();try{sc(f,d,m,g,w)}catch(S){if(_t(x),!(S instanceof A))throw S;bt(1,0)}}function pb(f,d,m,g,w,x){var S=yt();try{return oc(f,d,m,g,w,x)}catch(P){if(_t(S),!(P instanceof A))throw P;bt(1,0)}}async function mb(){var d;he(),Ii&&await t_();var f=e.setStatus;f&&(f("Running..."),await new Promise(m=>setTimeout(m,1)),setTimeout(f,1,"")),!T&&(Z(),(d=e.onRuntimeInitialized)==null||d.call(e),U())}var Li;return Li=await Rt(),await mb(),e}async function _l(r){let{pystack:e,heapsize:t,url:i,stdin:s,stdout:n,stderr:o,linebuffer:l}=Object.assign({pystack:2048,heapsize:1048576,linebuffer:!0},r),a=Object.assign({},r.module||{});a.locateFile=(c,u)=>i||u+c,a._textDecoder=new TextDecoder,s!==void 0&&(a.stdin=s),n!==void 0&&(l?(a._stdoutBuffer=[],a.stdout=c=>{c===10?(n(a._textDecoder.decode(new Uint8Array(a._stdoutBuffer))),a._stdoutBuffer=[]):a._stdoutBuffer.push(c)}):a.stdout=c=>n(new Uint8Array([c]))),o!==void 0&&(l?(a._stderrBuffer=[],a.stderr=c=>{c===10?(o(a._textDecoder.decode(new Uint8Array(a._stderrBuffer))),a._stderrBuffer=[]):a._stderrBuffer.push(c)}):a.stderr=c=>o(new Uint8Array([c]))),a=await kb(a),globalThis.Module=a,Hb();let h=c=>{let u=a._malloc(12);return a.ccall("mp_js_do_import","null",["string","pointer"],[c,u]),qi(u)};return a.ccall("mp_js_init","null",["number","number"],[e,t]),a.ccall("proxy_c_init","null",[],[]),{_module:a,PyProxy:Bi,FS:a.FS,globals:{__dict__:h("__main__").__dict__,get(c){return this.__dict__[c]},set(c,u){this.__dict__[c]=u},delete(c){delete this.__dict__[c]}},registerJsModule(c,u){let p=a._malloc(12);Pe(u,p),a.ccall("mp_js_register_js_module","null",["string","pointer"],[c,p]),a._free(p)},pyimport:h,runPython(c){let u=a.lengthBytesUTF8(c),p=a._malloc(u+1);a.stringToUTF8(c,p,u+1);let y=a._malloc(3*4);return a.ccall("mp_js_do_exec","number",["pointer","number","pointer"],[p,u,y]),a._free(p),qi(y)},runPythonAsync(c){let u=a.lengthBytesUTF8(c),p=a._malloc(u+1);a.stringToUTF8(c,p,u+1);let y=a._malloc(3*4);a.ccall("mp_js_do_exec_async","number",["pointer","number","pointer"],[p,u,y]),a._free(p);let O=qi(y);return O instanceof ys?Promise.resolve(O):O},replInit(){a.ccall("mp_js_repl_init","null",["null"])},replProcessChar(c){return a.ccall("mp_js_repl_process_char","number",["number"],[c])},async replProcessCharWithAsyncify(c){return a.ccall("mp_js_repl_process_char","number",["number"],[c],{async:!0})}}}globalThis.loadMicroPython=_l;var Bi=class r{constructor(e){this._ref=e}static toJs(e){if(!(e instanceof r))return e;let t=Module._malloc(2*4),i=Module.ccall("proxy_c_to_js_get_type_and_data","number",["number","pointer"],[e._ref,t]),s;if(i===1||i===2){let n=Module._malloc(12),o=Module.getValue(t,"i32"),l=Module.getValue(t+4,"i32"),a=[];for(let h=0;h<o;++h){Module.ccall("proxy_convert_mp_to_js_obj_cside","null",["pointer","pointer"],[Module.getValue(l+h*4,"i32"),n]);let c=ve(n);a.push(r.toJs(c))}Module._free(n),s=a}else if(i===3){let n=Module._malloc(12),o=Module.getValue(t,"i32"),l=Module.getValue(t+4,"i32"),a={};for(let h=0;h<o;++h){let c=Module.getValue(l+h*8,"i32");if(c>8){Module.ccall("proxy_convert_mp_to_js_obj_cside","null",["pointer","pointer"],[c,n]);let u=ve(n),p=Module.getValue(l+h*8+4,"i32");Module.ccall("proxy_convert_mp_to_js_obj_cside","null",["pointer","pointer"],[p,n]);let y=ve(n);a[u]=r.toJs(y)}}Module._free(n),s=a}else if(i===4){let n=Module.getValue(t,"i32"),o=Module.getValue(t+4,"i32");s=Module.HEAPU8.slice(o,o+n)}else s=e;return Module._free(t),s}},xb={isExtensible(){return!0},ownKeys(r){let e=Module._malloc(12);Module.ccall("proxy_c_to_js_dir","null",["number","pointer"],[r._ref,e]);let t=qi(e);return Bi.toJs(t).filter(i=>!i.startsWith("__"))},getOwnPropertyDescriptor(r,e){return{value:r[e],enumerable:!0,writable:!0,configurable:!0}},has(r,e){return typeof e!="string"?e===Symbol.iterator:Module.ccall("proxy_c_to_js_has_attr","number",["number","string"],[r._ref,e])},get(r,e){if(e==="_ref")return r._ref;if(e==="then"||typeof e!="string"){if(e===Symbol.iterator){let i=Module.ccall("proxy_c_to_js_get_iter","number",["number"],[r._ref]);return function*(){let s=Module._malloc(12);for(;Module.ccall("proxy_c_to_js_iternext","number",["number","pointer"],[i,s]);)yield ve(s);Module._free(s)}}return}let t=Module._malloc(3*4);return Module.ccall("proxy_c_to_js_lookup_attr","null",["number","string","pointer"],[r._ref,e,t]),qi(t)},set(r,e,t){let i=Module._malloc(12);Pe(t,i);let s=Module.ccall("proxy_c_to_js_store_attr","number",["number","string","number"],[r._ref,e,i]);return Module._free(i),s},deleteProperty(r,e){return Module.ccall("proxy_c_to_js_delete_attr","number",["number","string"],[r._ref,e])}},ys=class{constructor(e){this._ref=e}then(e,t){let i=Module._malloc(36);return Pe(e,i+3*4),Pe(t,i+2*3*4),Module.ccall("proxy_c_to_js_resume","null",["number","pointer"],[this._ref,i]),qi(i)}},wc=2,Sb=-1,Tb=0,Pb=1,Cb=2,Eb=3,Ab=4,Rb=5,Mb=6,Db=7;var Nb=9,Ib=10,Lb=0,Qb=1,qb=2,Bb=3,$b=4,Fb=5,Wb=6,zb=7,jb=8,tn=class extends Error{constructor(e,t){super(t),this.name="PythonError",this.type=e}};function Hb(){globalThis.proxy_js_ref=[globalThis,void 0],globalThis.proxy_js_ref_next=wc,globalThis.proxy_js_ref_map=new Map,globalThis.proxy_js_ref_map.set(globalThis,0),globalThis.proxy_js_map=new Map,globalThis.proxy_js_existing=[void 0],globalThis.pyProxyFinalizationRegistry=new FinalizationRegistry(r=>{globalThis.proxy_js_map.delete(r),Module.ccall("proxy_c_free_obj","null",["number"],[r])})}function Vb(r){var t;let e=(t=globalThis.proxy_js_map.get(r))==null?void 0:t.deref();if(e===void 0)return-1;for(let i=0;i<globalThis.proxy_js_existing.length;++i)if(globalThis.proxy_js_existing[i]===void 0)return globalThis.proxy_js_existing[i]=e,i;return globalThis.proxy_js_existing.push(e),globalThis.proxy_js_existing.length-1}function Ub(r){for(;proxy_js_ref_next<proxy_js_ref.length;){if(proxy_js_ref[proxy_js_ref_next]===void 0){let t=proxy_js_ref_next;return++proxy_js_ref_next,proxy_js_ref[t]=r,proxy_js_ref_map.set(r,t),t}++proxy_js_ref_next}let e=proxy_js_ref.length;return proxy_js_ref[e]=r,proxy_js_ref_next=proxy_js_ref.length,proxy_js_ref_map.set(r,e),e}function Gb(r,e){let t=0;for(;e.length>0&&e[e.length-1]===void 0;)e.pop();if(e.length>0){t=Module._malloc(e.length*3*4);for(let n in e)Pe(e[n],t+n*3*4)}let i=Module._malloc(3*4);Module.ccall("proxy_c_to_js_call","null",["number","number","number","pointer"],[r,e.length,t,i]),e.length>0&&Module._free(t);let s=qi(i);return s instanceof ys?Promise.resolve(s):s}function kc(r,e,t){let i;if(r===void 0)i=Lb;else if(r===null)i=Qb;else if(typeof r=="boolean")i=qb,Module.setValue(e+4,r,"i32");else if(typeof r=="number")if(Number.isInteger(r))i=Bb,Module.setValue(e+4,r,"i32");else{i=$b;let s=e+4&-8;Module.setValue(s,r,"double");let n=Module.getValue(s,"i32"),o=Module.getValue(s+4,"i32");Module.setValue(e+4,n,"i32"),Module.setValue(e+8,o,"i32")}else if(typeof r=="string"){i=Fb;let s=Module.lengthBytesUTF8(r),n=Module._malloc(s+1);Module.stringToUTF8(r,n,s+1),Module.setValue(e+4,s,"i32"),Module.setValue(e+8,n,"i32")}else if(t&&(r instanceof Bi||typeof r=="function"&&"_ref"in r||r instanceof ys))i=jb,Module.setValue(e+4,r._ref,"i32");else{let s,n=proxy_js_ref_map.get(r);n!==void 0?(i=Wb,s=n):(i=zb,s=Ub(r)),Module.setValue(e+4,s,"i32")}Module.setValue(e+0,i,"i32")}function Pe(r,e){kc(r,e,!0)}function Xb(r,e){kc(r,e,!1)}function ve(r){let e=Module.getValue(r,"i32"),t;if(e===Sb){let i=Module.getValue(r+4,"i32"),s=Module.getValue(r+8,"i32"),n=Module.UTF8ToString(s,i);Module._free(s);let o=n.split("");throw new tn(o[0],o[1])}if(e===Tb)throw new Error("NULL object");if(e===Pb)t=null;else if(e===Cb)t=!!Module.getValue(r+4,"i32");else if(e===Eb)t=Module.getValue(r+4,"i32");else if(e===Ab){let i=r+4&-8,s=Module.getValue(r+4,"i32"),n=Module.getValue(r+8,"i32");Module.setValue(i,s,"i32"),Module.setValue(i+4,n,"i32"),t=Module.getValue(i,"double")}else if(e===Rb){let i=Module.getValue(r+4,"i32"),s=Module.getValue(r+8,"i32");t=Module.UTF8ToString(s,i)}else if(e===Nb){let i=Module.getValue(r+4,"i32");t=proxy_js_ref[i]}else if(e===Ib){let i=Module.getValue(r+4,"i32");t=globalThis.proxy_js_existing[i],globalThis.proxy_js_existing[i]=void 0}else{let i=Module.getValue(r+4,"i32");if(e===Mb)t=(...s)=>Gb(i,s),t._ref=i;else if(e===Db)t=new ys(i);else{let s=new Bi(i);t=new Proxy(s,xb)}globalThis.pyProxyFinalizationRegistry.register(t,i),globalThis.proxy_js_map.set(i,new WeakRef(t))}return t}function qi(r){let e=ve(r);return Module._free(r),e}function Jb(r,e){let t=e;if(typeof t=="number"&&(t<0&&(t+=r.length),t<0||t>=r.length))throw new tn("IndexError","index out of range");return t}var Pc=se(en(),1);function xc(r){let e=()=>r.net,t=()=>r.netDev,i=0,s=new Map,n=new Map,o=new Map,l=()=>!!(e()&&t());return{net_online:()=>l()&&e().online(t())?1:0,net_ip:()=>l()?t().ip:"",net_resolve:a=>l()?e().resolve(a,t()):"",net_hostname:()=>l()&&t().hostname||"raspberrypi",net_request:(a,h,c,u)=>{let p=++i,y={done:!1,res:null};if(s.set(p,y),!l())return y.done=!0,y.res={failed:!0,error:"ERR_INTERNET_DISCONNECTED",statusText:"No network"},p;let O={};try{O=JSON.parse(c||"{}")}catch{}return e().request({method:a,url:h,headers:O,body:u,fromName:t().name},t()).then(b=>{y.done=!0,y.res=b}),p},net_poll:a=>{let h=s.get(a);return!h||!h.done?"":(s.delete(a),JSON.stringify(h.res))},net_listen:a=>l()?e().serverFor(t(),a)?-1:(e().listen(t(),a,t().name),1):0,net_unlisten:a=>{l()&&e().unlisten(t(),a)},net_accept:a=>{if(!l())return 0;let h=e().serverFor(t(),a);if(!h||!h.pending.length)return 0;let c=++i;return n.set(c,h.pending.shift()),c},net_req:a=>{let h=n.get(a);return h?JSON.stringify(h.req):"{}"},net_respond:(a,h,c,u)=>{let p=n.get(a);if(!p)return;n.delete(a);let y={};try{y=JSON.parse(c||"{}")}catch{}p.respond({status:h,headers:y,body:u})},mqtt_connect:(a,h,c,u,p,y,O)=>{if(!l())return-4;let b=y?{topic:y,payload:O||"",retain:!1}:null,v=e().mqtt.connect(a,h,c,{user:u||void 0,pass:p,will:b},t());if(!v.ok)return v.code;let k=++i;return o.set(k,v.client),k},mqtt_subscribe:(a,h)=>o.has(a)&&e().mqtt.subscribe(o.get(a),h)?1:0,mqtt_unsubscribe:(a,h)=>{o.has(a)&&e().mqtt.unsubscribe(o.get(a),h)},mqtt_publish:(a,h,c,u)=>o.has(a)&&e().mqtt.publish(o.get(a),h,c,!!u)?1:0,mqtt_poll:a=>{let h=o.get(a),c=h&&e().mqtt.poll(h);return c?JSON.stringify(c):""},mqtt_connected:a=>o.has(a)&&o.get(a).connected&&e().online(t())?1:0,mqtt_disconnect:a=>{let h=o.get(a);h&&(e().mqtt.disconnect(h),o.delete(a))},wifi_join:(a,h)=>l()?JSON.stringify(e().join(t(),a,h)):JSON.stringify({status:1,ip:""}),wifi_leave:()=>{l()&&e().leave(t())},wifi_ap:(a,h,c)=>{if(!l())return 0;let u=t();return u.apOn=!!a,u.apIp=a?"192.168.4.1":"",u.apSsid=h||"",e().changed(),1},wifi_info:()=>JSON.stringify(l()?{connected:e().online(t()),ip:t().ip,ssid:t().ssid,rssi:t().rssi,mac:e().macString(t()),router:e().opts.router}:{connected:!1}),wifi_scan:()=>JSON.stringify(l()?e().scan():[])}}var Cc=se(Tc(),1),Yb=["RPi/__init__.py","RPi/GPIO.py","gpiozero.py","board.py","adafruit_dht.py","signal.py","smbus2.py","smbus.py","serial.py","flask.py","http/__init__.py","http/server.py","paho/__init__.py","paho/mqtt/__init__.py","paho/mqtt/client.py","paho/mqtt/publish.py","paho/mqtt/subscribe.py","psutil.py","threading.py","adafruit_ssd1306.py","busio.py","spidev.py","RPLCD/__init__.py","RPLCD/i2c.py"],Kb=["machine.py","rp2.py","network.py","dht.py","urequests.py","umqtt/__init__.py","umqtt/simple.py","ntptime.py","pico_i2c_lcd.py","lcd_api.py"],ir=null;function Zb(r){return ir||(ir=(async()=>{let e=r?await r():await(await fetch((0,Cc.asset)("micropython.wasm"))).arrayBuffer();return WebAssembly.compile(e)})(),ir.catch(()=>{ir=null})),ir}function eO(r,e){let t=i=>i==="LED"?Pc.PICO_W_LED:i;return{board:()=>r.board,setup:(i,s,n)=>r.setup(t(i),s,n),set_pull:(i,s)=>r.setPull(t(i),s),write:(i,s)=>r.write(t(i),s),read:i=>r.read(t(i)),level:i=>r.level(t(i)),duty:i=>r.duty(t(i)),pwm:(i,s,n)=>r.pwm(t(i),s,n),pwm_off:i=>r.pwmOff(t(i)),blink:(i,s,n,o,l,a,h,c)=>r.blink(t(i),s,n,o,l,a,h,c),stop_bg:i=>r.stopBg(t(i)),watch:(i,s,n)=>r.watch(t(i),s,n),watch_cb:(i,s)=>r.watchCb(t(i),s),unwatch:i=>r.unwatch(t(i)),detected:i=>r.detected(t(i)),release:i=>r.release(t(i)),in_use:i=>(r.pins.get(t(i))||{}).used?1:0,claim:(i,s)=>{let n=r.pins.get(t(i));n&&(n.owner=s)},timer:(i,s,n)=>r.timer(i,s,n),timer_stop:i=>r.timerStop(i),next_event:()=>r.nextEvent(),event_arg:()=>r.evArg,adc:i=>r.adc(i),mcp3008:i=>r.mcp3008(i),light:i=>r.light(i),distance:i=>r.distance(i),dht:(i,s)=>r.dht(i,s),neo:(i,s,n)=>r.neoWrite(t(i),s,n),bootsel:()=>r.bootsel,cpu_temp:()=>r.cpuTemp(),wifi:(i,s)=>{r.wifiState={state:i,ssid:s},r.changed()},uart_write:(i,s)=>{!r.uartWrite(i,s)&&!r.uartWired(i)&&e.write(s)},uart_wired:i=>r.uartWired(i),uart_any:i=>r.uartAny(i),uart_read:(i,s)=>r.uartRead(i,s),uart_readline:(i,s)=>r.uartReadLine(i,s),uart_has_line:i=>r.uartHasLine(i)?1:0,i2c_has:i=>r.i2cHas(i),i2c_scan:()=>r.i2cScan(),i2c_write:(i,s)=>r.i2cWrite(i,s),i2c_read:(i,s)=>r.i2cRead(i,s),spi_xfer:(i,s,n)=>r.spiXfer(i,s,n),disp_tm1637:(i,s,n,o,l)=>r.dispTm1637(i,s,n,o,l),...xc(r)}}var tO=r=>`
import _rpi_boot as __rb
__rb.start()
try:
    exec(compile(open(${JSON.stringify(r)}).read(), ${JSON.stringify(r)}, 'exec'))
except BaseException as __e:
    __rb.report(__e)
del __rb
`,iO=(r,e)=>`
import _rpi_boot as __rb
__rb.start()
try:
    exec(compile(${JSON.stringify(r)}, ${JSON.stringify(e)}, 'exec'))
except BaseException as __e:
    __rb.report(__e)
del __rb
`,sO=r=>`
import _rpi_boot as __rb
try:
    exec(compile(${JSON.stringify(r)}, '<stdin>', 'single'))
except BaseException as __e:
    __rb.report(__e, True)
del __rb
`,rO=`
import sys, io
_status = [0]
def start():
    _status[0] = 0
def report(e, keep=False):
    if isinstance(e, SystemExit):
        code = e.value if hasattr(e, 'value') else (e.args[0] if e.args else None)
        if code not in (None, 0):
            if not isinstance(code, int):
                print(code, file=sys.stderr)
            _status[0] = 1
        return
    _status[0] = 2 if isinstance(e, KeyboardInterrupt) else 1
    s = io.StringIO()
    sys.print_exception(e, s)
    lines = s.getvalue().split('\\n')
    out = lines if keep else [l for l in lines if '"<stdin>"' not in l]
    sys.stderr.write('\\n'.join(out))
def status():
    return _status[0]
`,sn=class{constructor({gpio:e,libs:t,out:i,readLine:s,files:n,cwd:o="/home/pi",banner:l,wasmLoader:a,heap:h=6<<20}){this.gpio=e,this.libs=t||{},this.out=i||(()=>{}),this.readLine=s||(async()=>""),this.files=n||{},this.cwd=o,this.banner=l,this.wasmLoader=a,this.heap=h,this.dead=!1,this.busy=!1,this.queue=Promise.resolve(),this.pendingRead=null,this.outBuf="",this.errBuf=""}async start(){let e=await Zb(this.wasmLoader),t=new TextDecoder,i=new TextDecoder,s={instantiateWasm:(a,h)=>(WebAssembly.instantiate(e,a).then(c=>h(c,e)),{}),locateFile:a=>a,print:()=>{},printErr:()=>{}};this.mp=await _l({heapsize:this.heap,pystack:4096,linebuffer:!1,stdout:a=>this.emit(t.decode(a,{stream:!0}),"out"),stderr:a=>this.emit(i.decode(a,{stream:!0}),"err"),module:s});let n=this.mp._module;this.M=n,n.raptiPending=()=>this.dead?0:this.gpio.pending(),n.raptiShouldYield=()=>this.gpio.shouldYield(),n.raptiReadLine=a=>(this.flush(),new Promise(h=>{this.pendingRead=h,Promise.resolve(this.readLine(a)).then(c=>{this.pendingRead===h&&(this.pendingRead=null,h(c))})})),this.mp.registerJsModule("_rpi_js",eO(this.gpio,this));let o=this.mp.FS,l=this.gpio.isPico;o.mkdirTree("/rlib/RPi");for(let[a,h]of Object.entries(this.libs)){if(l&&Yb.includes(a)||!l&&Kb.includes(a))continue;let c=a.lastIndexOf("/");if(c>0)try{o.mkdirTree("/rlib/"+a.slice(0,c))}catch{}o.writeFile("/rlib/"+a,h)}o.writeFile("/rlib/_rpi_boot.py",rO),this.writeFiles(this.files);try{o.mkdirTree(this.cwd)}catch{}return await this.exec(`import sys, os, builtins, _rapti
sys.path.append('/rlib')
os.chdir(${JSON.stringify(this.cwd)})
builtins.input = _rapti.input
import _rpi_hw
`),this.idleT=setInterval(()=>{!this.dead&&!this.busy&&this.gpio.pending()&&this.exec("_rpi_hw._dispatch(0)")},15),this}writeFiles(e){let t=this.mp.FS;for(let[i,s]of Object.entries(e)){let n=i.slice(0,i.lastIndexOf("/"));if(n)try{t.mkdirTree(n)}catch{}try{t.writeFile(i,s)}catch{}}}readFiles(e){let t=this.mp.FS,i={},s=n=>{let o=[];try{o=t.readdir(n)}catch{return}for(let l of o){if(l==="."||l==="..")continue;let a=(n==="/"?"":n)+"/"+l,h;try{h=t.stat(a)}catch{continue}if(t.isDir(h.mode))a!=="/rlib"&&a!=="/proc"&&a!=="/dev"&&a!=="/tmp"&&s(a);else try{i[a]=t.readFile(a,{encoding:"utf8"})}catch{}}};return s(e),i}emit(e,t){e&&(t==="err"?(this.flushOut(),this.errBuf+=e):(this.flushErr(),this.outBuf+=e),this.flushT||(this.flushT=setTimeout(()=>this.flush(),16)))}flushOut(){if(!this.outBuf)return;let e=this.outBuf;this.outBuf="",this.banner&&e.includes("Raspberry Pi with RaptiAuto")&&(e=e.replace(/MicroPython v[\d.]+[^\n]*Raspberry Pi with RaptiAuto/,this.banner)),this.out(e,"out")}flushErr(){if(this.errBuf){let e=this.errBuf;this.errBuf="",this.out(e,"err")}}flush(){clearTimeout(this.flushT),this.flushT=0,this.flushOut(),this.flushErr()}write(e){this.emit(String(e),"out")}exec(e){let t=async()=>{if(this.dead)return;let i=this.M,s=i.lengthBytesUTF8(e),n=i._malloc(s+1);i.stringToUTF8(e,n,s+1);let o=i._malloc(12);this.busy=!0,this.gpio.busy=!0;try{await i.ccall("mp_js_do_exec","null",["pointer","number","pointer"],[n,s,o],{async:!0})}finally{this.busy=!1,this.gpio.busy=!1,this.dead||(i._free(n),i._free(o)),this.flush()}};return this.queue=this.queue.then(t,t),this.queue}async runFile(e){return await this.exec(tO(e)),this.status()}async runSource(e,t="<stdin>"){return await this.exec(iO(e,t)),this.status()}async status(){if(this.dead)return 2;try{return this.mp.pyimport("_rpi_boot").status()}catch{return 1}}async replExec(e){this.repl=!0,await this.exec(sO(e))}interrupt(){if(!this.dead){if(this.pendingRead){let e=this.pendingRead;this.pendingRead=null,this.M._mp_sched_keyboard_interrupt(),e("");return}this.busy&&this.M._mp_sched_keyboard_interrupt()}}async stop(e=1200){this.dead||this.busy&&(this.interrupt(),await Promise.race([this.queue.then(()=>!0,()=>!0),new Promise(i=>setTimeout(()=>i(!1),e))])||this.kill())}kill(){if(!this.dead){if(this.flush(),this.dead=!0,clearInterval(this.idleT),this.M&&(this.M.raptiDead=!0),this.pendingRead){let e=this.pendingRead;this.pendingRead=null,e("")}this.mp=null,this.M=null}}};function ue(r,e="/",t="/home/pi"){if(!r)return e;(r==="~"||r.startsWith("~/"))&&(r=t+r.slice(1)),r.startsWith("/")||(r=(e==="/"?"":e)+"/"+r);let i=[];for(let s of r.split("/"))!s||s==="."||(s===".."?i.pop():i.push(s));return"/"+i.join("/")}var Nt=r=>r.lastIndexOf("/")<=0?"/":r.slice(0,r.lastIndexOf("/")),Ae=r=>r.slice(r.lastIndexOf("/")+1),sr=class{constructor(e,t){this.key=e,this.listeners=new Set,this.load(t)}load(e){let t=null;try{t=JSON.parse(localStorage.getItem(this.key)||"null")}catch{t=null}if((!t||!t.files)&&(t={files:{},dirs:[]}),this.files=new Map(Object.entries(t.files)),this.dirs=new Set(t.dirs||[]),this.dirs.add("/"),!t.seeded&&e){for(let i of e.dirs||[])this.mkdir(i,!0,!1);for(let[i,s]of Object.entries(e.files||{}))this.files.has(i)||this.write(i,s,!1);this.seeded=!0,this.save()}else this.seeded=!!t.seeded}save(){let e={};for(let[t,i]of this.files)e[t]=i;try{localStorage.setItem(this.key,JSON.stringify({files:e,dirs:[...this.dirs],seeded:this.seeded||!1}))}catch{}for(let t of this.listeners)t()}on(e){return this.listeners.add(e),()=>this.listeners.delete(e)}exists(e){return this.dirs.has(e)||this.files.has(e)}isDir(e){return this.dirs.has(e)}isFile(e){return this.files.has(e)}read(e){let t=this.files.get(e);if(!t)throw new Error(`${e}: No such file or directory`);return t.text}stat(e){if(this.dirs.has(e))return{dir:!0,size:4096,mtime:0};let t=this.files.get(e);return t?{dir:!1,size:new TextEncoder().encode(t.text).length,mtime:t.mtime||0,x:!!t.x}:null}write(e,t,i=!0){if(this.dirs.has(e))throw new Error(`${e}: Is a directory`);let s=Nt(e);this.dirs.has(s)||this.mkdir(s,!0,!1);let n=this.files.get(e);this.files.set(e,{text:String(t),mtime:Date.now(),x:n?n.x:!1}),i&&this.save()}chmodX(e,t){let i=this.files.get(e);i&&(i.x=t,this.save())}mkdir(e,t=!1,i=!0){if(this.files.has(e))throw new Error(`cannot create directory '${e}': File exists`);let s=e.split("/").filter(Boolean),n="";for(let o=0;o<s.length;o++)if(n+="/"+s[o],!this.dirs.has(n)){if(!t&&o<s.length-1)throw new Error(`cannot create directory '${e}': No such file or directory`);this.dirs.add(n)}i&&this.save()}list(e){if(!this.dirs.has(e))throw new Error(`cannot access '${e}': No such file or directory`);let t=e==="/"?"/":e+"/",i=new Set;for(let s of this.dirs)s!==e&&s.startsWith(t)&&!s.slice(t.length).includes("/")&&i.add(s.slice(t.length));for(let s of this.files.keys())s.startsWith(t)&&!s.slice(t.length).includes("/")&&i.add(s.slice(t.length));return[...i].sort((s,n)=>s.localeCompare(n))}remove(e,t=!1){if(this.files.has(e)){this.files.delete(e),this.save();return}if(!this.dirs.has(e))throw new Error(`cannot remove '${e}': No such file or directory`);if(e==="/")throw new Error("it is dangerous to operate recursively on '/'");let i=e+"/";if(([...this.files.keys()].some(n=>n.startsWith(i))||[...this.dirs].some(n=>n.startsWith(i)))&&!t)throw new Error(`cannot remove '${e}': Is a directory`);for(let n of[...this.files.keys()])n.startsWith(i)&&this.files.delete(n);for(let n of[...this.dirs])(n===e||n.startsWith(i))&&this.dirs.delete(n);this.save()}copy(e,t){if(this.dirs.has(t)&&(t=(t==="/"?"":t)+"/"+Ae(e)),this.files.has(e))return this.write(t,this.files.get(e).text),t;if(!this.dirs.has(e))throw new Error(`cannot stat '${e}': No such file or directory`);let i=e+"/";this.mkdir(t,!0,!1);for(let s of[...this.dirs])s.startsWith(i)&&this.dirs.add(t+s.slice(e.length));for(let[s,n]of[...this.files])s.startsWith(i)&&this.files.set(t+s.slice(e.length),{...n});return this.save(),t}move(e,t){return this.dirs.has(t)&&(t=(t==="/"?"":t)+"/"+Ae(e)),e===t||(this.copy(e,t),this.remove(e,!0)),t}snapshot(e="/"){let t={},i=e==="/"?"/":e+"/";for(let[s,n]of this.files)(s.startsWith(i)||s===e)&&(t[s]=n.text);return t}merge(e,t="/"){let i=!1,s=t==="/"?"/":t+"/";for(let[n,o]of Object.entries(e)){if(!(n.startsWith(s)||n===t))continue;let l=this.files.get(n);(!l||l.text!==o)&&(this.write(n,o,!1),i=!0)}return i&&this.save(),i}};var rr=se($i(),1),on=se(rn(),1);var nO=se(ii(),1),oO=se(Qi(),1),Rc=se($i(),1);var lO={led:{name:"LED",desc:"LED + 330 \u03A9 resistor to GND",pins:[{key:"a",label:"Anode +"}],props:{color:"red"},ic:"bulb"},rgb:{name:"RGB LED",desc:"Common cathode, 3 resistors",pins:[{key:"r",label:"R"},{key:"g",label:"G"},{key:"b",label:"B"}],props:{},ic:"palette"},button:{name:"Push button",desc:"Between the pin and GND (use the pull-up)",pins:[{key:"a",label:"Pin"}],props:{to:"gnd"},ic:"button"},switch:{name:"Toggle switch",desc:"Latching switch to GND",pins:[{key:"a",label:"Pin"}],props:{to:"gnd"},ic:"sliders"},buzzer:{name:"Buzzer",desc:"Active buzzer (beeps when HIGH; PWM sets the tone)",pins:[{key:"a",label:"+"}],props:{},ic:"bell"},relay:{name:"Relay module",desc:"5 V relay board, IN active HIGH, switches a 230 V lamp",pins:[{key:"a",label:"IN"}],props:{},ic:"plug"},servo:{name:"Servo SG90",desc:"50 Hz PWM, 0.5\u20132.5 ms = 0\u2013180\xB0",pins:[{key:"sig",label:"Signal"}],props:{},ic:"rotate"},motor:{name:"DC motor (L298N)",desc:"IN1 = forward, IN2 = backward, PWM = speed",pins:[{key:"fwd",label:"IN1"},{key:"back",label:"IN2"}],props:{},ic:"motor"},pir:{name:"PIR motion sensor",desc:"HC-SR501, OUT goes HIGH for 3 s",pins:[{key:"out",label:"OUT"}],props:{},ic:"sensor"},ultrasonic:{name:"HC-SR04 ultrasonic",desc:"2\u2013400 cm, echo via voltage divider",pins:[{key:"trig",label:"TRIG"},{key:"echo",label:"ECHO"}],props:{cm:50},ic:"activity"},pot:{name:"Potentiometer",desc:"10 k\u03A9; Pico: on an ADC pin \xB7 Pi: MCP3008 channel",pins:[{key:"a",label:"Wiper",adc:!0}],props:{value:.5,ch:0},ic:"gauge"},ldr:{name:"Light sensor (LDR)",desc:"Pico: analog on an ADC pin \xB7 Pi: module DO pin",pins:[{key:"a",label:"OUT",adc:!0}],props:{light:.6,ch:1},ic:"sun"},dht:{name:"DHT22 sensor",desc:"Temperature and humidity, one data pin",pins:[{key:"data",label:"DATA"}],props:{t:28,h:60},ic:"thermometer"},neopixel:{name:"NeoPixel strip \xD78",desc:"WS2812B, data in",pins:[{key:"din",label:"DIN"}],props:{n:8},ic:"sparkles"}};var aO=0;function si(r,e,t={}){let i=lO[r];return{id:"p"+Date.now().toString(36)+aO++,type:r,pins:{...e},props:{...i.props,...t},state:{}}}var Qc=se(Dc(),1),Nc=()=>({dirs:["/home/pi/Desktop","/home/pi/Documents","/home/pi/Downloads","/home/pi/Music","/home/pi/Pictures","/home/pi/Videos","/home/pi/Public","/home/pi/Templates","/home/pi/projects","/etc","/boot/firmware","/tmp","/usr/bin","/var/log"],files:{...Object.fromEntries(on.PI_EXAMPLES.map(r=>["/home/pi/"+r.file,r.code])),"/home/pi/Documents/notes.txt":`Raspberry Pi notes
==================
- GPIO pins are 3.3 V. Never connect 5 V to a GPIO!
- Use a resistor (220\u2013330 \u03A9) with every LED.
- Run "pinout" in the terminal to see the header.
`,"/home/pi/.bashrc":`# ~/.bashrc: executed by bash(1) for non-login shells.
alias ll='ls -l'
export PATH="$HOME/.local/bin:$PATH"
`,"/etc/os-release":`PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"
NAME="Debian GNU/Linux"
VERSION_ID="12"
VERSION="12 (bookworm)"
VERSION_CODENAME=bookworm
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
`,"/etc/hostname":`raspberrypi
`,"/boot/firmware/config.txt":`# For more options and information see
# http://rptl.io/configtxt

# Uncomment some or all of these to enable the optional hardware interfaces
#dtparam=i2c_arm=on
#dtparam=i2s=on
#dtparam=spi=on

# Enable audio (loads snd_bcm2835)
dtparam=audio=on

# Automatically load overlays for detected cameras
camera_auto_detect=1

# Automatically load overlays for detected DSI displays
display_auto_detect=1

# Enable DRM VC4 V3D driver
dtoverlay=vc4-kms-v3d
max_framebuffers=2

arm_64bit=1
arm_boost=1

[all]
`}}),Ic=()=>({dirs:["/lib"],files:Object.fromEntries(on.PICO_EXAMPLES.filter(r=>!r.boards).map(r=>["/"+r.file,r.code]))}),nn=class{constructor(e,t){this.libs=t,this.listeners=new Set,this.outTaps=new Set,this.proc=null,this.owner=null,this.gpio=new Lc.GpioSim(e),this.net=new Qc.VirtualNet,this.piFs=new sr("rapti.pi.fs.v1",Nc()),this.picoFs=new sr("rapti.pico.fs.v1",Ic()),this.setBoard(e,!0)}get board(){return this.gpio.board}get info(){return rr.BOARDS[this.board]}get isPico(){return this.gpio.isPico}get fs(){return this.isPico?this.picoFs:this.piFs}get home(){return this.isPico?"/":"/home/pi"}on(e){return this.listeners.add(e),()=>this.listeners.delete(e)}onOut(e){return this.outTaps.add(e),()=>this.outTaps.delete(e)}emit(e){for(let t of this.listeners)try{t(e,this)}catch(i){console.error(i)}}setBoard(e,t=!1){t||this.killProcess(),this.gpio.setBoard(e),this.initNet(e),this.gpio.parts=this.loadParts(e),this.gpio.inputsChanged();try{localStorage.setItem("rapti.pi.board",e)}catch{}t||this.emit("board")}initNet(e){let t=rr.BOARDS[e],i=t.kind==="pi";this.netDev&&(this.net.dropServers(this.netDev),this.net.mqtt.dropDevice(this.netDev),this.net.leave(this.netDev),this.net.devices.delete(this.netDev.id)),this.netDev=this.net.registerDevice({id:"pi",name:i?"Raspberry Pi":t.name,kind:i?"pi":"pico",hostname:i?"raspberrypi":"picow",broker:i});let s=i||t.wifi;this.gpio.net=s?this.net:null,this.gpio.netDev=s?this.netDev:null,i&&this.net.join(this.netDev,"RaptiNet","rapti1234")}partsKey(e=this.board){return"rapti.pi.parts."+(rr.BOARDS[e].kind==="pico"?"pico":"pi")}loadParts(e){try{let t=JSON.parse(localStorage.getItem(this.partsKey(e))||"null");if(Array.isArray(t))return t.map(i=>({...i,state:{}}))}catch{}return rr.BOARDS[e].kind==="pico"?[si("led",{a:15},{color:"red"}),si("button",{a:14}),si("pot",{a:26})]:[si("led",{a:17},{color:"red"}),si("led",{a:27},{color:"green"}),si("button",{a:2}),si("buzzer",{a:22})]}saveParts(){let e=this.gpio.parts.map(({id:t,type:i,pins:s,props:n})=>({id:t,type:i,pins:s,props:n}));try{localStorage.setItem(this.partsKey(),JSON.stringify(e))}catch{}this.emit("parts")}wireExample(e){return!e.parts||!e.parts.length?!1:(this.gpio.parts=e.parts.map(t=>si(t.type,t.pins,t.props||{})),this.gpio.inputsChanged(),this.saveParts(),!0)}resetFs(){this.killProcess();let e=this.fs;try{localStorage.removeItem(e.key)}catch{}e.load(this.isPico?Ic():Nc()),this.emit("files")}get running(){return!!(this.proc&&!this.proc.dead&&this.proc.busy)}async spawn(e){this.killProcess();let t=new sn({gpio:this.gpio,libs:this.libs,files:this.fs.snapshot(this.isPico?"/":"/home/pi"),cwd:e.cwd||this.home,banner:e.banner,readLine:e.readLine,out:(i,s)=>{e.out&&e.out(i,s);for(let n of this.outTaps)n(i,s)}});return this.proc=t,this.owner=e.owner||null,await t.start(),this.emit("proc"),this.emit("start"),t}syncBack(e=this.proc){if(!(!e||e.dead||!e.mp))try{this.fs.merge(e.readFiles(this.isPico?"/":"/home/pi"),this.isPico?"/":"/home/pi")}catch{}}killProcess(){let e=this.proc;e&&(this.syncBack(e),e.kill(),this.proc=null,this.owner=null,this.netDev&&(this.net.dropServers(this.netDev),this.net.mqtt.dropDevice(this.netDev)),this.gpio.stopProcess(),this.isPico&&this.gpio.reset(),this.emit("proc"))}async stop(){let e=this.proc;e&&(await e.stop(),this.emit("proc"))}};var qc=`# RaptiAuto virtual hardware core: callbacks (edges, timers) and pin bookkeeping.
# The simulated GPIO lives in JavaScript (module _rpi_js); this file runs callbacks
# that JavaScript queues while Python sleeps or loops.
import _rpi_js as J
import _rapti

_cbs = {}
_next = [1]


def register(cb):
    i = _next[0]
    _next[0] += 1
    _cbs[i] = cb
    return i


def unregister(i):
    if i in _cbs:
        del _cbs[i]


def call(cb, *args):
    # gpiozero style: call with no argument, or with the device if the function wants one
    try:
        return cb()
    except TypeError as e:
        if args and 'argument' in str(e):
            return cb(*args)
        raise


def _dispatch(_):
    while True:
        cid = J.next_event()
        if not cid:
            break
        cb = _cbs.get(cid)
        if cb is not None:
            cb(J.event_arg())


_rapti.set_dispatch(_dispatch)


def board():
    return J.board()


def every(ms, fn):
    """Call fn() every ms milliseconds (in the background). Returns a handle for stop()."""
    cid = register(lambda _: fn())
    return (J.timer(cid, ms, 1), cid)


def stop(handle):
    if handle:
        J.timer_stop(handle[0])
        unregister(handle[1])
`;var Bc=`# time: MicroPython's built-in time plus the CPython functions Raspberry Pi scripts often use.
from utime import *
import utime as _t

_MON = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')
_MONL = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
_DAY = ('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')
_DAYL = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')


def perf_counter():
    return _t.ticks_us() / 1000000


def monotonic():
    return _t.ticks_ms() / 1000


def process_time():
    return _t.ticks_ms() / 1000


def perf_counter_ns():
    return _t.ticks_us() * 1000


def monotonic_ns():
    return _t.ticks_ms() * 1000000


def _tm(t):
    if t is None:
        return _t.localtime()
    if isinstance(t, (int, float)):
        return _t.localtime(int(t))
    return t


def strftime(fmt, t=None):
    t = _tm(t)
    y, mo, d, hh, mm, ss, wd, yd = t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7]
    rep = {
        'Y': '%04d' % y, 'y': '%02d' % (y % 100), 'm': '%02d' % mo, 'd': '%02d' % d, 'e': '%2d' % d,
        'H': '%02d' % hh, 'I': '%02d' % ((hh % 12) or 12), 'M': '%02d' % mm, 'S': '%02d' % ss,
        'p': 'AM' if hh < 12 else 'PM', 'b': _MON[mo - 1], 'B': _MONL[mo - 1], 'a': _DAY[wd], 'A': _DAYL[wd],
        'j': '%03d' % yd, 'w': str((wd + 1) % 7), '%': '%',
    }
    rep['c'] = '%s %s %s %s:%s:%s %s' % (rep['a'], rep['b'], rep['e'], rep['H'], rep['M'], rep['S'], rep['Y'])
    rep['x'] = '%s/%s/%s' % (rep['m'], rep['d'], rep['y'])
    rep['X'] = '%s:%s:%s' % (rep['H'], rep['M'], rep['S'])
    rep['T'] = rep['X']
    rep['D'] = rep['x']
    out = []
    i = 0
    while i < len(fmt):
        c = fmt[i]
        if c == '%' and i + 1 < len(fmt):
            out.append(rep.get(fmt[i + 1], '%' + fmt[i + 1]))
            i += 2
        else:
            out.append(c)
            i += 1
    return ''.join(out)


def asctime(t=None):
    return strftime('%a %b %e %H:%M:%S %Y', t)


def ctime(secs=None):
    return asctime(_tm(secs))


struct_time = tuple
`;var $c=`# random: MicroPython's built-in random plus shuffle / sample.
from urandom import *
import urandom as _r


def shuffle(x):
    for i in range(len(x) - 1, 0, -1):
        j = _r.randrange(i + 1)
        x[i], x[j] = x[j], x[i]


def sample(population, k):
    pool = list(population)
    if k > len(pool):
        raise ValueError('Sample larger than population or is negative')
    shuffle(pool)
    return pool[:k]


def choices(population, weights=None, k=1):
    pool = list(population)
    if not weights:
        return [_r.choice(pool) for _ in range(k)]
    total = sum(weights)
    out = []
    for _ in range(k):
        r = _r.random() * total
        acc = 0
        for p, w in zip(pool, weights):
            acc += w
            if r < acc:
                out.append(p)
                break
        else:
            out.append(pool[-1])
    return out
`;var Fc=`# signal.pause() keeps a gpiozero script alive while callbacks and blinking run.
import time

SIGINT = 2
SIGTERM = 15


def pause():
    while True:
        time.sleep(1)


def signal(sig, handler):
    return None
`;var Wc="";var zc=`# RPi.GPIO for the RaptiAuto virtual Raspberry Pi (same API as RPi.GPIO 0.7).
import _rpi_js as J
import _rpi_hw as H
import time as _time

BOARD = 10
BCM = 11
OUT = 0
IN = 1
LOW = 0
HIGH = 1
PUD_OFF = 20
PUD_DOWN = 21
PUD_UP = 22
RISING = 31
FALLING = 32
BOTH = 33
SERIAL = 40
SPI = 41
I2C = 42
HARD_PWM = 43
UNKNOWN = -1
VERSION = '0.7.1'
RPI_REVISION = 3
RPI_INFO = {'P1_REVISION': 3, 'RAM': '8G', 'REVISION': 'd04170', 'TYPE': 'Pi 5 Model B', 'PROCESSOR': 'BCM2712', 'MANUFACTURER': 'Raspberry Pi Ltd'}

_BOARD = {3: 2, 5: 3, 7: 4, 8: 14, 10: 15, 11: 17, 12: 18, 13: 27, 15: 22, 16: 23, 18: 24, 19: 10, 21: 9, 22: 25,
          23: 11, 24: 8, 26: 7, 27: 0, 28: 1, 29: 5, 31: 6, 32: 12, 33: 13, 35: 19, 36: 16, 37: 26, 38: 20, 40: 21}
_mode = None
_warn = True
_setup = {}     # bcm -> IN / OUT
_events = {}    # bcm -> [callback ids]
_pwm = {}

if J.board() == 'pi4':
    RPI_INFO = {'P1_REVISION': 3, 'RAM': '4G', 'REVISION': 'c03115', 'TYPE': 'Pi 4 Model B', 'PROCESSOR': 'BCM2711', 'MANUFACTURER': 'Sony'}


def _warning(msg):
    if _warn:
        print('<stdin>: RuntimeWarning: ' + msg)


def setwarnings(flag):
    global _warn
    _warn = bool(flag)


def setmode(mode):
    global _mode
    if mode not in (BOARD, BCM):
        raise ValueError('An invalid mode was passed to setmode()')
    if _mode is not None and mode != _mode:
        raise ValueError('A different mode has already been set!')
    _mode = mode


def getmode():
    return _mode


def _bcm(channel):
    if _mode is None:
        raise RuntimeError('Please set pin numbering mode using GPIO.setmode(GPIO.BOARD) or GPIO.setmode(GPIO.BCM)')
    if not isinstance(channel, int):
        raise ValueError('Channel must be an integer or list/tuple of integers')
    if _mode == BOARD:
        if channel not in _BOARD:
            raise ValueError('The channel sent is invalid on a Raspberry Pi')
        return _BOARD[channel]
    if channel < 0 or channel > 27:
        raise ValueError('The channel sent is invalid on a Raspberry Pi')
    return channel


def _each(channel):
    if isinstance(channel, (list, tuple)):
        return list(channel)
    return [channel]


def setup(channel, direction, pull_up_down=PUD_OFF, initial=-1):
    for ch in _each(channel):
        b = _bcm(ch)
        if direction not in (IN, OUT):
            raise ValueError('An invalid direction was passed to setup()')
        if b in _setup or J.in_use(b):
            _warning('This channel is already in use, continuing anyway.  Use GPIO.setwarnings(False) to disable warnings.')
        if direction == OUT:
            if pull_up_down != PUD_OFF:
                raise ValueError('pull_up_down parameter is not valid for outputs')
            J.setup(b, 'out', 'none')
            if initial != -1:
                J.write(b, 1 if initial else 0)
        else:
            if initial != -1:
                raise ValueError('initial parameter is not valid for inputs')
            pull = 'up' if pull_up_down == PUD_UP else ('down' if pull_up_down == PUD_DOWN else 'none')
            J.setup(b, 'in', pull)
        _setup[b] = direction


def output(channel, value):
    chans = _each(channel)
    vals = _each(value)
    if len(vals) == 1:
        vals = vals * len(chans)
    if len(vals) != len(chans):
        raise RuntimeError('Number of channels != number of values')
    for ch, v in zip(chans, vals):
        b = _bcm(ch)
        if _setup.get(b) != OUT:
            raise RuntimeError('The GPIO channel has not been set up as an OUTPUT')
        J.write(b, 1 if v else 0)


def input(channel):
    b = _bcm(channel)
    if b not in _setup:
        raise RuntimeError('You must setup() the GPIO channel first')
    return J.read(b)


def gpio_function(channel):
    b = _bcm(channel)
    return _setup.get(b, IN)


def cleanup(channel=None):
    global _mode
    chans = list(_setup.keys()) if channel is None else [_bcm(c) for c in _each(channel)]
    for b in chans:
        remove_event_detect_bcm(b)
        if b in _pwm:
            _pwm[b].stop()
        J.release(b)
        if b in _setup:
            del _setup[b]
    if channel is None:
        _mode = None


def _edge(edge):
    if edge == RISING:
        return 'rising'
    if edge == FALLING:
        return 'falling'
    if edge == BOTH:
        return 'both'
    raise ValueError('The edge must be set to RISING, FALLING or BOTH')


def add_event_detect(channel, edge, callback=None, bouncetime=None):
    b = _bcm(channel)
    if _setup.get(b) != IN:
        raise RuntimeError('You must setup() the GPIO channel as an input first')
    if b in _events:
        raise RuntimeError('Conflicting edge detection already enabled for this GPIO channel')
    _events[b] = []
    J.watch(b, _edge(edge), int(bouncetime or 0))
    if callback is not None:
        add_event_callback(channel, callback)


def add_event_callback(channel, callback):
    b = _bcm(channel)
    if b not in _events:
        raise RuntimeError('Add event detection using add_event_detect first before adding a callback')
    cid = H.register(lambda _arg, ch=channel, cb=callback: cb(ch))
    _events[b].append(cid)
    J.watch_cb(b, cid)


def remove_event_detect_bcm(b):
    if b in _events:
        for cid in _events[b]:
            H.unregister(cid)
        del _events[b]
        J.unwatch(b)


def remove_event_detect(channel):
    remove_event_detect_bcm(_bcm(channel))


def event_detected(channel):
    return bool(J.detected(_bcm(channel)))


def wait_for_edge(channel, edge, bouncetime=None, timeout=None):
    b = _bcm(channel)
    if _setup.get(b) != IN:
        raise RuntimeError('You must setup() the GPIO channel as an input first')
    e = _edge(edge)
    t0 = _time.ticks_ms()
    last = J.read(b)
    while True:
        v = J.read(b)
        if v != last:
            if e == 'both' or (e == 'rising' and v) or (e == 'falling' and not v):
                if bouncetime:
                    _time.sleep_ms(int(bouncetime))
                return channel
            last = v
        if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout:
            return None
        _time.sleep_ms(1)


class PWM:
    def __init__(self, channel, frequency):
        b = _bcm(channel)
        if _setup.get(b) != OUT:
            raise RuntimeError('You must setup() the GPIO channel as an output first')
        if b in _pwm:
            raise RuntimeError('A PWM object already exists for this GPIO channel')
        if frequency <= 0:
            raise ValueError('frequency must be greater than 0.0')
        self._b = b
        self._f = float(frequency)
        self._dc = 0.0
        self._on = False
        _pwm[b] = self

    def start(self, dutycycle):
        if not 0 <= dutycycle <= 100:
            raise ValueError('dutycycle must have a value from 0.0 to 100.0')
        self._dc = float(dutycycle)
        self._on = True
        J.pwm(self._b, self._f, self._dc / 100)

    def ChangeDutyCycle(self, dutycycle):
        if not 0 <= dutycycle <= 100:
            raise ValueError('dutycycle must have a value from 0.0 to 100.0')
        self._dc = float(dutycycle)
        if self._on:
            J.pwm(self._b, self._f, self._dc / 100)

    def ChangeFrequency(self, frequency):
        if frequency <= 0:
            raise ValueError('frequency must be greater than 0.0')
        self._f = float(frequency)
        if self._on:
            J.pwm(self._b, self._f, self._dc / 100)

    def stop(self):
        if self._on:
            J.pwm_off(self._b)
        self._on = False
        if _pwm.get(self._b) is self:
            del _pwm[self._b]
`;var jc=`# gpiozero for the RaptiAuto virtual Raspberry Pi: the commonly used devices with the
# same names and behaviour as gpiozero 2.0 (pins are BCM numbers, "GPIO17", "BOARD11" ...).
import _rpi_js as J
import _rpi_hw as H
import time as _time

__version__ = '2.0.1'

_BOARD = {3: 2, 5: 3, 7: 4, 8: 14, 10: 15, 11: 17, 12: 18, 13: 27, 15: 22, 16: 23, 18: 24, 19: 10, 21: 9, 22: 25,
          23: 11, 24: 8, 26: 7, 27: 0, 28: 1, 29: 5, 31: 6, 32: 12, 33: 13, 35: 19, 36: 16, 37: 26, 38: 20, 40: 21}
_used = {}


class GPIOZeroError(Exception):
    pass


class DeviceClosed(GPIOZeroError):
    pass


class BadPinFactory(GPIOZeroError):
    pass


class PinInvalidPin(GPIOZeroError):
    pass


class GPIOPinInUse(GPIOZeroError):
    pass


class PinFixedPull(GPIOZeroError):
    pass


def _pin(p):
    if isinstance(p, str):
        s = p.upper().strip()
        for pre in ('GPIO', 'BCM'):
            if s.startswith(pre):
                s = s[len(pre):]
                break
        else:
            for pre in ('BOARD', 'J8:', 'P1:'):
                if s.startswith(pre):
                    n = int(s[len(pre):])
                    if n not in _BOARD:
                        raise PinInvalidPin('%s is not a valid pin' % p)
                    return _BOARD[n]
        try:
            p = int(s)
        except ValueError:
            raise PinInvalidPin('%s is not a valid pin name' % p)
    if not isinstance(p, int) or p < 0 or p > 27:
        raise PinInvalidPin('%r is not a valid pin' % (p,))
    return p


class Device:
    def __init__(self):
        self._closed = False
        self._pins = []
        self._handles = []

    def _claim(self, *pins):
        out = []
        for p in pins:
            b = _pin(p)
            if b in _used and _used[b] is not self:
                raise GPIOPinInUse('pin GPIO%d is already in use by %r' % (b, _used[b]))
            _used[b] = self
            J.claim(b, 'zero')
            self._pins.append(b)
            out.append(b)
        return out[0] if len(out) == 1 else out

    def _check(self):
        if self._closed:
            raise DeviceClosed('%s is closed or uninitialized' % self.__class__.__name__)

    def close(self):
        if self._closed:
            return
        for hdl in self._handles:
            H.stop(hdl)
        self._handles = []
        for b in self._pins:
            J.release(b)
            if _used.get(b) is self:
                del _used[b]
        self._closed = True

    @property
    def closed(self):
        return self._closed

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def __repr__(self):
        if self._closed:
            return '<gpiozero.%s object closed>' % self.__class__.__name__
        pins = ', '.join('GPIO%d' % b for b in self._pins)
        return '<gpiozero.%s object on pin %s, is_active=%s>' % (self.__class__.__name__, pins, getattr(self, 'is_active', '?'))

    # gpiozero "source" / "values": led.source = button
    @property
    def values(self):
        def gen():
            while True:
                yield self.value
        return gen()

    @property
    def source(self):
        return getattr(self, '_source', None)

    @source.setter
    def source(self, src):
        hdl = getattr(self, '_src_handle', None)
        if hdl:
            H.stop(hdl)
            if hdl in self._handles:
                self._handles.remove(hdl)
        self._source = src
        self._src_handle = None
        if src is None:
            return
        it = None if hasattr(src, 'value') else iter(src)

        def tick():
            try:
                self.value = src.value if it is None else next(it)
            except StopIteration:
                H.stop(self._src_handle)

        self._src_handle = H.every(10, tick)
        self._handles.append(self._src_handle)


# ------------------------------------------------------------------ outputs
class OutputDevice(Device):
    def __init__(self, pin=None, active_high=True, initial_value=False, pin_factory=None):
        super().__init__()
        if pin is None:
            raise GPIOZeroError('No pin given')
        self.pin = self._claim(pin)
        self.active_high = active_high
        J.setup(self.pin, 'out', 'none')
        self._v = 0
        if initial_value is not None:
            self._write(1 if initial_value else 0)

    def _write(self, v):
        self._check()
        self._v = v
        J.stop_bg(self.pin)
        J.write(self.pin, v if self.active_high else 1 - v)

    def on(self):
        self._write(1)

    def off(self):
        self._write(0)

    def toggle(self):
        self._write(0 if self.value else 1)

    @property
    def value(self):
        lvl = J.level(self.pin)
        return lvl if self.active_high else 1 - lvl

    @value.setter
    def value(self, v):
        self._write(1 if v else 0)

    @property
    def is_active(self):
        return bool(self.value)


class DigitalOutputDevice(OutputDevice):
    def blink(self, on_time=1, off_time=1, n=None, background=True):
        self._check()
        on = 1 if self.active_high else 0
        J.blink(self.pin, float(on_time), float(off_time), int(n or 0), on, 1 - on, 0.0, 0.0)
        if not background:
            if n is None:
                while True:
                    _time.sleep(1)
            _time.sleep((on_time + off_time) * n)


class LED(DigitalOutputDevice):
    @property
    def is_lit(self):
        return self.is_active


class Buzzer(DigitalOutputDevice):
    def beep(self, on_time=1, off_time=1, n=None, background=True):
        self.blink(on_time, off_time, n, background)


class PWMOutputDevice(OutputDevice):
    def __init__(self, pin=None, active_high=True, initial_value=0, frequency=100, pin_factory=None):
        self._freq = float(frequency)
        self._d = 0.0
        super().__init__(pin, active_high, None)
        self.value = initial_value

    def _write(self, v):
        self._set(float(v))

    def _set(self, v):
        self._check()
        if not 0 <= v <= 1:
            raise ValueError('PWM value must be between 0 and 1')
        self._d = v
        J.stop_bg(self.pin)
        J.pwm(self.pin, self._freq, v if self.active_high else 1 - v)

    @property
    def value(self):
        d = J.duty(self.pin)
        return d if self.active_high else 1 - d

    @value.setter
    def value(self, v):
        self._set(float(v))

    def on(self):
        self._set(1.0)

    def off(self):
        self._set(0.0)

    def toggle(self):
        self._set(1 - self.value)

    @property
    def frequency(self):
        return self._freq

    @frequency.setter
    def frequency(self, f):
        self._freq = float(f)
        self._set(self._d)

    @property
    def is_active(self):
        return self.value > 0

    def blink(self, on_time=1, off_time=1, fade_in_time=0, fade_out_time=0, n=None, background=True):
        self._check()
        on, off = (1.0, 0.0) if self.active_high else (0.0, 1.0)
        J.pwm(self.pin, self._freq, off)
        J.blink(self.pin, float(on_time), float(off_time), int(n or 0), on, off, float(fade_in_time), float(fade_out_time))
        if not background:
            if n is None:
                while True:
                    _time.sleep(1)
            _time.sleep((on_time + off_time + fade_in_time + fade_out_time) * n)

    def pulse(self, fade_in_time=1, fade_out_time=1, n=None, background=True):
        self.blink(0, 0, fade_in_time, fade_out_time, n, background)


class PWMLED(PWMOutputDevice):
    @property
    def is_lit(self):
        return self.is_active


class TonalBuzzer(Device):
    def __init__(self, pin=None, initial_value=None, mid_tone=440, octaves=1, pin_factory=None):
        super().__init__()
        self.pin = self._claim(pin)
        self.mid_tone = mid_tone
        J.setup(self.pin, 'out', 'none')
        if initial_value is not None:
            self.play(initial_value)

    def play(self, tone):
        f = float(tone) if isinstance(tone, (int, float)) else 440.0
        J.pwm(self.pin, f, 0.5)

    def stop(self):
        J.pwm_off(self.pin)

    @property
    def is_active(self):
        return J.duty(self.pin) > 0


class RGBLED(Device):
    def __init__(self, red=None, green=None, blue=None, active_high=True, initial_value=(0, 0, 0), pwm=True, pin_factory=None):
        super().__init__()
        self._leds = [PWMLED(p, active_high) if pwm else LED(p, active_high) for p in (red, green, blue)]
        self.red_led, self.green_led, self.blue_led = self._leds
        self._pins = []
        self.color = initial_value

    def close(self):
        for led in self._leds:
            led.close()
        self._closed = True

    @property
    def value(self):
        return tuple(led.value for led in self._leds)

    @value.setter
    def value(self, v):
        for led, x in zip(self._leds, v):
            led.value = x

    color = value

    @property
    def red(self):
        return self._leds[0].value

    @red.setter
    def red(self, v):
        self._leds[0].value = v

    @property
    def green(self):
        return self._leds[1].value

    @green.setter
    def green(self, v):
        self._leds[1].value = v

    @property
    def blue(self):
        return self._leds[2].value

    @blue.setter
    def blue(self, v):
        self._leds[2].value = v

    @property
    def is_active(self):
        return self.value != (0, 0, 0)

    is_lit = is_active

    def on(self):
        self.value = (1, 1, 1)

    def off(self):
        self.value = (0, 0, 0)

    def toggle(self):
        self.value = tuple(1 - x for x in self.value)

    def blink(self, on_time=1, off_time=1, fade_in_time=0, fade_out_time=0, on_color=(1, 1, 1), off_color=(0, 0, 0), n=None, background=True):
        for led, a, b in zip(self._leds, on_color, off_color):
            J.pwm(led.pin, 100.0, float(b))
            J.blink(led.pin, float(on_time), float(off_time), int(n or 0), float(a), float(b), float(fade_in_time), float(fade_out_time))
        if not background and n:
            _time.sleep((on_time + off_time + fade_in_time + fade_out_time) * n)

    def pulse(self, fade_in_time=1, fade_out_time=1, on_color=(1, 1, 1), off_color=(0, 0, 0), n=None, background=True):
        self.blink(0, 0, fade_in_time, fade_out_time, on_color, off_color, n, background)


class Motor(Device):
    def __init__(self, forward=None, backward=None, enable=None, pwm=True, pin_factory=None):
        super().__init__()
        self.forward_device = PWMOutputDevice(forward) if pwm else DigitalOutputDevice(forward)
        self.backward_device = PWMOutputDevice(backward) if pwm else DigitalOutputDevice(backward)
        self.enable_device = DigitalOutputDevice(enable, initial_value=True) if enable is not None else None

    def close(self):
        for d in (self.forward_device, self.backward_device, self.enable_device):
            if d:
                d.close()
        self._closed = True

    @property
    def value(self):
        return self.forward_device.value - self.backward_device.value

    @value.setter
    def value(self, v):
        if v > 0:
            self.forward(v)
        elif v < 0:
            self.backward(-v)
        else:
            self.stop()

    @property
    def is_active(self):
        return self.value != 0

    def forward(self, speed=1):
        self.backward_device.off()
        self.forward_device.value = speed

    def backward(self, speed=1):
        self.forward_device.off()
        self.backward_device.value = speed

    def reverse(self):
        self.value = -self.value

    def stop(self):
        self.forward_device.off()
        self.backward_device.off()


class PhaseEnableMotor(Device):
    def __init__(self, phase=None, enable=None, pwm=True, pin_factory=None):
        super().__init__()
        self.phase_device = DigitalOutputDevice(phase)
        self.enable_device = PWMOutputDevice(enable) if pwm else DigitalOutputDevice(enable)

    def forward(self, speed=1):
        self.phase_device.off()
        self.enable_device.value = speed

    def backward(self, speed=1):
        self.phase_device.on()
        self.enable_device.value = speed

    def stop(self):
        self.enable_device.off()

    @property
    def value(self):
        return -self.enable_device.value if self.phase_device.value else self.enable_device.value

    @value.setter
    def value(self, v):
        if v >= 0:
            self.forward(v)
        else:
            self.backward(-v)


class Robot(Device):
    def __init__(self, left=None, right=None, pwm=True, pin_factory=None):
        super().__init__()
        self.left_motor = Motor(*left, pwm=pwm)
        self.right_motor = Motor(*right, pwm=pwm)

    def forward(self, speed=1, curve_left=0, curve_right=0):
        self.left_motor.forward(speed * (1 - curve_left))
        self.right_motor.forward(speed * (1 - curve_right))

    def backward(self, speed=1, curve_left=0, curve_right=0):
        self.left_motor.backward(speed * (1 - curve_left))
        self.right_motor.backward(speed * (1 - curve_right))

    def left(self, speed=1):
        self.right_motor.forward(speed)
        self.left_motor.backward(speed)

    def right(self, speed=1):
        self.left_motor.forward(speed)
        self.right_motor.backward(speed)

    def stop(self):
        self.left_motor.stop()
        self.right_motor.stop()

    @property
    def value(self):
        return (self.left_motor.value, self.right_motor.value)


class Servo(Device):
    def __init__(self, pin=None, initial_value=0, min_pulse_width=1 / 1000, max_pulse_width=2 / 1000, frame_width=20 / 1000, pin_factory=None):
        super().__init__()
        self.pin = self._claim(pin)
        self.min_pulse_width = min_pulse_width
        self.max_pulse_width = max_pulse_width
        self.frame_width = frame_width
        J.setup(self.pin, 'out', 'none')
        self._value = None
        self.value = initial_value

    @property
    def pulse_width(self):
        if self._value is None:
            return None
        return self.min_pulse_width + (self._value + 1) / 2 * (self.max_pulse_width - self.min_pulse_width)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, v):
        self._check()
        if v is None:
            self._value = None
            J.pwm_off(self.pin)
            return
        if not -1 <= v <= 1:
            raise ValueError('Servo value must be between -1 and 1, or None')
        self._value = float(v)
        J.pwm(self.pin, 1 / self.frame_width, self.pulse_width / self.frame_width)

    def min(self):
        self.value = -1

    def mid(self):
        self.value = 0

    def max(self):
        self.value = 1

    def detach(self):
        self.value = None

    @property
    def is_active(self):
        return self._value is not None


class AngularServo(Servo):
    def __init__(self, pin=None, initial_angle=0, min_angle=-90, max_angle=90, min_pulse_width=1 / 1000, max_pulse_width=2 / 1000, frame_width=20 / 1000, pin_factory=None):
        self.min_angle = min_angle
        self.max_angle = max_angle
        super().__init__(pin, self._a2v(initial_angle) if initial_angle is not None else None, min_pulse_width, max_pulse_width, frame_width)

    def _a2v(self, a):
        return (a - self.min_angle) / (self.max_angle - self.min_angle) * 2 - 1

    @property
    def angle(self):
        if self._value is None:
            return None
        return self.min_angle + (self._value + 1) / 2 * (self.max_angle - self.min_angle)

    @angle.setter
    def angle(self, a):
        self.value = None if a is None else self._a2v(a)


class LEDBoard(Device):
    def __init__(self, *pins, pwm=False, active_high=True, initial_value=False, pin_factory=None, **named):
        super().__init__()
        cls = PWMLED if pwm else LED
        self.leds = tuple(cls(p, active_high) for p in pins) + tuple(cls(p, active_high) for p in named.values())
        for k, led in zip(named.keys(), self.leds[len(pins):]):
            setattr(self, k, led)
        self.value = tuple(initial_value for _ in self.leds) if not isinstance(initial_value, tuple) else initial_value

    def __getitem__(self, i):
        return self.leds[i]

    def __len__(self):
        return len(self.leds)

    def __iter__(self):
        return iter(self.leds)

    def close(self):
        for led in self.leds:
            led.close()
        self._closed = True

    @property
    def value(self):
        return tuple(led.value for led in self.leds)

    @value.setter
    def value(self, v):
        for led, x in zip(self.leds, v):
            led.value = x

    def on(self, *idx):
        for i, led in enumerate(self.leds):
            if not idx or i in idx:
                led.on()

    def off(self, *idx):
        for i, led in enumerate(self.leds):
            if not idx or i in idx:
                led.off()

    def toggle(self, *idx):
        for i, led in enumerate(self.leds):
            if not idx or i in idx:
                led.toggle()

    def blink(self, on_time=1, off_time=1, n=None, background=True):
        for led in self.leds:
            led.blink(on_time, off_time, n, True)
        if not background and n:
            _time.sleep((on_time + off_time) * n)

    @property
    def is_active(self):
        return any(self.value)


class LEDBarGraph(LEDBoard):
    @property
    def value(self):
        return sum(led.value for led in self.leds) / len(self.leds)

    @value.setter
    def value(self, v):
        n = len(self.leds)
        for i, led in enumerate(self.leds):
            led.value = 1 if v * n >= i + 1 else 0


class TrafficLights(Device):
    def __init__(self, red=None, amber=None, green=None, pwm=False, initial_value=False, yellow=None, pin_factory=None):
        super().__init__()
        cls = PWMLED if pwm else LED
        if amber is None:
            amber = yellow
        self.red = cls(red)
        self.amber = cls(amber)
        self.yellow = self.amber
        self.green = cls(green)
        self.leds = (self.red, self.amber, self.green)

    def close(self):
        for led in self.leds:
            led.close()
        self._closed = True

    @property
    def value(self):
        return tuple(led.value for led in self.leds)

    @value.setter
    def value(self, v):
        for led, x in zip(self.leds, v):
            led.value = x

    def on(self):
        self.value = (1, 1, 1)

    def off(self):
        self.value = (0, 0, 0)


# ------------------------------------------------------------------ inputs
class InputDevice(Device):
    def __init__(self, pin=None, pull_up=False, active_state=None, pin_factory=None):
        super().__init__()
        if pin is None:
            raise GPIOZeroError('No pin given')
        self.pin = self._claim(pin)
        self.pull_up = pull_up
        J.setup(self.pin, 'in', 'up' if pull_up is True else ('down' if pull_up is False else 'none'))
        self._active_low = bool(pull_up) if active_state is None else not active_state

    @property
    def value(self):
        self._check()
        v = J.read(self.pin)
        return 1 - v if self._active_low else v

    @property
    def is_active(self):
        return bool(self.value)


class DigitalInputDevice(InputDevice):
    def __init__(self, pin=None, pull_up=False, active_state=None, bounce_time=None, pin_factory=None):
        super().__init__(pin, pull_up, active_state)
        self.bounce_time = bounce_time
        self._when_act = None
        self._when_deact = None
        self._cid = H.register(self._edge)
        J.watch(self.pin, 'both', int((bounce_time or 0) * 1000))
        J.watch_cb(self.pin, self._cid)
        self._t_act = None

    def close(self):
        if not self._closed:
            J.unwatch(self.pin)
            H.unregister(self._cid)
        super().close()

    def _edge(self, level):
        active = (1 - level if self._active_low else level) == 1
        if active:
            self._t_act = _time.ticks_ms()
            if self._when_act:
                H.call(self._when_act, self)
        else:
            self._t_act = None
            if self._when_deact:
                H.call(self._when_deact, self)

    @property
    def when_activated(self):
        return self._when_act

    @when_activated.setter
    def when_activated(self, fn):
        self._when_act = fn

    @property
    def when_deactivated(self):
        return self._when_deact

    @when_deactivated.setter
    def when_deactivated(self, fn):
        self._when_deact = fn

    def wait_for_active(self, timeout=None):
        return self._wait(True, timeout)

    def wait_for_inactive(self, timeout=None):
        return self._wait(False, timeout)

    def _wait(self, state, timeout):
        t0 = _time.ticks_ms()
        while self.is_active != state:
            if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout * 1000:
                return False
            _time.sleep_ms(5)
        return True

    @property
    def active_time(self):
        if self._t_act is None:
            return None
        return _time.ticks_diff(_time.ticks_ms(), self._t_act) / 1000


class SmoothedInputDevice(DigitalInputDevice):
    pass


class Button(DigitalInputDevice):
    def __init__(self, pin=None, pull_up=True, active_state=None, bounce_time=None, hold_time=1, hold_repeat=False, pin_factory=None):
        super().__init__(pin, pull_up, active_state, bounce_time)
        self.hold_time = hold_time
        self.hold_repeat = hold_repeat
        self._when_held = None
        self._hold_handle = None

    def _edge(self, level):
        super()._edge(level)
        if self._hold_handle:
            H.stop(self._hold_handle)
            self._hold_handle = None
        if self.is_active and self._when_held:
            t0 = _time.ticks_ms()
            fired = [False]

            def chk():
                if not self.is_active:
                    H.stop(self._hold_handle)
                    self._hold_handle = None
                    return
                if (not fired[0] or self.hold_repeat) and _time.ticks_diff(_time.ticks_ms(), t0) >= self.hold_time * 1000 * (1 + (1 if fired[0] else 0)):
                    fired[0] = True
                    H.call(self._when_held, self)

            self._hold_handle = H.every(20, chk)

    is_pressed = property(lambda self: self.is_active)
    is_held = property(lambda self: self.is_active and self.active_time is not None and self.active_time >= self.hold_time)
    held_time = property(lambda self: self.active_time)
    pressed_time = held_time

    @property
    def when_pressed(self):
        return self._when_act

    @when_pressed.setter
    def when_pressed(self, fn):
        self._when_act = fn

    @property
    def when_released(self):
        return self._when_deact

    @when_released.setter
    def when_released(self, fn):
        self._when_deact = fn

    @property
    def when_held(self):
        return self._when_held

    @when_held.setter
    def when_held(self, fn):
        self._when_held = fn

    def wait_for_press(self, timeout=None):
        return self.wait_for_active(timeout)

    def wait_for_release(self, timeout=None):
        return self.wait_for_inactive(timeout)


class MotionSensor(DigitalInputDevice):
    def __init__(self, pin=None, pull_up=False, active_state=None, queue_len=1, sample_rate=10, threshold=0.5, partial=False, pin_factory=None):
        super().__init__(pin, pull_up, active_state)

    motion_detected = property(lambda self: self.is_active)

    @property
    def when_motion(self):
        return self._when_act

    @when_motion.setter
    def when_motion(self, fn):
        self._when_act = fn

    @property
    def when_no_motion(self):
        return self._when_deact

    @when_no_motion.setter
    def when_no_motion(self, fn):
        self._when_deact = fn

    def wait_for_motion(self, timeout=None):
        return self.wait_for_active(timeout)

    def wait_for_no_motion(self, timeout=None):
        return self.wait_for_inactive(timeout)


class LineSensor(DigitalInputDevice):
    def __init__(self, pin=None, pull_up=False, active_state=None, queue_len=5, sample_rate=100, threshold=0.5, partial=False, pin_factory=None):
        super().__init__(pin, pull_up, active_state)

    line_detected = property(lambda self: not self.is_active)

    @property
    def when_line(self):
        return self._when_deact

    @when_line.setter
    def when_line(self, fn):
        self._when_deact = fn

    @property
    def when_no_line(self):
        return self._when_act

    @when_no_line.setter
    def when_no_line(self, fn):
        self._when_act = fn


class LightSensor(DigitalInputDevice):
    def __init__(self, pin=None, queue_len=5, charge_time_limit=0.01, threshold=0.1, partial=False, pin_factory=None):
        super().__init__(pin, False, None)

    @property
    def value(self):
        return J.light(self.pin)

    light_detected = property(lambda self: self.value > 0.5)

    def wait_for_light(self, timeout=None):
        return self._wait(True, timeout)

    def wait_for_dark(self, timeout=None):
        return self._wait(False, timeout)


class DistanceSensor(Device):
    def __init__(self, echo=None, trigger=None, queue_len=9, max_distance=1, threshold_distance=0.3, partial=False, pin_factory=None):
        super().__init__()
        self.echo, self.trigger = self._claim(echo, trigger)
        J.setup(self.echo, 'in', 'none')
        J.setup(self.trigger, 'out', 'none')
        self.max_distance = max_distance
        self.threshold_distance = threshold_distance
        self._in = None
        self._out = None

    @property
    def distance(self):
        self._check()
        d = J.distance(self.echo)
        if d < 0:
            return self.max_distance
        return min(self.max_distance, d)

    @property
    def value(self):
        return self.distance / self.max_distance

    @property
    def in_range(self):
        return self.distance < self.threshold_distance

    is_active = in_range

    def wait_for_in_range(self, timeout=None):
        t0 = _time.ticks_ms()
        while not self.in_range:
            if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout * 1000:
                return False
            _time.sleep_ms(20)
        return True

    def wait_for_out_of_range(self, timeout=None):
        t0 = _time.ticks_ms()
        while self.in_range:
            if timeout is not None and _time.ticks_diff(_time.ticks_ms(), t0) >= timeout * 1000:
                return False
            _time.sleep_ms(20)
        return True

    def _poll(self):
        r = self.in_range
        if r != self._last:
            self._last = r
            fn = self._in if r else self._out
            if fn:
                H.call(fn, self)

    def _ensure_poll(self):
        if not getattr(self, '_ph', None):
            self._last = self.in_range
            self._ph = H.every(50, self._poll)
            self._handles.append(self._ph)

    @property
    def when_in_range(self):
        return self._in

    @when_in_range.setter
    def when_in_range(self, fn):
        self._in = fn
        self._ensure_poll()

    @property
    def when_out_of_range(self):
        return self._out

    @when_out_of_range.setter
    def when_out_of_range(self, fn):
        self._out = fn
        self._ensure_poll()


# ------------------------------------------------------------------ SPI ADC (MCP3008 + pot)
class AnalogInputDevice(Device):
    bits = 10

    def __init__(self, channel=0, differential=False, max_voltage=3.3, **spi):
        super().__init__()
        self.channel = channel
        self.max_voltage = max_voltage

    @property
    def value(self):
        return J.mcp3008(self.channel)

    @property
    def raw_value(self):
        return int(self.value * ((1 << self.bits) - 1))

    @property
    def voltage(self):
        return self.value * self.max_voltage

    @property
    def is_active(self):
        return self.value > 0


class MCP3008(AnalogInputDevice):
    pass


class MCP3004(AnalogInputDevice):
    pass


class MCP3208(AnalogInputDevice):
    bits = 12


class Potentiometer(MCP3008):
    pass


# ------------------------------------------------------------------ internal devices
class CPUTemperature(Device):
    def __init__(self, sensor_file='/sys/class/thermal/thermal_zone0/temp', min_temp=0.0, max_temp=100.0, threshold=80.0, event_delay=5.0, pin_factory=None):
        super().__init__()
        self.min_temp = min_temp
        self.max_temp = max_temp
        self.threshold = threshold

    @property
    def temperature(self):
        return J.cpu_temp()

    @property
    def value(self):
        return min(1, max(0, (self.temperature - self.min_temp) / (self.max_temp - self.min_temp)))

    @property
    def is_active(self):
        return self.temperature > self.threshold


class LoadAverage(Device):
    @property
    def load_average(self):
        return 0.25

    value = property(lambda self: 0.25)


class PingServer(Device):
    def __init__(self, host='google.com', event_delay=10.0, pin_factory=None):
        super().__init__()
        self.host = host

    @property
    def value(self):
        return True

    is_active = value


class TimeOfDay(Device):
    def __init__(self, start_time=None, end_time=None, utc=True, event_delay=10.0, pin_factory=None):
        super().__init__()
        self.start_time = start_time
        self.end_time = end_time

    @property
    def value(self):
        return True


class Device_pin_factory:
    pass


Device.pin_factory = None
`;var Hc=`# board: Adafruit Blinka pin names for the Raspberry Pi (board.D4 is BCM GPIO 4).
for _i in range(28):
    globals()['D%d' % _i] = _i
SDA = 2
SCL = 3
SCK = SCLK = 11
MOSI = 10
MISO = 9
CE0 = 8
CE1 = 7
TXD = 14
RXD = 15


def I2C():
    import busio
    return busio.I2C(SCL, SDA)


def SPI():
    import busio
    return busio.SPI(SCLK, MOSI, MISO)
`;var Vc=`# adafruit_dht: DHT11 / DHT22 on a Raspberry Pi (Adafruit CircuitPython API).
import _rpi_js as J


class DHTBase:
    def __init__(self, pin, use_pulseio=True):
        self._id = int(pin)

    def _read(self, which):
        v = J.dht(self._id, which)
        if v < -100:
            raise RuntimeError('DHT sensor not found, check wiring')
        return v

    def exit(self):
        pass


class DHT11(DHTBase):
    @property
    def temperature(self):
        return int(round(self._read(0)))

    @property
    def humidity(self):
        return int(round(self._read(1)))


class DHT22(DHTBase):
    @property
    def temperature(self):
        return round(float(self._read(0)), 1)

    @property
    def humidity(self):
        return round(float(self._read(1)), 1)
`;var Uc=`# machine for the RaptiAuto virtual Raspberry Pi Pico (RP2040 / RP2350) \u2014 the MicroPython API.
import _rpi_js as J
import _rpi_hw as H
import time as _time

_LED = 64   # id of the Pico W "LED" pin (WL_GPIO0 on the wireless chip)


def _pid(id):
    if isinstance(id, Pin):
        return id._id
    if isinstance(id, str):
        s = id.upper()
        if s in ('LED', 'WL_GPIO0'):
            return _LED if J.board() in ('picow', 'pico2w') else 25
        if s.startswith('GPIO'):
            s = s[4:]
        elif s.startswith('GP'):
            s = s[2:]
        try:
            id = int(s)
        except ValueError:
            raise ValueError('unknown named pin "%s"' % id)
    if not isinstance(id, int):
        raise TypeError("can't convert %s to int" % type(id).__name__)
    if id == 25 and J.board() in ('picow', 'pico2w'):
        # on the Pico W GPIO25 is the wireless chip's SPI clock; the LED is Pin("LED")
        return 25
    if id < 0 or id > 29:
        raise ValueError('invalid pin')
    return id


class Pin:
    IN = 0
    OUT = 1
    OPEN_DRAIN = 2
    ALT = 3
    PULL_UP = 1
    PULL_DOWN = 2
    IRQ_FALLING = 4
    IRQ_RISING = 8
    IRQ_LOW_LEVEL = 1
    IRQ_HIGH_LEVEL = 2
    ALT_SPI = 1
    ALT_UART = 2
    ALT_I2C = 3
    ALT_PWM = 4
    ALT_SIO = 5
    ALT_PIO0 = 6
    ALT_PIO1 = 7

    def __init__(self, id, mode=-1, pull=-1, *, value=None, alt=-1):
        self._id = _pid(id)
        self._mode = None
        self._irq = None
        self.init(mode, pull, value=value)

    def init(self, mode=-1, pull=-1, *, value=None, alt=-1):
        if mode != -1:
            self._mode = mode
        if pull != -1:
            self._pull = pull
        if mode == Pin.OUT or mode == Pin.OPEN_DRAIN:
            if value is not None:
                J.write(self._id, 1 if value else 0)
            J.setup(self._id, 'out', 'none')
        elif mode == Pin.IN:
            p = pull if pull != -1 else None
            J.setup(self._id, 'in', 'up' if p == Pin.PULL_UP else ('down' if p == Pin.PULL_DOWN else 'none'))
        elif pull != -1:
            J.set_pull(self._id, 'up' if pull == Pin.PULL_UP else ('down' if pull == Pin.PULL_DOWN else 'none'))
        if value is not None and mode == -1:
            J.write(self._id, 1 if value else 0)

    def value(self, x=None):
        if x is None:
            return J.read(self._id)
        J.write(self._id, 1 if x else 0)

    def __call__(self, x=None):
        return self.value(x)

    def on(self):
        J.write(self._id, 1)

    def off(self):
        J.write(self._id, 0)

    high = on
    low = off

    def toggle(self):
        J.write(self._id, 0 if J.level(self._id) else 1)

    def irq(self, handler=None, trigger=IRQ_FALLING | IRQ_RISING, hard=False):
        if self._irq is not None:
            J.unwatch(self._id)
            H.unregister(self._irq)
            self._irq = None
        if handler is None:
            return None
        if trigger & (Pin.IRQ_FALLING | Pin.IRQ_RISING) == (Pin.IRQ_FALLING | Pin.IRQ_RISING):
            edge = 'both'
        elif trigger & Pin.IRQ_RISING:
            edge = 'rising'
        else:
            edge = 'falling'
        self._irq = H.register(lambda _lvl: handler(self))
        J.watch(self._id, edge, 0)
        J.watch_cb(self._id, self._irq)
        return self

    def mode(self, m=None):
        if m is None:
            return self._mode
        self.init(m)

    def pull(self, p=None):
        if p is None:
            return getattr(self, '_pull', None)
        self.init(pull=p)

    def __repr__(self):
        name = 'EXT_GPIO0' if self._id == _LED else 'GPIO%d' % self._id
        m = {Pin.IN: 'IN', Pin.OUT: 'OUT', Pin.OPEN_DRAIN: 'OPEN_DRAIN', Pin.ALT: 'ALT'}.get(self._mode, 'IN')
        return 'Pin(%s, mode=%s)' % (name, m)


class Signal:
    def __init__(self, pin, *args, invert=False, **kw):
        self._pin = pin if isinstance(pin, Pin) else Pin(pin, *args, **kw)
        self._inv = invert

    def value(self, x=None):
        if x is None:
            return self._pin.value() ^ (1 if self._inv else 0)
        self._pin.value((1 if x else 0) ^ (1 if self._inv else 0))

    def on(self):
        self.value(1)

    def off(self):
        self.value(0)


class PWM:
    def __init__(self, dest, *, freq=None, duty_u16=None, duty_ns=None, invert=False):
        self._id = _pid(dest)
        self._f = 1000 if freq is None else freq
        self._d = 0
        self._inv = invert
        J.setup(self._id, 'out', 'none')
        if duty_u16 is not None:
            self._d = duty_u16
        elif duty_ns is not None:
            self._d = int(duty_ns * self._f * 65535 // 1000000000)
        self._apply()

    def _apply(self):
        d = min(65535, max(0, self._d)) / 65535
        J.pwm(self._id, float(self._f), 1 - d if self._inv else d)

    def init(self, *, freq=None, duty_u16=None, duty_ns=None):
        if freq is not None:
            self._f = freq
        if duty_u16 is not None:
            self._d = duty_u16
        if duty_ns is not None:
            self.duty_ns(duty_ns)
        self._apply()

    def freq(self, f=None):
        if f is None:
            return self._f
        if f < 8 or f > 62500000:
            raise ValueError('freq too small' if f < 8 else 'freq too large')
        self._f = f
        self._apply()

    def duty_u16(self, d=None):
        if d is None:
            return self._d
        self._d = int(d)
        self._apply()

    def duty_ns(self, ns=None):
        if ns is None:
            return int(self._d / 65535 * 1000000000 / self._f)
        self._d = int(ns * self._f * 65535 // 1000000000)
        self._apply()

    def deinit(self):
        J.pwm_off(self._id)

    def __repr__(self):
        return '<PWM slice=%d channel=%d invert=%d>' % ((self._id >> 1) & 7, self._id & 1, 1 if self._inv else 0)


class ADC:
    CORE_TEMP = 4

    def __init__(self, pin, *, atten=None):
        if isinstance(pin, Pin):
            pin = pin._id
        if isinstance(pin, int) and 26 <= pin <= 29:
            self._ch = pin - 26
        elif isinstance(pin, int) and 0 <= pin <= 4:
            self._ch = pin
        else:
            raise ValueError('Pin doesn\\'t have ADC capabilities')

    def read_u16(self):
        v = J.adc(self._ch)
        return max(0, min(65535, int(v * 65535)))

    def __repr__(self):
        return '<ADC channel=%d>' % self._ch


class Timer:
    ONE_SHOT = 0
    PERIODIC = 1

    def __init__(self, id=-1, *, mode=PERIODIC, period=-1, freq=-1, tick_hz=1000, callback=None):
        self._t = None
        self._cid = None
        if callback is not None or period != -1 or freq != -1:
            self.init(mode=mode, period=period, freq=freq, tick_hz=tick_hz, callback=callback)

    def init(self, *, mode=PERIODIC, period=-1, freq=-1, tick_hz=1000, callback=None):
        self.deinit()
        if freq != -1:
            ms = 1000 / freq
        elif period != -1:
            ms = period * 1000 / tick_hz
        else:
            ms = 1000
        if callback is None:
            return
        self._cid = H.register(lambda _a: callback(self))
        self._t = J.timer(self._cid, max(1, ms), 1 if mode == Timer.PERIODIC else 0)

    def deinit(self):
        if self._t is not None:
            J.timer_stop(self._t)
            H.unregister(self._cid)
            self._t = None

    def __repr__(self):
        return '<Timer>'


class I2C:
    def __init__(self, id=0, *, scl=None, sda=None, freq=400000, timeout=50000):
        self._id = id
        self._freq = freq

    def scan(self):
        s = J.i2c_scan()
        return [int(a) for a in s.split(',')] if s else []

    def writeto(self, addr, buf, stop=True):
        J.i2c_write(addr, bytes(buf).hex())
        return len(buf)

    def writevto(self, addr, vector, stop=True):
        data = b''.join(bytes(v) for v in vector)
        J.i2c_write(addr, data.hex())
        return len(data)

    def readfrom(self, addr, n, stop=True):
        return bytes.fromhex(J.i2c_read(addr, n))

    def readfrom_into(self, addr, buf, stop=True):
        b = self.readfrom(addr, len(buf))
        for i in range(len(buf)):
            buf[i] = b[i]

    def writeto_mem(self, addr, memaddr, buf, *, addrsize=8):
        J.i2c_write(addr, (bytes([memaddr]) + bytes(buf)).hex())

    def readfrom_mem(self, addr, memaddr, n, *, addrsize=8):
        J.i2c_write(addr, bytes([memaddr]).hex())
        return bytes.fromhex(J.i2c_read(addr, n))

    def __repr__(self):
        return 'I2C(%d, freq=%d)' % (self._id, self._freq)


SoftI2C = I2C


class SPI:
    """SPI bus: the bytes reach a MAX7219 chain (or an MCP3008) wired to the SCK / MOSI pins."""
    MSB = 0
    LSB = 1
    _DEFAULT = {0: (18, 19, 16), 1: (10, 11, 12)}   # id -> (sck, mosi, miso) on the Pico

    def __init__(self, id=0, baudrate=1000000, *, polarity=0, phase=0, bits=8, firstbit=0, sck=None, mosi=None, miso=None):
        self._id = id
        d = SPI._DEFAULT.get(id, (18, 19, 16))
        self._sck = _pid(sck) if sck is not None else d[0]
        self._mosi = _pid(mosi) if mosi is not None else d[1]
        self._miso = _pid(miso) if miso is not None else d[2]
        self._baud = baudrate

    def init(self, baudrate=1000000, **kw):
        self._baud = baudrate
        for k in ('sck', 'mosi', 'miso'):
            if kw.get(k) is not None:
                setattr(self, '_' + k, _pid(kw[k]))

    def _xfer(self, data):
        r = J.spi_xfer(self._sck, self._mosi, bytes(data).hex())
        return bytes.fromhex(r)

    def write(self, buf):
        self._xfer(buf)

    def read(self, n, write=0):
        return self._xfer(bytes([write]) * n)

    def readinto(self, buf, write=0):
        r = self.read(len(buf), write)
        for i in range(len(buf)):
            buf[i] = r[i]

    def write_readinto(self, wbuf, rbuf):
        r = self._xfer(wbuf)
        for i in range(len(rbuf)):
            rbuf[i] = r[i]

    def deinit(self):
        pass

    def __repr__(self):
        return 'SPI(%d, baudrate=%d, sck=%d, mosi=%d, miso=%d)' % (self._id, self._baud, self._sck, self._mosi, self._miso)


class SoftSPI(SPI):
    def __init__(self, baudrate=500000, *, polarity=0, phase=0, bits=8, firstbit=0, sck, mosi, miso):
        SPI.__init__(self, -1, baudrate, sck=sck, mosi=mosi, miso=miso)


class UART:
    def __init__(self, id=0, baudrate=115200, **kw):
        self._id = id
        self._baud = baudrate

    def init(self, baudrate=115200, **kw):
        self._baud = baudrate

    def write(self, buf):
        J.uart_write(self._id, bytes(buf).decode('utf-8', 'ignore') if not isinstance(buf, str) else buf)
        return len(buf)

    def any(self):
        return J.uart_any(self._id)

    def read(self, n=-1):
        s = J.uart_read(self._id, -1 if n is None else n)
        return s.encode() if s else None

    def readline(self):
        s = J.uart_readline(self._id, 1)
        return s.encode() if s else None

    def readinto(self, buf, nbytes=None):
        b = self.read(len(buf) if nbytes is None else nbytes)
        if not b:
            return None
        for i in range(len(b)):
            buf[i] = b[i]
        return len(b)

    def deinit(self):
        pass

    def __repr__(self):
        return 'UART(%d, baudrate=%d)' % (self._id, self._baud)


class RTC:
    def __init__(self, id=0):
        self._off = 0

    def datetime(self, dt=None):
        t = _time.localtime()
        if dt is not None:
            return None
        return (t[0], t[1], t[2], t[6], t[3], t[4], t[5], 0)


class WDT:
    def __init__(self, id=0, timeout=5000):
        self._timeout = timeout

    def feed(self):
        pass


PWRON_RESET = 1
WDT_RESET = 3


def freq(hz=None):
    if hz is None:
        return 150000000 if J.board() in ('pico2', 'pico2w') else 125000000


def unique_id():
    return b'\\xe6\\x61\\x41\\x04\\x03\\x2b\\x5c\\x29'


def reset():
    raise SystemExit('machine.reset()')


def soft_reset():
    raise SystemExit('soft reset')


def reset_cause():
    return PWRON_RESET


def bootloader(*a):
    raise SystemExit('BOOTSEL mode')


def idle():
    _time.sleep_ms(1)


def lightsleep(ms=None):
    if ms is None:
        while True:
            _time.sleep(1)
    _time.sleep_ms(ms)


deepsleep = lightsleep


def disable_irq():
    return 0


def enable_irq(state=0):
    pass


def time_pulse_us(pin, pulse_level, timeout_us=1000000):
    t0 = _time.ticks_us()
    while pin.value() != pulse_level:
        if _time.ticks_diff(_time.ticks_us(), t0) > timeout_us:
            return -2
    t1 = _time.ticks_us()
    while pin.value() == pulse_level:
        if _time.ticks_diff(_time.ticks_us(), t1) > timeout_us:
            return -1
    return _time.ticks_diff(_time.ticks_us(), t1)


class mem32:
    pass
`;var Gc=`# rp2: RP2040 specific functions (BOOTSEL button, country code).
import _rpi_js as J


def bootsel_button():
    return J.bootsel()


def country(c=None):
    return 'XX' if c is None else None


class PIO:
    IN_LOW = 0
    IN_HIGH = 1
    OUT_LOW = 2
    OUT_HIGH = 3
    SHIFT_LEFT = 0
    SHIFT_RIGHT = 1

    def __init__(self, id):
        raise OSError('PIO programs are not simulated in RaptiAuto')


class StateMachine:
    def __init__(self, *a, **k):
        raise OSError('PIO state machines are not simulated in RaptiAuto')


def asm_pio(*a, **k):
    def deco(f):
        return f
    return deco
`;var Xc=`# network: Wi-Fi for the Pico W on the simulated network (see src/net). Networks in range: RaptiNet
# (password rapti1234), RAPTI-Lab (password123), Wokwi-GUEST and Guest (open), Home-WiFi (12345678),
# Office-5G (admin1234). Any other name works too when the password has 8+ characters (turn on
# "Strict Wi-Fi" in http://dashboard.rapti.net/ to make a wrong name fail).
import _rpi_js as J
import json
import time as _time

STA_IF = 0
AP_IF = 1
STAT_IDLE = 0
STAT_CONNECTING = 1
STAT_WRONG_PASSWORD = -3
STAT_NO_AP_FOUND = -2
STAT_CONNECT_FAIL = -1
STAT_GOT_IP = 3


def _check():
    if J.board() not in ('picow', 'pico2w'):
        raise ImportError("no module named 'network'")


class WLAN:
    def __init__(self, interface_id=STA_IF):
        _check()
        self._if = interface_id
        self._active = False
        self._t = None
        self._ssid = None
        self._res = None
        self._join = None
        self._ap_ssid = 'MicroPython-ap'
        self._ap_pass = ''

    def active(self, a=None):
        if a is None:
            return self._active
        self._active = bool(a)
        if self._if == AP_IF:
            if self._active and self._ap_pass and 0 < len(self._ap_pass) < 8:
                raise OSError('AP password must be at least 8 characters')
            J.wifi_ap(1 if self._active else 0, self._ap_ssid, self._ap_pass)
            return
        J.wifi(1 if self._active else 0, '')
        if not self._active:
            J.wifi_leave()

    def connect(self, ssid=None, key=None, **kw):
        if not self._active:
            raise OSError('wifi is not active')
        self._ssid = ssid
        self._t = _time.ticks_ms()
        self._res = json.loads(J.wifi_join(ssid or '', key or ''))
        J.wifi(2, ssid or '')

    def disconnect(self):
        self._t = None
        self._res = None
        J.wifi_leave()
        J.wifi(1, '')

    def status(self, param=None):
        if param == 'rssi':
            return json.loads(J.wifi_info()).get('rssi', -48)
        if self._t is None:
            return STAT_IDLE
        if _time.ticks_diff(_time.ticks_ms(), self._t) < 1800:
            return STAT_CONNECTING
        st = self._res['status'] if self._res else 1
        if st == 3:
            if not json.loads(J.wifi_info()).get('connected'):
                return STAT_CONNECT_FAIL
            J.wifi(3, self._ssid or '')
            return STAT_GOT_IP
        return STAT_WRONG_PASSWORD if st == 4 else STAT_NO_AP_FOUND

    def isconnected(self):
        if self._if == AP_IF:
            return self._active
        return self.status() == STAT_GOT_IP

    def ifconfig(self, cfg=None):
        if self._if == AP_IF:
            return ('192.168.4.1', '255.255.255.0', '192.168.4.1', '0.0.0.0') if self._active else ('0.0.0.0', '0.0.0.0', '0.0.0.0', '0.0.0.0')
        if self.isconnected():
            ip = json.loads(J.wifi_info()).get('ip', '192.168.1.50')
            return (ip, '255.255.255.0', '192.168.1.1', '8.8.8.8')
        return ('0.0.0.0', '0.0.0.0', '0.0.0.0', '0.0.0.0')

    def ipconfig(self, *a):
        return self.ifconfig()[0]

    def scan(self):
        out = []
        for n in json.loads(J.wifi_scan()):
            out.append((n['ssid'].encode(), bytes(n['bssid']), n['ch'], n['rssi'], 3 if n['enc'] != 'open' else 0, 0))
        return out

    def config(self, *a, **k):
        if self._if == AP_IF:
            if 'essid' in k or 'ssid' in k:
                self._ap_ssid = k.get('essid') or k.get('ssid')
            if 'password' in k:
                self._ap_pass = k['password']
            if a and a[0] in ('essid', 'ssid'):
                return self._ap_ssid
            if self._active and k:
                J.wifi_ap(1, self._ap_ssid, self._ap_pass)
            return None
        if a and a[0] == 'mac':
            return bytes(int(x, 16) for x in json.loads(J.wifi_info()).get('mac', '28:cd:c1:0a:4b:2e').split(':'))
        if a and a[0] == 'ssid':
            return self._ssid or ''
        return None


def hostname(name=None):
    return 'PicoW' if name is None else None


def country(c=None):
    return 'BD' if c is None else None
`;var Jc=`# neopixel: WS2812 LEDs. Works like MicroPython's NeoPixel(Pin(0), 8) + write(), and like
# Adafruit's neopixel.NeoPixel(board.D18, 8, auto_write=True) + show() on a Raspberry Pi.
import _rpi_js as J

GRB = 'GRB'
RGB = 'RGB'


class NeoPixel:
    def __init__(self, pin, n, bpp=3, timing=1, *, brightness=1.0, auto_write=None, pixel_order=None):
        self._id = pin._id if hasattr(pin, '_id') else int(pin)
        self.n = n
        self.bpp = bpp
        self.brightness = brightness
        # Adafruit's library (board pins are ints) writes after every change
        self.auto_write = (not hasattr(pin, '_id')) if auto_write is None else auto_write
        self._buf = [(0, 0, 0)] * n
        J.setup(self._id, 'out', 'none')

    def __len__(self):
        return self.n

    def __setitem__(self, i, v):
        if isinstance(i, slice):
            for k, c in zip(range(*i.indices(self.n)), v):
                self._buf[k] = tuple(c)[:3]
        else:
            if i < 0:
                i += self.n
            self._buf[i] = tuple(v)[:3]
        if self.auto_write:
            self.write()

    def __getitem__(self, i):
        return self._buf[i]

    def fill(self, v):
        self._buf = [tuple(v)[:3]] * self.n
        if self.auto_write:
            self.write()

    def write(self):
        b = self.brightness
        s = ''.join('%02x%02x%02x' % (int(c[0] * b) & 255, int(c[1] * b) & 255, int(c[2] * b) & 255) for c in self._buf)
        J.neo(self._id, self.n, s)

    show = write

    def deinit(self):
        self.fill((0, 0, 0))
        self.write()
`;var Yc=`# dht: DHT11 / DHT22 temperature and humidity sensors (MicroPython API).
import _rpi_js as J


class DHTBase:
    def __init__(self, pin):
        self._id = pin._id if hasattr(pin, '_id') else int(pin)
        self._t = None
        self._h = None

    def measure(self):
        t = J.dht(self._id, 0)
        if t < -100:
            raise OSError(110)  # ETIMEDOUT: no sensor on this pin
        self._t = t
        self._h = J.dht(self._id, 1)


class DHT11(DHTBase):
    def temperature(self):
        return int(round(self._t))

    def humidity(self):
        return int(round(self._h))


class DHT22(DHTBase):
    def temperature(self):
        return round(float(self._t), 1)

    def humidity(self):
        return round(float(self._h), 1)
`;var Kc=`# Character LCD (HD44780, 16x2 / 20x4) on an I2C backpack (PCF8574, address 0x27 or 0x3F) for the
# Raspberry Pi and the Pico:
#     from i2c_lcd import I2cLcd
#     lcd = I2cLcd(0x27, 2, 16)              # Raspberry Pi: SDA = GPIO2, SCL = GPIO3
#     lcd = I2cLcd(i2c, 0x27, 2, 16)         # Pico: i2c = machine.I2C(0, sda=Pin(4), scl=Pin(5))
#     lcd.putstr("Hello!")
import _rpi_js as J
import time

_RS = 0x01
_EN = 0x04
_BL = 0x08


class I2cLcd:
    def __init__(self, *args, **kw):
        a = list(args)
        if a and not isinstance(a[0], int):
            a.pop(0)  # pico_i2c_lcd style: I2cLcd(i2c, addr, rows, cols)
        self.addr = a[0] if len(a) > 0 else kw.get('addr', 0x27)
        self.rows = a[1] if len(a) > 1 else kw.get('rows', 2)
        self.cols = a[2] if len(a) > 2 else kw.get('cols', 16)
        if not J.i2c_has(self.addr):
            raise OSError(19, 'no I2C device at 0x%02X - wire the LCD: SDA, SCL, VCC to 5V, GND' % self.addr)
        self._bl = _BL
        self.col = 0
        self.row = 0
        for n in (0x03, 0x03, 0x03, 0x02):
            self._nibble(n << 4, 0)
            time.sleep(0.005)
        self._cmd(0x28)  # 4-bit, 2 lines, 5x8 dots
        self._cmd(0x0C)  # display on, cursor off
        self._cmd(0x06)  # entry mode: increment
        self.clear()

    def _write(self, data):
        J.i2c_write(self.addr, bytes(data).hex())

    def _nibble(self, hi, rs):
        b = (hi & 0xF0) | self._bl | rs
        self._write([b | _EN, b])

    def _send(self, v, rs):
        b1 = (v & 0xF0) | self._bl | rs
        b2 = ((v << 4) & 0xF0) | self._bl | rs
        self._write([b1 | _EN, b1, b2 | _EN, b2])

    def _cmd(self, c):
        self._send(c, 0)

    def clear(self):
        self._cmd(0x01)
        self.col = 0
        self.row = 0

    def home(self):
        self._cmd(0x02)
        self.col = 0
        self.row = 0

    def move_to(self, col, row):
        self.col = col
        self.row = row
        base = (0x00, 0x40, self.cols, 0x40 + self.cols)[row % 4]
        self._cmd(0x80 | (base + col))

    def putchar(self, ch):
        if ch == '\\n':
            self.move_to(0, (self.row + 1) % self.rows)
            return
        self._send(ord(ch) if isinstance(ch, str) else ch, _RS)
        self.col += 1
        if self.col >= self.cols:
            self.move_to(0, (self.row + 1) % self.rows)

    def putstr(self, s):
        for ch in str(s):
            self.putchar(ch)

    def custom_char(self, location, charmap):
        self._cmd(0x40 | ((location & 7) << 3))
        for b in charmap:
            self._send(b, _RS)
        self.move_to(self.col, self.row)

    def backlight_on(self):
        self._bl = _BL
        self._write([self._bl])

    def backlight_off(self):
        self._bl = 0
        self._write([0])

    def display_on(self):
        self._cmd(0x0C)

    def display_off(self):
        self._cmd(0x08)

    def show_cursor(self):
        self._cmd(0x0E)

    def hide_cursor(self):
        self._cmd(0x0C)

    def blink_cursor_on(self):
        self._cmd(0x0F)

    def blink_cursor_off(self):
        self._cmd(0x0E)

    # RPLCD-style names
    def write_string(self, s):
        self.putstr(s)

    @property
    def cursor_pos(self):
        return (self.row, self.col)

    @cursor_pos.setter
    def cursor_pos(self, rc):
        self.move_to(rc[1], rc[0])

    def close(self, clear=False):
        if clear:
            self.clear()
`;var Zc=`# smbus2 for the RaptiAuto virtual Raspberry Pi: I2C bus 1 (GPIO2 = SDA, GPIO3 = SCL).
# Talks to the parts on the circuit canvas: an I2C LCD backpack, or an Arduino running
# Wire.begin(address) as a slave (its onReceive / onRequest handlers answer).
#     from smbus2 import SMBus
#     bus = SMBus(1)
#     bus.write_i2c_block_data(8, 0, [90, 1])
#     data = bus.read_i2c_block_data(8, 0, 2)
import _rpi_js as J


def _check(addr):
    if not J.i2c_has(addr):
        raise OSError(121, 'Remote I/O error - no I2C device at 0x%02X (check SDA = GPIO2, SCL = GPIO3, GND)' % addr)


class i2c_msg:
    def __init__(self, addr, data, read):
        self.addr = addr
        self.buf = list(data)
        self.read_ = read
        self.len = len(self.buf)

    @staticmethod
    def write(addr, buf):
        return i2c_msg(addr, buf, False)

    @staticmethod
    def read(addr, length):
        return i2c_msg(addr, [0] * length, True)

    def __iter__(self):
        return iter(self.buf)

    def __len__(self):
        return self.len


class SMBus:
    def __init__(self, bus=1, force=False):
        if bus is not None and bus not in (1, '/dev/i2c-1'):
            raise FileNotFoundError(2, "No such file or directory: '/dev/i2c-%s'" % bus)
        self.bus = 1

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def open(self, bus):
        self.bus = bus

    def close(self):
        pass

    def write_quick(self, addr, force=None):
        _check(addr)

    def write_byte(self, addr, value, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([value & 255]).hex())

    def write_byte_data(self, addr, register, value, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255, value & 255]).hex())

    def write_word_data(self, addr, register, value, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255, value & 255, (value >> 8) & 255]).hex())

    def write_block_data(self, addr, register, data, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255, len(data)] + [d & 255 for d in data]).hex())

    def write_i2c_block_data(self, addr, register, data, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255] + [d & 255 for d in data]).hex())

    def read_byte(self, addr, force=None):
        _check(addr)
        return bytes.fromhex(J.i2c_read(addr, 1))[0]

    def read_byte_data(self, addr, register, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255]).hex())
        return bytes.fromhex(J.i2c_read(addr, 1))[0]

    def read_word_data(self, addr, register, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255]).hex())
        b = bytes.fromhex(J.i2c_read(addr, 2))
        return b[0] | (b[1] << 8)

    def read_i2c_block_data(self, addr, register, length, force=None):
        _check(addr)
        J.i2c_write(addr, bytes([register & 255]).hex())
        return list(bytes.fromhex(J.i2c_read(addr, length)))

    def i2c_rdwr(self, *msgs):
        for m in msgs:
            _check(m.addr)
            if m.read_:
                m.buf = list(bytes.fromhex(J.i2c_read(m.addr, m.len)))
            else:
                J.i2c_write(m.addr, bytes(m.buf).hex())

    def scan(self):
        s = J.i2c_scan()
        return [int(a) for a in s.split(',')] if s else []
`;var ed=`# smbus (python3-smbus) on the RaptiAuto virtual Raspberry Pi: the same bus as smbus2.
from smbus2 import SMBus
`;var td=`# pyserial for the RaptiAuto virtual Raspberry Pi: the GPIO UART /dev/serial0 (GPIO14 = TXD,
# GPIO15 = RXD). Wire TXD to an Arduino's RX (D0), RXD to its TX (D1) and GND to GND.
#     import serial
#     ser = serial.Serial('/dev/serial0', 9600, timeout=1)
#     ser.write(b'L1\\n')
#     print(ser.readline())
import _rpi_js as J
import time as _time

PARITY_NONE = 'N'
PARITY_EVEN = 'E'
PARITY_ODD = 'O'
STOPBITS_ONE = 1
STOPBITS_TWO = 2
EIGHTBITS = 8
SEVENBITS = 7


class SerialException(OSError):
    pass


class SerialTimeoutException(SerialException):
    pass


_PORTS = ('/dev/serial0', '/dev/ttyAMA0', '/dev/ttyS0', 'serial0')


class Serial:
    def __init__(self, port=None, baudrate=9600, bytesize=8, parity='N', stopbits=1, timeout=None, **kw):
        self.baudrate = baudrate
        self.bytesize = bytesize
        self.parity = parity
        self.stopbits = stopbits
        self.timeout = timeout
        self._port = None
        self.is_open = False
        self.port = port
        if port is not None:
            self.open()

    def open(self):
        if self.port not in _PORTS:
            if str(self.port).startswith('/dev/ttyUSB') or str(self.port).startswith('/dev/ttyACM'):
                raise SerialException(2, "could not open port %s: no USB serial device - use /dev/serial0 (GPIO14 TXD, GPIO15 RXD)" % self.port)
            raise SerialException(2, "could not open port %s: [Errno 2] No such file or directory" % self.port)
        self._port = 'serial0'
        self.is_open = True

    def close(self):
        self.is_open = False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def _need(self):
        if not self.is_open:
            raise SerialException('Attempting to use a port that is not open')

    @property
    def in_waiting(self):
        self._need()
        return J.uart_any(self._port)

    def inWaiting(self):
        return self.in_waiting

    def write(self, data):
        self._need()
        if isinstance(data, str):
            raise TypeError('unicode strings are not supported, please encode to bytes: %r' % data)
        J.uart_write(self._port, bytes(data).decode('utf-8', 'ignore'))
        return len(data)

    def flush(self):
        pass

    def reset_input_buffer(self):
        J.uart_read(self._port, -1)

    flushInput = reset_input_buffer

    def reset_output_buffer(self):
        pass

    def _wait(self, ready):
        if ready():
            return True
        if self.timeout == 0:
            return False
        end = None if self.timeout is None else _time.ticks_add(_time.ticks_ms(), int(self.timeout * 1000))
        while not ready():
            if end is not None and _time.ticks_diff(end, _time.ticks_ms()) <= 0:
                return False
            _time.sleep_ms(5)
        return True

    def read(self, size=1):
        self._need()
        self._wait(lambda: J.uart_any(self._port) >= size)
        return J.uart_read(self._port, size).encode()

    def read_all(self):
        self._need()
        return J.uart_read(self._port, -1).encode()

    def readline(self, size=-1):
        self._need()
        self._wait(lambda: J.uart_has_line(self._port))
        return J.uart_readline(self._port, 1).encode()

    def readlines(self):
        out = []
        while True:
            line = self.readline()
            if not line:
                return out
            out.append(line)

    def read_until(self, expected=b'\\n', size=None):
        if expected == b'\\n':
            return self.readline()
        return self.read(size or 1)

    def __repr__(self):
        return "Serial<id=0x0, open=%s>(port='%s', baudrate=%d, bytesize=%d, parity='%s', stopbits=%d, timeout=%s)" % (self.is_open, self.port, self.baudrate, self.bytesize, self.parity, self.stopbits, self.timeout)
`;var id=`# RaptiAuto virtual network (Python side): one blocking HTTP call, one server poll. The network lives in
# JavaScript (module _rpi_js); every wait sleeps a little so the screen keeps running.
import _rpi_js as J
import json
import time

# True while threading.Thread.start() runs its target: servers started there keep running in the
# background (polled between the sleeps of the main program) instead of blocking
BG = [False]


def online():
    return bool(J.net_online())


def to_text(body):
    if body is None:
        return ''
    if isinstance(body, (bytes, bytearray)):
        try:
            return bytes(body).decode('utf-8')
        except Exception:
            return ''.join(chr(c) for c in body)
    return str(body)


def to_bytes(text):
    return text.encode('utf-8') if isinstance(text, str) else bytes(text)


def http(method, url, headers=None, body='', timeout=20):
    """Send one HTTP request; returns {'status', 'statusText', 'headers', 'body', 'ms'} or raises OSError."""
    if not J.net_online():
        raise OSError(101, 'Network is unreachable (the Pi has no Wi-Fi connection)')
    rid = J.net_request(method.upper(), url, json.dumps(headers or {}), to_text(body))
    t0 = time.ticks_ms()
    while True:
        r = J.net_poll(rid)
        if r:
            break
        if time.ticks_diff(time.ticks_ms(), t0) > timeout * 1000:
            raise OSError(110, 'Connection timed out')
        time.sleep(0.01)
    res = json.loads(r)
    if res.get('failed'):
        code = res.get('error', 'ERR_FAILED')
        if code == 'ERR_NAME_NOT_RESOLVED':
            raise OSError(-2, 'Name or service not known: ' + url)
        if code == 'ERR_CONNECTION_REFUSED':
            raise OSError(111, 'Connection refused: ' + url)
        raise OSError(101, '%s (%s)' % (res.get('statusText', code), code))
    # a little round-trip time, like a real connection
    ms = res.get('ms', 0)
    if ms:
        time.sleep(min(ms, 250) / 1000)
    return res
`;var sd=`# requests for the RaptiAuto virtual Raspberry Pi / Pico W: the usual calls on the simulated network.
#     import requests
#     r = requests.get("http://wttr.in/Dhaka?format=3")
#     print(r.status_code, r.text)
#     data = requests.get("http://api.open-meteo.com/v1/forecast?latitude=23.8&longitude=90.4&current_weather=true").json()
import json as _json
import _netio
from urllib.parse import urlencode as _urlencode


class RequestException(OSError):
    pass


class ConnectionError(RequestException):
    pass


class Timeout(RequestException):
    pass


class HTTPError(RequestException):
    def __init__(self, *a, response=None):
        super().__init__(*a)
        self.response = response


class InvalidURL(RequestException):
    pass


class _Headers(dict):
    """Case-insensitive headers."""
    def __init__(self, d=None):
        super().__init__()
        for k, v in (d or {}).items():
            self[k] = v

    def __setitem__(self, k, v):
        super().__setitem__(k.lower(), v)

    def __getitem__(self, k):
        return super().__getitem__(k.lower())

    def get(self, k, default=None):
        return super().get(k.lower(), default)

    def __contains__(self, k):
        return super().__contains__(k.lower())


class Response:
    def __init__(self, res, url):
        self.status_code = res['status']
        self.reason = res.get('statusText', '')
        self.headers = _Headers(res.get('headers', {}))
        self._text = res.get('body', '')
        self.url = url
        self.encoding = 'utf-8'
        self.elapsed = res.get('ms', 0)
        self.history = []
        self.cookies = {}

    @property
    def text(self):
        return self._text

    @property
    def content(self):
        return self._text.encode('utf-8')

    @property
    def ok(self):
        return self.status_code < 400

    def json(self, **kw):
        return _json.loads(self._text)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise HTTPError('%d %s Error: %s for url: %s' % (self.status_code, 'Client' if self.status_code < 500 else 'Server', self.reason, self.url), response=self)

    def iter_content(self, chunk_size=1024):
        c = self.content
        for i in range(0, len(c), chunk_size):
            yield c[i:i + chunk_size]

    def iter_lines(self):
        for line in self._text.split('\\n'):
            yield line

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __bool__(self):
        return self.ok

    def __repr__(self):
        return '<Response [%d]>' % self.status_code


def _b64(s):
    import base64
    return base64.b64encode(s.encode()).decode()


def request(method, url, params=None, data=None, headers=None, json=None, timeout=None, auth=None, allow_redirects=True, **kw):
    if not url.startswith('http://') and not url.startswith('https://'):
        raise InvalidURL("Invalid URL %r: No scheme supplied. Perhaps you meant https://%s?" % (url, url))
    h = {'User-Agent': 'python-requests/2.31.0', 'Accept': '*/*'}
    h.update(headers or {})
    if params:
        url += ('&' if '?' in url else '?') + _urlencode(params)
    body = ''
    if json is not None:
        body = _json.dumps(json)
        h.setdefault('Content-Type', 'application/json')
    elif data is not None:
        if isinstance(data, dict):
            body = _urlencode(data)
            h.setdefault('Content-Type', 'application/x-www-form-urlencoded')
        else:
            body = _netio.to_text(data)
    if auth:
        h['Authorization'] = 'Basic ' + _b64('%s:%s' % auth)
    try:
        res = _netio.http(method, url, h, body, timeout or 20)
    except OSError as e:
        if len(e.args) and e.args[0] == 110:
            raise Timeout(*e.args)
        raise ConnectionError(*e.args)
    r = Response(res, url)
    loc = r.headers.get('location')
    if allow_redirects and 300 <= r.status_code < 400 and loc:
        from urllib.parse import urljoin
        return request('GET', urljoin(url, loc), headers=headers, timeout=timeout)
    return r


def get(url, params=None, **kw):
    return request('GET', url, params=params, **kw)


def post(url, data=None, json=None, **kw):
    return request('POST', url, data=data, json=json, **kw)


def put(url, data=None, **kw):
    return request('PUT', url, data=data, **kw)


def patch(url, data=None, **kw):
    return request('PATCH', url, data=data, **kw)


def delete(url, **kw):
    return request('DELETE', url, **kw)


def head(url, **kw):
    return request('HEAD', url, **kw)


class Session:
    def __init__(self):
        self.headers = {}
        self.auth = None
        self.cookies = {}

    def request(self, method, url, **kw):
        h = dict(self.headers)
        h.update(kw.pop('headers', None) or {})
        if self.auth and 'auth' not in kw:
            kw['auth'] = self.auth
        return request(method, url, headers=h, **kw)

    def get(self, url, **kw):
        return self.request('GET', url, **kw)

    def post(self, url, **kw):
        return self.request('POST', url, **kw)

    def put(self, url, **kw):
        return self.request('PUT', url, **kw)

    def delete(self, url, **kw):
        return self.request('DELETE', url, **kw)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass


class codes:
    ok = 200
    created = 201
    not_found = 404
    internal_server_error = 500


_RE, _CE, _TO, _HE, _IU = RequestException, ConnectionError, Timeout, HTTPError, InvalidURL


class exceptions:
    RequestException = _RE
    ConnectionError = _CE
    Timeout = _TO
    ConnectTimeout = _TO
    ReadTimeout = _TO
    HTTPError = _HE
    InvalidURL = _IU

`;var rd=`# urequests (MicroPython): the same calls as requests with the small Response of MicroPython.
#     import urequests
#     r = urequests.get(url); print(r.text); r.close()
import requests as _r

Response = _r.Response


def request(method, url, data=None, json=None, headers=None, stream=None, parse_headers=True, **kw):
    return _r.request(method, url, data=data, json=json, headers=headers)


def get(url, **kw):
    return request('GET', url, **kw)


def post(url, **kw):
    return request('POST', url, **kw)


def put(url, **kw):
    return request('PUT', url, **kw)


def patch(url, **kw):
    return request('PATCH', url, **kw)


def delete(url, **kw):
    return request('DELETE', url, **kw)


def head(url, **kw):
    return request('HEAD', url, **kw)
`;var nd="";var od=`# urllib.parse: quoting, query strings and URL splitting.
_SAFE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-~'


def quote(s, safe='/'):
    if isinstance(s, str):
        s = s.encode('utf-8')
    out = []
    for c in s:
        ch = chr(c)
        if ch in _SAFE or ch in safe:
            out.append(ch)
        else:
            out.append('%%%02X' % c)
    return ''.join(out)


def quote_plus(s, safe=''):
    return quote(s, safe + ' ').replace(' ', '+')


def unquote(s):
    if '%' not in s:
        return s
    b = bytearray()
    i = 0
    while i < len(s):
        c = s[i]
        if c == '%' and i + 3 <= len(s):
            try:
                b.append(int(s[i + 1:i + 3], 16))
                i += 3
                continue
            except ValueError:
                pass
        b.extend(c.encode('utf-8'))
        i += 1
    return bytes(b).decode('utf-8')


def unquote_plus(s):
    return unquote(s.replace('+', ' '))


def urlencode(query, doseq=False, **kw):
    items = query.items() if hasattr(query, 'items') else query
    parts = []
    for k, v in items:
        if doseq and isinstance(v, (list, tuple)):
            for x in v:
                parts.append(quote_plus(str(k)) + '=' + quote_plus(str(x)))
        else:
            parts.append(quote_plus(str(k)) + '=' + quote_plus(str(v)))
    return '&'.join(parts)


def parse_qs(qs, **kw):
    out = {}
    for part in qs.split('&'):
        if not part:
            continue
        k, _, v = part.partition('=')
        out.setdefault(unquote_plus(k), []).append(unquote_plus(v))
    return out


def parse_qsl(qs, **kw):
    return [(k, v) for k, vs in parse_qs(qs).items() for v in vs]


class ParseResult:
    """urlparse() result: a 6-item sequence with named parts (MicroPython can't subclass tuple)."""
    def __init__(self, scheme, netloc, path, params, query, fragment):
        self.scheme, self.netloc, self.path, self.params, self.query, self.fragment = scheme, netloc, path, params, query, fragment

    def _t(self):
        return (self.scheme, self.netloc, self.path, self.params, self.query, self.fragment)

    def __iter__(self):
        return iter(self._t())

    def __getitem__(self, i):
        return self._t()[i]

    def __len__(self):
        return 6

    def __eq__(self, o):
        return tuple(self) == tuple(o)

    def __repr__(self):
        return "ParseResult(scheme=%r, netloc=%r, path=%r, params=%r, query=%r, fragment=%r)" % self._t()

    @property
    def hostname(self):
        h = self.netloc.rpartition('@')[2].partition(':')[0]
        return h or None

    @property
    def port(self):
        p = self.netloc.rpartition(':')[2]
        return int(p) if self.netloc.count(':') and p.isdigit() else None

    def geturl(self):
        return urlunparse(self)


def urlparse(url, scheme=''):
    fragment = ''
    query = ''
    if '#' in url:
        url, _, fragment = url.partition('#')
    if '?' in url:
        url, _, query = url.partition('?')
    netloc = ''
    if '://' in url:
        scheme, _, rest = url.partition('://')
        if '/' in rest:
            netloc, _, path = rest.partition('/')
            path = '/' + path
        else:
            netloc, path = rest, ''
    else:
        path = url
    return ParseResult(scheme, netloc, path, '', query, fragment)


def urlunparse(p):
    scheme, netloc, path, params, query, fragment = p
    u = path
    if netloc:
        u = scheme + '://' + netloc + path if scheme else '//' + netloc + path
    if query:
        u += '?' + query
    if fragment:
        u += '#' + fragment
    return u


def urljoin(base, url):
    if '://' in url:
        return url
    b = urlparse(base)
    if url.startswith('//'):
        return b.scheme + ':' + url
    if url.startswith('/'):
        return b.scheme + '://' + b.netloc + url
    path = b.path.rsplit('/', 1)[0] + '/' + url if '/' in b.path else '/' + url
    return b.scheme + '://' + b.netloc + path
`;var ld=`class URLError(OSError):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


class HTTPError(URLError):
    def __init__(self, url, code, msg, hdrs, fp):
        super().__init__(msg)
        self.url = url
        self.code = code
        self.msg = msg
        self.headers = hdrs
        self.fp = fp

    def read(self):
        return self.fp.read() if self.fp else b''

    def __str__(self):
        return 'HTTP Error %d: %s' % (self.code, self.msg)
`;var ad=`# urllib.request.urlopen on the simulated network.
#     from urllib.request import urlopen
#     print(urlopen("http://wttr.in/Dhaka?format=3").read().decode())
import _netio
from urllib.error import URLError, HTTPError


class Request:
    def __init__(self, url, data=None, headers=None, method=None, **kw):
        self.full_url = url
        self.data = data
        self.headers = dict(headers or {})
        self.method = method or ('POST' if data is not None else 'GET')

    def add_header(self, k, v):
        self.headers[k] = v


class _Resp:
    def __init__(self, res, url):
        self.status = res['status']
        self.code = res['status']
        self.reason = res.get('statusText', '')
        self.headers = res.get('headers', {})
        self._b = res.get('body', '').encode('utf-8')
        self._url = url
        self._p = 0

    def read(self, n=-1):
        if n is None or n < 0:
            d = self._b[self._p:]
            self._p = len(self._b)
        else:
            d = self._b[self._p:self._p + n]
            self._p += len(d)
        return d

    def readline(self):
        i = self._b.find(b'\\n', self._p)
        j = len(self._b) if i < 0 else i + 1
        d = self._b[self._p:j]
        self._p = j
        return d

    def getcode(self):
        return self.status

    def geturl(self):
        return self._url

    def info(self):
        return self.headers

    def getheader(self, k, default=None):
        return self.headers.get(k.lower(), default)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __iter__(self):
        while True:
            l = self.readline()
            if not l:
                break
            yield l


def urlopen(url, data=None, timeout=20, **kw):
    if isinstance(url, Request):
        req = url
    else:
        req = Request(url, data)
    h = {'User-Agent': 'Python-urllib/3.11'}
    h.update(req.headers)
    if req.data is not None and 'Content-Type' not in h:
        h['Content-Type'] = 'application/x-www-form-urlencoded'
    try:
        res = _netio.http(req.method, req.full_url, h, req.data if req.data is not None else '', timeout)
    except OSError as e:
        raise URLError(e)
    if res['status'] >= 400:
        raise HTTPError(req.full_url, res['status'], res.get('statusText', ''), res.get('headers', {}), _Resp(res, req.full_url))
    return _Resp(res, req.full_url)


def urlretrieve(url, filename=None, **kw):
    r = urlopen(url)
    if filename:
        with open(filename, 'wb') as f:
            f.write(r.read())
    return filename, r.headers
`;var hd=`# socket for the RaptiAuto virtual Raspberry Pi / Pico W. TCP sockets speak HTTP: a client socket sends
# a request (GET / HTTP/1.1 \u2026) to a host on the simulated network and reads the answer; a server socket
# (bind / listen / accept) receives the requests a browser sends to this device and replies. That is
# what Pico W "web server" and Raspberry Pi socket examples need.
import _rpi_js as J
import json
import time
import _netio

def _title(k):
    """str.title() for header names (MicroPython has none): content-type -> Content-Type."""
    return '-'.join(p[:1].upper() + p[1:] for p in k.split('-'))

AF_INET = 2
AF_INET6 = 10
SOCK_STREAM = 1
SOCK_DGRAM = 2
SOL_SOCKET = 1
SO_REUSEADDR = 2
SO_BROADCAST = 6
IPPROTO_TCP = 6
IPPROTO_UDP = 17
SHUT_RD = 0
SHUT_WR = 1
SHUT_RDWR = 2
error = OSError
timeout = OSError
gaierror = OSError
herror = OSError

_default_timeout = [None]


def setdefaulttimeout(t):
    _default_timeout[0] = t


def getdefaulttimeout():
    return _default_timeout[0]


def gethostname():
    return J.net_hostname()


def gethostbyname(host):
    ip = J.net_resolve(host)
    if not ip:
        raise gaierror(-2, 'Name or service not known')
    return ip


def getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    ip = gethostbyname(host)
    return [(AF_INET, SOCK_STREAM, 6, '', (ip, int(port) if port else 0))]


def inet_aton(s):
    return bytes(int(x) for x in s.split('.'))


def inet_ntoa(b):
    return '.'.join(str(x) for x in b)


def _my_ip():
    return J.net_ip() or '0.0.0.0'


class _Conn:
    """The connection a server socket hands out: recv() the request, send() the reply, close() delivers it."""
    def __init__(self, rid, addr):
        info = json.loads(J.net_req(rid))
        self._id = rid
        self._addr = addr
        path = info.get('path', '/')
        lines = ['%s %s HTTP/1.1' % (info.get('method', 'GET'), path), 'Host: ' + info.get('host', '')]
        for k, v in (info.get('headers') or {}).items():
            if k != 'host':
                lines.append('%s: %s' % (_title(k), v))
        body = info.get('body', '')
        self._in = ('\\r\\n'.join(lines) + '\\r\\n\\r\\n' + body).encode('utf-8')
        self._out = b''
        self._closed = False

    def recv(self, n=1024):
        d = self._in[:n]
        self._in = self._in[n:]
        return d

    def recvfrom(self, n=1024):
        return self.recv(n), self._addr

    def send(self, data):
        if isinstance(data, str):
            data = data.encode('utf-8')
        self._out += bytes(data)
        return len(data)

    def sendall(self, data):
        self.send(data)

    def write(self, data):
        return self.send(data)

    def read(self, n=-1):
        return self.recv(n if n and n > 0 else 100000)

    def readline(self):
        i = self._in.find(b'\\n')
        j = len(self._in) if i < 0 else i + 1
        d = self._in[:j]
        self._in = self._in[j:]
        return d

    def settimeout(self, t):
        pass

    def setblocking(self, f):
        pass

    def makefile(self, mode='rwb', *a, **k):
        return self

    def fileno(self):
        return self._id

    def close(self):
        if self._closed:
            return
        self._closed = True
        raw = self._out
        status, headers, body = 200, {}, b''
        if raw:
            head, _, body = raw.partition(b'\\r\\n\\r\\n')
            lines = head.decode('utf-8', 'replace').split('\\r\\n')
            parts = lines[0].split(' ', 2)
            if len(parts) > 1 and parts[1].isdigit():
                status = int(parts[1])
            for l in lines[1:]:
                k, _, v = l.partition(':')
                if k:
                    headers[k.strip().lower()] = v.strip()
        else:
            status = 500
        J.net_respond(self._id, status, json.dumps(headers), body.decode('utf-8', 'replace'))

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


class socket:
    def __init__(self, family=AF_INET, type=SOCK_STREAM, proto=0, fileno=None):
        self.family = family
        self.type = type
        self._timeout = _default_timeout[0]
        self._block = True
        self._port = None
        self._listening = False
        self._peer = None
        self._buf = b''
        self._out = b''
        self._resp = None
        self._pos = 0
        self._closed = False

    # ---- options
    def setsockopt(self, *a):
        pass

    def settimeout(self, t):
        self._timeout = t

    def gettimeout(self):
        return self._timeout

    def setblocking(self, flag):
        self._block = bool(flag)
        self._timeout = None if flag else 0

    def getsockname(self):
        return (_my_ip(), self._port or 0)

    # ---- server
    def bind(self, addr):
        self._port = int(addr[1])

    def listen(self, backlog=5):
        if self._port is None:
            raise OSError(22, 'Invalid argument')
        r = J.net_listen(self._port)
        if r == -1:
            raise OSError(98, 'Address already in use')
        if r == 0:
            raise OSError(101, 'Network is unreachable (no Wi-Fi connection)')
        self._listening = True

    def accept(self):
        t0 = time.ticks_ms()
        while True:
            rid = J.net_accept(self._port)
            if rid:
                return _Conn(rid, ('192.168.1.2', 50000 + rid % 1000)), ('192.168.1.2', 50000 + rid % 1000)
            if self._timeout == 0:
                raise OSError(11, 'EAGAIN')
            if self._timeout is not None and time.ticks_diff(time.ticks_ms(), t0) > self._timeout * 1000:
                raise OSError(110, 'timed out')
            time.sleep(0.02)

    # ---- client
    def connect(self, addr):
        host, port = addr[0], int(addr[1])
        if not J.net_online():
            raise OSError(101, 'Network is unreachable')
        if not J.net_resolve(host):
            raise gaierror(-2, 'Name or service not known')
        self._peer = (host, port)

    def _flush(self):
        # one HTTP request is complete: send it and keep the answer for recv()
        raw = self._out
        self._out = b''
        head, _, body = raw.partition(b'\\r\\n\\r\\n')
        lines = head.decode('utf-8', 'replace').split('\\r\\n')
        parts = lines[0].split(' ')
        method = parts[0]
        path = parts[1] if len(parts) > 1 else '/'
        headers = {}
        for l in lines[1:]:
            k, _, v = l.partition(':')
            if k:
                headers[k.strip()] = v.strip()
        host, port = self._peer
        scheme = 'https' if port == 443 else 'http'
        url = '%s://%s%s%s' % (scheme, host, '' if port in (80, 443) else ':%d' % port, path)
        res = _netio.http(method, url, headers, body)
        out = 'HTTP/1.1 %d %s\\r\\n' % (res['status'], res.get('statusText', ''))
        for k, v in res.get('headers', {}).items():
            out += '%s: %s\\r\\n' % (_title(k), v)
        out += 'Connection: close\\r\\n\\r\\n' + res.get('body', '')
        self._buf = out.encode('utf-8')

    def send(self, data):
        if self._peer is None:
            raise OSError(107, 'Transport endpoint is not connected')
        if isinstance(data, str):
            data = data.encode('utf-8')
        self._out += bytes(data)
        head, sep, body = self._out.partition(b'\\r\\n\\r\\n')
        if sep:
            n = 0
            for l in head.split(b'\\r\\n'):
                if l.lower().startswith(b'content-length:'):
                    n = int(l.split(b':')[1])
            if len(body) >= n:
                self._flush()
        return len(data)

    def sendall(self, data):
        self.send(data)

    def recv(self, n=1024):
        if self._out:
            self._flush()
        d = self._buf[:n]
        self._buf = self._buf[n:]
        return d

    def recv_into(self, buf, n=0):
        d = self.recv(n or len(buf))
        buf[:len(d)] = d
        return len(d)

    def sendto(self, data, addr):
        return len(data)

    def recvfrom(self, n=1024):
        return self.recv(n), self._peer

    def makefile(self, mode='rb', *a, **k):
        return self

    def read(self, n=-1):
        return self.recv(n if n and n > 0 else 100000)

    def readline(self):
        if self._out:
            self._flush()
        i = self._buf.find(b'\\n')
        j = len(self._buf) if i < 0 else i + 1
        d = self._buf[:j]
        self._buf = self._buf[j:]
        return d

    def write(self, data):
        return self.send(data)

    def shutdown(self, how):
        pass

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._listening and self._port is not None:
            J.net_unlisten(self._port)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def create_connection(addr, timeout=None, **kw):
    s = socket()
    s.connect(addr)
    return s
`;var fd=`class HTTPStatus:
    OK = 200
    CREATED = 201
    NO_CONTENT = 204
    MOVED_PERMANENTLY = 301
    FOUND = 302
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    METHOD_NOT_ALLOWED = 405
    INTERNAL_SERVER_ERROR = 500
`;var cd=`# http.server on the simulated network: a web server on the Raspberry Pi, reachable from Chromium
# (http://localhost:8000/) and from other devices (http://<pi ip>:8000/).
#     from http.server import HTTPServer, BaseHTTPRequestHandler
#     class H(BaseHTTPRequestHandler):
#         def do_GET(self):
#             self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers()
#             self.wfile.write(b"<h1>Hello</h1>")
#     HTTPServer(("", 8000), H).serve_forever()
import json
import time
import _rpi_js as J
import _netio
from urllib.parse import urlparse

_REASON = {200: 'OK', 201: 'Created', 204: 'No Content', 301: 'Moved Permanently', 302: 'Found', 304: 'Not Modified', 400: 'Bad Request',
           401: 'Unauthorized', 403: 'Forbidden', 404: 'Not Found', 405: 'Method Not Allowed', 500: 'Internal Server Error'}


class _Headers:
    def __init__(self, d):
        self._d = {}
        for k, v in d.items():
            self._d[k.lower()] = v

    def get(self, k, default=None):
        return self._d.get(k.lower(), default)

    def __getitem__(self, k):
        return self._d[k.lower()]

    def __contains__(self, k):
        return k.lower() in self._d

    def items(self):
        return self._d.items()

    def keys(self):
        return self._d.keys()

    def get_content_type(self):
        return self._d.get('content-type', 'text/plain').split(';')[0]


class _In:
    def __init__(self, b):
        self._b = b
        self._p = 0

    def read(self, n=-1):
        if n is None or n < 0:
            d = self._b[self._p:]
        else:
            d = self._b[self._p:self._p + n]
        self._p += len(d)
        return d

    def readline(self):
        i = self._b.find(b'\\n', self._p)
        j = len(self._b) if i < 0 else i + 1
        d = self._b[self._p:j]
        self._p = j
        return d


class _Out:
    def __init__(self):
        self.data = b''

    def write(self, b):
        if isinstance(b, str):
            b = b.encode('utf-8')
        self.data += bytes(b)
        return len(b)

    def flush(self):
        pass


class BaseHTTPRequestHandler:
    server_version = 'BaseHTTP/0.6'
    sys_version = 'Python/3.11'
    protocol_version = 'HTTP/1.0'
    default_request_version = 'HTTP/0.9'

    def __init__(self, info, server):
        self.server = server
        self.client_address = ('192.168.1.2', 50000)
        self.command = info.get('method', 'GET')
        self.path = info.get('path', '/')
        self.request_version = 'HTTP/1.1'
        self.headers = _Headers(info.get('headers') or {})
        self.rfile = _In(info.get('body', '').encode('utf-8'))
        self.wfile = _Out()
        self._status = 200
        self._hdrs = []
        self._head_done = False
        self.requestline = '%s %s HTTP/1.1' % (self.command, self.path)

    def send_response(self, code, message=None):
        self._status = code
        self._msg = message

    def send_response_only(self, code, message=None):
        self._status = code

    def send_header(self, k, v):
        self._hdrs.append((k, str(v)))

    def end_headers(self):
        self._head_done = True

    def send_error(self, code, message=None, explain=None):
        msg = message or _REASON.get(code, '')
        body = '<!DOCTYPE HTML><html><head><title>Error response</title></head><body><h1>Error response</h1><p>Error code: %d</p><p>Message: %s.</p></body></html>' % (code, msg)
        self.send_response(code, msg)
        self.send_header('Content-Type', 'text/html;charset=utf-8')
        self.end_headers()
        self.wfile.write(body.encode('utf-8'))

    def log_message(self, fmt, *args):
        print('%s - - [%s] %s' % (self.client_address[0], time.strftime('%d/%b/%Y %H:%M:%S'), fmt % args))

    def log_request(self, code='-', size='-'):
        self.log_message('"%s" %s %s', self.requestline, str(code), str(size))

    def date_time_string(self, ts=None):
        return time.strftime('%a, %d %b %Y %H:%M:%S GMT')

    def address_string(self):
        return self.client_address[0]

    def handle_one(self):
        m = getattr(self, 'do_' + self.command, None)
        if m is None:
            self.send_error(501, 'Unsupported method (%r)' % self.command)
        else:
            try:
                m()
            except Exception as e:
                import sys
                sys.print_exception(e)
                if not self.wfile.data:
                    self.send_error(500, 'Internal Server Error')
        self.log_request(self._status)

    def respond(self, rid):
        hdrs = {}
        for k, v in self._hdrs:
            hdrs[k.lower()] = v
        J.net_respond(rid, self._status, json.dumps(hdrs), self.wfile.data.decode('utf-8', 'replace'))


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    """Serves the files of the current folder."""
    def do_GET(self):
        import os
        path = urlparse(self.path).path
        fs = '.' + path
        if fs.endswith('/'):
            if 'index.html' in os.listdir(fs):
                fs += 'index.html'
            else:
                names = sorted(os.listdir(fs))
                body = '<!DOCTYPE HTML><html><head><title>Directory listing for %s</title></head><body><h1>Directory listing for %s</h1><hr><ul>%s</ul><hr></body></html>' % (path, path, ''.join('<li><a href="%s%s">%s</a></li>' % (path, n, n) for n in names))
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(body.encode('utf-8'))
                return
        try:
            with open(fs, 'rb') as f:
                data = f.read()
        except OSError:
            self.send_error(404, 'File not found')
            return
        ctype = 'text/html' if fs.endswith('.html') else 'text/css' if fs.endswith('.css') else 'application/javascript' if fs.endswith('.js') else 'application/json' if fs.endswith('.json') else 'text/plain'
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)


class HTTPServer:
    allow_reuse_address = True

    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        self.server_address = (server_address[0] or '0.0.0.0', server_address[1])
        self.server_name = 'raspberrypi'
        self.server_port = server_address[1]
        self.RequestHandlerClass = RequestHandlerClass
        self._stop = False
        self._bg = None
        if bind_and_activate:
            r = J.net_listen(self.server_port)
            if r == -1:
                raise OSError(98, 'Address already in use')
            if r == 0:
                raise OSError(101, 'Network is unreachable (the Pi has no Wi-Fi / network connection)')

    def _serve_one(self):
        rid = J.net_accept(self.server_port)
        if not rid:
            return False
        info = json.loads(J.net_req(rid))
        h = self.RequestHandlerClass(info, self)
        h.handle_one()
        h.respond(rid)
        return True

    def handle_request(self):
        while not self._serve_one():
            time.sleep(0.02)

    def serve_forever(self, poll_interval=0.5):
        self._stop = False
        if _netio.BG[0]:
            import _rpi_hw
            self._bg = _rpi_hw.every(20, self._serve_one)
            return
        while not self._stop:
            if not self._serve_one():
                time.sleep(0.02)

    def shutdown(self):
        self._stop = True
        if self._bg:
            import _rpi_hw
            _rpi_hw.stop(self._bg)
            self._bg = None

    def server_close(self):
        J.net_unlisten(self.server_port)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.server_close()


ThreadingHTTPServer = HTTPServer
`;var dd=`# A small Flask for the RaptiAuto virtual Raspberry Pi: routes, request, jsonify, render_template_string,
# redirect. The server answers browsers on the simulated network (Chromium: http://localhost:5000/).
#     from flask import Flask, jsonify
#     app = Flask(__name__)
#     @app.route("/")
#     def home(): return "Hello from the Pi!"
#     app.run(host="0.0.0.0", port=5000)
import json as _json
import time
import _rpi_js as J
import _netio
from urllib.parse import urlparse, parse_qs, unquote_plus


class Headers:
    def __init__(self, d=None):
        self._d = {}
        for k, v in (d or {}).items():
            self._d[k.lower()] = v

    def get(self, k, default=None):
        return self._d.get(k.lower(), default)

    def __getitem__(self, k):
        return self._d[k.lower()]

    def __setitem__(self, k, v):
        self._d[k.lower()] = v

    def __contains__(self, k):
        return k.lower() in self._d

    def items(self):
        return self._d.items()

    def add(self, k, v):
        self._d[k.lower()] = v


class _Args:
    """request.args / request.form: a dict that returns the first value (and has getlist)."""
    def __init__(self, multi):
        self._m = multi

    def get(self, k, default=None, type=None):
        v = self._m.get(k)
        if not v:
            return default
        v = v[0]
        if type is not None:
            try:
                return type(v)
            except Exception:
                return default
        return v

    def getlist(self, k):
        return list(self._m.get(k, []))

    def __getitem__(self, k):
        v = self._m.get(k)
        if not v:
            raise KeyError(k)
        return v[0]

    def __contains__(self, k):
        return k in self._m

    def keys(self):
        return self._m.keys()

    def items(self):
        return [(k, v[0]) for k, v in self._m.items()]

    def to_dict(self):
        return dict(self.items())

    def __iter__(self):
        return iter(self._m)

    def __len__(self):
        return len(self._m)


class Request:
    method = 'GET'
    path = '/'
    args = _Args({})
    form = _Args({})
    values = _Args({})
    headers = Headers()
    data = b''
    host = 'localhost'
    url = ''
    remote_addr = '127.0.0.1'

    def get_json(self, force=False, silent=False):
        try:
            return _json.loads(self.data.decode('utf-8'))
        except Exception:
            if silent:
                return None
            raise

    @property
    def json(self):
        ct = self.headers.get('content-type', '')
        return self.get_json(silent=True) if 'json' in ct else None


request = Request()


class Response:
    def __init__(self, response='', status=200, headers=None, mimetype=None, content_type=None):
        if isinstance(response, (bytes, bytearray)):
            response = bytes(response).decode('utf-8', 'replace')
        self.data = response
        self.status_code = status
        self.headers = Headers(headers)
        ct = content_type or (mimetype and (mimetype + ('; charset=utf-8' if mimetype.startswith('text/') else '')))
        if ct:
            self.headers['content-type'] = ct
        elif 'content-type' not in self.headers:
            self.headers['content-type'] = 'text/html; charset=utf-8'

    @property
    def status(self):
        return '%d' % self.status_code

    @property
    def mimetype(self):
        return self.headers.get('content-type', '').split(';')[0]

    def get_data(self, as_text=False):
        return self.data if as_text else self.data.encode('utf-8')

    def set_cookie(self, *a, **k):
        pass


def make_response(*args):
    return _to_response(args if len(args) > 1 else args[0] if args else '')


def jsonify(*args, **kwargs):
    obj = args[0] if len(args) == 1 else (list(args) if args else kwargs)
    return Response(_json.dumps(obj), 200, mimetype='application/json')


def redirect(location, code=302):
    return Response('Redirecting to ' + location, code, {'Location': location})


class HTTPException(Exception):
    def __init__(self, code, description=''):
        super().__init__(description)
        self.code = code
        self.description = description


def abort(code, description=''):
    raise HTTPException(code, description)


def url_for(endpoint, **values):
    app = _CURRENT[0]
    if endpoint == 'static':
        return '/static/' + values.get('filename', '')
    for rule, (fn, methods, name) in app._rules:
        if name == endpoint:
            url = rule
            for k, v in values.items():
                url = url.replace('<%s>' % k, str(v)).replace('<int:%s>' % k, str(v))
            return url
    return '/'


def escape(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


class Markup(str):
    pass


# ---------------------------------------------------------------- templates (a small Jinja subset)
def _render(src, ctx):
    pos = 0
    toks = []
    while True:
        i = src.find('{', pos)
        while i >= 0 and src[i + 1:i + 2] not in ('{', '%', '#'):
            i = src.find('{', i + 1)
        if i < 0:
            toks.append(('t', src[pos:]))
            break
        toks.append(('t', src[pos:i]))
        kind = src[i + 1]
        end = src.find({'{': '}}', '%': '%}', '#': '#}'}[kind], i + 2)
        if end < 0:
            toks.append(('t', src[i:]))
            break
        toks.append((kind, src[i + 2:end].strip()))
        pos = end + 2
    out, _ = _run(toks, 0, ctx, None)
    return out


def _eval(expr, ctx):
    filt = None
    if '|' in expr and '||' not in expr:
        expr, _, filt = expr.rpartition('|')
        filt = filt.strip()
        expr = expr.strip()
    g = {'len': len, 'range': range, 'str': str, 'int': int, 'float': float, 'round': round, 'abs': abs, 'min': min, 'max': max, 'sum': sum, 'sorted': sorted, 'enumerate': enumerate, 'zip': zip, 'True': True, 'False': False, 'None': None}
    g.update(ctx)
    try:
        v = eval(expr, g)
    except Exception as e:
        v = ''
    if filt:
        if filt == 'safe':
            return Markup(str(v))
        if filt.startswith('round'):
            n = filt[filt.find('(') + 1:filt.find(')')]
            v = round(v, int(n) if n else 0)
        elif filt == 'int':
            v = int(v)
        elif filt == 'upper':
            v = str(v).upper()
        elif filt == 'lower':
            v = str(v).lower()
        elif filt == 'length':
            v = len(v)
        elif filt == 'tojson':
            return Markup(_json.dumps(v))
    return v


def _run(toks, i, ctx, stop):
    out = ''
    while i < len(toks):
        kind, val = toks[i]
        if kind == 't':
            out += val
        elif kind == '{':
            v = _eval(val, ctx)
            out += str(v) if isinstance(v, Markup) else escape(v)
        elif kind == '#':
            pass
        else:
            word = val.split(None, 1)[0] if val else ''
            if stop and word in stop:
                return out, i
            if word == 'for':
                rest = val[3:].strip()
                var, _, it = rest.partition(' in ')
                seq = _eval(it.strip(), ctx)
                names = [v.strip() for v in var.split(',')]
                # find the matching endfor
                depth, j = 1, i + 1
                while j < len(toks):
                    if toks[j][0] == '%':
                        w = toks[j][1].split(None, 1)[0] if toks[j][1] else ''
                        if w == 'for':
                            depth += 1
                        elif w == 'endfor':
                            depth -= 1
                            if depth == 0:
                                break
                    j += 1
                n = 0
                for item in seq:
                    c = dict(ctx)
                    if len(names) == 1:
                        c[names[0]] = item
                    else:
                        for a, b in zip(names, item):
                            c[a] = b
                    c['loop'] = {'index': n + 1, 'index0': n, 'first': n == 0}
                    o, _ = _run(toks[i + 1:j], 0, c, None)
                    out += o
                    n += 1
                i = j
            elif word == 'if':
                # collect branches until endif (nesting aware)
                depth, j, branches, cur_start, cur_cond = 1, i + 1, [], i + 1, val[2:].strip()
                while j < len(toks):
                    if toks[j][0] == '%':
                        w = toks[j][1].split(None, 1)[0] if toks[j][1] else ''
                        if w == 'if':
                            depth += 1
                        elif w == 'endif':
                            depth -= 1
                            if depth == 0:
                                branches.append((cur_cond, toks[cur_start:j]))
                                break
                        elif depth == 1 and w == 'elif':
                            branches.append((cur_cond, toks[cur_start:j]))
                            cur_cond, cur_start = toks[j][1][4:].strip(), j + 1
                        elif depth == 1 and w == 'else':
                            branches.append((cur_cond, toks[cur_start:j]))
                            cur_cond, cur_start = 'True', j + 1
                    j += 1
                for cond, body in branches:
                    if _eval(cond, ctx):
                        o, _ = _run(body, 0, ctx, None)
                        out += o
                        break
                i = j
            elif word == 'set':
                name, _, ex = val[3:].partition('=')
                ctx[name.strip()] = _eval(ex.strip(), ctx)
        i += 1
    return out, i


def render_template_string(source, **context):
    return _render(source, context)


def render_template(name, **context):
    import os
    for d in ('templates', '.'):
        try:
            with open(d + '/' + name) as f:
                return _render(f.read(), context)
        except OSError:
            pass
    raise OSError('TemplateNotFound: ' + name)


_CURRENT = [None]


def _to_response(rv):
    status, headers = 200, None
    if isinstance(rv, tuple):
        if len(rv) == 3:
            rv, status, headers = rv
        elif len(rv) == 2:
            rv, x = rv
            if isinstance(x, int):
                status = x
            else:
                headers = x
    if isinstance(rv, Response):
        if status != 200:
            rv.status_code = status
        if headers:
            for k, v in headers.items():
                rv.headers[k] = v
        return rv
    if isinstance(rv, (dict, list)):
        return Response(_json.dumps(rv), status, headers, mimetype='application/json')
    if rv is None:
        raise TypeError('The view function did not return a valid response. The function either returned None or ended without a return statement.')
    return Response(rv, status, headers)


class Flask:
    def __init__(self, import_name='app', **kw):
        self.name = import_name
        self.config = {}
        self._rules = []
        self._before = []
        self._after = []
        self._errors = {}
        self.debug = False
        self.static_folder = 'static'
        self._stop = False
        self._bg = None
        self._port = 5000
        _CURRENT[0] = self

    def route(self, rule, methods=None, **kw):
        def deco(fn):
            self._rules.append((rule, (fn, [m.upper() for m in (methods or ['GET'])], kw.get('endpoint') or fn.__name__)))
            return fn
        return deco

    def get(self, rule, **kw):
        return self.route(rule, methods=['GET'], **kw)

    def post(self, rule, **kw):
        return self.route(rule, methods=['POST'], **kw)

    def add_url_rule(self, rule, endpoint=None, view_func=None, methods=None, **kw):
        self._rules.append((rule, (view_func, [m.upper() for m in (methods or ['GET'])], endpoint or view_func.__name__)))

    def before_request(self, fn):
        self._before.append(fn)
        return fn

    def after_request(self, fn):
        self._after.append(fn)
        return fn

    def errorhandler(self, code):
        def deco(fn):
            self._errors[code] = fn
            return fn
        return deco

    def _match(self, path):
        for rule, (fn, methods, name) in self._rules:
            rp, pp = rule.strip('/').split('/'), path.strip('/').split('/')
            if len(rp) != len(pp):
                continue
            kw = {}
            ok = True
            for a, b in zip(rp, pp):
                if a.startswith('<') and a.endswith('>'):
                    spec = a[1:-1]
                    conv, _, nm = spec.rpartition(':')
                    b = unquote_plus(b)
                    if conv == 'int':
                        if not b.lstrip('-').isdigit():
                            ok = False
                            break
                        b = int(b)
                    elif conv == 'float':
                        try:
                            b = float(b)
                        except ValueError:
                            ok = False
                            break
                    kw[nm] = b
                elif a != b:
                    ok = False
                    break
            if ok:
                return fn, methods, kw
        return None

    def _dispatch(self, info):
        u = urlparse(info.get('path', '/'))
        method = info.get('method', 'GET')
        req = request
        req.method = method
        req.path = u.path
        req.url = 'http://' + info.get('host', 'localhost') + info.get('path', '/')
        req.host = info.get('host', 'localhost')
        req.args = _Args(parse_qs(u.query))
        body = info.get('body', '')
        req.data = body.encode('utf-8')
        req.headers = Headers(info.get('headers') or {})
        ct = req.headers.get('content-type', '')
        req.form = _Args(parse_qs(body) if 'urlencoded' in ct else {})
        m = {}
        for k in req.args.keys():
            m[k] = req.args._m[k]
        for k in req.form.keys():
            m[k] = req.form._m[k]
        req.values = _Args(m)
        try:
            for fn in self._before:
                r = fn()
                if r is not None:
                    return _to_response(r)
            if u.path.startswith('/static/'):
                try:
                    with open(self.static_folder + u.path[7:]) as f:
                        data = f.read()
                    ctype = 'text/css' if u.path.endswith('.css') else 'application/javascript' if u.path.endswith('.js') else 'text/html' if u.path.endswith('.html') else 'text/plain'
                    return Response(data, 200, mimetype=ctype)
                except OSError:
                    raise HTTPException(404, 'Not Found')
            hit = self._match(u.path)
            if hit is None:
                raise HTTPException(404, 'The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.')
            fn, methods, kw = hit
            if method not in methods and not (method == 'HEAD' and 'GET' in methods):
                raise HTTPException(405, 'The method is not allowed for the requested URL.')
            resp = _to_response(fn(**kw))
        except HTTPException as e:
            h = self._errors.get(e.code)
            if h:
                resp = _to_response(h(e))
            else:
                names = {404: 'Not Found', 405: 'Method Not Allowed', 400: 'Bad Request', 401: 'Unauthorized', 403: 'Forbidden', 500: 'Internal Server Error'}
                resp = Response('<!doctype html>\\n<html lang=en>\\n<title>%d %s</title>\\n<h1>%s</h1>\\n<p>%s</p>\\n' % (e.code, names.get(e.code, 'Error'), names.get(e.code, 'Error'), e.description), e.code)
        except Exception as e:
            import sys
            sys.print_exception(e)
            h = self._errors.get(500)
            resp = _to_response(h(e)) if h else Response('<!doctype html>\\n<html lang=en>\\n<title>500 Internal Server Error</title>\\n<h1>Internal Server Error</h1>\\n<p>The server encountered an internal error and was unable to complete your request. Either the server is overloaded or there is an error in the application.</p>\\n', 500)
        for fn in self._after:
            resp = fn(resp) or resp
        return resp

    def _serve_one(self):
        rid = J.net_accept(self._port)
        if not rid:
            return False
        info = _json.loads(J.net_req(rid))
        resp = self._dispatch(info)
        hdrs = dict(resp.headers.items())
        J.net_respond(rid, resp.status_code, _json.dumps(hdrs), resp.data)
        print('%s - - [%s] "%s %s HTTP/1.1" %d -' % (info.get('from', '192.168.1.2'), time.strftime('%d/%b/%Y %H:%M:%S'), info.get('method', 'GET'), info.get('path', '/'), resp.status_code))
        return True

    def test_client(self):
        return _TestClient(self)

    def run(self, host=None, port=None, debug=None, use_reloader=None, threaded=True, **kw):
        self._port = int(port or 5000)
        r = J.net_listen(self._port)
        if r == -1:
            raise OSError(98, 'Address already in use')
        if r == 0:
            raise OSError(101, 'Network is unreachable (the Pi has no Wi-Fi / network connection)')
        ip = J.net_ip() or '127.0.0.1'
        print(' * Serving Flask app %r' % self.name)
        print(' * Debug mode: %s' % ('on' if debug else 'off'))
        print('WARNING: This is a development server. Do not use it in a production deployment.')
        print(' * Running on all addresses (0.0.0.0)' if host == '0.0.0.0' else ' * Running on http://127.0.0.1:%d' % self._port)
        print(' * Running on http://127.0.0.1:%d' % self._port)
        if host == '0.0.0.0':
            print(' * Running on http://%s:%d' % (ip, self._port))
        print('Press CTRL+C to quit')
        self._stop = False
        if _netio.BG[0]:
            import _rpi_hw
            self._bg = _rpi_hw.every(20, self._serve_one)
            return
        while not self._stop:
            if not self._serve_one():
                time.sleep(0.02)


class _TestClient:
    def __init__(self, app):
        self.app = app

    def open(self, path, method='GET', data=None, json=None, headers=None):
        info = {'method': method, 'path': path, 'host': 'localhost', 'headers': dict(headers or {}), 'body': ''}
        if json is not None:
            info['body'] = _json.dumps(json)
            info['headers']['content-type'] = 'application/json'
        elif data:
            from urllib.parse import urlencode
            info['body'] = urlencode(data)
            info['headers']['content-type'] = 'application/x-www-form-urlencoded'
        return self.app._dispatch(info)

    def get(self, path, **kw):
        return self.open(path, 'GET', **kw)

    def post(self, path, **kw):
        return self.open(path, 'POST', **kw)
`;var ud=`
`;var pd=`
`;var md=`# paho-mqtt for the RaptiAuto virtual Raspberry Pi: a client for the simulated MQTT brokers
# (broker.hivemq.com, test.mosquitto.org, localhost = the Pi's own Mosquitto).
#     import paho.mqtt.client as mqtt
#     def on_message(client, userdata, msg): print(msg.topic, msg.payload.decode())
#     c = mqtt.Client(); c.on_message = on_message
#     c.connect("broker.hivemq.com", 1883); c.subscribe("rapti/#"); c.loop_forever()
import json
import time
import _rpi_js as J
import _netio

MQTT_ERR_SUCCESS = 0
MQTT_ERR_NO_CONN = 4
MQTT_ERR_CONN_REFUSED = 5
MQTTv31 = 3
MQTTv311 = 4
MQTTv5 = 5
MQTT_CLEAN_START_FIRST_ONLY = 3


class CallbackAPIVersion:
    VERSION1 = 1
    VERSION2 = 2


class MQTTMessage:
    def __init__(self, topic, payload, retain=False):
        self.topic = topic
        self.payload = payload.encode('utf-8') if isinstance(payload, str) else payload
        self.qos = 0
        self.retain = retain
        self.mid = 0


class MQTTMessageInfo:
    def __init__(self, rc=0):
        self.rc = rc
        self.mid = 1

    def wait_for_publish(self, timeout=None):
        pass

    def is_published(self):
        return True


def error_string(rc):
    return {0: 'No error.', 4: 'The client is not currently connected.', 5: 'Connection Refused: not authorised'}.get(rc, 'Unknown error.')


def connack_string(rc):
    return {0: 'Connection Accepted.', 5: 'Connection Refused: not authorised.'}.get(rc, 'Connection Refused: unknown reason.')


class Client:
    def __init__(self, *args, client_id='', clean_session=True, userdata=None, protocol=MQTTv311, transport='tcp', **kw):
        # Client(), Client("id"), Client(CallbackAPIVersion.VERSION2, "id")
        self._v2 = False
        a = list(args)
        if a and isinstance(a[0], int) and not isinstance(a[0], bool):
            self._v2 = a[0] == 2
            a = a[1:]
        if a and isinstance(a[0], str):
            client_id = a[0]
        self._cid = client_id or 'rapti-%d' % (time.ticks_ms() % 100000)
        self._userdata = userdata
        self._h = 0
        self._host = None
        self._user = None
        self._pass = None
        self._will = None
        self._subs = []
        self._cbs = {}
        self._bg = None
        self._stop = False
        self._connected = False
        self.on_connect = None
        self.on_disconnect = None
        self.on_message = None
        self.on_publish = None
        self.on_subscribe = None
        self.on_unsubscribe = None
        self.on_log = None

    def user_data_set(self, u):
        self._userdata = u

    def username_pw_set(self, username, password=None):
        self._user = username
        self._pass = password

    def will_set(self, topic, payload=None, qos=0, retain=False):
        self._will = (topic, payload if isinstance(payload, str) else (payload or b'').decode('utf-8'))

    def tls_set(self, *a, **k):
        pass

    def tls_insecure_set(self, *a):
        pass

    def enable_logger(self, *a):
        pass

    def reconnect_delay_set(self, *a, **k):
        pass

    def message_callback_add(self, sub, cb):
        self._cbs[sub] = cb

    def message_callback_remove(self, sub):
        self._cbs.pop(sub, None)

    def connect(self, host, port=1883, keepalive=60, bind_address='', *a, **k):
        if not J.net_online():
            raise OSError(101, 'Network is unreachable')
        w = self._will
        h = J.mqtt_connect(self._cid, host, int(port), self._user or '', self._pass or '', w[0] if w else '', w[1] if w else '')
        if h < 0:
            if h == -4 and not J.net_resolve(host):
                raise OSError(-2, 'Name or service not known')
            if h == 5:
                self._fire_connect(5)
                return 5
            raise OSError(111, 'Connection refused')
        self._h = h
        self._host = host
        self._connected = True
        for t in self._subs:
            J.mqtt_subscribe(h, t)
        self._fire_connect(0)
        return MQTT_ERR_SUCCESS

    def connect_async(self, host, port=1883, keepalive=60, *a, **k):
        self.connect(host, port, keepalive)

    def reconnect(self):
        return self.connect(self._host)

    def _fire_connect(self, rc):
        if self.on_connect:
            if self._v2:
                self.on_connect(self, self._userdata, {'session present': 0}, rc, None)
            else:
                self.on_connect(self, self._userdata, {'session present': 0}, rc)

    def disconnect(self):
        if self._h:
            J.mqtt_disconnect(self._h)
            self._h = 0
        was = self._connected
        self._connected = False
        self._stop = True
        if was and self.on_disconnect:
            if self._v2:
                self.on_disconnect(self, self._userdata, {}, 0, None)
            else:
                self.on_disconnect(self, self._userdata, 0)
        return MQTT_ERR_SUCCESS

    def is_connected(self):
        return bool(self._h and J.mqtt_connected(self._h))

    def subscribe(self, topic, qos=0, *a, **k):
        topics = topic if isinstance(topic, list) else [topic]
        for t in topics:
            if isinstance(t, tuple):
                t = t[0]
            self._subs.append(t)
            if self._h:
                J.mqtt_subscribe(self._h, t)
        if self.on_subscribe:
            if self._v2:
                self.on_subscribe(self, self._userdata, 1, [0], None)
            else:
                self.on_subscribe(self, self._userdata, 1, (qos,))
        return (MQTT_ERR_SUCCESS, 1)

    def unsubscribe(self, topic, *a):
        for t in (topic if isinstance(topic, list) else [topic]):
            if t in self._subs:
                self._subs.remove(t)
            if self._h:
                J.mqtt_unsubscribe(self._h, t)
        return (MQTT_ERR_SUCCESS, 1)

    def publish(self, topic, payload=None, qos=0, retain=False, properties=None):
        if not self._h or not J.mqtt_connected(self._h):
            return MQTTMessageInfo(MQTT_ERR_NO_CONN)
        if isinstance(payload, (bytes, bytearray)):
            payload = bytes(payload).decode('utf-8', 'replace')
        elif payload is None:
            payload = ''
        elif not isinstance(payload, str):
            payload = str(payload)
        J.mqtt_publish(self._h, topic, payload, 1 if retain else 0)
        if self.on_publish:
            if self._v2:
                self.on_publish(self, self._userdata, 1, 0, None)
            else:
                self.on_publish(self, self._userdata, 1)
        return MQTTMessageInfo(0)

    def _deliver(self, m):
        msg = MQTTMessage(m['topic'], m['payload'], m.get('retained', False))
        for sub, cb in self._cbs.items():
            if _match(sub, msg.topic):
                cb(self, self._userdata, msg)
                return
        if self.on_message:
            self.on_message(self, self._userdata, msg)

    def loop(self, timeout=1.0, max_packets=1):
        if not self._h:
            return MQTT_ERR_NO_CONN
        n = 0
        t0 = time.ticks_ms()
        while True:
            r = J.mqtt_poll(self._h)
            if r:
                self._deliver(json.loads(r))
                n += 1
                if n >= 50:
                    break
            elif n or time.ticks_diff(time.ticks_ms(), t0) >= timeout * 1000:
                break
            else:
                time.sleep(0.01)
        return MQTT_ERR_SUCCESS

    def _tick(self):
        if not self._h:
            return
        for _ in range(20):
            r = J.mqtt_poll(self._h)
            if not r:
                break
            self._deliver(json.loads(r))

    def loop_start(self):
        import _rpi_hw
        if self._bg is None:
            self._bg = _rpi_hw.every(20, self._tick)
        return MQTT_ERR_SUCCESS

    def loop_stop(self, force=False):
        if self._bg is not None:
            import _rpi_hw
            _rpi_hw.stop(self._bg)
            self._bg = None
        return MQTT_ERR_SUCCESS

    def loop_forever(self, timeout=1.0, retry_first_connection=False):
        self._stop = False
        while not self._stop and self._h:
            self._tick()
            time.sleep(0.02)
        return MQTT_ERR_SUCCESS

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.disconnect()


def _match(f, t):
    fs, ts = f.split('/'), t.split('/')
    for i, p in enumerate(fs):
        if p == '#':
            return True
        if i >= len(ts):
            return False
        if p != '+' and p != ts[i]:
            return False
    return len(fs) == len(ts)


def topic_matches_sub(sub, topic):
    return _match(sub, topic)
`;var gd=`from paho.mqtt.client import Client


def single(topic, payload=None, qos=0, retain=False, hostname='localhost', port=1883, client_id='', auth=None, **kw):
    c = Client(client_id=client_id)
    if auth:
        c.username_pw_set(auth.get('username'), auth.get('password'))
    c.connect(hostname, port)
    c.publish(topic, payload, qos, retain)
    c.disconnect()


def multiple(msgs, hostname='localhost', port=1883, client_id='', auth=None, **kw):
    c = Client(client_id=client_id)
    c.connect(hostname, port)
    for m in msgs:
        if isinstance(m, dict):
            c.publish(m['topic'], m.get('payload'), m.get('qos', 0), m.get('retain', False))
        else:
            c.publish(*m[:4])
    c.disconnect()
`;var _d=`import time
from paho.mqtt.client import Client


def simple(topics, hostname='localhost', port=1883, msg_count=1, **kw):
    out = []
    c = Client()

    def on_message(client, userdata, msg):
        out.append(msg)

    c.on_message = on_message
    c.connect(hostname, port)
    c.subscribe(topics)
    while len(out) < msg_count:
        c.loop(0.2)
    c.disconnect()
    return out[0] if msg_count == 1 else out
`;var yd=`
`;var bd=`# umqtt.simple (MicroPython): MQTT client for the Pico W on the simulated brokers.
#     from umqtt.simple import MQTTClient
#     c = MQTTClient("pico", "broker.hivemq.com"); c.connect(); c.publish(b"rapti/pico", b"hello")
import json
import time
import _rpi_js as J


class MQTTException(Exception):
    pass


class MQTTClient:
    def __init__(self, client_id, server, port=0, user=None, password=None, keepalive=0, ssl=False, ssl_params={}):
        self.client_id = client_id if isinstance(client_id, str) else client_id.decode()
        self.server = server
        self.port = port or (8883 if ssl else 1883)
        self.user = user
        self.pswd = password
        self.cb = None
        self._h = 0
        self._will = None

    def set_callback(self, f):
        self.cb = f

    def set_last_will(self, topic, msg, retain=False, qos=0):
        self._will = (topic.decode() if isinstance(topic, bytes) else topic, msg.decode() if isinstance(msg, bytes) else msg)

    def connect(self, clean_session=True, timeout=None):
        w = self._will
        h = J.mqtt_connect(self.client_id, self.server, self.port, self.user or '', (self.pswd or ''), w[0] if w else '', w[1] if w else '')
        if h < 0:
            if h == 5:
                raise MQTTException(5)
            raise OSError(-1 if h == -4 else 111, 'MQTT connect failed')
        self._h = h
        return False

    def disconnect(self):
        if self._h:
            J.mqtt_disconnect(self._h)
            self._h = 0

    def ping(self):
        pass

    def publish(self, topic, msg, retain=False, qos=0):
        if not self._h or not J.mqtt_connected(self._h):
            raise OSError(104, 'ECONNRESET')
        J.mqtt_publish(self._h, topic.decode() if isinstance(topic, bytes) else topic, msg.decode() if isinstance(msg, (bytes, bytearray)) else str(msg), 1 if retain else 0)

    def subscribe(self, topic, qos=0):
        if not self.cb:
            raise MQTTException('subscribe callback is not set')
        J.mqtt_subscribe(self._h, topic.decode() if isinstance(topic, bytes) else topic)

    def check_msg(self):
        r = J.mqtt_poll(self._h) if self._h else ''
        if not r:
            return None
        m = json.loads(r)
        self.cb(m['topic'].encode(), m['payload'].encode())
        return None

    def wait_msg(self):
        while True:
            r = J.mqtt_poll(self._h)
            if r:
                m = json.loads(r)
                self.cb(m['topic'].encode(), m['payload'].encode())
                return None
            time.sleep(0.02)
`;var Od=`def bisect_left(a, x, lo=0, hi=None):
    if hi is None:
        hi = len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        if a[mid] < x:
            lo = mid + 1
        else:
            hi = mid
    return lo


def bisect_right(a, x, lo=0, hi=None):
    if hi is None:
        hi = len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        if x < a[mid]:
            hi = mid
        else:
            lo = mid + 1
    return lo


bisect = bisect_right


def insort_left(a, x, lo=0, hi=None):
    a.insert(bisect_left(a, x, lo, hi), x)


def insort_right(a, x, lo=0, hi=None):
    a.insert(bisect_right(a, x, lo, hi), x)


insort = insort_right
`;var vd=`def wrap(text, width=70, **kw):
    lines, cur = [], ''
    for w in text.split():
        if cur and len(cur) + 1 + len(w) > width:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + ' ' + w) if cur else w
    if cur:
        lines.append(cur)
    return lines


def fill(text, width=70, **kw):
    return '\\n'.join(wrap(text, width))


def shorten(text, width, placeholder=' [...]', **kw):
    t = ' '.join(text.split())
    if len(t) <= width:
        return t
    return t[:max(0, width - len(placeholder))].rstrip() + placeholder


def dedent(text):
    lines = text.split('\\n')
    ind = min((len(l) - len(l.lstrip()) for l in lines if l.strip()), default=0)
    return '\\n'.join(l[ind:] for l in lines)


def indent(text, prefix):
    return ''.join(prefix + l if l.strip() else l for l in text.splitlines(True))
`;var wd=`class _GC:
    def __init__(self, gen):
        self._gen = gen

    def __enter__(self):
        return next(self._gen)

    def __exit__(self, t, v, tb):
        try:
            if t is None:
                next(self._gen)
            else:
                try:
                    self._gen.throw(v)
                except StopIteration:
                    return True
        except StopIteration:
            pass
        return False


def contextmanager(fn):
    def helper(*a, **k):
        return _GC(fn(*a, **k))
    return helper


class closing:
    def __init__(self, thing):
        self.thing = thing

    def __enter__(self):
        return self.thing

    def __exit__(self, *a):
        self.thing.close()


class suppress:
    def __init__(self, *exc):
        self.exc = exc

    def __enter__(self):
        return None

    def __exit__(self, t, v, tb):
        return t is not None and issubclass(t, self.exc)
`;var kd=`# threading for the virtual Pi (one interpreter, no real threads): Thread(target).start() runs the
# target at once. A web server started in it (Flask app.run, HTTPServer.serve_forever) keeps running
# in the background, and mqtt loop_start() does too, so the main program carries on.
import time
import _netio


class Thread:
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, daemon=None):
        self._target = target
        self._args = args
        self._kwargs = kwargs or {}
        self.name = name or 'Thread-1'
        self.daemon = bool(daemon)
        self._alive = False

    def start(self):
        self._alive = True
        _netio.BG[0] = True
        try:
            self.run()
        finally:
            _netio.BG[0] = False
            self._alive = False

    def run(self):
        if self._target:
            self._target(*self._args, **self._kwargs)

    def join(self, timeout=None):
        pass

    def is_alive(self):
        return self._alive

    def setDaemon(self, d):
        self.daemon = d


class Event:
    def __init__(self):
        self._f = False

    def set(self):
        self._f = True

    def clear(self):
        self._f = False

    def is_set(self):
        return self._f

    def wait(self, timeout=None):
        t0 = time.ticks_ms()
        while not self._f:
            if timeout is not None and time.ticks_diff(time.ticks_ms(), t0) > timeout * 1000:
                break
            time.sleep(0.01)
        return self._f


class Lock:
    def acquire(self, *a, **k):
        return True

    def release(self):
        pass

    def locked(self):
        return False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass


RLock = Lock


class Timer(Thread):
    def __init__(self, interval, function, args=None, kwargs=None):
        super().__init__(target=function, args=args or (), kwargs=kwargs)
        self.interval = interval

    def start(self):
        import _rpi_hw
        h = [None]

        def fire():
            _rpi_hw.stop(h[0])
            self._target(*self._args, **self._kwargs)
        h[0] = _rpi_hw.every(int(self.interval * 1000), fire)

    def cancel(self):
        pass


def current_thread():
    return Thread(name='MainThread')


def active_count():
    return 1
`;var xd=`# psutil (a few calls) for dashboards: CPU load, memory, temperature of the virtual Pi.
import random as _r
import time as _t


class _N:
    def __init__(self, **k):
        self._v = tuple(k.values())
        for key in k:
            setattr(self, key, k[key])

    def __iter__(self):
        return iter(self._v)


def cpu_percent(interval=None, percpu=False):
    v = 6 + (_t.ticks_ms() // 700) % 17 + _r.random() * 4
    return [v, v + 1, v - 1, v + 2] if percpu else round(v, 1)


def cpu_count(logical=True):
    return 4


def virtual_memory():
    total = 8 * 1024 ** 3
    used = int(total * (0.11 + ((_t.ticks_ms() // 3000) % 9) * 0.004))
    return _N(total=total, available=total - used, used=used, free=total - used, percent=round(used * 100 / total, 1))


def disk_usage(path='/'):
    total = 29 * 1024 ** 3
    used = int(6.6 * 1024 ** 3)
    return _N(total=total, used=used, free=total - used, percent=round(used * 100 / total, 1))


def sensors_temperatures(fahrenheit=False):
    t = 44 + ((_t.ticks_ms() // 2000) % 7) * 0.5
    return {'cpu_thermal': [_N(label='', current=t, high=None, critical=None)]}


def boot_time():
    return _t.time() - 3600


def net_if_addrs():
    import _rpi_js as J
    return {'wlan0': [_N(family=2, address=J.net_ip() or '0.0.0.0', netmask='255.255.255.0')]}
`;var Sd=`# ntptime (MicroPython): sets the RTC from the simulated NTP server (the phone's clock).
import time as _t

host = 'pool.ntp.org'
timeout = 1


def time():
    return int(_t.time())


def settime():
    try:
        import machine
        tm = _t.gmtime(int(_t.time()))
        machine.RTC().datetime((tm[0], tm[1], tm[2], tm[6], tm[3], tm[4], tm[5], 0))
    except Exception:
        pass
`;var Td=`# SSD1306 OLED driver (the MicroPython one): 128x64 or 128x32 on I2C
#     from machine import Pin, I2C
#     import ssd1306
#     i2c = I2C(0, sda=Pin(4), scl=Pin(5))
#     oled = ssd1306.SSD1306_I2C(128, 64, i2c)
#     oled.fill(0); oled.text("Hello", 0, 0); oled.show()
import framebuf

SET_CONTRAST = 0x81
SET_ENTIRE_ON = 0xA4
SET_NORM_INV = 0xA6
SET_DISP = 0xAE
SET_MEM_ADDR = 0x20
SET_COL_ADDR = 0x21
SET_PAGE_ADDR = 0x22
SET_DISP_START_LINE = 0x40
SET_SEG_REMAP = 0xA0
SET_MUX_RATIO = 0xA8
SET_IREF_SELECT = 0x8D
SET_COM_OUT_DIR = 0xC0
SET_DISP_OFFSET = 0xD3
SET_COM_PIN_CFG = 0xDA
SET_DISP_CLK_DIV = 0xD5
SET_PRECHARGE = 0xD9
SET_VCOM_DESEL = 0xDB
SET_CHARGE_PUMP = 0x8D


class SSD1306(framebuf.FrameBuffer):
    def __init__(self, width, height, external_vcc):
        self.width = width
        self.height = height
        self.external_vcc = external_vcc
        self.pages = self.height // 8
        self.buffer = bytearray(self.pages * self.width)
        super().__init__(self.buffer, self.width, self.height, framebuf.MONO_VLSB)
        self.init_display()

    def init_display(self):
        for cmd in (
            SET_DISP,
            SET_MEM_ADDR, 0x00,
            SET_DISP_START_LINE,
            SET_SEG_REMAP | 0x01,
            SET_MUX_RATIO, self.height - 1,
            SET_COM_OUT_DIR | 0x08,
            SET_DISP_OFFSET, 0x00,
            SET_COM_PIN_CFG, 0x02 if self.width > 2 * self.height else 0x12,
            SET_DISP_CLK_DIV, 0x80,
            SET_PRECHARGE, 0x22 if self.external_vcc else 0xF1,
            SET_VCOM_DESEL, 0x30,
            SET_CONTRAST, 0xFF,
            SET_ENTIRE_ON,
            SET_NORM_INV,
            SET_IREF_SELECT, 0x10 if self.external_vcc else 0x14,
            SET_DISP | 0x01,
        ):
            self.write_cmd(cmd)
        self.fill(0)
        self.show()

    def poweroff(self):
        self.write_cmd(SET_DISP)

    def poweron(self):
        self.write_cmd(SET_DISP | 0x01)

    def contrast(self, contrast):
        self.write_cmd(SET_CONTRAST)
        self.write_cmd(contrast)

    def invert(self, invert):
        self.write_cmd(SET_NORM_INV | (invert & 1))

    def rotate(self, rotate):
        self.write_cmd(SET_COM_OUT_DIR | ((rotate & 1) << 3))
        self.write_cmd(SET_SEG_REMAP | (rotate & 1))

    def show(self):
        x0 = 0
        x1 = self.width - 1
        if self.width != 128:
            col_offset = (128 - self.width) // 2
            x0 += col_offset
            x1 += col_offset
        self.write_cmd(SET_COL_ADDR)
        self.write_cmd(x0)
        self.write_cmd(x1)
        self.write_cmd(SET_PAGE_ADDR)
        self.write_cmd(0)
        self.write_cmd(self.pages - 1)
        self.write_data(self.buffer)


class SSD1306_I2C(SSD1306):
    def __init__(self, width, height, i2c, addr=0x3C, external_vcc=False):
        self.i2c = i2c
        self.addr = addr
        self.temp = bytearray(2)
        self.write_list = [b"\\x40", None]
        super().__init__(width, height, external_vcc)

    def write_cmd(self, cmd):
        self.temp[0] = 0x80
        self.temp[1] = cmd
        self.i2c.writeto(self.addr, self.temp)

    def write_data(self, buf):
        self.i2c.writeto(self.addr, b"\\x40" + bytes(buf))
`;var Pd=`# adafruit_ssd1306 (CircuitPython / Blinka) for the Raspberry Pi:
#     import board, busio, adafruit_ssd1306
#     i2c = board.I2C()
#     oled = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c, addr=0x3C)
#     oled.fill(0); oled.text("Hello", 0, 0, 1); oled.show()
import ssd1306 as _s

class SSD1306_I2C(_s.SSD1306_I2C):
    def __init__(self, width, height, i2c, *, addr=0x3C, external_vcc=False, reset=None):
        if not i2c.try_lock():
            raise RuntimeError("I2C bus is in use")
        i2c.unlock()
        if addr not in i2c.scan():
            raise ValueError("No I2C device at address: 0x%x" % addr)
        super().__init__(width, height, _Bus(i2c), addr, external_vcc)

    def image(self, image):
        raise NotImplementedError("PIL images are not available in the simulator - draw with fill/text/line/rect/pixel")

    @property
    def power(self):
        return True


class _Bus:
    def __init__(self, i2c):
        self.i2c = i2c

    def writeto(self, addr, buf):
        self.i2c.writeto(addr, bytes(buf))
`;var Cd=`# busio (Adafruit Blinka): I2C, SPI and UART on the Raspberry Pi
import _rpi_js as J


class I2C:
    def __init__(self, scl=None, sda=None, frequency=100000):
        self.frequency = frequency
        self._locked = False

    def try_lock(self):
        if self._locked:
            return False
        self._locked = True
        return True

    def unlock(self):
        self._locked = False

    def deinit(self):
        pass

    def scan(self):
        s = J.i2c_scan()
        return [int(a) for a in s.split(',')] if s else []

    def writeto(self, address, buffer, *, start=0, end=None, stop=True):
        end = len(buffer) if end is None else end
        J.i2c_write(address, bytes(buffer[start:end]).hex())

    def readfrom_into(self, address, buffer, *, start=0, end=None, stop=True):
        end = len(buffer) if end is None else end
        data = bytes.fromhex(J.i2c_read(address, end - start))
        for i in range(end - start):
            buffer[start + i] = data[i]

    def writeto_then_readfrom(self, address, buffer_out, buffer_in, *, out_start=0, out_end=None, in_start=0, in_end=None, stop=False):
        self.writeto(address, buffer_out, start=out_start, end=out_end)
        self.readfrom_into(address, buffer_in, start=in_start, end=in_end)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.deinit()


class SPI:
    def __init__(self, clock=None, MOSI=None, MISO=None):
        self._sck = clock if clock is not None else 11
        self._mosi = MOSI if MOSI is not None else 10
        self._locked = False

    def try_lock(self):
        self._locked = True
        return True

    def unlock(self):
        self._locked = False

    def configure(self, **kw):
        pass

    def write(self, buf, start=0, end=None):
        end = len(buf) if end is None else end
        J.spi_xfer(self._sck, self._mosi, bytes(buf[start:end]).hex())

    def deinit(self):
        pass
`;var Ed=`# TM1637 4-digit 7-segment display (the popular micropython-tm1637 / tm1637 PyPI API):
#     import tm1637
#     tm = tm1637.TM1637(clk=Pin(2), dio=Pin(3))     # Pico  (Raspberry Pi: clk=23, dio=24)
#     tm.number(1234)    tm.show("HELP")    tm.numbers(12, 34)    tm.temperature(25)
import _rpi_js as J
import time

_SEGMENTS = bytearray(b'\\x3F\\x06\\x5B\\x4F\\x66\\x6D\\x7D\\x07\\x7F\\x6F\\x77\\x7C\\x39\\x5E\\x79\\x71\\x3D\\x76\\x06\\x1E\\x76\\x38\\x55\\x54\\x3F\\x73\\x67\\x50\\x6D\\x78\\x3E\\x1C\\x2A\\x76\\x6E\\x5B\\x00\\x40\\x63')


def _gpio(p):
    if isinstance(p, int):
        return p
    return p._id if hasattr(p, '_id') else int(p)


class TM1637:
    def __init__(self, clk, dio, brightness=7):
        self.clk = _gpio(clk)
        self.dio = _gpio(dio)
        self._brightness = brightness
        self._frame = bytearray(6)
        self._send(self._frame[:4])

    def _send(self, segs):
        for i in range(len(segs)):
            self._frame[i] = segs[i]
        J.disp_tm1637(self.clk, self.dio, bytes(self._frame).hex(), self._brightness, 1)

    def brightness(self, val=None):
        """Set the display brightness 0-7."""
        if val is None:
            return self._brightness
        if not 0 <= val <= 7:
            raise ValueError("Brightness out of range")
        self._brightness = val
        self._send(self._frame[:4])

    def write(self, segments, pos=0):
        """Display up to 6 segments (a segment is one byte: bit 0 = A ... bit 6 = G, bit 7 = dot)."""
        if not 0 <= pos <= 5:
            raise ValueError("Position out of range")
        for i in range(len(segments)):
            if pos + i < 6:
                self._frame[pos + i] = segments[i]
        self._send(self._frame[:4])

    def encode_digit(self, digit):
        return _SEGMENTS[digit & 0x0f]

    def encode_string(self, string):
        segments = bytearray(len(string))
        for i in range(len(string)):
            segments[i] = self.encode_char(string[i])
        return segments

    def encode_char(self, char):
        o = ord(char)
        if o == 32:
            return _SEGMENTS[36]
        if o == 42:
            return _SEGMENTS[38]
        if o == 45:
            return _SEGMENTS[37]
        if o >= 65 and o <= 90:
            return _SEGMENTS[o - 55]
        if o >= 97 and o <= 122:
            return _SEGMENTS[o - 87]
        if o >= 48 and o <= 57:
            return _SEGMENTS[o - 48]
        raise ValueError("Character out of range: {:d} '{:s}'".format(o, chr(o)))

    def hex(self, val):
        string = '{:04x}'.format(val & 0xffff)
        self.write(self.encode_string(string))

    def number(self, num):
        num = max(-999, min(num, 9999))
        string = '{0: >4d}'.format(num)
        self.write(self.encode_string(string))

    def numbers(self, num1, num2, colon=True):
        num1 = max(-9, min(num1, 99))
        num2 = max(-9, min(num2, 99))
        segments = self.encode_string('{0:0>2d}{1:0>2d}'.format(num1, num2))
        if colon:
            segments[1] |= 0x80
        self.write(segments)

    def temperature(self, num):
        if num < -9:
            self.show('lo')
        elif num > 99:
            self.show('hi')
        else:
            string = '{0: >2d}'.format(num)
            self.write(self.encode_string(string))
        self.write([_SEGMENTS[38], _SEGMENTS[12]], 2)

    def show(self, string, colon=False):
        segments = self.encode_string(string)
        if len(segments) > 1 and colon:
            segments[1] |= 128
        self.write(segments[:4])

    def scroll(self, string, delay=250):
        segments = string if isinstance(string, list) else self.encode_string(string)
        data = [0] * 8
        data[4:0] = list(segments)
        for i in range(len(segments) + 5):
            self.write(data[0 + i:4 + i])
            time.sleep_ms(delay) if hasattr(time, 'sleep_ms') else time.sleep(delay / 1000)


class TM1637Decimal(TM1637):
    def number(self, num):
        self.show(str(num)[:5].rjust(4))
`;var Ad=`# MAX7219 8x8 LED matrix (the MicroPython driver API, plus the Raspberry Pi: pass a spidev device):
#     from machine import Pin, SPI
#     import max7219
#     spi = SPI(0, sck=Pin(2), mosi=Pin(3))
#     display = max7219.Matrix8x8(spi, Pin(5, Pin.OUT), 4)     # 4 modules = 32x8
#     display.text("Hi!", 0, 0, 1); display.show()
import framebuf

_DECODEMODE = 9
_INTENSITY = 10
_SCANLIMIT = 11
_SHUTDOWN = 12
_DISPLAYTEST = 15


class Matrix8x8:
    def __init__(self, spi, cs=None, num=1):
        self.spi = spi
        self.cs = cs
        self.num = num
        self.buffer = bytearray(8 * num)
        self.fb = framebuf.FrameBuffer(self.buffer, 8 * num, 8, framebuf.MONO_HLSB)
        self.width = 8 * num
        self.height = 8
        self.init()

    def _write(self, command, data):
        frame = bytearray([command, data] * self.num)
        if hasattr(self.spi, 'xfer2'):
            self.spi.xfer2(list(frame))
        else:
            if self.cs is not None:
                self.cs.value(0)
            self.spi.write(frame)
            if self.cs is not None:
                self.cs.value(1)

    def init(self):
        for command, data in ((_SHUTDOWN, 0), (_DISPLAYTEST, 0), (_SCANLIMIT, 7), (_DECODEMODE, 0), (_SHUTDOWN, 1)):
            self._write(command, data)
        self.fill(0)
        self.show()

    def brightness(self, value):
        if not 0 <= value <= 15:
            raise ValueError("Brightness out of range")
        self._write(_INTENSITY, value)

    def show(self):
        for y in range(8):
            frame = bytearray()
            for m in range(self.num - 1, -1, -1):
                frame.append(y + 1)
                frame.append(self.buffer[y * self.num + m])
            if hasattr(self.spi, 'xfer2'):
                self.spi.xfer2(list(frame))
            else:
                if self.cs is not None:
                    self.cs.value(0)
                self.spi.write(frame)
                if self.cs is not None:
                    self.cs.value(1)

    # framebuf API
    def fill(self, c):
        self.fb.fill(c)

    def pixel(self, x, y, c=None):
        return self.fb.pixel(x, y, c) if c is not None else self.fb.pixel(x, y)

    def text(self, s, x, y, c=1):
        self.fb.text(s, x, y, c)

    def line(self, x1, y1, x2, y2, c):
        self.fb.line(x1, y1, x2, y2, c)

    def rect(self, x, y, w, h, c):
        self.fb.rect(x, y, w, h, c)

    def fill_rect(self, x, y, w, h, c):
        self.fb.fill_rect(x, y, w, h, c)

    def hline(self, x, y, w, c):
        self.fb.hline(x, y, w, c)

    def vline(self, x, y, h, c):
        self.fb.vline(x, y, h, c)

    def scroll(self, dx, dy):
        self.fb.scroll(dx, dy)
`;var Rd=`# spidev: SPI on the Raspberry Pi header (SPI0: SCLK GPIO11, MOSI GPIO10, MISO GPIO9, CE0 GPIO8, CE1 GPIO7)
import _rpi_js as J

_PINS = {0: (11, 10), 1: (21, 20)}


class SpiDev:
    def __init__(self):
        self._bus = 0
        self._dev = 0
        self.max_speed_hz = 500000
        self.mode = 0
        self.bits_per_word = 8
        self.cshigh = False
        self._open = False

    def open(self, bus, device):
        if bus not in _PINS:
            raise FileNotFoundError(2, "No such file or directory")
        self._bus = bus
        self._dev = device
        self._open = True

    def close(self):
        self._open = False

    def _xfer(self, data):
        if not self._open:
            raise OSError(9, "Bad file descriptor")
        sck, mosi = _PINS[self._bus]
        r = J.spi_xfer(sck, mosi, bytes(data).hex())
        return list(bytes.fromhex(r))

    def xfer(self, data, speed_hz=0, delay_usec=0, bits_per_word=0):
        return self._xfer(data)

    def xfer2(self, data, speed_hz=0, delay_usec=0, bits_per_word=0):
        return self._xfer(data)

    def writebytes(self, data):
        self._xfer(data)

    writebytes2 = writebytes

    def readbytes(self, n):
        return self._xfer([0] * n)
`;var Md="";var Dd=`# RPLCD.i2c.CharLCD: HD44780 character LCD with a PCF8574 I2C backpack
#     from RPLCD.i2c import CharLCD
#     lcd = CharLCD('PCF8574', 0x27, cols=16, rows=2)
#     lcd.write_string("Hello"); lcd.cursor_pos = (1, 0); lcd.clear()
from i2c_lcd import I2cLcd


class CharLCD(I2cLcd):
    def __init__(self, i2c_expander='PCF8574', address=0x27, port=1, charmap='A02', cols=16, rows=2, **kw):
        I2cLcd.__init__(self, address, rows, cols)

    @property
    def backlight_enabled(self):
        return self._bl != 0

    @backlight_enabled.setter
    def backlight_enabled(self, on):
        if on:
            self.backlight_on()
        else:
            self.backlight_off()

    def create_char(self, location, bitmap):
        self.custom_char(location, bitmap)
`;var Nd=`from i2c_lcd import I2cLcd
`;var Id=`from i2c_lcd import I2cLcd as LcdApi
`;var Ld={"_rpi_hw.py":qc,"time.py":Bc,"random.py":$c,"signal.py":Fc,"RPi/__init__.py":Wc,"RPi/GPIO.py":zc,"gpiozero.py":jc,"board.py":Hc,"adafruit_dht.py":Vc,"machine.py":Uc,"rp2.py":Gc,"network.py":Xc,"neopixel.py":Jc,"dht.py":Yc,"i2c_lcd.py":Kc,"smbus2.py":Zc,"smbus.py":ed,"serial.py":td,"_netio.py":id,"requests.py":sd,"urequests.py":rd,"socket.py":hd,"urllib/__init__.py":nd,"urllib/parse.py":od,"urllib/error.py":ld,"urllib/request.py":ad,"http/__init__.py":fd,"http/server.py":cd,"flask.py":dd,"paho/__init__.py":ud,"paho/mqtt/__init__.py":pd,"paho/mqtt/client.py":md,"paho/mqtt/publish.py":gd,"paho/mqtt/subscribe.py":_d,"umqtt/__init__.py":yd,"umqtt/simple.py":bd,"bisect.py":Od,"textwrap.py":vd,"contextlib.py":wd,"threading.py":kd,"psutil.py":xd,"ntptime.py":Sd,"ssd1306.py":Td,"adafruit_ssd1306.py":Pd,"busio.py":Cd,"tm1637.py":Ed,"max7219.py":Ad,"spidev.py":Rd,"RPLCD/__init__.py":Md,"RPLCD/i2c.py":Dd,"pico_i2c_lcd.py":Nd,"lcd_api.py":Id};var rt=se($i(),1),B2=se(en(),1);var H=se(ii(),1),Xr=se(Qi(),1);var ot=se(ii(),1),Qd={30:"k",31:"r",32:"g",33:"y",34:"b",35:"m",36:"c",37:"w",90:"K",91:"R",92:"G",93:"Y",94:"B",95:"M",96:"C",97:"W"},l1=2500,bs=class{constructor({cls:e="",onKey:t,extraKeys:i=null,placeholder:s=""}={}){this.el=(0,ot.h)("div",{class:"con "+e}),this.scroller=(0,ot.h)("div",{class:"con-scroll"}),this.lines=(0,ot.h)("div",{class:"con-lines"}),this.prefix=(0,ot.h)("span",{class:"con-prefix"}),this.input=(0,ot.h)("input",{class:"con-input",type:"text",autocomplete:"off",autocapitalize:"off",autocorrect:"off",spellcheck:"false",enterkeyhint:"send",placeholder:s}),this.inrow=(0,ot.h)("div",{class:"con-inrow hidden"},this.prefix,this.input),this.scroller.append(this.lines,this.inrow),this.el.appendChild(this.scroller),i&&this.el.appendChild(this.keyBar(i)),this.cur=null,this.sgr="",this.history=[],this.hIdx=0,this.pending=null,this.onKey=t,this.input.addEventListener("keydown",n=>this.keydown(n)),this.scroller.addEventListener("click",n=>{!this.inrow.classList.contains("hidden")&&!window.getSelection().toString()&&n.target.closest(".con-scroll")&&this.focus()})}keyBar(e){let t=(0,ot.h)("div",{class:"con-keys"});for(let[i,s]of e){let n=(0,ot.h)("button",{class:"ck"},i);n.addEventListener("pointerdown",o=>o.preventDefault()),n.addEventListener("click",()=>s(this)),t.appendChild(n)}return t}focus(){try{this.input.focus({preventScroll:!0})}catch{this.input.focus()}}clear(){this.lines.innerHTML="",this.cur=null}newLine(){let e=(0,ot.h)("div",{class:"cl"});for(this.lines.appendChild(e);this.lines.childElementCount>l1;)this.lines.firstChild.remove();return e}write(e,t=""){if(!e)return;let i=this.atBottom(),s="",n=()=>{if(!s)return;this.cur||(this.cur=this.newLine());let o=[t,this.sgr].filter(Boolean).join(" "),l=this.cur.lastChild;if(l&&l.nodeType===1&&l.className===o)l.textContent+=s;else{let a=document.createElement("span");o&&(a.className=o),a.textContent=s,this.cur.appendChild(a)}s=""};for(let o=0;o<e.length;o++){let l=e[o];if(l===`
`)n(),this.cur||(this.cur=this.newLine()),this.cur.firstChild||(this.cur.innerHTML="&#8203;"),this.cur=null;else if(l==="\r"){if(e[o+1]===`
`)continue;n(),this.cur&&(this.cur.innerHTML="")}else if(l==="\b")n(),this.backspace();else if(l==="\x1B"&&e[o+1]==="["){n();let a=/^\x1b\[([\d;?]*)([A-Za-z])/.exec(e.slice(o));if(!a)continue;if(o+=a[0].length-1,a[2]==="m"){let h=a[1].split(";").filter(Boolean).map(Number);h.length||h.push(0);let c=new Set(this.sgr.split(" ").filter(Boolean));for(let u of h)if(u===0)c.clear();else if(u===1)c.add("bold");else if(Qd[u]){for(let p of[...c])p.startsWith("fg-")&&c.delete(p);c.add("fg-"+Qd[u])}this.sgr=[...c].join(" ")}else a[2]==="J"?this.clear():a[2]}else l==="\x07"||l==="\0"||(s+=l)}n(),i&&this.scrollEnd()}backspace(){if(!this.cur)return;let e=this.cur.lastChild;e&&(e.textContent=e.textContent.slice(0,-1),e.textContent||e.remove())}writeln(e="",t=""){this.write(e+`
`,t)}segs(e){for(let[t,i]of e)this.write(t,i||"")}atBottom(){let e=this.scroller;return e.scrollHeight-e.scrollTop-e.clientHeight<40}scrollEnd(){requestAnimationFrame(()=>{this.scroller.scrollTop=this.scroller.scrollHeight})}prompt(e="",t={}){if(this.pending){let s=this.pending;this.pending=null,s.resolve(null)}if(this.prefix.innerHTML="",this.cur&&this.cur.textContent){for(;this.cur.firstChild;)this.prefix.appendChild(this.cur.firstChild);this.cur.remove(),this.cur=null}let i=typeof e=="string"?[[e,""]]:e;for(let[s,n]of i){let o=document.createElement("span");n&&(o.className=n),o.textContent=s,this.prefix.appendChild(o)}return this.input.value=t.value||"",this.input.type=t.mask?"password":"text",this.inrow.classList.remove("hidden"),this.hIdx=this.history.length,this.keepHistory=t.keepHistory!==!1,this.scrollEnd(),t.focus!==!1&&this.focus(),new Promise(s=>{this.pending={resolve:s}})}get waiting(){return!!this.pending}submit(e=this.input.value){if(!this.pending)return;let t=this.pending;this.pending=null;let i=(0,ot.h)("div",{class:"cl"});for(;this.prefix.firstChild;)i.appendChild(this.prefix.firstChild);i.appendChild((0,ot.h)("span",{class:"con-typed"},this.input.type==="password"?"":e)),this.lines.appendChild(i),this.cur=null,this.inrow.classList.add("hidden"),this.input.value="",e.trim()&&this.keepHistory&&this.history[this.history.length-1]!==e&&this.history.push(e),this.scrollEnd(),t.resolve(e)}cancel(e="^C"){if(!this.pending)return!1;let t=this.pending;this.pending=null;let i=(0,ot.h)("div",{class:"cl"});for(;this.prefix.firstChild;)i.appendChild(this.prefix.firstChild);return i.appendChild((0,ot.h)("span",{},this.input.value+e)),this.lines.appendChild(i),this.cur=null,this.inrow.classList.add("hidden"),this.input.value="",t.resolve(null),!0}hideInput(){if(this.pending){let e=this.pending;this.pending=null,e.resolve(null)}this.inrow.classList.add("hidden")}keydown(e){if(this.onKey&&this.onKey(e,this)===!0){e.preventDefault();return}if(e.key==="Enter"){e.preventDefault(),this.submit();return}if(e.key==="ArrowUp"){e.preventDefault(),this.histMove(-1);return}e.key==="ArrowDown"&&(e.preventDefault(),this.histMove(1))}histMove(e){if(!this.history.length)return;this.hIdx=Math.max(0,Math.min(this.history.length,this.hIdx+e)),this.input.value=this.history[this.hIdx]||"";let t=this.input.value.length;requestAnimationFrame(()=>this.input.setSelectionRange(t,t))}insert(e){let t=this.input,i=t.selectionStart??t.value.length,s=t.selectionEnd??t.value.length;t.value=t.value.slice(0,i)+e+t.value.slice(s),t.setSelectionRange(i+e.length,i+e.length),this.focus()}};var bl=[],Fd=[];(()=>{let r="lc,34,7n,7,7b,19,,,,2,,2,,,20,b,1c,l,g,,2t,7,2,6,2,2,,4,z,,u,r,2j,b,1m,9,9,,o,4,,9,,3,,5,17,3,1n,9,16,o,,x,1i,3,,i,,7,a,2,t,3,1k,,,7,2,2,2,3,9,,a,2,q,,2,3,1k,,,5,4,2,2,3,3,,u,2,3,,b,3,1k,,,8,,3,,3,k,2,m,6,,3,1k,,,7,2,2,2,3,7,3,a,2,u,,1n,5,3,3,,4,9,,14,5,1j,,,7,,3,,4,7,2,b,2,t,3,1k,,,7,,3,,4,7,2,b,2,f,,c,4,1j,2,,7,,3,,4,9,,a,2,t,3,1y,,4,6,,,,8,i,2,1p,,,8,c,8,2q,,,a,b,7,21,2,r,,,,,,4,2,1d,k,,2,5,b,,10,9,,2u,b,,6,n,4,4,3,g,4,d,,,3,6,,f,,jj,3,qa,4,s,3,t,2,u,2,1s,w,9,,19,3,,,39,2,y,,3a,c,4,c,63,5,1l,a,,,,,2,o,2,,1c,1a,2,c,k,5,1b,h,12,9,c,3,u,d,1k,e,1c,k,48,3,,l,4,,6,,2,3,5i,1s,ek,,5f,x,2da,3,3x,,2o,w,fe,6,2x,2,n9w,4,,a,w,2,28,2,7k,,3,,4,,n,5,4,,2b,2,1e,i,q,i,d,,12,8,p,d,18,4,1b,e,10,,1v,e,c,,8,2,1a,,1f,,,3,2,2,5,2,,,15,5,5,2,6k,8,,2,fn4,,kh,g,g,g,a6,2,gt,,6a,,45,5,1ae,3,,2,5,4,14,3,4,,4l,2,fx,4,1t,5,8t,2,25,6,1y,b,1d,4,3e,3,1h,f,15,,2,2,a,4,19,b,7,,1p,3,10,e,g,2,18,,c,3,1c,e,8,4,,2,2k,c,6,,2,,4d,c,l,4,1j,2,,7,2,2,2,3,9,,a,2,2,7,3,5,1v,9,,,2,,,4,,5,,,e,2,2a,i,n,,29,k,6j,7,2,9,r,2,2a,h,2y,d,2t,3,2,a,74,f,6t,6,,2,2,4,,,,2,3x,7,2,7,3,,s,a,14,7,,4,8,,9,b,1a,g,5i,8,5j,8,,8,2a,m,,e,3e,6,3,,,2,,7,,,1u,5,,2,,5,9n,4,9,2,,,1c,7,3,5,n,,44l,,6,f,8ug,i,1xc,5,1n,7,t4,,,1j,7,4,29,,b,2,f57,2,3mp,1a,2,n,f2,5,3,6,8,8,2,7,u,4,44,3,1iz,1j,4,1e,8,,e,,m,5,,f,11s,7,,h,2,7,,2,,5,2s,,4g,7,af,,1p,4,e4,4,72,2,6r,,2,,7,2,5,,d6,7,31,7,240,5".split(",").map(e=>e?parseInt(e,36):1);for(let e=0,t=0;e<r.length;e++)(e%2?Fd:bl).push(t=t+r[e])})();function a1(r){if(r<768)return!1;for(let e=0,t=bl.length;;){let i=e+t>>1;if(r<bl[i])t=i;else if(r>=Fd[i])e=i+1;else return!0;if(e==t)return!1}}function qd(r){return r>=127462&&r<=127487}var Bd=8205;function Wd(r,e,t=!0,i=!0){return(t?zd:h1)(r,e,i)}function zd(r,e,t){if(e==r.length)return e;e&&jd(r.charCodeAt(e))&&Hd(r.charCodeAt(e-1))&&e--;let i=yl(r,e);for(e+=$d(i);e<r.length;){let s=yl(r,e);if(i==Bd||s==Bd||t&&a1(s))e+=$d(s),i=s;else if(qd(s)){let n=0,o=e-2;for(;o>=0&&qd(yl(r,o));)n++,o-=2;if(n%2==0)break;e+=2}else break}return e}function h1(r,e,t){for(;e>1;){let i=zd(r,e-2,t);if(i<e)return i;e--}return 0}function yl(r,e){let t=r.charCodeAt(e);if(!Hd(t)||e+1==r.length)return t;let i=r.charCodeAt(e+1);return jd(i)?(t-55296<<10)+(i-56320)+65536:t}function jd(r){return r>=56320&&r<57344}function Hd(r){return r>=55296&&r<56320}function $d(r){return r<65536?1:2}var oe=class r{lineAt(e){if(e<0||e>this.length)throw new RangeError(`Invalid position ${e} in document of length ${this.length}`);return this.lineInner(e,!1,1,0)}line(e){if(e<1||e>this.lines)throw new RangeError(`Invalid line number ${e} in ${this.lines}-line document`);return this.lineInner(e,!0,1,0)}replace(e,t,i){[e,t]=xs(this,e,t);let s=[];return this.decompose(0,e,s,2),i.length&&i.decompose(0,i.length,s,3),this.decompose(t,this.length,s,1),vs.from(s,this.length-(t-e)+i.length)}append(e){return this.replace(this.length,this.length,e)}slice(e,t=this.length){[e,t]=xs(this,e,t);let i=[];return this.decompose(e,t,i,0),vs.from(i,t-e)}eq(e){if(e==this)return!0;if(e.length!=this.length||e.lines!=this.lines)return!1;let t=this.scanIdentical(e,1),i=this.length-this.scanIdentical(e,-1),s=new ji(this),n=new ji(e);for(let o=t,l=t;;){if(s.next(o),n.next(o),o=0,s.lineBreak!=n.lineBreak||s.done!=n.done||s.value!=n.value)return!1;if(l+=s.value.length,s.done||l>=i)return!0}}iter(e=1){return new ji(this,e)}iterRange(e,t=this.length){return new cn(this,e,t)}iterLines(e,t){let i;if(e==null)i=this.iter();else{t==null&&(t=this.lines+1);let s=this.line(e).from;i=this.iterRange(s,Math.max(s,t==this.lines+1?this.length:t<=1?0:this.line(t-1).to))}return new dn(i)}toString(){return this.sliceString(0)}toJSON(){let e=[];return this.flatten(e),e}constructor(){}static of(e){if(e.length==0)throw new RangeError("A document must have at least one line");return e.length==1&&!e[0]?r.empty:e.length<=32?new ft(e):vs.from(ft.split(e,[]))}},ft=class r extends oe{constructor(e,t=f1(e)){super(),this.text=e,this.length=t}get lines(){return this.text.length}get children(){return null}lineInner(e,t,i,s){for(let n=0;;n++){let o=this.text[n],l=s+o.length;if((t?i:l)>=e)return new vl(s,l,i,o);s=l+1,i++}}decompose(e,t,i,s){let n=e<=0&&t>=this.length?this:new r(Vd(this.text,e,t),Math.min(t,this.length)-Math.max(0,e));if(s&1){let o=i.pop(),l=fn(n.text,o.text.slice(),0,n.length);if(l.length<=32)i.push(new r(l,o.length+n.length));else{let a=l.length>>1;i.push(new r(l.slice(0,a)),new r(l.slice(a)))}}else i.push(n)}replace(e,t,i){if(!(i instanceof r))return super.replace(e,t,i);[e,t]=xs(this,e,t);let s=fn(this.text,fn(i.text,Vd(this.text,0,e)),t),n=this.length+i.length-(t-e);return s.length<=32?new r(s,n):vs.from(r.split(s,[]),n)}sliceString(e,t=this.length,i=`
`){[e,t]=xs(this,e,t);let s="";for(let n=0,o=0;n<=t&&o<this.text.length;o++){let l=this.text[o],a=n+l.length;n>e&&o&&(s+=i),e<a&&t>n&&(s+=l.slice(Math.max(0,e-n),t-n)),n=a+1}return s}flatten(e){for(let t of this.text)e.push(t)}scanIdentical(){return 0}static split(e,t){let i=[],s=-1;for(let n of e)i.push(n),s+=n.length+1,i.length==32&&(t.push(new r(i,s)),i=[],s=-1);return s>-1&&t.push(new r(i,s)),t}},vs=class r extends oe{constructor(e,t){super(),this.children=e,this.length=t,this.lines=0;for(let i of e)this.lines+=i.lines}lineInner(e,t,i,s){for(let n=0;;n++){let o=this.children[n],l=s+o.length,a=i+o.lines-1;if((t?a:l)>=e)return o.lineInner(e,t,i,s);s=l+1,i=a+1}}decompose(e,t,i,s){for(let n=0,o=0;o<=t&&n<this.children.length;n++){let l=this.children[n],a=o+l.length;if(e<=a&&t>=o){let h=s&((o<=e?1:0)|(a>=t?2:0));o>=e&&a<=t&&!h?i.push(l):l.decompose(e-o,t-o,i,h)}o=a+1}}replace(e,t,i){if([e,t]=xs(this,e,t),i.lines<this.lines)for(let s=0,n=0;s<this.children.length;s++){let o=this.children[s],l=n+o.length;if(e>=n&&t<=l){let a=o.replace(e-n,t-n,i),h=this.lines-o.lines+a.lines;if(a.lines<h>>4&&a.lines>h>>6){let c=this.children.slice();return c[s]=a,new r(c,this.length-(t-e)+i.length)}return super.replace(n,l,a)}n=l+1}return super.replace(e,t,i)}sliceString(e,t=this.length,i=`
`){[e,t]=xs(this,e,t);let s="";for(let n=0,o=0;n<this.children.length&&o<=t;n++){let l=this.children[n],a=o+l.length;o>e&&n&&(s+=i),e<a&&t>o&&(s+=l.sliceString(e-o,t-o,i)),o=a+1}return s}flatten(e){for(let t of this.children)t.flatten(e)}scanIdentical(e,t){if(!(e instanceof r))return 0;let i=0,[s,n,o,l]=t>0?[0,0,this.children.length,e.children.length]:[this.children.length-1,e.children.length-1,-1,-1];for(;;s+=t,n+=t){if(s==o||n==l)return i;let a=this.children[s],h=e.children[n];if(a!=h)return i+a.scanIdentical(h,t);i+=a.length+1}}static from(e,t=e.reduce((i,s)=>i+s.length+1,-1)){let i=0;for(let y of e)i+=y.lines;if(i<32){let y=[];for(let O of e)O.flatten(y);return new ft(y,t)}let s=Math.max(32,i>>5),n=s<<1,o=s>>1,l=[],a=0,h=-1,c=[];function u(y){let O;if(y.lines>n&&y instanceof r)for(let b of y.children)u(b);else y.lines>o&&(a>o||!a)?(p(),l.push(y)):y instanceof ft&&a&&(O=c[c.length-1])instanceof ft&&y.lines+O.lines<=32?(a+=y.lines,h+=y.length+1,c[c.length-1]=new ft(O.text.concat(y.text),O.length+1+y.length)):(a+y.lines>s&&p(),a+=y.lines,h+=y.length+1,c.push(y))}function p(){a!=0&&(l.push(c.length==1?c[0]:r.from(c,h)),h=-1,a=c.length=0)}for(let y of e)u(y);return p(),l.length==1?l[0]:new r(l,t)}};oe.empty=new ft([""],0);function f1(r){let e=-1;for(let t of r)e+=t.length+1;return e}function fn(r,e,t=0,i=1e9){for(let s=0,n=0,o=!0;n<r.length&&s<=i;n++){let l=r[n],a=s+l.length;a>=t&&(a>i&&(l=l.slice(0,i-s)),s<t&&(l=l.slice(t-s)),o?(e[e.length-1]+=l,o=!1):e.push(l)),s=a+1}return e}function Vd(r,e,t){return fn(r,[""],e,t)}var ji=class{constructor(e,t=1){this.dir=t,this.done=!1,this.lineBreak=!1,this.value="",this.nodes=[e],this.offsets=[t>0?1:(e instanceof ft?e.text.length:e.children.length)<<1]}nextInner(e,t){for(this.done=this.lineBreak=!1;;){let i=this.nodes.length-1,s=this.nodes[i],n=this.offsets[i],o=n>>1,l=s instanceof ft?s.text.length:s.children.length;if(o==(t>0?l:0)){if(i==0)return this.done=!0,this.value="",this;t>0&&this.offsets[i-1]++,this.nodes.pop(),this.offsets.pop()}else if((n&1)==(t>0?0:1)){if(this.offsets[i]+=t,e==0)return this.lineBreak=!0,this.value=`
`,this;e--}else if(s instanceof ft){let a=s.text[o+(t<0?-1:0)];if(this.offsets[i]+=t,a.length>Math.max(0,e))return this.value=e==0?a:t>0?a.slice(e):a.slice(0,a.length-e),this;e-=a.length}else{let a=s.children[o+(t<0?-1:0)];e>a.length?(e-=a.length,this.offsets[i]+=t):(t<0&&this.offsets[i]--,this.nodes.push(a),this.offsets.push(t>0?1:(a instanceof ft?a.text.length:a.children.length)<<1))}}}next(e=0){return e<0&&(this.nextInner(-e,-this.dir),e=this.value.length),this.nextInner(e,this.dir)}},cn=class{constructor(e,t,i){this.value="",this.done=!1,this.cursor=new ji(e,t>i?-1:1),this.pos=t>i?e.length:0,this.from=Math.min(t,i),this.to=Math.max(t,i)}nextInner(e,t){if(t<0?this.pos<=this.from:this.pos>=this.to)return this.value="",this.done=!0,this;e+=Math.max(0,t<0?this.pos-this.to:this.from-this.pos);let i=t<0?this.pos-this.from:this.to-this.pos;e>i&&(e=i),i-=e;let{value:s}=this.cursor.next(e);return this.pos+=(s.length+e)*t,this.value=s.length<=i?s:t<0?s.slice(s.length-i):s.slice(0,i),this.done=!this.value,this}next(e=0){return e<0?e=Math.max(e,this.from-this.pos):e>0&&(e=Math.min(e,this.to-this.pos)),this.nextInner(e,this.cursor.dir)}get lineBreak(){return this.cursor.lineBreak&&this.value!=""}},dn=class{constructor(e){this.inner=e,this.afterBreak=!0,this.value="",this.done=!1}next(e=0){let{done:t,lineBreak:i,value:s}=this.inner.next(e);return t&&this.afterBreak?(this.value="",this.afterBreak=!1):t?(this.done=!0,this.value=""):i?this.afterBreak?this.value="":(this.afterBreak=!0,this.next()):(this.value=s,this.afterBreak=!1),this}get lineBreak(){return!1}};typeof Symbol<"u"&&(oe.prototype[Symbol.iterator]=function(){return this.iter()},ji.prototype[Symbol.iterator]=cn.prototype[Symbol.iterator]=dn.prototype[Symbol.iterator]=function(){return this});var vl=class{constructor(e,t,i,s){this.from=e,this.to=t,this.number=i,this.text=s}get length(){return this.to-this.from}};function xs(r,e,t){return e=Math.max(0,Math.min(r.length,e)),[e,Math.max(e,Math.min(r.length,t))]}function Ce(r,e,t=!0,i=!0){return Wd(r,e,t,i)}function c1(r){return r>=56320&&r<57344}function d1(r){return r>=55296&&r<56320}function Ge(r,e){let t=r.charCodeAt(e);if(!d1(t)||e+1==r.length)return t;let i=r.charCodeAt(e+1);return c1(i)?(t-55296<<10)+(i-56320)+65536:t}function fr(r){return r<=65535?String.fromCharCode(r):(r-=65536,String.fromCharCode((r>>10)+55296,(r&1023)+56320))}function ct(r){return r<65536?1:2}var wl=/\r\n?|\n/,Le=function(r){return r[r.Simple=0]="Simple",r[r.TrackDel=1]="TrackDel",r[r.TrackBefore=2]="TrackBefore",r[r.TrackAfter=3]="TrackAfter",r}(Le||(Le={})),ri=class r{constructor(e){this.sections=e}get length(){let e=0;for(let t=0;t<this.sections.length;t+=2)e+=this.sections[t];return e}get newLength(){let e=0;for(let t=0;t<this.sections.length;t+=2){let i=this.sections[t+1];e+=i<0?this.sections[t]:i}return e}get empty(){return this.sections.length==0||this.sections.length==2&&this.sections[1]<0}iterGaps(e){for(let t=0,i=0,s=0;t<this.sections.length;){let n=this.sections[t++],o=this.sections[t++];o<0?(e(i,s,n),s+=n):s+=o,i+=n}}iterChangedRanges(e,t=!1){kl(this,e,t)}get invertedDesc(){let e=[];for(let t=0;t<this.sections.length;){let i=this.sections[t++],s=this.sections[t++];s<0?e.push(i,s):e.push(s,i)}return new r(e)}composeDesc(e){return this.empty?e:e.empty?this:Yd(this,e)}mapDesc(e,t=!1){return e.empty?this:xl(this,e,t)}mapPos(e,t=-1,i=Le.Simple){let s=0,n=0;for(let o=0;o<this.sections.length;){let l=this.sections[o++],a=this.sections[o++],h=s+l;if(a<0){if(h>e)return n+(e-s);n+=l}else{if(i!=Le.Simple&&h>=e&&(i==Le.TrackDel&&s<e&&h>e||i==Le.TrackBefore&&s<e||i==Le.TrackAfter&&h>e))return null;if(h>e||h==e&&t<0&&!l)return e==s||t<0?n:n+a;n+=a}s=h}if(e>s)throw new RangeError(`Position ${e} is out of range for changeset of length ${s}`);return n}touchesRange(e,t=e){for(let i=0,s=0;i<this.sections.length&&s<=t;){let n=this.sections[i++],o=this.sections[i++],l=s+n;if(o>=0&&s<=t&&l>=e)return s<e&&l>t?"cover":!0;s=l}return!1}toString(){let e="";for(let t=0;t<this.sections.length;){let i=this.sections[t++],s=this.sections[t++];e+=(e?" ":"")+i+(s>=0?":"+s:"")}return e}toJSON(){return this.sections}static fromJSON(e){if(!Array.isArray(e)||e.length%2||e.some(t=>typeof t!="number"))throw new RangeError("Invalid JSON representation of ChangeDesc");return new r(e)}static create(e){return new r(e)}},Ze=class r extends ri{constructor(e,t){super(e),this.inserted=t}apply(e){if(this.length!=e.length)throw new RangeError("Applying change set to a document with the wrong length");return kl(this,(t,i,s,n,o)=>e=e.replace(s,s+(i-t),o),!1),e}mapDesc(e,t=!1){return xl(this,e,t,!0)}invert(e){let t=this.sections.slice(),i=[];for(let s=0,n=0;s<t.length;s+=2){let o=t[s],l=t[s+1];if(l>=0){t[s]=l,t[s+1]=o;let a=s>>1;for(;i.length<a;)i.push(oe.empty);i.push(o?e.slice(n,n+o):oe.empty)}n+=o}return new r(t,i)}compose(e){return this.empty?e:e.empty?this:Yd(this,e,!0)}map(e,t=!1){return e.empty?this:xl(this,e,t,!0)}iterChanges(e,t=!1){kl(this,e,t)}get desc(){return ri.create(this.sections)}filter(e){let t=[],i=[],s=[],n=new Hi(this);e:for(let o=0,l=0;;){let a=o==e.length?1e9:e[o++];for(;l<a||l==a&&n.len==0;){if(n.done)break e;let c=Math.min(n.len,a-l);Ue(s,c,-1);let u=n.ins==-1?-1:n.off==0?n.ins:0;Ue(t,c,u),u>0&&yi(i,t,n.text),n.forward(c),l+=c}let h=e[o++];for(;l<h;){if(n.done)break e;let c=Math.min(n.len,h-l);Ue(t,c,-1),Ue(s,c,n.ins==-1?-1:n.off==0?n.ins:0),n.forward(c),l+=c}}return{changes:new r(t,i),filtered:ri.create(s)}}toJSON(){let e=[];for(let t=0;t<this.sections.length;t+=2){let i=this.sections[t],s=this.sections[t+1];s<0?e.push(i):s==0?e.push([i]):e.push([i].concat(this.inserted[t>>1].toJSON()))}return e}static of(e,t,i){let s=[],n=[],o=0,l=null;function a(c=!1){if(!c&&!s.length)return;o<t&&Ue(s,t-o,-1);let u=new r(s,n);l=l?l.compose(u.map(l)):u,s=[],n=[],o=0}function h(c){if(Array.isArray(c))for(let u of c)h(u);else if(c instanceof r){if(c.length!=t)throw new RangeError(`Mismatched change set length (got ${c.length}, expected ${t})`);a(),l=l?l.compose(c.map(l)):c}else{let{from:u,to:p=u,insert:y}=c;if(u>p||u<0||p>t)throw new RangeError(`Invalid change range ${u} to ${p} (in doc of length ${t})`);let O=y?typeof y=="string"?oe.of(y.split(i||wl)):y:oe.empty,b=O.length;if(u==p&&b==0)return;u<o&&a(),u>o&&Ue(s,u-o,-1),Ue(s,p-u,b),yi(n,s,O),o=p}}return h(e),a(!l),l}static empty(e){return new r(e?[e,-1]:[],[])}static fromJSON(e){if(!Array.isArray(e))throw new RangeError("Invalid JSON representation of ChangeSet");let t=[],i=[];for(let s=0;s<e.length;s++){let n=e[s];if(typeof n=="number")t.push(n,-1);else{if(!Array.isArray(n)||typeof n[0]!="number"||n.some((o,l)=>l&&typeof o!="string"))throw new RangeError("Invalid JSON representation of ChangeSet");if(n.length==1)t.push(n[0],0);else{for(;i.length<s;)i.push(oe.empty);i[s]=oe.of(n.slice(1)),t.push(n[0],i[s].length)}}}return new r(t,i)}static createSet(e,t){return new r(e,t)}};function Ue(r,e,t,i=!1){if(e==0&&t<=0)return;let s=r.length-2;s>=0&&t<=0&&t==r[s+1]?r[s]+=e:s>=0&&e==0&&r[s]==0?r[s+1]+=t:i?(r[s]+=e,r[s+1]+=t):r.push(e,t)}function yi(r,e,t){if(t.length==0)return;let i=e.length-2>>1;if(i<r.length)r[r.length-1]=r[r.length-1].append(t);else{for(;r.length<i;)r.push(oe.empty);r.push(t)}}function kl(r,e,t){let i=r.inserted;for(let s=0,n=0,o=0;o<r.sections.length;){let l=r.sections[o++],a=r.sections[o++];if(a<0)s+=l,n+=l;else{let h=s,c=n,u=oe.empty;for(;h+=l,c+=a,a&&i&&(u=u.append(i[o-2>>1])),!(t||o==r.sections.length||r.sections[o+1]<0);)l=r.sections[o++],a=r.sections[o++];e(s,h,n,c,u),s=h,n=c}}}function xl(r,e,t,i=!1){let s=[],n=i?[]:null,o=new Hi(r),l=new Hi(e);for(let a=-1;;){if(o.done&&l.len||l.done&&o.len)throw new Error("Mismatched change set lengths");if(o.ins==-1&&l.ins==-1){let h=Math.min(o.len,l.len);Ue(s,h,-1),o.forward(h),l.forward(h)}else if(l.ins>=0&&(o.ins<0||a==o.i||o.off==0&&(l.len<o.len||l.len==o.len&&!t))){let h=l.len;for(Ue(s,l.ins,-1);h;){let c=Math.min(o.len,h);o.ins>=0&&a<o.i&&o.len<=c&&(Ue(s,0,o.ins),n&&yi(n,s,o.text),a=o.i),o.forward(c),h-=c}l.next()}else if(o.ins>=0){let h=0,c=o.len;for(;c;)if(l.ins==-1){let u=Math.min(c,l.len);h+=u,c-=u,l.forward(u)}else if(l.ins==0&&l.len<c)c-=l.len,l.next();else break;Ue(s,h,a<o.i?o.ins:0),n&&a<o.i&&yi(n,s,o.text),a=o.i,o.forward(o.len-c)}else{if(o.done&&l.done)return n?Ze.createSet(s,n):ri.create(s);throw new Error("Mismatched change set lengths")}}}function Yd(r,e,t=!1){let i=[],s=t?[]:null,n=new Hi(r),o=new Hi(e);for(let l=!1;;){if(n.done&&o.done)return s?Ze.createSet(i,s):ri.create(i);if(n.ins==0)Ue(i,n.len,0,l),n.next();else if(o.len==0&&!o.done)Ue(i,0,o.ins,l),s&&yi(s,i,o.text),o.next();else{if(n.done||o.done)throw new Error("Mismatched change set lengths");{let a=Math.min(n.len2,o.len),h=i.length;if(n.ins==-1){let c=o.ins==-1?-1:o.off?0:o.ins;Ue(i,a,c,l),s&&c&&yi(s,i,o.text)}else o.ins==-1?(Ue(i,n.off?0:n.len,a,l),s&&yi(s,i,n.textBit(a))):(Ue(i,n.off?0:n.len,o.off?0:o.ins,l),s&&!o.off&&yi(s,i,o.text));l=(n.ins>a||o.ins>=0&&o.len>a)&&(l||i.length>h),n.forward2(a),o.forward(a)}}}}var Hi=class{constructor(e){this.set=e,this.i=0,this.next()}next(){let{sections:e}=this.set;this.i<e.length?(this.len=e[this.i++],this.ins=e[this.i++]):(this.len=0,this.ins=-2),this.off=0}get done(){return this.ins==-2}get len2(){return this.ins<0?this.len:this.ins}get text(){let{inserted:e}=this.set,t=this.i-2>>1;return t>=e.length?oe.empty:e[t]}textBit(e){let{inserted:t}=this.set,i=this.i-2>>1;return i>=t.length&&!e?oe.empty:t[i].slice(this.off,e==null?void 0:this.off+e)}forward(e){e==this.len?this.next():(this.len-=e,this.off+=e)}forward2(e){this.ins==-1?this.forward(e):e==this.ins?this.next():(this.ins-=e,this.off+=e)}},Fi=class r{constructor(e,t,i,s){this.from=e,this.to=t,this.flags=i,this.goalColumn=s}get anchor(){return this.flags&32?this.to:this.from}get head(){return this.flags&32?this.from:this.to}get empty(){return this.from==this.to}get assoc(){return this.flags&8?-1:this.flags&16?1:0}get undirectional(){return(this.flags&64)>0}get bidiLevel(){let e=this.flags&7;return e==7?null:e}map(e,t=-1){let i,s;return this.empty?i=s=e.mapPos(this.from,t):(i=e.mapPos(this.from,1),s=e.mapPos(this.to,-1)),i==this.from&&s==this.to?this:new r(i,s,this.flags,this.goalColumn)}extend(e,t=e,i=0){if(e<=this.anchor&&t>=this.anchor)return M.range(e,t,void 0,void 0,i);let s=Math.abs(e-this.anchor)>Math.abs(t-this.anchor)?e:t;return M.range(this.anchor,s,void 0,void 0,i)}eq(e,t=!1){return this.anchor==e.anchor&&this.head==e.head&&this.goalColumn==e.goalColumn&&(!t||!this.empty||this.assoc==e.assoc)}toJSON(){return{anchor:this.anchor,head:this.head}}static fromJSON(e){if(!e||typeof e.anchor!="number"||typeof e.head!="number")throw new RangeError("Invalid JSON representation for SelectionRange");return M.range(e.anchor,e.head)}static create(e,t,i,s){return new r(e,t,i,s)}},M=class r{constructor(e,t){this.ranges=e,this.mainIndex=t}map(e,t=-1){return e.empty?this:r.create(this.ranges.map(i=>i.map(e,t)),this.mainIndex)}eq(e,t=!1){if(this.ranges.length!=e.ranges.length||this.mainIndex!=e.mainIndex)return!1;for(let i=0;i<this.ranges.length;i++)if(!this.ranges[i].eq(e.ranges[i],t))return!1;return!0}get main(){return this.ranges[this.mainIndex]}asSingle(){return this.ranges.length==1?this:new r([this.main],0)}addRange(e,t=!0){return r.create([e].concat(this.ranges),t?0:this.mainIndex+1)}replaceRange(e,t=this.mainIndex){let i=this.ranges.slice();return i[t]=e,r.create(i,this.mainIndex)}toJSON(){return{ranges:this.ranges.map(e=>e.toJSON()),main:this.mainIndex}}static fromJSON(e){if(!e||!Array.isArray(e.ranges)||typeof e.main!="number"||e.main>=e.ranges.length)throw new RangeError("Invalid JSON representation for EditorSelection");return new r(e.ranges.map(t=>Fi.fromJSON(t)),e.main)}static single(e,t=e){return new r([r.range(e,t)],0)}static create(e,t=0){if(e.length==0)throw new RangeError("A selection needs at least one range");for(let i=0,s=0;s<e.length;s++){let n=e[s];if(n.empty?n.from<=i:n.from<i)return r.normalized(e.slice(),t);i=n.to}return new r(e,t)}static cursor(e,t=0,i,s){return Fi.create(e,e,(t==0?0:t<0?8:16)|(i==null?7:Math.min(6,i)),s)}static range(e,t,i,s,n){let o=s==null?7:Math.min(6,s);return!n&&e!=t&&(n=t<e?1:-1),n&&(o|=n<0?8:16),t<e?Fi.create(t,e,o|32,i):Fi.create(e,t,o,i)}static undirectionalRange(e,t){return Fi.create(e,t,64,void 0)}static normalized(e,t=0){let i=e[t];e.sort((s,n)=>s.from-n.from),t=e.indexOf(i);for(let s=1;s<e.length;s++){let n=e[s],o=e[s-1];if(n.empty?n.from<=o.to:n.from<o.to){let l=o.from,a=Math.max(n.to,o.to);s<=t&&t--,e.splice(--s,2,n.anchor>n.head?r.range(a,l):r.range(l,a))}}return new r(e,t)}};function Kd(r,e){for(let t of r.ranges)if(t.to>e)throw new RangeError("Selection points outside of document")}var Nl=0,W=class r{constructor(e,t,i,s,n){this.combine=e,this.compareInput=t,this.compare=i,this.isStatic=s,this.id=Nl++,this.default=e([]),this.extensions=typeof n=="function"?n(this):n}get reader(){return this}static define(e={}){return new r(e.combine||(t=>t),e.compareInput||((t,i)=>t===i),e.compare||(e.combine?(t,i)=>t===i:Il),!!e.static,e.enables)}of(e){return new ws([],this,0,e)}compute(e,t){if(this.isStatic)throw new Error("Can't compute a static facet");return new ws(e,this,1,t)}computeN(e,t){if(this.isStatic)throw new Error("Can't compute a static facet");return new ws(e,this,2,t)}from(e,t){return t||(t=i=>i),this.compute([e],i=>t(i.field(e)))}};function Il(r,e){return r==e||r.length==e.length&&r.every((t,i)=>t===e[i])}var ws=class{constructor(e,t,i,s){this.dependencies=e,this.facet=t,this.type=i,this.value=s,this.id=Nl++}dynamicSlot(e){var t;let i=this.value,s=this.facet.compareInput,n=this.id,o=e[n]>>1,l=this.type==2,a=!1,h=!1,c=[];for(let u of this.dependencies)u=="doc"?a=!0:u=="selection"?h=!0:((t=e[u.id])!==null&&t!==void 0?t:1)&1||c.push(e[u.id]);return{create(u){return u.values[o]=i(u),1},update(u,p){if(a&&p.docChanged||h&&(p.docChanged||p.selection)||Sl(u,c)){let y=i(u);if(l?!Ud(y,u.values[o],s):!s(y,u.values[o]))return u.values[o]=y,1}return 0},reconfigure:(u,p)=>{let y,O=p.config.address[n];if(O!=null){let b=mn(p,O);if(this.dependencies.every(v=>v instanceof W?p.facet(v)===u.facet(v):v instanceof Qe?p.field(v,!1)==u.field(v,!1):!0)||(l?Ud(y=i(u),b,s):s(y=i(u),b)))return u.values[o]=b,0}else y=i(u);return u.values[o]=y,1}}}get extension(){return this}};function Ud(r,e,t){if(r.length!=e.length)return!1;for(let i=0;i<r.length;i++)if(!t(r[i],e[i]))return!1;return!0}function Sl(r,e){let t=!1;for(let i of e)or(r,i)&1&&(t=!0);return t}function u1(r,e,t){let i=t.map(a=>r[a.id]),s=t.map(a=>a.type),n=i.filter(a=>!(a&1)),o=r[e.id]>>1;function l(a){let h=[];for(let c=0;c<i.length;c++){let u=mn(a,i[c]);if(s[c]==2)for(let p of u)h.push(p);else h.push(u)}return e.combine(h)}return{create(a){for(let h of i)or(a,h);return a.values[o]=l(a),1},update(a,h){if(!Sl(a,n))return 0;let c=l(a);return e.compare(c,a.values[o])?0:(a.values[o]=c,1)},reconfigure(a,h){let c=Sl(a,i),u=h.config.facets[e.id],p=h.facet(e);if(u&&!c&&Il(t,u))return a.values[o]=p,0;let y=l(a);return e.compare(y,p)?(a.values[o]=p,0):(a.values[o]=y,1)}}}var ln=W.define({static:!0}),Qe=class r{constructor(e,t,i,s,n){this.id=e,this.createF=t,this.updateF=i,this.compareF=s,this.spec=n,this.provides=void 0}static define(e){let t=new r(Nl++,e.create,e.update,e.compare||((i,s)=>i===s),e);return e.provide&&(t.provides=e.provide(t)),t}create(e){let t=e.facet(ln).find(i=>i.field==this);return((t==null?void 0:t.create)||this.createF)(e)}slot(e){let t=e[this.id]>>1;return{create:i=>(i.values[t]=this.create(i),1),update:(i,s)=>{let n=i.values[t],o=this.updateF(n,s);return this.compareF(n,o)?0:(i.values[t]=o,1)},reconfigure:(i,s)=>{let n=i.facet(ln),o=s.facet(ln),l;return(l=n.find(a=>a.field==this))&&l!=o.find(a=>a.field==this)?(i.values[t]=l.create(i),1):s.config.address[this.id]!=null?(i.values[t]=s.field(this),0):(i.values[t]=this.create(i),1)}}}init(e){return[this,ln.of({field:this,create:e})]}get extension(){return this}},Wi={lowest:4,low:3,default:2,high:1,highest:0};function nr(r){return e=>new un(e,r)}var vt={highest:nr(Wi.highest),high:nr(Wi.high),default:nr(Wi.default),low:nr(Wi.low),lowest:nr(Wi.lowest)},un=class{constructor(e,t){this.inner=e,this.prec=t}get extension(){return this}},Ss=class r{of(e){return new lr(this,e)}reconfigure(e){return r.reconfigure.of({compartment:this,extension:e})}get(e){return e.config.compartments.get(this)}},lr=class{constructor(e,t){this.compartment=e,this.inner=t}get extension(){return this}},pn=class r{constructor(e,t,i,s,n,o){for(this.base=e,this.compartments=t,this.dynamicSlots=i,this.address=s,this.staticValues=n,this.facets=o,this.statusTemplate=[];this.statusTemplate.length<i.length;)this.statusTemplate.push(0)}staticFacet(e){let t=this.address[e.id];return t==null?e.default:this.staticValues[t>>1]}static resolve(e,t,i){let s=[],n=Object.create(null),o=new Map;for(let p of p1(e,t,o))p instanceof Qe?s.push(p):(n[p.facet.id]||(n[p.facet.id]=[])).push(p);let l=Object.create(null),a=[],h=[];for(let p of s)l[p.id]=h.length<<1,h.push(y=>p.slot(y));let c=i==null?void 0:i.config.facets;for(let p in n){let y=n[p],O=y[0].facet,b=c&&c[p]||[];if(y.every(v=>v.type==0))if(l[O.id]=a.length<<1|1,Il(b,y))a.push(i.facet(O));else{let v=O.combine(y.map(k=>k.value));a.push(i&&O.compare(v,i.facet(O))?i.facet(O):v)}else{for(let v of y)v.type==0?(l[v.id]=a.length<<1|1,a.push(v.value)):(l[v.id]=h.length<<1,h.push(k=>v.dynamicSlot(k)));l[O.id]=h.length<<1,h.push(v=>u1(v,O,y))}}let u=h.map(p=>p(l));return new r(e,o,u,l,a,n)}};function p1(r,e,t){let i=[[],[],[],[],[]],s=new Map;function n(o,l){let a=s.get(o);if(a!=null){if(a<=l)return;let h=i[a].indexOf(o);h>-1&&i[a].splice(h,1),o instanceof lr&&t.delete(o.compartment)}if(s.set(o,l),Array.isArray(o))for(let h of o)n(h,l);else if(o instanceof lr){if(t.has(o.compartment))throw new RangeError("Duplicate use of compartment in extensions");let h=e.get(o.compartment)||o.inner;t.set(o.compartment,h),n(h,l)}else if(o instanceof un)n(o.inner,o.prec);else if(o instanceof Qe)i[l].push(o),o.provides&&n(o.provides,l);else if(o instanceof ws)i[l].push(o),o.facet.extensions&&n(o.facet.extensions,Wi.default);else{let h=o.extension;if(!h)throw new Error(`Unrecognized extension value in extension set (${o}).`);if(h==o)throw new Error(`Unrecognized extension value in extension set (${o}). This sometimes happens because multiple instances of @codemirror/state are loaded, breaking instanceof checks.`);n(h,l)}}return n(r,Wi.default),i.reduce((o,l)=>o.concat(l))}function or(r,e){if(e&1)return 2;let t=e>>1,i=r.status[t];if(i==4)throw new Error("Cyclic dependency between fields and/or facets");if(i&2)return i;r.status[t]=4;let s=r.computeSlot(r,r.config.dynamicSlots[t]);return r.status[t]=2|s}function mn(r,e){return e&1?r.config.staticValues[e>>1]:r.values[e>>1]}var Zd=W.define(),Tl=W.define({combine:r=>r.some(e=>e),static:!0}),eu=W.define({combine:r=>r.length?r[0]:void 0,static:!0}),tu=W.define(),iu=W.define(),su=W.define(),ru=W.define({combine:r=>r.length?r[0]:!1}),lt=class{constructor(e,t){this.type=e,this.value=t}static define(){return new Pl}},Pl=class{of(e){return new lt(this,e)}},Cl=class{constructor(e){this.map=e}of(e){return new re(this,e)}},re=class r{constructor(e,t){this.type=e,this.value=t}map(e){let t=this.type.map(this.value,e);return t===void 0?void 0:t==this.value?this:new r(this.type,t)}is(e){return this.type==e}static define(e={}){return new Cl(e.map||(t=>t))}static mapEffects(e,t){if(!e.length)return e;let i=[];for(let s of e){let n=s.map(t);n&&i.push(n)}return i}};re.reconfigure=re.define();re.appendConfig=re.define();var Re=class r{constructor(e,t,i,s,n,o){this.startState=e,this.changes=t,this.selection=i,this.effects=s,this.annotations=n,this.scrollIntoView=o,this._doc=null,this._state=null,i&&Kd(i,t.newLength),n.some(l=>l.type==r.time)||(this.annotations=n.concat(r.time.of(Date.now())))}static create(e,t,i,s,n,o){return new r(e,t,i,s,n,o)}get newDoc(){return this._doc||(this._doc=this.changes.apply(this.startState.doc))}get newSelection(){return this.selection||this.startState.selection.map(this.changes)}get state(){return this._state||this.startState.applyTransaction(this),this._state}annotation(e){for(let t of this.annotations)if(t.type==e)return t.value}get docChanged(){return!this.changes.empty}get reconfigured(){return this.startState.config!=this.state.config}isUserEvent(e){let t=this.annotation(r.userEvent);return!!(t&&(t==e||t.length>e.length&&t.slice(0,e.length)==e&&t[e.length]=="."))}};Re.time=lt.define();Re.userEvent=lt.define();Re.addToHistory=lt.define();Re.remote=lt.define();function m1(r,e){let t=[];for(let i=0,s=0;;){let n,o;if(i<r.length&&(s==e.length||e[s]>=r[i]))n=r[i++],o=r[i++];else if(s<e.length)n=e[s++],o=e[s++];else return t;!t.length||t[t.length-1]<n?t.push(n,o):t[t.length-1]<o&&(t[t.length-1]=o)}}function nu(r,e,t){var i;let s,n,o;return t?(s=e.changes,n=Ze.empty(e.changes.length),o=r.changes.compose(e.changes)):(s=e.changes.map(r.changes),n=r.changes.mapDesc(e.changes,!0),o=r.changes.compose(s)),{changes:o,selection:e.selection?e.selection.map(n):(i=r.selection)===null||i===void 0?void 0:i.map(s),effects:re.mapEffects(r.effects,s).concat(re.mapEffects(e.effects,n)),annotations:r.annotations.length?r.annotations.concat(e.annotations):e.annotations,scrollIntoView:r.scrollIntoView||e.scrollIntoView}}function El(r,e,t){let i=e.selection,s=ks(e.annotations);return e.userEvent&&(s=s.concat(Re.userEvent.of(e.userEvent))),{changes:e.changes instanceof Ze?e.changes:Ze.of(e.changes||[],t,r.facet(eu)),selection:i&&(i instanceof M?i:M.single(i.anchor,i.head)),effects:ks(e.effects),annotations:s,scrollIntoView:!!e.scrollIntoView}}function ou(r,e,t){let i=El(r,e.length?e[0]:{},r.doc.length);e.length&&e[0].filter===!1&&(t=!1);for(let n=1;n<e.length;n++){e[n].filter===!1&&(t=!1);let o=!!e[n].sequential;i=nu(i,El(r,e[n],o?i.changes.newLength:r.doc.length),o)}let s=Re.create(r,i.changes,i.selection,i.effects,i.annotations,i.scrollIntoView);return _1(t?g1(s):s)}function g1(r){let e=r.startState,t=!0;for(let s of e.facet(tu)){let n=s(r);if(n===!1){t=!1;break}Array.isArray(n)&&(t=t===!0?n:m1(t,n))}if(t!==!0){let s,n;if(t===!1)n=r.changes.invertedDesc,s=Ze.empty(e.doc.length);else{let o=r.changes.filter(t);s=o.changes,n=o.filtered.mapDesc(o.changes).invertedDesc}r=Re.create(e,s,r.selection&&r.selection.map(n),re.mapEffects(r.effects,n),r.annotations,r.scrollIntoView)}let i=e.facet(iu);for(let s=i.length-1;s>=0;s--){let n=i[s](r);n instanceof Re?r=n:Array.isArray(n)&&n.length==1&&n[0]instanceof Re?r=n[0]:r=ou(e,ks(n),!1)}return r}function _1(r){let e=r.startState,t=e.facet(su),i=r;for(let s=t.length-1;s>=0;s--){let n=t[s](r);n&&Object.keys(n).length&&(i=nu(i,El(e,n,r.changes.newLength),!0))}return i==r?r:Re.create(e,r.changes,r.selection,i.effects,i.annotations,i.scrollIntoView)}var y1=[];function ks(r){return r==null?y1:Array.isArray(r)?r:[r]}var be=function(r){return r[r.Word=0]="Word",r[r.Space=1]="Space",r[r.Other=2]="Other",r}(be||(be={})),b1=/[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/,Al;try{Al=new RegExp("[\\p{Alphabetic}\\p{Number}_]","u")}catch{}function O1(r){if(Al)return Al.test(r);for(let e=0;e<r.length;e++){let t=r[e];if(/\w/.test(t)||t>"\x80"&&(t.toUpperCase()!=t.toLowerCase()||b1.test(t)))return!0}return!1}function v1(r){return e=>{if(!/\S/.test(e))return be.Space;if(O1(e))return be.Word;for(let t=0;t<r.length;t++)if(e.indexOf(r[t])>-1)return be.Word;return be.Other}}var pe=class r{constructor(e,t,i,s,n,o){this.config=e,this.doc=t,this.selection=i,this.values=s,this.status=e.statusTemplate.slice(),this.computeSlot=n,o&&(o._state=this);for(let l=0;l<this.config.dynamicSlots.length;l++)or(this,l<<1);this.computeSlot=null}field(e,t=!0){let i=this.config.address[e.id];if(i==null){if(t)throw new RangeError("Field is not present in this state");return}return or(this,i),mn(this,i)}update(...e){return ou(this,e,!0)}applyTransaction(e){let t=this.config,{base:i,compartments:s}=t;for(let l of e.effects)l.is(Ss.reconfigure)?(t&&(s=new Map,t.compartments.forEach((a,h)=>s.set(h,a)),t=null),s.set(l.value.compartment,l.value.extension)):l.is(re.reconfigure)?(t=null,i=l.value):l.is(re.appendConfig)&&(t=null,i=ks(i).concat(l.value));let n;t?n=e.startState.values.slice():(t=pn.resolve(i,s,this),n=new r(t,this.doc,this.selection,t.dynamicSlots.map(()=>null),(a,h)=>h.reconfigure(a,this),null).values);let o=e.startState.facet(Tl)?e.newSelection:e.newSelection.asSingle();new r(t,e.newDoc,o,n,(l,a)=>a.update(l,e),e)}replaceSelection(e){return typeof e=="string"&&(e=this.toText(e)),this.changeByRange(t=>({changes:{from:t.from,to:t.to,insert:e},range:M.cursor(t.from+e.length,-1)}))}changeByRange(e){let t=this.selection,i=e(t.ranges[0]),s=this.changes(i.changes),n=[i.range],o=ks(i.effects);for(let l=1;l<t.ranges.length;l++){let a=e(t.ranges[l]),h=this.changes(a.changes),c=h.map(s);for(let p=0;p<l;p++)n[p]=n[p].map(c);let u=s.mapDesc(h,!0);n.push(a.range.map(u)),s=s.compose(c),o=re.mapEffects(o,c).concat(re.mapEffects(ks(a.effects),u))}return{changes:s,selection:M.create(n,t.mainIndex),effects:o}}changes(e=[]){return e instanceof Ze?e:Ze.of(e,this.doc.length,this.facet(r.lineSeparator))}toText(e){return oe.of(e.split(this.facet(r.lineSeparator)||wl))}sliceDoc(e=0,t=this.doc.length){return this.doc.sliceString(e,t,this.lineBreak)}facet(e){let t=this.config.address[e.id];return t==null?e.default:(or(this,t),mn(this,t))}toJSON(e){let t={doc:this.sliceDoc(),selection:this.selection.toJSON()};if(e)for(let i in e){let s=e[i];s instanceof Qe&&this.config.address[s.id]!=null&&(t[i]=s.spec.toJSON(this.field(e[i]),this))}return t}static fromJSON(e,t={},i){if(!e||typeof e.doc!="string")throw new RangeError("Invalid JSON representation for EditorState");let s=[];if(i){for(let n in i)if(Object.prototype.hasOwnProperty.call(e,n)){let o=i[n],l=e[n];s.push(o.init(a=>o.spec.fromJSON(l,a)))}}return r.create({doc:e.doc,selection:M.fromJSON(e.selection),extensions:t.extensions?s.concat([t.extensions]):s})}static create(e={}){let t=pn.resolve(e.extensions||[],new Map),i=e.doc instanceof oe?e.doc:oe.of((e.doc||"").split(t.staticFacet(r.lineSeparator)||wl)),s=e.selection?e.selection instanceof M?e.selection:M.single(e.selection.anchor,e.selection.head):M.single(0);return Kd(s,i.length),t.staticFacet(Tl)||(s=s.asSingle()),new r(t,i,s,t.dynamicSlots.map(()=>null),(n,o)=>o.create(n),null)}get tabSize(){return this.facet(r.tabSize)}get lineBreak(){return this.facet(r.lineSeparator)||`
`}get readOnly(){return this.facet(ru)}phrase(e,...t){for(let i of this.facet(r.phrases))if(Object.prototype.hasOwnProperty.call(i,e)){e=i[e];break}return t.length&&(e=e.replace(/\$(\$|\d*)/g,(i,s)=>{if(s=="$")return"$";let n=+(s||1);return!n||n>t.length?i:t[n-1]})),e}languageDataAt(e,t,i=-1){let s=[];for(let n of this.facet(Zd))for(let o of n(this,t,i))Object.prototype.hasOwnProperty.call(o,e)&&s.push(o[e]);return s}charCategorizer(e){let t=this.languageDataAt("wordChars",e);return v1(t.length?t[0]:"")}wordAt(e){let{text:t,from:i,length:s}=this.doc.lineAt(e),n=this.charCategorizer(e),o=e-i,l=e-i;for(;o>0;){let a=Ce(t,o,!1);if(n(t.slice(a,o))!=be.Word)break;o=a}for(;l<s;){let a=Ce(t,l);if(n(t.slice(l,a))!=be.Word)break;l=a}return o==l?null:M.range(o+i,l+i)}};pe.allowMultipleSelections=Tl;pe.tabSize=W.define({combine:r=>r.length?r[0]:4});pe.lineSeparator=eu;pe.readOnly=ru;pe.phrases=W.define({compare(r,e){let t=Object.keys(r),i=Object.keys(e);return t.length==i.length&&t.every(s=>r[s]==e[s])}});pe.languageData=Zd;pe.changeFilter=tu;pe.transactionFilter=iu;pe.transactionExtender=su;Ss.reconfigure=re.define();function wt(r,e,t={}){let i={};for(let s of r)for(let n of Object.keys(s)){let o=s[n],l=i[n];if(l===void 0)i[n]=o;else if(!(l===o||o===void 0))if(Object.hasOwnProperty.call(t,n))i[n]=t[n](l,o);else throw new Error("Config merge conflict for field "+n)}for(let s in e)i[s]===void 0&&(i[s]=e[s]);return i}var Ot=class{eq(e){return this==e}range(e,t=e){return ar.create(e,t,this)}};Ot.prototype.startSide=Ot.prototype.endSide=0;Ot.prototype.point=!1;Ot.prototype.mapMode=Le.TrackDel;function Ll(r,e){return r==e||r.constructor==e.constructor&&r.eq(e)}var ar=class r{constructor(e,t,i){this.from=e,this.to=t,this.value=i}static create(e,t,i){return new r(e,t,i)}};function Rl(r,e){return r.from-e.from||r.value.startSide-e.value.startSide}var Ml=class r{constructor(e,t,i,s){this.from=e,this.to=t,this.value=i,this.maxPoint=s}get length(){return Os(this.to)}findIndex(e,t,i,s=0){let n=i?this.to:this.from;for(let o=s,l=n.length;;){if(o==l)return o;let a=o+l>>1,h=n[a]-e||(i?this.value[a].endSide:this.value[a].startSide)-t;if(a==o)return h>=0?o:l;h>=0?l=a:o=a+1}}between(e,t,i,s){for(let n=this.findIndex(t,-1e9,!0),o=this.findIndex(i,1e9,!1,n);n<o;n++)if(s(this.from[n]+e,this.to[n]+e,this.value[n])===!1)return!1}map(e,t,i,s,n){let o=[],l=[],a=[],h=-1,c=-1;e:for(let u=0;u<this.value.length;u++){let p=this.value[u],y=this.from[u]+e,O=this.to[u]+e,b,v;if(y==O){let k=t.mapPos(y,p.startSide,p.mapMode);if(k==null||(b=v=k,p.startSide!=p.endSide&&(v=t.mapPos(y,p.endSide),v<b)))continue}else if(b=t.mapPos(y,p.startSide),v=t.mapPos(O,p.endSide),b>v||b==v&&p.startSide>0&&p.endSide<=0)continue;if(!((v-b||p.endSide-p.startSide)<0))if(h<0&&(h=b),p.point&&(c=Math.max(c,v-b)),(b-i||p.startSide-s)>=0)o.push(p),l.push(b-h),a.push(v-h),i=v,s=p.endSide;else{if(b==v)for(let k=o.length;k>0;k--){if((b-(a[k-1]+h)||p.startSide-o[k-1].endSide)>=0){o.splice(k,0,p),l.splice(k,0,b-h),a.splice(k,0,v-h);continue e}if((b-(l[k-1]+h)||p.endSide-o[k-1].startSide)>0)break}n(b,v,p)}}return{mapped:o.length?new r(l,a,o,c):null,pos:h}}},ce=class r{constructor(e,t,i,s){this.chunkPos=e,this.chunk=t,this.nextLayer=i,this.maxPoint=s}static create(e,t,i,s){return new r(e,t,i,s)}get length(){let e=this.chunk.length-1;return e<0?0:Math.max(this.chunkEnd(e),this.nextLayer.length)}get size(){if(this.isEmpty)return 0;let e=this.nextLayer.size;for(let t of this.chunk)e+=t.value.length;return e}chunkEnd(e){return this.chunkPos[e]+this.chunk[e].length}update(e){let{add:t=[],sort:i=!1,filterFrom:s=0,filterTo:n=this.length}=e,o=e.filter;if(t.length==0&&!o)return this;if(i&&(t=t.slice().sort(Rl)),this.isEmpty)return t.length?r.of(t):this;let l=new gn(this,null,-1).goto(0),a=0,h=[],c=new Gt;for(;l.value||a<t.length;)if(a<t.length&&(l.from-t[a].from||l.startSide-t[a].value.startSide)>=0){let u=t[a++];c.addInner(u.from,u.to,u.value,!1)||h.push(u)}else l.rangeIndex==1&&l.chunkIndex<this.chunk.length&&(a==t.length||this.chunkEnd(l.chunkIndex)<t[a].from)&&(!o||s>this.chunkEnd(l.chunkIndex)||n<this.chunkPos[l.chunkIndex])&&c.addChunk(this.chunkPos[l.chunkIndex],this.chunk[l.chunkIndex])?l.nextChunk():((!o||s>l.to||n<l.from||o(l.from,l.to,l.value))&&(c.addInner(l.from,l.to,l.value,!1)||h.push(ar.create(l.from,l.to,l.value))),l.next());return c.finishInner(this.nextLayer.isEmpty&&!h.length?r.empty:this.nextLayer.update({add:h,filter:o,filterFrom:s,filterTo:n}))}map(e){if(e.empty||this.isEmpty)return this;let t=[],i=[],s=-1,n,o=(a,h,c)=>{n||(n=new Gt),n.addRange(a,h,c,!1)};for(let a=0;a<this.chunk.length;a++){let h=this.chunkPos[a],c=this.chunk[a],u=e.touchesRange(h,h+c.length);if(u===!1)s=Math.max(s,c.maxPoint),t.push(c),i.push(e.mapPos(h));else if(u===!0){let[p,y]=t.length?[Os(i)+Os(t).length,Os(Os(t).value).endSide]:[-1,-1],{mapped:O,pos:b}=c.map(h,e,p,y,o);O&&(s=Math.max(s,O.maxPoint),t.push(O),i.push(b))}}let l=this.nextLayer.map(e);return n&&(l=n.finishInner(l)),t.length==0?l:new r(i,t,l||r.empty,s)}between(e,t,i){if(!this.isEmpty){for(let s=0;s<this.chunk.length;s++){let n=this.chunkPos[s],o=this.chunk[s];if(t>=n&&e<=n+o.length&&o.between(n,e-n,t-n,i)===!1)return}this.nextLayer.between(e,t,i)}}iter(e=0){return hr.from([this]).goto(e)}get isEmpty(){return this.nextLayer==this}static iter(e,t=0){return hr.from(e).goto(t)}static compare(e,t,i,s,n=-1){let o=e.filter(u=>u.maxPoint>0||!u.isEmpty&&u.maxPoint>=n),l=t.filter(u=>u.maxPoint>0||!u.isEmpty&&u.maxPoint>=n),a=Gd(o,l,i),h=new zi(o,a,n),c=new zi(l,a,n);i.iterGaps((u,p,y)=>Xd(h,u,c,p,y,s)),i.empty&&i.length==0&&Xd(h,0,c,0,0,s)}static eq(e,t,i=0,s){s==null&&(s=999999999);let n=e.filter(c=>!c.isEmpty&&t.indexOf(c)<0),o=t.filter(c=>!c.isEmpty&&e.indexOf(c)<0);if(n.length!=o.length)return!1;if(!n.length)return!0;let l=Gd(n,o),a=new zi(n,l,0).goto(i),h=new zi(o,l,0).goto(i);for(;;){if(a.to!=h.to||!Dl(a.active,h.active)||a.point&&(!h.point||!Ll(a.point,h.point)))return!1;if(a.to>s)return!0;a.next(),h.next()}}static spans(e,t,i,s,n=-1){let o=new zi(e,null,n).goto(t),l=t,a=o.openStart;for(;;){let h=Math.min(o.to,i);if(o.point){let c=o.activeForPoint(o.to),u=o.pointFrom<t?c.length+1:o.point.startSide<0?c.length:Math.min(c.length,a);s.point(l,h,o.point,c,u,o.pointRank),a=Math.min(o.openEnd(h),c.length)}else h>l&&(s.span(l,h,o.active,a),a=o.openEnd(h));if(o.to>i)return a+(o.point&&o.to>i?1:0);l=o.to,o.next()}}static of(e,t=!1){let i=new Gt;for(let s of e instanceof ar?[e]:t?w1(e):e)i.add(s.from,s.to,s.value);return i.finish()}static join(e){if(!e.length)return r.empty;let t=Os(e);for(let i=e.length-2;i>=0;i--)for(let s=e[i];s!=r.empty;s=s.nextLayer)t=new r(s.chunkPos,s.chunk,t,Math.max(s.maxPoint,t.maxPoint));return t}};ce.empty=new ce([],[],null,-1);function Os(r){return r[r.length-1]}function w1(r){if(r.length>1)for(let e=r[0],t=1;t<r.length;t++){let i=r[t];if(Rl(e,i)>0)return r.slice().sort(Rl);e=i}return r}ce.empty.nextLayer=ce.empty;var Gt=class r{finishChunk(e){this.chunks.push(new Ml(this.from,this.to,this.value,this.maxPoint)),this.chunkPos.push(this.chunkStart),this.chunkStart=-1,this.setMaxPoint=Math.max(this.setMaxPoint,this.maxPoint),this.maxPoint=-1,e&&(this.from=[],this.to=[],this.value=[])}constructor(){this.chunks=[],this.chunkPos=[],this.chunkStart=-1,this.last=null,this.lastFrom=-1e9,this.lastTo=-1e9,this.from=[],this.to=[],this.value=[],this.maxPoint=-1,this.setMaxPoint=-1,this.nextLayer=null}add(e,t,i){this.addRange(e,t,i,!0)}addRange(e,t,i,s){this.addInner(e,t,i,s)||(this.nextLayer||(this.nextLayer=new r)).addRange(e,t,i,s)}addInner(e,t,i,s){let n=e-this.lastTo||i.startSide-this.last.endSide;if(s&&n<=0&&(e-this.lastFrom||i.startSide-this.last.startSide)<0)throw new Error("Ranges must be added sorted by `from` position and `startSide`");return n<0?!1:(this.from.length==250&&this.finishChunk(!0),this.chunkStart<0&&(this.chunkStart=e),this.from.push(e-this.chunkStart),this.to.push(t-this.chunkStart),this.last=i,this.lastFrom=e,this.lastTo=t,this.value.push(i),i.point&&(this.maxPoint=Math.max(this.maxPoint,t-e)),!0)}addChunk(e,t){if((e-this.lastTo||t.value[0].startSide-this.last.endSide)<0)return!1;this.from.length&&this.finishChunk(!0),this.setMaxPoint=Math.max(this.setMaxPoint,t.maxPoint),this.chunks.push(t),this.chunkPos.push(e);let i=t.value.length-1;return this.last=t.value[i],this.lastFrom=t.from[i]+e,this.lastTo=t.to[i]+e,!0}finish(){return this.finishInner(ce.empty)}finishInner(e){if(this.from.length&&this.finishChunk(!1),this.chunks.length==0)return e;let t=ce.create(this.chunkPos,this.chunks,this.nextLayer?this.nextLayer.finishInner(e):e,this.setMaxPoint);return this.from=null,t}};function Gd(r,e,t){let i=new Map;for(let n of r)for(let o=0;o<n.chunk.length;o++)n.chunk[o].maxPoint<=0&&i.set(n.chunk[o],n.chunkPos[o]);let s=new Set;for(let n of e)for(let o=0;o<n.chunk.length;o++){let l=i.get(n.chunk[o]);l!=null&&(t?t.mapPos(l):l)==n.chunkPos[o]&&!(t!=null&&t.touchesRange(l,l+n.chunk[o].length))&&s.add(n.chunk[o])}return s}var gn=class{constructor(e,t,i,s=0){this.layer=e,this.skip=t,this.minPoint=i,this.rank=s}get startSide(){return this.value?this.value.startSide:0}get endSide(){return this.value?this.value.endSide:0}goto(e,t=-1e9){return this.chunkIndex=this.rangeIndex=0,this.gotoInner(e,t,!1),this}gotoInner(e,t,i){for(;this.chunkIndex<this.layer.chunk.length;){let s=this.layer.chunk[this.chunkIndex];if(!(this.skip&&this.skip.has(s)||this.layer.chunkEnd(this.chunkIndex)<e||s.maxPoint<this.minPoint))break;this.chunkIndex++,i=!1}if(this.chunkIndex<this.layer.chunk.length){let s=this.layer.chunk[this.chunkIndex].findIndex(e-this.layer.chunkPos[this.chunkIndex],t,!0);(!i||this.rangeIndex<s)&&this.setRangeIndex(s)}this.next()}forward(e,t){(this.to-e||this.endSide-t)<0&&this.gotoInner(e,t,!0)}next(){for(;;)if(this.chunkIndex==this.layer.chunk.length){this.from=this.to=1e9,this.value=null;break}else{let e=this.layer.chunkPos[this.chunkIndex],t=this.layer.chunk[this.chunkIndex],i=e+t.from[this.rangeIndex];if(this.from=i,this.to=e+t.to[this.rangeIndex],this.value=t.value[this.rangeIndex],this.setRangeIndex(this.rangeIndex+1),this.minPoint<0||this.value.point&&this.to-this.from>=this.minPoint)break}}setRangeIndex(e){if(e==this.layer.chunk[this.chunkIndex].value.length){if(this.chunkIndex++,this.skip)for(;this.chunkIndex<this.layer.chunk.length&&this.skip.has(this.layer.chunk[this.chunkIndex]);)this.chunkIndex++;this.rangeIndex=0}else this.rangeIndex=e}nextChunk(){this.chunkIndex++,this.rangeIndex=0,this.next()}compare(e){return this.from-e.from||this.startSide-e.startSide||this.rank-e.rank||this.to-e.to||this.endSide-e.endSide}},hr=class r{constructor(e){this.heap=e}static from(e,t=null,i=-1){let s=[];for(let n=0;n<e.length;n++)for(let o=e[n];!o.isEmpty;o=o.nextLayer)o.maxPoint>=i&&s.push(new gn(o,t,i,n));return s.length==1?s[0]:new r(s)}get startSide(){return this.value?this.value.startSide:0}goto(e,t=-1e9){for(let i of this.heap)i.goto(e,t);for(let i=this.heap.length>>1;i>=0;i--)Ol(this.heap,i);return this.next(),this}forward(e,t){for(let i of this.heap)i.forward(e,t);for(let i=this.heap.length>>1;i>=0;i--)Ol(this.heap,i);(this.to-e||this.value.endSide-t)<0&&this.next()}next(){if(this.heap.length==0)this.from=this.to=1e9,this.value=null,this.rank=-1;else{let e=this.heap[0];this.from=e.from,this.to=e.to,this.value=e.value,this.rank=e.rank,e.value&&e.next(),Ol(this.heap,0)}}};function Ol(r,e){for(let t=r[e];;){let i=(e<<1)+1;if(i>=r.length)break;let s=r[i];if(i+1<r.length&&s.compare(r[i+1])>=0&&(s=r[i+1],i++),t.compare(s)<0)break;r[i]=t,r[e]=s,e=i}}var zi=class{constructor(e,t,i){this.minPoint=i,this.active=[],this.activeTo=[],this.activeRank=[],this.minActive=-1,this.point=null,this.pointFrom=0,this.pointRank=0,this.to=-1e9,this.endSide=0,this.openStart=-1,this.cursor=hr.from(e,t,i)}goto(e,t=-1e9){return this.cursor.goto(e,t),this.active.length=this.activeTo.length=this.activeRank.length=0,this.minActive=-1,this.to=e,this.endSide=t,this.openStart=-1,this.next(),this}forward(e,t){for(;this.minActive>-1&&(this.activeTo[this.minActive]-e||this.active[this.minActive].endSide-t)<0;)this.removeActive(this.minActive);this.cursor.forward(e,t)}removeActive(e){an(this.active,e),an(this.activeTo,e),an(this.activeRank,e),this.minActive=Jd(this.active,this.activeTo)}addActive(e){let t=0,{value:i,to:s,rank:n}=this.cursor;for(;t<this.activeRank.length&&(n-this.activeRank[t]||s-this.activeTo[t])>0;)t++;hn(this.active,t,i),hn(this.activeTo,t,s),hn(this.activeRank,t,n),e&&hn(e,t,this.cursor.from),this.minActive=Jd(this.active,this.activeTo)}next(){let e=this.to,t=this.point;this.point=null;let i=this.openStart<0?[]:null;for(;;){let s=this.minActive;if(s>-1&&(this.activeTo[s]-this.cursor.from||this.active[s].endSide-this.cursor.startSide)<0){if(this.activeTo[s]>e){this.to=this.activeTo[s],this.endSide=this.active[s].endSide;break}this.removeActive(s),i&&an(i,s)}else if(this.cursor.value)if(this.cursor.from>e){this.to=this.cursor.from,this.endSide=this.cursor.startSide;break}else{let n=this.cursor.value;if(!n.point)this.addActive(i),this.cursor.next();else if(t&&this.cursor.to==this.to&&this.cursor.from<this.cursor.to)this.cursor.next();else{this.point=n,this.pointFrom=this.cursor.from,this.pointRank=this.cursor.rank,this.to=this.cursor.to,this.endSide=n.endSide,this.cursor.next(),this.forward(this.to,this.endSide);break}}else{this.to=this.endSide=1e9;break}}if(i){this.openStart=0;for(let s=i.length-1;s>=0&&i[s]<e;s--)this.openStart++}}activeForPoint(e){if(!this.active.length)return this.active;let t=[];for(let i=this.active.length-1;i>=0&&!(this.activeRank[i]<this.pointRank);i--)(this.activeTo[i]>e||this.activeTo[i]==e&&this.active[i].endSide>=this.point.endSide)&&t.push(this.active[i]);return t.reverse()}openEnd(e){let t=0;for(let i=this.activeTo.length-1;i>=0&&this.activeTo[i]>e;i--)t++;return t}};function Xd(r,e,t,i,s,n){r.goto(e),t.goto(i);let o=i+s,l=i,a=i-e,h=!!n.boundChange;for(let c=!1;;){let u=r.to+a-t.to,p=u||r.endSide-t.endSide,y=p<0?r.to+a:t.to,O=Math.min(y,o);if(r.point||t.point?(r.point&&t.point&&Ll(r.point,t.point)&&Dl(r.activeForPoint(r.to),t.activeForPoint(t.to))||n.comparePoint(l,O,r.point,t.point),c=!1):(c&&(n.boundChange(l),c=!1),O>l&&!Dl(r.active,t.active)&&n.compareRange(l,O,r.active,t.active),h&&O<o&&(u||r.openEnd(y)!=t.openEnd(y))&&(c=!0)),y>o)break;l=y,p<=0&&r.next(),p>=0&&t.next()}}function Dl(r,e){if(r.length!=e.length)return!1;for(let t=0;t<r.length;t++)if(r[t]!=e[t]&&!Ll(r[t],e[t]))return!1;return!0}function an(r,e){for(let t=e,i=r.length-1;t<i;t++)r[t]=r[t+1];r.pop()}function hn(r,e,t){for(let i=r.length-1;i>=e;i--)r[i+1]=r[i];r[e]=t}function Jd(r,e){let t=-1,i=1e9;for(let s=0;s<e.length;s++)(e[s]-i||r[s].endSide-r[t].endSide)<0&&(t=s,i=e[s]);return t}function Vi(r,e,t=r.length){let i=0;for(let s=0;s<t&&s<r.length;)r.charCodeAt(s)==9?(i+=e-i%e,s++):(i++,s=Ce(r,s));return i}function lu(r,e,t,i){for(let s=0,n=0;;){if(n>=e)return s;if(s==r.length)break;n+=r.charCodeAt(s)==9?t-n%t:1,s=Ce(r,s)}return i===!0?-1:r.length}var Ql="\u037C",au=typeof Symbol>"u"?"__"+Ql:Symbol.for(Ql),ql=typeof Symbol>"u"?"__styleSet"+Math.floor(Math.random()*1e8):Symbol("styleSet"),hu=typeof globalThis<"u"?globalThis:typeof window<"u"?window:{},kt=class{constructor(e,t){this.rules=[];let{finish:i}=t||{};function s(o){return/^@/.test(o)?[o]:o.split(/,\s*/)}function n(o,l,a,h){let c=[],u=/^@(\w+)\b/.exec(o[0]),p=u&&u[1]=="keyframes";if(u&&l==null)return a.push(o[0]+";");for(let y in l){let O=l[y];if(/&/.test(y))n(y.split(/,\s*/).map(b=>o.map(v=>b.replace(/&/,v))).reduce((b,v)=>b.concat(v)),O,a);else if(O&&typeof O=="object"){if(!u)throw new RangeError("The value of a property ("+y+") should be a primitive value.");n(s(y),O,c,p)}else O!=null&&c.push(y.replace(/_.*/,"").replace(/[A-Z]/g,b=>"-"+b.toLowerCase())+": "+O+";")}(c.length||p)&&a.push((i&&!u&&!h?o.map(i):o).join(", ")+" {"+c.join(" ")+"}")}for(let o in e)n(s(o),e[o],this.rules)}getRules(){return this.rules.join(`
`)}static newName(){let e=hu[au]||1;return hu[au]=e+1,Ql+e.toString(36)}static mount(e,t,i){let s=e[ql],n=i&&i.nonce;s?n&&s.setNonce(n):s=new Bl(e,n),s.mount(Array.isArray(t)?t:[t],e)}},fu=new Map,Bl=class{constructor(e,t){let i=e.ownerDocument||e,s=i.defaultView;if(!e.head&&e.adoptedStyleSheets&&s.CSSStyleSheet){let n=fu.get(i);if(n)return e[ql]=n;this.sheet=new s.CSSStyleSheet,fu.set(i,this)}else this.styleTag=i.createElement("style"),t&&this.styleTag.setAttribute("nonce",t);this.modules=[],e[ql]=this}mount(e,t){let i=this.sheet,s=0,n=0,o=!1;for(let l=0;l<e.length;l++){let a=e[l],h=this.modules.indexOf(a);if(h<n&&h>-1&&(this.modules.splice(h,1),o=!0,n--,h=-1),h==-1){if(this.modules.splice(n++,0,a),o=!0,i)for(let c=0;c<a.rules.length;c++)i.insertRule(a.rules[c],s++)}else{for(;n<h;)s+=this.modules[n++].rules.length;s+=a.rules.length,n++}}if(i)t.adoptedStyleSheets.indexOf(this.sheet)<0&&(t.adoptedStyleSheets=[this.sheet,...t.adoptedStyleSheets]);else{if(o){let a="";for(let h=0;h<this.modules.length;h++)a+=this.modules[h].getRules()+`
`;this.styleTag.textContent=a}let l=t.head||t;this.styleTag.parentNode!=l&&l.insertBefore(this.styleTag,l.firstChild)}}setNonce(e){this.styleTag&&this.styleTag.getAttribute("nonce")!=e&&this.styleTag.setAttribute("nonce",e)}};var ni={8:"Backspace",9:"Tab",10:"Enter",12:"NumLock",13:"Enter",16:"Shift",17:"Control",18:"Alt",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",44:"PrintScreen",45:"Insert",46:"Delete",59:";",61:"=",91:"Meta",92:"Meta",106:"*",107:"+",108:",",109:"-",110:".",111:"/",144:"NumLock",145:"ScrollLock",160:"Shift",161:"Shift",162:"Control",163:"Control",164:"Alt",165:"Alt",173:"-",186:";",187:"=",188:",",189:"-",190:".",191:"/",192:"`",219:"[",220:"\\",221:"]",222:"'"},Ts={48:")",49:"!",50:"@",51:"#",52:"$",53:"%",54:"^",55:"&",56:"*",57:"(",59:":",61:"+",173:"_",186:":",187:"+",188:"<",189:"_",190:">",191:"?",192:"~",219:"{",220:"|",221:"}",222:'"'},k1=typeof navigator<"u"&&/Mac/.test(navigator.platform),x1=typeof navigator<"u"&&/MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent);for(Me=0;Me<10;Me++)ni[48+Me]=ni[96+Me]=String(Me);var Me;for(Me=1;Me<=24;Me++)ni[Me+111]="F"+Me;var Me;for(Me=65;Me<=90;Me++)ni[Me]=String.fromCharCode(Me+32),Ts[Me]=String.fromCharCode(Me);var Me;for(_n in ni)Ts.hasOwnProperty(_n)||(Ts[_n]=ni[_n]);var _n;function cu(r){var e=k1&&r.metaKey&&r.shiftKey&&!r.ctrlKey&&!r.altKey||x1&&r.shiftKey&&r.key&&r.key.length==1||r.key=="Unidentified",t=!e&&r.key||(r.shiftKey?Ts:ni)[r.keyCode]||r.key||"Unidentified";return t=="Esc"&&(t="Escape"),t=="Del"&&(t="Delete"),t=="Left"&&(t="ArrowLeft"),t=="Up"&&(t="ArrowUp"),t=="Right"&&(t="ArrowRight"),t=="Down"&&(t="ArrowDown"),t}function Ee(){var r=arguments[0];typeof r=="string"&&(r=document.createElement(r));var e=1,t=arguments[1];if(t&&typeof t=="object"&&t.nodeType==null&&!Array.isArray(t)){for(var i in t)if(Object.prototype.hasOwnProperty.call(t,i)){var s=t[i];typeof s=="string"?r.setAttribute(i,s):s!=null&&(r[i]=s)}e++}for(;e<arguments.length;e++)du(r,arguments[e]);return r}function du(r,e){if(typeof e=="string")r.appendChild(document.createTextNode(e));else if(e!=null)if(e.nodeType!=null)r.appendChild(e);else if(Array.isArray(e))for(var t=0;t<e.length;t++)du(r,e[t]);else throw new RangeError("Unsupported child node: "+e)}var et=typeof navigator<"u"?navigator:{userAgent:"",vendor:"",platform:""},Ul=typeof document<"u"?document:{documentElement:{style:{}}},Gl=/Edge\/(\d+)/.exec(et.userAgent),Gu=/MSIE \d/.test(et.userAgent),Xl=/Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(et.userAgent),Un=!!(Gu||Xl||Gl),uu=!Un&&/gecko\/(\d+)/i.test(et.userAgent),$l=!Un&&/Chrome\/(\d+)/.exec(et.userAgent),pu="webkitFontSmoothing"in Ul.documentElement.style,Jl=!Un&&/Apple Computer/.test(et.vendor),mu=Jl&&(/Mobile\/\w+/.test(et.userAgent)||et.maxTouchPoints>2),$={mac:mu||/Mac/.test(et.platform),windows:/Win/.test(et.platform),linux:/Linux|X11/.test(et.platform),ie:Un,ie_version:Gu?Ul.documentMode||6:Xl?+Xl[1]:Gl?+Gl[1]:0,gecko:uu,gecko_version:uu?+(/Firefox\/(\d+)/.exec(et.userAgent)||[0,0])[1]:0,chrome:!!$l,chrome_version:$l?+$l[1]:0,ios:mu,android:/Android\b/.test(et.userAgent),webkit:pu,webkit_version:pu?+(/\bAppleWebKit\/(\d+)/.exec(et.userAgent)||[0,0])[1]:0,safari:Jl,safari_version:Jl?+(/\bVersion\/(\d+(\.\d+)?)/.exec(et.userAgent)||[0,0])[1]:0,tabSize:Ul.documentElement.style.tabSize!=null?"tab-size":"-moz-tab-size"};function Qa(r,e){for(let t in r)t=="class"&&e.class?e.class+=" "+r.class:t=="style"&&e.style?e.style+=";"+r.style:e[t]=r[t];return e}var Mn=Object.create(null);function qa(r,e,t){if(r==e)return!0;r||(r=Mn),e||(e=Mn);let i=Object.keys(r),s=Object.keys(e);if(i.length-(t&&i.indexOf(t)>-1?1:0)!=s.length-(t&&s.indexOf(t)>-1?1:0))return!1;for(let n of i)if(n!=t&&(s.indexOf(n)==-1||r[n]!==e[n]))return!1;return!0}function S1(r,e){for(let t=r.attributes.length-1;t>=0;t--){let i=r.attributes[t].name;e[i]==null&&r.removeAttribute(i)}for(let t in e){let i=e[t];t=="style"?r.style.cssText=i:r.getAttribute(t)!=i&&r.setAttribute(t,i)}}function gu(r,e,t){let i=!1;if(e)for(let s in e)t&&s in t||(i=!0,s=="style"?r.style.cssText="":r.removeAttribute(s));if(t)for(let s in t)e&&e[s]==t[s]||(i=!0,s=="style"?r.style.cssText=t[s]:r.setAttribute(s,t[s]));return i}function T1(r){let e=Object.create(null);for(let t=0;t<r.attributes.length;t++){let i=r.attributes[t];e[i.name]=i.value}return e}var ai=class{eq(e){return!1}updateDOM(e,t,i){return!1}compare(e){return this==e||this.constructor==e.constructor&&this.eq(e)}get estimatedHeight(){return-1}get lineBreaks(){return 0}ignoreEvent(e){return!0}coordsAt(e,t,i){return null}get isHidden(){return!1}get editable(){return!1}destroy(e){}},He=function(r){return r[r.Text=0]="Text",r[r.WidgetBefore=1]="WidgetBefore",r[r.WidgetAfter=2]="WidgetAfter",r[r.WidgetRange=3]="WidgetRange",r}(He||(He={})),K=class extends Ot{constructor(e,t,i,s){super(),this.startSide=e,this.endSide=t,this.widget=i,this.spec=s}get heightRelevant(){return!1}static mark(e){return new vr(e)}static widget(e){let t=Math.max(-1e4,Math.min(1e4,e.side||0)),i=!!e.block;return t+=i&&!e.inlineOrder?t>0?3e8:-4e8:t>0?1e8:-1e8,new Ji(e,t,t,i,e.widget||null,!1)}static replace(e){let t=!!e.block,i,s;if(e.isBlockGap)i=-5e8,s=4e8;else{let{start:n,end:o}=Xu(e,t);i=(n?t?-3e8:-1:5e8)-1,s=(o?t?2e8:1:-6e8)+1}return new Ji(e,i,s,t,e.widget||null,!0)}static line(e){return new wr(e)}static set(e,t=!1){return ce.of(e,t)}hasHeight(){return this.widget?this.widget.estimatedHeight>-1:!1}};K.none=ce.empty;var vr=class r extends K{constructor(e){let{start:t,end:i}=Xu(e);super(t?-1:5e8,i?1:-6e8,null,e),this.tagName=e.tagName||"span",this.attrs=e.class&&e.attributes?Qa(e.attributes,{class:e.class}):e.class?{class:e.class}:e.attributes||Mn}eq(e){return this==e||e instanceof r&&this.tagName==e.tagName&&qa(this.attrs,e.attrs)}range(e,t=e){if(e>=t)throw new RangeError("Mark decorations may not be empty");return super.range(e,t)}};vr.prototype.point=!1;var wr=class r extends K{constructor(e){super(-2e8,-2e8,null,e)}eq(e){return e instanceof r&&this.spec.class==e.spec.class&&qa(this.spec.attributes,e.spec.attributes)}range(e,t=e){if(t!=e)throw new RangeError("Line decoration ranges must be zero-length");return super.range(e,t)}};wr.prototype.mapMode=Le.TrackBefore;wr.prototype.point=!0;var Ji=class r extends K{constructor(e,t,i,s,n,o){super(t,i,n,e),this.block=s,this.isReplace=o,this.mapMode=s?t<=0?Le.TrackBefore:Le.TrackAfter:Le.TrackDel}get type(){return this.startSide!=this.endSide?He.WidgetRange:this.startSide<=0?He.WidgetBefore:He.WidgetAfter}get heightRelevant(){return this.block||!!this.widget&&(this.widget.estimatedHeight>=5||this.widget.lineBreaks>0)}eq(e){return e instanceof r&&P1(this.widget,e.widget)&&this.block==e.block&&this.startSide==e.startSide&&this.endSide==e.endSide}range(e,t=e){if(this.isReplace&&(e>t||e==t&&this.startSide>0&&this.endSide<=0))throw new RangeError("Invalid range for replacement decoration");if(!this.isReplace&&t!=e)throw new RangeError("Widget decorations can only have zero-length ranges");return super.range(e,t)}};Ji.prototype.point=!0;function Xu(r,e=!1){let{inclusiveStart:t,inclusiveEnd:i}=r;return t==null&&(t=r.inclusive),i==null&&(i=r.inclusive),{start:t??e,end:i??e}}function P1(r,e){return r==e||!!(r&&e&&r.compare(e))}function Ms(r,e,t,i=0){let s=t.length-1;s>=0&&t[s]+i>=r?t[s]=Math.max(t[s],e):t.push(r,e)}var Dn=class r extends Ot{constructor(e,t,i){super(),this.tagName=e,this.attributes=t,this.rank=i}eq(e){return e==this||e instanceof r&&this.tagName==e.tagName&&qa(this.attributes,e.attributes)}static create(e){return new r(e.tagName,e.attributes||Mn,e.rank==null?50:Math.max(0,Math.min(e.rank,100)))}static set(e,t=!1){return ce.of(e,t)}};Dn.prototype.startSide=Dn.prototype.endSide=-1;function kr(r){let e;return r.nodeType==11?e=r.getSelection?r:r.ownerDocument:e=r,e.getSelection()}function Yl(r,e){return e?r==e||r.contains(e.nodeType!=1?e.parentNode:e):!1}function ur(r,e){if(!e.anchorNode)return!1;try{return Yl(r,e.anchorNode)}catch{return!1}}function Tn(r){return r.nodeType==3?xr(r,0,r.nodeValue.length).getClientRects():r.nodeType==1?r.getClientRects():[]}function pr(r,e,t,i){return t?_u(r,e,t,i,-1)||_u(r,e,t,i,1):!1}function vi(r){for(var e=0;;e++)if(r=r.previousSibling,!r)return e}function Nn(r){return r.nodeType==1&&/^(DIV|P|LI|UL|OL|BLOCKQUOTE|DD|DT|H\d|SECTION|PRE)$/.test(r.nodeName)}function _u(r,e,t,i,s){for(;;){if(r==t&&e==i)return!0;if(e==(s<0?0:hi(r))){if(r.nodeName=="DIV")return!1;let n=r.parentNode;if(!n||n.nodeType!=1)return!1;e=vi(r)+(s<0?0:1),r=n}else if(r.nodeType==1){if(r=r.childNodes[e+(s<0?-1:0)],r.nodeType==1&&r.contentEditable=="false")return!1;e=s<0?hi(r):0}else return!1}}function hi(r){return r.nodeType==3?r.nodeValue.length:r.childNodes.length}function In(r,e){let{left:t,right:i}=r;if(t==i)return r;let s=e?t:i;return{left:s,right:s,top:r.top,bottom:r.bottom}}function C1(r){let e=r.visualViewport;return e?{left:0,right:e.width,top:0,bottom:e.height}:{left:0,right:r.innerWidth,top:0,bottom:r.innerHeight}}function Ju(r,e){let t=e.width/r.offsetWidth,i=e.height/r.offsetHeight;return(t>.995&&t<1.005||!isFinite(t)||Math.abs(e.width-r.offsetWidth)<1)&&(t=1),(i>.995&&i<1.005||!isFinite(i)||Math.abs(e.height-r.offsetHeight)<1)&&(i=1),{scaleX:t,scaleY:i}}function E1(r,e,t,i,s,n,o,l){let a=r.ownerDocument,h=a.defaultView||window;for(let c=r,u=!1;c&&!u;)if(c.nodeType==1){let p,y=c==a.body,O=1,b=1;if(y)p=C1(h);else{if(/^(fixed|sticky)$/.test(getComputedStyle(c).position)&&(u=!0),c.scrollHeight<=c.clientHeight&&c.scrollWidth<=c.clientWidth){c=c.assignedSlot||c.parentNode;continue}let T=c.getBoundingClientRect();({scaleX:O,scaleY:b}=Ju(c,T)),p={left:T.left,right:T.left+c.clientWidth*O,top:T.top,bottom:T.top+c.clientHeight*b}}let v=0,k=0;if(s=="nearest")e.top<p.top+o?(k=e.top-(p.top+o),t>0&&e.bottom>p.bottom+k&&(k=e.bottom-p.bottom+o)):e.bottom>p.bottom-o&&(k=e.bottom-p.bottom+o,t<0&&e.top-k<p.top&&(k=e.top-(p.top+o)));else{let T=e.bottom-e.top,C=p.bottom-p.top;k=(s=="center"&&T<=C?e.top+T/2-C/2:s=="start"||s=="center"&&t<0?e.top-o:e.bottom-C+o)-p.top}if(i=="nearest"?e.left<p.left+n?(v=e.left-(p.left+n),t>0&&e.right>p.right+v&&(v=e.right-p.right+n)):e.right>p.right-n&&(v=e.right-p.right+n,t<0&&e.left<p.left+v&&(v=e.left-(p.left+n))):v=(i=="center"?e.left+(e.right-e.left)/2-(p.right-p.left)/2:i=="start"==l?e.left-n:e.right-(p.right-p.left)+n)-p.left,v||k)if(y)h.scrollBy(v,k);else{let T=0,C=0;if(k){let Q=c.scrollTop;c.scrollTop+=k/b,C=(c.scrollTop-Q)*b}if(v){let Q=c.scrollLeft;c.scrollLeft+=v/O,T=(c.scrollLeft-Q)*O}e={left:e.left-T,top:e.top-C,right:e.right-T,bottom:e.bottom-C},T&&Math.abs(T-v)<1&&(i="nearest"),C&&Math.abs(C-k)<1&&(s="nearest")}if(y)break;(e.top<p.top||e.bottom>p.bottom||e.left<p.left||e.right>p.right)&&(e={left:Math.max(e.left,p.left),right:Math.min(e.right,p.right),top:Math.max(e.top,p.top),bottom:Math.min(e.bottom,p.bottom)}),c=c.assignedSlot||c.parentNode}else if(c.nodeType==11)c=c.host;else break}function Yu(r,e=!0){let t=r.ownerDocument,i=null,s=null;for(let n=r.parentNode;n&&!(n==t.body||(!e||i)&&s);)if(n.nodeType==1)!s&&n.scrollHeight>n.clientHeight&&(s=n),e&&!i&&n.scrollWidth>n.clientWidth&&(i=n),n=n.assignedSlot||n.parentNode;else if(n.nodeType==11)n=n.host;else break;return{x:i,y:s}}var Kl=class{constructor(){this.anchorNode=null,this.anchorOffset=0,this.focusNode=null,this.focusOffset=0}eq(e){return this.anchorNode==e.anchorNode&&this.anchorOffset==e.anchorOffset&&this.focusNode==e.focusNode&&this.focusOffset==e.focusOffset}setRange(e){let{anchorNode:t,focusNode:i}=e;this.set(t,Math.min(e.anchorOffset,t?hi(t):0),i,Math.min(e.focusOffset,i?hi(i):0))}set(e,t,i,s){this.anchorNode=e,this.anchorOffset=t,this.focusNode=i,this.focusOffset=s}};function Ku(r){let e=[];for(let t=r;t;t=t.nodeType==11?t.host:t.parentNode)t.nodeType==1&&e.push({node:t,left:t.scrollLeft,top:t.scrollTop});return e}function Zu(r,e=!0){for(let{node:t,left:i,top:s}of r)e&&t.scrollTop!=s&&(t.scrollTop=s),t.scrollLeft!=i&&(t.scrollLeft=i)}var Ui=null;$.safari&&$.safari_version>=26&&(Ui=!1);function ep(r){if(r.setActive)return r.setActive();if(Ui)return r.focus(Ui);let e=Ku(r);r.focus(Ui==null?{get preventScroll(){return Ui={preventScroll:!0},!0}}:void 0),Ui||(Ui=!1,Zu(e))}var yu;function xr(r,e,t=e){let i=yu||(yu=document.createRange());return i.setEnd(r,t),i.setStart(r,e),i}function Ds(r,e,t,i){let s={key:e,code:e,keyCode:t,which:t,cancelable:!0};i&&({altKey:s.altKey,ctrlKey:s.ctrlKey,shiftKey:s.shiftKey,metaKey:s.metaKey}=i);let n=new KeyboardEvent("keydown",s);n.synthetic=!0,r.dispatchEvent(n);let o=new KeyboardEvent("keyup",s);return o.synthetic=!0,r.dispatchEvent(o),n.defaultPrevented||o.defaultPrevented}function A1(r){for(;r;){if(r&&(r.nodeType==9||r.nodeType==11&&r.host))return r;r=r.assignedSlot||r.parentNode}return null}function R1(r,e){let t=e.focusNode,i=e.focusOffset;if(!t||e.anchorNode!=t||e.anchorOffset!=i)return!1;for(i=Math.min(i,hi(t));;)if(i){if(t.nodeType!=1)return!1;let s=t.childNodes[i-1];s.contentEditable=="false"?i--:(t=s,i=hi(t))}else{if(t==r)return!0;i=vi(t),t=t.parentNode}}function tp(r){return r instanceof Window?r.pageYOffset>Math.max(0,r.document.documentElement.scrollHeight-r.innerHeight-4):r.scrollTop>Math.max(1,r.scrollHeight-r.clientHeight-4)}function ip(r,e){for(let t=r,i=e;;){if(t.nodeType==3&&i>0)return{node:t,offset:i};if(t.nodeType==1&&i>0){if(t.contentEditable=="false")return null;t=t.childNodes[i-1],i=hi(t)}else if(t.parentNode&&!Nn(t))i=vi(t),t=t.parentNode;else return null}}function sp(r,e){for(let t=r,i=e;;){if(t.nodeType==3&&i<t.nodeValue.length)return{node:t,offset:i};if(t.nodeType==1&&i<t.childNodes.length){if(t.contentEditable=="false")return null;t=t.childNodes[i],i=0}else if(t.parentNode&&!Nn(t))i=vi(t)+1,t=t.parentNode;else return null}}var Jt=class r{constructor(e,t,i=!0){this.node=e,this.offset=t,this.precise=i}static before(e,t){return new r(e.parentNode,vi(e),t)}static after(e,t){return new r(e.parentNode,vi(e)+1,t)}},_e=function(r){return r[r.LTR=0]="LTR",r[r.RTL=1]="RTL",r}(_e||(_e={})),Yi=_e.LTR,Ba=_e.RTL;function rp(r){let e=[];for(let t=0;t<r.length;t++)e.push(1<<+r[t]);return e}var M1=rp("88888888888888888888888888888888888666888888787833333333337888888000000000000000000000000008888880000000000000000000000000088888888888888888888888888888888888887866668888088888663380888308888800000000000000000000000800000000000000000000000000000008"),D1=rp("4444448826627288999999999992222222222222222222222222222222222222222222222229999999999999999999994444444444644222822222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222999999949999999229989999223333333333"),Zl=Object.create(null),Xt=[];for(let r of["()","[]","{}"]){let e=r.charCodeAt(0),t=r.charCodeAt(1);Zl[e]=t,Zl[t]=-e}function np(r){return r<=247?M1[r]:1424<=r&&r<=1524?2:1536<=r&&r<=1785?D1[r-1536]:1774<=r&&r<=2220?4:8192<=r&&r<=8204?256:64336<=r&&r<=65023?4:1}var N1=/[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac\ufb50-\ufdff]/,Tt=class{get dir(){return this.level%2?Ba:Yi}constructor(e,t,i){this.from=e,this.to=t,this.level=i}side(e,t){return this.dir==t==e?this.to:this.from}forward(e,t){return e==(this.dir==t)}static find(e,t,i,s){let n=-1;for(let o=0;o<e.length;o++){let l=e[o];if(l.from<=t&&l.to>=t){if(l.level==i)return o;(n<0||(s!=0?s<0?l.from<t:l.to>t:e[n].level>l.level))&&(n=o)}}if(n<0)throw new RangeError("Index out of range");return n}};function op(r,e){if(r.length!=e.length)return!1;for(let t=0;t<r.length;t++){let i=r[t],s=e[t];if(i.from!=s.from||i.to!=s.to||i.direction!=s.direction||!op(i.inner,s.inner))return!1}return!0}var we=[];function I1(r,e,t,i,s){for(let n=0;n<=i.length;n++){let o=n?i[n-1].to:e,l=n<i.length?i[n].from:t,a=n?256:s;for(let h=o,c=a,u=a;h<l;h++){let p=np(r.charCodeAt(h));p==512?p=c:p==8&&u==4&&(p=16),we[h]=p==4?2:p,p&7&&(u=p),c=p}for(let h=o,c=a,u=a;h<l;h++){let p=we[h];if(p==128)h<l-1&&c==we[h+1]&&c&24?p=we[h]=c:we[h]=256;else if(p==64){let y=h+1;for(;y<l&&we[y]==64;)y++;let O=h&&c==8||y<t&&we[y]==8?u==1?1:8:256;for(let b=h;b<y;b++)we[b]=O;h=y-1}else p==8&&u==1&&(we[h]=1);c=p,p&7&&(u=p)}}}function L1(r,e,t,i,s){let n=s==1?2:1;for(let o=0,l=0,a=0;o<=i.length;o++){let h=o?i[o-1].to:e,c=o<i.length?i[o].from:t;for(let u=h,p,y,O;u<c;u++)if(y=Zl[p=r.charCodeAt(u)])if(y<0){for(let b=l-3;b>=0;b-=3)if(Xt[b+1]==-y){let v=Xt[b+2],k=v&2?s:v&4?v&1?n:s:0;k&&(we[u]=we[Xt[b]]=k),l=b;break}}else{if(Xt.length==189)break;Xt[l++]=u,Xt[l++]=p,Xt[l++]=a}else if((O=we[u])==2||O==1){let b=O==s;a=b?0:1;for(let v=l-3;v>=0;v-=3){let k=Xt[v+2];if(k&2)break;if(b)Xt[v+2]|=2;else{if(k&4)break;Xt[v+2]|=4}}}}}function Q1(r,e,t,i){for(let s=0,n=i;s<=t.length;s++){let o=s?t[s-1].to:r,l=s<t.length?t[s].from:e;for(let a=o;a<l;){let h=we[a];if(h==256){let c=a+1;for(;;)if(c==l){if(s==t.length)break;c=t[s++].to,l=s<t.length?t[s].from:e}else if(we[c]==256)c++;else break;let u=n==1,p=(c<e?we[c]:i)==1,y=u==p?u?1:2:i;for(let O=c,b=s,v=b?t[b-1].to:r;O>a;)O==v&&(O=t[--b].from,v=b?t[b-1].to:r),we[--O]=y;a=c}else n=h,a++}}}function ea(r,e,t,i,s,n,o){let l=i%2?2:1;if(i%2==s%2)for(let a=e,h=0;a<t;){let c=!0,u=!1;if(h==n.length||a<n[h].from){let b=we[a];b!=l&&(c=!1,u=b==16)}let p=!c&&l==1?[]:null,y=c?i:i+1,O=a;e:for(;;)if(h<n.length&&O==n[h].from){if(u)break e;let b=n[h];if(!c)for(let v=b.to,k=h+1;;){if(v==t)break e;if(k<n.length&&n[k].from==v)v=n[k++].to;else{if(we[v]==l)break e;break}}if(h++,p)p.push(b);else{b.from>a&&o.push(new Tt(a,b.from,y));let v=b.direction==Yi!=!(y%2);ta(r,v?i+1:i,s,b.inner,b.from,b.to,o),a=b.to}O=b.to}else{if(O==t||(c?we[O]!=l:we[O]==l))break;O++}p?ea(r,a,O,i+1,s,p,o):a<O&&o.push(new Tt(a,O,y)),a=O}else for(let a=t,h=n.length;a>e;){let c=!0,u=!1;if(!h||a>n[h-1].to){let b=we[a-1];b!=l&&(c=!1,u=b==16)}let p=!c&&l==1?[]:null,y=c?i:i+1,O=a;e:for(;;)if(h&&O==n[h-1].to){if(u)break e;let b=n[--h];if(!c)for(let v=b.from,k=h;;){if(v==e)break e;if(k&&n[k-1].to==v)v=n[--k].from;else{if(we[v-1]==l)break e;break}}if(p)p.push(b);else{b.to<a&&o.push(new Tt(b.to,a,y));let v=b.direction==Yi!=!(y%2);ta(r,v?i+1:i,s,b.inner,b.from,b.to,o),a=b.from}O=b.from}else{if(O==e||(c?we[O-1]!=l:we[O-1]==l))break;O--}p?ea(r,O,a,i+1,s,p,o):O<a&&o.push(new Tt(O,a,y)),a=O}}function ta(r,e,t,i,s,n,o){let l=e%2?2:1;I1(r,s,n,i,l),L1(r,s,n,i,l),Q1(s,n,i,l),ea(r,s,n,e,t,i,o)}function q1(r,e,t){if(!r)return[new Tt(0,0,e==Ba?1:0)];if(e==Yi&&!t.length&&!N1.test(r))return lp(r.length);if(t.length)for(;r.length>we.length;)we[we.length]=256;let i=[],s=e==Yi?0:1;return ta(r,s,s,t,0,r.length,i),i}function lp(r){return[new Tt(0,r,0)]}var ap="";function B1(r,e,t,i,s){var n;if(!r.length)return null;let o=i.head-r.from,l;if(i.head==r.from&&i.assoc<0){if(!s)return null;o=e[l=0].side(!1,t)}else if(i.head==r.to&&i.assoc>0){if(s)return null;o=e[l=e.length-1].side(!0,t)}else l=Tt.find(e,o,(n=i.bidiLevel)!==null&&n!==void 0?n:-1,i.assoc);let a=e[l],h=a.side(s,t);if(o==h){let p=l+=s?1:-1;if(p<0||p>=e.length)return null;a=e[l=p],o=a.side(!s,t),h=a.side(s,t)}let c=Ce(r.text,o,a.forward(s,t));(c<a.from||c>a.to)&&(c=h),ap=r.text.slice(Math.min(o,c),Math.max(o,c));let u=l==(s?e.length-1:0)?null:e[l+(s?1:-1)];if(c==h){if(!u)return s?M.cursor(r.to,1):M.cursor(r.from,-1);if(u.level+(s?0:1)<a.level)return M.cursor(u.side(!s,t)+r.from,u.forward(s,t)?1:-1,u.level)}return M.cursor(c+r.from,a.forward(s,t)?-1:1,a.level)}function $1(r,e,t){for(let i=e;i<t;i++){let s=np(r.charCodeAt(i));if(s==1)return Yi;if(s==2||s==4)return Ba}return Yi}var hp=W.define(),fp=W.define(),cp=W.define(),dp=W.define(),ia=W.define(),up=W.define(),pp=W.define(),$a=W.define(),Fa=W.define(),mp=W.define({combine:r=>r.some(e=>e)}),gp=W.define({combine:r=>r.some(e=>e)}),_p=W.define(),mr=class r{constructor(e,t,i,s,n,o=!1){this.range=e,this.y=t,this.x=i,this.yMargin=s,this.xMargin=n,this.isSnapshot=o}map(e){return e.empty?this:new r(this.range.map(e),this.y,this.x,this.yMargin,this.xMargin,this.isSnapshot)}clip(e){return this.range.to<=e.doc.length?this:new r(M.cursor(e.doc.length),this.y,this.x,this.yMargin,this.xMargin,this.isSnapshot)}},yn=re.define({map:(r,e)=>r.map(e)}),yp=re.define();function tt(r,e,t){let i=r.facet(dp);i.length?i[0](e):window.onerror&&window.onerror(String(e),t,void 0,void 0,e)||(t?console.error(t+":",e):console.error(e))}var oi=W.define({combine:r=>r.length?r[0]:!0}),F1=0,Cs=W.define({combine(r){return r.filter((e,t)=>{for(let i=0;i<t;i++)if(r[i].plugin==e.plugin)return!1;return!0})}}),qe=class r{constructor(e,t,i,s,n){this.id=e,this.create=t,this.domEventHandlers=i,this.domEventObservers=s,this.baseExtensions=n(this),this.extension=this.baseExtensions.concat(Cs.of({plugin:this,arg:void 0}))}of(e){return this.baseExtensions.concat(Cs.of({plugin:this,arg:e}))}static define(e,t){let{eventHandlers:i,eventObservers:s,provide:n,decorations:o}=t||{};return new r(F1++,e,i,s,l=>{let a=[];return o&&a.push(Gn.of(h=>{let c=h.plugin(l);return c?o(c):K.none})),n&&a.push(n(l)),a})}static fromClass(e,t){return r.define((i,s)=>new e(i,s),t)}},gr=class{constructor(e){this.spec=e,this.mustUpdate=null,this.value=null}get plugin(){return this.spec&&this.spec.plugin}update(e){if(this.value){if(this.mustUpdate){let t=this.mustUpdate;if(this.mustUpdate=null,this.value.update)try{this.value.update(t)}catch(i){if(tt(t.state,i,"CodeMirror plugin crashed"),this.value.destroy)try{this.value.destroy()}catch{}this.deactivate()}}}else if(this.spec)try{this.value=this.spec.plugin.create(e,this.spec.arg)}catch(t){tt(e.state,t,"CodeMirror plugin crashed"),this.deactivate()}return this}destroy(e){var t;if(!((t=this.value)===null||t===void 0)&&t.destroy)try{this.value.destroy()}catch(i){tt(e.state,i,"CodeMirror plugin crashed")}}deactivate(){this.spec=this.value=null}},bp=W.define(),Wa=W.define(),Gn=W.define(),Op=W.define(),za=W.define(),Tr=W.define(),vp=W.define();function bu(r,e){let t=r.state.facet(vp);if(!t.length)return t;let i=t.map(n=>n instanceof Function?n(r):n),s=[];return ce.spans(i,e.from,e.to,{point(){},span(n,o,l,a){let h=n-e.from,c=o-e.from,u=s;for(let p=l.length-1;p>=0;p--,a--){let y=l[p].spec.bidiIsolate,O;if(y==null&&(y=$1(e.text,h,c)),a>0&&u.length&&(O=u[u.length-1]).to==h&&O.direction==y)O.to=c,u=O.inner;else{let b={from:h,to:c,direction:y,inner:[]};u.push(b),u=b.inner}}}}),s}var wp=W.define();function ja(r){let e=0,t=0,i=0,s=0;for(let n of r.state.facet(wp)){let o=n(r);o&&(o.left!=null&&(e=Math.max(e,o.left)),o.right!=null&&(t=Math.max(t,o.right)),o.top!=null&&(i=Math.max(i,o.top)),o.bottom!=null&&(s=Math.max(s,o.bottom)))}return{left:e,right:t,top:i,bottom:s}}var cr=W.define(),Lt=class r{constructor(e,t,i,s){this.fromA=e,this.toA=t,this.fromB=i,this.toB=s}join(e){return new r(Math.min(this.fromA,e.fromA),Math.max(this.toA,e.toA),Math.min(this.fromB,e.fromB),Math.max(this.toB,e.toB))}addToSet(e){let t=e.length,i=this;for(;t>0;t--){let s=e[t-1];if(!(s.fromA>i.toA)){if(s.toA<i.fromA)break;i=i.join(s),e.splice(t-1,1)}}return e.splice(t,0,i),e}static extendWithRanges(e,t){if(t.length==0)return e;let i=[];for(let s=0,n=0,o=0;;){let l=s<e.length?e[s].fromB:1e9,a=n<t.length?t[n]:1e9,h=Math.min(l,a);if(h==1e9)break;let c=h+o,u=h,p=c;for(;;)if(n<t.length&&t[n]<=u){let y=t[n+1];n+=2,u=Math.max(u,y);for(let O=s;O<e.length&&e[O].fromB<=u;O++)o=e[O].toA-e[O].toB;p=Math.max(p,y+o)}else if(s<e.length&&e[s].fromB<=u){let y=e[s++];u=Math.max(u,y.toB),p=Math.max(p,y.toA),o=y.toA-y.toB}else break;i.push(new r(c,p,h,u))}return i}},Ln=class r{constructor(e,t,i){this.view=e,this.state=t,this.transactions=i,this.flags=0,this.startState=e.state,this.changes=Ze.empty(this.startState.doc.length);for(let n of i)this.changes=this.changes.compose(n.changes);let s=[];this.changes.iterChangedRanges((n,o,l,a)=>s.push(new Lt(n,o,l,a))),this.changedRanges=s}static create(e,t,i){return new r(e,t,i)}get viewportChanged(){return(this.flags&4)>0}get viewportMoved(){return(this.flags&8)>0}get heightChanged(){return(this.flags&2)>0}get geometryChanged(){return this.docChanged||(this.flags&18)>0}get focusChanged(){return(this.flags&1)>0}get docChanged(){return!this.changes.empty}get selectionSet(){return this.transactions.some(e=>e.selection)}get empty(){return this.flags==0&&this.transactions.length==0}},W1=[],Se=class{constructor(e,t,i=0){this.dom=e,this.length=t,this.flags=i,this.parent=null,e.cmTile=this}get breakAfter(){return this.flags&1}get children(){return W1}isWidget(){return!1}get isHidden(){return!1}isComposite(){return!1}isLine(){return!1}isText(){return!1}isBlock(){return!1}get domAttrs(){return null}sync(e){if(this.flags|=2,this.flags&4){this.flags&=-5;let t=this.domAttrs;t&&S1(this.dom,t)}}toString(){return this.constructor.name+(this.children.length?`(${this.children})`:"")+(this.breakAfter?"#":"")}destroy(){this.parent=null}setDOM(e){this.dom=e,e.cmTile=this}get posAtStart(){return this.parent?this.parent.posBefore(this):0}get posAtEnd(){return this.posAtStart+this.length}posBefore(e,t=this.posAtStart){let i=t;for(let s of this.children){if(s==e)return i;i+=s.length+s.breakAfter}throw new RangeError("Invalid child in posBefore")}posAfter(e){return this.posBefore(e)+e.length}covers(e){return!0}coordsIn(e,t,i){return null}domPosFor(e,t){let i=vi(this.dom),s=this.length?e>0:t>0;return new Jt(this.parent.dom,i+(s?1:0),e==0||e==this.length)}markDirty(e){this.flags&=-3,e&&(this.flags|=4),this.parent&&this.parent.flags&2&&this.parent.markDirty(!1)}get overrideDOMText(){return null}get root(){for(let e=this;e;e=e.parent)if(e instanceof Is)return e;return null}static get(e){return e.cmTile}},Ns=class extends Se{constructor(e){super(e,0),this._children=[]}isComposite(){return!0}get children(){return this._children}get lastChild(){return this.children.length?this.children[this.children.length-1]:null}append(e){this.children.push(e),e.parent=this}sync(e){if(this.flags&2)return;super.sync(e);let t=this.dom,i=null,s,n=(e==null?void 0:e.node)==t?e:null,o=0;for(let l of this.children){if(l.sync(e),o+=l.length+l.breakAfter,s=i?i.nextSibling:t.firstChild,n&&s!=l.dom&&(n.written=!0),l.dom.parentNode==t)for(;s&&s!=l.dom;)s=Ou(s);else t.insertBefore(l.dom,s);i=l.dom}for(s=i?i.nextSibling:t.firstChild,n&&s&&(n.written=!0);s;)s=Ou(s);this.length=o}};function Ou(r){let e=r.nextSibling;return r.parentNode.removeChild(r),e}var Is=class extends Ns{constructor(e,t){super(t),this.view=e}owns(e){for(;e;e=e.parent)if(e==this)return!0;return!1}isBlock(){return!0}nearest(e){for(;;){if(!e)return null;let t=Se.get(e);if(t&&this.owns(t))return t;e=e.parentNode}}blockTiles(e){for(let t=[],i=this,s=0,n=0;;)if(s==i.children.length){if(!t.length)return;i=i.parent,i.breakAfter&&n++,s=t.pop()}else{let o=i.children[s++];if(o instanceof li)t.push(s),i=o,s=0;else{let l=n+o.length,a=e(o,n);if(a!==void 0)return a;n=l+o.breakAfter}}}resolveBlock(e,t){let i,s=-1,n,o=-1;if(this.blockTiles((l,a)=>{let h=a+l.length;if(e>=a&&e<=h){if(l.isWidget()&&t>=-1&&t<=1){if(l.flags&32)return!0;l.flags&16&&(i=void 0)}(a<e||e==h&&(t<-1?l.length:l.covers(1)))&&(!i||!l.isWidget()&&i.isWidget())&&(i=l,s=e-a),(h>e||e==a&&(t>1?l.length:l.covers(-1)))&&(!n||!l.isWidget()&&n.isWidget())&&(n=l,o=e-a)}}),!i&&!n)throw new Error("No tile at position "+e);return i&&t<0||!n?{tile:i,offset:s}:{tile:n,offset:o}}},li=class r extends Ns{constructor(e,t){super(e),this.wrapper=t}isBlock(){return!0}covers(e){return this.children.length?e<0?this.children[0].covers(-1):this.lastChild.covers(1):!1}get domAttrs(){return this.wrapper.attributes}static of(e,t){let i=new r(t||document.createElement(e.tagName),e);return t||(i.flags|=4),i}},Ls=class r extends Ns{constructor(e,t){super(e),this.attrs=t}isLine(){return!0}static start(e,t,i){let s=new r(t||document.createElement("div"),e);return(!t||!i)&&(s.flags|=4),s}get domAttrs(){return this.attrs}resolveInline(e,t,i){let s=null,n=-1,o=null,l=-1;function a(c,u){for(let p=0,y=0;p<c.children.length&&y<=u;p++){let O=c.children[p],b=y+O.length;b>=u&&(O.isComposite()?a(O,u-y):(!o||o.isHidden&&(t>0&&!(o.flags&32)||i&&j1(o,O)))&&(b>u||O.flags&32&&t<=1)?(o=O,l=u-y):(y<u||O.flags&16&&!O.isHidden&&t>=-1)&&(s=O,n=u-y)),y=b}}a(this,e);let h=(t<0?s:o)||s||o;return h?{tile:h,offset:h==s?n:l}:null}coordsIn(e,t,i){let s=this.resolveInline(e,t,!0);return s?s.tile.coordsIn(Math.max(0,s.offset),t,i):z1(this)}domIn(e,t){let i=this.resolveInline(e,t);if(i){let{tile:s,offset:n}=i;if(this.dom.contains(s.dom))return s.isText()?new Jt(s.dom,Math.min(s.dom.nodeValue.length,n)):s.domPosFor(n,s.flags&16?1:s.flags&32?-1:t);let o=i.tile.parent,l=!1;for(let a of o.children){if(l)return new Jt(a.dom,0);a==i.tile&&(l=!0)}}return new Jt(this.dom,0)}};function z1(r){let e=r.dom.lastChild;if(!e)return r.dom.getBoundingClientRect();let t=Tn(e);return t[t.length-1]||null}function j1(r,e){let t=r.coordsIn(0,1),i=e.coordsIn(0,1);return t&&i&&i.top<t.bottom}var at=class r extends Ns{constructor(e,t){super(e),this.mark=t}get domAttrs(){return this.mark.attrs}static of(e,t){let i=new r(t||document.createElement(e.tagName),e);return t||(i.flags|=4),i}},Gi=class r extends Se{constructor(e,t){super(e,t.length),this.text=t}sync(e){this.flags&2||(super.sync(e),this.dom.nodeValue!=this.text&&(e&&e.node==this.dom&&(e.written=!0),this.dom.nodeValue=this.text))}isText(){return!0}toString(){return JSON.stringify(this.text)}coordsIn(e,t,i){let s=this.dom.nodeValue.length;e>s&&(e=s);let n=e,o=e,l=0;e==0&&t<0||e==s&&t>=0?$.chrome||$.gecko||(e?(n--,l=1):o<s&&(o++,l=-1)):t<0?n--:o<s&&o++;let a=xr(this.dom,n,o).getClientRects();if(!a.length)return null;let h=a[(l?l<0:t>=0)?0:a.length-1];return $.safari&&!l&&h.width==0&&(h=Array.prototype.find.call(a,c=>c.width)||h),i==null?h:In(h,(l?l>0:t<0)==i)}static of(e,t){let i=new r(t||document.createTextNode(e),e);return t||(i.flags|=2),i}},Ki=class r extends Se{constructor(e,t,i,s){super(e,t,s),this.widget=i}isWidget(){return!0}get isHidden(){return this.widget.isHidden}covers(e){return this.flags&48?!1:(this.flags&(e<0?64:128))>0}coordsIn(e,t){return this.coordsInWidget(e,t,!1)}coordsInWidget(e,t,i){let s=this.widget.coordsAt(this.dom,e,t);if(s)return s;if(i)return In(this.dom.getBoundingClientRect(),this.length?e==0:t<=0);{let n=this.dom.getClientRects(),o=null;if(!n.length)return null;let l=this.flags&16?!0:this.flags&32?!1:e>0;for(let a=l?n.length-1:0;o=n[a],!(e>0?a==0:a==n.length-1||o.top<o.bottom);a+=l?-1:1);return In(o,!l)}}get overrideDOMText(){if(!this.length)return oe.empty;let{root:e}=this;if(!e)return oe.empty;let t=this.posAtStart;return e.view.state.doc.slice(t,t+this.length)}destroy(){super.destroy(),this.widget.destroy(this.dom)}static of(e,t,i,s,n){return n||(n=e.toDOM(t),e.editable||(n.contentEditable="false")),new r(n,i,e,s)}},Qs=class extends Se{constructor(e){let t=document.createElement("img");t.className="cm-widgetBuffer",t.setAttribute("aria-hidden","true"),super(t,0,e)}get isHidden(){return!0}get overrideDOMText(){return oe.empty}coordsIn(e,t,i){let s=this.dom.getBoundingClientRect();return i==null?s:In(s,t>0==i)}},sa=class{constructor(e){this.index=0,this.beforeBreak=!1,this.parents=[],this.tile=e}advance(e,t,i){let{tile:s,index:n,beforeBreak:o,parents:l}=this;for(;e||t>0;)if(s.isComposite())if(o){if(!e)break;i&&i.break(),e--,o=!1}else if(n==s.children.length){if(!e&&!l.length)break;i&&i.leave(s),o=!!s.breakAfter,{tile:s,index:n}=l.pop(),n++}else{let a=s.children[n],h=a.breakAfter;(t>0?a.length<=e:a.length<e)&&(!i||i.skip(a,0,a.length)!==!1||!a.isComposite)?(o=!!h,n++,e-=a.length):(l.push({tile:s,index:n}),s=a,n=0,i&&a.isComposite()&&i.enter(a))}else{let a=s.length;if(n<a&&e){let h=Math.min(e,a-n);i&&i.skip(s,n,n+h),e-=h,n+=h}if(n==a)o=!!s.breakAfter,{tile:s,index:n}=l.pop(),n++;else if(!e)break}return this.tile=s,this.index=n,this.beforeBreak=o,this}get root(){return this.parents.length?this.parents[0].tile:this.tile}},ra=class{constructor(e,t,i,s){this.from=e,this.to=t,this.wrapper=i,this.rank=s}},na=class{constructor(e,t,i){this.cache=e,this.root=t,this.blockWrappers=i,this.curLine=null,this.lastBlock=null,this.afterWidget=null,this.pos=0,this.wrappers=[],this.wrapperPos=0}addText(e,t,i,s){var n;this.flushBuffer();let o=this.ensureMarks(t,i),l=o.lastChild;if(l&&l.isText()&&!(l.flags&8)&&l.length+e.length<512){this.cache.reused.set(l,2);let a=o.children[o.children.length-1]=new Gi(l.dom,l.text+e);a.parent=o}else o.append(s||Gi.of(e,(n=this.cache.find(Gi))===null||n===void 0?void 0:n.dom));this.pos+=e.length,this.afterWidget=null}addComposition(e,t){let i=this.curLine;i.dom!=t.line.dom&&(i.setDOM(this.cache.reused.has(t.line)?Fl(t.line.dom):t.line.dom),this.cache.reused.set(t.line,2));let s=i;for(let l=t.marks.length-1;l>=0;l--){let a=t.marks[l],h=s.lastChild;if(h instanceof at&&h.mark.eq(a.mark))h.dom!=a.dom&&h.setDOM(Fl(a.dom)),s=h;else{let{dom:c}=a;this.cache.reused.get(a)&&Se.get(a.dom)&&(c=Fl(a.dom));let u=at.of(a.mark,c);s.append(u),s=u}this.cache.reused.set(a,2)}let n=Se.get(e.text);n&&this.cache.reused.set(n,2);let o=new Gi(e.text,e.text.nodeValue);o.flags|=8,this.pos=e.range.toB,s.append(o)}addInlineWidget(e,t,i){let s=this.afterWidget&&e.flags&48&&(this.afterWidget.flags&48)==(e.flags&48);s||this.flushBuffer();let n=this.ensureMarks(t,i);!s&&!(e.flags&16)&&n.append(this.getBuffer(1)),n.append(e),this.pos+=e.length,this.afterWidget=e}addMark(e,t,i){this.flushBuffer(),this.ensureMarks(t,i).append(e),this.pos+=e.length,this.afterWidget=null}addBlockWidget(e){this.getBlockPos().append(e),this.pos+=e.length,this.lastBlock=e,this.endLine()}continueWidget(e){let t=this.afterWidget||this.lastBlock;t.length+=e,this.pos+=e}addLineStart(e,t){var i;e||(e=kp);let s=Ls.start(e,t||((i=this.cache.find(Ls))===null||i===void 0?void 0:i.dom),!!t);this.getBlockPos().append(this.lastBlock=this.curLine=s)}addLine(e){this.getBlockPos().append(e),this.pos+=e.length,this.lastBlock=e,this.endLine()}addBreak(){this.lastBlock.flags|=1,this.endLine(),this.pos++}addLineStartIfNotCovered(e){this.blockPosCovered()||this.addLineStart(e)}ensureLine(e){this.curLine||this.addLineStart(e)}ensureMarks(e,t){var i;let s=this.curLine;for(let n=e.length-1;n>=0;n--){let o=e[n],l;if(t>0&&(l=s.lastChild)&&l instanceof at&&l.mark.eq(o))s=l,t--;else{let a=at.of(o,(i=this.cache.find(at,h=>h.mark.eq(o)))===null||i===void 0?void 0:i.dom);s.append(a),s=a,t=0}}return s}endLine(){if(this.curLine){this.flushBuffer();let e=this.curLine.lastChild;(!e||!vu(this.curLine,!1)||e.dom.nodeName!="BR"&&e.isWidget()&&!($.ios&&vu(this.curLine,!0)))&&this.curLine.append(this.cache.findWidget(Wl,0,32)||new Ki(Wl.toDOM(),0,Wl,32)),this.curLine=this.afterWidget=null}}updateBlockWrappers(){this.wrapperPos>this.pos+1e4&&(this.blockWrappers.goto(this.pos),this.wrappers.length=0);for(let e=this.wrappers.length-1;e>=0;e--)this.wrappers[e].to<this.pos&&this.wrappers.splice(e,1);for(let e=this.blockWrappers;e.value&&e.from<=this.pos;e.next())if(e.to>=this.pos){let t=e.rank*102+e.value.rank,i=new ra(e.from,e.to,e.value,t),s=this.wrappers.length;for(;s>0&&(this.wrappers[s-1].rank-i.rank||this.wrappers[s-1].to-i.to)<0;)s--;this.wrappers.splice(s,0,i)}this.wrapperPos=this.pos}getBlockPos(){var e;this.updateBlockWrappers();let t=this.root;for(let i of this.wrappers){let s=t.lastChild;if(i.from<this.pos&&s instanceof li&&s.wrapper.eq(i.wrapper))t=s;else{let n=li.of(i.wrapper,(e=this.cache.find(li,o=>o.wrapper.eq(i.wrapper)))===null||e===void 0?void 0:e.dom);t.append(n),t=n}}return t}blockPosCovered(){let e=this.lastBlock;return e!=null&&!e.breakAfter&&(!e.isWidget()||(e.flags&160)>0)}getBuffer(e){let t=2|(e<0?16:32),i=this.cache.find(Qs,void 0,1);return i&&(i.flags=t),i||new Qs(t)}flushBuffer(){this.afterWidget&&!(this.afterWidget.flags&32)&&(this.afterWidget.parent.append(this.getBuffer(-1)),this.afterWidget=null)}},oa=class{constructor(e){this.skipCount=0,this.text="",this.textOff=0,this.cursor=e.iter()}skip(e){this.textOff+e<=this.text.length?this.textOff+=e:(this.skipCount+=e-(this.text.length-this.textOff),this.text="",this.textOff=0)}next(e){if(this.textOff==this.text.length){let{value:s,lineBreak:n,done:o}=this.cursor.next(this.skipCount);if(this.skipCount=0,o)throw new Error("Ran out of text content when drawing inline views");this.text=s;let l=this.textOff=Math.min(e,s.length);return n?null:s.slice(0,l)}let t=Math.min(this.text.length,this.textOff+e),i=this.text.slice(this.textOff,t);return this.textOff=t,i}},Qn=[Ki,Ls,Gi,at,Qs,li,Is];for(let r=0;r<Qn.length;r++)Qn[r].bucket=r;var la=class{constructor(e){this.view=e,this.buckets=Qn.map(()=>[]),this.index=Qn.map(()=>0),this.reused=new Map}add(e){let t=e.constructor.bucket,i=this.buckets[t];i.length<6?i.push(e):i[this.index[t]=(this.index[t]+1)%6]=e}find(e,t,i=2){let s=e.bucket,n=this.buckets[s],o=this.index[s];for(let l=0;l<n.length;l++){let a=(l+o)%n.length,h=n[a];if((!t||t(h))&&!this.reused.has(h))return n.splice(a,1),a<o&&this.index[s]--,this.reused.set(h,i),h}return null}findWidget(e,t,i){let s=this.buckets[0];if(s.length)for(let n=0,o=0;;n++){if(n==s.length){if(o)return null;o=1,n=0}let l=s[n];if(!this.reused.has(l)&&(o==0?l.widget.compare(e):l.widget.constructor==e.constructor&&e.updateDOM(l.dom,this.view,l.widget)))return s.splice(n,1),n<this.index[0]&&this.index[0]--,l.widget==e&&l.length==t&&(l.flags&497)==i?(this.reused.set(l,1),l):(this.reused.set(l,2),new Ki(l.dom,t,e,l.flags&-498|i))}}reuse(e){return this.reused.set(e,1),e}maybeReuse(e,t=2){if(!this.reused.has(e))return this.reused.set(e,t),e.dom}clear(){for(let e=0;e<this.buckets.length;e++)this.buckets[e].length=this.index[e]=0}},aa=class{constructor(e,t,i,s,n){this.view=e,this.decorations=s,this.disallowBlockEffectsFor=n,this.openWidget=!1,this.openMarks=0,this.cache=new la(e),this.text=new oa(e.state.doc),this.builder=new na(this.cache,new Is(e,e.contentDOM),ce.iter(i)),this.cache.reused.set(t,2),this.old=new sa(t),this.reuseWalker={skip:(o,l,a)=>{if(this.cache.add(o),o.isComposite())return!1},enter:o=>this.cache.add(o),leave:()=>{},break:()=>{}}}run(e,t){let i=t&&this.getCompositionContext(t.text);for(let s=0,n=0,o=0;;){let l=o<e.length?e[o++]:null,a=l?l.fromA:this.old.root.length;if(a>s){let h=a-s;this.preserve(h,!o,!l),s=a,n+=h}if(!l)break;t&&l.fromA<=t.range.fromA&&l.toA>=t.range.toA?(this.forward(l.fromA,t.range.fromA,t.range.fromA<t.range.toA?1:-1),this.emit(n,t.range.fromB),this.builder.flushBuffer(),this.cache.clear(),this.builder.addComposition(t,i),this.text.skip(t.range.toB-t.range.fromB),this.forward(t.range.fromA,l.toA),this.emit(t.range.toB,l.toB)):(this.forward(l.fromA,l.toA),this.emit(n,l.toB)),n=l.toB,s=l.toA}return this.builder.curLine&&this.builder.endLine(),this.builder.root}preserve(e,t,i){let s=U1(this.old),n=this.openMarks;this.old.advance(e,i?1:-1,{skip:(o,l,a)=>{if(o.isWidget())if(this.openWidget)this.builder.continueWidget(a-l);else{let h=a>0||l<o.length?Ki.of(o.widget,this.view,a-l,o.flags&496,this.cache.maybeReuse(o)):this.cache.reuse(o);h.flags&256?(h.flags&=-2,this.builder.addBlockWidget(h)):(this.builder.ensureLine(null),this.builder.addInlineWidget(h,s,n),n=s.length)}else if(o.isText())this.builder.ensureLine(null),!l&&a==o.length&&!this.cache.reused.has(o)?this.builder.addText(o.text,s,n,this.cache.reuse(o)):(this.cache.add(o),this.builder.addText(o.text.slice(l,a),s,n)),n=s.length;else if(o.isLine())o.flags&=-2,this.cache.reused.set(o,1),this.builder.addLine(o);else if(o instanceof Qs)this.cache.add(o);else if(o instanceof at)this.builder.ensureLine(null),this.builder.addMark(o,s,n),this.cache.reused.set(o,1),n=s.length;else return!1;this.openWidget=!1},enter:o=>{o.isLine()?this.builder.addLineStart(o.attrs,this.cache.maybeReuse(o)):(this.cache.add(o),o instanceof at&&s.unshift(o.mark)),this.openWidget=!1},leave:o=>{o.isLine()?s.length&&(s.length=n=0):o instanceof at&&(s.shift(),n=Math.min(n,s.length))},break:()=>{this.builder.addBreak(),this.openWidget=!1}}),this.text.skip(e)}emit(e,t){let i=null,s=this.builder,n=-1,o=ce.spans(this.decorations,e,t,{point:(l,a,h,c,u,p)=>{if(h instanceof Ji){if(this.disallowBlockEffectsFor[p]){if(h.block)throw new RangeError("Block decorations may not be specified via plugins");if(a>this.view.state.doc.lineAt(l).to)throw new RangeError("Decorations that replace line breaks may not be specified via plugins")}if(n=c.length,u>c.length)s.continueWidget(a-l);else{let y=h.widget||(h.block?wi.block:wi.inline),O=H1(h),b=this.cache.findWidget(y,a-l,O)||Ki.of(y,this.view,a-l,O);h.block?(h.startSide>0&&s.addLineStartIfNotCovered(i),s.addBlockWidget(b)):(s.ensureLine(i),s.addInlineWidget(b,c,u))}i=null}else i=V1(i,h);a>l&&this.text.skip(a-l)},span:(l,a,h,c)=>{for(let u=l;u<a;){let p=this.text.next(Math.min(512,a-u));p==null?(s.addLineStartIfNotCovered(i),s.addBreak(),u++):(s.ensureLine(i),s.addText(p,h,u==l?c:h.length),u+=p.length),i=null}n=h.length}});n>-1&&(this.openWidget=o>n),this.openWidget||s.addLineStartIfNotCovered(i),this.openMarks=o}forward(e,t,i=1){t-e<=10?this.old.advance(t-e,i,this.reuseWalker):(this.old.advance(5,-1,this.reuseWalker),this.old.advance(t-e-10,-1),this.old.advance(5,i,this.reuseWalker))}getCompositionContext(e){let t=[],i=null;for(let s=e.parentNode;;s=s.parentNode){let n=Se.get(s);if(s==this.view.contentDOM)break;n instanceof at?t.push(n):n!=null&&n.isLine()?i=n:n instanceof li||(s.nodeName=="DIV"&&!i?i=new Ls(s,kp):i||t.push(at.of(new vr({tagName:s.nodeName.toLowerCase(),attributes:T1(s)}),s)))}return i?{line:i,marks:t}:null}};function vu(r,e){let t=i=>{for(let s of i.children)if((e?s.isText():s.length)||t(s))return!0;return!1};return t(r)}function H1(r){let e=r.isReplace?(r.startSide<0?64:0)|(r.endSide>0?128:0):r.startSide>0?32:16;return r.block&&(e|=256),e}var kp={class:"cm-line"};function V1(r,e){let t=e.spec.attributes,i=e.spec.class;return!t&&!i||(r||(r={class:"cm-line"}),t&&Qa(t,r),i&&(r.class+=" "+i)),r}function U1(r){let e=[];for(let t=r.parents.length;t>1;t--){let i=t==r.parents.length?r.tile:r.parents[t].tile;i instanceof at&&e.push(i.mark)}return e}function Fl(r){let e=Se.get(r);return e&&e.setDOM(r.cloneNode()),r}var wi=class extends ai{constructor(e){super(),this.tag=e}eq(e){return e.tag==this.tag}toDOM(){return document.createElement(this.tag)}updateDOM(e){return e.nodeName.toLowerCase()==this.tag}get isHidden(){return!0}};wi.inline=new wi("span");wi.block=new wi("div");var Wl=new class extends ai{toDOM(){return document.createElement("br")}get isHidden(){return!0}get editable(){return!0}},qn=class{constructor(e){this.view=e,this.decorations=[],this.blockWrappers=[],this.dynamicDecorationMap=[!1],this.domChanged=null,this.hasComposition=null,this.editContextFormatting=K.none,this.lastCompositionAfterCursor=!1,this.minWidth=0,this.minWidthFrom=0,this.minWidthTo=0,this.impreciseAnchor=null,this.impreciseHead=null,this.forceSelection=!1,this.lastUpdate=Date.now(),this.updateDeco(),this.tile=new Is(e,e.contentDOM),this.updateInner([new Lt(0,0,0,e.state.doc.length)],null)}update(e){var t;let i=e.changedRanges;this.minWidth>0&&i.length&&(i.every(({fromA:c,toA:u})=>u<this.minWidthFrom||c>this.minWidthTo)?(this.minWidthFrom=e.changes.mapPos(this.minWidthFrom,1),this.minWidthTo=e.changes.mapPos(this.minWidthTo,1)):this.minWidth=this.minWidthFrom=this.minWidthTo=0),this.updateEditContextFormatting(e);let s=-1;this.view.inputState.composing>=0&&!this.view.observer.editContext&&(!((t=this.domChanged)===null||t===void 0)&&t.newSel?s=this.domChanged.newSel.head:!tv(e.changes,this.hasComposition)&&!e.selectionSet&&(s=e.state.selection.main.head));let n=s>-1?X1(this.view,e.changes,s):null;if(this.domChanged=null,this.hasComposition){let{from:c,to:u}=this.hasComposition;i=new Lt(c,u,e.changes.mapPos(c,-1),e.changes.mapPos(u,1)).addToSet(i.slice())}this.hasComposition=n?{from:n.range.fromB,to:n.range.toB}:null,($.ie||$.chrome)&&!n&&e&&e.state.doc.lines!=e.startState.doc.lines&&(this.forceSelection=!0);let o=this.decorations,l=this.blockWrappers;this.updateDeco();let a=K1(o,this.decorations,e.changes);a.length&&(i=Lt.extendWithRanges(i,a));let h=Z1(l,this.blockWrappers,e.changes);return h.length&&(i=Lt.extendWithRanges(i,h)),n&&!i.some(c=>c.fromA<=n.range.fromA&&c.toA>=n.range.toA)&&(i=n.range.addToSet(i.slice())),this.tile.flags&2&&i.length==0?!1:(this.updateInner(i,n),e.transactions.length&&(this.lastUpdate=Date.now()),!0)}updateInner(e,t){this.view.viewState.mustMeasureContent=!0;let{observer:i}=this.view;i.ignore(()=>{if(t||e.length){let o=this.tile,l=new aa(this.view,o,this.blockWrappers,this.decorations,this.dynamicDecorationMap);t&&Se.get(t.text)&&l.cache.reused.set(Se.get(t.text),2),this.tile=l.run(e,t),ha(o,l.cache.reused)}this.tile.dom.style.height=this.view.viewState.contentHeight/this.view.scaleY+"px",this.tile.dom.style.flexBasis=this.minWidth?this.minWidth+"px":"";let n=$.chrome||$.ios?{node:i.selectionRange.focusNode,written:!1}:void 0;this.tile.sync(n),n&&(n.written||i.selectionRange.focusNode!=n.node||!this.tile.dom.contains(n.node))&&(this.forceSelection=!0),this.tile.dom.style.height=""});let s=[];if(this.view.viewport.from||this.view.viewport.to<this.view.state.doc.length)for(let n of this.tile.children)n.isWidget()&&n.widget instanceof _r&&s.push(n.dom);i.updateGaps(s)}updateEditContextFormatting(e){this.editContextFormatting=this.editContextFormatting.map(e.changes);for(let t of e.transactions)for(let i of t.effects)i.is(yp)&&(this.editContextFormatting=i.value)}updateSelection(e=!1,t=!1){(e||!this.view.observer.selectionRange.focusNode)&&this.view.observer.readSelectionRange();let{dom:i}=this.tile,s=this.view.root.activeElement,n=s==i,o=!n&&!(this.view.state.facet(oi)||i.tabIndex>-1)&&ur(i,this.view.observer.selectionRange)&&!(s&&i.contains(s));if(!(n||t||o))return;let l=this.forceSelection;this.forceSelection=!1;let a=this.view.state.selection.main,h,c;if(a.empty?c=h=this.inlineDOMNearPos(a.anchor,a.assoc||1):(c=this.inlineDOMNearPos(a.head,a.head==a.from?1:-1),h=this.inlineDOMNearPos(a.anchor,a.anchor==a.from?1:-1)),$.gecko&&a.empty&&!this.hasComposition&&G1(h)){let p=document.createTextNode("");this.view.observer.ignore(()=>h.node.insertBefore(p,h.node.childNodes[h.offset]||null)),h=c=new Jt(p,0),l=!0}let u=this.view.observer.selectionRange;(l||!u.focusNode||(!pr(h.node,h.offset,u.anchorNode,u.anchorOffset)||!pr(c.node,c.offset,u.focusNode,u.focusOffset))&&!this.suppressWidgetCursorChange(u,a))&&(this.view.observer.ignore(()=>{$.android&&$.chrome&&i.contains(u.focusNode)&&ev(u.focusNode,i)&&(i.blur(),i.focus({preventScroll:!0}));let p=kr(this.view.root);if(p)if(a.empty){if($.gecko){let y=J1(h.node,h.offset);if(y&&y!=3){let O=(y==1?ip:sp)(h.node,h.offset);O&&(h=new Jt(O.node,O.offset))}}p.collapse(h.node,h.offset),a.bidiLevel!=null&&p.caretBidiLevel!==void 0&&(p.caretBidiLevel=a.bidiLevel)}else if(p.extend){p.collapse(h.node,h.offset);try{p.extend(c.node,c.offset)}catch{}}else{let y=document.createRange();a.anchor>a.head&&([h,c]=[c,h]),y.setEnd(c.node,c.offset),y.setStart(h.node,h.offset),p.removeAllRanges(),p.addRange(y)}o&&this.view.root.activeElement==i&&(i.blur(),s&&s.focus())}),this.view.observer.setSelectionRange(h,c)),this.impreciseAnchor=h.precise?null:new Jt(u.anchorNode,u.anchorOffset),this.impreciseHead=c.precise?null:new Jt(u.focusNode,u.focusOffset)}suppressWidgetCursorChange(e,t){return this.hasComposition&&t.empty&&pr(e.focusNode,e.focusOffset,e.anchorNode,e.anchorOffset)&&this.posFromDOM(e.focusNode,e.focusOffset)==t.head}enforceCursorAssoc(){if(this.hasComposition)return;let{view:e}=this,t=e.state.selection.main,i=kr(e.root),{anchorNode:s,anchorOffset:n}=e.observer.selectionRange;if(!i||!t.empty||!t.assoc||!i.modify)return;let o=this.lineAt(t.head,t.assoc);if(!o)return;let l=o.posAtStart;if(t.head==l||t.head==l+o.length)return;let a=this.coordsAt(t.head,-1),h=this.coordsAt(t.head,1);if(!a||!h||a.bottom>h.top)return;let c=this.domAtPos(t.head+t.assoc,t.assoc);i.collapse(c.node,c.offset),i.modify("move",t.assoc<0?"forward":"backward","lineboundary"),e.observer.readSelectionRange();let u=e.observer.selectionRange;e.docView.posFromDOM(u.anchorNode,u.anchorOffset)!=t.from&&i.collapse(s,n)}posFromDOM(e,t){let i=this.tile.nearest(e);if(!i)return this.tile.dom.compareDocumentPosition(e)&2?0:this.view.state.doc.length;let s=i.posAtStart;if(i.isComposite()){let n;if(e==i.dom)n=i.dom.childNodes[t];else{let o=hi(e)==0?0:t==0?-1:1;for(;;){let l=e.parentNode;if(l==i.dom)break;o==0&&l.firstChild!=l.lastChild&&(e==l.firstChild?o=-1:o=1),e=l}o<0?n=e:n=e.nextSibling}if(n==i.dom.firstChild)return s;for(;n&&!Se.get(n);)n=n.nextSibling;if(!n)return s+i.length;for(let o=0,l=s;;o++){let a=i.children[o];if(a.dom==n)return l;l+=a.length+a.breakAfter}}else return i.isText()?e==i.dom?s+t:s+(t?i.length:0):s}domAtPos(e,t){let{tile:i,offset:s}=this.tile.resolveBlock(e,t);return i.isWidget()?i.domPosFor(s,t):i.domIn(s,t)}inlineDOMNearPos(e,t){let i,s=-1,n=!1,o,l=-1,a=!1;return this.tile.blockTiles((h,c)=>{if(h.isWidget()){if(h.flags&32&&c>=e)return!0;h.flags&16&&(n=!0)}else{let u=c+h.length;if(c<=e&&(i=h,s=e-c,n=u<e),u>=e&&!o&&(o=h,l=e-c,a=c>e),c>e&&o)return!0}}),!i&&!o?this.domAtPos(e,t):(n&&o?i=null:a&&i&&(o=null),i&&t<0||!o?i.domIn(s,t):o.domIn(l,t))}coordsAt(e,t,i){let{tile:s,offset:n}=this.tile.resolveBlock(e,t);return s.isWidget()?s.widget instanceof _r?null:s.coordsInWidget(n,t,!0):s.coordsIn(n,t,i)}lineAt(e,t){let{tile:i}=this.tile.resolveBlock(e,t);return i.isLine()?i:null}coordsForChar(e){let{tile:t,offset:i}=this.tile.resolveBlock(e,1);if(!t.isLine())return null;function s(n,o){if(n.isComposite())for(let l of n.children){if(l.length>=o){let a=s(l,o);if(a)return a}if(o-=l.length,o<0)break}else if(n.isText()&&o<n.length){let l=Ce(n.text,o);if(l==o)return null;let a=xr(n.dom,o,l).getClientRects();for(let h=0;h<a.length;h++){let c=a[h];if(h==a.length-1||c.top<c.bottom&&c.left<c.right)return c}}return null}return s(t,i)}measureVisibleLineHeights(e){let t=[],{from:i,to:s}=e,n=this.view.contentDOM.clientWidth,o=n>Math.max(this.view.scrollDOM.clientWidth,this.minWidth)+1,l=-1,a=this.view.textDirection==_e.LTR,h=0,c=(u,p,y)=>{for(let O=0;O<u.children.length&&!(p>s);O++){let b=u.children[O],v=p+b.length,k=b.dom.getBoundingClientRect(),{height:T}=k;if(y&&!O&&(h+=k.top-y.top),b instanceof li)v>i&&c(b,p,k);else if(p>=i&&(h>0&&t.push(-h),t.push(T+h),h=0,o)){let C=b.dom.lastChild,Q=C?Tn(C):[];if(Q.length){let A=Q[Q.length-1],R=a?A.right-k.left:k.right-A.left;R>l&&(l=R,this.minWidth=n,this.minWidthFrom=p,this.minWidthTo=v)}}y&&O==u.children.length-1&&(h+=y.bottom-k.bottom),p=v+b.breakAfter}};return c(this.tile,0,null),t}textDirectionAt(e){let{tile:t}=this.tile.resolveBlock(e,1);return getComputedStyle(t.dom).direction=="rtl"?_e.RTL:_e.LTR}measureTextSize(){let e=this.tile.blockTiles(o=>{if(o.isLine()&&o.children.length&&o.length<=20){let l=0,a;for(let h of o.children){if(!h.isText()||/[^ -~]/.test(h.text))return;let c=Tn(h.dom);if(c.length!=1)return;l+=c[0].width,a=c[0].height}if(l)return{lineHeight:o.dom.getBoundingClientRect().height,charWidth:l/o.length,textHeight:a}}});if(e)return e;let t=document.createElement("div"),i,s,n;return t.className="cm-line",t.style.width="99999px",t.style.position="absolute",t.textContent="abc def ghi jkl mno pqr stu",this.view.observer.ignore(()=>{this.tile.dom.appendChild(t);let o=Tn(t.firstChild)[0];i=t.getBoundingClientRect().height,s=o&&o.width?o.width/27:7,n=o&&o.height?o.height:i,t.remove()}),{lineHeight:i,charWidth:s,textHeight:n}}computeBlockGapDeco(){let e=[],t=this.view.viewState;for(let i=0,s=0;;s++){let n=s==t.viewports.length?null:t.viewports[s],o=n?n.from-1:this.view.state.doc.length;if(o>i){let l=(t.lineBlockAt(o).bottom-t.lineBlockAt(i).top)/this.view.scaleY;e.push(K.replace({widget:new _r(l),block:!0,inclusive:!0,isBlockGap:!0}).range(i,o))}if(!n)break;i=n.to+1}return K.set(e)}updateDeco(){let e=1,t=this.view.state.facet(Gn).map(n=>(this.dynamicDecorationMap[e++]=typeof n=="function")?n(this.view):n),i=!1,s=this.view.state.facet(za).map((n,o)=>{let l=typeof n=="function";return l&&(i=!0),l?n(this.view):n});for(s.length&&(this.dynamicDecorationMap[e++]=i,t.push(ce.join(s))),this.decorations=[this.editContextFormatting,...t,this.computeBlockGapDeco(),this.view.viewState.lineGapDeco];e<this.decorations.length;)this.dynamicDecorationMap[e++]=!1;this.blockWrappers=this.view.state.facet(Op).map(n=>typeof n=="function"?n(this.view):n)}scrollIntoView(e){if(e.isSnapshot){let h=this.view.viewState.lineBlockAt(e.range.head);this.view.scrollDOM.scrollTop=h.top-e.yMargin,this.view.scrollDOM.scrollLeft=e.xMargin;return}for(let h of this.view.state.facet(_p))try{if(h(this.view,e.range,e))return!0}catch(c){tt(this.view.state,c,"scroll handler")}let{range:t}=e,i=this.coordsAt(t.head,t.assoc||(t.head>t.anchor?-1:1)),s;if(!i)return;!t.empty&&(s=this.coordsAt(t.anchor,t.anchor>t.head?-1:1))&&(i={left:Math.min(i.left,s.left),top:Math.min(i.top,s.top),right:Math.max(i.right,s.right),bottom:Math.max(i.bottom,s.bottom)});let n=ja(this.view),o={left:i.left-n.left,top:i.top-n.top,right:i.right+n.right,bottom:i.bottom+n.bottom},{offsetWidth:l,offsetHeight:a}=this.view.scrollDOM;if(E1(this.view.scrollDOM,o,t.head<t.anchor?-1:1,e.x,e.y,Math.max(Math.min(e.xMargin,l),-l),Math.max(Math.min(e.yMargin,a),-a),this.view.textDirection==_e.LTR),window.visualViewport&&window.innerHeight-window.visualViewport.height>1&&(i.top>window.visualViewport.offsetTop+window.visualViewport.height||i.bottom<window.visualViewport.offsetTop)){let h=this.view.docView.lineAt(t.head,1);if(h){let c=Ku(h.dom);h.dom.scrollIntoView({block:"nearest"}),Zu(c,!1)}}}lineHasWidget(e){let t=i=>i.isWidget()||i.children.some(t);return t(this.tile.resolveBlock(e,1).tile)}destroy(){ha(this.tile)}};function ha(r,e){let t=e==null?void 0:e.get(r);if(t!=1){t==null&&r.destroy();for(let i of r.children)ha(i,e)}}function G1(r){return r.node.nodeType==1&&r.node.firstChild&&(r.offset==0||r.node.childNodes[r.offset-1].contentEditable=="false")&&(r.offset==r.node.childNodes.length||r.node.childNodes[r.offset].contentEditable=="false")}function xp(r,e){let t=r.observer.selectionRange;if(!t.focusNode)return null;let i=ip(t.focusNode,t.focusOffset),s=sp(t.focusNode,t.focusOffset),n=i||s;if(s&&i&&s.node!=i.node){let l=Se.get(s.node);if(!l||l.isText()&&l.text!=s.node.nodeValue)n=s;else if(r.docView.lastCompositionAfterCursor){let a=Se.get(i.node);!a||a.isText()&&a.text!=i.node.nodeValue||(n=s)}}if(r.docView.lastCompositionAfterCursor=n!=i,!n)return null;let o=e-n.offset;return{from:o,to:o+n.node.nodeValue.length,node:n.node}}function X1(r,e,t){let i=xp(r,t);if(!i)return null;let{node:s,from:n,to:o}=i,l=s.nodeValue;if(/[\n\r]/.test(l)||r.state.doc.sliceString(i.from,i.to)!=l)return null;let a=e.invertedDesc;return{range:new Lt(a.mapPos(n),a.mapPos(o),n,o),text:s}}function J1(r,e){return r.nodeType!=1?0:(e&&r.childNodes[e-1].contentEditable=="false"?1:0)|(e<r.childNodes.length&&r.childNodes[e].contentEditable=="false"?2:0)}var Y1=class{constructor(){this.changes=[]}compareRange(e,t){Ms(e,t,this.changes)}comparePoint(e,t){Ms(e,t,this.changes)}boundChange(e){Ms(e,e,this.changes)}};function K1(r,e,t){let i=new Y1;return ce.compare(r,e,t,i),i.changes}var fa=class{constructor(){this.changes=[]}compareRange(e,t){Ms(e,t,this.changes)}comparePoint(){}boundChange(e){Ms(e,e,this.changes)}};function Z1(r,e,t){let i=new fa;return ce.compare(r,e,t,i),i.changes}function ev(r,e){for(let t=r;t&&t!=e;t=t.assignedSlot||t.parentNode)if(t.nodeType==1&&t.contentEditable=="false")return!0;return!1}function tv(r,e){let t=!1;return e&&r.iterChangedRanges((i,s)=>{i<e.to&&s>e.from&&(t=!0)}),t}var _r=class extends ai{constructor(e){super(),this.height=e}toDOM(){let e=document.createElement("div");return e.className="cm-gap",this.updateDOM(e),e}eq(e){return e.height==this.height}updateDOM(e){return e.style.height=this.height+"px",!0}get editable(){return!0}get estimatedHeight(){return this.height}ignoreEvent(){return!1}};function iv(r,e,t=1){let i=r.charCategorizer(e),s=r.doc.lineAt(e),n=e-s.from;if(s.length==0)return M.cursor(e);n==0?t=1:n==s.length&&(t=-1);let o=n,l=n;t<0?o=Ce(s.text,n,!1):l=Ce(s.text,n);let a=i(s.text.slice(o,l));for(;o>0;){let h=Ce(s.text,o,!1);if(i(s.text.slice(h,o))!=a)break;o=h}for(;l<s.length;){let h=Ce(s.text,l);if(i(s.text.slice(l,h))!=a)break;l=h}return M.undirectionalRange(o+s.from,l+s.from)}function sv(r,e,t,i,s){let n=Math.round((i-e.left)*r.defaultCharacterWidth);if(r.lineWrapping&&t.height>r.defaultLineHeight*1.5){let l=r.viewState.heightOracle.textHeight,a=Math.floor((s-t.top-(r.defaultLineHeight-l)*.5)/l);n+=a*r.viewState.heightOracle.lineLength}let o=r.state.sliceDoc(t.from,t.to);return t.from+lu(o,n,r.state.tabSize)}function ca(r,e,t){let i=r.lineBlockAt(e);if(Array.isArray(i.type)){let s;for(let n of i.type){if(n.from>e)break;if(!(n.to<e)){if(n.from<e&&n.to>e)return n;(!s||n.type==He.Text&&(s.type!=n.type||(t<0?n.from<e:n.to>e)))&&(s=n)}}return s||i}return i}function rv(r,e,t,i){let s=ca(r,e.head,e.assoc||-1),n=!i||s.type!=He.Text||!(r.lineWrapping||s.widgetLineBreaks)?null:r.coordsAtPos(e.assoc<0&&e.head>s.from?e.head-1:e.head);if(n){let o=r.dom.getBoundingClientRect(),l=r.textDirectionAt(s.from),a=r.posAtCoords({x:t==(l==_e.LTR)?o.right-1:o.left+1,y:(n.top+n.bottom)/2});if(a!=null)return M.cursor(a,t?-1:1)}return M.cursor(t?s.to:s.from,t?-1:1)}function wu(r,e,t,i){let s=r.state.doc.lineAt(e.head),n=r.bidiSpans(s),o=r.textDirectionAt(s.from);for(let l=e,a=null;;){let h=B1(s,n,o,l,t),c=ap;if(!h){if(s.number==(t?r.state.doc.lines:1))return l;c=`
`,s=r.state.doc.line(s.number+(t?1:-1)),n=r.bidiSpans(s),h=t?M.cursor(s.from,-1):M.cursor(s.to,1)}if(a){if(!a(c))return l}else{if(!i)return h;a=i(c)}l=h}}function nv(r,e,t){let i=r.state.charCategorizer(e),s=i(t);return n=>{let o=i(n);return s==be.Space&&(s=o),s==o}}function ov(r,e,t,i){let s=e.head,n=t?1:-1;if(s==(t?r.state.doc.length:0))return M.cursor(s,e.assoc);let o=e.goalColumn,l,a=r.contentDOM.getBoundingClientRect(),h=r.coordsAtPos(s,e.assoc||((e.empty?t:e.head==e.from)?1:-1)),c=r.documentTop;if(h)o==null&&(o=h.left-a.left),l=n<0?h.top:h.bottom;else{let O=r.viewState.lineBlockAt(s);o==null&&(o=Math.min(a.right-a.left,r.defaultCharacterWidth*(s-O.from))),l=(n<0?O.top:O.bottom)+c}let u=a.left+o,p=r.viewState.heightOracle.textHeight>>1,y=i??p;for(let O=0;;O+=p){let b=l+(y+O)*n,v=da(r,{x:u,y:b},!1,n);if(t?b>a.bottom:b<a.top)return M.cursor(v.pos,v.assoc);let k=r.coordsAtPos(v.pos,v.assoc),T=k?(k.top+k.bottom)/2:0;if(!k||(t?T>l:T<l))return M.cursor(v.pos,v.assoc,void 0,o)}}function yr(r,e,t){for(;;){let i=0;for(let s of r)s.between(e-1,e+1,(n,o,l)=>{if(e>n&&e<o){let a=i||t||(e-n<o-e?-1:1);e=a<0?n:o,i=a}});if(!i)return e}}function Sp(r,e){let t=null;for(let i=0;i<e.ranges.length;i++){let s=e.ranges[i],n=null;if(s.empty){let o=yr(r,s.from,0);o!=s.from&&(n=M.cursor(o,-1))}else{let o=yr(r,s.from,-1),l=yr(r,s.to,1);(o!=s.from||l!=s.to)&&(s.undirectional?n=M.undirectionalRange(s.from,s.to):n=M.range(s.from==s.anchor?o:l,s.from==s.head?o:l))}n&&(t||(t=e.ranges.slice()),t[i]=n)}return t?M.create(t,e.mainIndex):e}function zl(r,e,t){let i=yr(r.state.facet(Tr).map(s=>s(r)),t.from,e.head>t.from?-1:1);return i==t.from?t:M.cursor(i,i<t.from?1:-1)}var St=class{constructor(e,t){this.pos=e,this.assoc=t}};function da(r,e,t,i){let s=r.contentDOM.getBoundingClientRect(),n=s.top+r.viewState.paddingTop,{x:o,y:l}=e,a=l-n,h;for(;;){if(a<0)return new St(0,1);if(a>r.viewState.docHeight)return new St(r.state.doc.length,-1);if(h=r.elementAtHeight(a),i==null)break;if(h.type==He.Text){if(i<0?h.to<r.viewport.from:h.from>r.viewport.to)break;let p=r.docView.coordsAt(i<0?h.from:h.to,i>0?-1:1);if(p&&(i<0?p.top<=a+n:p.bottom>=a+n))break}let u=r.viewState.heightOracle.textHeight/2;a=i>0?h.bottom+u:h.top-u}if(r.viewport.from>=h.to||r.viewport.to<=h.from){if(t)return null;if(h.type==He.Text){let u=sv(r,s,h,o,l);return new St(u,u==h.from?1:-1)}}if(h.type!=He.Text)return a<(h.top+h.bottom)/2?new St(h.from,1):new St(h.to,-1);let c=r.docView.lineAt(h.from,2);return(!c||c.length!=h.length)&&(c=r.docView.lineAt(h.from,-2)),new ua(r,o,l,r.textDirectionAt(h.from)).scanTile(c,h.from)}var ua=class{constructor(e,t,i,s){this.view=e,this.x=t,this.y=i,this.baseDir=s,this.line=null,this.spans=null}bidiSpansAt(e){return(!this.line||this.line.from>e||this.line.to<e)&&(this.line=this.view.state.doc.lineAt(e),this.spans=this.view.bidiSpans(this.line)),this}baseDirAt(e,t){let{line:i,spans:s}=this.bidiSpansAt(e);return s[Tt.find(s,e-i.from,-1,t)].level==this.baseDir}dirAt(e,t){let{line:i,spans:s}=this.bidiSpansAt(e);return s[Tt.find(s,e-i.from,-1,t)].dir}bidiIn(e,t){let{spans:i,line:s}=this.bidiSpansAt(e);return i.length>1||i.length&&(i[0].level!=this.baseDir||i[0].to+s.from<t)}scan(e,t,i=!1){let s=0,n=e.length-1,o=new Set,l=this.bidiIn(e[0],e[n]),a,h,c=-1,u=1e9,p;e:for(;s<n;){let O=n-s,b=s+n>>1;t:if(o.has(b)){for(let T=1;T<O;T++){let C=b+T;if(C>=n&&(C-=O),!o.has(C)){b=C;break t}}break e}o.add(b);let v=t(b),k=0;if(v)for(let T=0;T<v.length;T++){let C=v[T];if(!(C.width==0&&v.length>1))if(C.bottom<this.y)(!a||a.bottom<C.bottom)&&(a=C),k=1;else if(C.top>this.y)(!h||h.top>C.top)&&(h=C),k=-1;else{let Q=C.left>this.x?this.x-C.left:C.right<this.x?this.x-C.right:0,A=Math.abs(Q);A<u&&(c=b,u=A,p=C),Q&&(k=Q<0==(this.baseDir==_e.LTR)?-1:1)}}k==-1&&(!l||this.baseDirAt(e[b],1))?n=b:k==1&&(!l||this.baseDirAt(e[b+1],-1))&&(s=b+1)}if(!p){if(!h&&!a)return{i:0,after:!1};let O=a&&(!h||this.y-a.bottom<h.top-this.y)?a:h;return this.y=(O.top+O.bottom)/2,this.scan(e,t,!0)}if(u&&!i){let{top:O,bottom:b}=p;if(a&&a.bottom>(O+O+b)/3)return this.y=a.bottom-1,this.scan(e,t,!0);if(h&&h.top<(O+b+b)/3)return this.y=h.top+1,this.scan(e,t,!0)}let y=(l?this.dirAt(e[c],1):this.baseDir)==_e.LTR;return{i:c,after:this.x>(p.left+p.right)/2==y}}scanText(e,t){let i=[];for(let n=0;n<e.length;n=Ce(e.text,n))i.push(t+n);i.push(t+e.length);let s=this.scan(i,n=>{let o=i[n]-t,l=i[n+1]-t;return xr(e.dom,o,l).getClientRects()});return s.after?new St(i[s.i+1],-1):new St(i[s.i],1)}scanTile(e,t){if(!e.length)return new St(t,1);if(e.children.length==1){let l=e.children[0];if(l.isText())return this.scanText(l,t);if(l.isComposite())return this.scanTile(l,t)}let i=[t];for(let l=0,a=t;l<e.children.length;l++)i.push(a+=e.children[l].length);let s=this.scan(i,l=>{let a=e.children[l];return a.flags&48?null:(a.dom.nodeType==1?a.dom:xr(a.dom,0,a.length)).getClientRects()}),n=e.children[s.i],o=i[s.i];return n.isText()?this.scanText(n,o):n.isComposite()?this.scanTile(n,o):s.after?new St(i[s.i+1],-1):new St(o,1)}},Ps="\uFFFF",pa=class{constructor(e,t){this.points=e,this.view=t,this.text="",this.lineSeparator=t.state.facet(pe.lineSeparator)}append(e){this.text+=e}lineBreak(){this.text+=Ps}readRange(e,t){if(!e)return this;let i=e.parentNode;for(let s=e;;){this.findPointBefore(i,s);let n=this.text.length;this.readNode(s);let o=Se.get(s),l=s.nextSibling;if(l==t){o!=null&&o.breakAfter&&!l&&i!=this.view.contentDOM&&this.lineBreak();break}let a=Se.get(l);(o&&a?o.breakAfter:(o?o.breakAfter:Nn(s))||Nn(l)&&(s.nodeName!="BR"||o!=null&&o.isWidget())&&this.text.length>n)&&!av(l,t)&&this.lineBreak(),s=l}return this.findPointBefore(i,t),this}readTextNode(e){let t=e.nodeValue;for(let i of this.points)i.node==e&&(i.pos=this.text.length+Math.min(i.offset,t.length));for(let i=0,s=this.lineSeparator?null:/\r\n?|\n/g;;){let n=-1,o=1,l;if(this.lineSeparator?(n=t.indexOf(this.lineSeparator,i),o=this.lineSeparator.length):(l=s.exec(t))&&(n=l.index,o=l[0].length),this.append(t.slice(i,n<0?t.length:n)),n<0)break;if(this.lineBreak(),o>1)for(let a of this.points)a.node==e&&a.pos>this.text.length&&(a.pos-=o-1);i=n+o}}readNode(e){let t=Se.get(e),i=t&&t.overrideDOMText;if(i!=null){this.findPointInside(e,i.length);for(let s=i.iter();!s.next().done;)s.lineBreak?this.lineBreak():this.append(s.value)}else e.nodeType==3?this.readTextNode(e):e.nodeName=="BR"?e.nextSibling&&this.lineBreak():e.nodeType==1&&this.readRange(e.firstChild,null)}findPointBefore(e,t){for(let i of this.points)i.node==e&&e.childNodes[i.offset]==t&&(i.pos=this.text.length)}findPointInside(e,t){for(let i of this.points)(e.nodeType==3?i.node==e:e.contains(i.node))&&(i.pos=this.text.length+(lv(e,i.node,i.offset)?t:0))}};function lv(r,e,t){for(;;){if(!e||t<hi(e))return!1;if(e==r)return!0;t=vi(e)+1,e=e.parentNode}}function av(r,e){let t;for(;!(r==e||!r);r=r.nextSibling){let i=Se.get(r);if(!(i!=null&&i.isWidget()))return!1;i&&(t||(t=[])).push(i)}if(t)for(let i of t){let s=i.overrideDOMText;if(s!=null&&s.length)return!1}return!0}var Bn=class{constructor(e,t){this.node=e,this.offset=t,this.pos=-1}},ma=class{constructor(e,t,i,s){this.typeOver=s,this.bounds=null,this.text="",this.domChanged=t>-1;let{impreciseHead:n,impreciseAnchor:o}=e.docView,l=e.state.selection;if(e.state.readOnly&&t>-1)this.newSel=null;else if(t>-1&&(this.bounds=Tp(e.docView.tile,t,i,0))){let a=n||o?[]:fv(e),h=new pa(a,e);h.readRange(this.bounds.startDOM,this.bounds.endDOM),this.text=h.text,this.newSel=cv(a,this.bounds.from)}else{let a=e.observer.selectionRange,h=n&&n.node==a.focusNode&&n.offset==a.focusOffset||!Yl(e.contentDOM,a.focusNode)?l.main.head:e.docView.posFromDOM(a.focusNode,a.focusOffset),c=o&&o.node==a.anchorNode&&o.offset==a.anchorOffset||!Yl(e.contentDOM,a.anchorNode)?l.main.anchor:e.docView.posFromDOM(a.anchorNode,a.anchorOffset),u=e.viewport;if(($.ios||$.chrome)&&h!=c&&Math.min(h,c)<=l.main.from&&Math.max(h,c)>=l.main.to&&(u.from>0||u.to<e.state.doc.length)){let p=Math.min(h,c),y=Math.max(h,c),O=u.from-p,b=u.to-y;(O==0||O==1||p==0)&&(b==0||b==-1||y==e.state.doc.length)&&(h=0,c=e.state.doc.length)}if(e.inputState.composing>-1&&l.ranges.length>1)this.newSel=l.replaceRange(M.range(c,h));else if(e.lineWrapping&&c==h&&!(l.main.empty&&l.main.head==h)&&e.inputState.lastTouchTime>Date.now()-100){let p=e.coordsAtPos(h,-1),y=0;p&&(y=e.inputState.lastTouchY<=p.bottom?-1:1),this.newSel=M.create([M.cursor(h,y)])}else this.newSel=M.single(c,h)}}};function Tp(r,e,t,i){if(r.isComposite()){let s=-1,n=-1,o=-1,l=-1;for(let a=0,h=i,c=i;a<r.children.length;a++){let u=r.children[a],p=h+u.length;if(h<e&&p>t)return Tp(u,e,t,h);if(p>=e&&s==-1&&(s=a,n=h),h>t&&u.dom.parentNode==r.dom){o=a,l=c;break}c=p,h=p+u.breakAfter}return{from:n,to:l<0?i+r.length:l,startDOM:(s?r.children[s-1].dom.nextSibling:null)||r.dom.firstChild,endDOM:o<r.children.length&&o>=0?r.children[o].dom:null}}else return r.isText()?{from:i,to:i+r.length,startDOM:r.dom,endDOM:r.dom.nextSibling}:null}function Pp(r,e){let t,{newSel:i}=e,{state:s}=r,n=s.selection.main,o=r.inputState.lastKeyTime>Date.now()-100?r.inputState.lastKeyCode:-1;if(e.bounds){let{from:l,to:a}=e.bounds,h=n.from,c=null;(o===8||$.android&&e.text.length<a-l)&&(h=n.to,c="end");let u=s.doc.sliceString(l,a,Ps),p,y;!n.empty&&n.from>=l&&n.to<=a&&(e.typeOver||u!=e.text)&&u.slice(0,n.from-l)==e.text.slice(0,n.from-l)&&u.slice(n.to-l)==e.text.slice(p=e.text.length-(u.length-(n.to-l)))?t={from:n.from,to:n.to,insert:oe.of(e.text.slice(n.from-l,p).split(Ps))}:(y=Cp(u,e.text,h-l,c))&&($.chrome&&o==13&&y.toB==y.from+2&&e.text.slice(y.from,y.toB)==Ps+Ps&&y.toB--,t={from:l+y.from,to:l+y.toA,insert:oe.of(e.text.slice(y.from,y.toB).split(Ps))})}else i&&(!r.hasFocus&&s.facet(oi)||$n(i,n))&&(i=null);if(!t&&!i)return!1;if(($.mac||$.android)&&t&&t.from==t.to&&t.from==n.head-1&&/^\. ?$/.test(t.insert.toString())&&r.contentDOM.getAttribute("autocorrect")=="off"?(i&&t.insert.length==2&&(i=M.single(i.main.anchor-1,i.main.head-1)),t={from:t.from,to:t.to,insert:oe.of([t.insert.toString().replace("."," ")])}):s.doc.lineAt(n.from).to<n.to&&r.docView.lineHasWidget(n.to)&&r.inputState.insertingTextAt>Date.now()-50?t={from:n.from,to:n.to,insert:s.toText(r.inputState.insertingText)}:$.chrome&&t&&t.from==t.to&&t.from==n.head&&t.insert.toString()==`
 `&&r.lineWrapping&&(i&&(i=M.single(i.main.anchor-1,i.main.head-1)),t={from:n.from,to:n.to,insert:oe.of([" "])}),t)return Ha(r,t,i,o);if(i&&!$n(i,n)){let l=!1,a="select";return r.inputState.lastSelectionTime>Date.now()-50&&(r.inputState.lastSelectionOrigin=="select"&&(l=!0),a=r.inputState.lastSelectionOrigin,a=="select.pointer"&&(i=Sp(s.facet(Tr).map(h=>h(r)),i))),r.dispatch({selection:i,scrollIntoView:l,userEvent:a}),!0}else return!1}function Ha(r,e,t,i=-1){if($.ios&&r.inputState.flushIOSKey(e))return!0;let s=r.state.selection.main;if($.android&&(e.to==s.to&&(e.from==s.from||e.from==s.from-1&&r.state.sliceDoc(e.from,s.from)==" ")&&e.insert.length==1&&e.insert.lines==2&&Ds(r.contentDOM,"Enter",13)||(e.from==s.from-1&&e.to==s.to&&e.insert.length==0||i==8&&e.insert.length<e.to-e.from&&e.to>s.head)&&Ds(r.contentDOM,"Backspace",8)||e.from==s.from&&e.to==s.to+1&&e.insert.length==0&&Ds(r.contentDOM,"Delete",46)))return!0;let n=e.insert.toString();r.inputState.composing>=0&&r.inputState.composing++;let o,l=()=>o||(o=hv(r,e,t));return r.state.facet(up).some(a=>a(r,e.from,e.to,n,l))||r.dispatch(l()),!0}function hv(r,e,t){let i,s=r.state,n=s.selection.main,o=-1;if(e.from==e.to&&e.from<n.from||e.from>n.to){let a=e.from<n.from?-1:1,h=a<0?n.from:n.to,c=yr(s.facet(Tr).map(u=>u(r)),h,a);e.from==c&&(o=c)}if(o>-1)i={changes:e,selection:M.cursor(e.from+e.insert.length,-1)};else if(e.from>=n.from&&e.to<=n.to&&e.to-e.from>=(n.to-n.from)/3&&(!t||t.main.empty&&t.main.from==e.from+e.insert.length)&&r.inputState.composing<0){let a=n.from<e.from?s.sliceDoc(n.from,e.from):"",h=n.to>e.to?s.sliceDoc(e.to,n.to):"";i=s.replaceSelection(r.state.toText(a+e.insert.sliceString(0,void 0,r.state.lineBreak)+h))}else{let a=s.changes(e),h=t&&t.main.to<=a.newLength?t.main:void 0;if(s.selection.ranges.length>1&&(r.inputState.composing>=0||r.inputState.compositionPendingChange)&&e.to<=n.to+10&&e.to>=n.to-10){let c=r.state.sliceDoc(e.from,e.to),u,p=t&&xp(r,t.main.head);if(p){let O=e.insert.length-(e.to-e.from);u={from:p.from,to:p.to-O}}else u=r.state.doc.lineAt(n.head);let y=n.to-e.to;i=s.changeByRange(O=>{if(O.from==n.from&&O.to==n.to)return{changes:a,range:h||O.map(a)};let b=O.to-y,v=b-c.length;if(r.state.sliceDoc(v,b)!=c||b>=u.from&&v<=u.to)return{range:O};let k=s.changes({from:v,to:b,insert:e.insert}),T=O.to-n.to;return{changes:k,range:h?M.range(Math.max(0,h.anchor+T),Math.max(0,h.head+T)):O.map(k)}})}else i={changes:a,selection:h&&s.selection.replaceRange(h)}}let l="input.type";return(r.composing||r.inputState.compositionPendingChange&&r.inputState.compositionEndedAt>Date.now()-50)&&(r.inputState.compositionPendingChange=!1,l+=".compose",r.inputState.compositionFirstChange&&(l+=".start",r.inputState.compositionFirstChange=!1)),s.update(i,{userEvent:l,scrollIntoView:!0})}function Cp(r,e,t,i){let s=Math.min(r.length,e.length),n=0;for(;n<s&&r.charCodeAt(n)==e.charCodeAt(n);)n++;if(n==s&&r.length==e.length)return null;let o=r.length,l=e.length;for(;o>0&&l>0&&r.charCodeAt(o-1)==e.charCodeAt(l-1);)o--,l--;if(i=="end"){let a=Math.max(0,n-Math.min(o,l));t-=o+a-n}if(o<n&&r.length<e.length){let a=t<=n&&t>=o?n-t:0;n-=a,l=n+(l-o),o=n}else if(l<n){let a=t<=n&&t>=l?n-t:0;n-=a,o=n+(o-l),l=n}return{from:n,toA:o,toB:l}}function fv(r){let e=[];if(r.root.activeElement!=r.contentDOM)return e;let{anchorNode:t,anchorOffset:i,focusNode:s,focusOffset:n}=r.observer.selectionRange;return t&&(e.push(new Bn(t,i)),(s!=t||n!=i)&&e.push(new Bn(s,n))),e}function cv(r,e){if(r.length==0)return null;let t=r[0].pos,i=r.length==2?r[1].pos:t;return t<0||i<0?null:t==i?M.create([M.cursor(i+e,-1)]):M.single(t+e,i+e)}function $n(r,e){return e.head==r.main.head&&e.anchor==r.main.anchor}var ga=class{setSelectionOrigin(e){this.lastSelectionOrigin=e,this.lastSelectionTime=Date.now()}constructor(e){this.view=e,this.lastKeyCode=0,this.lastKeyTime=0,this.touchActive=!1,this.lastTouchTime=0,this.lastTouchX=0,this.lastTouchY=0,this.lastFocusTime=0,this.lastScrollTop=0,this.lastScrollLeft=0,this.lastWheelEvent=0,this.pendingIOSKey=void 0,this.lastIOSMomentumScroll=0,this.tabFocusMode=-1,this.lastSelectionOrigin=null,this.lastSelectionTime=0,this.lastContextMenu=0,this.scrollHandlers=[],this.handlers=Object.create(null),this.composing=-1,this.compositionFirstChange=null,this.compositionEndedAt=0,this.compositionPendingKey=!1,this.compositionPendingChange=!1,this.insertingText="",this.insertingTextAt=0,this.mouseSelection=null,this.draggedContent=null,this.handleEvent=this.handleEvent.bind(this),this.notifiedFocused=e.hasFocus,$.safari&&e.contentDOM.addEventListener("input",()=>null),$.gecko&&Tv(e.contentDOM.ownerDocument)}handleEvent(e){!bv(this.view,e)||this.ignoreDuringComposition(e)||e.type=="keydown"&&this.keydown(e)||(this.view.updateState!=0?Promise.resolve().then(()=>this.runHandlers(e.type,e)):this.runHandlers(e.type,e))}runHandlers(e,t){let i=this.handlers[e];if(i){for(let s of i.observers)s(this.view,t);for(let s of i.handlers){if(t.defaultPrevented)break;if(s(this.view,t)){t.preventDefault();break}}}}ensureHandlers(e){let t=uv(e),i=this.handlers,s=this.view.contentDOM;for(let n in t)if(n!="scroll"){let o=!t[n].handlers.length,l=i[n];l&&o!=!l.handlers.length&&(s.removeEventListener(n,this.handleEvent),l=null),l||s.addEventListener(n,this.handleEvent,{passive:o})}for(let n in i)n!="scroll"&&!t[n]&&s.removeEventListener(n,this.handleEvent);this.handlers=t}keydown(e){if(this.lastKeyCode=e.keyCode,this.lastKeyTime=Date.now(),e.keyCode==9&&this.tabFocusMode>-1&&(!this.tabFocusMode||Date.now()<=this.tabFocusMode))return!0;if(this.tabFocusMode>0&&e.keyCode!=27&&Ap.indexOf(e.keyCode)<0&&(this.tabFocusMode=-1),$.android&&$.chrome&&!e.synthetic&&(e.keyCode==13||e.keyCode==8))return this.view.observer.delayAndroidKey(e.key,e.keyCode),!0;if($.ios&&!e.synthetic&&!e.altKey&&!e.metaKey&&(Ep.some(t=>t.keyCode==e.keyCode)&&!e.ctrlKey||pv.indexOf(e.key)>-1&&e.ctrlKey)){let t={ctrlKey:e.ctrlKey,altKey:e.altKey,metaKey:e.metaKey,shiftKey:e.shiftKey};t.shiftKey&&$.ios&&!/^(off|none)$/.test(this.view.contentDOM.autocapitalize)&&dv(this.view.win)&&(t.shiftKey=!1);let i=this.pendingIOSKey={key:e.key,keyCode:e.keyCode,mods:t};return setTimeout(()=>{this.pendingIOSKey==i&&this.flushIOSKey()},50),!0}return e.keyCode!=229&&this.view.observer.forceFlush(),!1}flushIOSKey(e){let t=this.pendingIOSKey;return!t||this.view.observer.pendingRecords().length||t.key=="Enter"&&e&&e.from<e.to&&/^\S+$/.test(e.insert.toString())?!1:(this.pendingIOSKey=void 0,Ds(this.view.contentDOM,t.key,t.keyCode,t.mods))}ignoreDuringComposition(e){return!/^key/.test(e.type)||e.synthetic?!1:this.composing>0?!0:$.safari&&!$.ios&&this.compositionPendingKey&&Date.now()-this.compositionEndedAt<100?(this.compositionPendingKey=!1,!0):!1}startMouseSelection(e){this.mouseSelection&&this.mouseSelection.destroy(),this.mouseSelection=e}update(e){this.view.observer.update(e),this.mouseSelection&&this.mouseSelection.update(e),this.draggedContent&&e.docChanged&&(this.draggedContent=this.draggedContent.map(e.changes)),e.transactions.length&&(this.lastKeyCode=this.lastSelectionTime=0)}destroy(){this.mouseSelection&&this.mouseSelection.destroy()}};function dv(r){return r.visualViewport?r.visualViewport.height*r.visualViewport.scale/r.document.documentElement.clientHeight<.85:!1}function ku(r,e){return(t,i)=>{try{return e.call(r,i,t)}catch(s){tt(t.state,s)}}}function uv(r){let e=Object.create(null);function t(i){return e[i]||(e[i]={observers:[],handlers:[]})}for(let i of r){let s=i.spec,n=s&&s.plugin.domEventHandlers,o=s&&s.plugin.domEventObservers;if(n)for(let l in n){let a=n[l];a&&t(l).handlers.push(ku(i.value,a))}if(o)for(let l in o){let a=o[l];a&&t(l).observers.push(ku(i.value,a))}}for(let i in Qt)t(i).handlers.push(Qt[i]);for(let i in it)t(i).observers.push(it[i]);return e}var Ep=[{key:"Backspace",keyCode:8,inputType:"deleteContentBackward"},{key:"Enter",keyCode:13,inputType:"insertParagraph"},{key:"Enter",keyCode:13,inputType:"insertLineBreak"},{key:"Delete",keyCode:46,inputType:"deleteContentForward"}],pv="dthko",Ap=[16,17,18,20,91,92,224,225],bn=6;function On(r){return Math.max(0,r)*.7+8}function mv(r,e){return Math.max(Math.abs(r.clientX-e.clientX),Math.abs(r.clientY-e.clientY))}var _a=class{constructor(e,t,i,s){this.view=e,this.startEvent=t,this.style=i,this.mustSelect=s,this.scrollSpeed={x:0,y:0},this.scrolling=-1,this.lastEvent=t,this.scrollParents=Yu(e.contentDOM),this.atoms=e.state.facet(Tr).map(o=>o(e));let n=e.contentDOM.ownerDocument;n.addEventListener("mousemove",this.move=this.move.bind(this)),n.addEventListener("mouseup",this.up=this.up.bind(this)),this.extend=t.shiftKey,this.multiple=e.state.facet(pe.allowMultipleSelections)&&gv(e,t),this.dragging=yv(e,t)&&Dp(t)==1?null:!1}start(e){this.dragging===!1&&this.select(e)}move(e){if(e.buttons==0)return this.destroy();if(this.dragging||this.dragging==null&&mv(this.startEvent,e)<10)return;this.select(this.lastEvent=e);let t=0,i=0,s=0,n=0,o=this.view.win.innerWidth,l=this.view.win.innerHeight;this.scrollParents.x&&({left:s,right:o}=this.scrollParents.x.getBoundingClientRect()),this.scrollParents.y&&({top:n,bottom:l}=this.scrollParents.y.getBoundingClientRect());let a=ja(this.view);e.clientX-a.left<=s+bn?t=-On(s-e.clientX):e.clientX+a.right>=o-bn&&(t=On(e.clientX-o)),e.clientY-a.top<=n+bn?i=-On(n-e.clientY):e.clientY+a.bottom>=l-bn&&(i=On(e.clientY-l)),this.setScrollSpeed(t,i)}up(e){this.dragging==null&&this.select(this.lastEvent),this.dragging||e.preventDefault(),this.destroy()}destroy(){this.setScrollSpeed(0,0);let e=this.view.contentDOM.ownerDocument;e.removeEventListener("mousemove",this.move),e.removeEventListener("mouseup",this.up),this.view.inputState.mouseSelection=this.view.inputState.draggedContent=null}setScrollSpeed(e,t){this.scrollSpeed={x:e,y:t},e||t?this.scrolling<0&&(this.scrolling=setInterval(()=>this.scroll(),50)):this.scrolling>-1&&(clearInterval(this.scrolling),this.scrolling=-1)}scroll(){let{x:e,y:t}=this.scrollSpeed;e&&this.scrollParents.x&&(this.scrollParents.x.scrollLeft+=e,e=0),t&&this.scrollParents.y&&(this.scrollParents.y.scrollTop+=t,t=0),(e||t)&&this.view.win.scrollBy(e,t),this.dragging===!1&&this.select(this.lastEvent)}select(e){let{view:t}=this,i=Sp(this.atoms,this.style.get(e,this.extend,this.multiple));(this.mustSelect||!i.eq(t.state.selection,this.dragging===!1))&&this.view.dispatch({selection:i,userEvent:"select.pointer"}),this.mustSelect=!1}update(e){e.transactions.some(t=>t.isUserEvent("input.type"))?this.destroy():this.style.update(e)&&setTimeout(()=>this.select(this.lastEvent),20)}};function gv(r,e){let t=r.state.facet(hp);return t.length?t[0](e):$.mac?e.metaKey:e.ctrlKey}function _v(r,e){let t=r.state.facet(fp);return t.length?t[0](e):$.mac?!e.altKey:!e.ctrlKey}function yv(r,e){let{main:t}=r.state.selection;if(t.empty)return!1;let i=kr(r.root);if(!i||i.rangeCount==0)return!0;let s=i.getRangeAt(0).getClientRects();for(let n=0;n<s.length;n++){let o=s[n];if(o.left<=e.clientX&&o.right>=e.clientX&&o.top<=e.clientY&&o.bottom>=e.clientY)return!0}return!1}function bv(r,e){if(!e.bubbles)return!0;if(e.defaultPrevented)return!1;for(let t=e.target,i;t!=r.contentDOM;t=t.parentNode)if(!t||t.nodeType==11||(i=Se.get(t))&&i.isWidget()&&!i.isHidden&&i.widget.ignoreEvent(e))return!1;return!0}var Qt=Object.create(null),it=Object.create(null),Rp=$.ie&&$.ie_version<15||$.ios&&$.webkit_version<604;function Ov(r){let e=r.dom.parentNode;if(!e)return;let t=e.appendChild(document.createElement("textarea"));t.style.cssText="position: fixed; left: -10000px; top: 10px",t.focus(),setTimeout(()=>{r.focus(),t.remove(),Mp(r,t.value)},50)}function Xn(r,e,t){for(let i of r.facet(e))t=i(t,r);return t}function Mp(r,e){e=Xn(r.state,$a,e);let{state:t}=r,i,s=1,n=t.toText(e),o=n.lines==t.selection.ranges.length;if(ya!=null&&t.selection.ranges.every(a=>a.empty)&&ya==n.toString()){let a=-1;i=t.changeByRange(h=>{let c=t.doc.lineAt(h.from);if(c.from==a)return{range:h};a=c.from;let u=t.toText((o?n.line(s++).text:e)+t.lineBreak);return{changes:{from:c.from,insert:u},range:M.cursor(h.from+u.length,-1)}})}else o?i=t.changeByRange(a=>{let h=n.line(s++);return{changes:{from:a.from,to:a.to,insert:h.text},range:M.cursor(a.from+h.length,-1)}}):i=t.replaceSelection(n);r.dispatch(i,{userEvent:"input.paste",scrollIntoView:!0})}it.scroll=r=>{let e=r.inputState;e.lastScrollTop=r.scrollDOM.scrollTop,e.lastScrollLeft=r.scrollDOM.scrollLeft,$.ios&&!e.touchActive&&(e.lastIOSMomentumScroll=Date.now())};it.wheel=it.mousewheel=r=>{r.inputState.lastWheelEvent=Date.now()};Qt.keydown=(r,e)=>(r.inputState.setSelectionOrigin("select"),e.keyCode==27&&r.inputState.tabFocusMode!=0&&(r.inputState.tabFocusMode=Date.now()+2e3),!1);it.touchstart=(r,e)=>{let t=r.inputState,i=e.targetTouches[0];t.touchActive=!0,t.lastTouchTime=Date.now(),i&&(t.lastTouchX=i.clientX,t.lastTouchY=i.clientY),t.setSelectionOrigin("select.pointer")};it.touchmove=r=>{r.inputState.setSelectionOrigin("select.pointer")};it.touchend=(r,e)=>{r.inputState.touchActive=!1};Qt.mousedown=(r,e)=>{if(r.observer.flush(),r.inputState.lastTouchTime>Date.now()-2e3)return!1;let t=null;for(let i of r.state.facet(cp))if(t=i(r,e),t)break;if(!t&&e.button==0&&(t=wv(r,e)),t){let i=!r.hasFocus;r.inputState.startMouseSelection(new _a(r,e,t,i)),i&&r.observer.ignore(()=>{ep(r.contentDOM);let n=r.root.activeElement;n&&!n.contains(r.contentDOM)&&n.blur()});let s=r.inputState.mouseSelection;if(s)return s.start(e),s.dragging===!1}else r.inputState.setSelectionOrigin("select.pointer");return!1};function xu(r,e,t,i){if(i==1)return M.cursor(e,t);if(i==2)return iv(r.state,e,t);{let s=r.docView.lineAt(e,t),n=r.state.doc.lineAt(s?s.posAtEnd:e),o=s?s.posAtStart:n.from,l=s?s.posAtEnd:n.to;return l<r.state.doc.length&&l==n.to&&l++,M.undirectionalRange(o,l)}}var vv=$.ie&&$.ie_version<=11,Su=null,Tu=0,Pu=0;function Dp(r){if(!vv)return r.detail;let e=Su,t=Pu;return Su=r,Pu=Date.now(),Tu=!e||t>Date.now()-400&&Math.abs(e.clientX-r.clientX)<2&&Math.abs(e.clientY-r.clientY)<2?(Tu+1)%3:1}function wv(r,e){let t=r.posAndSideAtCoords({x:e.clientX,y:e.clientY},!1),i=Dp(e),s=r.state.selection;return{update(n){n.docChanged&&(t.pos=n.changes.mapPos(t.pos),s=s.map(n.changes))},get(n,o,l){let a=r.posAndSideAtCoords({x:n.clientX,y:n.clientY},!1),h,c=xu(r,a.pos,a.assoc,i);if(t.pos!=a.pos&&!o){let u=xu(r,t.pos,t.assoc,i),p=Math.min(u.from,c.from),y=Math.max(u.to,c.to);c=p<c.from?M.range(p,y,c.assoc):M.range(y,p,c.assoc)}return o?s.replaceRange(s.main.extend(c.from,c.to,c.assoc)):l&&i==1&&s.ranges.length>1&&(h=kv(s,a.pos))?h:l?s.addRange(c):M.create([c])}}}function kv(r,e){for(let t=0;t<r.ranges.length;t++){let{from:i,to:s}=r.ranges[t];if(i<=e&&s>=e)return M.create(r.ranges.slice(0,t).concat(r.ranges.slice(t+1)),r.mainIndex==t?0:r.mainIndex-(r.mainIndex>t?1:0))}return null}Qt.dragstart=(r,e)=>{let{selection:{main:t}}=r.state;if(e.target.draggable){let s=r.docView.tile.nearest(e.target);if(s&&s.isWidget()){let n=s.posAtStart,o=n+s.length;(n>=t.to||o<=t.from)&&(t=M.undirectionalRange(n,o))}}let{inputState:i}=r;return i.mouseSelection&&(i.mouseSelection.dragging=!0),i.draggedContent=t,e.dataTransfer&&(e.dataTransfer.setData("Text",Xn(r.state,Fa,r.state.sliceDoc(t.from,t.to))),e.dataTransfer.effectAllowed="copyMove"),!1};Qt.dragend=r=>(r.inputState.draggedContent=null,!1);function Cu(r,e,t,i){if(t=Xn(r.state,$a,t),!t)return;let s=r.posAtCoords({x:e.clientX,y:e.clientY},!1),{draggedContent:n}=r.inputState,o=i&&n&&_v(r,e)?{from:n.from,to:n.to}:null,l={from:s,insert:t},a=r.state.changes(o?[o,l]:l);r.focus(),r.dispatch({changes:a,selection:{anchor:a.mapPos(s,-1),head:a.mapPos(s,1)},userEvent:o?"move.drop":"input.drop"}),r.inputState.draggedContent=null}Qt.drop=(r,e)=>{if(!e.dataTransfer)return!1;if(r.state.readOnly)return!0;let t=e.dataTransfer.files;if(t&&t.length){let i=Array(t.length),s=0,n=()=>{++s==t.length&&Cu(r,e,i.filter(o=>o!=null).join(r.state.lineBreak),!1)};for(let o=0;o<t.length;o++){let l=new FileReader;l.onerror=n,l.onload=()=>{/[\x00-\x08\x0e-\x1f]{2}/.test(l.result)||(i[o]=l.result),n()},l.readAsText(t[o])}return!0}else{let i=e.dataTransfer.getData("Text");if(i)return Cu(r,e,i,!0),!0}return!1};Qt.paste=(r,e)=>{if(r.state.readOnly)return!0;r.observer.flush();let t=Rp?null:e.clipboardData;return t?(Mp(r,t.getData("text/plain")||t.getData("text/uri-list")),!0):(Ov(r),!1)};function xv(r,e){let t=r.dom.parentNode;if(!t)return;let i=t.appendChild(document.createElement("textarea"));i.style.cssText="position: fixed; left: -10000px; top: 10px",i.value=e,i.focus(),i.selectionEnd=e.length,i.selectionStart=0,setTimeout(()=>{i.remove(),r.focus()},50)}function Sv(r){let e=[],t=[],i=!1;for(let s of r.selection.ranges)s.empty||(e.push(r.sliceDoc(s.from,s.to)),t.push(s));if(!e.length){let s=-1;for(let{from:n}of r.selection.ranges){let o=r.doc.lineAt(n);o.number>s&&(e.push(o.text),t.push({from:o.from,to:Math.min(r.doc.length,o.to+1)})),s=o.number}i=!0}return{text:Xn(r,Fa,e.join(r.lineBreak)),ranges:t,linewise:i}}var ya=null;Qt.copy=Qt.cut=(r,e)=>{if(!ur(r.contentDOM,r.observer.selectionRange))return!1;let{text:t,ranges:i,linewise:s}=Sv(r.state);if(!t&&!s)return!1;ya=s?t:null,e.type=="cut"&&!r.state.readOnly&&r.dispatch({changes:i,scrollIntoView:!0,userEvent:"delete.cut"});let n=Rp?null:e.clipboardData;return n?(n.clearData(),n.setData("text/plain",t),!0):(xv(r,t),!1)};var Np=lt.define();function Ip(r,e){let t=[];for(let i of r.facet(pp)){let s=i(r,e);s&&t.push(s)}return t.length?r.update({effects:t,annotations:Np.of(!0)}):null}function Lp(r){setTimeout(()=>{let e=r.hasFocus;if(e!=r.inputState.notifiedFocused){let t=Ip(r.state,e);t?r.dispatch(t):r.update([])}},10)}it.focus=r=>{r.inputState.lastFocusTime=Date.now(),!r.scrollDOM.scrollTop&&(r.inputState.lastScrollTop||r.inputState.lastScrollLeft)&&(r.scrollDOM.scrollTop=r.inputState.lastScrollTop,r.scrollDOM.scrollLeft=r.inputState.lastScrollLeft),Lp(r)};it.blur=r=>{r.observer.clearSelectionRange(),Lp(r)};it.compositionstart=it.compositionupdate=r=>{if(!r.observer.editContext&&(r.inputState.compositionFirstChange==null&&(r.inputState.compositionFirstChange=!0),r.inputState.composing<0)){let{main:e}=r.state.selection;!e.empty&&r.lineBlockAt(e.from).from!=r.lineBlockAt(e.to).from&&r.dispatch({changes:r.state.selection.ranges.filter(t=>!t.empty).map(t=>({from:t.from,to:t.to})),userEvent:"input"}),r.inputState.composing=0}};it.compositionend=r=>{r.observer.editContext||(r.inputState.composing=-1,r.inputState.compositionEndedAt=Date.now(),r.inputState.compositionPendingKey=!0,r.inputState.compositionPendingChange=r.observer.pendingRecords().length>0,r.inputState.compositionFirstChange=null,$.chrome&&$.android?r.observer.flushSoon():r.inputState.compositionPendingChange?Promise.resolve().then(()=>r.observer.flush()):setTimeout(()=>{r.inputState.composing<0&&r.docView.hasComposition&&r.update([])},50))};it.contextmenu=r=>{r.inputState.lastContextMenu=Date.now()};Qt.beforeinput=(r,e)=>{var t,i;if((e.inputType=="insertText"||e.inputType=="insertCompositionText")&&(r.inputState.insertingText=e.data,r.inputState.insertingTextAt=Date.now()),e.inputType=="insertReplacementText"&&r.observer.editContext){let n=(t=e.dataTransfer)===null||t===void 0?void 0:t.getData("text/plain"),o=e.getTargetRanges();if(n&&o.length){let l=o[0],a=r.posAtDOM(l.startContainer,l.startOffset),h=r.posAtDOM(l.endContainer,l.endOffset);return Ha(r,{from:a,to:h,insert:r.state.toText(n)},null),!0}}let s;if($.chrome&&$.android&&(s=Ep.find(n=>n.inputType==e.inputType))&&(r.observer.delayAndroidKey(s.key,s.keyCode),s.key=="Backspace"||s.key=="Delete")){let n=((i=window.visualViewport)===null||i===void 0?void 0:i.height)||0;setTimeout(()=>{var o;(((o=window.visualViewport)===null||o===void 0?void 0:o.height)||0)>n+10&&r.hasFocus&&(r.contentDOM.blur(),r.focus())},100)}return $.ios&&e.inputType=="deleteContentForward"&&r.observer.flushSoon(),$.safari&&e.inputType=="insertText"&&r.inputState.composing>=0&&setTimeout(()=>it.compositionend(r,e),20),!1};var Eu=new Set;function Tv(r){Eu.has(r)||(Eu.add(r),r.addEventListener("copy",()=>{}),r.addEventListener("cut",()=>{}))}var Au=["pre-wrap","normal","pre-line","break-spaces"],qs=!1;function Ru(){qs=!1}var ba=class{constructor(e){this.lineWrapping=e,this.doc=oe.empty,this.heightSamples={},this.lineHeight=14,this.charWidth=7,this.textHeight=14,this.lineLength=30}heightForGap(e,t){let i=this.doc.lineAt(t).number-this.doc.lineAt(e).number+1;return this.lineWrapping&&(i+=Math.max(0,Math.ceil((t-e-i*this.lineLength*.5)/this.lineLength))),this.lineHeight*i}heightForLine(e){return this.lineWrapping?(1+Math.max(0,Math.ceil((e-this.lineLength)/Math.max(1,this.lineLength-5))))*this.lineHeight:this.lineHeight}setDoc(e){return this.doc=e,this}mustRefreshForWrapping(e){return Au.indexOf(e)>-1!=this.lineWrapping}mustRefreshForHeights(e){let t=!1;for(let i=0;i<e.length;i++){let s=e[i];s<0?i++:this.heightSamples[Math.floor(s*10)]||(t=!0,this.heightSamples[Math.floor(s*10)]=!0)}return t}refresh(e,t,i,s,n,o){let l=Au.indexOf(e)>-1,a=Math.abs(t-this.lineHeight)>.3||this.lineWrapping!=l;if(this.lineWrapping=l,this.lineHeight=t,this.charWidth=i,this.textHeight=s,this.lineLength=n,a){this.heightSamples={};for(let h=0;h<o.length;h++){let c=o[h];c<0?h++:this.heightSamples[Math.floor(c*10)]=!0}}return a}},Oa=class{constructor(e,t){this.from=e,this.heights=t,this.index=0}get more(){return this.index<this.heights.length}},It=class r{constructor(e,t,i,s,n){this.from=e,this.length=t,this.top=i,this.height=s,this._content=n}get type(){return typeof this._content=="number"?He.Text:Array.isArray(this._content)?this._content:this._content.type}get to(){return this.from+this.length}get bottom(){return this.top+this.height}get widget(){return this._content instanceof Ji?this._content.widget:null}get widgetLineBreaks(){return typeof this._content=="number"?this._content:0}join(e){let t=(Array.isArray(this._content)?this._content:[this]).concat(Array.isArray(e._content)?e._content:[e]);return new r(this.from,this.length+e.length,this.top,this.height+e.height,t)}},ke=function(r){return r[r.ByPos=0]="ByPos",r[r.ByHeight=1]="ByHeight",r[r.ByPosNoHeight=2]="ByPosNoHeight",r}(ke||(ke={})),Pn=.001,dt=class r{constructor(e,t,i=2){this.length=e,this.height=t,this.flags=i}get outdated(){return(this.flags&2)>0}set outdated(e){this.flags=(e?2:0)|this.flags&-3}setHeight(e){this.height!=e&&(Math.abs(this.height-e)>Pn&&(qs=!0),this.height=e)}replace(e,t,i){return r.of(i)}decomposeLeft(e,t){t.push(this)}decomposeRight(e,t){t.push(this)}applyChanges(e,t,i,s){let n=this,o=i.doc;for(let l=s.length-1;l>=0;l--){let{fromA:a,toA:h,fromB:c,toB:u}=s[l],p=n.lineAt(a,ke.ByPosNoHeight,i.setDoc(t),0,0),y=p.to>=h?p:n.lineAt(h,ke.ByPosNoHeight,i,0,0);for(u+=y.to-h,h=y.to;l>0&&p.from<=s[l-1].toA;)a=s[l-1].fromA,c=s[l-1].fromB,l--,a<p.from&&(p=n.lineAt(a,ke.ByPosNoHeight,i,0,0));c+=p.from-a,a=p.from;let O=wa.build(i.setDoc(o),e,c,u);n=Fn(n,n.replace(a,h,O))}return n.updateHeight(i,0)}static empty(){return new xt(0,0,0)}static of(e){if(e.length==1)return e[0];let t=0,i=e.length,s=0,n=0;for(;;)if(t==i)if(s>n*2){let l=e[t-1];l.break?e.splice(--t,1,l.left,null,l.right):e.splice(--t,1,l.left,l.right),i+=1+l.break,s-=l.size}else if(n>s*2){let l=e[i];l.break?e.splice(i,1,l.left,null,l.right):e.splice(i,1,l.left,l.right),i+=2+l.break,n-=l.size}else break;else if(s<n){let l=e[t++];l&&(s+=l.size)}else{let l=e[--i];l&&(n+=l.size)}let o=!1;return e[t-1]==null?(o=!0,t--):e[t]==null&&(o=!0,i++),new va(r.of(e.slice(0,t)),o,r.of(e.slice(i)))}};function Fn(r,e){return r==e?r:(r.constructor!=e.constructor&&(qs=!0),e)}dt.prototype.size=1;var Pv=K.replace({}),Wn=class extends dt{constructor(e,t,i){super(e,t),this.deco=i,this.spaceAbove=0}mainBlock(e,t){return new It(t,this.length,e+this.spaceAbove,this.height-this.spaceAbove,this.deco||0)}blockAt(e,t,i,s){return this.spaceAbove&&e<i+this.spaceAbove?new It(s,0,i,this.spaceAbove,Pv):this.mainBlock(i,s)}lineAt(e,t,i,s,n){let o=this.mainBlock(s,n);return this.spaceAbove?this.blockAt(0,i,s,n).join(o):o}forEachLine(e,t,i,s,n,o){e<=n+this.length&&t>=n&&o(this.lineAt(0,ke.ByPos,i,s,n))}setMeasuredHeight(e){let t=e.heights[e.index++];t<0?(this.spaceAbove=-t,t=e.heights[e.index++]):this.spaceAbove=0,this.setHeight(t)}updateHeight(e,t=0,i=!1,s){return s&&s.from<=t&&s.more&&this.setMeasuredHeight(s),this.outdated=!1,this}toString(){return`block(${this.length})`}},xt=class r extends Wn{constructor(e,t,i){super(e,t,null),this.collapsed=0,this.widgetHeight=0,this.breaks=0,this.spaceAbove=i}mainBlock(e,t){return new It(t,this.length,e+this.spaceAbove,this.height-this.spaceAbove,this.breaks)}replace(e,t,i){let s=i[0];return i.length==1&&(s instanceof r||s instanceof Oi&&s.flags&4)&&Math.abs(this.length-s.length)<10?(s instanceof Oi?s=new r(s.length,this.height,this.spaceAbove):s.height=this.height,this.outdated||(s.outdated=!1),s):dt.of(i)}updateHeight(e,t=0,i=!1,s){return s&&s.from<=t&&s.more?this.setMeasuredHeight(s):(i||this.outdated)&&(this.spaceAbove=0,this.setHeight(Math.max(this.widgetHeight,e.heightForLine(this.length-this.collapsed))+this.breaks*e.lineHeight)),this.outdated=!1,this}toString(){return`line(${this.length}${this.collapsed?-this.collapsed:""}${this.widgetHeight?":"+this.widgetHeight:""})`}},Oi=class r extends dt{constructor(e){super(e,0)}heightMetrics(e,t){let i=e.doc.lineAt(t).number,s=e.doc.lineAt(t+this.length).number,n=s-i+1,o,l=0;if(e.lineWrapping){let a=Math.min(this.height,e.lineHeight*n);o=a/n,this.length>n+1&&(l=(this.height-a)/(this.length-n-1))}else o=this.height/n;return{firstLine:i,lastLine:s,perLine:o,perChar:l}}blockAt(e,t,i,s){let{firstLine:n,lastLine:o,perLine:l,perChar:a}=this.heightMetrics(t,s);if(t.lineWrapping){let h=s+(e<t.lineHeight?0:Math.round(Math.max(0,Math.min(1,(e-i)/this.height))*this.length)),c=t.doc.lineAt(h),u=l+c.length*a,p=Math.max(i,e-u/2);return new It(c.from,c.length,p,u,0)}else{let h=Math.max(0,Math.min(o-n,Math.floor((e-i)/l))),{from:c,length:u}=t.doc.line(n+h);return new It(c,u,i+l*h,l,0)}}lineAt(e,t,i,s,n){if(t==ke.ByHeight)return this.blockAt(e,i,s,n);if(t==ke.ByPosNoHeight){let{from:y,to:O}=i.doc.lineAt(e);return new It(y,O-y,0,0,0)}let{firstLine:o,perLine:l,perChar:a}=this.heightMetrics(i,n),h=i.doc.lineAt(e),c=l+h.length*a,u=h.number-o,p=s+l*u+a*(h.from-n-u);return new It(h.from,h.length,Math.max(s,Math.min(p,s+this.height-c)),c,0)}forEachLine(e,t,i,s,n,o){e=Math.max(e,n),t=Math.min(t,n+this.length);let{firstLine:l,perLine:a,perChar:h}=this.heightMetrics(i,n);for(let c=e,u=s;c<=t;){let p=i.doc.lineAt(c);if(c==e){let O=p.number-l;u+=a*O+h*(e-n-O)}let y=a+h*p.length;o(new It(p.from,p.length,u,y,0)),u+=y,c=p.to+1}}replace(e,t,i){let s=this.length-t;if(s>0){let n=i[i.length-1];n instanceof r?i[i.length-1]=new r(n.length+s):i.push(null,new r(s-1))}if(e>0){let n=i[0];n instanceof r?i[0]=new r(e+n.length):i.unshift(new r(e-1),null)}return dt.of(i)}decomposeLeft(e,t){t.push(new r(e-1),null)}decomposeRight(e,t){t.push(null,new r(this.length-e-1))}updateHeight(e,t=0,i=!1,s){let n=t+this.length;if(s&&s.from<=t+this.length&&s.more){let o=[],l=Math.max(t,s.from),a=-1;for(s.from>t&&o.push(new r(s.from-t-1).updateHeight(e,t));l<=n&&s.more;){let c=e.doc.lineAt(l).length;o.length&&o.push(null);let u=s.heights[s.index++],p=0;u<0&&(p=-u,u=s.heights[s.index++]),a==-1?a=u:Math.abs(u-a)>=Pn&&(a=-2);let y=new xt(c,u,p);y.outdated=!1,o.push(y),l+=c+1}l<=n&&o.push(null,new r(n-l).updateHeight(e,l));let h=dt.of(o);return(a<0||Math.abs(h.height-this.height)>=Pn||Math.abs(a-this.heightMetrics(e,t).perLine)>=Pn)&&(qs=!0),Fn(this,h)}else(i||this.outdated)&&(this.setHeight(e.heightForGap(t,t+this.length)),this.outdated=!1);return this}toString(){return`gap(${this.length})`}},va=class extends dt{constructor(e,t,i){super(e.length+(t?1:0)+i.length,e.height+i.height,(t?1:0)|(e.outdated||i.outdated?2:0)),this.left=e,this.right=i,this.size=e.size+i.size}get break(){return this.flags&1}blockAt(e,t,i,s){let n=i+this.left.height;return e<n?this.left.blockAt(e,t,i,s):this.right.blockAt(e,t,n,s+this.left.length+this.break)}lineAt(e,t,i,s,n){let o=s+this.left.height,l=n+this.left.length+this.break,a=t==ke.ByHeight?e<o:e<l,h=a?this.left.lineAt(e,t,i,s,n):this.right.lineAt(e,t,i,o,l);if(this.break||(a?h.to<l:h.from>l))return h;let c=t==ke.ByPosNoHeight?ke.ByPosNoHeight:ke.ByPos;return a?h.join(this.right.lineAt(l,c,i,o,l)):this.left.lineAt(l,c,i,s,n).join(h)}forEachLine(e,t,i,s,n,o){let l=s+this.left.height,a=n+this.left.length+this.break;if(this.break)e<a&&this.left.forEachLine(e,t,i,s,n,o),t>=a&&this.right.forEachLine(e,t,i,l,a,o);else{let h=this.lineAt(a,ke.ByPos,i,s,n);e<h.from&&this.left.forEachLine(e,Math.min(t,h.from-1),i,s,n,o),h.to>=e&&h.from<=t&&o(h),t>h.to&&this.right.forEachLine(Math.max(e,h.to+1),t,i,l,a,o)}}replace(e,t,i){let s=this.left.length+this.break;if(t<s)return this.balanced(this.left.replace(e,t,i),this.right);if(e>this.left.length)return this.balanced(this.left,this.right.replace(e-s,t-s,i));let n=[];e>0&&this.decomposeLeft(e,n);let o=n.length;for(let l of i)n.push(l);if(e>0&&Mu(n,o-1),t<this.length){let l=n.length;this.decomposeRight(t,n),Mu(n,l)}return dt.of(n)}decomposeLeft(e,t){let i=this.left.length;if(e<=i)return this.left.decomposeLeft(e,t);t.push(this.left),this.break&&(i++,e>=i&&t.push(null)),e>i&&this.right.decomposeLeft(e-i,t)}decomposeRight(e,t){let i=this.left.length,s=i+this.break;if(e>=s)return this.right.decomposeRight(e-s,t);e<i&&this.left.decomposeRight(e,t),this.break&&e<s&&t.push(null),t.push(this.right)}balanced(e,t){return e.size>2*t.size||t.size>2*e.size?dt.of(this.break?[e,null,t]:[e,t]):(this.left=Fn(this.left,e),this.right=Fn(this.right,t),this.setHeight(e.height+t.height),this.outdated=e.outdated||t.outdated,this.size=e.size+t.size,this.length=e.length+this.break+t.length,this)}updateHeight(e,t=0,i=!1,s){let{left:n,right:o}=this,l=t+n.length+this.break,a=null;return s&&s.from<=t+n.length&&s.more?a=n=n.updateHeight(e,t,i,s):n.updateHeight(e,t,i),s&&s.from<=l+o.length&&s.more?a=o=o.updateHeight(e,l,i,s):o.updateHeight(e,l,i),a?this.balanced(n,o):(this.height=this.left.height+this.right.height,this.outdated=!1,this)}toString(){return this.left+(this.break?" ":"-")+this.right}};function Mu(r,e){let t,i;r[e]==null&&(t=r[e-1])instanceof Oi&&(i=r[e+1])instanceof Oi&&r.splice(e-1,3,new Oi(t.length+1+i.length))}var Cv=5,wa=class r{constructor(e,t){this.pos=e,this.oracle=t,this.nodes=[],this.lineStart=-1,this.lineEnd=-1,this.covering=null,this.writtenTo=e}get isCovered(){return this.covering&&this.nodes[this.nodes.length-1]==this.covering}span(e,t){if(this.lineStart>-1){let i=Math.min(t,this.lineEnd),s=this.nodes[this.nodes.length-1];s instanceof xt?s.length+=i-this.pos:(i>this.pos||!this.isCovered)&&this.nodes.push(new xt(i-this.pos,-1,0)),this.writtenTo=i,t>i&&(this.nodes.push(null),this.writtenTo++,this.lineStart=-1)}this.pos=t}point(e,t,i){if(e<t||i.heightRelevant){let s=i.widget?i.widget.estimatedHeight:0,n=i.widget?i.widget.lineBreaks:0;s<0&&(s=this.oracle.lineHeight);let o=t-e;i.block?this.addBlock(new Wn(o,s,i)):(o||n||s>=Cv)&&this.addLineDeco(s,n,o)}else t>e&&this.span(e,t);this.lineEnd>-1&&this.lineEnd<this.pos&&(this.lineEnd=this.oracle.doc.lineAt(this.pos).to)}enterLine(){if(this.lineStart>-1)return;let{from:e,to:t}=this.oracle.doc.lineAt(this.pos);this.lineStart=e,this.lineEnd=t,this.writtenTo<e&&((this.writtenTo<e-1||this.nodes[this.nodes.length-1]==null)&&this.nodes.push(this.blankContent(this.writtenTo,e-1)),this.nodes.push(null)),this.pos>e&&this.nodes.push(new xt(this.pos-e,-1,0)),this.writtenTo=this.pos}blankContent(e,t){let i=new Oi(t-e);return this.oracle.doc.lineAt(e).to==t&&(i.flags|=4),i}ensureLine(){this.enterLine();let e=this.nodes.length?this.nodes[this.nodes.length-1]:null;if(e instanceof xt)return e;let t=new xt(0,-1,0);return this.nodes.push(t),t}addBlock(e){this.enterLine();let t=e.deco;t&&t.startSide>0&&!this.isCovered&&this.ensureLine(),this.nodes.push(e),this.writtenTo=this.pos=this.pos+e.length,t&&t.endSide>0&&(this.covering=e)}addLineDeco(e,t,i){let s=this.ensureLine();s.length+=i,s.collapsed+=i,s.widgetHeight=Math.max(s.widgetHeight,e),s.breaks+=t,this.writtenTo=this.pos=this.pos+i}finish(e){let t=this.nodes.length==0?null:this.nodes[this.nodes.length-1];this.lineStart>-1&&!(t instanceof xt)&&!this.isCovered?this.nodes.push(new xt(0,-1,0)):(this.writtenTo<this.pos||t==null)&&this.nodes.push(this.blankContent(this.writtenTo,this.pos));let i=e;for(let s of this.nodes)s instanceof xt&&s.updateHeight(this.oracle,i),i+=s?s.length:1;return this.nodes}static build(e,t,i,s){let n=new r(i,e);return ce.spans(t,i,s,n,0),n.finish(i)}};function Ev(r,e,t){let i=new ka;return ce.compare(r,e,t,i,0),i.changes}var ka=class{constructor(){this.changes=[]}compareRange(){}comparePoint(e,t,i,s){(e<t||i&&i.heightRelevant||s&&s.heightRelevant)&&Ms(e,t,this.changes,5)}};function Av(r,e){let t=r.getBoundingClientRect(),i=r.ownerDocument,s=i.defaultView||window,n=Math.max(0,t.left),o=Math.min(s.innerWidth,t.right),l=Math.max(0,t.top),a=Math.min(s.innerHeight,t.bottom);for(let h=r.parentNode;h&&h!=i.body;)if(h.nodeType==1){let c=h,u=window.getComputedStyle(c);if((c.scrollHeight>c.clientHeight||c.scrollWidth>c.clientWidth)&&u.overflow!="visible"){let p=c.getBoundingClientRect();n=Math.max(n,p.left),o=Math.min(o,p.right),l=Math.max(l,p.top),a=Math.min(h==r.parentNode?s.innerHeight:a,p.bottom)}h=u.position=="absolute"||u.position=="fixed"?c.offsetParent:c.parentNode}else if(h.nodeType==11)h=h.host;else break;return{left:n-t.left,right:Math.max(n,o)-t.left,top:l-(t.top+e),bottom:Math.max(l,a)-(t.top+e)}}function Rv(r){let e=r.getBoundingClientRect(),t=r.ownerDocument.defaultView||window;return e.left<t.innerWidth&&e.right>0&&e.top<t.innerHeight&&e.bottom>0}function Mv(r,e){let t=r.getBoundingClientRect();return{left:0,right:t.right-t.left,top:e,bottom:t.bottom-(t.top+e)}}var br=class{constructor(e,t,i,s){this.from=e,this.to=t,this.size=i,this.displaySize=s}static same(e,t){if(e.length!=t.length)return!1;for(let i=0;i<e.length;i++){let s=e[i],n=t[i];if(s.from!=n.from||s.to!=n.to||s.size!=n.size)return!1}return!0}draw(e,t){return K.replace({widget:new xa(this.displaySize*(t?e.scaleY:e.scaleX),t)}).range(this.from,this.to)}},xa=class extends ai{constructor(e,t){super(),this.size=e,this.vertical=t}eq(e){return e.size==this.size&&e.vertical==this.vertical}toDOM(){let e=document.createElement("div");return this.vertical?e.style.height=this.size+"px":(e.style.width=this.size+"px",e.style.height="2px",e.style.display="inline-block"),e}get estimatedHeight(){return this.vertical?this.size:-1}},zn=class{constructor(e,t){this.view=e,this.state=t,this.pixelViewport={left:0,right:window.innerWidth,top:0,bottom:0},this.inView=!0,this.paddingTop=0,this.paddingBottom=0,this.contentDOMWidth=0,this.contentDOMHeight=0,this.editorHeight=0,this.editorWidth=0,this.scaleX=1,this.scaleY=1,this.scrollOffset=0,this.scrolledToBottom=!1,this.scrollAnchorPos=0,this.scrollAnchorHeight=-1,this.scaler=Du,this.scrollTarget=null,this.printing=!1,this.mustMeasureContent=!0,this.defaultTextDirection=_e.LTR,this.visibleRanges=[],this.mustEnforceCursorAssoc=!1;let i=t.facet(Wa).some(s=>typeof s!="function"&&s.class=="cm-lineWrapping");this.heightOracle=new ba(i),this.stateDeco=Nu(t),this.heightMap=dt.empty().applyChanges(this.stateDeco,oe.empty,this.heightOracle.setDoc(t.doc),[new Lt(0,0,0,t.doc.length)]);for(let s=0;s<2&&(this.viewport=this.getViewport(0,null),!!this.updateForViewport());s++);this.updateViewportLines(),this.lineGaps=this.ensureLineGaps([]),this.lineGapDeco=K.set(this.lineGaps.map(s=>s.draw(this,!1))),this.scrollParent=e.scrollDOM,this.computeVisibleRanges()}updateForViewport(){let e=[this.viewport],{main:t}=this.state.selection;for(let i=0;i<=1;i++){let s=i?t.head:t.anchor;if(!e.some(({from:n,to:o})=>s>=n&&s<=o)){let{from:n,to:o}=this.lineBlockAt(s);e.push(new Es(n,o))}}return this.viewports=e.sort((i,s)=>i.from-s.from),this.updateScaler()}updateScaler(){let e=this.scaler;return this.scaler=this.heightMap.height<=7e6?Du:new Sa(this.heightOracle,this.heightMap,this.viewports),e.eq(this.scaler)?0:2}updateViewportLines(){this.viewportLines=[],this.heightMap.forEachLine(this.viewport.from,this.viewport.to,this.heightOracle.setDoc(this.state.doc),0,0,e=>{this.viewportLines.push(dr(e,this.scaler))})}update(e,t=null){this.state=e.state;let i=this.stateDeco;this.stateDeco=Nu(this.state);let s=e.changedRanges,n=Lt.extendWithRanges(s,Ev(i,this.stateDeco,e?e.changes:Ze.empty(this.state.doc.length))),o=this.heightMap.height,l=this.scrolledToBottom?null:this.scrollAnchorAt(this.scrollOffset);Ru(),this.heightMap=this.heightMap.applyChanges(this.stateDeco,e.startState.doc,this.heightOracle.setDoc(this.state.doc),n),(this.heightMap.height!=o||qs)&&(e.flags|=2),l?(this.scrollAnchorPos=e.changes.mapPos(l.from,-1),this.scrollAnchorHeight=l.top):(this.scrollAnchorPos=-1,this.scrollAnchorHeight=o);let a=n.length?this.mapViewport(this.viewport,e.changes):this.viewport;(t&&(t.range.head<a.from||t.range.head>a.to)||!this.viewportIsAppropriate(a))&&(a=this.getViewport(0,t));let h=a.from!=this.viewport.from||a.to!=this.viewport.to;this.viewport=a,e.flags|=this.updateForViewport(),(h||!e.changes.empty||e.flags&2)&&this.updateViewportLines(),(this.lineGaps.length||this.viewport.to-this.viewport.from>4e3)&&this.updateLineGaps(this.ensureLineGaps(this.mapLineGaps(this.lineGaps,e.changes))),e.flags|=this.computeVisibleRanges(e.changes),t&&(this.scrollTarget=t),!this.mustEnforceCursorAssoc&&(e.selectionSet||e.focusChanged)&&e.view.lineWrapping&&e.state.selection.main.empty&&e.state.selection.main.assoc&&!e.state.facet(gp)&&(this.mustEnforceCursorAssoc=!0)}measure(){let{view:e}=this,t=e.contentDOM,i=window.getComputedStyle(t),s=this.heightOracle,n=i.whiteSpace;this.defaultTextDirection=i.direction=="rtl"?_e.RTL:_e.LTR;let o=this.heightOracle.mustRefreshForWrapping(n)||this.mustMeasureContent==="refresh",l=t.getBoundingClientRect(),a=o||this.mustMeasureContent||this.contentDOMHeight!=l.height;this.contentDOMHeight=l.height,this.mustMeasureContent=!1;let h=0,c=0;if(l.width&&l.height){let{scaleX:A,scaleY:R}=Ju(t,l);(A>.005&&Math.abs(this.scaleX-A)>.005||R>.005&&Math.abs(this.scaleY-R)>.005)&&(this.scaleX=A,this.scaleY=R,h|=16,o=a=!0)}let u=(parseInt(i.paddingTop)||0)*this.scaleY,p=(parseInt(i.paddingBottom)||0)*this.scaleY;(this.paddingTop!=u||this.paddingBottom!=p)&&(this.paddingTop=u,this.paddingBottom=p,h|=18),this.editorWidth!=e.scrollDOM.clientWidth&&(s.lineWrapping&&(a=!0),this.editorWidth=e.scrollDOM.clientWidth,h|=16);let y=Yu(this.view.contentDOM,!1).y;y!=this.scrollParent&&(this.scrollParent=y,this.scrollAnchorHeight=-1,this.scrollOffset=0);let O=this.getScrollOffset();this.scrollOffset!=O&&(this.scrollAnchorHeight=-1,this.scrollOffset=O),this.scrolledToBottom=tp(this.scrollParent||e.win);let b=(this.printing?Mv:Av)(t,this.paddingTop),v=b.top-this.pixelViewport.top,k=b.bottom-this.pixelViewport.bottom;this.pixelViewport=b;let T=this.pixelViewport.bottom>this.pixelViewport.top&&this.pixelViewport.right>this.pixelViewport.left;if(T!=this.inView&&(this.inView=T,T&&(a=!0)),!this.inView&&!this.scrollTarget&&!Rv(e.dom))return 0;let C=l.width;if((this.contentDOMWidth!=C||this.editorHeight!=e.scrollDOM.clientHeight)&&(this.contentDOMWidth=l.width,this.editorHeight=e.scrollDOM.clientHeight,h|=16),a){let A=e.docView.measureVisibleLineHeights(this.viewport);if(s.mustRefreshForHeights(A)&&(o=!0),o||s.lineWrapping&&Math.abs(C-this.contentDOMWidth)>s.charWidth){let{lineHeight:R,charWidth:D,textHeight:F}=e.docView.measureTextSize();o=R>0&&s.refresh(n,R,D,F,Math.max(5,C/D),A),o&&(e.docView.minWidth=0,h|=16)}v>0&&k>0?c=Math.max(v,k):v<0&&k<0&&(c=Math.min(v,k)),Ru();for(let R of this.viewports){let D=R.from==this.viewport.from?A:e.docView.measureVisibleLineHeights(R);this.heightMap=(o?dt.empty().applyChanges(this.stateDeco,oe.empty,this.heightOracle,[new Lt(0,0,0,e.state.doc.length)]):this.heightMap).updateHeight(s,0,o,new Oa(R.from,D))}qs&&(h|=2)}let Q=!this.viewportIsAppropriate(this.viewport,c)||this.scrollTarget&&(this.scrollTarget.range.head<this.viewport.from||this.scrollTarget.range.head>this.viewport.to);return Q&&(h&2&&(h|=this.updateScaler()),this.viewport=this.getViewport(c,this.scrollTarget),h|=this.updateForViewport()),(h&2||Q)&&this.updateViewportLines(),(this.lineGaps.length||this.viewport.to-this.viewport.from>4e3)&&this.updateLineGaps(this.ensureLineGaps(o?[]:this.lineGaps,e)),h|=this.computeVisibleRanges(),this.mustEnforceCursorAssoc&&(this.mustEnforceCursorAssoc=!1,e.docView.enforceCursorAssoc()),h}get visibleTop(){return this.scaler.fromDOM(this.pixelViewport.top)}get visibleBottom(){return this.scaler.fromDOM(this.pixelViewport.bottom)}getViewport(e,t){let i=.5-Math.max(-.5,Math.min(.5,e/1e3/2)),s=this.heightMap,n=this.heightOracle,{visibleTop:o,visibleBottom:l}=this,a=new Es(s.lineAt(o-i*1e3,ke.ByHeight,n,0,0).from,s.lineAt(l+(1-i)*1e3,ke.ByHeight,n,0,0).to);if(t){let{head:h}=t.range;if(h<a.from||h>a.to){let c=Math.min(this.editorHeight,this.pixelViewport.bottom-this.pixelViewport.top),u=s.lineAt(h,ke.ByPos,n,0,0),p;t.y=="center"?p=(u.top+u.bottom)/2-c/2:t.y=="start"||t.y=="nearest"&&h<a.from?p=u.top:p=u.bottom-c,a=new Es(s.lineAt(p-1e3/2,ke.ByHeight,n,0,0).from,s.lineAt(p+c+1e3/2,ke.ByHeight,n,0,0).to)}}return a}mapViewport(e,t){let i=t.mapPos(e.from,-1),s=t.mapPos(e.to,1);return new Es(this.heightMap.lineAt(i,ke.ByPos,this.heightOracle,0,0).from,this.heightMap.lineAt(s,ke.ByPos,this.heightOracle,0,0).to)}viewportIsAppropriate({from:e,to:t},i=0){if(!this.inView)return!0;let{top:s}=this.heightMap.lineAt(e,ke.ByPos,this.heightOracle,0,0),{bottom:n}=this.heightMap.lineAt(t,ke.ByPos,this.heightOracle,0,0),{visibleTop:o,visibleBottom:l}=this;return(e==0||s<=o-Math.max(10,Math.min(-i,250)))&&(t==this.state.doc.length||n>=l+Math.max(10,Math.min(i,250)))&&s>o-2*1e3&&n<l+2*1e3}mapLineGaps(e,t){if(!e.length||t.empty)return e;let i=[];for(let s of e)t.touchesRange(s.from,s.to)||i.push(new br(t.mapPos(s.from),t.mapPos(s.to),s.size,s.displaySize));return i}ensureLineGaps(e,t){let i=this.heightOracle.lineWrapping,s=i?1e4:2e3,n=s>>1,o=s<<1;if(this.defaultTextDirection!=_e.LTR&&!i)return[];let l=[],a=(c,u,p,y)=>{if(u-c<n)return;let O=this.state.selection.main,b=[O.from];O.empty||b.push(O.to);for(let k of b)if(k>c&&k<u){a(c,k-10,p,y),a(k+10,u,p,y);return}let v=Nv(e,k=>k.from>=p.from&&k.to<=p.to&&Math.abs(k.from-c)<n&&Math.abs(k.to-u)<n&&!b.some(T=>k.from<T&&k.to>T));if(!v){if(u<p.to&&t&&i&&t.visibleRanges.some(C=>C.from<=u&&C.to>=u)){let C=t.moveToLineBoundary(M.cursor(u),!1,!0).head;C>c&&(u=C)}let k=this.gapSize(p,c,u,y),T=i||k<2e6?k:2e6;v=new br(c,u,k,T)}l.push(v)},h=c=>{if(c.length<o||c.type!=He.Text)return;let u=Dv(c.from,c.to,this.stateDeco);if(u.total<o)return;let p=this.scrollTarget?this.scrollTarget.range.head:null,y,O;if(i){let b=s/this.heightOracle.lineLength*this.heightOracle.lineHeight,v,k;if(p!=null){let T=wn(u,p),C=((this.visibleBottom-this.visibleTop)/2+b)/c.height;v=T-C,k=T+C}else v=(this.visibleTop-c.top-b)/c.height,k=(this.visibleBottom-c.top+b)/c.height;y=vn(u,v),O=vn(u,k)}else{let b=u.total*this.heightOracle.charWidth,v=s*this.heightOracle.charWidth,k=0;if(b>2e6)for(let R of e)R.from>=c.from&&R.from<c.to&&R.size!=R.displaySize&&R.from*this.heightOracle.charWidth+k<this.pixelViewport.left&&(k=R.size-R.displaySize);let T=this.pixelViewport.left+k,C=this.pixelViewport.right+k,Q,A;if(p!=null){let R=wn(u,p),D=((C-T)/2+v)/b;Q=R-D,A=R+D}else Q=(T-v)/b,A=(C+v)/b;y=vn(u,Q),O=vn(u,A)}y>c.from&&a(c.from,y,c,u),O<c.to&&a(O,c.to,c,u)};for(let c of this.viewportLines)Array.isArray(c.type)?c.type.forEach(h):h(c);return l}gapSize(e,t,i,s){let n=wn(s,i)-wn(s,t);return this.heightOracle.lineWrapping?e.height*n:s.total*this.heightOracle.charWidth*n}updateLineGaps(e){br.same(e,this.lineGaps)||(this.lineGaps=e,this.lineGapDeco=K.set(e.map(t=>t.draw(this,this.heightOracle.lineWrapping))))}computeVisibleRanges(e){let t=this.stateDeco;this.lineGaps.length&&(t=t.concat(this.lineGapDeco));let i=[];ce.spans(t,this.viewport.from,this.viewport.to,{span(n,o){i.push({from:n,to:o})},point(){}},20);let s=0;if(i.length!=this.visibleRanges.length)s=12;else for(let n=0;n<i.length&&!(s&8);n++){let o=this.visibleRanges[n],l=i[n];(o.from!=l.from||o.to!=l.to)&&(s|=4,e&&e.mapPos(o.from,-1)==l.from&&e.mapPos(o.to,1)==l.to||(s|=8))}return this.visibleRanges=i,s}lineBlockAt(e){return e>=this.viewport.from&&e<=this.viewport.to&&this.viewportLines.find(t=>t.from<=e&&t.to>=e)||dr(this.heightMap.lineAt(e,ke.ByPos,this.heightOracle,0,0),this.scaler)}lineBlockAtHeight(e){return e>=this.viewportLines[0].top&&e<=this.viewportLines[this.viewportLines.length-1].bottom&&this.viewportLines.find(t=>t.top<=e&&t.bottom>=e)||dr(this.heightMap.lineAt(this.scaler.fromDOM(e),ke.ByHeight,this.heightOracle,0,0),this.scaler)}getScrollOffset(){return this.scrollParent==this.view.scrollDOM?this.scrollParent.scrollTop*this.scaleY:(this.scrollParent?this.scrollParent.getBoundingClientRect().top:0)-this.view.contentDOM.getBoundingClientRect().top}scrollAnchorAt(e){let t=this.lineBlockAtHeight(e+8);return t.from>=this.viewport.from||this.viewportLines[0].top-e>200?t:this.viewportLines[0]}elementAtHeight(e){return dr(this.heightMap.blockAt(this.scaler.fromDOM(e),this.heightOracle,0,0),this.scaler)}get docHeight(){return this.scaler.toDOM(this.heightMap.height)}get contentHeight(){return this.docHeight+this.paddingTop+this.paddingBottom}},Es=class{constructor(e,t){this.from=e,this.to=t}};function Dv(r,e,t){let i=[],s=r,n=0;return ce.spans(t,r,e,{span(){},point(o,l){o>s&&(i.push({from:s,to:o}),n+=o-s),s=l}},20),s<e&&(i.push({from:s,to:e}),n+=e-s),{total:n,ranges:i}}function vn({total:r,ranges:e},t){if(t<=0)return e[0].from;if(t>=1)return e[e.length-1].to;let i=Math.floor(r*t);for(let s=0;;s++){let{from:n,to:o}=e[s],l=o-n;if(i<=l)return n+i;i-=l}}function wn(r,e){let t=0;for(let{from:i,to:s}of r.ranges){if(e<=s){t+=e-i;break}t+=s-i}return t/r.total}function Nv(r,e){for(let t of r)if(e(t))return t}var Du={toDOM(r){return r},fromDOM(r){return r},scale:1,eq(r){return r==this}};function Nu(r){let e=r.facet(Gn).filter(i=>typeof i!="function"),t=r.facet(za).filter(i=>typeof i!="function");return t.length&&e.push(ce.join(t)),e}var Sa=class r{constructor(e,t,i){let s=0,n=0,o=0;this.viewports=i.map(({from:l,to:a})=>{let h=t.lineAt(l,ke.ByPos,e,0,0).top,c=t.lineAt(a,ke.ByPos,e,0,0).bottom;return s+=c-h,{from:l,to:a,top:h,bottom:c,domTop:0,domBottom:0}}),this.scale=(7e6-s)/(t.height-s);for(let l of this.viewports)l.domTop=o+(l.top-n)*this.scale,o=l.domBottom=l.domTop+(l.bottom-l.top),n=l.bottom}toDOM(e){for(let t=0,i=0,s=0;;t++){let n=t<this.viewports.length?this.viewports[t]:null;if(!n||e<n.top)return s+(e-i)*this.scale;if(e<=n.bottom)return n.domTop+(e-n.top);i=n.bottom,s=n.domBottom}}fromDOM(e){for(let t=0,i=0,s=0;;t++){let n=t<this.viewports.length?this.viewports[t]:null;if(!n||e<n.domTop)return i+(e-s)/this.scale;if(e<=n.domBottom)return n.top+(e-n.domTop);i=n.bottom,s=n.domBottom}}eq(e){return e instanceof r?this.scale==e.scale&&this.viewports.length==e.viewports.length&&this.viewports.every((t,i)=>t.from==e.viewports[i].from&&t.to==e.viewports[i].to):!1}};function dr(r,e){if(e.scale==1)return r;let t=e.toDOM(r.top),i=e.toDOM(r.bottom);return new It(r.from,r.length,t,i-t,Array.isArray(r._content)?r._content.map(s=>dr(s,e)):r._content)}var kn=W.define({combine:r=>r.join(" ")}),Ta=W.define({combine:r=>r.indexOf(!0)>-1}),Pa=kt.newName(),Qp=kt.newName(),qp=kt.newName(),Bp={"&light":"."+Qp,"&dark":"."+qp};function Ca(r,e,t){return new kt(e,{finish(i){return/&/.test(i)?i.replace(/&\w*/,s=>{if(s=="&")return r;if(!t||!t[s])throw new RangeError(`Unsupported selector: ${s}`);return t[s]}):r+" "+i}})}var Iv=Ca("."+Pa,{"&":{position:"relative !important",boxSizing:"border-box","&.cm-focused":{outline:"1px dotted #212121"},display:"flex !important",flexDirection:"column"},".cm-scroller":{display:"flex !important",alignItems:"flex-start !important",fontFamily:"monospace",lineHeight:1.4,height:"100%",overflowX:"auto",position:"relative",zIndex:0,overflowAnchor:"none"},".cm-content":{margin:0,flexGrow:2,flexShrink:0,display:"block",whiteSpace:"pre",wordWrap:"normal",boxSizing:"border-box",minHeight:"100%",padding:"4px 0",outline:"none","&[contenteditable=true]":{WebkitUserModify:"read-write-plaintext-only"}},".cm-lineWrapping":{whiteSpace_fallback:"pre-wrap",whiteSpace:"break-spaces",wordBreak:"break-word",overflowWrap:"anywhere",flexShrink:1},"&light .cm-content":{caretColor:"black"},"&dark .cm-content":{caretColor:"white"},".cm-line":{display:"block",padding:"0 2px 0 6px"},".cm-layer":{userSelect:"none",position:"absolute",left:0,top:0,contain:"size style","& > *":{position:"absolute"}},"&light .cm-selectionBackground":{background:"#d9d9d9"},"&dark .cm-selectionBackground":{background:"#222"},"&light.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground":{background:"#d7d4f0"},"&dark.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground":{background:"#233"},".cm-cursorLayer":{pointerEvents:"none"},"&.cm-focused > .cm-scroller > .cm-cursorLayer":{animation:"steps(1) cm-blink 1.2s infinite"},"@keyframes cm-blink":{"0%":{},"50%":{opacity:0},"100%":{}},"@keyframes cm-blink2":{"0%":{},"50%":{opacity:0},"100%":{}},".cm-cursor, .cm-dropCursor":{borderLeft:"1.2px solid black",marginLeft:"-0.6px",pointerEvents:"none"},".cm-cursor":{display:"none"},"&dark .cm-cursor":{borderLeftColor:"#ddd"},".cm-selectionHandle":{backgroundColor:"currentColor",width:"1.5px"},".cm-selectionHandle-start::before, .cm-selectionHandle-end::before":{content:'""',backgroundColor:"inherit",borderRadius:"50%",width:"8px",height:"8px",position:"absolute",left:"-3.25px"},".cm-selectionHandle-start::before":{top:"-8px"},".cm-selectionHandle-end::before":{bottom:"-8px"},".cm-dropCursor":{position:"absolute"},"&.cm-focused > .cm-scroller > .cm-cursorLayer .cm-cursor":{display:"block"},".cm-iso":{unicodeBidi:"isolate"},".cm-announced":{position:"fixed",top:"-10000px"},"@media print":{".cm-announced":{display:"none"}},"&light .cm-activeLine":{backgroundColor:"#cceeff44"},"&dark .cm-activeLine":{backgroundColor:"#99eeff33"},"&light .cm-specialChar":{color:"red"},"&dark .cm-specialChar":{color:"#f78"},".cm-gutters":{flexShrink:0,display:"flex",height:"100%",boxSizing:"border-box",zIndex:200},".cm-gutters-before":{insetInlineStart:0},".cm-gutters-after":{insetInlineEnd:0},"&light .cm-gutters":{backgroundColor:"#f5f5f5",color:"#6c6c6c",border:"0px solid #ddd","&.cm-gutters-before":{borderRightWidth:"1px"},"&.cm-gutters-after":{borderLeftWidth:"1px"}},"&dark .cm-gutters":{backgroundColor:"#333338",color:"#ccc"},".cm-gutter":{display:"flex !important",flexDirection:"column",flexShrink:0,boxSizing:"border-box",minHeight:"100%",overflow:"hidden"},".cm-gutterElement":{boxSizing:"border-box"},".cm-lineNumbers .cm-gutterElement":{padding:"0 3px 0 5px",minWidth:"20px",textAlign:"right",whiteSpace:"nowrap"},"&light .cm-activeLineGutter":{backgroundColor:"#e2f2ff"},"&dark .cm-activeLineGutter":{backgroundColor:"#222227"},".cm-panels":{boxSizing:"border-box",position:"sticky",left:0,right:0,zIndex:300},"&light .cm-panels":{backgroundColor:"#f5f5f5",color:"black"},".cm-panels-top":{top:"0"},".cm-panels-bottom":{bottom:"0"},"&light .cm-panels-top":{borderBottom:"1px solid #ddd"},"&light .cm-panels-bottom":{borderTop:"1px solid #ddd"},"&dark .cm-panels":{backgroundColor:"#333338",color:"white"},".cm-dialog":{padding:"2px 19px 4px 6px",position:"relative","& label":{fontSize:"80%"}},".cm-dialog-close":{position:"absolute",top:"3px",right:"4px",backgroundColor:"inherit",border:"none",font:"inherit",fontSize:"14px",padding:"0"},".cm-tab":{display:"inline-block",overflow:"hidden",verticalAlign:"bottom"},".cm-widgetBuffer":{verticalAlign:"text-top",height:"1em",width:0,display:"inline"},".cm-placeholder":{color:"#888",display:"inline-block",verticalAlign:"top",userSelect:"none"},".cm-highlightSpace":{background:"radial-gradient(circle at 50% 55%, #aaa 20%, transparent 0) no-repeat",backgroundSize:".4em",backgroundPosition:"calc(min(50%, 0px)) center"},".cm-highlightTab":{backgroundImage:`url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="20"><path stroke="%23888" stroke-width="1" fill="none" d="M1 10H196L190 5M190 15L196 10M197 4L197 16"/></svg>')`,backgroundSize:"auto 100%",backgroundPosition:"right 90%",backgroundRepeat:"no-repeat"},".cm-trailingSpace":{backgroundColor:"#ff332255"},".cm-button":{verticalAlign:"middle",color:"inherit",fontSize:"70%",padding:".2em 1em",borderRadius:"1px"},"&light .cm-button":{backgroundImage:"linear-gradient(#eff1f5, #d9d9df)",border:"1px solid #888","&:active":{backgroundImage:"linear-gradient(#b4b4b4, #d0d3d6)"}},"&dark .cm-button":{backgroundImage:"linear-gradient(#393939, #111)",border:"1px solid #888","&:active":{backgroundImage:"linear-gradient(#111, #333)"}},".cm-textfield":{verticalAlign:"middle",color:"inherit",fontSize:"70%",border:"1px solid silver",padding:".2em .5em"},"&light .cm-textfield":{backgroundColor:"white"},"&dark .cm-textfield":{border:"1px solid #555",backgroundColor:"inherit"}},Bp),Lv={childList:!0,characterData:!0,subtree:!0,attributes:!0,characterDataOldValue:!0},jl=$.ie&&$.ie_version<=11,Ea=class{constructor(e){this.view=e,this.active=!1,this.editContext=null,this.selectionRange=new Kl,this.selectionChanged=!1,this.delayedFlush=-1,this.resizeTimeout=-1,this.queue=[],this.delayedAndroidKey=null,this.flushingAndroidKey=-1,this.lastChange=0,this.scrollTargets=[],this.intersection=null,this.resizeScroll=null,this.intersecting=!1,this.gapIntersection=null,this.gaps=[],this.printQuery=null,this.parentCheck=-1,this.dom=e.contentDOM,this.observer=new MutationObserver(t=>{for(let i of t)this.queue.push(i);($.ie&&$.ie_version<=11||$.ios&&e.composing)&&t.some(i=>i.type=="childList"&&i.removedNodes.length||i.type=="characterData"&&i.oldValue.length>i.target.nodeValue.length)?this.flushSoon():this.flush()}),window.EditContext&&$.android&&e.constructor.EDIT_CONTEXT!==!1&&!($.chrome&&$.chrome_version<126)&&(this.editContext=new Aa(e),e.state.facet(oi)&&(e.contentDOM.editContext=this.editContext.editContext)),jl&&(this.onCharData=t=>{this.queue.push({target:t.target,type:"characterData",oldValue:t.prevValue}),this.flushSoon()}),this.onSelectionChange=this.onSelectionChange.bind(this),this.onResize=this.onResize.bind(this),this.onPrint=this.onPrint.bind(this),this.onScroll=this.onScroll.bind(this),window.matchMedia&&(this.printQuery=window.matchMedia("print")),typeof ResizeObserver=="function"&&(this.resizeScroll=new ResizeObserver(()=>{var t;((t=this.view.docView)===null||t===void 0?void 0:t.lastUpdate)<Date.now()-75&&this.onResize()}),this.resizeScroll.observe(e.scrollDOM)),this.addWindowListeners(this.win=e.win),this.start(),typeof IntersectionObserver=="function"&&(this.intersection=new IntersectionObserver(t=>{this.parentCheck<0&&(this.parentCheck=setTimeout(this.listenForScroll.bind(this),1e3)),t.length>0&&t[t.length-1].intersectionRatio>0!=this.intersecting&&(this.intersecting=!this.intersecting,this.intersecting!=this.view.inView&&this.onScrollChanged(document.createEvent("Event")))},{threshold:[0,.001]}),this.intersection.observe(this.dom),this.gapIntersection=new IntersectionObserver(t=>{t.length>0&&t[t.length-1].intersectionRatio>0&&this.onScrollChanged(document.createEvent("Event"))},{})),this.listenForScroll(),this.readSelectionRange()}onScrollChanged(e){this.view.inputState.runHandlers("scroll",e),this.intersecting&&this.view.measure()}onScroll(e){this.intersecting&&this.flush(!1),this.editContext&&this.view.requestMeasure(this.editContext.measureReq),this.onScrollChanged(e)}onResize(){this.resizeTimeout<0&&(this.resizeTimeout=setTimeout(()=>{this.resizeTimeout=-1,this.view.requestMeasure()},50))}onPrint(e){(e.type=="change"||!e.type)&&!e.matches||(this.view.viewState.printing=!0,this.view.measure(),setTimeout(()=>{this.view.viewState.printing=!1,this.view.requestMeasure()},500))}updateGaps(e){if(this.gapIntersection&&(e.length!=this.gaps.length||this.gaps.some((t,i)=>t!=e[i]))){this.gapIntersection.disconnect();for(let t of e)this.gapIntersection.observe(t);this.gaps=e}}onSelectionChange(e){let t=this.selectionChanged;if(!this.readSelectionRange()||this.delayedAndroidKey)return;let{view:i}=this,s=this.selectionRange;if(i.state.facet(oi)?i.root.activeElement!=this.dom:!ur(this.dom,s))return;let n=s.anchorNode&&i.docView.tile.nearest(s.anchorNode);if(n&&n.isWidget()&&n.widget.ignoreEvent(e)){t||(this.selectionChanged=!1);return}($.ie&&$.ie_version<=11||$.android&&$.chrome)&&!i.state.selection.main.empty&&s.focusNode&&pr(s.focusNode,s.focusOffset,s.anchorNode,s.anchorOffset)?this.flushSoon():this.flush(!1)}readSelectionRange(){let{view:e}=this,t=kr(e.root);if(!t)return!1;let i=$.safari&&e.root.nodeType==11&&e.root.activeElement==this.dom&&Qv(this.view,t)||t;if(!i||this.selectionRange.eq(i))return!1;let s=ur(this.dom,i);return s&&!this.selectionChanged&&e.inputState.lastFocusTime>Date.now()-200&&e.inputState.lastTouchTime<Date.now()-300&&R1(this.dom,i)?(this.view.inputState.lastFocusTime=0,e.docView.updateSelection(),!1):(this.selectionRange.setRange(i),s&&(this.selectionChanged=!0),!0)}setSelectionRange(e,t){this.selectionRange.set(e.node,e.offset,t.node,t.offset),this.selectionChanged=!1}clearSelectionRange(){this.selectionRange.set(null,0,null,0)}listenForScroll(){this.parentCheck=-1;let e=0,t=null;for(let i=this.dom;i;)if(i.nodeType==1)!t&&e<this.scrollTargets.length&&this.scrollTargets[e]==i?e++:t||(t=this.scrollTargets.slice(0,e)),t&&t.push(i),i=i.assignedSlot||i.parentNode;else if(i.nodeType==11)i=i.host;else break;if(e<this.scrollTargets.length&&!t&&(t=this.scrollTargets.slice(0,e)),t){for(let i of this.scrollTargets)i.removeEventListener("scroll",this.onScroll);for(let i of this.scrollTargets=t)i.addEventListener("scroll",this.onScroll)}}ignore(e){if(!this.active)return e();try{return this.stop(),e()}finally{this.start(),this.clear()}}start(){this.active||(this.observer.observe(this.dom,Lv),jl&&this.dom.addEventListener("DOMCharacterDataModified",this.onCharData),this.active=!0)}stop(){this.active&&(this.active=!1,this.observer.disconnect(),jl&&this.dom.removeEventListener("DOMCharacterDataModified",this.onCharData))}clear(){this.processRecords(),this.queue.length=0,this.selectionChanged=!1}delayAndroidKey(e,t){var i;if(!this.delayedAndroidKey){let s=()=>{let n=this.delayedAndroidKey;n&&(this.clearDelayedAndroidKey(),this.view.inputState.lastKeyCode=n.keyCode,this.view.inputState.lastKeyTime=Date.now(),!this.flush()&&n.force&&Ds(this.dom,n.key,n.keyCode))};this.flushingAndroidKey=this.view.win.requestAnimationFrame(s)}(!this.delayedAndroidKey||e=="Enter")&&(this.delayedAndroidKey={key:e,keyCode:t,force:this.lastChange<Date.now()-50||!!(!((i=this.delayedAndroidKey)===null||i===void 0)&&i.force)})}clearDelayedAndroidKey(){this.win.cancelAnimationFrame(this.flushingAndroidKey),this.delayedAndroidKey=null,this.flushingAndroidKey=-1}flushSoon(){this.delayedFlush<0&&(this.delayedFlush=this.view.win.requestAnimationFrame(()=>{this.delayedFlush=-1,this.flush()}))}forceFlush(){this.delayedFlush>=0&&(this.view.win.cancelAnimationFrame(this.delayedFlush),this.delayedFlush=-1),this.flush()}pendingRecords(){for(let e of this.observer.takeRecords())this.queue.push(e);return this.queue}processRecords(){let e=this.pendingRecords();e.length&&(this.queue=[]);let t=-1,i=-1,s=!1;for(let n of e){let o=this.readMutation(n);o&&(o.typeOver&&(s=!0),t==-1?{from:t,to:i}=o:(t=Math.min(o.from,t),i=Math.max(o.to,i)))}return{from:t,to:i,typeOver:s}}readChange(){let{from:e,to:t,typeOver:i}=this.processRecords(),s=this.selectionChanged&&ur(this.dom,this.selectionRange);if(e<0&&!s)return null;e>-1&&(this.lastChange=Date.now()),this.view.inputState.lastFocusTime=0,this.selectionChanged=!1;let n=new ma(this.view,e,t,i);return this.view.docView.domChanged={newSel:n.newSel?n.newSel.main:null},n}flush(e=!0){if(this.delayedFlush>=0||this.delayedAndroidKey)return!1;e&&this.readSelectionRange();let t=this.readChange();if(!t)return this.view.requestMeasure(),!1;let i=this.view.state,s=Pp(this.view,t);return this.view.state==i&&(t.domChanged||t.newSel&&!$n(this.view.state.selection,t.newSel.main))&&this.view.update([]),s}readMutation(e){let t=this.view.docView.tile.nearest(e.target);if(!t||t.isWidget())return null;if(t.markDirty(e.type=="attributes"),e.type=="childList"){let i=Iu(t,e.previousSibling||e.target.previousSibling,-1),s=Iu(t,e.nextSibling||e.target.nextSibling,1);return{from:i?t.posAfter(i):t.posAtStart,to:s?t.posBefore(s):t.posAtEnd,typeOver:!1}}else return e.type=="characterData"?{from:t.posAtStart,to:t.posAtEnd,typeOver:e.target.nodeValue==e.oldValue}:null}setWindow(e){e!=this.win&&(this.removeWindowListeners(this.win),this.win=e,this.addWindowListeners(this.win))}addWindowListeners(e){e.addEventListener("resize",this.onResize),this.printQuery?this.printQuery.addEventListener?this.printQuery.addEventListener("change",this.onPrint):this.printQuery.addListener(this.onPrint):e.addEventListener("beforeprint",this.onPrint),e.addEventListener("scroll",this.onScroll),e.document.addEventListener("selectionchange",this.onSelectionChange)}removeWindowListeners(e){e.removeEventListener("scroll",this.onScroll),e.removeEventListener("resize",this.onResize),this.printQuery?this.printQuery.removeEventListener?this.printQuery.removeEventListener("change",this.onPrint):this.printQuery.removeListener(this.onPrint):e.removeEventListener("beforeprint",this.onPrint),e.document.removeEventListener("selectionchange",this.onSelectionChange)}update(e){this.editContext&&(this.editContext.update(e),e.startState.facet(oi)!=e.state.facet(oi)&&(e.view.contentDOM.editContext=e.state.facet(oi)?this.editContext.editContext:null))}destroy(){var e,t,i;this.stop(),(e=this.intersection)===null||e===void 0||e.disconnect(),(t=this.gapIntersection)===null||t===void 0||t.disconnect(),(i=this.resizeScroll)===null||i===void 0||i.disconnect();for(let s of this.scrollTargets)s.removeEventListener("scroll",this.onScroll);this.removeWindowListeners(this.win),clearTimeout(this.parentCheck),clearTimeout(this.resizeTimeout),this.win.cancelAnimationFrame(this.delayedFlush),this.win.cancelAnimationFrame(this.flushingAndroidKey),this.editContext&&(this.view.contentDOM.editContext=null,this.editContext.destroy())}};function Iu(r,e,t){for(;e;){let i=Se.get(e);if(i&&i.parent==r)return i;let s=e.parentNode;e=s!=r.dom?s:t>0?e.nextSibling:e.previousSibling}return null}function Lu(r,e){let t=e.startContainer,i=e.startOffset,s=e.endContainer,n=e.endOffset,o=r.docView.domAtPos(r.state.selection.main.anchor,1);return pr(o.node,o.offset,s,n)&&([t,i,s,n]=[s,n,t,i]),{anchorNode:t,anchorOffset:i,focusNode:s,focusOffset:n}}function Qv(r,e){if(e.getComposedRanges){let s=e.getComposedRanges(r.root)[0];if(s)return Lu(r,s)}let t=null;function i(s){s.preventDefault(),s.stopImmediatePropagation(),t=s.getTargetRanges()[0]}return r.contentDOM.addEventListener("beforeinput",i,!0),r.dom.ownerDocument.execCommand("indent"),r.contentDOM.removeEventListener("beforeinput",i,!0),t?Lu(r,t):null}var Aa=class{constructor(e){this.from=0,this.to=0,this.pendingContextChange=null,this.handlers=Object.create(null),this.composing=null,this.resetRange(e.state);let t=this.editContext=new window.EditContext({text:e.state.doc.sliceString(this.from,this.to),selectionStart:this.toContextPos(Math.max(this.from,Math.min(this.to,e.state.selection.main.anchor))),selectionEnd:this.toContextPos(e.state.selection.main.head)});this.handlers.textupdate=i=>{let s=e.state.selection.main,{anchor:n,head:o}=s,l=this.toEditorPos(i.updateRangeStart),a=this.toEditorPos(i.updateRangeEnd);e.inputState.composing>=0&&!this.composing&&(this.composing={contextBase:i.updateRangeStart,editorBase:l,drifted:!1});let h=a-l>i.text.length;l==this.from&&n<this.from?l=n:a==this.to&&n>this.to&&(a=n);let c=Cp(e.state.sliceDoc(l,a),i.text,(h?s.from:s.to)-l,h?"end":null);if(!c){let p=M.single(this.toEditorPos(i.selectionStart),this.toEditorPos(i.selectionEnd));$n(p,s)||e.dispatch({selection:p,userEvent:"select"});return}let u={from:c.from+l,to:c.toA+l,insert:oe.of(i.text.slice(c.from,c.toB).split(`
`))};if(($.mac||$.android)&&u.from==o-1&&/^\. ?$/.test(i.text)&&e.contentDOM.getAttribute("autocorrect")=="off"&&(u={from:l,to:a,insert:oe.of([i.text.replace("."," ")])}),this.pendingContextChange=u,!e.state.readOnly){let p=this.to-this.from+(u.to-u.from+u.insert.length);Ha(e,u,M.single(this.toEditorPos(i.selectionStart,p),this.toEditorPos(i.selectionEnd,p)))}this.pendingContextChange&&(this.revertPending(e.state),this.setSelection(e.state)),u.from<u.to&&!u.insert.length&&e.inputState.composing>=0&&!/[\\p{Alphabetic}\\p{Number}_]/.test(t.text.slice(Math.max(0,i.updateRangeStart-1),Math.min(t.text.length,i.updateRangeStart+1)))&&this.handlers.compositionend(i)},this.handlers.characterboundsupdate=i=>{let s=[],n=null;for(let o=this.toEditorPos(i.rangeStart),l=this.toEditorPos(i.rangeEnd);o<l;o++){let a=e.coordsForChar(o);n=a&&new DOMRect(a.left,a.top,a.right-a.left,a.bottom-a.top)||n||new DOMRect,s.push(n)}t.updateCharacterBounds(i.rangeStart,s)},this.handlers.textformatupdate=i=>{let s=[];for(let n of i.getTextFormats()){let o=n.underlineStyle,l=n.underlineThickness;if(!/none/i.test(o)&&!/none/i.test(l)){let a=this.toEditorPos(n.rangeStart),h=this.toEditorPos(n.rangeEnd);if(a<h){let c=`text-decoration: underline ${/^[a-z]/.test(o)?o+" ":o=="Dashed"?"dashed ":o=="Squiggle"?"wavy ":""}${/thin/i.test(l)?1:2}px`;s.push(K.mark({attributes:{style:c}}).range(a,h))}}}e.dispatch({effects:yp.of(K.set(s))})},this.handlers.compositionstart=()=>{e.inputState.composing<0&&(e.inputState.composing=0,e.inputState.compositionFirstChange=!0)},this.handlers.compositionend=()=>{if(e.inputState.composing=-1,e.inputState.compositionFirstChange=null,this.composing){let{drifted:i}=this.composing;this.composing=null,i&&this.reset(e.state)}};for(let i in this.handlers)t.addEventListener(i,this.handlers[i]);this.measureReq={read:i=>{let s=kr(i.root);s&&s.rangeCount&&this.editContext.updateSelectionBounds(s.getRangeAt(0).getBoundingClientRect())}}}applyEdits(e){let t=0,i=!1,s=this.pendingContextChange;return e.changes.iterChanges((n,o,l,a,h)=>{if(i)return;let c=h.length-(o-n);if(s&&o>=s.to)if(s.from==n&&s.to==o&&s.insert.eq(h)){s=this.pendingContextChange=null,t+=c,this.to+=c;return}else s=null,this.revertPending(e.state);if(n+=t,o+=t,o<=this.from)this.from+=c,this.to+=c;else if(n<this.to){if(n<this.from||o>this.to||this.to-this.from+h.length>3e4){i=!0;return}this.editContext.updateText(this.toContextPos(n),this.toContextPos(o),h.toString()),this.to+=c}t+=c}),s&&!i&&this.revertPending(e.state),!i}update(e){let t=this.pendingContextChange,i=e.startState.selection.main;this.composing&&(this.composing.drifted||!e.changes.touchesRange(i.from,i.to)&&e.transactions.some(s=>!s.isUserEvent("input.type")&&s.changes.touchesRange(this.from,this.to)))?(this.composing.drifted=!0,this.composing.editorBase=e.changes.mapPos(this.composing.editorBase)):!this.applyEdits(e)||!this.rangeIsValid(e.state)?(this.pendingContextChange=null,this.reset(e.state)):(e.docChanged||e.selectionSet||t)&&this.setSelection(e.state),(e.geometryChanged||e.docChanged||e.selectionSet)&&e.view.requestMeasure(this.measureReq)}resetRange(e){let{head:t}=e.selection.main;this.from=Math.max(0,t-1e4),this.to=Math.min(e.doc.length,t+1e4)}reset(e){this.resetRange(e),this.editContext.updateText(0,this.editContext.text.length,e.doc.sliceString(this.from,this.to)),this.setSelection(e)}revertPending(e){let t=this.pendingContextChange;this.pendingContextChange=null,this.editContext.updateText(this.toContextPos(t.from),this.toContextPos(t.from+t.insert.length),e.doc.sliceString(t.from,t.to))}setSelection(e){let{main:t}=e.selection,i=this.toContextPos(Math.max(this.from,Math.min(this.to,t.anchor))),s=this.toContextPos(t.head);(this.editContext.selectionStart!=i||this.editContext.selectionEnd!=s)&&this.editContext.updateSelection(i,s)}rangeIsValid(e){let{head:t}=e.selection.main;return!(this.from>0&&t-this.from<500||this.to<e.doc.length&&this.to-t<500||this.to-this.from>1e4*3)}toEditorPos(e,t=this.to-this.from){e=Math.min(e,t);let i=this.composing;return i&&i.drifted?i.editorBase+(e-i.contextBase):e+this.from}toContextPos(e){let t=this.composing;return t&&t.drifted?t.contextBase+(e-t.editorBase):e-this.from}destroy(){for(let e in this.handlers)this.editContext.removeEventListener(e,this.handlers[e])}},z=class r{get state(){return this.viewState.state}get viewport(){return this.viewState.viewport}get visibleRanges(){return this.viewState.visibleRanges}get inView(){return this.viewState.inView}get composing(){return!!this.inputState&&this.inputState.composing>0}get compositionStarted(){return!!this.inputState&&this.inputState.composing>=0}get root(){return this._root}get win(){return this.dom.ownerDocument.defaultView||window}constructor(e={}){var t;this.plugins=[],this.pluginMap=new Map,this.editorAttrs={},this.contentAttrs={},this.bidiCache=[],this.destroyed=!1,this.updateState=2,this.measureScheduled=-1,this.measureRequests=[],this.clearAnnouncement=-1,this.contentDOM=document.createElement("div"),this.scrollDOM=document.createElement("div"),this.scrollDOM.tabIndex=-1,this.scrollDOM.className="cm-scroller",this.scrollDOM.appendChild(this.contentDOM),this.announceDOM=document.createElement("div"),this.announceDOM.className="cm-announced",this.announceDOM.setAttribute("aria-live","polite"),this.dom=document.createElement("div"),this.dom.appendChild(this.announceDOM),this.dom.appendChild(this.scrollDOM),e.parent&&e.parent.appendChild(this.dom);let{dispatch:i}=e;this.dispatchTransactions=e.dispatchTransactions||i&&(s=>s.forEach(n=>i(n,this)))||(s=>this.update(s)),this.dispatch=this.dispatch.bind(this),this._root=e.root||A1(e.parent)||document,this.viewState=new zn(this,e.state||pe.create(e)),e.scrollTo&&e.scrollTo.is(yn)&&(this.viewState.scrollTarget=e.scrollTo.value.clip(this.viewState.state)),this.plugins=this.state.facet(Cs).map(s=>new gr(s));for(let s of this.plugins)s.update(this);this.observer=new Ea(this),this.inputState=new ga(this),this.inputState.ensureHandlers(this.plugins),this.docView=new qn(this),this.mountStyles(),this.updateAttrs(),this.updateState=0,this.requestMeasure(),!((t=document.fonts)===null||t===void 0)&&t.ready&&document.fonts.ready.then(()=>{this.viewState.mustMeasureContent="refresh",this.requestMeasure()})}dispatch(...e){let t=e.length==1&&e[0]instanceof Re?e:e.length==1&&Array.isArray(e[0])?e[0]:[this.state.update(...e)];this.dispatchTransactions(t,this)}update(e){if(this.updateState!=0)throw new Error("Calls to EditorView.update are not allowed while an update is in progress");let t=!1,i=!1,s,n=this.state;for(let p of e){if(p.startState!=n)throw new RangeError("Trying to update state with a transaction that doesn't start from the previous state.");n=p.state}if(this.destroyed){this.viewState.state=n;return}let o=this.hasFocus,l=0,a=null;e.some(p=>p.annotation(Np))?(this.inputState.notifiedFocused=o,l=1):o!=this.inputState.notifiedFocused&&(this.inputState.notifiedFocused=o,a=Ip(n,o),a||(l=1));let h=this.observer.delayedAndroidKey,c=null;if(h?(this.observer.clearDelayedAndroidKey(),c=this.observer.readChange(),(c&&!this.state.doc.eq(n.doc)||!this.state.selection.eq(n.selection))&&(c=null)):this.observer.clear(),n.facet(pe.phrases)!=this.state.facet(pe.phrases))return this.setState(n);s=Ln.create(this,n,e),s.flags|=l;let u=this.viewState.scrollTarget;try{this.updateState=2;for(let p of e){if(u&&(u=u.map(p.changes)),p.scrollIntoView){let{main:y}=p.state.selection,{x:O,y:b}=this.state.facet(r.cursorScrollMargin);u=new mr(y.empty?y:M.cursor(y.head,y.head>y.anchor?-1:1),"nearest","nearest",b,O)}for(let y of p.effects)y.is(yn)&&(u=y.value.clip(this.state))}this.viewState.update(s,u),this.bidiCache=jn.update(this.bidiCache,s.changes),s.empty||(this.updatePlugins(s),this.inputState.update(s)),t=this.docView.update(s),this.state.facet(cr)!=this.styleModules&&this.mountStyles(),i=this.updateAttrs(),this.showAnnouncements(e),this.docView.updateSelection(t,e.some(p=>p.isUserEvent("select.pointer")))}finally{this.updateState=0}if(s.startState.facet(kn)!=s.state.facet(kn)&&(this.viewState.mustMeasureContent=!0),(t||i||u||this.viewState.mustEnforceCursorAssoc||this.viewState.mustMeasureContent)&&this.requestMeasure(),t&&this.docViewUpdate(),!s.empty)for(let p of this.state.facet(ia))try{p(s)}catch(y){tt(this.state,y,"update listener")}(a||c)&&Promise.resolve().then(()=>{a&&this.state==a.startState&&this.dispatch(a),c&&!Pp(this,c)&&h.force&&Ds(this.contentDOM,h.key,h.keyCode)})}setState(e){if(this.updateState!=0)throw new Error("Calls to EditorView.setState are not allowed while an update is in progress");if(this.destroyed){this.viewState.state=e;return}this.updateState=2;let t=this.hasFocus;try{for(let i of this.plugins)i.destroy(this);this.viewState=new zn(this,e),this.plugins=e.facet(Cs).map(i=>new gr(i)),this.pluginMap.clear();for(let i of this.plugins)i.update(this);this.docView.destroy(),this.docView=new qn(this),this.inputState.ensureHandlers(this.plugins),this.mountStyles(),this.updateAttrs(),this.bidiCache=[]}finally{this.updateState=0}t&&this.focus(),this.requestMeasure()}updatePlugins(e){let t=e.startState.facet(Cs),i=e.state.facet(Cs);if(t!=i){let s=[];for(let n of i){let o=t.indexOf(n);if(o<0)s.push(new gr(n));else{let l=this.plugins[o];l.mustUpdate=e,s.push(l)}}for(let n of this.plugins)n.mustUpdate!=e&&n.destroy(this);this.plugins=s,this.pluginMap.clear()}else for(let s of this.plugins)s.mustUpdate=e;for(let s=0;s<this.plugins.length;s++)this.plugins[s].update(this);t!=i&&this.inputState.ensureHandlers(this.plugins)}docViewUpdate(){for(let e of this.plugins){let t=e.value;if(t&&t.docViewUpdate)try{t.docViewUpdate(this)}catch(i){tt(this.state,i,"doc view update listener")}}}measure(e=!0){if(this.destroyed)return;if(this.measureScheduled>-1&&this.win.cancelAnimationFrame(this.measureScheduled),this.observer.delayedAndroidKey){this.measureScheduled=-1,this.requestMeasure();return}this.measureScheduled=0,e&&this.observer.forceFlush();let t=null,i=this.viewState.scrollParent,s=this.viewState.getScrollOffset(),{scrollAnchorPos:n,scrollAnchorHeight:o,scaleY:l}=this.viewState;Math.abs(s-this.viewState.scrollOffset)>1&&(o=-1),this.viewState.scrollAnchorHeight=-1;try{for(let a=0;;a++){if(o<0){if(tp(i||this.win))n=-1,o=this.viewState.heightMap.height/this.viewState.scaleY;else{let O=this.viewState.scrollAnchorAt(s);n=O.from,o=O.top}l=this.viewState.scaleY}this.updateState=1;let h=this.viewState.measure();if(!h&&!this.measureRequests.length&&this.viewState.scrollTarget==null)break;if(a>5){console.warn(this.measureRequests.length?"Measure loop restarted more than 5 times":"Viewport failed to stabilize");break}let c=[];h&4||([this.measureRequests,c]=[c,this.measureRequests]);let u=c.map(O=>{try{return O.read(this)}catch(b){return tt(this.state,b),Qu}}),p=Ln.create(this,this.state,[]),y=!1;p.flags|=h,t?t.flags|=h:t=p,this.updateState=2,p.empty||(this.updatePlugins(p),this.inputState.update(p),this.updateAttrs(),y=this.docView.update(p),y&&this.docViewUpdate());for(let O=0;O<c.length;O++)if(u[O]!=Qu)try{let b=c[O];b.write&&b.write(u[O],this)}catch(b){tt(this.state,b)}if(y&&this.docView.updateSelection(!0),!p.viewportChanged&&this.measureRequests.length==0){if(this.viewState.editorHeight)if(this.viewState.scrollTarget){this.docView.scrollIntoView(this.viewState.scrollTarget),this.viewState.scrollTarget=null,o=-1;continue}else{let b=(n<0?this.viewState.heightMap.height:this.viewState.lineBlockAt(n).top)/this.viewState.scaleY-o/l;if((b>1||b<-1)&&!($.ios&&this.inputState.lastIOSMomentumScroll>Date.now()-100)&&(i==this.scrollDOM||this.hasFocus||Math.max(this.inputState.lastWheelEvent,this.inputState.lastTouchTime)>Date.now()-100)){s=s+b,i?n<0?i.scrollTop=i.scrollHeight:i.scrollTop+=b:this.win.scrollBy(0,b),o=-1;continue}}break}}}finally{this.updateState=0,this.measureScheduled=-1}if(t&&!t.empty)for(let a of this.state.facet(ia))a(t)}get themeClasses(){return Pa+" "+(this.state.facet(Ta)?qp:Qp)+" "+this.state.facet(kn)}updateAttrs(){let e=qu(this,bp,{class:"cm-editor"+(this.hasFocus?" cm-focused ":" ")+this.themeClasses}),t={spellcheck:"false",autocorrect:"off",autocapitalize:"off",writingsuggestions:"false",translate:"no",contenteditable:this.state.facet(oi)?"true":"false",class:"cm-content",style:`${$.tabSize}: ${this.state.tabSize}`,role:"textbox","aria-multiline":"true"};this.state.readOnly&&(t["aria-readonly"]="true"),qu(this,Wa,t);let i=this.observer.ignore(()=>{let s=gu(this.contentDOM,this.contentAttrs,t),n=gu(this.dom,this.editorAttrs,e);return s||n});return this.editorAttrs=e,this.contentAttrs=t,i}showAnnouncements(e){let t=!0;for(let i of e)for(let s of i.effects)if(s.is(r.announce)){t&&(this.announceDOM.textContent="",this.win.clearTimeout(this.clearAnnouncement),this.clearAnnouncement=this.win.setTimeout(()=>{this.announceDOM.textContent="\xA0"},200),t=!1);let n=this.announceDOM.appendChild(document.createElement("div"));n.textContent=s.value}}mountStyles(){this.styleModules=this.state.facet(cr);let e=this.state.facet(r.cspNonce);kt.mount(this.root,this.styleModules.concat(Iv).reverse(),e?{nonce:e}:void 0)}readMeasured(){if(this.updateState==2)throw new Error("Reading the editor layout isn't allowed during an update");this.updateState==0&&this.measureScheduled>-1&&this.measure(!1)}requestMeasure(e){if(this.measureScheduled<0&&(this.measureScheduled=this.win.requestAnimationFrame(()=>this.measure())),e){if(this.measureRequests.indexOf(e)>-1)return;if(e.key!=null){for(let t=0;t<this.measureRequests.length;t++)if(this.measureRequests[t].key===e.key){this.measureRequests[t]=e;return}}this.measureRequests.push(e)}}plugin(e){let t=this.pluginMap.get(e);return(t===void 0||t&&t.plugin!=e)&&this.pluginMap.set(e,t=this.plugins.find(i=>i.plugin==e)||null),t&&t.update(this).value}get documentTop(){return this.contentDOM.getBoundingClientRect().top+this.viewState.paddingTop}get documentPadding(){return{top:this.viewState.paddingTop,bottom:this.viewState.paddingBottom}}get scaleX(){return this.viewState.scaleX}get scaleY(){return this.viewState.scaleY}elementAtHeight(e){return this.readMeasured(),this.viewState.elementAtHeight(e)}lineBlockAtHeight(e){return this.readMeasured(),this.viewState.lineBlockAtHeight(e)}get viewportLineBlocks(){return this.viewState.viewportLines}lineBlockAt(e){return this.viewState.lineBlockAt(e)}get contentHeight(){return this.viewState.contentHeight}moveByChar(e,t,i){return zl(this,e,wu(this,e,t,i))}moveByGroup(e,t){return zl(this,e,wu(this,e,t,i=>nv(this,e.head,i)))}visualLineSide(e,t){return t?M.cursor(e.to,1):M.cursor(e.from,-1)}moveToLineBoundary(e,t,i=!0){return rv(this,e,t,i)}moveVertically(e,t,i){return zl(this,e,ov(this,e,t,i))}domAtPos(e,t=1){return this.docView.domAtPos(e,t)}posAtDOM(e,t=0){return this.docView.posFromDOM(e,t)}posAtCoords(e,t=!0){this.readMeasured();let i=da(this,e,t);return i&&i.pos}posAndSideAtCoords(e,t=!0){return this.readMeasured(),da(this,e,t)}coordsAtPos(e,t=1){this.readMeasured();let i=this.state.doc.lineAt(e),s=this.bidiSpans(i),n=s[Tt.find(s,e-i.from,-1,t)];return i.length&&(e==i.from&&t<0||e==i.to&&t>0)&&n.dir!=this.textDirectionAt(i.from)&&(e==i.to?(e=i.from+n.from,t=1):(e=i.from+n.to,t=-1)),this.docView.coordsAt(e,t,n.dir==_e.RTL)}coordsForChar(e){return this.readMeasured(),this.docView.coordsForChar(e)}get defaultCharacterWidth(){return this.viewState.heightOracle.charWidth}get defaultLineHeight(){return this.viewState.heightOracle.lineHeight}get textDirection(){return this.viewState.defaultTextDirection}textDirectionAt(e){return!this.state.facet(mp)||e<this.viewport.from||e>this.viewport.to?this.textDirection:(this.readMeasured(),this.docView.textDirectionAt(e))}get lineWrapping(){return this.viewState.heightOracle.lineWrapping}bidiSpans(e){if(e.length>qv)return lp(e.length);let t=this.textDirectionAt(e.from),i;for(let n of this.bidiCache)if(n.from==e.from&&n.dir==t&&(n.fresh||op(n.isolates,i=bu(this,e))))return n.order;i||(i=bu(this,e));let s=q1(e.text,t,i);return this.bidiCache.push(new jn(e.from,e.to,t,i,!0,s)),s}get hasFocus(){var e;return(this.dom.ownerDocument.hasFocus()||$.safari&&((e=this.inputState)===null||e===void 0?void 0:e.lastContextMenu)>Date.now()-3e4)&&this.root.activeElement==this.contentDOM}focus(){this.observer.ignore(()=>{ep(this.contentDOM),this.docView.updateSelection()})}setRoot(e){this._root!=e&&(this._root=e,this.observer.setWindow((e.nodeType==9?e:e.ownerDocument).defaultView||window),this.mountStyles())}destroy(){this.root.activeElement==this.contentDOM&&this.contentDOM.blur();for(let e of this.plugins)e.destroy(this);this.plugins=[],this.inputState.destroy(),this.docView.destroy(),this.dom.remove(),this.observer.destroy(),this.win.clearTimeout(this.clearAnnouncement),this.measureScheduled>-1&&this.win.cancelAnimationFrame(this.measureScheduled),this.destroyed=!0}static scrollIntoView(e,t={}){var i,s,n,o;return yn.of(new mr(typeof e=="number"?M.cursor(e):e,(i=t.y)!==null&&i!==void 0?i:"nearest",(s=t.x)!==null&&s!==void 0?s:"nearest",(n=t.yMargin)!==null&&n!==void 0?n:5,(o=t.xMargin)!==null&&o!==void 0?o:5))}scrollSnapshot(){let{scrollTop:e,scrollLeft:t}=this.scrollDOM,i=this.viewState.scrollAnchorAt(e);return yn.of(new mr(M.cursor(i.from),"start","start",i.top-e,t,!0))}setTabFocusMode(e){e==null?this.inputState.tabFocusMode=this.inputState.tabFocusMode<0?0:-1:typeof e=="boolean"?this.inputState.tabFocusMode=e?0:-1:this.inputState.tabFocusMode!=0&&(this.inputState.tabFocusMode=Date.now()+e)}static domEventHandlers(e){return qe.define(()=>({}),{eventHandlers:e})}static domEventObservers(e){return qe.define(()=>({}),{eventObservers:e})}static theme(e,t){let i=kt.newName(),s=[kn.of(i),cr.of(Ca(`.${i}`,e))];return t&&t.dark&&s.push(Ta.of(!0)),s}static baseTheme(e){return vt.lowest(cr.of(Ca("."+Pa,e,Bp)))}static findFromDOM(e){var t;let i=e.querySelector(".cm-content"),s=i&&Se.get(i)||Se.get(e);return((t=s==null?void 0:s.root)===null||t===void 0?void 0:t.view)||null}};z.styleModule=cr;z.inputHandler=up;z.clipboardInputFilter=$a;z.clipboardOutputFilter=Fa;z.scrollHandler=_p;z.focusChangeEffect=pp;z.perLineTextDirection=mp;z.exceptionSink=dp;z.updateListener=ia;z.editable=oi;z.mouseSelectionStyle=cp;z.dragMovesSelection=fp;z.clickAddsSelectionRange=hp;z.decorations=Gn;z.blockWrappers=Op;z.outerDecorations=za;z.atomicRanges=Tr;z.bidiIsolatedRanges=vp;z.cursorScrollMargin=W.define({combine:r=>{let e=5,t=5;for(let i of r)typeof i=="number"?e=t=i:{x:e,y:t}=i;return{x:e,y:t}}});z.scrollMargins=wp;z.darkTheme=Ta;z.cspNonce=W.define({combine:r=>r.length?r[0]:""});z.contentAttributes=Wa;z.editorAttributes=bp;z.lineWrapping=z.contentAttributes.of({class:"cm-lineWrapping"});z.announce=re.define();var qv=4096,Qu={},jn=class r{constructor(e,t,i,s,n,o){this.from=e,this.to=t,this.dir=i,this.isolates=s,this.fresh=n,this.order=o}static update(e,t){if(t.empty&&!e.some(n=>n.fresh))return e;let i=[],s=e.length?e[e.length-1].dir:_e.LTR;for(let n=Math.max(0,e.length-10);n<e.length;n++){let o=e[n];o.dir==s&&!t.touchesRange(o.from,o.to)&&i.push(new r(t.mapPos(o.from,1),t.mapPos(o.to,-1),o.dir,o.isolates,!1,o.order))}return i}};function qu(r,e,t){for(let i=r.state.facet(e),s=i.length-1;s>=0;s--){let n=i[s],o=typeof n=="function"?n(r):n;o&&Qa(o,t)}return t}var Bv=$.mac?"mac":$.windows?"win":$.linux?"linux":"key";function $v(r,e){let t=r.split(/-(?!$)/),i=t[t.length-1];i=="Space"&&(i=" ");let s,n,o,l;for(let a=0;a<t.length-1;++a){let h=t[a];if(/^(cmd|meta|m)$/i.test(h))l=!0;else if(/^a(lt)?$/i.test(h))s=!0;else if(/^(c|ctrl|control)$/i.test(h))n=!0;else if(/^s(hift)?$/i.test(h))o=!0;else if(/^mod$/i.test(h))e=="mac"?l=!0:n=!0;else throw new Error("Unrecognized modifier name: "+h)}return s&&(i="Alt-"+i),n&&(i="Ctrl-"+i),l&&(i="Meta-"+i),o&&(i="Shift-"+i),i}function xn(r,e,t){return e.altKey&&(r="Alt-"+r),e.ctrlKey&&(r="Ctrl-"+r),e.metaKey&&(r="Meta-"+r),t!==!1&&e.shiftKey&&(r="Shift-"+r),r}var Fv=vt.default(z.domEventHandlers({keydown(r,e){return Wp($p(e.state),r,e,"editor")}})),$s=W.define({enables:Fv}),Bu=new WeakMap;function $p(r){let e=r.facet($s),t=Bu.get(e);return t||Bu.set(e,t=zv(e.reduce((i,s)=>i.concat(s),[]))),t}function Fp(r,e,t){return Wp($p(r.state),e,r,t)}var bi=null,Wv=4e3;function zv(r,e=Bv){let t=Object.create(null),i=Object.create(null),s=(o,l)=>{let a=i[o];if(a==null)i[o]=l;else if(a!=l)throw new Error("Key binding "+o+" is used both as a regular binding and as a multi-stroke prefix")},n=(o,l,a,h,c)=>{var u,p;let y=t[o]||(t[o]=Object.create(null)),O=l.split(/ (?!$)/).map(k=>$v(k,e));for(let k=1;k<O.length;k++){let T=O.slice(0,k).join(" ");s(T,!0),y[T]||(y[T]={preventDefault:!0,stopPropagation:!1,run:[C=>{let Q=bi={view:C,prefix:T,scope:o};return setTimeout(()=>{bi==Q&&(bi=null)},Wv),!0}]})}let b=O.join(" ");s(b,!1);let v=y[b]||(y[b]={preventDefault:!1,stopPropagation:!1,run:((p=(u=y._any)===null||u===void 0?void 0:u.run)===null||p===void 0?void 0:p.slice())||[]});a&&v.run.push(a),h&&(v.preventDefault=!0),c&&(v.stopPropagation=!0)};for(let o of r){let l=o.scope?o.scope.split(" "):["editor"];if(o.any)for(let h of l){let c=t[h]||(t[h]=Object.create(null));c._any||(c._any={preventDefault:!1,stopPropagation:!1,run:[]});let{any:u}=o;for(let p in c)c[p].run.push(y=>u(y,Ra))}let a=o[e]||o.key;if(a)for(let h of l)n(h,a,o.run,o.preventDefault,o.stopPropagation),o.shift&&n(h,"Shift-"+a,o.shift,o.preventDefault,o.stopPropagation)}return t}var Ra=null;function Wp(r,e,t,i){Ra=e;let s=cu(e),n=Ge(s,0),o=ct(n)==s.length&&s!=" ",l="",a=!1,h=!1,c=!1;bi&&bi.view==t&&bi.scope==i&&(l=bi.prefix+" ",Ap.indexOf(e.keyCode)<0&&(h=!0,bi=null));let u=new Set,p=v=>{if(v){for(let k of v.run)if(!u.has(k)&&(u.add(k),k(t)))return v.stopPropagation&&(c=!0),!0;v.preventDefault&&(v.stopPropagation&&(c=!0),h=!0)}return!1},y=r[i],O,b;return y&&(p(y[l+xn(s,e,!o)])?a=!0:o&&(e.altKey||e.metaKey||e.ctrlKey)&&!($.windows&&e.ctrlKey&&e.altKey)&&!($.mac&&e.altKey&&!(e.ctrlKey||e.metaKey))&&(O=ni[e.keyCode])&&O!=s?(p(y[l+xn(O,e,!0)])||e.shiftKey&&(b=Ts[e.keyCode])!=s&&b!=O&&p(y[l+xn(b,e,!1)]))&&(a=!0):o&&e.shiftKey&&p(y[l+xn(s,e,!0)])&&(a=!0),!a&&p(y._any)&&(a=!0)),h&&(a=!0),a&&c&&e.stopPropagation(),Ra=null,a}var Xi=class r{constructor(e,t,i,s,n){this.className=e,this.left=t,this.top=i,this.width=s,this.height=n}draw(){let e=document.createElement("div");return e.className=this.className,this.adjust(e),e}update(e,t){return t.className!=this.className?!1:(this.adjust(e),!0)}adjust(e){e.style.left=this.left+"px",e.style.top=this.top+"px",this.width!=null&&(e.style.width=this.width+"px"),e.style.height=this.height+"px"}eq(e){return this.left==e.left&&this.top==e.top&&this.width==e.width&&this.height==e.height&&this.className==e.className}static forRange(e,t,i){if(i.empty){let s=e.coordsAtPos(i.head,i.assoc||1);if(!s)return[];let n=zp(e);return[new r(t,s.left-n.left,s.top-n.top,null,s.bottom-s.top)]}else return jv(e,t,i)}};function zp(r){let e=r.scrollDOM.getBoundingClientRect();return{left:(r.textDirection==_e.LTR?e.left:e.right-r.scrollDOM.clientWidth*r.scaleX)-r.scrollDOM.scrollLeft*r.scaleX,top:e.top-r.scrollDOM.scrollTop*r.scaleY}}function $u(r,e,t,i){let s=r.coordsAtPos(e,t*2);if(!s)return i;let n=r.dom.getBoundingClientRect(),o=(s.top+s.bottom)/2,l=r.posAtCoords({x:n.left+1,y:o}),a=r.posAtCoords({x:n.right-1,y:o});return l==null||a==null?i:{from:Math.max(i.from,Math.min(l,a)),to:Math.min(i.to,Math.max(l,a))}}function jv(r,e,t){if(t.to<=r.viewport.from||t.from>=r.viewport.to)return[];let i=Math.max(t.from,r.viewport.from),s=Math.min(t.to,r.viewport.to),n=r.textDirection==_e.LTR,o=r.contentDOM,l=o.getBoundingClientRect(),a=zp(r),h=o.querySelector(".cm-line"),c=h&&window.getComputedStyle(h),u=l.left+(c?parseInt(c.paddingLeft)+Math.min(0,parseInt(c.textIndent)):0),p=l.right-(c?parseInt(c.paddingRight):0),y=ca(r,i,1),O=ca(r,s,-1),b=y.type==He.Text?y:null,v=O.type==He.Text?O:null;if(b&&(r.lineWrapping||y.widgetLineBreaks)&&(b=$u(r,i,1,b)),v&&(r.lineWrapping||O.widgetLineBreaks)&&(v=$u(r,s,-1,v)),b&&v&&b.from==v.from&&b.to==v.to)return T(C(t.from,t.to,b));{let A=b?C(t.from,null,b):Q(y,!1),R=v?C(null,t.to,v):Q(O,!0),D=[];return(b||y).to<(v||O).from-(b&&v?1:0)||y.widgetLineBreaks>1&&A.bottom+r.defaultLineHeight/2<R.top?D.push(k(u,A.bottom,p,R.top)):A.bottom<R.top&&r.elementAtHeight((A.bottom+R.top)/2).type==He.Text&&(A.bottom=R.top=(A.bottom+R.top)/2),T(A).concat(D).concat(T(R))}function k(A,R,D,F){return new Xi(e,A-a.left,R-a.top,Math.max(0,D-A),F-R)}function T({top:A,bottom:R,horizontal:D}){let F=[];for(let J=0;J<D.length;J+=2)F.push(k(D[J],A,D[J+1],R));return F}function C(A,R,D){let F=1e9,J=-1e9,he=[];function Z(le,ye,We,Ye,gt){let De=r.coordsAtPos(le,le==D.to?-2:2),nt=r.coordsAtPos(We,We==D.from?2:-2);!De||!nt||(F=Math.min(De.top,nt.top,F),J=Math.max(De.bottom,nt.bottom,J),gt==_e.LTR?he.push(n&&ye?u:De.left,n&&Ye?p:nt.right):he.push(!n&&Ye?u:nt.left,!n&&ye?p:De.right))}let U=A??D.from,ee=R??D.to;for(let le of r.visibleRanges)if(le.to>U&&le.from<ee)for(let ye=Math.max(le.from,U),We=Math.min(le.to,ee);;){let Ye=r.state.doc.lineAt(ye);for(let gt of r.bidiSpans(Ye)){let De=gt.from+Ye.from,nt=gt.to+Ye.from;if(De>=We)break;nt>ye&&Z(Math.max(De,ye),A==null&&De<=U,Math.min(nt,We),R==null&&nt>=ee,gt.dir)}if(ye=Ye.to+1,ye>=We)break}return he.length==0&&Z(U,A==null,ee,R==null,r.textDirection),{top:F,bottom:J,horizontal:he}}function Q(A,R){let D=l.top+(R?A.top:A.bottom);return{top:D,bottom:D,horizontal:[]}}}function Hv(r,e){return r.constructor==e.constructor&&r.eq(e)}var Ma=class{constructor(e,t){this.view=e,this.layer=t,this.drawn=[],this.scaleX=1,this.scaleY=1,this.measureReq={read:this.measure.bind(this),write:this.draw.bind(this)},this.dom=e.scrollDOM.appendChild(document.createElement("div")),this.dom.classList.add("cm-layer"),t.above&&this.dom.classList.add("cm-layer-above"),t.class&&this.dom.classList.add(t.class),this.scale(),this.dom.setAttribute("aria-hidden","true"),this.setOrder(e.state),e.requestMeasure(this.measureReq),t.mount&&t.mount(this.dom,e)}update(e){e.startState.facet(Cn)!=e.state.facet(Cn)&&this.setOrder(e.state),(this.layer.update(e,this.dom)||e.geometryChanged)&&(this.scale(),e.view.requestMeasure(this.measureReq))}docViewUpdate(e){this.layer.updateOnDocViewUpdate!==!1&&e.requestMeasure(this.measureReq)}setOrder(e){let t=0,i=e.facet(Cn);for(;t<i.length&&i[t]!=this.layer;)t++;this.dom.style.zIndex=String((this.layer.above?150:-1)-t)}measure(){return this.layer.markers(this.view)}scale(){let{scaleX:e,scaleY:t}=this.view;(e!=this.scaleX||t!=this.scaleY)&&(this.scaleX=e,this.scaleY=t,this.dom.style.transform=`scale(${1/e}, ${1/t})`)}draw(e){if(e.length!=this.drawn.length||e.some((t,i)=>!Hv(t,this.drawn[i]))){let t=this.dom.firstChild,i=0;for(let s of e)s.update&&t&&s.constructor&&this.drawn[i].constructor&&s.update(t,this.drawn[i])?(t=t.nextSibling,i++):this.dom.insertBefore(s.draw(),t);for(;t;){let s=t.nextSibling;t.remove(),t=s}this.drawn=e,$.webkit&&(this.dom.style.display=this.dom.firstChild?"":"none")}}destroy(){this.layer.destroy&&this.layer.destroy(this.dom,this.view),this.dom.remove()}},Cn=W.define();function jp(r){return[qe.define(e=>new Ma(e,r)),Cn.of(r)]}var Bs=W.define({combine(r){return wt(r,{cursorBlinkRate:1200,drawRangeCursor:!0,iosSelectionHandles:!0},{cursorBlinkRate:(e,t)=>Math.min(e,t),drawRangeCursor:(e,t)=>e||t})}});function Hp(r={}){return[Bs.of(r),Vv,Uv,Xv,gp.of(!0)]}function Vp(r){return r.startState.facet(Bs)!=r.state.facet(Bs)}var Vv=jp({above:!0,markers(r){let{state:e}=r,t=e.facet(Bs),i=[];for(let s of e.selection.ranges){let n=s==e.selection.main;if(s.empty||t.drawRangeCursor&&!(n&&$.ios&&t.iosSelectionHandles)){let o=n?"cm-cursor cm-cursor-primary":"cm-cursor cm-cursor-secondary",l=s.empty?s:M.cursor(s.head,s.assoc);for(let a of Xi.forRange(r,o,l))i.push(a)}}return i},update(r,e){r.transactions.some(i=>i.selection)&&(e.style.animationName=e.style.animationName=="cm-blink"?"cm-blink2":"cm-blink");let t=Vp(r);return t&&Fu(r.state,e),r.docChanged||r.selectionSet||t},mount(r,e){Fu(e.state,r)},class:"cm-cursorLayer"});function Fu(r,e){e.style.animationDuration=r.facet(Bs).cursorBlinkRate+"ms"}var Uv=jp({above:!1,markers(r){let e=[],{main:t,ranges:i}=r.state.selection;for(let s of i)if(!s.empty)for(let n of Xi.forRange(r,"cm-selectionBackground",s))e.push(n);if($.ios&&!t.empty&&r.state.facet(Bs).iosSelectionHandles){for(let s of Xi.forRange(r,"cm-selectionHandle cm-selectionHandle-start",M.cursor(t.from,1)))e.push(s);for(let s of Xi.forRange(r,"cm-selectionHandle cm-selectionHandle-end",M.cursor(t.to,1)))e.push(s)}return e},update(r,e){return r.docChanged||r.selectionSet||r.viewportChanged||Vp(r)},class:"cm-selectionLayer"}),Gv=$.gecko&&$.gecko_version==153?"#ffffff01":"transparent",Xv=vt.highest(z.theme({".cm-line":{"& ::selection, &::selection":{backgroundColor:`${Gv} !important`},caretColor:"transparent !important"},".cm-content":{caretColor:"transparent !important","& :focus":{caretColor:"initial !important","&::selection, & ::selection":{backgroundColor:"Highlight !important"}}}}));var SC=/x/.unicode!=null?"gu":"g";function Up(){return Yv}var Jv=K.line({class:"cm-activeLine"}),Yv=qe.fromClass(class{constructor(r){this.decorations=this.getDeco(r)}update(r){(r.docChanged||r.selectionSet)&&(this.decorations=this.getDeco(r.view))}getDeco(r){let e=-1,t=[];for(let i of r.state.selection.ranges){let s=r.lineBlockAt(i.head);s.from>e&&(t.push(Jv.range(s.from)),e=s.from)}return K.set(t)}},{decorations:r=>r.decorations});var Sn="-10000px",Da=class{constructor(e,t,i,s){this.facet=t,this.createTooltipView=i,this.removeTooltipView=s,this.input=e.state.facet(t),this.tooltips=this.input.filter(o=>o);let n=null;this.tooltipViews=this.tooltips.map(o=>n=i(o,n))}update(e,t){var i;let s=e.state.facet(this.facet),n=s.filter(a=>a);if(s===this.input){for(let a of this.tooltipViews)a.update&&a.update(e);return!1}let o=[],l=t?[]:null;for(let a=0;a<n.length;a++){let h=n[a],c=-1;if(h){for(let u=0;u<this.tooltips.length;u++){let p=this.tooltips[u];p&&p.create==h.create&&(c=u)}if(c<0)o[a]=this.createTooltipView(h,a?o[a-1]:null),l&&(l[a]=!!h.above);else{let u=o[a]=this.tooltipViews[c];l&&(l[a]=t[c]),u.update&&u.update(e)}}}for(let a of this.tooltipViews)o.indexOf(a)<0&&(this.removeTooltipView(a),(i=a.destroy)===null||i===void 0||i.call(a));return t&&(l.forEach((a,h)=>t[h]=a),t.length=l.length),this.input=s,this.tooltips=n,this.tooltipViews=o,!0}};function Kv(r){let e=r.dom.ownerDocument.documentElement;return{top:0,left:0,bottom:e.clientHeight,right:e.clientWidth}}var Hl=W.define({combine:r=>{var e,t,i;return{position:$.ios?"absolute":((e=r.find(s=>s.position))===null||e===void 0?void 0:e.position)||"fixed",parent:((t=r.find(s=>s.parent))===null||t===void 0?void 0:t.parent)||null,tooltipSpace:((i=r.find(s=>s.tooltipSpace))===null||i===void 0?void 0:i.tooltipSpace)||Kv}}}),Wu=new WeakMap,Gp=qe.fromClass(class{constructor(r){this.view=r,this.above=[],this.inView=!0,this.madeAbsolute=!1,this.lastTransaction=0,this.measureTimeout=-1;let e=r.state.facet(Hl);this.position=e.position,this.parent=e.parent,this.classes=r.themeClasses,this.createContainer(),this.measureReq={read:this.readMeasure.bind(this),write:this.writeMeasure.bind(this),key:this},this.resizeObserver=typeof ResizeObserver=="function"?new ResizeObserver(()=>this.measureSoon()):null,this.manager=new Da(r,Va,(t,i)=>this.createTooltip(t,i),t=>{this.resizeObserver&&this.resizeObserver.unobserve(t.dom),t.dom.remove()}),this.above=this.manager.tooltips.map(t=>!!t.above),this.intersectionObserver=typeof IntersectionObserver=="function"?new IntersectionObserver(t=>{Date.now()>this.lastTransaction-50&&t.length>0&&t[t.length-1].intersectionRatio<1&&this.measureSoon()},{threshold:[1]}):null,this.observeIntersection(),r.win.addEventListener("resize",this.measureSoon=this.measureSoon.bind(this)),this.maybeMeasure()}createContainer(){this.parent?(this.container=document.createElement("div"),this.container.style.position="relative",this.container.className=this.view.themeClasses,this.parent.appendChild(this.container)):this.container=this.view.dom}observeIntersection(){if(this.intersectionObserver){this.intersectionObserver.disconnect();for(let r of this.manager.tooltipViews)this.intersectionObserver.observe(r.dom)}}measureSoon(){this.measureTimeout<0&&(this.measureTimeout=setTimeout(()=>{this.measureTimeout=-1,this.maybeMeasure()},50))}update(r){r.transactions.length&&(this.lastTransaction=Date.now());let e=this.manager.update(r,this.above);e&&this.observeIntersection();let t=e||r.geometryChanged,i=r.state.facet(Hl);if(i.position!=this.position&&!this.madeAbsolute){this.position=i.position;for(let s of this.manager.tooltipViews)s.dom.style.position=this.position;t=!0}if(i.parent!=this.parent){this.parent&&this.container.remove(),this.parent=i.parent,this.createContainer();for(let s of this.manager.tooltipViews)this.container.appendChild(s.dom);t=!0}else this.parent&&this.view.themeClasses!=this.classes&&(this.classes=this.container.className=this.view.themeClasses);t&&this.maybeMeasure()}createTooltip(r,e){let t=r.create(this.view),i=e?e.dom:null;if(t.dom.classList.add("cm-tooltip"),r.arrow&&!t.dom.querySelector(".cm-tooltip > .cm-tooltip-arrow")){let s=document.createElement("div");s.className="cm-tooltip-arrow",t.dom.appendChild(s)}return t.dom.style.position=this.position,t.dom.style.top=Sn,t.dom.style.left="0px",this.container.insertBefore(t.dom,i),t.mount&&t.mount(this.view),this.resizeObserver&&this.resizeObserver.observe(t.dom),t}destroy(){var r,e,t;this.view.win.removeEventListener("resize",this.measureSoon);for(let i of this.manager.tooltipViews)i.dom.remove(),(r=i.destroy)===null||r===void 0||r.call(i);this.parent&&this.container.remove(),(e=this.resizeObserver)===null||e===void 0||e.disconnect(),(t=this.intersectionObserver)===null||t===void 0||t.disconnect(),clearTimeout(this.measureTimeout)}readMeasure(){let r=1,e=1,t=!1;if(this.position=="fixed"&&this.manager.tooltipViews.length){let{dom:n}=this.manager.tooltipViews[0];if($.safari){let o=n.getBoundingClientRect();t=Math.abs(o.top+1e4)>1||Math.abs(o.left)>1}else t=!!n.offsetParent&&n.offsetParent!=this.container.ownerDocument.body}if(t||this.position=="absolute")if(this.parent){let n=this.parent.getBoundingClientRect();n.width&&n.height&&(r=n.width/this.parent.offsetWidth,e=n.height/this.parent.offsetHeight)}else({scaleX:r,scaleY:e}=this.view.viewState);let i=this.view.scrollDOM.getBoundingClientRect(),s=ja(this.view);return{visible:{left:i.left+s.left,top:i.top+s.top,right:i.right-s.right,bottom:i.bottom-s.bottom},parent:this.parent?this.container.getBoundingClientRect():this.view.dom.getBoundingClientRect(),pos:this.manager.tooltips.map((n,o)=>{let l=this.manager.tooltipViews[o];return l.getCoords?l.getCoords(n.pos):this.view.coordsAtPos(n.pos)}),size:this.manager.tooltipViews.map(({dom:n})=>n.getBoundingClientRect()),space:this.view.state.facet(Hl).tooltipSpace(this.view),scaleX:r,scaleY:e,makeAbsolute:t}}writeMeasure(r){var e;if(r.makeAbsolute){this.madeAbsolute=!0,this.position="absolute";for(let l of this.manager.tooltipViews)l.dom.style.position="absolute"}let{visible:t,space:i,scaleX:s,scaleY:n}=r,o=[];for(let l=0;l<this.manager.tooltips.length;l++){let a=this.manager.tooltips[l],h=this.manager.tooltipViews[l],{dom:c}=h,u=r.pos[l],p=r.size[l];if(!u||a.clip!==!1&&(u.bottom<=Math.max(t.top,i.top)||u.top>=Math.min(t.bottom,i.bottom)||u.right<Math.max(t.left,i.left)-.1||u.left>Math.min(t.right,i.right)+.1)){c.style.top=Sn;continue}let y=a.arrow?h.dom.querySelector(".cm-tooltip-arrow"):null,O=y?7:0,b=p.right-p.left,v=(e=Wu.get(h))!==null&&e!==void 0?e:p.bottom-p.top,k=h.offset||ew,T=this.view.textDirection==_e.LTR,C=p.width>i.right-i.left?T?i.left:i.right-p.width:T?Math.max(i.left,Math.min(u.left-(y?14:0)+k.x,i.right-b)):Math.min(Math.max(i.left,u.left-b+(y?14:0)-k.x),i.right-b),Q=this.above[l];!a.strictSide&&(Q?u.top-v-O-k.y<i.top:u.bottom+v+O+k.y>i.bottom)&&Q==i.bottom-u.bottom>u.top-i.top&&(Q=this.above[l]=!Q);let A=(Q?u.top-i.top:i.bottom-u.bottom)-O;if(A<v&&h.resize!==!1){if(A<this.view.defaultLineHeight){c.style.top=Sn;continue}Wu.set(h,v),c.style.height=(v=A)/n+"px"}else c.style.height&&(c.style.height="");let R=Q?u.top-v-O-k.y:u.bottom+O+k.y,D=C+b;if(h.overlap!==!0)for(let F of o)F.left<D&&F.right>C&&F.top<R+v&&F.bottom>R&&(R=Q?F.top-v-2-O:F.bottom+O+2);if(this.position=="absolute"?(c.style.top=(R-r.parent.top)/n+"px",zu(c,(C-r.parent.left)/s)):(c.style.top=R/n+"px",zu(c,C/s)),y){let F=u.left+(T?k.x:-k.x)-(C+14-7);y.style.left=F/s+"px"}h.overlap!==!0&&o.push({left:C,top:R,right:D,bottom:R+v}),c.classList.toggle("cm-tooltip-above",Q),c.classList.toggle("cm-tooltip-below",!Q),h.positioned&&h.positioned(r.space)}}maybeMeasure(){if(this.manager.tooltips.length&&(this.view.inView&&this.view.requestMeasure(this.measureReq),this.inView!=this.view.inView&&(this.inView=this.view.inView,!this.inView)))for(let r of this.manager.tooltipViews)r.dom.style.top=Sn}},{eventObservers:{scroll(){this.maybeMeasure()}}});function zu(r,e){let t=parseInt(r.style.left,10);(isNaN(t)||Math.abs(e-t)>1)&&(r.style.left=e+"px")}var Zv=z.baseTheme({".cm-tooltip":{zIndex:500,boxSizing:"border-box"},"&light .cm-tooltip":{border:"1px solid #bbb",backgroundColor:"#f5f5f5"},"&light .cm-tooltip-section:not(:first-child)":{borderTop:"1px solid #bbb"},"&dark .cm-tooltip":{backgroundColor:"#333338",color:"white"},".cm-tooltip-arrow":{height:"7px",width:`${7*2}px`,position:"absolute",zIndex:-1,overflow:"hidden","&:before, &:after":{content:"''",position:"absolute",width:0,height:0,borderLeft:"7px solid transparent",borderRight:"7px solid transparent"},".cm-tooltip-above &":{bottom:"-7px","&:before":{borderTop:"7px solid #bbb"},"&:after":{borderTop:"7px solid #f5f5f5",bottom:"1px"}},".cm-tooltip-below &":{top:"-7px","&:before":{borderBottom:"7px solid #bbb"},"&:after":{borderBottom:"7px solid #f5f5f5",top:"1px"}}},"&dark .cm-tooltip .cm-tooltip-arrow":{"&:before":{borderTopColor:"#333338",borderBottomColor:"#333338"},"&:after":{borderTopColor:"transparent",borderBottomColor:"transparent"}}}),ew={x:0,y:0},Va=W.define({enables:[Gp,Zv]});function Ua(r,e){let t=r.plugin(Gp);if(!t)return null;let i=t.manager.tooltips.indexOf(e);return i<0?null:t.manager.tooltipViews[i]}var ju=W.define({combine(r){let e,t;for(let i of r)e=e||i.topContainer,t=t||i.bottomContainer;return{topContainer:e,bottomContainer:t}}});function Jn(r,e){let t=r.plugin(Xp),i=t?t.specs.indexOf(e):-1;return i>-1?t.panels[i]:null}var Xp=qe.fromClass(class{constructor(r){this.input=r.state.facet(Sr),this.specs=this.input.filter(t=>t),this.panels=this.specs.map(t=>t(r));let e=r.state.facet(ju);this.top=new As(r,!0,e.topContainer),this.bottom=new As(r,!1,e.bottomContainer),this.top.sync(this.panels.filter(t=>t.top)),this.bottom.sync(this.panels.filter(t=>!t.top));for(let t of this.panels)t.dom.classList.add("cm-panel"),t.mount&&t.mount()}update(r){let e=r.state.facet(ju);this.top.container!=e.topContainer&&(this.top.sync([]),this.top=new As(r.view,!0,e.topContainer)),this.bottom.container!=e.bottomContainer&&(this.bottom.sync([]),this.bottom=new As(r.view,!1,e.bottomContainer)),this.top.syncClasses(),this.bottom.syncClasses();let t=r.state.facet(Sr);if(t!=this.input){let i=t.filter(a=>a),s=[],n=[],o=[],l=[];for(let a of i){let h=this.specs.indexOf(a),c;h<0?(c=a(r.view),l.push(c)):(c=this.panels[h],c.update&&c.update(r)),s.push(c),(c.top?n:o).push(c)}this.specs=i,this.panels=s,this.top.sync(n),this.bottom.sync(o);for(let a of l)a.dom.classList.add("cm-panel"),a.mount&&a.mount()}else for(let i of this.panels)i.update&&i.update(r)}destroy(){this.top.sync([]),this.bottom.sync([])}},{provide:r=>z.scrollMargins.of(e=>{let t=e.plugin(r);return t&&{top:t.top.scrollMargin(),bottom:t.bottom.scrollMargin()}})}),As=class{constructor(e,t,i){this.view=e,this.top=t,this.container=i,this.dom=void 0,this.classes="",this.panels=[],this.syncClasses()}sync(e){for(let t of this.panels)t.destroy&&e.indexOf(t)<0&&t.destroy();this.panels=e,this.syncDOM()}syncDOM(){if(this.panels.length==0){this.dom&&(this.dom.remove(),this.dom=void 0);return}if(!this.dom){this.dom=document.createElement("div"),this.dom.className=this.top?"cm-panels cm-panels-top":"cm-panels cm-panels-bottom";let t=this.container||this.view.dom;t.insertBefore(this.dom,this.top?t.firstChild:null)}let e=this.dom.firstChild;for(let t of this.panels)if(t.dom.parentNode==this.dom){for(;e!=t.dom;)e=Hu(e);e=e.nextSibling}else this.dom.insertBefore(t.dom,e);for(;e;)e=Hu(e)}scrollMargin(){return!this.dom||this.container?0:Math.max(0,this.top?this.dom.getBoundingClientRect().bottom-Math.max(0,this.view.scrollDOM.getBoundingClientRect().top):Math.min(innerHeight,this.view.scrollDOM.getBoundingClientRect().bottom)-this.dom.getBoundingClientRect().top)}syncClasses(){if(!(!this.container||this.classes==this.view.themeClasses)){for(let e of this.classes.split(" "))e&&this.container.classList.remove(e);for(let e of(this.classes=this.view.themeClasses).split(" "))e&&this.container.classList.add(e)}}};function Hu(r){let e=r.nextSibling;return r.remove(),e}var Sr=W.define({enables:Xp});function Jp(r,e){let t,i=new Promise(o=>t=o),s=o=>tw(o,e,t);r.state.field(En,!1)?r.dispatch({effects:Kp.of(s)}):r.dispatch({effects:re.appendConfig.of(En.init(()=>[s]))});let n=Zp.of(s);return{close:n,result:i.then(o=>((r.win.queueMicrotask||(a=>r.win.setTimeout(a,10)))(()=>{r.state.field(En).indexOf(s)>-1&&r.dispatch({effects:n})}),o))}}function Yp(r,e){let t=r.state.field(En,!1)||[];for(let i of t){let s=Jn(r,i);if(s&&s.dom.classList.contains(e))return s}return null}var En=Qe.define({create(){return[]},update(r,e){for(let t of e.effects)t.is(Kp)?r=[t.value].concat(r):t.is(Zp)&&(r=r.filter(i=>i!=t.value));return r},provide:r=>Sr.computeN([r],e=>e.field(r))}),Kp=re.define(),Zp=re.define();function tw(r,e,t){let i=e.content?e.content(r,()=>o(null)):null;if(!i){if(i=Ee("form"),e.input){let l=Ee("input",e.input);/^(text|password|number|email|tel|url)$/.test(l.type)&&l.classList.add("cm-textfield"),l.name||(l.name="input"),i.appendChild(Ee("label",(e.label||"")+": ",l))}else i.appendChild(document.createTextNode(e.label||""));i.appendChild(document.createTextNode(" ")),i.appendChild(Ee("button",{class:"cm-button",type:"submit"},e.submitLabel||"OK"))}let s=i.nodeName=="FORM"?[i]:i.querySelectorAll("form");for(let l=0;l<s.length;l++){let a=s[l];a.addEventListener("keydown",h=>{h.keyCode==27?(h.preventDefault(),o(null)):h.keyCode==13&&(h.preventDefault(),o(a))}),a.addEventListener("submit",h=>{h.preventDefault(),o(a)})}let n=Ee("div",i,Ee("button",{onclick:()=>o(null),"aria-label":r.state.phrase("close"),class:"cm-dialog-close",type:"button"},["\xD7"]));e.class&&(n.className=e.class),n.classList.add("cm-dialog");function o(l){n.contains(n.ownerDocument.activeElement)&&r.focus(),t(l)}return{dom:n,top:e.top,mount:()=>{if(e.focus){let l;typeof e.focus=="string"?l=i.querySelector(e.focus):l=i.querySelector("input")||i.querySelector("button"),l&&"select"in l?l.select():l&&"focus"in l&&l.focus()}}}}var qt=class extends Ot{compare(e){return this==e||this.constructor==e.constructor&&this.eq(e)}eq(e){return!1}destroy(e){}};qt.prototype.elementClass="";qt.prototype.toDOM=void 0;qt.prototype.mapMode=Le.TrackBefore;qt.prototype.startSide=qt.prototype.endSide=-1;qt.prototype.point=!0;var An=W.define(),iw=W.define();var Rn=W.define();var Na=W.define({combine:r=>r.some(e=>e)});function sw(r){let e=[rw];return r&&r.fixed===!1&&e.push(Na.of(!0)),e}var rw=qe.fromClass(class{constructor(r){this.view=r,this.domAfter=null,this.prevViewport=r.viewport,this.dom=document.createElement("div"),this.dom.className="cm-gutters cm-gutters-before",this.dom.setAttribute("aria-hidden","true"),this.dom.style.minHeight=this.view.contentHeight/this.view.scaleY+"px",this.gutters=r.state.facet(Rn).map(e=>new Hn(r,e)),this.fixed=!r.state.facet(Na);for(let e of this.gutters)e.config.side=="after"?this.getDOMAfter().appendChild(e.dom):this.dom.appendChild(e.dom);this.fixed&&(this.dom.style.position="sticky"),this.syncGutters(!1),r.scrollDOM.insertBefore(this.dom,r.contentDOM)}getDOMAfter(){return this.domAfter||(this.domAfter=document.createElement("div"),this.domAfter.className="cm-gutters cm-gutters-after",this.domAfter.setAttribute("aria-hidden","true"),this.domAfter.style.minHeight=this.view.contentHeight/this.view.scaleY+"px",this.domAfter.style.position=this.fixed?"sticky":"",this.view.scrollDOM.appendChild(this.domAfter)),this.domAfter}update(r){if(this.updateGutters(r)){let e=this.prevViewport,t=r.view.viewport,i=Math.min(e.to,t.to)-Math.max(e.from,t.from);this.syncGutters(i<(t.to-t.from)*.8)}if(r.geometryChanged){let e=this.view.contentHeight/this.view.scaleY+"px";this.dom.style.minHeight=e,this.domAfter&&(this.domAfter.style.minHeight=e)}this.view.state.facet(Na)!=!this.fixed&&(this.fixed=!this.fixed,this.dom.style.position=this.fixed?"sticky":"",this.domAfter&&(this.domAfter.style.position=this.fixed?"sticky":"")),this.prevViewport=r.view.viewport}syncGutters(r){let e=this.dom.nextSibling;r&&(this.dom.remove(),this.domAfter&&this.domAfter.remove());let t=ce.iter(this.view.state.facet(An),this.view.viewport.from),i=[],s=this.gutters.map(n=>new La(n,this.view.viewport,-this.view.documentPadding.top));for(let n of this.view.viewportLineBlocks)if(i.length&&(i=[]),Array.isArray(n.type)){let o=!0;for(let l of n.type)if(l.type==He.Text&&o){Ia(t,i,l.from);for(let a of s)a.line(this.view,l,i);o=!1}else if(l.widget)for(let a of s)a.widget(this.view,l)}else if(n.type==He.Text){Ia(t,i,n.from);for(let o of s)o.line(this.view,n,i)}else if(n.widget)for(let o of s)o.widget(this.view,n);for(let n of s)n.finish();r&&(this.view.scrollDOM.insertBefore(this.dom,e),this.domAfter&&this.view.scrollDOM.appendChild(this.domAfter))}updateGutters(r){let e=r.startState.facet(Rn),t=r.state.facet(Rn),i=r.docChanged||r.heightChanged||r.viewportChanged||!ce.eq(r.startState.facet(An),r.state.facet(An),r.view.viewport.from,r.view.viewport.to);if(e==t)for(let s of this.gutters)s.update(r)&&(i=!0);else{i=!0;let s=[];for(let n of t){let o=e.indexOf(n);o<0?s.push(new Hn(this.view,n)):(this.gutters[o].update(r),s.push(this.gutters[o]))}for(let n of this.gutters)n.dom.remove(),s.indexOf(n)<0&&n.destroy();for(let n of s)n.config.side=="after"?this.getDOMAfter().appendChild(n.dom):this.dom.appendChild(n.dom);this.gutters=s}return i}destroy(){for(let r of this.gutters)r.destroy();this.dom.remove(),this.domAfter&&this.domAfter.remove()}},{provide:r=>z.scrollMargins.of(e=>{let t=e.plugin(r);if(!t||t.gutters.length==0||!t.fixed)return null;let i=t.dom.offsetWidth*e.scaleX,s=t.domAfter?t.domAfter.offsetWidth*e.scaleX:0;return e.textDirection==_e.LTR?{left:i,right:s}:{right:i,left:s}})});function Vu(r){return Array.isArray(r)?r:[r]}function Ia(r,e,t){for(;r.value&&r.from<=t;)r.from==t&&e.push(r.value),r.next()}var La=class{constructor(e,t,i){this.gutter=e,this.height=i,this.i=0,this.cursor=ce.iter(e.markers,t.from)}addElement(e,t,i){let{gutter:s}=this,n=(t.top-this.height)/e.scaleY,o=t.height/e.scaleY;if(this.i==s.elements.length){let l=new Vn(e,o,n,i);s.elements.push(l),s.dom.appendChild(l.dom)}else s.elements[this.i].update(e,o,n,i);this.height=t.bottom,this.i++}line(e,t,i){let s=[];Ia(this.cursor,s,t.from),i.length&&(s=s.concat(i));let n=this.gutter.config.lineMarker(e,t,s);n&&s.unshift(n);let o=this.gutter;s.length==0&&!o.config.renderEmptyElements||this.addElement(e,t,s)}widget(e,t){let i=this.gutter.config.widgetMarker(e,t.widget,t),s=i?[i]:null;for(let n of e.state.facet(iw)){let o=n(e,t.widget,t);o&&(s||(s=[])).push(o)}s&&this.addElement(e,t,s)}finish(){let e=this.gutter;for(;e.elements.length>this.i;){let t=e.elements.pop();e.dom.removeChild(t.dom),t.destroy()}}},Hn=class{constructor(e,t){this.view=e,this.config=t,this.elements=[],this.spacer=null,this.dom=document.createElement("div"),this.dom.className="cm-gutter"+(this.config.class?" "+this.config.class:"");for(let i in t.domEventHandlers)this.dom.addEventListener(i,s=>{let n=s.target,o;if(n!=this.dom&&this.dom.contains(n)){for(;n.parentNode!=this.dom;)n=n.parentNode;let a=n.getBoundingClientRect();o=(a.top+a.bottom)/2}else o=s.clientY;let l=e.lineBlockAtHeight(o-e.documentTop);t.domEventHandlers[i](e,l,s)&&s.preventDefault()});this.markers=Vu(t.markers(e)),t.initialSpacer&&(this.spacer=new Vn(e,0,0,[t.initialSpacer(e)]),this.dom.appendChild(this.spacer.dom),this.spacer.dom.style.cssText+="visibility: hidden; pointer-events: none")}update(e){let t=this.markers;if(this.markers=Vu(this.config.markers(e.view)),this.spacer&&this.config.updateSpacer){let s=this.config.updateSpacer(this.spacer.markers[0],e);s!=this.spacer.markers[0]&&this.spacer.update(e.view,0,0,[s])}let i=e.view.viewport;return!ce.eq(this.markers,t,i.from,i.to)||(this.config.lineMarkerChange?this.config.lineMarkerChange(e):!1)}destroy(){for(let e of this.elements)e.destroy()}},Vn=class{constructor(e,t,i,s){this.height=-1,this.above=0,this.markers=[],this.dom=document.createElement("div"),this.dom.className="cm-gutterElement",this.update(e,t,i,s)}update(e,t,i,s){this.height!=t&&(this.height=t,this.dom.style.height=t+"px"),this.above!=i&&(this.dom.style.marginTop=(this.above=i)?i+"px":""),nw(this.markers,s)||this.setMarkers(e,s)}setMarkers(e,t){let i="cm-gutterElement",s=this.dom.firstChild;for(let n=0,o=0;;){let l=o,a=n<t.length?t[n++]:null,h=!1;if(a){let c=a.elementClass;c&&(i+=" "+c);for(let u=o;u<this.markers.length;u++)if(this.markers[u].compare(a)){l=u,h=!0;break}}else l=this.markers.length;for(;o<l;){let c=this.markers[o++];if(c.toDOM){c.destroy(s);let u=s.nextSibling;s.remove(),s=u}}if(!a)break;a.toDOM&&(h?s=s.nextSibling:this.dom.insertBefore(a.toDOM(e),s)),h&&o++}this.dom.className=i,this.markers=t}destroy(){this.setMarkers(null,[])}};function nw(r,e){if(r.length!=e.length)return!1;for(let t=0;t<r.length;t++)if(!r[t].compare(e[t]))return!1;return!0}var ow=W.define(),lw=W.define(),Rs=W.define({combine(r){return wt(r,{formatNumber:String,domEventHandlers:{}},{domEventHandlers(e,t){let i=Object.assign({},e);for(let s in t){let n=i[s],o=t[s];i[s]=n?(l,a,h)=>n(l,a,h)||o(l,a,h):o}return i}})}}),Or=class extends qt{constructor(e){super(),this.number=e}eq(e){return this.number==e.number}toDOM(){return document.createTextNode(this.number)}};function Vl(r,e){return r.state.facet(Rs).formatNumber(e,r.state)}var aw=Rn.compute([Rs],r=>({class:"cm-lineNumbers",renderEmptyElements:!1,markers(e){return e.state.facet(ow)},lineMarker(e,t,i){return i.some(s=>s.toDOM)?null:new Or(Vl(e,e.state.doc.lineAt(t.from).number))},widgetMarker:(e,t,i)=>{for(let s of e.state.facet(lw)){let n=s(e,t,i);if(n)return n}return null},lineMarkerChange:e=>e.startState.facet(Rs)!=e.state.facet(Rs),initialSpacer(e){return new Or(Vl(e,Uu(e.state.doc.lines)))},updateSpacer(e,t){let i=Vl(t.view,Uu(t.view.state.doc.lines));return i==e.number?e:new Or(i)},domEventHandlers:r.facet(Rs).domEventHandlers,side:"before"}));function em(r={}){return[Rs.of(r),sw(),aw]}function Uu(r){let e=9;for(;e<r;)e=e*10+9;return e}var hw=new class extends qt{constructor(){super(...arguments),this.elementClass="cm-activeLineGutter"}},fw=An.compute(["selection"],r=>{let e=[],t=-1;for(let i of r.selection.ranges){let s=r.doc.lineAt(i.head).from;s>t&&(t=s,e.push(hw.range(s)))}return ce.of(e)});function tm(){return fw}var cw=0,Pr=class{constructor(e,t){this.from=e,this.to=t}},ie=class{constructor(e={}){this.id=cw++,this.perNode=!!e.perNode,this.deserialize=e.deserialize||(()=>{throw new Error("This node type doesn't define a deserialize function")}),this.combine=e.combine||null}add(e){if(this.perNode)throw new RangeError("Can't add per-node props to node types");return typeof e!="function"&&(e=Xe.match(e)),t=>{let i=e(t);return i===void 0?null:[this,i]}}};ie.closedBy=new ie({deserialize:r=>r.split(" ")});ie.openedBy=new ie({deserialize:r=>r.split(" ")});ie.group=new ie({deserialize:r=>r.split(" ")});ie.isolate=new ie({deserialize:r=>{if(r&&r!="rtl"&&r!="ltr"&&r!="auto")throw new RangeError("Invalid value for isolate: "+r);return r||"auto"}});ie.contextHash=new ie({perNode:!0});ie.lookAhead=new ie({perNode:!0});ie.mounted=new ie({perNode:!0});var Zi=class{constructor(e,t,i,s=!1){this.tree=e,this.overlay=t,this.parser=i,this.bracketed=s}static get(e){return e&&e.props&&e.props[ie.mounted.id]}},dw=Object.create(null),Xe=class r{constructor(e,t,i,s=0){this.name=e,this.props=t,this.id=i,this.flags=s}static define(e){let t=e.props&&e.props.length?Object.create(null):dw,i=(e.top?1:0)|(e.skipped?2:0)|(e.error?4:0)|(e.name==null?8:0),s=new r(e.name||"",t,e.id,i);if(e.props){for(let n of e.props)if(Array.isArray(n)||(n=n(s)),n){if(n[0].perNode)throw new RangeError("Can't store a per-node prop on a node type");t[n[0].id]=n[1]}}return s}prop(e){return this.props[e.id]}get isTop(){return(this.flags&1)>0}get isSkipped(){return(this.flags&2)>0}get isError(){return(this.flags&4)>0}get isAnonymous(){return(this.flags&8)>0}is(e){if(typeof e=="string"){if(this.name==e)return!0;let t=this.prop(ie.group);return t?t.indexOf(e)>-1:!1}return this.id==e}static match(e){let t=Object.create(null);for(let i in e)for(let s of i.split(" "))t[s]=e[i];return i=>{for(let s=i.prop(ie.group),n=-1;n<(s?s.length:0);n++){let o=t[n<0?i.name:s[n]];if(o)return o}}}};Xe.none=new Xe("",Object.create(null),0,8);var Cr=class r{constructor(e){this.types=e;for(let t=0;t<e.length;t++)if(e[t].id!=t)throw new RangeError("Node type ids should correspond to array positions when creating a node set")}extend(...e){let t=[];for(let i of this.types){let s=null;for(let n of e){let o=n(i);if(o){s||(s=Object.assign({},i.props));let l=o[1],a=o[0];a.combine&&a.id in s&&(l=a.combine(s[a.id],l)),s[a.id]=l}}t.push(s?new Xe(i.name,s,i.id,i.flags):i)}return new r(t)}},Yn=new WeakMap,im=new WeakMap,xe;(function(r){r[r.ExcludeBuffers=1]="ExcludeBuffers",r[r.IncludeAnonymous=2]="IncludeAnonymous",r[r.IgnoreMounts=4]="IgnoreMounts",r[r.IgnoreOverlays=8]="IgnoreOverlays",r[r.EnterBracketed=16]="EnterBracketed"})(xe||(xe={}));var Te=class r{constructor(e,t,i,s,n){if(this.type=e,this.children=t,this.positions=i,this.length=s,this.props=null,n&&n.length){this.props=Object.create(null);for(let[o,l]of n)this.props[typeof o=="number"?o:o.id]=l}}toString(){let e=Zi.get(this);if(e&&!e.overlay)return e.tree.toString();let t="";for(let i of this.children){let s=i.toString();s&&(t&&(t+=","),t+=s)}return this.type.name?(/\W/.test(this.type.name)&&!this.type.isError?JSON.stringify(this.type.name):this.type.name)+(t.length?"("+t+")":""):t}cursor(e=0){return new Ar(this.topNode,e)}cursorAt(e,t=0,i=0){let s=Yn.get(this)||this.topNode,n=new Ar(s);return n.moveTo(e,t),Yn.set(this,n._tree),n}get topNode(){return new Pt(this,0,0,null)}resolve(e,t=0){let i=Er(Yn.get(this)||this.topNode,e,t,!1);return Yn.set(this,i),i}resolveInner(e,t=0){let i=Er(im.get(this)||this.topNode,e,t,!0);return im.set(this,i),i}resolveStack(e,t=0){return uw(this,e,t)}iterate(e){let{enter:t,leave:i,from:s=0,to:n=this.length}=e,o=e.mode||0,l=(o&xe.IncludeAnonymous)>0;for(let a=this.cursor(o|xe.IncludeAnonymous);;){let h=!1;if(a.from<=n&&a.to>=s&&(!l&&a.type.isAnonymous||t(a)!==!1)){if(a.firstChild())continue;h=!0}for(;h&&i&&(l||!a.type.isAnonymous)&&i(a),!a.nextSibling();){if(!a.parent())return;h=!0}}}prop(e){return e.perNode?this.props?this.props[e.id]:void 0:this.type.prop(e)}get propValues(){let e=[];if(this.props)for(let t in this.props)e.push([+t,this.props[t]]);return e}balance(e={}){return this.children.length<=8?this:eh(Xe.none,this.children,this.positions,0,this.children.length,0,this.length,(t,i,s)=>new r(this.type,t,i,s,this.propValues),e.makeTree||((t,i,s)=>new r(Xe.none,t,i,s)))}static build(e){return pw(e)}};Te.empty=new Te(Xe.none,[],[],0);var Ga=class r{constructor(e,t){this.buffer=e,this.index=t}get id(){return this.buffer[this.index-4]}get start(){return this.buffer[this.index-3]}get end(){return this.buffer[this.index-2]}get size(){return this.buffer[this.index-1]}get pos(){return this.index}next(){this.index-=4}fork(){return new r(this.buffer,this.index)}},ki=class r{constructor(e,t,i){this.buffer=e,this.length=t,this.set=i}get type(){return Xe.none}toString(){let e=[];for(let t=0;t<this.buffer.length;)e.push(this.childString(t)),t=this.buffer[t+3];return e.join(",")}childString(e){let t=this.buffer[e],i=this.buffer[e+3],s=this.set.types[t],n=s.name;if(/\W/.test(n)&&!s.isError&&(n=JSON.stringify(n)),e+=4,i==e)return n;let o=[];for(;e<i;)o.push(this.childString(e)),e=this.buffer[e+3];return n+"("+o.join(",")+")"}findChild(e,t,i,s,n){let{buffer:o}=this,l=-1;for(let a=e;a!=t&&!(nm(n,s,o[a+1],o[a+2])&&(l=a,i>0));a=o[a+3]);return l}slice(e,t,i){let s=this.buffer,n=new Uint16Array(t-e),o=0;for(let l=e,a=0;l<t;){n[a++]=s[l++],n[a++]=s[l++]-i;let h=n[a++]=s[l++]-i;n[a++]=s[l++]-e,o=Math.max(o,h)}return new r(n,o,this.set)}};function nm(r,e,t,i){switch(r){case-2:return t<e;case-1:return i>=e&&t<e;case 0:return t<e&&i>e;case 1:return t<=e&&i>e;case 2:return i>e;case 4:return!0}}function Er(r,e,t,i){for(var s;r.from==r.to||(t<1?r.from>=e:r.from>e)||(t>-1?r.to<=e:r.to<e);){let o=!i&&r instanceof Pt&&r.index<0?null:r.parent;if(!o)return r;r=o}let n=i?0:xe.IgnoreOverlays;if(i)for(let o=r,l=o.parent;l;o=l,l=o.parent)o instanceof Pt&&o.index<0&&((s=l.enter(e,t,n))===null||s===void 0?void 0:s.from)!=o.from&&(r=l);for(;;){let o=r.enter(e,t,n);if(!o)return r;r=o}}var Zn=class{cursor(e=0){return new Ar(this,e)}getChild(e,t=null,i=null){let s=sm(this,e,t,i);return s.length?s[0]:null}getChildren(e,t=null,i=null){return sm(this,e,t,i)}resolve(e,t=0){return Er(this,e,t,!1)}resolveInner(e,t=0){return Er(this,e,t,!0)}matchContext(e){return Xa(this.parent,e)}enterUnfinishedNodesBefore(e){let t=this.childBefore(e),i=this;for(;t;){let s=t.lastChild;if(!s||s.to!=t.to)break;s.type.isError&&s.from==s.to?(i=t,t=s.prevSibling):t=s}return i}get node(){return this}get next(){return this.parent}},Pt=class r extends Zn{constructor(e,t,i,s){super(),this._tree=e,this.from=t,this.index=i,this._parent=s}get type(){return this._tree.type}get name(){return this._tree.type.name}get to(){return this.from+this._tree.length}nextChild(e,t,i,s,n=0){for(let o=this;;){for(let{children:l,positions:a}=o._tree,h=t>0?l.length:-1;e!=h;e+=t){let c=l[e],u=a[e]+o.from,p;if(!(!(n&xe.EnterBracketed&&c instanceof Te&&(p=Zi.get(c))&&!p.overlay&&p.bracketed&&i>=u&&i<=u+c.length)&&!nm(s,i,u,u+c.length))){if(c instanceof ki){if(n&xe.ExcludeBuffers)continue;let y=c.findChild(0,c.buffer.length,t,i-u,s);if(y>-1)return new es(new Ja(o,c,e,u),null,y)}else if(n&xe.IncludeAnonymous||!c.type.isAnonymous||Za(c)){let y;if(!(n&xe.IgnoreMounts)&&(y=Zi.get(c))&&!y.overlay)return new r(y.tree,u,e,o);let O=new r(c,u,e,o);return n&xe.IncludeAnonymous||!O.type.isAnonymous?O:O.nextChild(t<0?c.children.length-1:0,t,i,s,n)}}}if(n&xe.IncludeAnonymous||!o.type.isAnonymous||(o.index>=0?e=o.index+t:e=t<0?-1:o._parent._tree.children.length,o=o._parent,!o))return null}}get firstChild(){return this.nextChild(0,1,0,4)}get lastChild(){return this.nextChild(this._tree.children.length-1,-1,0,4)}childAfter(e){return this.nextChild(0,1,e,2)}childBefore(e){return this.nextChild(this._tree.children.length-1,-1,e,-2)}prop(e){return this._tree.prop(e)}enter(e,t,i=0){let s;if(!(i&xe.IgnoreOverlays)&&(s=Zi.get(this._tree))&&s.overlay){let n=e-this.from,o=i&xe.EnterBracketed&&s.bracketed;for(let{from:l,to:a}of s.overlay)if((t>0||o?l<=n:l<n)&&(t<0||o?a>=n:a>n))return new r(s.tree,s.overlay[0].from+this.from,-1,this)}return this.nextChild(0,1,e,t,i)}nextSignificantParent(){let e=this;for(;e.type.isAnonymous&&e._parent;)e=e._parent;return e}get parent(){return this._parent?this._parent.nextSignificantParent():null}get nextSibling(){return this._parent&&this.index>=0?this._parent.nextChild(this.index+1,1,0,4):null}get prevSibling(){return this._parent&&this.index>=0?this._parent.nextChild(this.index-1,-1,0,4):null}get tree(){return this._tree}toTree(){return this._tree}toString(){return this._tree.toString()}};function sm(r,e,t,i){let s=r.cursor(),n=[];if(!s.firstChild())return n;if(t!=null){for(let o=!1;!o;)if(o=s.type.is(t),!s.nextSibling())return n}for(;;){if(i!=null&&s.type.is(i))return n;if(s.type.is(e)&&n.push(s.node),!s.nextSibling())return i==null?n:[]}}function Xa(r,e,t=e.length-1){for(let i=r;t>=0;i=i.parent){if(!i)return!1;if(!i.type.isAnonymous){if(e[t]&&e[t]!=i.name)return!1;t--}}return!0}var Ja=class{constructor(e,t,i,s){this.parent=e,this.buffer=t,this.index=i,this.start=s}},es=class r extends Zn{get name(){return this.type.name}get from(){return this.context.start+this.context.buffer.buffer[this.index+1]}get to(){return this.context.start+this.context.buffer.buffer[this.index+2]}constructor(e,t,i){super(),this.context=e,this._parent=t,this.index=i,this.type=e.buffer.set.types[e.buffer.buffer[i]]}child(e,t,i){let{buffer:s}=this.context,n=s.findChild(this.index+4,s.buffer[this.index+3],e,t-this.context.start,i);return n<0?null:new r(this.context,this,n)}get firstChild(){return this.child(1,0,4)}get lastChild(){return this.child(-1,0,4)}childAfter(e){return this.child(1,e,2)}childBefore(e){return this.child(-1,e,-2)}prop(e){return this.type.prop(e)}enter(e,t,i=0){if(i&xe.ExcludeBuffers)return null;let{buffer:s}=this.context,n=s.findChild(this.index+4,s.buffer[this.index+3],t>0?1:-1,e-this.context.start,t);return n<0?null:new r(this.context,this,n)}get parent(){return this._parent||this.context.parent.nextSignificantParent()}externalSibling(e){return this._parent?null:this.context.parent.nextChild(this.context.index+e,e,0,4)}get nextSibling(){let{buffer:e}=this.context,t=e.buffer[this.index+3];return t<(this._parent?e.buffer[this._parent.index+3]:e.buffer.length)?new r(this.context,this._parent,t):this.externalSibling(1)}get prevSibling(){let{buffer:e}=this.context,t=this._parent?this._parent.index+4:0;return this.index==t?this.externalSibling(-1):new r(this.context,this._parent,e.findChild(t,this.index,-1,0,4))}get tree(){return null}toTree(){let e=[],t=[],{buffer:i}=this.context,s=this.index+4,n=i.buffer[this.index+3];if(n>s){let o=i.buffer[this.index+1];e.push(i.slice(s,n,o)),t.push(0)}return new Te(this.type,e,t,this.to-this.from)}toString(){return this.context.buffer.childString(this.index)}};function om(r){if(!r.length)return null;let e=0,t=r[0];for(let n=1;n<r.length;n++){let o=r[n];(o.from>t.from||o.to<t.to)&&(t=o,e=n)}let i=t instanceof Pt&&t.index<0?null:t.parent,s=r.slice();return i?s[e]=i:s.splice(e,1),new Ya(s,t)}var Ya=class{constructor(e,t){this.heads=e,this.node=t}get next(){return om(this.heads)}};function uw(r,e,t){let i=r.resolveInner(e,t),s=null;for(let n=i instanceof Pt?i:i.context.parent;n;n=n.parent)if(n.index<0){let o=n.parent;(s||(s=[i])).push(o.resolve(e,t)),n=o}else{let o=Zi.get(n.tree);if(o&&o.overlay&&o.overlay[0].from<=e&&o.overlay[o.overlay.length-1].to>=e){let l=new Pt(o.tree,o.overlay[0].from+n.from,-1,n);(s||(s=[i])).push(Er(l,e,t,!1))}}return s?om(s):i}var Ar=class{get name(){return this.type.name}constructor(e,t=0){if(this.buffer=null,this.stack=[],this.index=0,this.bufferNode=null,this.mode=t&~xe.EnterBracketed,e instanceof Pt)this.yieldNode(e);else{this._tree=e.context.parent,this.buffer=e.context;for(let i=e._parent;i;i=i._parent)this.stack.unshift(i.index);this.bufferNode=e,this.yieldBuf(e.index)}}yieldNode(e){return e?(this._tree=e,this.type=e.type,this.from=e.from,this.to=e.to,!0):!1}yieldBuf(e,t){this.index=e;let{start:i,buffer:s}=this.buffer;return this.type=t||s.set.types[s.buffer[e]],this.from=i+s.buffer[e+1],this.to=i+s.buffer[e+2],!0}yield(e){return e?e instanceof Pt?(this.buffer=null,this.yieldNode(e)):(this.buffer=e.context,this.yieldBuf(e.index,e.type)):!1}toString(){return this.buffer?this.buffer.buffer.childString(this.index):this._tree.toString()}enterChild(e,t,i){if(!this.buffer)return this.yield(this._tree.nextChild(e<0?this._tree._tree.children.length-1:0,e,t,i,this.mode));let{buffer:s}=this.buffer,n=s.findChild(this.index+4,s.buffer[this.index+3],e,t-this.buffer.start,i);return n<0?!1:(this.stack.push(this.index),this.yieldBuf(n))}firstChild(){return this.enterChild(1,0,4)}lastChild(){return this.enterChild(-1,0,4)}childAfter(e){return this.enterChild(1,e,2)}childBefore(e){return this.enterChild(-1,e,-2)}enter(e,t,i=this.mode){return this.buffer?i&xe.ExcludeBuffers?!1:this.enterChild(1,e,t):this.yield(this._tree.enter(e,t,i))}parent(){if(!this.buffer)return this.yieldNode(this.mode&xe.IncludeAnonymous?this._tree._parent:this._tree.parent);if(this.stack.length)return this.yieldBuf(this.stack.pop());let e=this.mode&xe.IncludeAnonymous?this.buffer.parent:this.buffer.parent.nextSignificantParent();return this.buffer=null,this.yieldNode(e)}sibling(e){if(!this.buffer)return this._tree._parent?this.yield(this._tree.index<0?null:this._tree._parent.nextChild(this._tree.index+e,e,0,4,this.mode)):!1;let{buffer:t}=this.buffer,i=this.stack.length-1;if(e<0){let s=i<0?0:this.stack[i]+4;if(this.index!=s)return this.yieldBuf(t.findChild(s,this.index,-1,0,4))}else{let s=t.buffer[this.index+3];if(s<(i<0?t.buffer.length:t.buffer[this.stack[i]+3]))return this.yieldBuf(s)}return i<0?this.yield(this.buffer.parent.nextChild(this.buffer.index+e,e,0,4,this.mode)):!1}nextSibling(){return this.sibling(1)}prevSibling(){return this.sibling(-1)}atLastNode(e){let t,i,{buffer:s}=this;if(s){if(e>0){if(this.index<s.buffer.buffer.length)return!1}else for(let n=0;n<this.index;n++)if(s.buffer.buffer[n+3]<this.index)return!1;({index:t,parent:i}=s)}else({index:t,_parent:i}=this._tree);for(;i;{index:t,_parent:i}=i)if(t>-1)for(let n=t+e,o=e<0?-1:i._tree.children.length;n!=o;n+=e){let l=i._tree.children[n];if(this.mode&xe.IncludeAnonymous||l instanceof ki||!l.type.isAnonymous||Za(l))return!1}return!0}move(e,t){if(t&&this.enterChild(e,0,4))return!0;for(;;){if(this.sibling(e))return!0;if(this.atLastNode(e)||!this.parent())return!1}}next(e=!0){return this.move(1,e)}prev(e=!0){return this.move(-1,e)}moveTo(e,t=0){for(;(this.from==this.to||(t<1?this.from>=e:this.from>e)||(t>-1?this.to<=e:this.to<e))&&this.parent(););for(;this.enterChild(1,e,t););return this}get node(){if(!this.buffer)return this._tree;let e=this.bufferNode,t=null,i=0;if(e&&e.context==this.buffer)e:for(let s=this.index,n=this.stack.length;n>=0;){for(let o=e;o;o=o._parent)if(o.index==s){if(s==this.index)return o;t=o,i=n+1;break e}s=this.stack[--n]}for(let s=i;s<this.stack.length;s++)t=new es(this.buffer,t,this.stack[s]);return this.bufferNode=new es(this.buffer,t,this.index)}get tree(){return this.buffer?null:this._tree._tree}iterate(e,t){for(let i=0;;){let s=!1;if(this.type.isAnonymous||e(this)!==!1){if(this.firstChild()){i++;continue}this.type.isAnonymous||(s=!0)}for(;;){if(s&&t&&t(this),s=this.type.isAnonymous,!i)return;if(this.nextSibling())break;this.parent(),i--,s=!0}}}matchContext(e){if(!this.buffer)return Xa(this.node.parent,e);let{buffer:t}=this.buffer,{types:i}=t.set;for(let s=e.length-1,n=this.stack.length-1;s>=0;n--){if(n<0)return Xa(this._tree,e,s);let o=i[t.buffer[this.stack[n]]];if(!o.isAnonymous){if(e[s]&&e[s]!=o.name)return!1;s--}}return!0}};function Za(r){return r.children.some(e=>e instanceof ki||!e.type.isAnonymous||Za(e))}function pw(r){var e;let{buffer:t,nodeSet:i,maxBufferLength:s=1024,reused:n=[],minRepeatType:o=i.types.length}=r,l=Array.isArray(t)?new Ga(t,t.length):t,a=i.types,h=0,c=0;function u(A,R,D,F,J,he){let{id:Z,start:U,end:ee,size:le}=l,ye=c,We=h;if(le<0)if(l.next(),le==-1){let Rt=n[Z];D.push(Rt),F.push(U-A);return}else if(le==-3){h=Z;return}else if(le==-4){c=Z;return}else throw new RangeError(`Unrecognized record size: ${le}`);let Ye=a[Z],gt,De,nt=U-A;if(ee-U<=s&&(De=v(l.pos-R,J))){let Rt=new Uint16Array(De.size-De.skip),Ke=l.pos-De.size,Oe=Rt.length;for(;l.pos>Ke;)Oe=k(De.start,Rt,Oe);gt=new ki(Rt,ee-De.start,i),nt=De.start-A}else{let Rt=l.pos-le;l.next();let Ke=[],Oe=[],Vt=Z>=o?Z:-1,ei=0,Di=ee;for(;l.pos>Rt;)Vt>=0&&l.id==Vt&&l.size>=0?(l.end<=Di-s&&(O(Ke,Oe,U,ei,l.end,Di,Vt,ye,We),ei=Ke.length,Di=l.end),l.next()):he>2500?p(U,Rt,Ke,Oe):u(U,Rt,Ke,Oe,Vt,he+1);if(Vt>=0&&ei>0&&ei<Ke.length&&O(Ke,Oe,U,ei,U,Di,Vt,ye,We),Ke.reverse(),Oe.reverse(),Vt>-1&&ei>0){let Ne=y(Ye,We);gt=eh(Ye,Ke,Oe,0,Ke.length,0,ee-U,Ne,Ne)}else gt=b(Ye,Ke,Oe,ee-U,ye-ee,We)}D.push(gt),F.push(nt)}function p(A,R,D,F){let J=[],he=0,Z=-1;for(;l.pos>R;){let{id:U,start:ee,end:le,size:ye}=l;if(ye>4)l.next();else{if(Z>-1&&ee<Z)break;Z<0&&(Z=le-s),J.push(U,ee,le),he++,l.next()}}if(he){let U=new Uint16Array(he*4),ee=J[J.length-2];for(let le=J.length-3,ye=0;le>=0;le-=3)U[ye++]=J[le],U[ye++]=J[le+1]-ee,U[ye++]=J[le+2]-ee,U[ye++]=ye;D.push(new ki(U,J[2]-ee,i)),F.push(ee-A)}}function y(A,R){return(D,F,J)=>{let he=0,Z=D.length-1,U,ee;if(Z>=0&&(U=D[Z])instanceof Te){if(!Z&&U.type==A&&U.length==J)return U;(ee=U.prop(ie.lookAhead))&&(he=F[Z]+U.length+ee)}return b(A,D,F,J,he,R)}}function O(A,R,D,F,J,he,Z,U,ee){let le=[],ye=[];for(;A.length>F;)le.push(A.pop()),ye.push(R.pop()+D-J);A.push(b(i.types[Z],le,ye,he-J,U-he,ee)),R.push(J-D)}function b(A,R,D,F,J,he,Z){if(he){let U=[ie.contextHash,he];Z=Z?[U].concat(Z):[U]}if(J>25){let U=[ie.lookAhead,J];Z=Z?[U].concat(Z):[U]}return new Te(A,R,D,F,Z)}function v(A,R){let D=l.fork(),F=0,J=0,he=0,Z=D.end-s,U={size:0,start:0,skip:0};e:for(let ee=D.pos-A;D.pos>ee;){let le=D.size;if(D.id==R&&le>=0){U.size=F,U.start=J,U.skip=he,he+=4,F+=4,D.next();continue}let ye=D.pos-le;if(le<0||ye<ee||D.start<Z)break;let We=D.id>=o?4:0,Ye=D.start;for(D.next();D.pos>ye;){if(D.size<0)if(D.size==-3||D.size==-4)We+=4;else break e;else D.id>=o&&(We+=4);D.next()}J=Ye,F+=le,he+=We}return(R<0||F==A)&&(U.size=F,U.start=J,U.skip=he),U.size>4?U:void 0}function k(A,R,D){let{id:F,start:J,end:he,size:Z}=l;if(l.next(),Z>=0&&F<o){let U=D;if(Z>4){let ee=l.pos-(Z-4);for(;l.pos>ee;)D=k(A,R,D)}R[--D]=U,R[--D]=he-A,R[--D]=J-A,R[--D]=F}else Z==-3?h=F:Z==-4&&(c=F);return D}let T=[],C=[];for(;l.pos>0;)u(r.start||0,r.bufferStart||0,T,C,-1,0);let Q=(e=r.length)!==null&&e!==void 0?e:T.length?C[0]+T[0].length:0;return new Te(a[r.topID],T.reverse(),C.reverse(),Q)}var rm=new WeakMap;function Kn(r,e){if(!r.isAnonymous||e instanceof ki||e.type!=r)return 1;let t=rm.get(e);if(t==null){t=1;for(let i of e.children){if(i.type!=r||!(i instanceof Te)){t=1;break}t+=Kn(r,i)}rm.set(e,t)}return t}function eh(r,e,t,i,s,n,o,l,a){let h=0;for(let O=i;O<s;O++)h+=Kn(r,e[O]);let c=Math.ceil(h*1.5/8),u=[],p=[];function y(O,b,v,k,T){for(let C=v;C<k;){let Q=C,A=b[C],R=Kn(r,O[C]);for(C++;C<k;C++){let D=Kn(r,O[C]);if(R+D>=c)break;R+=D}if(C==Q+1){if(R>c){let D=O[Q];y(D.children,D.positions,0,D.children.length,b[Q]+T);continue}u.push(O[Q])}else{let D=b[C-1]+O[C-1].length-A;u.push(eh(r,O,b,Q,C,A,D,null,a))}p.push(A+T-n)}}return y(e,t,i,s,0),(l||a)(u,p,o)}var eo=class{constructor(){this.map=new WeakMap}setBuffer(e,t,i){let s=this.map.get(e);s||this.map.set(e,s=new Map),s.set(t,i)}getBuffer(e,t){let i=this.map.get(e);return i&&i.get(t)}set(e,t){e instanceof es?this.setBuffer(e.context.buffer,e.index,t):e instanceof Pt&&this.map.set(e.tree,t)}get(e){return e instanceof es?this.getBuffer(e.context.buffer,e.index):e instanceof Pt?this.map.get(e.tree):void 0}cursorSet(e,t){e.buffer?this.setBuffer(e.buffer.buffer,e.index,t):this.map.set(e.tree,t)}cursorGet(e){return e.buffer?this.getBuffer(e.buffer.buffer,e.index):this.map.get(e.tree)}},ts=class r{constructor(e,t,i,s,n=!1,o=!1){this.from=e,this.to=t,this.tree=i,this.offset=s,this.open=(n?1:0)|(o?2:0)}get openStart(){return(this.open&1)>0}get openEnd(){return(this.open&2)>0}static addTree(e,t=[],i=!1){let s=[new r(0,e.length,e,0,!1,i)];for(let n of t)n.to>e.length&&s.push(n);return s}static applyChanges(e,t,i=128){if(!t.length)return e;let s=[],n=1,o=e.length?e[0]:null;for(let l=0,a=0,h=0;;l++){let c=l<t.length?t[l]:null,u=c?c.fromA:1e9;if(u-a>=i)for(;o&&o.from<u;){let p=o;if(a>=p.from||u<=p.to||h){let y=Math.max(p.from,a)-h,O=Math.min(p.to,u)-h;p=y>=O?null:new r(y,O,p.tree,p.offset+h,l>0,!!c)}if(p&&s.push(p),o.to>u)break;o=n<e.length?e[n++]:null}if(!c)break;a=c.toA,h=c.toA-c.toB}return s}},Fs=class{startParse(e,t,i){return typeof e=="string"&&(e=new Ka(e)),i=i?i.length?i.map(s=>new Pr(s.from,s.to)):[new Pr(0,0)]:[new Pr(0,e.length)],this.createParse(e,t||[],i)}parse(e,t,i){let s=this.startParse(e,t,i);for(;;){let n=s.advance();if(n)return n}}},Ka=class{constructor(e){this.string=e}get length(){return this.string.length}chunk(e){return this.string.slice(e)}get lineChunks(){return!1}read(e,t){return this.string.slice(e,t)}};var DC=new ie({perNode:!0});var mw=0,Bt=class r{constructor(e,t,i,s){this.name=e,this.set=t,this.base=i,this.modified=s,this.id=mw++}toString(){let{name:e}=this;for(let t of this.modified)t.name&&(e=`${t.name}(${e})`);return e}static define(e,t){let i=typeof e=="string"?e:"?";if(e instanceof r&&(t=e),t!=null&&t.base)throw new Error("Can not derive from a modified tag");let s=new r(i,[],null,[]);if(s.set.push(s),t)for(let n of t.set)s.set.push(n);return s}static defineModifier(e){let t=new ro(e);return i=>i.modified.indexOf(t)>-1?i:ro.get(i.base||i,i.modified.concat(t).sort((s,n)=>s.id-n.id))}},gw=0,ro=class r{constructor(e){this.name=e,this.instances=[],this.id=gw++}static get(e,t){if(!t.length)return e;let i=t[0].instances.find(l=>l.base==e&&_w(t,l.modified));if(i)return i;let s=[],n=new Bt(e.name,s,e,t);for(let l of t)l.instances.push(n);let o=yw(t);for(let l of e.set)if(!l.modified.length)for(let a of o)s.push(r.get(l,a));return n}};function _w(r,e){return r.length==e.length&&r.every((t,i)=>t==e[i])}function yw(r){let e=[[]];for(let t=0;t<r.length;t++)for(let i=0,s=e.length;i<s;i++)e.push(e[i].concat(r[t]));return e.sort((t,i)=>i.length-t.length)}function no(r){let e=Object.create(null);for(let t in r){let i=r[t];Array.isArray(i)||(i=[i]);for(let s of t.split(" "))if(s){let n=[],o=2,l=s;for(let u=0;;){if(l=="..."&&u>0&&u+3==s.length){o=1;break}let p=/^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(l);if(!p)throw new RangeError("Invalid path: "+s);if(n.push(p[0]=="*"?"":p[0][0]=='"'?JSON.parse(p[0]):p[0]),u+=p[0].length,u==s.length)break;let y=s[u++];if(u==s.length&&y=="!"){o=0;break}if(y!="/")throw new RangeError("Invalid path: "+s);l=s.slice(u)}let a=n.length-1,h=n[a];if(!h)throw new RangeError("Invalid path: "+s);let c=new ss(i,o,a>0?n.slice(0,a):null);e[h]=c.sort(e[h])}}return hm.add(e)}var hm=new ie({combine(r,e){let t,i,s;for(;r||e;){if(!r||e&&r.depth<=e.depth?(s=e,e=e.next):(s=r,r=r.next),t&&t.mode==s.mode&&!s.context&&!t.context)continue;let n=new ss(s.tags,s.mode,s.context);t?t.next=n:i=n,t=n}return i}}),ss=class{constructor(e,t,i,s){this.tags=e,this.mode=t,this.context=i,this.next=s}get opaque(){return this.mode==0}get inherit(){return this.mode==1}sort(e){return!e||e.depth<this.depth?(this.next=e,this):(e.next=this.sort(e.next),e)}get depth(){return this.context?this.context.length:0}};ss.empty=new ss([],2,null);function rh(r,e){let t=Object.create(null);for(let n of r)if(!Array.isArray(n.tag))t[n.tag.id]=n.class;else for(let o of n.tag)t[o.id]=n.class;let{scope:i,all:s=null}=e||{};return{style:n=>{let o=s;for(let l of n)for(let a of l.set){let h=t[a.id];if(h){o=o?o+" "+h:h;break}}return o},scope:i}}function bw(r,e){let t=null;for(let i of r){let s=i.style(e);s&&(t=t?t+" "+s:s)}return t}function fm(r,e,t,i=0,s=r.length){let n=new ih(i,Array.isArray(e)?e:[e],t);n.highlightRange(r.cursor(),i,s,"",n.highlighters),n.flush(s)}var ih=class{constructor(e,t,i){this.at=e,this.highlighters=t,this.span=i,this.class=""}startSpan(e,t){t!=this.class&&(this.flush(e),e>this.at&&(this.at=e),this.class=t)}flush(e){e>this.at&&this.class&&this.span(this.at,e,this.class)}highlightRange(e,t,i,s,n){let{type:o,from:l,to:a}=e;if(l>=i||a<=t)return;o.isTop&&(n=this.highlighters.filter(y=>!y.scope||y.scope(o)));let h=s,c=Ow(e)||ss.empty,u=bw(n,c.tags);if(u&&(h&&(h+=" "),h+=u,c.mode==1&&(s+=(s?" ":"")+u)),this.startSpan(Math.max(t,l),h),c.opaque)return;let p=e.tree&&e.tree.prop(ie.mounted);if(p&&p.overlay){let y=e.node.enter(p.overlay[0].from+l,1),O=this.highlighters.filter(v=>!v.scope||v.scope(p.tree.type)),b=e.firstChild();for(let v=0,k=l;;v++){let T=v<p.overlay.length?p.overlay[v]:null,C=T?T.from+l:a,Q=Math.max(t,k),A=Math.min(i,C);if(Q<A&&b)for(;e.from<A&&(this.highlightRange(e,Q,A,s,n),this.startSpan(Math.min(A,e.to),h),!(e.to>=C||!e.nextSibling())););if(!T||C>i)break;k=T.to+l,k>t&&(this.highlightRange(y.cursor(),Math.max(t,T.from+l),Math.min(i,k),"",O),this.startSpan(Math.min(i,k),h))}b&&e.parent()}else if(e.firstChild()){p&&(s="");do if(!(e.to<=t)){if(e.from>=i)break;this.highlightRange(e,t,i,s,n),this.startSpan(Math.min(i,e.to),h)}while(e.nextSibling());e.parent()}}};function Ow(r){let e=r.type.prop(hm);for(;e&&e.context&&!r.matchContext(e.context);)e=e.next;return e||null}var B=Bt.define,to=B(),xi=B(),lm=B(xi),am=B(xi),Si=B(),io=B(Si),th=B(Si),Zt=B(),is=B(Zt),Yt=B(),Kt=B(),sh=B(),Rr=B(sh),so=B(),E={comment:to,lineComment:B(to),blockComment:B(to),docComment:B(to),name:xi,variableName:B(xi),typeName:lm,tagName:B(lm),propertyName:am,attributeName:B(am),className:B(xi),labelName:B(xi),namespace:B(xi),macroName:B(xi),literal:Si,string:io,docString:B(io),character:B(io),attributeValue:B(io),number:th,integer:B(th),float:B(th),bool:B(Si),regexp:B(Si),escape:B(Si),color:B(Si),url:B(Si),keyword:Yt,self:B(Yt),null:B(Yt),atom:B(Yt),unit:B(Yt),modifier:B(Yt),operatorKeyword:B(Yt),controlKeyword:B(Yt),definitionKeyword:B(Yt),moduleKeyword:B(Yt),operator:Kt,derefOperator:B(Kt),arithmeticOperator:B(Kt),logicOperator:B(Kt),bitwiseOperator:B(Kt),compareOperator:B(Kt),updateOperator:B(Kt),definitionOperator:B(Kt),typeOperator:B(Kt),controlOperator:B(Kt),punctuation:sh,separator:B(sh),bracket:Rr,angleBracket:B(Rr),squareBracket:B(Rr),paren:B(Rr),brace:B(Rr),content:Zt,heading:is,heading1:B(is),heading2:B(is),heading3:B(is),heading4:B(is),heading5:B(is),heading6:B(is),contentSeparator:B(Zt),list:B(Zt),quote:B(Zt),emphasis:B(Zt),strong:B(Zt),link:B(Zt),monospace:B(Zt),strikethrough:B(Zt),inserted:B(),deleted:B(),changed:B(),invalid:B(),meta:so,documentMeta:B(so),annotation:B(so),processingInstruction:B(so),definition:Bt.defineModifier("definition"),constant:Bt.defineModifier("constant"),function:Bt.defineModifier("function"),standard:Bt.defineModifier("standard"),local:Bt.defineModifier("local"),special:Bt.defineModifier("special")};for(let r in E){let e=E[r];e instanceof Bt&&(e.name=r)}var LC=rh([{tag:E.link,class:"tok-link"},{tag:E.heading,class:"tok-heading"},{tag:E.emphasis,class:"tok-emphasis"},{tag:E.strong,class:"tok-strong"},{tag:E.keyword,class:"tok-keyword"},{tag:E.atom,class:"tok-atom"},{tag:E.bool,class:"tok-bool"},{tag:E.url,class:"tok-url"},{tag:E.labelName,class:"tok-labelName"},{tag:E.inserted,class:"tok-inserted"},{tag:E.deleted,class:"tok-deleted"},{tag:E.literal,class:"tok-literal"},{tag:E.string,class:"tok-string"},{tag:E.number,class:"tok-number"},{tag:[E.regexp,E.escape,E.special(E.string)],class:"tok-string2"},{tag:E.variableName,class:"tok-variableName"},{tag:E.local(E.variableName),class:"tok-variableName tok-local"},{tag:E.definition(E.variableName),class:"tok-variableName tok-definition"},{tag:E.special(E.variableName),class:"tok-variableName2"},{tag:E.definition(E.propertyName),class:"tok-propertyName tok-definition"},{tag:E.typeName,class:"tok-typeName"},{tag:E.namespace,class:"tok-namespace"},{tag:E.className,class:"tok-className"},{tag:E.macroName,class:"tok-macroName"},{tag:E.propertyName,class:"tok-propertyName"},{tag:E.operator,class:"tok-operator"},{tag:E.comment,class:"tok-comment"},{tag:E.meta,class:"tok-meta"},{tag:E.invalid,class:"tok-invalid"},{tag:E.punctuation,class:"tok-punctuation"}]);var nh,Ws=new ie;function vw(r){return W.define({combine:r?e=>e.concat(r):void 0})}var ww=new ie,ut=class{constructor(e,t,i=[],s=""){this.data=e,this.name=s,pe.prototype.hasOwnProperty("tree")||Object.defineProperty(pe.prototype,"tree",{get(){return Be(this)}}),this.parser=t,this.extension=[zs.of(this),pe.languageData.of((n,o,l)=>{let a=cm(n,o,l),h=a.type.prop(Ws);if(!h)return[];let c=n.facet(h),u=a.type.prop(ww);if(u){let p=a.resolve(o-a.from,l);for(let y of u)if(y.test(p,n)){let O=n.facet(y.facet);return y.type=="replace"?O:O.concat(c)}}return c})].concat(i)}isActiveAt(e,t,i=-1){return cm(e,t,i).type.prop(Ws)==this.data}findRegions(e){let t=e.facet(zs);if((t==null?void 0:t.data)==this.data)return[{from:0,to:e.doc.length}];if(!t||!t.allowsNesting)return[];let i=[],s=(n,o)=>{if(n.prop(Ws)==this.data){i.push({from:o,to:o+n.length});return}let l=n.prop(ie.mounted);if(l){if(l.tree.prop(Ws)==this.data){if(l.overlay)for(let a of l.overlay)i.push({from:a.from+o,to:a.to+o});else i.push({from:o,to:o+n.length});return}else if(l.overlay){let a=i.length;if(s(l.tree,l.overlay[0].from+o),i.length>a)return}}for(let a=0;a<n.children.length;a++){let h=n.children[a];h instanceof Te&&s(h,n.positions[a]+o)}};return s(Be(e),0),i}get allowsNesting(){return!0}};ut.setState=re.define();function cm(r,e,t){let i=r.facet(zs),s=Be(r).topNode;if(!i||i.allowsNesting)for(let n=s;n;n=n.enter(e,t,xe.ExcludeBuffers|xe.EnterBracketed))n.type.isTop&&(s=n);return s}var oo=class r extends ut{constructor(e,t,i){super(e,t,[],i),this.parser=t}static define(e){let t=vw(e.languageData);return new r(t,e.parser.configure({props:[Ws.add(i=>i.isTop?t:void 0)]}),e.name)}configure(e,t){return new r(this.data,this.parser.configure(e),t||this.name)}get allowsNesting(){return this.parser.hasWrappers()}};function Be(r){let e=r.field(ut.state,!1);return e?e.tree:Te.empty}var hh=class{constructor(e){this.doc=e,this.cursorPos=0,this.string="",this.cursor=e.iter()}get length(){return this.doc.length}syncTo(e){return this.string=this.cursor.next(e-this.cursorPos).value,this.cursorPos=e+this.string.length,this.cursorPos-this.string.length}chunk(e){return this.syncTo(e),this.string}get lineChunks(){return!0}read(e,t){let i=this.cursorPos-this.string.length;return e<i||t>=this.cursorPos?this.doc.sliceString(e,t):this.string.slice(e-i,t-i)}},Mr=null,fh=class r{constructor(e,t,i=[],s,n,o,l,a){this.parser=e,this.state=t,this.fragments=i,this.tree=s,this.treeLen=n,this.viewport=o,this.skipped=l,this.scheduleOn=a,this.parse=null,this.tempSkipped=[]}static create(e,t,i){return new r(e,t,[],Te.empty,0,i,[],null)}startParse(){return this.parser.startParse(new hh(this.state.doc),this.fragments)}work(e,t){return t!=null&&t>=this.state.doc.length&&(t=void 0),this.tree!=Te.empty&&this.isDone(t??this.state.doc.length)?(this.takeTree(),!0):this.withContext(()=>{var i;if(typeof e=="number"){let s=Date.now()+e;e=()=>Date.now()>s}for(this.parse||(this.parse=this.startParse()),t!=null&&(this.parse.stoppedAt==null||this.parse.stoppedAt>t)&&t<this.state.doc.length&&this.parse.stopAt(t);;){let s=this.parse.advance();if(s)if(this.fragments=this.withoutTempSkipped(ts.addTree(s,this.fragments,this.parse.stoppedAt!=null)),this.treeLen=(i=this.parse.stoppedAt)!==null&&i!==void 0?i:this.state.doc.length,this.tree=s,this.parse=null,this.treeLen<(t??this.state.doc.length))this.parse=this.startParse();else return!0;if(e())return!1}})}takeTree(){let e,t;this.parse&&(e=this.parse.parsedPos)>=this.treeLen&&((this.parse.stoppedAt==null||this.parse.stoppedAt>e)&&this.parse.stopAt(e),this.withContext(()=>{for(;!(t=this.parse.advance()););}),this.treeLen=e,this.tree=t,this.fragments=this.withoutTempSkipped(ts.addTree(this.tree,this.fragments,!0)),this.parse=null)}withContext(e){let t=Mr;Mr=this;try{return e()}finally{Mr=t}}withoutTempSkipped(e){for(let t;t=this.tempSkipped.pop();)e=dm(e,t.from,t.to);return e}changes(e,t){let{fragments:i,tree:s,treeLen:n,viewport:o,skipped:l}=this;if(this.takeTree(),!e.empty){let a=[];if(e.iterChangedRanges((h,c,u,p)=>a.push({fromA:h,toA:c,fromB:u,toB:p})),i=ts.applyChanges(i,a),s=Te.empty,n=0,o={from:e.mapPos(o.from,-1),to:e.mapPos(o.to,1)},this.skipped.length){l=[];for(let h of this.skipped){let c=e.mapPos(h.from,1),u=e.mapPos(h.to,-1);c<u&&l.push({from:c,to:u})}}}return new r(this.parser,t,i,s,n,o,l,this.scheduleOn)}updateViewport(e){if(this.viewport.from==e.from&&this.viewport.to==e.to)return!1;this.viewport=e;let t=this.skipped.length;for(let i=0;i<this.skipped.length;i++){let{from:s,to:n}=this.skipped[i];s<e.to&&n>e.from&&(this.fragments=dm(this.fragments,s,n),this.skipped.splice(i--,1))}return this.skipped.length>=t?!1:(this.reset(),!0)}reset(){this.parse&&(this.takeTree(),this.parse=null)}skipUntilInView(e,t){this.skipped.push({from:e,to:t})}static getSkippingParser(e){return new class extends Fs{createParse(t,i,s){let n=s[0].from,o=s[s.length-1].to;return{parsedPos:n,advance(){let a=Mr;if(a){for(let h of s)a.tempSkipped.push(h);e&&(a.scheduleOn=a.scheduleOn?Promise.all([a.scheduleOn,e]):e)}return this.parsedPos=o,new Te(Xe.none,[],[],o-n)},stoppedAt:null,stopAt(){}}}}}isDone(e){e=Math.min(e,this.state.doc.length);let t=this.fragments;return this.treeLen>=e&&t.length&&t[0].from==0&&t[0].to>=e}static get(){return Mr}};function dm(r,e,t){return ts.applyChanges(r,[{fromA:e,toA:t,fromB:e,toB:t}])}var Dr=class r{constructor(e){this.context=e,this.tree=e.tree}apply(e){if(!e.docChanged&&this.tree==this.context.tree)return this;let t=this.context.changes(e.changes,e.state),i=this.context.treeLen==e.startState.doc.length?void 0:Math.max(e.changes.mapPos(this.context.treeLen),t.viewport.to);return t.work(20,i)||t.takeTree(),new r(t)}static init(e){let t=Math.min(3e3,e.doc.length),i=fh.create(e.facet(zs).parser,e,{from:0,to:t});return i.work(20,t)||i.takeTree(),new r(i)}};ut.state=Qe.define({create:Dr.init,update(r,e){for(let t of e.effects)if(t.is(ut.setState))return t.value;return e.startState.facet(zs)!=e.state.facet(zs)?Dr.init(e.state):r.apply(e)}});var _m=r=>{let e=setTimeout(()=>r(),500);return()=>clearTimeout(e)};typeof requestIdleCallback<"u"&&(_m=r=>{let e=-1,t=setTimeout(()=>{e=requestIdleCallback(r,{timeout:400})},100);return()=>e<0?clearTimeout(t):cancelIdleCallback(e)});var oh=typeof navigator<"u"&&(!((nh=navigator.scheduling)===null||nh===void 0)&&nh.isInputPending)?()=>navigator.scheduling.isInputPending():null,kw=qe.fromClass(class{constructor(e){this.view=e,this.working=null,this.workScheduled=0,this.chunkEnd=-1,this.chunkBudget=-1,this.work=this.work.bind(this),this.scheduleWork()}update(e){let t=this.view.state.field(ut.state).context;(t.updateViewport(e.view.viewport)||this.view.viewport.to>t.treeLen)&&this.scheduleWork(),(e.docChanged||e.selectionSet)&&(this.view.hasFocus&&(this.chunkBudget+=50),this.scheduleWork()),this.checkAsyncSchedule(t)}scheduleWork(){if(this.working)return;let{state:e}=this.view,t=e.field(ut.state);(t.tree!=t.context.tree||!t.context.isDone(e.doc.length))&&(this.working=_m(this.work))}work(e){this.working=null;let t=Date.now();if(this.chunkEnd<t&&(this.chunkEnd<0||this.view.hasFocus)&&(this.chunkEnd=t+3e4,this.chunkBudget=3e3),this.chunkBudget<=0)return;let{state:i,viewport:{to:s}}=this.view,n=i.field(ut.state);if(n.tree==n.context.tree&&n.context.isDone(s+1e5))return;let o=Date.now()+Math.min(this.chunkBudget,100,e&&!oh?Math.max(25,e.timeRemaining()-5):1e9),l=n.context.treeLen<s&&i.doc.length>s+1e3,a=n.context.work(()=>oh&&oh()||Date.now()>o,s+(l?0:1e5));this.chunkBudget-=Date.now()-t,(a||this.chunkBudget<=0)&&(n.context.takeTree(),this.view.dispatch({effects:ut.setState.of(new Dr(n.context))})),this.chunkBudget>0&&!(a&&!l)&&this.scheduleWork(),this.checkAsyncSchedule(n.context)}checkAsyncSchedule(e){e.scheduleOn&&(this.workScheduled++,e.scheduleOn.then(()=>this.scheduleWork()).catch(t=>tt(this.view.state,t)).then(()=>this.workScheduled--),e.scheduleOn=null)}destroy(){this.working&&this.working()}isWorking(){return!!(this.working||this.workScheduled>0)}},{eventHandlers:{focus(){this.scheduleWork()}}}),zs=W.define({combine(r){return r.length?r[0]:null},enables:r=>[ut.state,kw,z.contentAttributes.compute([r],e=>{let t=e.facet(r);return t&&t.name?{"data-language":t.name}:{}})]}),lo=class{constructor(e,t=[]){this.language=e,this.support=t,this.extension=[e,t]}};var xw=W.define(),Ti=W.define({combine:r=>{if(!r.length)return"  ";let e=r[0];if(!e||/\S/.test(e)||Array.from(e).some(t=>t!=e[0]))throw new Error("Invalid indent unit: "+JSON.stringify(r[0]));return e}});function Nr(r){let e=r.facet(Ti);return e.charCodeAt(0)==9?r.tabSize*e.length:e.length}function Hs(r,e){let t="",i=r.tabSize,s=r.facet(Ti)[0];if(s=="	"){for(;e>=i;)t+="	",e-=i;s=" "}for(let n=0;n<e;n++)t+=s;return t}function ao(r,e){r instanceof pe&&(r=new rs(r));for(let i of r.state.facet(xw)){let s=i(r,e);if(s!==void 0)return s}let t=Be(r.state);return t.length>=e?Sw(r,t,e):null}var rs=class{constructor(e,t={}){this.state=e,this.options=t,this.unit=Nr(e)}lineAt(e,t=1){let i=this.state.doc.lineAt(e),{simulateBreak:s,simulateDoubleBreak:n}=this.options;return s!=null&&s>=i.from&&s<=i.to?n&&s==e?{text:"",from:e}:(t<0?s<e:s<=e)?{text:i.text.slice(s-i.from),from:s}:{text:i.text.slice(0,s-i.from),from:i.from}:i}textAfterPos(e,t=1){if(this.options.simulateDoubleBreak&&e==this.options.simulateBreak)return"";let{text:i,from:s}=this.lineAt(e,t);return i.slice(e-s,Math.min(i.length,e+100-s))}column(e,t=1){let{text:i,from:s}=this.lineAt(e,t),n=this.countColumn(i,e-s),o=this.options.overrideIndentation?this.options.overrideIndentation(s):-1;return o>-1&&(n+=o-this.countColumn(i,i.search(/\S|$/))),n}countColumn(e,t=e.length){return Vi(e,this.state.tabSize,t)}lineIndent(e,t=1){let{text:i,from:s}=this.lineAt(e,t),n=this.options.overrideIndentation;if(n){let o=n(s);if(o>-1)return o}return this.countColumn(i,i.search(/\S|$/))}get simulatedBreak(){return this.options.simulateBreak||null}},gh=new ie;function Sw(r,e,t){let i=e.resolveStack(t),s=e.resolveInner(t,-1).resolve(t,0).enterUnfinishedNodesBefore(t);if(s!=i.node){let n=[];for(let o=s;o&&!(o.from<i.node.from||o.to>i.node.to||o.from==i.node.from&&o.type==i.node.type);o=o.parent)n.push(o);for(let o=n.length-1;o>=0;o--)i={node:n[o],next:i}}return ym(i,r,t)}function ym(r,e,t){for(let i=r;i;i=i.next){let s=Pw(i.node);if(s)return s(ch.create(e,t,i))}return 0}function Tw(r){return r.pos==r.options.simulateBreak&&r.options.simulateDoubleBreak}function Pw(r){let e=r.type.prop(gh);if(e)return e;let t=r.firstChild,i;if(t&&(i=t.type.prop(ie.closedBy))){let s=r.lastChild,n=s&&i.indexOf(s.name)>-1;return o=>bm(o,!0,1,void 0,n&&!Tw(o)?s.from:void 0)}return r.parent==null?Cw:null}function Cw(){return 0}var ch=class r extends rs{constructor(e,t,i){super(e.state,e.options),this.base=e,this.pos=t,this.context=i}get node(){return this.context.node}static create(e,t,i){return new r(e,t,i)}get textAfter(){return this.textAfterPos(this.pos)}get baseIndent(){return this.baseIndentFor(this.node)}baseIndentFor(e){let t=this.state.doc.lineAt(e.from);for(;;){let i=e.resolve(t.from);for(;i.parent&&i.parent.from==i.from;)i=i.parent;if(Ew(i,e))break;t=this.state.doc.lineAt(i.from)}return this.lineIndent(t.from)}continue(){return ym(this.context.next,this.base,this.pos)}};function Ew(r,e){for(let t=e;t;t=t.parent)if(r==t)return!0;return!1}function Aw(r){let e=r.node,t=e.childAfter(e.from),i=e.lastChild;if(!t)return null;let s=r.options.simulateBreak,n=r.state.doc.lineAt(t.from),o=s==null||s<=n.from?n.to:Math.min(n.to,s);for(let l=t.to;;){let a=e.childAfter(l);if(!a||a==i)return null;if(!a.type.isSkipped){if(a.from>=o)return null;let h=/^ */.exec(n.text.slice(t.to-n.from))[0].length;return{from:t.from,to:t.to+h}}l=a.to}}function ho({closing:r,align:e=!0,units:t=1}){return i=>bm(i,e,t,r)}function bm(r,e,t,i,s){let n=r.textAfter,o=n.match(/^\s*/)[0].length,l=i&&n.slice(o,o+i.length)==i||s==r.pos+o,a=e?Aw(r):null;return a?l?r.column(a.from):r.column(a.to):r.baseIndent+(l?0:r.unit*t)}var Rw=200;function Om(){return pe.transactionFilter.of(r=>{if(!r.docChanged||!r.isUserEvent("input.type")&&!r.isUserEvent("input.complete"))return r;let e=r.startState.languageDataAt("indentOnInput",r.startState.selection.main.head);if(!e.length)return r;let t=r.newDoc,{head:i}=r.newSelection.main,s=t.lineAt(i);if(i>s.from+Rw)return r;let n=t.sliceString(s.from,i);if(!e.some(h=>h.test(n)))return r;let{state:o}=r,l=-1,a=[];for(let{head:h}of o.selection.ranges){let c=o.doc.lineAt(h);if(c.from==l)continue;l=c.from;let u=ao(o,c.from);if(u==null)continue;let p=/^\s*/.exec(c.text)[0],y=Hs(o,u);p!=y&&a.push({from:c.from,to:c.from+p.length,insert:y})}return a.length?[r,{changes:a,sequential:!0}]:r})}var vm=new ie;function wm(r){let e=r.firstChild,t=r.lastChild;return e&&e.to<t.from?{from:e.to,to:t.type.isError?r.to:t.from}:null}var js=class r{constructor(e,t){this.specs=e;let i;function s(l){let a=kt.newName();return(i||(i=Object.create(null)))["."+a]=l,a}let n=typeof t.all=="string"?t.all:t.all?s(t.all):void 0,o=t.scope;this.scope=o instanceof ut?l=>l.prop(Ws)==o.data:o?l=>l==o:void 0,this.style=rh(e.map(l=>({tag:l.tag,class:l.class||s(Object.assign({},l,{tag:null}))})),{all:n}).style,this.module=i?new kt(i):null,this.themeType=t.themeType}static define(e,t){return new r(e,t||{})}},dh=W.define(),km=W.define({combine(r){return r.length?[r[0]]:null}});function lh(r){let e=r.facet(dh);return e.length?e:r.facet(km)}function xm(r,e){let t=[Mw],i;return r instanceof js&&(r.module&&t.push(z.styleModule.of(r.module)),i=r.themeType),e!=null&&e.fallback?t.push(km.of(r)):i?t.push(dh.computeN([z.darkTheme],s=>s.facet(z.darkTheme)==(i=="dark")?[r]:[])):t.push(dh.of(r)),t}var uh=class{constructor(e){this.markCache=Object.create(null),this.tree=Be(e.state),this.decorations=this.buildDeco(e,lh(e.state)),this.decoratedTo=e.viewport.to}update(e){let t=Be(e.state),i=lh(e.state),s=i!=lh(e.startState),{viewport:n}=e.view,o=e.changes.mapPos(this.decoratedTo,1);t.length<n.to&&!s&&t.type==this.tree.type&&o>=n.to?(this.decorations=this.decorations.map(e.changes),this.decoratedTo=o):(t!=this.tree||e.viewportChanged||s)&&(this.tree=t,this.decorations=this.buildDeco(e.view,i),this.decoratedTo=n.to)}buildDeco(e,t){if(!t||!this.tree.length)return K.none;let i=new Gt;for(let{from:s,to:n}of e.visibleRanges)fm(this.tree,t,(o,l,a)=>{i.add(o,l,this.markCache[a]||(this.markCache[a]=K.mark({class:a})))},s,n);return i.finish()}},Mw=vt.high(qe.fromClass(uh,{decorations:r=>r.decorations})),HC=js.define([{tag:E.meta,color:"#404740"},{tag:E.link,textDecoration:"underline"},{tag:E.heading,textDecoration:"underline",fontWeight:"bold"},{tag:E.emphasis,fontStyle:"italic"},{tag:E.strong,fontWeight:"bold"},{tag:E.strikethrough,textDecoration:"line-through"},{tag:E.keyword,color:"#708"},{tag:[E.atom,E.bool,E.url,E.contentSeparator,E.labelName],color:"#219"},{tag:[E.literal,E.inserted],color:"#164"},{tag:[E.string,E.deleted],color:"#a11"},{tag:[E.regexp,E.escape,E.special(E.string)],color:"#e40"},{tag:E.definition(E.variableName),color:"#00f"},{tag:E.local(E.variableName),color:"#30a"},{tag:[E.typeName,E.namespace],color:"#085"},{tag:E.className,color:"#167"},{tag:[E.special(E.variableName),E.macroName],color:"#256"},{tag:E.definition(E.propertyName),color:"#00c"},{tag:E.comment,color:"#940"},{tag:E.invalid,color:"#f00"}]),Dw=z.baseTheme({"&.cm-focused .cm-matchingBracket":{backgroundColor:"#328c8252"},"&.cm-focused .cm-nonmatchingBracket":{backgroundColor:"#bb555544"}}),Sm=1e4,Tm="()[]{}",Pm=W.define({combine(r){return wt(r,{afterCursor:!0,brackets:Tm,maxScanDistance:Sm,renderMatch:Lw})}}),Nw=K.mark({class:"cm-matchingBracket"}),Iw=K.mark({class:"cm-nonmatchingBracket"});function Lw(r){let e=[],t=r.matched?Nw:Iw;return e.push(t.range(r.start.from,r.start.to)),r.end&&e.push(t.range(r.end.from,r.end.to)),e}function um(r){let e=[],t=r.facet(Pm);for(let i of r.selection.ranges){if(!i.empty)continue;let s=$t(r,i.head,-1,t)||i.head>0&&$t(r,i.head-1,1,t)||t.afterCursor&&($t(r,i.head,1,t)||i.head<r.doc.length&&$t(r,i.head+1,-1,t));s&&(e=e.concat(t.renderMatch(s,r)))}return K.set(e,!0)}var Qw=qe.fromClass(class{constructor(r){this.paused=!1,this.decorations=um(r.state)}update(r){(r.docChanged||r.selectionSet||this.paused)&&(r.view.composing?(this.decorations=this.decorations.map(r.changes),this.paused=!0):(this.decorations=um(r.state),this.paused=!1))}},{decorations:r=>r.decorations}),qw=[Qw,Dw];function Cm(r={}){return[Pm.of(r),qw]}var Bw=new ie;function ph(r,e,t){let i=r.prop(e<0?ie.openedBy:ie.closedBy);if(i)return i;if(r.name.length==1){let s=t.indexOf(r.name);if(s>-1&&s%2==(e<0?1:0))return[t[s+e]]}return null}function mh(r){let e=r.type.prop(Bw);return e?e(r.node):r}function $t(r,e,t,i={}){let s=i.maxScanDistance||Sm,n=i.brackets||Tm,o=Be(r),l=o.resolveInner(e,t);for(let a=l;a;a=a.parent){let h=ph(a.type,t,n);if(h&&a.from<a.to){let c=mh(a);if(c&&(t>0?e>=c.from&&e<c.to:e>c.from&&e<=c.to))return $w(r,e,t,a,c,h,n)}}return Fw(r,e,t,o,l.type,s,n)}function $w(r,e,t,i,s,n,o){let l=i.parent,a={from:s.from,to:s.to},h=0,c=l==null?void 0:l.cursor();if(c&&(t<0?c.childBefore(i.from):c.childAfter(i.to)))do if(t<0?c.to<=i.from:c.from>=i.to){if(h==0&&n.indexOf(c.type.name)>-1&&c.from<c.to){let u=mh(c);return{start:a,end:u?{from:u.from,to:u.to}:void 0,matched:!0}}else if(ph(c.type,t,o))h++;else if(ph(c.type,-t,o)){if(h==0){let u=mh(c);return{start:a,end:u&&u.from<u.to?{from:u.from,to:u.to}:void 0,matched:!1}}h--}}while(t<0?c.prevSibling():c.nextSibling());return{start:a,matched:!1}}function Fw(r,e,t,i,s,n,o){if(t<0?!e:e==r.doc.length)return null;let l=t<0?r.sliceDoc(e-1,e):r.sliceDoc(e,e+1),a=o.indexOf(l);if(a<0||a%2==0!=t>0)return null;let h={from:t<0?e-1:e,to:t>0?e+1:e},c=r.doc.iterRange(e,t>0?r.doc.length:0),u=0;for(let p=0;!c.next().done&&p<=n;){let y=c.value;t<0&&(p+=y.length);let O=e+p*t;for(let b=t>0?0:y.length-1,v=t>0?y.length:-1;b!=v;b+=t){let k=o.indexOf(y[b]);if(!(k<0||i.resolveInner(O+b,1).type!=s))if(k%2==0==t>0)u++;else{if(u==1)return{start:h,end:{from:O+b,to:O+b+1},matched:k>>1==a>>1};u--}}t>0&&(p+=y.length)}return c.done?{start:h,matched:!1}:null}var Ww=Object.create(null),pm=[Xe.none];var mm=[],gm=Object.create(null),zw=Object.create(null);for(let[r,e]of[["variable","variableName"],["variable-2","variableName.special"],["string-2","string.special"],["def","variableName.definition"],["tag","tagName"],["attribute","attributeName"],["type","typeName"],["builtin","variableName.standard"],["qualifier","modifier"],["error","invalid"],["header","heading"],["property","propertyName"]])zw[r]=jw(Ww,e);function ah(r,e){mm.indexOf(r)>-1||(mm.push(r),console.warn(e))}function jw(r,e){let t=[];for(let l of e.split(" ")){let a=[];for(let h of l.split(".")){let c=r[h]||E[h];c?typeof c=="function"?a.length?a=a.map(c):ah(h,`Modifier ${h} used at start of tag`):a.length?ah(h,`Tag ${h} used as modifier`):a=Array.isArray(c)?c:[c]:ah(h,`Unknown highlighting tag ${h}`)}for(let h of a)t.push(h)}if(!t.length)return 0;let i=e.replace(/ /g,"_"),s=i+" "+t.map(l=>l.id),n=gm[s];if(n)return n.id;let o=gm[s]=Xe.define({id:pm.length,name:i,props:[no({[i]:t})]});return pm.push(o),o.id}var VC={rtl:K.mark({class:"cm-iso",inclusive:!0,attributes:{dir:"rtl"},bidiIsolate:_e.RTL}),ltr:K.mark({class:"cm-iso",inclusive:!0,attributes:{dir:"ltr"},bidiIsolate:_e.LTR}),auto:K.mark({class:"cm-iso",inclusive:!0,attributes:{dir:"auto"},bidiIsolate:null})};var vh=r=>{let{state:e}=r,t=e.doc.lineAt(e.selection.main.from),i=kh(r.state,t.from);return i.line?Hw(r):i.block?Uw(r):!1};function wh(r,e){return({state:t,dispatch:i})=>{if(t.readOnly)return!1;let s=r(e,t);return s?(i(t.update(s)),!0):!1}}var Hw=wh(Jw,0);var Vw=wh(Qm,0);var Uw=wh((r,e)=>Qm(r,e,Xw(e)),0);function kh(r,e){let t=r.languageDataAt("commentTokens",e,1);return t.length?t[0]:{}}var Ir=50;function Gw(r,{open:e,close:t},i,s){let n=r.sliceDoc(i-Ir,i),o=r.sliceDoc(s,s+Ir),l=/\s*$/.exec(n)[0].length,a=/^\s*/.exec(o)[0].length,h=n.length-l;if(n.slice(h-e.length,h)==e&&o.slice(a,a+t.length)==t)return{open:{pos:i-l,margin:l&&1},close:{pos:s+a,margin:a&&1}};let c,u;s-i<=2*Ir?c=u=r.sliceDoc(i,s):(c=r.sliceDoc(i,i+Ir),u=r.sliceDoc(s-Ir,s));let p=/^\s*/.exec(c)[0].length,y=/\s*$/.exec(u)[0].length,O=u.length-y-t.length;return c.slice(p,p+e.length)==e&&u.slice(O,O+t.length)==t?{open:{pos:i+p+e.length,margin:/\s/.test(c.charAt(p+e.length))?1:0},close:{pos:s-y-t.length,margin:/\s/.test(u.charAt(O-1))?1:0}}:null}function Xw(r){let e=[];for(let t of r.selection.ranges){let i=r.doc.lineAt(t.from),s=t.to<=i.to?i:r.doc.lineAt(t.to);s.from>i.from&&s.from==t.to&&(s=t.to==i.to+1?i:r.doc.lineAt(t.to-1));let n=e.length-1;n>=0&&e[n].to>i.from?e[n].to=s.to:e.push({from:i.from+/^\s*/.exec(i.text)[0].length,to:s.to})}return e}function Qm(r,e,t=e.selection.ranges){let i=t.map(n=>kh(e,n.from).block);if(!i.every(n=>n))return null;let s=t.map((n,o)=>Gw(e,i[o],n.from,n.to));if(r!=2&&!s.every(n=>n))return{changes:e.changes(t.map((n,o)=>s[o]?[]:[{from:n.from,insert:i[o].open+" "},{from:n.to,insert:" "+i[o].close}]))};if(r!=1&&s.some(n=>n)){let n=[];for(let o=0,l;o<s.length;o++)if(l=s[o]){let a=i[o],{open:h,close:c}=l;n.push({from:h.pos-a.open.length,to:h.pos+h.margin},{from:c.pos-c.margin,to:c.pos+a.close.length})}return{changes:n}}return null}function Jw(r,e,t=e.selection.ranges){let i=[],s=-1;e:for(let{from:n,to:o}of t){let l=i.length,a=1e9,h;for(let c=n;c<=o;){let u=e.doc.lineAt(c);if(h==null&&(h=kh(e,u.from).line,!h))continue e;if(u.from>s&&(n==o||o>u.from)){s=u.from;let p=/^\s*/.exec(u.text)[0].length,y=p==u.length,O=u.text.slice(p,p+h.length)==h?p:-1;p<u.text.length&&p<a&&(a=p),i.push({line:u,comment:O,token:h,indent:p,empty:y,single:!1})}c=u.to+1}if(a<1e9)for(let c=l;c<i.length;c++)i[c].indent<i[c].line.text.length&&(i[c].indent=a);i.length==l+1&&(i[l].single=!0)}if(r!=2&&i.some(n=>n.comment<0&&(!n.empty||n.single))){let n=[];for(let{line:l,token:a,indent:h,empty:c,single:u}of i)(u||!c)&&n.push({from:l.from+h,insert:a+" "});let o=e.changes(n);return{changes:o,selection:e.selection.map(o,1)}}else if(r!=1&&i.some(n=>n.comment>=0)){let n=[];for(let{line:o,comment:l,token:a}of i)if(l>=0){let h=o.from+l,c=h+a.length;o.text[c-o.from]==" "&&c++,n.push({from:h,to:c})}return{changes:n}}return null}var yh=lt.define(),Yw=lt.define(),Kw=W.define(),qm=W.define({combine(r){return wt(r,{minDepth:100,newGroupDelay:500,joinToEvent:(e,t)=>t},{minDepth:Math.max,newGroupDelay:Math.min,joinToEvent:(e,t)=>(i,s)=>e(i,s)||t(i,s)})}}),Bm=Qe.define({create(){return ns.empty},update(r,e){let t=e.state.facet(qm),i=e.annotation(yh);if(i){let a=Ft.fromTransaction(e,i.selection),h=i.side,c=h==0?r.undone:r.done;return a?c=co(c,c.length,t.minDepth,a):c=Wm(c,e.startState.selection),new ns(h==0?i.rest:c,h==0?c:i.rest)}let s=e.annotation(Yw);if((s=="full"||s=="before")&&(r=r.isolate()),e.annotation(Re.addToHistory)===!1)return e.changes.empty?r:r.addMapping(e.changes.desc);let n=Ft.fromTransaction(e),o=e.annotation(Re.time),l=e.annotation(Re.userEvent);return n?r=r.addChanges(n,o,l,t,e):e.selection&&(r=r.addSelection(e.startState.selection,o,l,t.newGroupDelay)),(s=="full"||s=="after")&&(r=r.isolate()),r},toJSON(r){return{done:r.done.map(e=>e.toJSON()),undone:r.undone.map(e=>e.toJSON())}},fromJSON(r){return new ns(r.done.map(Ft.fromJSON),r.undone.map(Ft.fromJSON))}});function $m(r={}){return[Bm,qm.of(r),z.domEventHandlers({beforeinput(e,t){let i=e.inputType=="historyUndo"?Lr:e.inputType=="historyRedo"?Vs:null;return i?(e.preventDefault(),i(t)):!1}})]}function uo(r,e){return function({state:t,dispatch:i}){if(!e&&t.readOnly)return!1;let s=t.field(Bm,!1);if(!s)return!1;let n=s.pop(r,t,e);return n?(i(n),!0):!1}}var Lr=uo(0,!1),Vs=uo(1,!1),Zw=uo(0,!0),ek=uo(1,!0);var Ft=class r{constructor(e,t,i,s,n){this.changes=e,this.effects=t,this.mapped=i,this.startSelection=s,this.selectionsAfter=n}setSelAfter(e){return new r(this.changes,this.effects,this.mapped,this.startSelection,e)}toJSON(){var e,t,i;return{changes:(e=this.changes)===null||e===void 0?void 0:e.toJSON(),mapped:(t=this.mapped)===null||t===void 0?void 0:t.toJSON(),startSelection:(i=this.startSelection)===null||i===void 0?void 0:i.toJSON(),selectionsAfter:this.selectionsAfter.map(s=>s.toJSON())}}static fromJSON(e){return new r(e.changes&&Ze.fromJSON(e.changes),[],e.mapped&&ri.fromJSON(e.mapped),e.startSelection&&M.fromJSON(e.startSelection),e.selectionsAfter.map(M.fromJSON))}static fromTransaction(e,t){let i=Ct;for(let s of e.startState.facet(Kw)){let n=s(e);n.length&&(i=i.concat(n))}return!i.length&&e.changes.empty?null:new r(e.changes.invert(e.startState.doc),i,void 0,t||e.startState.selection,Ct)}static selection(e){return new r(void 0,Ct,void 0,void 0,e)}};function co(r,e,t,i){let s=e+1>t+20?e-t-1:0,n=r.slice(s,e);return n.push(i),n}function tk(r,e){let t=[],i=!1;return r.iterChangedRanges((s,n)=>t.push(s,n)),e.iterChangedRanges((s,n,o,l)=>{for(let a=0;a<t.length;){let h=t[a++],c=t[a++];l>=h&&o<=c&&(i=!0)}}),i}function ik(r,e){return r.ranges.length==e.ranges.length&&r.ranges.filter((t,i)=>t.empty!=e.ranges[i].empty).length===0}function Fm(r,e){return r.length?e.length?r.concat(e):r:e}var Ct=[],sk=200;function Wm(r,e){if(r.length){let t=r[r.length-1],i=t.selectionsAfter.slice(Math.max(0,t.selectionsAfter.length-sk));return i.length&&i[i.length-1].eq(e)?r:(i.push(e),co(r,r.length-1,1e9,t.setSelAfter(i)))}else return[Ft.selection([e])]}function rk(r){let e=r[r.length-1],t=r.slice();return t[r.length-1]=e.setSelAfter(e.selectionsAfter.slice(0,e.selectionsAfter.length-1)),t}function _h(r,e){if(!r.length)return r;let t=r.length,i=Ct;for(;t;){let s=nk(r[t-1],e,i);if(s.changes&&!s.changes.empty||s.effects.length){let n=r.slice(0,t);return n[t-1]=s,n}else e=s.mapped,t--,i=s.selectionsAfter}return i.length?[Ft.selection(i)]:Ct}function nk(r,e,t){let i=Fm(r.selectionsAfter.length?r.selectionsAfter.map(l=>l.map(e)):Ct,t);if(!r.changes)return Ft.selection(i);let s=r.changes.map(e),n=e.mapDesc(r.changes,!0),o=r.mapped?r.mapped.composeDesc(n):n;return new Ft(s,re.mapEffects(r.effects,e),o,r.startSelection.map(n),i)}var ok=/^(input\.type|delete)($|\.)/,ns=class r{constructor(e,t,i=0,s=void 0){this.done=e,this.undone=t,this.prevTime=i,this.prevUserEvent=s}isolate(){return this.prevTime?new r(this.done,this.undone):this}addChanges(e,t,i,s,n){let o=this.done,l=o[o.length-1];return l&&l.changes&&!l.changes.empty&&e.changes&&(!i||ok.test(i))&&(!l.selectionsAfter.length&&t-this.prevTime<s.newGroupDelay&&s.joinToEvent(n,tk(l.changes,e.changes))||i=="input.type.compose")?o=co(o,o.length-1,s.minDepth,new Ft(e.changes.compose(l.changes),Fm(re.mapEffects(e.effects,l.changes),l.effects),l.mapped,l.startSelection,Ct)):o=co(o,o.length,s.minDepth,e),new r(o,Ct,t,i)}addSelection(e,t,i,s){let n=this.done.length?this.done[this.done.length-1].selectionsAfter:Ct;return n.length>0&&t-this.prevTime<s&&i==this.prevUserEvent&&i&&/^select($|\.)/.test(i)&&ik(n[n.length-1],e)?this:new r(Wm(this.done,e),this.undone,t,i)}addMapping(e){return new r(_h(this.done,e),_h(this.undone,e),this.prevTime,this.prevUserEvent)}pop(e,t,i){let s=e==0?this.done:this.undone;if(s.length==0)return null;let n=s[s.length-1],o=n.selectionsAfter[0]||(n.startSelection?n.startSelection.map(n.changes.invertedDesc,1):t.selection);if(i&&n.selectionsAfter.length)return t.update({selection:n.selectionsAfter[n.selectionsAfter.length-1],annotations:yh.of({side:e,rest:rk(s),selection:o}),userEvent:e==0?"select.undo":"select.redo",scrollIntoView:!0});if(n.changes){let l=s.length==1?Ct:s.slice(0,s.length-1);return n.mapped&&(l=_h(l,n.mapped)),t.update({changes:n.changes,selection:n.startSelection,effects:n.effects,annotations:yh.of({side:e,rest:l,selection:o}),filter:!1,userEvent:e==0?"undo":"redo",scrollIntoView:!0})}else return null}};ns.empty=new ns(Ct,Ct);var zm=[{key:"Mod-z",run:Lr,preventDefault:!0},{key:"Mod-y",mac:"Mod-Shift-z",run:Vs,preventDefault:!0},{linux:"Ctrl-Shift-z",run:Vs,preventDefault:!0},{key:"Mod-u",run:Zw,preventDefault:!0},{key:"Alt-u",mac:"Mod-Shift-u",run:ek,preventDefault:!0}];function Us(r,e){return M.create(r.ranges.map(e),r.mainIndex)}function Wt(r,e){return r.update({selection:e,scrollIntoView:!0,userEvent:"select"})}function zt({state:r,dispatch:e},t){let i=Us(r.selection,t);return i.eq(r.selection,!0)?!1:(e(Wt(r,i)),!0)}function po(r,e){return M.cursor(e?r.to:r.from)}function jm(r,e){return zt(r,t=>t.empty?r.moveByChar(t,e):po(t,e))}function Je(r){return r.textDirectionAt(r.state.selection.main.head)==_e.LTR}var mo=r=>jm(r,!Je(r)),go=r=>jm(r,Je(r));function Hm(r,e){return zt(r,t=>t.empty?r.moveByGroup(t,e):po(t,e))}var lk=r=>Hm(r,!Je(r)),ak=r=>Hm(r,Je(r));var eE=typeof Intl<"u"&&Intl.Segmenter?new Intl.Segmenter(void 0,{granularity:"word"}):null;function hk(r,e,t){if(e.type.prop(t))return!0;let i=e.to-e.from;return i&&(i>2||/[^\s,.;:]/.test(r.sliceDoc(e.from,e.to)))||e.firstChild}function _o(r,e,t){let i=Be(r).resolveInner(e.head),s=t?ie.closedBy:ie.openedBy;for(let a=e.head;;){let h=t?i.childAfter(a):i.childBefore(a);if(!h)break;hk(r,h,s)?i=h:a=t?h.to:h.from}let n=i.type.prop(s),o,l;return n&&(o=t?$t(r,i.from,1):$t(r,i.to,-1))&&o.matched?l=t?o.end.to:o.end.from:l=t?i.to:i.from,M.cursor(l,t?-1:1)}var fk=r=>zt(r,e=>_o(r.state,e,!Je(r))),ck=r=>zt(r,e=>_o(r.state,e,Je(r)));function Vm(r,e){return zt(r,t=>{if(!t.empty)return po(t,e);let i=r.moveVertically(t,e);return i.head!=t.head?i:r.moveToLineBoundary(t,e)})}var Um=r=>Vm(r,!1),Gm=r=>Vm(r,!0);function Xm(r){let e=r.scrollDOM.clientHeight<r.scrollDOM.scrollHeight-2,t=0,i=0,s;if(e){for(let n of r.state.facet(z.scrollMargins)){let o=n(r);o!=null&&o.top&&(t=Math.max(o==null?void 0:o.top,t)),o!=null&&o.bottom&&(i=Math.max(o==null?void 0:o.bottom,i))}s=r.scrollDOM.clientHeight-t-i}else s=(r.dom.ownerDocument.defaultView||window).innerHeight;return{marginTop:t,marginBottom:i,selfScroll:e,height:Math.max(r.defaultLineHeight,s-5)}}function Jm(r,e){let t=Xm(r),{state:i}=r,s=Us(i.selection,o=>o.empty?r.moveVertically(o,e,t.height):po(o,e));if(s.eq(i.selection))return!1;let n;if(t.selfScroll){let o=r.coordsAtPos(i.selection.main.head),l=r.scrollDOM.getBoundingClientRect(),a=l.top+t.marginTop,h=l.bottom-t.marginBottom;o&&o.top>a&&o.bottom<h&&(n=z.scrollIntoView(s.main.head,{y:"start",yMargin:o.top-a}))}return r.dispatch(Wt(i,s),{effects:n}),!0}var Em=r=>Jm(r,!1),bh=r=>Jm(r,!0);function Pi(r,e,t){let i=r.lineBlockAt(e.head),s=r.moveToLineBoundary(e,t);if(s.head==e.head&&s.head!=(t?i.to:i.from)&&(s=r.moveToLineBoundary(e,t,!1)),!t&&s.head==i.from&&i.length){let n=/^\s*/.exec(r.state.sliceDoc(i.from,Math.min(i.from+100,i.to)))[0].length;n&&e.head!=i.from+n&&(s=M.cursor(i.from+n))}return s}var dk=r=>zt(r,e=>Pi(r,e,!0)),uk=r=>zt(r,e=>Pi(r,e,!1)),pk=r=>zt(r,e=>Pi(r,e,!Je(r))),mk=r=>zt(r,e=>Pi(r,e,Je(r))),gk=r=>zt(r,e=>r.moveToLineBoundary(e,!1,!1)),_k=r=>zt(r,e=>r.moveToLineBoundary(e,!0,!1));function yk(r,e,t){let i=!1,s=Us(r.selection,n=>{let o=$t(r,n.head,-1)||$t(r,n.head,1)||n.head>0&&$t(r,n.head-1,1)||n.head<r.doc.length&&$t(r,n.head+1,-1);if(!o||!o.end)return n;i=!0;let l=o.start.from==n.head?o.end.to:o.end.from;return t?M.range(n.anchor,l):M.cursor(l)});return i?(e(Wt(r,s)),!0):!1}var bk=({state:r,dispatch:e})=>yk(r,e,!1);function Et(r,e,t){let i=Us(r.state.selection,s=>{s.undirectional&&s.head>=s.anchor!=e&&(s=M.range(s.head,s.anchor));let n=t(s);return M.range(s.anchor,n.head,n.goalColumn,n.bidiLevel||void 0,n.assoc)});return i.eq(r.state.selection)?!1:(r.dispatch(Wt(r.state,i)),!0)}function Ym(r,e){return Et(r,e,t=>r.moveByChar(t,e))}var Km=r=>Ym(r,!Je(r)),Zm=r=>Ym(r,Je(r));function eg(r,e){return Et(r,e,t=>r.moveByGroup(t,e))}var Ok=r=>eg(r,!Je(r)),vk=r=>eg(r,Je(r));var wk=r=>{let e=!Je(r);return Et(r,e,t=>_o(r.state,t,e))},kk=r=>{let e=Je(r);return Et(r,e,t=>_o(r.state,t,e))};function tg(r,e){return Et(r,e,t=>r.moveVertically(t,e))}var ig=r=>tg(r,!1),sg=r=>tg(r,!0);function rg(r,e){return Et(r,e,t=>r.moveVertically(t,e,Xm(r).height))}var Am=r=>rg(r,!1),Rm=r=>rg(r,!0),xk=r=>Et(r,!0,e=>Pi(r,e,!0)),Sk=r=>Et(r,!1,e=>Pi(r,e,!1)),Tk=r=>{let e=!Je(r);return Et(r,e,t=>Pi(r,t,e))},Pk=r=>{let e=Je(r);return Et(r,e,t=>Pi(r,t,e))},Ck=r=>Et(r,!1,e=>M.cursor(r.lineBlockAt(e.head).from)),Ek=r=>Et(r,!0,e=>M.cursor(r.lineBlockAt(e.head).to)),Mm=({state:r,dispatch:e})=>(e(Wt(r,{anchor:0})),!0),Dm=({state:r,dispatch:e})=>(e(Wt(r,{anchor:r.doc.length})),!0),Nm=({state:r,dispatch:e})=>(e(Wt(r,{anchor:r.selection.main.anchor,head:0})),!0),Im=({state:r,dispatch:e})=>(e(Wt(r,{anchor:r.selection.main.anchor,head:r.doc.length})),!0),Ak=({state:r,dispatch:e})=>(e(r.update({selection:{anchor:0,head:r.doc.length},userEvent:"select"})),!0),Rk=({state:r,dispatch:e})=>{let t=yo(r).map(({from:i,to:s})=>M.undirectionalRange(i,Math.min(s+1,r.doc.length)));return e(r.update({selection:M.create(t),userEvent:"select"})),!0},Mk=({state:r,dispatch:e})=>{let t=Us(r.selection,i=>{let s=Be(r),n=s.resolveStack(i.from,1);if(i.empty){let o=s.resolveStack(i.from,-1);o.node.from>=n.node.from&&o.node.to<=n.node.to&&(n=o)}for(let o=n;o;o=o.next){let{node:l}=o;if((l.from<i.from&&l.to>=i.to||l.to>i.to&&l.from<=i.from)&&o.next)return M.undirectionalRange(l.from,l.to)}return i});return t.eq(r.selection)?!1:(e(Wt(r,t)),!0)};function ng(r,e){let{state:t}=r,i=t.selection,s=t.selection.ranges.slice();for(let n of t.selection.ranges){let o=t.doc.lineAt(n.head);if(e?o.to<r.state.doc.length:o.from>0)for(let l=n;;){let a=r.moveVertically(l,e);if(a.head<o.from||a.head>o.to){s.some(h=>h.head==a.head)||s.push(a);break}else{if(a.head==l.head)break;l=a}}}return s.length==i.ranges.length?!1:(r.dispatch(Wt(t,M.create(s,s.length-1))),!0)}var Dk=r=>ng(r,!1),Nk=r=>ng(r,!0),Ik=({state:r,dispatch:e})=>{let t=r.selection,i=null;return t.ranges.length>1?i=M.create([t.main]):t.main.empty||(i=M.create([M.cursor(t.main.head)])),i?(e(Wt(r,i)),!0):!1};function Qr(r,e){if(r.state.readOnly)return!1;let t="delete.selection",{state:i}=r,s=i.changeByRange(n=>{let{from:o,to:l}=n;if(o==l){let a=e(n);a<o?(t="delete.backward",a=fo(r,a,!1)):a>o&&(t="delete.forward",a=fo(r,a,!0)),o=Math.min(o,a),l=Math.max(l,a)}else o=fo(r,o,!1),l=fo(r,l,!0);return o==l?{range:n}:{changes:{from:o,to:l},range:M.cursor(o,o<n.head?-1:1)}});return s.changes.empty?!1:(r.dispatch(i.update(s,{scrollIntoView:!0,userEvent:t,effects:t=="delete.selection"?z.announce.of(i.phrase("Selection deleted")):void 0})),!0)}function fo(r,e,t){if(r instanceof z)for(let i of r.state.facet(z.atomicRanges).map(s=>s(r)))i.between(e,e,(s,n)=>{s<e&&n>e&&(e=t?n:s)});return e}var og=(r,e,t)=>Qr(r,i=>{let s=i.from,{state:n}=r,o=n.doc.lineAt(s),l,a;if(t&&!e&&s>o.from&&s<o.from+200&&!/[^ \t]/.test(l=o.text.slice(0,s-o.from))){if(l[l.length-1]=="	")return s-1;let h=Vi(l,n.tabSize),c=h%Nr(n)||Nr(n);for(let u=0;u<c&&l[l.length-1-u]==" ";u++)s--;a=s}else a=Ce(o.text,s-o.from,e,e)+o.from,a==s&&o.number!=(e?n.doc.lines:1)?a+=e?1:-1:!e&&/[\ufe00-\ufe0f]/.test(o.text.slice(a-o.from,s-o.from))&&(a=Ce(o.text,a-o.from,!1,!1)+o.from);return a}),Oh=r=>og(r,!1,!0);var lg=r=>og(r,!0,!1),ag=(r,e)=>Qr(r,t=>{let i=t.head,{state:s}=r,n=s.doc.lineAt(i),o=s.charCategorizer(i);for(let l=null;;){if(i==(e?n.to:n.from)){i==t.head&&n.number!=(e?s.doc.lines:1)&&(i+=e?1:-1);break}let a=Ce(n.text,i-n.from,e)+n.from,h=n.text.slice(Math.min(i,a)-n.from,Math.max(i,a)-n.from),c=o(h);if(l!=null&&c!=l)break;(h!=" "||i!=t.head)&&(l=c),i=a}return i}),hg=r=>ag(r,!1),Lk=r=>ag(r,!0);var Qk=r=>Qr(r,e=>{let t=r.lineBlockAt(e.head).to;return e.head<t?t:Math.min(r.state.doc.length,e.head+1)});var qk=r=>Qr(r,e=>{let t=r.moveToLineBoundary(e,!1).head;return e.head>t?t:Math.max(0,e.head-1)}),Bk=r=>Qr(r,e=>{let t=r.moveToLineBoundary(e,!0).head;return e.head<t?t:Math.min(r.state.doc.length,e.head+1)});var $k=({state:r,dispatch:e})=>{if(r.readOnly)return!1;let t=r.changeByRange(i=>({changes:{from:i.from,to:i.to,insert:oe.of(["",""])},range:M.cursor(i.from)}));return e(r.update(t,{scrollIntoView:!0,userEvent:"input"})),!0},Fk=({state:r,dispatch:e})=>{if(r.readOnly)return!1;let t=r.changeByRange(i=>{if(!i.empty||i.from==0||i.from==r.doc.length)return{range:i};let s=i.from,n=r.doc.lineAt(s),o=s==n.from?s-1:Ce(n.text,s-n.from,!1)+n.from,l=s==n.to?s+1:Ce(n.text,s-n.from,!0)+n.from;return{changes:{from:o,to:l,insert:r.doc.slice(s,l).append(r.doc.slice(o,s))},range:M.cursor(l)}});return t.changes.empty?!1:(e(r.update(t,{scrollIntoView:!0,userEvent:"move.character"})),!0)};function yo(r){let e=[],t=-1;for(let i of r.selection.ranges){let s=r.doc.lineAt(i.from),n=r.doc.lineAt(i.to);if(!i.empty&&i.to==n.from&&(n=r.doc.lineAt(i.to-1)),t>=s.number){let o=e[e.length-1];o.to=n.to,o.ranges.push(i)}else e.push({from:s.from,to:n.to,ranges:[i]});t=n.number+1}return e}function fg(r,e,t){if(r.readOnly)return!1;let i=[],s=[];for(let n of yo(r)){if(t?n.to==r.doc.length:n.from==0)continue;let o=r.doc.lineAt(t?n.to+1:n.from-1),l=o.length+1;if(t){i.push({from:n.to,to:o.to},{from:n.from,insert:o.text+r.lineBreak});for(let a of n.ranges)s.push(M.range(Math.min(r.doc.length,a.anchor+l),Math.min(r.doc.length,a.head+l)))}else{i.push({from:o.from,to:n.from},{from:n.to,insert:r.lineBreak+o.text});for(let a of n.ranges)s.push(M.range(a.anchor-l,a.head-l))}}return i.length?(e(r.update({changes:i,scrollIntoView:!0,selection:M.create(s,r.selection.mainIndex),userEvent:"move.line"})),!0):!1}var Wk=({state:r,dispatch:e})=>fg(r,e,!1),zk=({state:r,dispatch:e})=>fg(r,e,!0);function cg(r,e,t){if(r.readOnly)return!1;let i=[];for(let n of yo(r))t?i.push({from:n.from,insert:r.doc.slice(n.from,n.to)+r.lineBreak}):i.push({from:n.to,insert:r.lineBreak+r.doc.slice(n.from,n.to)});let s=r.changes(i);return e(r.update({changes:s,selection:r.selection.map(s,t?1:-1),scrollIntoView:!0,userEvent:"input.copyline"})),!0}var jk=({state:r,dispatch:e})=>cg(r,e,!1),Hk=({state:r,dispatch:e})=>cg(r,e,!0),Vk=r=>{if(r.state.readOnly)return!1;let{state:e}=r,t=e.changes(yo(e).map(({from:s,to:n})=>(s>0?s--:n<e.doc.length&&n++,{from:s,to:n}))),i=Us(e.selection,s=>{let n;if(r.lineWrapping){let o=r.lineBlockAt(s.head),l=r.coordsAtPos(s.head,s.assoc||1);l&&(n=o.bottom+r.documentTop-l.bottom+r.defaultLineHeight/2)}return r.moveVertically(s,!0,n)}).map(t);return r.dispatch({changes:t,selection:i,scrollIntoView:!0,userEvent:"delete.line"}),!0};function Uk(r,e){if(/\(\)|\[\]|\{\}/.test(r.sliceDoc(e-1,e+1)))return{from:e,to:e};let t=Be(r).resolveInner(e),i=t.childBefore(e),s=t.childAfter(e),n;return i&&s&&i.to<=e&&s.from>=e&&(n=i.type.prop(ie.closedBy))&&n.indexOf(s.name)>-1&&r.doc.lineAt(i.to).from==r.doc.lineAt(s.from).from&&!/\S/.test(r.sliceDoc(i.to,s.from))?{from:i.to,to:s.from}:null}var Lm=dg(!1),Gk=dg(!0);function dg(r){return({state:e,dispatch:t})=>{if(e.readOnly)return!1;let i=e.changeByRange(s=>{let{from:n,to:o}=s,l=e.doc.lineAt(n),a=!r&&n==o&&Uk(e,n);r&&(n=o=(o<=l.to?l:e.doc.lineAt(o)).to);let h=new rs(e,{simulateBreak:n,simulateDoubleBreak:!!a}),c=ao(h,n);for(c==null&&(c=Vi(/^\s*/.exec(e.doc.lineAt(n).text)[0],e.tabSize));o<l.to&&/\s/.test(l.text[o-l.from]);)o++;a?{from:n,to:o}=a:n>l.from&&n<l.from+100&&!/\S/.test(l.text.slice(0,n))&&(n=l.from);let u=["",Hs(e,c)];return a&&u.push(Hs(e,h.lineIndent(l.from,-1))),{changes:{from:n,to:o,insert:oe.of(u)},range:M.cursor(n+1+u[1].length)}});return t(e.update(i,{scrollIntoView:!0,userEvent:"input"})),!0}}function xh(r,e){let t=-1;return r.changeByRange(i=>{let s=[];for(let o=i.from;o<=i.to;){let l=r.doc.lineAt(o);l.number>t&&(i.empty||i.to>l.from)&&(e(l,s,i),t=l.number),o=l.to+1}let n=r.changes(s);return{changes:s,range:M.range(n.mapPos(i.anchor,1),n.mapPos(i.head,1))}})}var Xk=({state:r,dispatch:e})=>{if(r.readOnly)return!1;let t=Object.create(null),i=new rs(r,{overrideIndentation:n=>{let o=t[n];return o??-1}}),s=xh(r,(n,o,l)=>{let a=ao(i,n.from);if(a==null)return;/\S/.test(n.text)||(a=0);let h=/^\s*/.exec(n.text)[0],c=Hs(r,a);(h!=c||l.from<n.from+h.length)&&(t[n.from]=a,o.push({from:n.from,to:n.from+h.length,insert:c}))});return s.changes.empty||e(r.update(s,{userEvent:"indent"})),!0},bo=({state:r,dispatch:e})=>r.readOnly?!1:(e(r.update(xh(r,(t,i)=>{i.push({from:t.from,insert:r.facet(Ti)})}),{userEvent:"input.indent"})),!0),Oo=({state:r,dispatch:e})=>r.readOnly?!1:(e(r.update(xh(r,(t,i)=>{let s=/^\s*/.exec(t.text)[0];if(!s)return;let n=Vi(s,r.tabSize),o=0,l=Hs(r,Math.max(0,n-Nr(r)));for(;o<s.length&&o<l.length&&s.charCodeAt(o)==l.charCodeAt(o);)o++;i.push({from:t.from+o,to:t.from+s.length,insert:l.slice(o)})}),{userEvent:"delete.dedent"})),!0),Jk=r=>(r.setTabFocusMode(),!0);var Yk=[{key:"Ctrl-b",run:mo,shift:Km,preventDefault:!0},{key:"Ctrl-f",run:go,shift:Zm},{key:"Ctrl-p",run:Um,shift:ig},{key:"Ctrl-n",run:Gm,shift:sg},{key:"Ctrl-a",run:gk,shift:Ck},{key:"Ctrl-e",run:_k,shift:Ek},{key:"Ctrl-d",run:lg},{key:"Ctrl-h",run:Oh},{key:"Ctrl-k",run:Qk},{key:"Ctrl-Alt-h",run:hg},{key:"Ctrl-o",run:$k},{key:"Ctrl-t",run:Fk},{key:"Ctrl-v",run:bh}],Kk=[{key:"ArrowLeft",run:mo,shift:Km,preventDefault:!0},{key:"Mod-ArrowLeft",mac:"Alt-ArrowLeft",run:lk,shift:Ok,preventDefault:!0},{mac:"Cmd-ArrowLeft",run:pk,shift:Tk,preventDefault:!0},{key:"ArrowRight",run:go,shift:Zm,preventDefault:!0},{key:"Mod-ArrowRight",mac:"Alt-ArrowRight",run:ak,shift:vk,preventDefault:!0},{mac:"Cmd-ArrowRight",run:mk,shift:Pk,preventDefault:!0},{key:"ArrowUp",run:Um,shift:ig,preventDefault:!0},{mac:"Cmd-ArrowUp",run:Mm,shift:Nm},{mac:"Ctrl-ArrowUp",run:Em,shift:Am},{key:"ArrowDown",run:Gm,shift:sg,preventDefault:!0},{mac:"Cmd-ArrowDown",run:Dm,shift:Im},{mac:"Ctrl-ArrowDown",run:bh,shift:Rm},{key:"PageUp",run:Em,shift:Am},{key:"PageDown",run:bh,shift:Rm},{key:"Home",run:uk,shift:Sk,preventDefault:!0},{key:"Mod-Home",run:Mm,shift:Nm},{key:"End",run:dk,shift:xk,preventDefault:!0},{key:"Mod-End",run:Dm,shift:Im},{key:"Enter",run:Lm,shift:Lm},{key:"Mod-a",run:Ak},{key:"Backspace",run:Oh,shift:Oh,preventDefault:!0},{key:"Delete",run:lg,preventDefault:!0},{key:"Mod-Backspace",mac:"Alt-Backspace",run:hg,preventDefault:!0},{key:"Mod-Delete",mac:"Alt-Delete",run:Lk,preventDefault:!0},{mac:"Mod-Backspace",run:qk,preventDefault:!0},{mac:"Mod-Delete",run:Bk,preventDefault:!0}].concat(Yk.map(r=>({mac:r.key,run:r.run,shift:r.shift}))),ug=[{key:"Alt-ArrowLeft",mac:"Ctrl-ArrowLeft",run:fk,shift:wk},{key:"Alt-ArrowRight",mac:"Ctrl-ArrowRight",run:ck,shift:kk},{key:"Alt-ArrowUp",run:Wk},{key:"Shift-Alt-ArrowUp",run:jk},{key:"Alt-ArrowDown",run:zk},{key:"Shift-Alt-ArrowDown",run:Hk},{key:"Mod-Alt-ArrowUp",run:Dk},{key:"Mod-Alt-ArrowDown",run:Nk},{key:"Escape",run:Ik},{key:"Mod-Enter",run:Gk},{key:"Alt-l",mac:"Ctrl-l",run:Rk},{key:"Mod-i",run:Mk,preventDefault:!0},{key:"Mod-[",run:Oo},{key:"Mod-]",run:bo},{key:"Mod-Alt-\\",run:Xk},{key:"Shift-Mod-k",run:Vk},{key:"Shift-Mod-\\",run:bk},{key:"Mod-/",run:vh},{key:"Alt-A",mac:"Ctrl-A",run:Vw},{key:"Ctrl-m",mac:"Shift-Alt-m",run:Jk}].concat(Kk),pg={key:"Tab",run:bo,shift:Oo};var Ph=class r{constructor(e,t,i,s,n,o,l,a,h,c=0,u){this.p=e,this.stack=t,this.state=i,this.reducePos=s,this.pos=n,this.score=o,this.buffer=l,this.bufferBase=a,this.curContext=h,this.lookAhead=c,this.parent=u}toString(){return`[${this.stack.filter((e,t)=>t%3==0).concat(this.state)}]@${this.pos}${this.score?"!"+this.score:""}`}static start(e,t,i=0){let s=e.parser.context;return new r(e,[],t,i,i,0,[],0,s?new vo(s,s.start):null,0,null)}get context(){return this.curContext?this.curContext.context:null}pushState(e,t){this.stack.push(this.state,t,this.bufferBase+this.buffer.length),this.state=e}reduce(e){var t;let i=e>>19,s=e&65535,{parser:n}=this.p,o=this.reducePos<this.pos-25&&this.setLookAhead(this.pos),l=n.dynamicPrecedence(s);if(l&&(this.score+=l),i==0){s<n.minRepeatTerm&&this.reducePos<this.pos&&(this.reducePos=this.pos),this.pushState(n.getGoto(this.state,s,!0),this.reducePos),s<n.minRepeatTerm&&this.storeNode(s,this.reducePos,this.reducePos,o?8:4,!0),this.reduceContext(s,this.reducePos);return}let a=this.stack.length-(i-1)*3-(e&262144?6:0),h=a?this.stack[a-2]:this.p.ranges[0].from;s<n.minRepeatTerm&&h==this.reducePos&&this.reducePos<this.pos&&(this.reducePos=this.pos);let c=this.reducePos-h;c>=2e3&&!(!((t=this.p.parser.nodeSet.types[s])===null||t===void 0)&&t.isAnonymous)&&(h==this.p.lastBigReductionStart?(this.p.bigReductionCount++,this.p.lastBigReductionSize=c):this.p.lastBigReductionSize<c&&(this.p.bigReductionCount=1,this.p.lastBigReductionStart=h,this.p.lastBigReductionSize=c));let u=a?this.stack[a-1]:0,p=this.bufferBase+this.buffer.length-u;if(s<n.minRepeatTerm||e&131072){let y=n.stateFlag(this.state,1)?this.pos:this.reducePos;this.storeNode(s,h,y,p+4,!0)}if(e&262144)this.state=this.stack[a];else{let y=this.stack[a-3];this.state=n.getGoto(y,s,!0)}for(;this.stack.length>a;)this.stack.pop();this.reduceContext(s,h)}storeNode(e,t,i,s=4,n=!1){if(e==0&&(!this.stack.length||this.stack[this.stack.length-1]<this.buffer.length+this.bufferBase)){let o=this.buffer.length;if(o>0&&this.buffer[o-4]==0&&this.buffer[o-1]>-1){if(t==i)return;if(this.buffer[o-2]>=t){this.buffer[o-2]=i;return}}}if(!n||this.pos==i)this.buffer.push(e,t,i,s);else{let o=this.buffer.length;if(o>0&&(this.buffer[o-4]!=0||this.buffer[o-1]<0)){let l=!1;for(let a=o;a>0&&this.buffer[a-2]>i;a-=4)if(this.buffer[a-1]>=0){l=!0;break}if(l)for(;o>0&&this.buffer[o-2]>i;)this.buffer[o]=this.buffer[o-4],this.buffer[o+1]=this.buffer[o-3],this.buffer[o+2]=this.buffer[o-2],this.buffer[o+3]=this.buffer[o-1],o-=4,s>4&&(s-=4)}this.buffer[o]=e,this.buffer[o+1]=t,this.buffer[o+2]=i,this.buffer[o+3]=s}}shift(e,t,i,s){if(e&131072)this.pushState(e&65535,this.pos);else if(e&262144)this.pos=s,this.shiftContext(t,i),t<=this.p.parser.maxNode&&this.buffer.push(t,i,s,4);else{let n=e,{parser:o}=this.p;this.pos=s;let l=o.stateFlag(n,1);!l&&(s>i||t<=o.maxNode)&&(this.reducePos=s),this.pushState(n,l?i:Math.min(i,this.reducePos)),this.shiftContext(t,i),t<=o.maxNode&&this.buffer.push(t,i,s,4)}}apply(e,t,i,s){e&65536?this.reduce(e):this.shift(e,t,i,s)}useNode(e,t){let i=this.p.reused.length-1;(i<0||this.p.reused[i]!=e)&&(this.p.reused.push(e),i++);let s=this.pos;this.reducePos=this.pos=s+e.length,this.pushState(t,s),this.buffer.push(i,s,this.reducePos,-1),this.curContext&&this.updateContext(this.curContext.tracker.reuse(this.curContext.context,e,this,this.p.stream.reset(this.pos-e.length)))}split(){let e=this,t=e.buffer.length;for(t&&e.buffer[t-4]==0&&(t-=4);t>0&&e.buffer[t-2]>e.reducePos;)t-=4;let i=e.buffer.slice(t),s=e.bufferBase+t;for(;e&&s==e.bufferBase;)e=e.parent;return new r(this.p,this.stack.slice(),this.state,this.reducePos,this.pos,this.score,i,s,this.curContext,this.lookAhead,e)}recoverByDelete(e,t){let i=e<=this.p.parser.maxNode;i&&this.storeNode(e,this.pos,t,4),this.storeNode(0,this.pos,t,i?8:4),this.pos=this.reducePos=t,this.score-=190}canShift(e){for(let t=new Ch(this);;){let i=this.p.parser.stateSlot(t.state,4)||this.p.parser.hasAction(t.state,e);if(i==0)return!1;if(!(i&65536))return!0;t.reduce(i)}}recoverByInsert(e){if(this.stack.length>=300)return[];let t=this.p.parser.nextStates(this.state);if(t.length>8||this.stack.length>=120){let s=[];for(let n=0,o;n<t.length;n+=2)(o=t[n+1])!=this.state&&this.p.parser.hasAction(o,e)&&s.push(t[n],o);if(this.stack.length<120)for(let n=0;s.length<8&&n<t.length;n+=2){let o=t[n+1];s.some((l,a)=>a&1&&l==o)||s.push(t[n],o)}t=s}let i=[];for(let s=0;s<t.length&&i.length<4;s+=2){let n=t[s+1];if(n==this.state)continue;let o=this.split();o.pushState(n,this.pos),o.storeNode(0,o.pos,o.pos,4,!0),o.shiftContext(t[s],this.pos),o.reducePos=this.pos,o.score-=200,i.push(o)}return i}forceReduce(){let{parser:e}=this.p,t=e.stateSlot(this.state,5);if(!(t&65536))return!1;if(!e.validAction(this.state,t)){let i=t>>19,s=t&65535,n=this.stack.length-i*3;if(n<0||e.getGoto(this.stack[n],s,!1)<0){let o=this.findForcedReduction();if(o==null)return!1;t=o}this.storeNode(0,this.pos,this.pos,4,!0),this.score-=100}return this.reducePos=this.pos,this.reduce(t),!0}findForcedReduction(){let{parser:e}=this.p,t=[],i=(s,n)=>{if(!t.includes(s))return t.push(s),e.allActions(s,o=>{if(!(o&393216))if(o&65536){let l=(o>>19)-n;if(l>1){let a=o&65535,h=this.stack.length-l*3;if(h>=0&&e.getGoto(this.stack[h],a,!1)>=0)return l<<19|65536|a}}else{let l=i(o,n+1);if(l!=null)return l}})};return i(this.state,0)}forceAll(){for(;!this.p.parser.stateFlag(this.state,2);)if(!this.forceReduce()){this.storeNode(0,this.pos,this.pos,4,!0);break}return this}get deadEnd(){if(this.stack.length!=3)return!1;let{parser:e}=this.p;return e.data[e.stateSlot(this.state,1)]==65535&&!e.stateSlot(this.state,4)}restart(){this.storeNode(0,this.pos,this.pos,4,!0),this.state=this.stack[0],this.stack.length=0}sameState(e){if(this.state!=e.state||this.stack.length!=e.stack.length)return!1;for(let t=0;t<this.stack.length;t+=3)if(this.stack[t]!=e.stack[t])return!1;return!0}get parser(){return this.p.parser}dialectEnabled(e){return this.p.parser.dialect.flags[e]}shiftContext(e,t){this.curContext&&this.updateContext(this.curContext.tracker.shift(this.curContext.context,e,this,this.p.stream.reset(t)))}reduceContext(e,t){this.curContext&&this.updateContext(this.curContext.tracker.reduce(this.curContext.context,e,this,this.p.stream.reset(t)))}emitContext(){let e=this.buffer.length-1;(e<0||this.buffer[e]!=-3)&&this.buffer.push(this.curContext.hash,this.pos,this.pos,-3)}emitLookAhead(){let e=this.buffer.length-1;(e<0||this.buffer[e]!=-4)&&this.buffer.push(this.lookAhead,this.pos,this.pos,-4)}updateContext(e){if(e!=this.curContext.context){let t=new vo(this.curContext.tracker,e);t.hash!=this.curContext.hash&&this.emitContext(),this.curContext=t}}setLookAhead(e){return e<=this.lookAhead?!1:(this.emitLookAhead(),this.lookAhead=e,!0)}close(){this.curContext&&this.curContext.tracker.strict&&this.emitContext(),this.lookAhead>0&&this.emitLookAhead()}},vo=class{constructor(e,t){this.tracker=e,this.context=t,this.hash=e.strict?e.hash(t):0}},Ch=class{constructor(e){this.start=e,this.state=e.state,this.stack=e.stack,this.base=this.stack.length}reduce(e){let t=e&65535,i=e>>19;i==0?(this.stack==this.start.stack&&(this.stack=this.stack.slice()),this.stack.push(this.state,0,0),this.base+=3):this.base-=(i-1)*3;let s=this.start.p.parser.getGoto(this.stack[this.base-3],t,!0);this.state=s}},Eh=class r{constructor(e,t,i){this.stack=e,this.pos=t,this.index=i,this.buffer=e.buffer,this.index==0&&this.maybeNext()}static create(e,t=e.bufferBase+e.buffer.length){return new r(e,t,t-e.bufferBase)}maybeNext(){let e=this.stack.parent;e!=null&&(this.index=this.stack.bufferBase-e.bufferBase,this.stack=e,this.buffer=e.buffer)}get id(){return this.buffer[this.index-4]}get start(){return this.buffer[this.index-3]}get end(){return this.buffer[this.index-2]}get size(){return this.buffer[this.index-1]}next(){this.index-=4,this.pos-=4,this.index==0&&this.maybeNext()}fork(){return new r(this.stack,this.pos,this.index)}};function qr(r,e=Uint16Array){if(typeof r!="string")return r;let t=null;for(let i=0,s=0;i<r.length;){let n=0;for(;;){let o=r.charCodeAt(i++),l=!1;if(o==126){n=65535;break}o>=92&&o--,o>=34&&o--;let a=o-32;if(a>=46&&(a-=46,l=!0),n+=a,l)break;n*=46}t?t[s++]=n:t=new e(n)}return t}var Gs=class{constructor(){this.start=-1,this.value=-1,this.end=-1,this.extended=-1,this.lookAhead=0,this.mask=0,this.context=0}},mg=new Gs,Ah=class{constructor(e,t){this.input=e,this.ranges=t,this.chunk="",this.chunkOff=0,this.chunk2="",this.chunk2Pos=0,this.next=-1,this.token=mg,this.rangeIndex=0,this.pos=this.chunkPos=t[0].from,this.range=t[0],this.end=t[t.length-1].to,this.readNext()}resolveOffset(e,t){let i=this.range,s=this.rangeIndex,n=this.pos+e;for(;n<i.from;){if(!s)return null;let o=this.ranges[--s];n-=i.from-o.to,i=o}for(;t<0?n>i.to:n>=i.to;){if(s==this.ranges.length-1)return null;let o=this.ranges[++s];n+=o.from-i.to,i=o}return n}clipPos(e){if(e>=this.range.from&&e<this.range.to)return e;for(let t of this.ranges)if(t.to>e)return Math.max(e,t.from);return this.end}peek(e){let t=this.chunkOff+e,i,s;if(t>=0&&t<this.chunk.length)i=this.pos+e,s=this.chunk.charCodeAt(t);else{let n=this.resolveOffset(e,1);if(n==null)return-1;if(i=n,i>=this.chunk2Pos&&i<this.chunk2Pos+this.chunk2.length)s=this.chunk2.charCodeAt(i-this.chunk2Pos);else{let o=this.rangeIndex,l=this.range;for(;l.to<=i;)l=this.ranges[++o];this.chunk2=this.input.chunk(this.chunk2Pos=i),i+this.chunk2.length>l.to&&(this.chunk2=this.chunk2.slice(0,l.to-i)),s=this.chunk2.charCodeAt(0)}}return i>=this.token.lookAhead&&(this.token.lookAhead=i+1),s}acceptToken(e,t=0){let i=t?this.resolveOffset(t,-1):this.pos;if(i==null||i<this.token.start)throw new RangeError("Token end out of bounds");this.token.value=e,this.token.end=i}acceptTokenTo(e,t){this.token.value=e,this.token.end=t}getChunk(){if(this.pos>=this.chunk2Pos&&this.pos<this.chunk2Pos+this.chunk2.length){let{chunk:e,chunkPos:t}=this;this.chunk=this.chunk2,this.chunkPos=this.chunk2Pos,this.chunk2=e,this.chunk2Pos=t,this.chunkOff=this.pos-this.chunkPos}else{this.chunk2=this.chunk,this.chunk2Pos=this.chunkPos;let e=this.input.chunk(this.pos),t=this.pos+e.length;this.chunk=t>this.range.to?e.slice(0,this.range.to-this.pos):e,this.chunkPos=this.pos,this.chunkOff=0}}readNext(){return this.chunkOff>=this.chunk.length&&(this.getChunk(),this.chunkOff==this.chunk.length)?this.next=-1:this.next=this.chunk.charCodeAt(this.chunkOff)}advance(e=1){for(this.chunkOff+=e;this.pos+e>=this.range.to;){if(this.rangeIndex==this.ranges.length-1)return this.setDone();e-=this.range.to-this.pos,this.range=this.ranges[++this.rangeIndex],this.pos=this.range.from}return this.pos+=e,this.pos>=this.token.lookAhead&&(this.token.lookAhead=this.pos+1),this.readNext()}setDone(){return this.pos=this.chunkPos=this.end,this.range=this.ranges[this.rangeIndex=this.ranges.length-1],this.chunk="",this.next=-1}reset(e,t){if(t?(this.token=t,t.start=e,t.lookAhead=e+1,t.value=t.extended=-1):this.token=mg,this.pos!=e){if(this.pos=e,e==this.end)return this.setDone(),this;for(;e<this.range.from;)this.range=this.ranges[--this.rangeIndex];for(;e>=this.range.to;)this.range=this.ranges[++this.rangeIndex];e>=this.chunkPos&&e<this.chunkPos+this.chunk.length?this.chunkOff=e-this.chunkPos:(this.chunk="",this.chunkOff=0),this.readNext()}return this}read(e,t){if(e>=this.chunkPos&&t<=this.chunkPos+this.chunk.length)return this.chunk.slice(e-this.chunkPos,t-this.chunkPos);if(e>=this.chunk2Pos&&t<=this.chunk2Pos+this.chunk2.length)return this.chunk2.slice(e-this.chunk2Pos,t-this.chunk2Pos);if(e>=this.range.from&&t<=this.range.to)return this.input.read(e,t);let i="";for(let s of this.ranges){if(s.from>=t)break;s.to>e&&(i+=this.input.read(Math.max(s.from,e),Math.min(s.to,t)))}return i}},Ci=class{constructor(e,t){this.data=e,this.id=t}token(e,t){let{parser:i}=t.p;Og(this.data,e,t,this.id,i.data,i.tokenPrecTable)}};Ci.prototype.contextual=Ci.prototype.fallback=Ci.prototype.extend=!1;var Rh=class{constructor(e,t,i){this.precTable=t,this.elseToken=i,this.data=typeof e=="string"?qr(e):e}token(e,t){let i=e.pos,s=0;for(;;){let n=e.next<0,o=e.resolveOffset(1,1);if(Og(this.data,e,t,0,this.data,this.precTable),e.token.value>-1)break;if(this.elseToken==null)return;if(n||s++,o==null)break;e.reset(o,e.token)}s&&(e.reset(i,e.token),e.acceptToken(this.elseToken,s))}};Rh.prototype.contextual=Ci.prototype.fallback=Ci.prototype.extend=!1;var os=class{constructor(e,t={}){this.token=e,this.contextual=!!t.contextual,this.fallback=!!t.fallback,this.extend=!!t.extend}};function Og(r,e,t,i,s,n){let o=0,l=1<<i,{dialect:a}=t.p.parser;e:for(;l&r[o];){let h=r[o+1];for(let y=o+3;y<h;y+=2)if((r[y+1]&l)>0){let O=r[y];if(a.allows(O)&&(e.token.value==-1||e.token.value==O||ex(O,e.token.value,s,n))){e.acceptToken(O);break}}let c=e.next,u=0,p=r[o+2];if(e.next<0&&p>u&&r[h+p*3-3]==65535){o=r[h+p*3-1];continue e}for(;u<p;){let y=u+p>>1,O=h+y+(y<<1),b=r[O],v=r[O+1]||65536;if(c<b)p=y;else if(c>=v)u=y+1;else{o=r[O+2],e.advance();continue e}}break}}function gg(r,e,t){for(let i=e,s;(s=r[i])!=65535;i++)if(s==t)return i-e;return-1}function ex(r,e,t,i){let s=gg(t,i,e);return s<0||gg(t,i,r)<s}var pt=typeof process<"u"&&process.env&&/\bparse\b/.test(process.env.LOG),Sh=null;function _g(r,e,t){let i=r.cursor(xe.IncludeAnonymous);for(i.moveTo(e);;)if(!(t<0?i.childBefore(e):i.childAfter(e)))for(;;){if((t<0?i.to<e:i.from>e)&&!i.type.isError)return t<0?Math.max(0,Math.min(i.to-1,e-25)):Math.min(r.length,Math.max(i.from+1,e+25));if(t<0?i.prevSibling():i.nextSibling())break;if(!i.parent())return t<0?0:r.length}}var Mh=class{constructor(e,t){this.fragments=e,this.nodeSet=t,this.i=0,this.fragment=null,this.safeFrom=-1,this.safeTo=-1,this.trees=[],this.start=[],this.index=[],this.nextFragment()}nextFragment(){let e=this.fragment=this.i==this.fragments.length?null:this.fragments[this.i++];if(e){for(this.safeFrom=e.openStart?_g(e.tree,e.from+e.offset,1)-e.offset:e.from,this.safeTo=e.openEnd?_g(e.tree,e.to+e.offset,-1)-e.offset:e.to;this.trees.length;)this.trees.pop(),this.start.pop(),this.index.pop();this.trees.push(e.tree),this.start.push(-e.offset),this.index.push(0),this.nextStart=this.safeFrom}else this.nextStart=1e9}nodeAt(e){if(e<this.nextStart)return null;for(;this.fragment&&this.safeTo<=e;)this.nextFragment();if(!this.fragment)return null;for(;;){let t=this.trees.length-1;if(t<0)return this.nextFragment(),null;let i=this.trees[t],s=this.index[t];if(s==i.children.length){this.trees.pop(),this.start.pop(),this.index.pop();continue}let n=i.children[s],o=this.start[t]+i.positions[s];if(o>e)return this.nextStart=o,null;if(n instanceof Te){if(o==e){if(o<this.safeFrom)return null;let l=o+n.length;if(l<=this.safeTo){let a=n.prop(ie.lookAhead);if(!a||l+a<this.fragment.to)return n}}this.index[t]++,o+n.length>=Math.max(this.safeFrom,e)&&(this.trees.push(n),this.start.push(o),this.index.push(0))}else this.index[t]++,this.nextStart=o+n.length}}},Dh=class{constructor(e,t){this.stream=t,this.tokens=[],this.mainToken=null,this.actions=[],this.tokens=e.tokenizers.map(i=>new Gs)}getActions(e){let t=0,i=null,{parser:s}=e.p,{tokenizers:n}=s,o=s.stateSlot(e.state,3),l=e.curContext?e.curContext.hash:0,a=0;for(let h=0;h<n.length;h++){if(!(1<<h&o))continue;let c=n[h],u=this.tokens[h];if(!(i&&!c.fallback)&&((c.contextual||u.start!=e.pos||u.mask!=o||u.context!=l)&&(this.updateCachedToken(u,c,e),u.mask=o,u.context=l),u.lookAhead>u.end+25&&(a=Math.max(u.lookAhead,a)),u.value!=0)){let p=t;if(u.extended>-1&&(t=this.addActions(e,u.extended,u.end,t)),t=this.addActions(e,u.value,u.end,t),!c.extend&&(i=u,t>p))break}}for(;this.actions.length>t;)this.actions.pop();return a&&e.setLookAhead(a),!i&&e.pos==this.stream.end&&(i=new Gs,i.value=e.p.parser.eofTerm,i.start=i.end=e.pos,t=this.addActions(e,i.value,i.end,t)),this.mainToken=i,this.actions}getMainToken(e){if(this.mainToken)return this.mainToken;let t=new Gs,{pos:i,p:s}=e;return t.start=i,t.end=Math.min(i+1,s.stream.end),t.value=i==s.stream.end?s.parser.eofTerm:0,t}updateCachedToken(e,t,i){let s=this.stream.clipPos(i.pos);if(t.token(this.stream.reset(s,e),i),e.value>-1){let{parser:n}=i.p;for(let o=0;o<n.specialized.length;o++)if(n.specialized[o]==e.value){let l=n.specializers[o](this.stream.read(e.start,e.end),i);if(l>=0&&i.p.parser.dialect.allows(l>>1)){l&1?e.extended=l>>1:e.value=l>>1;break}}}else e.value=0,e.end=this.stream.clipPos(s+1)}putAction(e,t,i,s){for(let n=0;n<s;n+=3)if(this.actions[n]==e)return s;return this.actions[s++]=e,this.actions[s++]=t,this.actions[s++]=i,s}addActions(e,t,i,s){let{state:n}=e,{parser:o}=e.p,{data:l}=o;for(let a=0;a<2;a++)for(let h=o.stateSlot(n,a?2:1);;h+=3){if(l[h]==65535)if(l[h+1]==1)h=fi(l,h+2);else{s==0&&l[h+1]==2&&(s=this.putAction(fi(l,h+2),t,i,s));break}l[h]==t&&(s=this.putAction(fi(l,h+1),t,i,s))}return s}},Nh=class{constructor(e,t,i,s){this.parser=e,this.input=t,this.ranges=s,this.recovering=0,this.nextStackID=9812,this.minStackPos=0,this.reused=[],this.stoppedAt=null,this.lastBigReductionStart=-1,this.lastBigReductionSize=0,this.bigReductionCount=0,this.stream=new Ah(t,s),this.tokens=new Dh(e,this.stream),this.topTerm=e.top[1];let{from:n}=s[0];this.stacks=[Ph.start(this,e.top[0],n)],this.fragments=i.length&&this.stream.end-n>e.bufferLength*4?new Mh(i,e.nodeSet):null}get parsedPos(){return this.minStackPos}advance(){let e=this.stacks,t=this.minStackPos,i=this.stacks=[],s,n;if(this.bigReductionCount>300&&e.length==1){let[o]=e;for(;o.forceReduce()&&o.stack.length&&o.stack[o.stack.length-2]>=this.lastBigReductionStart;);this.bigReductionCount=this.lastBigReductionSize=0}for(let o=0;o<e.length;o++){let l=e[o];for(;;){if(this.tokens.mainToken=null,l.pos>t)i.push(l);else{if(this.advanceStack(l,i,e))continue;{s||(s=[],n=[]),s.push(l);let a=this.tokens.getMainToken(l);n.push(a.value,a.end)}}break}}if(!i.length){let o=s&&tx(s);if(o)return pt&&console.log("Finish with "+this.stackID(o)),this.stackToTree(o);if(this.parser.strict)throw pt&&s&&console.log("Stuck with token "+(this.tokens.mainToken?this.parser.getName(this.tokens.mainToken.value):"none")),new SyntaxError("No parse at "+t);this.recovering||(this.recovering=5)}if(this.recovering&&s){let o=this.stoppedAt!=null&&s[0].pos>this.stoppedAt?s[0]:this.runRecovery(s,n,i);if(o)return pt&&console.log("Force-finish "+this.stackID(o)),this.stackToTree(o.forceAll())}if(this.recovering){let o=this.recovering==1?1:this.recovering*3;if(i.length>o)for(i.sort((l,a)=>a.score-l.score);i.length>o;)i.pop();i.some(l=>l.reducePos>t)&&this.recovering--}else if(i.length>1){e:for(let o=0;o<i.length-1;o++){let l=i[o];for(let a=o+1;a<i.length;a++){let h=i[a];if(l.sameState(h)||l.buffer.length>500&&h.buffer.length>500)if((l.score-h.score||l.buffer.length-h.buffer.length)>0)i.splice(a--,1);else{i.splice(o--,1);continue e}}}i.length>12&&(i.sort((o,l)=>l.score-o.score),i.splice(12,i.length-12))}this.minStackPos=i[0].pos;for(let o=1;o<i.length;o++)i[o].pos<this.minStackPos&&(this.minStackPos=i[o].pos);return null}stopAt(e){if(this.stoppedAt!=null&&this.stoppedAt<e)throw new RangeError("Can't move stoppedAt forward");this.stoppedAt=e}advanceStack(e,t,i){let s=e.pos,{parser:n}=this,o=pt?this.stackID(e)+" -> ":"";if(this.stoppedAt!=null&&s>this.stoppedAt)return e.forceReduce()?e:null;if(this.fragments){let h=e.curContext&&e.curContext.tracker.strict,c=h?e.curContext.hash:0;for(let u=this.fragments.nodeAt(s);u;){let p=this.parser.nodeSet.types[u.type.id]==u.type?n.getGoto(e.state,u.type.id):-1;if(p>-1&&u.length&&(!h||(u.prop(ie.contextHash)||0)==c))return e.useNode(u,p),pt&&console.log(o+this.stackID(e)+` (via reuse of ${n.getName(u.type.id)})`),!0;if(!(u instanceof Te)||u.children.length==0||u.positions[0]>0)break;let y=u.children[0];if(y instanceof Te&&u.positions[0]==0)u=y;else break}}let l=n.stateSlot(e.state,4);if(l>0)return e.reduce(l),pt&&console.log(o+this.stackID(e)+` (via always-reduce ${n.getName(l&65535)})`),!0;if(e.stack.length>=8400)for(;e.stack.length>6e3&&e.forceReduce(););let a=this.tokens.getActions(e);for(let h=0;h<a.length;){let c=a[h++],u=a[h++],p=a[h++],y=h==a.length||!i,O=y?e:e.split(),b=this.tokens.mainToken;if(O.apply(c,u,b?b.start:O.pos,p),pt&&console.log(o+this.stackID(O)+` (via ${c&65536?`reduce of ${n.getName(c&65535)}`:"shift"} for ${n.getName(u)} @ ${s}${O==e?"":", split"})`),y)return!0;O.pos>s?t.push(O):i.push(O)}return!1}advanceFully(e,t){let i=e.pos;for(;;){if(!this.advanceStack(e,null,null))return!1;if(e.pos>i)return yg(e,t),!0}}runRecovery(e,t,i){let s=null,n=!1;for(let o=0;o<e.length;o++){let l=e[o],a=t[o<<1],h=t[(o<<1)+1],c=pt?this.stackID(l)+" -> ":"";if(l.deadEnd&&(n||(n=!0,l.restart(),pt&&console.log(c+this.stackID(l)+" (restarted)"),this.advanceFully(l,i))))continue;let u=l.split(),p=c;for(let y=0;y<10&&u.forceReduce()&&(pt&&console.log(p+this.stackID(u)+" (via force-reduce)"),!this.advanceFully(u,i));y++)pt&&(p=this.stackID(u)+" -> ");for(let y of l.recoverByInsert(a))pt&&console.log(c+this.stackID(y)+" (via recover-insert)"),this.advanceFully(y,i);this.stream.end>l.pos?(h==l.pos&&(h++,a=0),l.recoverByDelete(a,h),pt&&console.log(c+this.stackID(l)+` (via recover-delete ${this.parser.getName(a)})`),yg(l,i)):(!s||s.score<u.score)&&(s=u)}return s}stackToTree(e){return e.close(),Te.build({buffer:Eh.create(e),nodeSet:this.parser.nodeSet,topID:this.topTerm,maxBufferLength:this.parser.bufferLength,reused:this.reused,start:this.ranges[0].from,length:e.pos-this.ranges[0].from,minRepeatType:this.parser.minRepeatTerm})}stackID(e){let t=(Sh||(Sh=new WeakMap)).get(e);return t||Sh.set(e,t=String.fromCodePoint(this.nextStackID++)),t+e}};function yg(r,e){for(let t=0;t<e.length;t++){let i=e[t];if(i.pos==r.pos&&i.sameState(r)){e[t].score<r.score&&(e[t]=r);return}}e.push(r)}var Ih=class{constructor(e,t,i){this.source=e,this.flags=t,this.disabled=i}allows(e){return!this.disabled||this.disabled[e]==0}},Th=r=>r,wo=class{constructor(e){this.start=e.start,this.shift=e.shift||Th,this.reduce=e.reduce||Th,this.reuse=e.reuse||Th,this.hash=e.hash||(()=>0),this.strict=e.strict!==!1}},ko=class r extends Fs{constructor(e){if(super(),this.wrappers=[],e.version!=14)throw new RangeError(`Parser version (${e.version}) doesn't match runtime version (14)`);let t=e.nodeNames.split(" ");this.minRepeatTerm=t.length;for(let l=0;l<e.repeatNodeCount;l++)t.push("");let i=Object.keys(e.topRules).map(l=>e.topRules[l][1]),s=[];for(let l=0;l<t.length;l++)s.push([]);function n(l,a,h){s[l].push([a,a.deserialize(String(h))])}if(e.nodeProps)for(let l of e.nodeProps){let a=l[0];typeof a=="string"&&(a=ie[a]);for(let h=1;h<l.length;){let c=l[h++];if(c>=0)n(c,a,l[h++]);else{let u=l[h+-c];for(let p=-c;p>0;p--)n(l[h++],a,u);h++}}}this.nodeSet=new Cr(t.map((l,a)=>Xe.define({name:a>=this.minRepeatTerm?void 0:l,id:a,props:s[a],top:i.indexOf(a)>-1,error:a==0,skipped:e.skippedNodes&&e.skippedNodes.indexOf(a)>-1}))),e.propSources&&(this.nodeSet=this.nodeSet.extend(...e.propSources)),this.strict=!1,this.bufferLength=1024;let o=qr(e.tokenData);this.context=e.context,this.specializerSpecs=e.specialized||[],this.specialized=new Uint16Array(this.specializerSpecs.length);for(let l=0;l<this.specializerSpecs.length;l++)this.specialized[l]=this.specializerSpecs[l].term;this.specializers=this.specializerSpecs.map(bg),this.states=qr(e.states,Uint32Array),this.data=qr(e.stateData),this.goto=qr(e.goto),this.maxTerm=e.maxTerm,this.tokenizers=e.tokenizers.map(l=>typeof l=="number"?new Ci(o,l):l),this.topRules=e.topRules,this.dialects=e.dialects||{},this.dynamicPrecedences=e.dynamicPrecedences||null,this.tokenPrecTable=e.tokenPrec,this.termNames=e.termNames||null,this.maxNode=this.nodeSet.types.length-1,this.dialect=this.parseDialect(),this.top=this.topRules[Object.keys(this.topRules)[0]]}createParse(e,t,i){let s=new Nh(this,e,t,i);for(let n of this.wrappers)s=n(s,e,t,i);return s}getGoto(e,t,i=!1){let s=this.goto;if(t>=s[0])return-1;for(let n=s[t+1];;){let o=s[n++],l=o&1,a=s[n++];if(l&&i)return a;for(let h=n+(o>>1);n<h;n++)if(s[n]==e)return a;if(l)return-1}}hasAction(e,t){let i=this.data;for(let s=0;s<2;s++)for(let n=this.stateSlot(e,s?2:1),o;;n+=3){if((o=i[n])==65535)if(i[n+1]==1)o=i[n=fi(i,n+2)];else{if(i[n+1]==2)return fi(i,n+2);break}if(o==t||o==0)return fi(i,n+1)}return 0}stateSlot(e,t){return this.states[e*6+t]}stateFlag(e,t){return(this.stateSlot(e,0)&t)>0}validAction(e,t){return!!this.allActions(e,i=>i==t?!0:null)}allActions(e,t){let i=this.stateSlot(e,4),s=i?t(i):void 0;for(let n=this.stateSlot(e,1);s==null;n+=3){if(this.data[n]==65535)if(this.data[n+1]==1)n=fi(this.data,n+2);else break;s=t(fi(this.data,n+1))}return s}nextStates(e){let t=[];for(let i=this.stateSlot(e,1);;i+=3){if(this.data[i]==65535)if(this.data[i+1]==1)i=fi(this.data,i+2);else break;if(!(this.data[i+2]&1)){let s=this.data[i+1];t.some((n,o)=>o&1&&n==s)||t.push(this.data[i],s)}}return t}configure(e){let t=Object.assign(Object.create(r.prototype),this);if(e.props&&(t.nodeSet=this.nodeSet.extend(...e.props)),e.top){let i=this.topRules[e.top];if(!i)throw new RangeError(`Invalid top rule name ${e.top}`);t.top=i}return e.tokenizers&&(t.tokenizers=this.tokenizers.map(i=>{let s=e.tokenizers.find(n=>n.from==i);return s?s.to:i})),e.specializers&&(t.specializers=this.specializers.slice(),t.specializerSpecs=this.specializerSpecs.map((i,s)=>{let n=e.specializers.find(l=>l.from==i.external);if(!n)return i;let o=Object.assign(Object.assign({},i),{external:n.to});return t.specializers[s]=bg(o),o})),e.contextTracker&&(t.context=e.contextTracker),e.dialect&&(t.dialect=this.parseDialect(e.dialect)),e.strict!=null&&(t.strict=e.strict),e.wrap&&(t.wrappers=t.wrappers.concat(e.wrap)),e.bufferLength!=null&&(t.bufferLength=e.bufferLength),t}hasWrappers(){return this.wrappers.length>0}getName(e){return this.termNames?this.termNames[e]:String(e<=this.maxNode&&this.nodeSet.types[e].name||e)}get eofTerm(){return this.maxNode+1}get topNode(){return this.nodeSet.types[this.top[1]]}dynamicPrecedence(e){let t=this.dynamicPrecedences;return t==null?0:t[e]||0}parseDialect(e){let t=Object.keys(this.dialects),i=t.map(()=>!1);if(e)for(let n of e.split(" ")){let o=t.indexOf(n);o>=0&&(i[o]=!0)}let s=null;for(let n=0;n<t.length;n++)if(!i[n])for(let o=this.dialects[t[n]],l;(l=this.data[o++])!=65535;)(s||(s=new Uint8Array(this.maxTerm+1)))[l]=1;return new Ih(e,i,s)}static deserialize(e){return new r(e)}};function fi(r,e){return r[e]|r[e+1]<<16}function tx(r){let e=null;for(let t of r){let i=t.p.stoppedAt;(t.pos==t.p.stream.end||i!=null&&t.pos>i)&&t.p.parser.stateFlag(t.state,2)&&(!e||e.score<t.score)&&(e=t)}return e}function bg(r){if(r.external){let e=r.extend?1:0;return(t,i)=>r.external(t,i)<<1|e}return r.get}var ix=1,Tg=194,Pg=195,sx=196,vg=197,rx=198,nx=199,ox=200,lx=2,Cg=3,wg=201,ax=24,hx=25,fx=49,cx=50,dx=55,ux=56,px=57,mx=59,gx=60,_x=61,yx=62,bx=63,Ox=65,vx=238,wx=71,kx=241,xx=242,Sx=243,Tx=244,Px=245,Cx=246,Ex=247,Ax=248,Eg=72,Rx=249,Mx=250,Dx=251,Nx=252,Ix=253,Lx=254,Qx=255,qx=256,Bx=73,$x=77,Fx=263,Wx=112,zx=130,jx=151,Hx=152,Vx=155,ls=10,Br=13,Bh=32,To=9,$h=35,Ux=40,Gx=46,qh=123,kg=125,Ag=39,Rg=34,xg=92,Xx=111,Jx=120,Yx=78,Kx=117,Zx=85,eS=new Set([hx,fx,cx,Fx,Ox,zx,ux,px,vx,yx,bx,Eg,Bx,$x,gx,_x,jx,Hx,Vx,Wx]);function Lh(r){return r==ls||r==Br}function Qh(r){return r>=48&&r<=57||r>=65&&r<=70||r>=97&&r<=102}var tS=new os((r,e)=>{let t;if(r.next<0)r.acceptToken(nx);else if(e.context.flags&xo)Lh(r.next)&&r.acceptToken(rx,1);else if(((t=r.peek(-1))<0||Lh(t))&&e.canShift(vg)){let i=0;for(;r.next==Bh||r.next==To;)r.advance(),i++;(r.next==ls||r.next==Br||r.next==$h)&&r.acceptToken(vg,-i)}else Lh(r.next)&&r.acceptToken(sx,1)},{contextual:!0}),iS=new os((r,e)=>{let t=e.context;if(t.flags)return;let i=r.peek(-1);if(i==ls||i==Br){let s=0,n=0;for(;;){if(r.next==Bh)s++;else if(r.next==To)s+=8-s%8;else break;r.advance(),n++}s!=t.indent&&r.next!=ls&&r.next!=Br&&r.next!=$h&&(s<t.indent?r.acceptToken(Pg,-n):r.acceptToken(Tg))}}),xo=1,Mg=2,ci=4,di=8,ui=16,pi=32;function So(r,e,t){this.parent=r,this.indent=e,this.flags=t,this.hash=(r?r.hash+r.hash<<8:0)+e+(e<<4)+t+(t<<6)}var sS=new So(null,0,0);function rS(r){let e=0;for(let t=0;t<r.length;t++)e+=r.charCodeAt(t)==To?8-e%8:1;return e}var Sg=new Map([[kx,0],[xx,ci],[Sx,di],[Tx,di|ci],[Px,ui],[Cx,ui|ci],[Ex,ui|di],[Ax,ui|di|ci],[Rx,pi],[Mx,pi|ci],[Dx,pi|di],[Nx,pi|di|ci],[Ix,pi|ui],[Lx,pi|ui|ci],[Qx,pi|ui|di],[qx,pi|ui|di|ci]].map(([r,e])=>[r,e|Mg])),nS=new wo({start:sS,reduce(r,e,t,i){return r.flags&xo&&eS.has(e)||(e==wx||e==Eg)&&r.flags&Mg?r.parent:r},shift(r,e,t,i){return e==Tg?new So(r,rS(i.read(i.pos,t.pos)),0):e==Pg?r.parent:e==ax||e==dx||e==mx||e==Cg?new So(r,0,xo):Sg.has(e)?new So(r,0,Sg.get(e)|r.flags&xo):r},hash(r){return r.hash}}),oS=new os(r=>{for(let e=0;e<5;e++){if(r.next!="print".charCodeAt(e))return;r.advance()}if(!/\w/.test(String.fromCharCode(r.next)))for(let e=0;;e++){let t=r.peek(e);if(!(t==Bh||t==To)){t!=Ux&&t!=Gx&&t!=ls&&t!=Br&&t!=$h&&r.acceptToken(ix);return}}}),lS=new os((r,e)=>{let{flags:t}=e.context,i=t&ci?Rg:Ag,s=(t&di)>0,n=!(t&ui),o=(t&pi)>0,l=r.pos;for(;!(r.next<0);)if(o&&r.next==qh)if(r.peek(1)==qh)r.advance(2);else{if(r.pos==l){r.acceptToken(Cg,1);return}break}else if(n&&r.next==xg){if(r.pos==l){r.advance();let a=r.next;a>=0&&(r.advance(),aS(r,a)),r.acceptToken(lx);return}break}else if(r.next==xg&&!n&&r.peek(1)>-1)r.advance(2);else if(r.next==i&&(!s||r.peek(1)==i&&r.peek(2)==i)){if(r.pos==l){r.acceptToken(wg,s?3:1);return}break}else if(r.next==ls){if(s)r.advance();else if(r.pos==l){r.acceptToken(wg);return}break}else r.advance();r.pos>l&&r.acceptToken(ox)});function aS(r,e){if(e==Xx)for(let t=0;t<2&&r.next>=48&&r.next<=55;t++)r.advance();else if(e==Jx)for(let t=0;t<2&&Qh(r.next);t++)r.advance();else if(e==Kx)for(let t=0;t<4&&Qh(r.next);t++)r.advance();else if(e==Zx)for(let t=0;t<8&&Qh(r.next);t++)r.advance();else if(e==Yx&&r.next==qh){for(r.advance();r.next>=0&&r.next!=kg&&r.next!=Ag&&r.next!=Rg&&r.next!=ls;)r.advance();r.next==kg&&r.advance()}}var hS=no({'async "*" "**" FormatConversion FormatSpec':E.modifier,"for while if elif else try except finally return raise break continue with pass assert await yield match case":E.controlKeyword,"in not and or is del":E.operatorKeyword,"from def class global nonlocal lambda":E.definitionKeyword,import:E.moduleKeyword,"with as print":E.keyword,Boolean:E.bool,None:E.null,VariableName:E.variableName,"CallExpression/VariableName":E.function(E.variableName),"FunctionDefinition/VariableName":E.function(E.definition(E.variableName)),"ClassDefinition/VariableName":E.definition(E.className),PropertyName:E.propertyName,"CallExpression/MemberExpression/PropertyName":E.function(E.propertyName),Comment:E.lineComment,Number:E.number,String:E.string,FormatString:E.special(E.string),Escape:E.escape,UpdateOp:E.updateOperator,"ArithOp!":E.arithmeticOperator,BitOp:E.bitwiseOperator,CompareOp:E.compareOperator,AssignOp:E.definitionOperator,Ellipsis:E.punctuation,At:E.meta,"( )":E.paren,"[ ]":E.squareBracket,"{ }":E.brace,".":E.derefOperator,", ;":E.separator}),fS={__proto__:null,await:44,or:54,and:56,in:60,not:62,is:64,if:70,else:72,lambda:76,yield:94,from:96,async:102,for:104,None:162,True:164,False:164,del:178,pass:182,break:186,continue:190,return:194,raise:202,import:206,as:208,global:212,nonlocal:214,assert:218,type:223,elif:236,while:240,try:246,except:248,finally:250,with:254,def:258,class:268,match:279,case:285},Dg=ko.deserialize({version:14,states:"##jQ`QeOOP$}OSOOO&WQtO'#HUOOQS'#Co'#CoOOQS'#Cp'#CpO'vQdO'#CnO*UQtO'#HTOOQS'#HU'#HUOOQS'#DU'#DUOOQS'#HT'#HTO*rQdO'#D_O+VQdO'#DfO+gQdO'#DjO+zOWO'#DuO,VOWO'#DvO.[QtO'#GuOOQS'#Gu'#GuO'vQdO'#GtO0ZQtO'#GtOOQS'#Eb'#EbO0rQdO'#EcOOQS'#Gs'#GsO0|QdO'#GrOOQV'#Gr'#GrO1XQdO'#FYOOQS'#G^'#G^O1^QdO'#FXOOQV'#IS'#ISOOQV'#Gq'#GqOOQV'#Fq'#FqQ`QeOOO'vQdO'#CqO1lQdO'#C}O1sQdO'#DRO2RQdO'#HYO2cQtO'#EVO'vQdO'#EWOOQS'#EY'#EYOOQS'#E['#E[OOQS'#E^'#E^O2wQdO'#E`O3_QdO'#EdO3rQdO'#EfO3zQtO'#EfO1XQdO'#EiO0rQdO'#ElO1XQdO'#EnO0rQdO'#EtO0rQdO'#EwO4VQdO'#EyO4^QdO'#FOO4iQdO'#EzO0rQdO'#FOO1XQdO'#FQO1XQdO'#FVO4nQdO'#F[P4uOdO'#GpPOOO)CBd)CBdOOQS'#Ce'#CeOOQS'#Cf'#CfOOQS'#Cg'#CgOOQS'#Ch'#ChOOQS'#Ci'#CiOOQS'#Cj'#CjOOQS'#Cl'#ClO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO5TQdO'#DoOOQS,5:Y,5:YO5hQdO'#HdOOQS,5:],5:]O5uQ!fO,5:]O5zQtO,59YO1lQdO,59bO1lQdO,59bO1lQdO,59bO8jQdO,59bO8oQdO,59bO8vQdO,59jO8}QdO'#HTO:TQdO'#HSOOQS'#HS'#HSOOQS'#D['#D[O:lQdO,59aO'vQdO,59aO:zQdO,59aOOQS,59y,59yO;PQdO,5:RO'vQdO,5:ROOQS,5:Q,5:QO;_QdO,5:QO;dQdO,5:XO'vQdO,5:XO'vQdO,5:VOOQS,5:U,5:UO;uQdO,5:UO;zQdO,5:WOOOW'#Fy'#FyO<POWO,5:aOOQS,5:a,5:aO<[QdO'#HwOOOW'#Dw'#DwOOOW'#Fz'#FzO<lOWO,5:bOOQS,5:b,5:bOOQS'#F}'#F}O<zQtO,5:iO?lQtO,5=`O@VQ#xO,5=`O@vQtO,5=`OOQS,5:},5:}OA_QeO'#GWOBqQdO,5;^OOQV,5=^,5=^OB|QtO'#IPOCkQdO,5;tOOQS-E:[-E:[OOQV,5;s,5;sO4dQdO'#FQOOQV-E9o-E9oOCsQtO,59]OEzQtO,59iOFeQdO'#HVOFpQdO'#HVO1XQdO'#HVOF{QdO'#DTOGTQdO,59mOGYQdO'#HZO'vQdO'#HZO0rQdO,5=tOOQS,5=t,5=tO0rQdO'#EROOQS'#ES'#ESOGwQdO'#GPOHXQdO,58|OHXQdO,58|O*xQdO,5:oOHgQtO'#H]OOQS,5:r,5:rOOQS,5:z,5:zOHzQdO,5;OOI]QdO'#IOO1XQdO'#H}OOQS,5;Q,5;QOOQS'#GT'#GTOIqQtO,5;QOJPQdO,5;QOJUQdO'#IQOOQS,5;T,5;TOJdQdO'#H|OOQS,5;W,5;WOJuQdO,5;YO4iQdO,5;`O4iQdO,5;cOJ}QtO'#ITO'vQdO'#ITOKXQdO,5;eO4VQdO,5;eO0rQdO,5;jO1XQdO,5;lOK^QeO'#EuOLjQgO,5;fO!!kQdO'#IUO4iQdO,5;jO!!vQdO,5;lO!#OQdO,5;qO!#ZQtO,5;vO'vQdO,5;vPOOO,5=[,5=[P!#bOSO,5=[P!#jOdO,5=[O!&bQtO1G.jO!&iQtO1G.jO!)YQtO1G.jO!)dQtO1G.jO!+}QtO1G.jO!,bQtO1G.jO!,uQdO'#HcO!-TQtO'#GuO0rQdO'#HcO!-_QdO'#HbOOQS,5:Z,5:ZO!-gQdO,5:ZO!-lQdO'#HeO!-wQdO'#HeO!.[QdO,5>OOOQS'#Ds'#DsOOQS1G/w1G/wOOQS1G.|1G.|O!/[QtO1G.|O!/cQtO1G.|O1lQdO1G.|O!0OQdO1G/UOOQS'#DZ'#DZO0rQdO,59tOOQS1G.{1G.{O!0VQdO1G/eO!0gQdO1G/eO!0oQdO1G/fO'vQdO'#H[O!0tQdO'#H[O!0yQtO1G.{O!1ZQdO,59iO!2aQdO,5=zO!2qQdO,5=zO!2yQdO1G/mO!3OQtO1G/mOOQS1G/l1G/lO!3`QdO,5=uO!4VQdO,5=uO0rQdO1G/qO!4tQdO1G/sO!4yQtO1G/sO!5ZQtO1G/qOOQS1G/p1G/pOOQS1G/r1G/rOOOW-E9w-E9wOOQS1G/{1G/{O!5kQdO'#HxO0rQdO'#HxO!5|QdO,5>cOOOW-E9x-E9xOOQS1G/|1G/|OOQS-E9{-E9{O!6[Q#xO1G2zO!6{QtO1G2zO'vQdO,5<jOOQS,5<j,5<jOOQS-E9|-E9|OOQS,5<r,5<rOOQS-E:U-E:UOOQV1G0x1G0xO1XQdO'#GRO!7dQtO,5>kOOQS1G1`1G1`O!8RQdO1G1`OOQS'#DV'#DVO0rQdO,5=qOOQS,5=q,5=qO!8WQdO'#FrO!8cQdO,59oO!8kQdO1G/XO!8uQtO,5=uOOQS1G3`1G3`OOQS,5:m,5:mO!9fQdO'#GtOOQS,5<k,5<kOOQS-E9}-E9}O!9wQdO1G.hOOQS1G0Z1G0ZO!:VQdO,5=wO!:gQdO,5=wO0rQdO1G0jO0rQdO1G0jO!:xQdO,5>jO!;ZQdO,5>jO1XQdO,5>jO!;lQdO,5>iOOQS-E:R-E:RO!;qQdO1G0lO!;|QdO1G0lO!<RQdO,5>lO!<aQdO,5>lO!<oQdO,5>hO!=VQdO,5>hO!=hQdO'#EpO0rQdO1G0tO!=sQdO1G0tO!=xQgO1G0zO!AvQgO1G0}O!EqQdO,5>oO!E{QdO,5>oO!FTQtO,5>oO0rQdO1G1PO!F_QdO1G1PO4iQdO1G1UO!!vQdO1G1WOOQV,5;a,5;aO!FdQfO,5;aO!FiQgO1G1QO!JjQdO'#GZO4iQdO1G1QO4iQdO1G1QO!JzQdO,5>pO!KXQdO,5>pO1XQdO,5>pOOQV1G1U1G1UO!KaQdO'#FSO!KrQ!fO1G1WO!KzQdO1G1WOOQV1G1]1G1]O4iQdO1G1]O!LPQdO1G1]O!LXQdO'#F^OOQV1G1b1G1bO!#ZQtO1G1bPOOO1G2v1G2vP!L^OSO1G2vOOQS,5=},5=}OOQS'#Dp'#DpO0rQdO,5=}O!LfQdO,5=|O!LyQdO,5=|OOQS1G/u1G/uO!MRQdO,5>PO!McQdO,5>PO!MkQdO,5>PO!NOQdO,5>PO!N`QdO,5>POOQS1G3j1G3jOOQS7+$h7+$hO!8kQdO7+$pO#!RQdO1G.|O#!YQdO1G.|OOQS1G/`1G/`OOQS,5<`,5<`O'vQdO,5<`OOQS7+%P7+%PO#!aQdO7+%POOQS-E9r-E9rOOQS7+%Q7+%QO#!qQdO,5=vO'vQdO,5=vOOQS7+$g7+$gO#!vQdO7+%PO##OQdO7+%QO##TQdO1G3fOOQS7+%X7+%XO##eQdO1G3fO##mQdO7+%XOOQS,5<_,5<_O'vQdO,5<_O##rQdO1G3aOOQS-E9q-E9qO#$iQdO7+%]OOQS7+%_7+%_O#$wQdO1G3aO#%fQdO7+%_O#%kQdO1G3gO#%{QdO1G3gO#&TQdO7+%]O#&YQdO,5>dO#&sQdO,5>dO#&sQdO,5>dOOQS'#Dx'#DxO#'UO&jO'#DzO#'aO`O'#HyOOOW1G3}1G3}O#'fQdO1G3}O#'nQdO1G3}O#'yQ#xO7+(fO#(jQtO1G2UP#)TQdO'#GOOOQS,5<m,5<mOOQS-E:P-E:POOQS7+&z7+&zOOQS1G3]1G3]OOQS,5<^,5<^OOQS-E9p-E9pOOQS7+$s7+$sO#)bQdO,5=`O#){QdO,5=`O#*^QtO,5<aO#*qQdO1G3cOOQS-E9s-E9sOOQS7+&U7+&UO#+RQdO7+&UO#+aQdO,5<nO#+uQdO1G4UOOQS-E:Q-E:QO#,WQdO1G4UOOQS1G4T1G4TOOQS7+&W7+&WO#,iQdO7+&WOOQS,5<p,5<pO#,tQdO1G4WOOQS-E:S-E:SOOQS,5<l,5<lO#-SQdO1G4SOOQS-E:O-E:OO1XQdO'#EqO#-jQdO'#EqO#-uQdO'#IRO#-}QdO,5;[OOQS7+&`7+&`O0rQdO7+&`O#.SQgO7+&fO!JmQdO'#GXO4iQdO7+&fO4iQdO7+&iO#2QQtO,5<tO'vQdO,5<tO#2[QdO1G4ZOOQS-E:W-E:WO#2fQdO1G4ZO4iQdO7+&kO0rQdO7+&kOOQV7+&p7+&pO!KrQ!fO7+&rO!KzQdO7+&rO`QeO1G0{OOQV-E:X-E:XO4iQdO7+&lO4iQdO7+&lOOQV,5<u,5<uO#2nQdO,5<uO!JmQdO,5<uOOQV7+&l7+&lO#2yQgO7+&lO#6tQdO,5<vO#7PQdO1G4[OOQS-E:Y-E:YO#7^QdO1G4[O#7fQdO'#IWO#7tQdO'#IWO1XQdO'#IWOOQS'#IW'#IWO#8PQdO'#IVOOQS,5;n,5;nO#8XQdO,5;nO0rQdO'#FUOOQV7+&r7+&rO4iQdO7+&rOOQV7+&w7+&wO4iQdO7+&wO#8^QfO,5;xOOQV7+&|7+&|POOO7+(b7+(bO#8cQdO1G3iOOQS,5<c,5<cO#8qQdO1G3hOOQS-E9u-E9uO#9UQdO,5<dO#9aQdO,5<dO#9tQdO1G3kOOQS-E9v-E9vO#:UQdO1G3kO#:^QdO1G3kO#:nQdO1G3kO#:UQdO1G3kOOQS<<H[<<H[O#:yQtO1G1zOOQS<<Hk<<HkP#;WQdO'#FtO8vQdO1G3bO#;eQdO1G3bO#;jQdO<<HkOOQS<<Hl<<HlO#;zQdO7+)QOOQS<<Hs<<HsO#<[QtO1G1yP#<{QdO'#FsO#=YQdO7+)RO#=jQdO7+)RO#=rQdO<<HwO#=wQdO7+({OOQS<<Hy<<HyO#>nQdO,5<bO'vQdO,5<bOOQS-E9t-E9tOOQS<<Hw<<HwOOQS,5<g,5<gO0rQdO,5<gO#>sQdO1G4OOOQS-E9y-E9yO#?^QdO1G4OO<[QdO'#H{OOOO'#D{'#D{OOOO'#F|'#F|O#?oO&jO,5:fOOOW,5>e,5>eOOOW7+)i7+)iO#?zQdO7+)iO#@SQdO1G2zO#@mQdO1G2zP'vQdO'#FuO0rQdO<<IpO1XQdO1G2YP1XQdO'#GSO#AOQdO7+)pO#AaQdO7+)pOOQS<<Ir<<IrP1XQdO'#GUP0rQdO'#GQOOQS,5;],5;]O#ArQdO,5>mO#BQQdO,5>mOOQS1G0v1G0vOOQS<<Iz<<IzOOQV-E:V-E:VO4iQdO<<JQOOQV,5<s,5<sO4iQdO,5<sOOQV<<JQ<<JQOOQV<<JT<<JTO#BYQtO1G2`P#BdQdO'#GYO#BkQdO7+)uO#BuQgO<<JVO4iQdO<<JVOOQV<<J^<<J^O4iQdO<<J^O!KrQ!fO<<J^O#FpQgO7+&gOOQV<<JW<<JWO#FzQgO<<JWOOQV1G2a1G2aO1XQdO1G2aO#JuQdO1G2aO4iQdO<<JWO1XQdO1G2bP0rQdO'#G[O#KQQdO7+)vO#K_QdO7+)vOOQS'#FT'#FTO0rQdO,5>rO#KgQdO,5>rO#KrQdO,5>rO#K}QdO,5>qO#L`QdO,5>qOOQS1G1Y1G1YOOQS,5;p,5;pOOQV<<Jc<<JcO#LhQdO1G1dOOQS7+)T7+)TP#LmQdO'#FwO#L}QdO1G2OO#MbQdO1G2OO#MrQdO1G2OP#M}QdO'#FxO#N[QdO7+)VO#NlQdO7+)VO#NlQdO7+)VO#NtQdO7+)VO$ UQdO7+(|O8vQdO7+(|OOQSAN>VAN>VO$ oQdO<<LmOOQSAN>cAN>cO0rQdO1G1|O$!PQtO1G1|P$!ZQdO'#FvOOQS1G2R1G2RP$!hQdO'#F{O$!uQdO7+)jO$#`QdO,5>gOOOO-E9z-E9zOOOW<<MT<<MTO$#nQdO7+(fOOQSAN?[AN?[OOQS7+'t7+'tO$$XQdO<<M[OOQS,5<q,5<qO$$jQdO1G4XOOQS-E:T-E:TOOQVAN?lAN?lOOQV1G2_1G2_O4iQdOAN?qO$$xQgOAN?qOOQVAN?xAN?xO4iQdOAN?xOOQV<<JR<<JRO4iQdOAN?rO4iQdO7+'{OOQV7+'{7+'{O1XQdO7+'{OOQVAN?rAN?rOOQS7+'|7+'|O$(sQdO<<MbOOQS1G4^1G4^O0rQdO1G4^OOQS,5<w,5<wO$)QQdO1G4]OOQS-E:Z-E:ZOOQU'#G_'#G_O$)cQfO7+'OO$)nQdO'#F_O$*uQdO7+'jO$+VQdO7+'jOOQS7+'j7+'jO$+bQdO<<LqO$+rQdO<<LqO$+rQdO<<LqO$+zQdO'#H^OOQS<<Lh<<LhO$,UQdO<<LhOOQS7+'h7+'hOOQS'#D|'#D|OOOO1G4R1G4RO$,oQdO1G4RO$,wQdO1G4RP!=hQdO'#GVOOQVG25]G25]O4iQdOG25]OOQVG25dG25dOOQVG25^G25^OOQV<<Kg<<KgO4iQdO<<KgOOQS7+)x7+)xP$-SQdO'#G]OOQU-E:]-E:]OOQV<<Jj<<JjO$-vQtO'#FaOOQS'#Fc'#FcO$.WQdO'#FbO$.xQdO'#FbOOQS'#Fb'#FbO$.}QdO'#IYO$)nQdO'#FiO$)nQdO'#FiO$/fQdO'#FjO$)nQdO'#FkO$/mQdO'#IZOOQS'#IZ'#IZO$0[QdO,5;yOOQS<<KU<<KUO$0dQdO<<KUO$0tQdOANB]O$1UQdOANB]O$1^QdO'#H_OOQS'#H_'#H_O1sQdO'#DcO$1wQdO,5=xOOQSANBSANBSOOOO7+)m7+)mO$2`QdO7+)mOOQVLD*wLD*wOOQVANARANARO5uQ!fO'#GaO$2hQtO,5<SO$)nQdO'#FmOOQS,5<W,5<WOOQS'#Fd'#FdO$3YQdO,5;|O$3_QdO,5;|OOQS'#Fg'#FgO$)nQdO'#G`O$4PQdO,5<QO$4kQdO,5>tO$4{QdO,5>tO1XQdO,5<PO$5^QdO,5<TO$5cQdO,5<TO$)nQdO'#I[O$5hQdO'#I[O$5mQdO,5<UOOQS,5<V,5<VO0rQdO'#FpOOQU1G1e1G1eO4iQdO1G1eOOQSAN@pAN@pO$5rQdOG27wO$6SQdO,59}OOQS1G3d1G3dOOOO<<MX<<MXOOQS,5<{,5<{OOQS-E:_-E:_O$6XQtO'#FaO$6`QdO'#I]O$6nQdO'#I]O$6vQdO,5<XOOQS1G1h1G1hO$6{QdO1G1hO$7QQdO,5<zOOQS-E:^-E:^O$7lQdO,5=OO$8TQdO1G4`OOQS-E:b-E:bOOQS1G1k1G1kOOQS1G1o1G1oO$8eQdO,5>vO$)nQdO,5>vOOQS1G1p1G1pOOQS,5<[,5<[OOQU7+'P7+'PO$+zQdO1G/iO$)nQdO,5<YO$8sQdO,5>wO$8zQdO,5>wOOQS1G1s1G1sOOQS7+'S7+'SP$)nQdO'#GdO$9SQdO1G4bO$9^QdO1G4bO$9fQdO1G4bOOQS7+%T7+%TO$9tQdO1G1tO$:SQtO'#FaO$:ZQdO,5<}OOQS,5<},5<}O$:iQdO1G4cOOQS-E:a-E:aO$)nQdO,5<|O$:pQdO,5<|O$:uQdO7+)|OOQS-E:`-E:`O$;PQdO7+)|O$)nQdO,5<ZP$)nQdO'#GcO$;XQdO1G2hO$)nQdO1G2hP$;gQdO'#GbO$;nQdO<<MhO$;xQdO1G1uO$<WQdO7+(SO8vQdO'#C}O8vQdO,59bO8vQdO,59bO8vQdO,59bO$<fQtO,5=`O8vQdO1G.|O0rQdO1G/XO0rQdO7+$pP$<yQdO'#GOO'vQdO'#GtO$=WQdO,59bO$=]QdO,59bO$=dQdO,59mO$=iQdO1G/UO1sQdO'#DRO8vQdO,59j",stateData:"$>S~O%cOS%^OSSOS%]PQ~OPdOVaOfoOhYOopOs!POvqO!PrO!Q{O!T!SO!U!RO!XZO!][O!h`O!r`O!s`O!t`O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO#l!QO#o!TO#s!UO#u!VO#z!WO#}hO$P!XO%oRO%pRO%tSO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O~O%]!YO~OV!aO_!aOa!bOh!iO!X!kO!f!mO%j![O%k!]O%l!^O%m!_O%n!_O%o!`O%p!`O%q!aO%r!aO%s!aO~Ok%xXl%xXm%xXn%xXo%xXp%xXs%xXz%xX{%xX!x%xX#g%xX%[%xX%_%xX%z%xXg%xX!T%xX!U%xX%{%xX!W%xX![%xX!Q%xX#[%xXt%xX!m%xX~P%SOfoOhYO!XZO!][O!h`O!r`O!s`O!t`O%oRO%pRO%tSO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O~Oz%wX{%wX#g%wX%[%wX%_%wX%z%wX~Ok!pOl!qOm!oOn!oOo!rOp!sOs!tO!x%wX~P)pOV!zOg!|Oo0cOv0qO!PrO~P'vOV#OOo0cOv0qO!W#PO~P'vOV#SOa#TOo0cOv0qO![#UO~P'vOQ#XO%`#XO%a#ZO~OQ#^OR#[O%`#^O%a#`O~OV%iX_%iXa%iXh%iXk%iXl%iXm%iXn%iXo%iXp%iXs%iXz%iX!X%iX!f%iX%j%iX%k%iX%l%iX%m%iX%n%iX%o%iX%p%iX%q%iX%r%iX%s%iXg%iX!T%iX!U%iX~O&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O{%iX!x%iX#g%iX%[%iX%_%iX%z%iX%{%iX!W%iX![%iX!Q%iX#[%iXt%iX!m%iX~P,eOz#dO{%hX!x%hX#g%hX%[%hX%_%hX%z%hX~Oo0cOv0qO~P'vO#g#gO%[#iO%_#iO~O%uWO~O!T#nO#u!VO#z!WO#}hO~OopO~P'vOV#sOa#tO%uWO{wP~OV#xOo0cOv0qO!Q#yO~P'vO{#{O!x$QO%z#|O#g!yX%[!yX%_!yX~OV#xOo0cOv0qO#g#SX%[#SX%_#SX~P'vOo0cOv0qO#g#WX%[#WX%_#WX~P'vOh$WO%uWO~O!f$YO!r$YO%uWO~OV$eO~P'vO!U$gO#s$hO#u$iO~O{$jO~OV$qO~P'vOS$sO%[$rO%_$rO%c$tO~OV$}Oa$}Og%POo0cOv0qO~P'vOo0cOv0qO{%SO~P'vO&Y%UO~Oa!bOh!iO!X!kO!f!mOVba_bakbalbambanbaobapbasbazba{ba!xba#gba%[ba%_ba%jba%kba%lba%mba%nba%oba%pba%qba%rba%sba%zbagba!Tba!Uba%{ba!Wba![ba!Qba#[batba!mba~On%ZO~Oo%ZO~P'vOo0cO~P'vOk0eOl0fOm0dOn0dOo0mOp0nOs0rOg%wX!T%wX!U%wX%{%wX!W%wX![%wX!Q%wX#[%wX!m%wX~P)pO%{%]Og%vXz%vX!T%vX!U%vX!W%vX{%vX~Og%_Oz%`O!T%dO!U%cO~Og%_O~Oz%gO!T%dO!U%cO!W&SX~O!W%kO~Oz%lO{%nO!T%dO!U%cO![%}X~O![%rO~O![%sO~OQ#XO%`#XO%a%uO~OV%wOo0cOv0qO!PrO~P'vOQ#^OR#[O%`#^O%a%zO~OV!qa_!qaa!qah!qak!qal!qam!qan!qao!qap!qas!qaz!qa{!qa!X!qa!f!qa!x!qa#g!qa%[!qa%_!qa%j!qa%k!qa%l!qa%m!qa%n!qa%o!qa%p!qa%q!qa%r!qa%s!qa%z!qag!qa!T!qa!U!qa%{!qa!W!qa![!qa!Q!qa#[!qat!qa!m!qa~P#yOz%|O{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~P%SOV&OOopOvqO{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~P'vOz%|O{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~OPdOVaOopOvqO!PrO!Q{O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO#g$zX%[$zX%_$zX~P'vO#g#gO%[&TO%_&TO~O!f&UOh&sX%[&sXz&sX#[&sX#g&sX%_&sX#Z&sXg&sX~Oh!iO%[&WO~Okealeameaneaoeapeaseazea{ea!xea#gea%[ea%_ea%zeagea!Tea!Uea%{ea!Wea![ea!Qea#[eatea!mea~P%SOsqazqa{qa#gqa%[qa%_qa%zqa~Ok!pOl!qOm!oOn!oOo!rOp!sO!xqa~PEcO%z&YOz%yX{%yX~O%uWOz%yX{%yX~Oz&]O{wX~O{&_O~Oz%lO#g%}X%[%}X%_%}Xg%}X{%}X![%}X!m%}X%z%}X~OV0lOo0cOv0qO!PrO~P'vO%z#|O#gUa%[Ua%_Ua~Oz&hO#g&PX%[&PX%_&PXn&PX~P%SOz&kO!Q&jO#g#Wa%[#Wa%_#Wa~Oz&lO#[&nO#g&rX%[&rX%_&rXg&rX~O!f$YO!r$YO#Z&qO%uWO~O#Z&qO~Oz&sO#g&tX%[&tX%_&tX~Oz&uO#g&pX%[&pX%_&pX{&pX~O!X&wO%z&xO~Oz&|On&wX~P%SOn'PO~OPdOVaOopOvqO!PrO!Q{O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO%['UO~P'vOt'YO#p'WO#q'XOP#naV#naf#nah#nao#nas#nav#na!P#na!Q#na!T#na!U#na!X#na!]#na!h#na!r#na!s#na!t#na!{#na!}#na#P#na#R#na#T#na#X#na#Z#na#^#na#_#na#a#na#c#na#l#na#o#na#s#na#u#na#z#na#}#na$P#na%X#na%o#na%p#na%t#na%u#na&Z#na&[#na&]#na&^#na&_#na&`#na&a#na&b#na&c#na&d#na&e#na&f#na&g#na&h#na&i#na&j#na%Z#na%_#na~Oz'ZO#[']O{&xX~Oh'_O!X&wO~Oh!iO{$jO!X&wO~O{'eO~P%SO%['hO%_'hO~OS'iO%['hO%_'hO~OV!aO_!aOa!bOh!iO!X!kO!f!mO%l!^O%m!_O%n!_O%o!`O%p!`O%q!aO%r!aO%s!aOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~O%k!]O~P!#uO%kWi~P!#uOV!aO_!aOa!bOh!iO!X!kO!f!mO%o!`O%p!`O%q!aO%r!aO%s!aOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%kWi%lWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~O%m!_O%n!_O~P!&pO%mWi%nWi~P!&pOa!bOh!iO!X!kO!f!mOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%kWi%lWi%mWi%nWi%oWi%pWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~OV!aO_!aO%q!aO%r!aO%s!aO~P!)nOVWi_Wi%qWi%rWi%sWi~P!)nO!T%dO!U%cOg&VXz&VX~O%z'kO%{'kO~P,eOz'mOg&UX~Og'oO~Oz'pO{'rO!W&XX~Oo0cOv0qOz'pO{'sO!W&XX~P'vO!W'uO~Om!oOn!oOo!rOp!sOkjisjizji{ji!xji#gji%[ji%_ji%zji~Ol!qO~P!.aOlji~P!.aOk0eOl0fOm0dOn0dOo0mOp0nO~Ot'wO~P!/jOV'|Og'}Oo0cOv0qO~P'vOg'}Oz(OO~Og(QO~O!U(SO~Og(TOz(OO!T%dO!U%cO~P%SOk0eOl0fOm0dOn0dOo0mOp0nOgqa!Tqa!Uqa%{qa!Wqa![qa!Qqa#[qatqa!mqa~PEcOV'|Oo0cOv0qO!W&Sa~P'vOz(WO!W&Sa~O!W(XO~Oz(WO!T%dO!U%cO!W&Sa~P%SOV(]Oo0cOv0qO![%}a#g%}a%[%}a%_%}ag%}a{%}a!m%}a%z%}a~P'vOz(^O![%}a#g%}a%[%}a%_%}ag%}a{%}a!m%}a%z%}a~O![(aO~Oz(^O!T%dO!U%cO![%}a~P%SOz(dO!T%dO!U%cO![&Ta~P%SOz(gO{&lX![&lX!m&lX%z&lX~O{(kO![(mO!m(nO%z(jO~OV&OOopOvqO{%hi!x%hi#g%hi%[%hi%_%hi%z%hi~P'vOz(pO{%hi!x%hi#g%hi%[%hi%_%hi%z%hi~O!f&UOh&sa%[&saz&sa#[&sa#g&sa%_&sa#Z&sag&sa~O%[(uO~OV#sOa#tO%uWO~Oz&]O{wa~OopOvqO~P'vOz(^O#g%}a%[%}a%_%}ag%}a{%}a![%}a!m%}a%z%}a~P%SOz(zO#g%hX%[%hX%_%hX%z%hX~O%z#|O#gUi%[Ui%_Ui~O#g&Pa%[&Pa%_&Pan&Pa~P'vOz(}O#g&Pa%[&Pa%_&Pan&Pa~O%uWO#g&ra%[&ra%_&rag&ra~Oz)SO#g&ra%[&ra%_&rag&ra~Og)VO~OV)WOh$WO%uWO~O#Z)XO~O%uWO#g&ta%[&ta%_&ta~Oz)ZO#g&ta%[&ta%_&ta~Oo0cOv0qO#g&pa%[&pa%_&pa{&pa~P'vOz)^O#g&pa%[&pa%_&pa{&pa~OV)`Oa)`O%uWO~O%z)eO~Ot)hO#j)gOP#hiV#hif#hih#hio#his#hiv#hi!P#hi!Q#hi!T#hi!U#hi!X#hi!]#hi!h#hi!r#hi!s#hi!t#hi!{#hi!}#hi#P#hi#R#hi#T#hi#X#hi#Z#hi#^#hi#_#hi#a#hi#c#hi#l#hi#o#hi#s#hi#u#hi#z#hi#}#hi$P#hi%X#hi%o#hi%p#hi%t#hi%u#hi&Z#hi&[#hi&]#hi&^#hi&_#hi&`#hi&a#hi&b#hi&c#hi&d#hi&e#hi&f#hi&g#hi&h#hi&i#hi&j#hi%Z#hi%_#hi~Ot)iOP#kiV#kif#kih#kio#kis#kiv#ki!P#ki!Q#ki!T#ki!U#ki!X#ki!]#ki!h#ki!r#ki!s#ki!t#ki!{#ki!}#ki#P#ki#R#ki#T#ki#X#ki#Z#ki#^#ki#_#ki#a#ki#c#ki#l#ki#o#ki#s#ki#u#ki#z#ki#}#ki$P#ki%X#ki%o#ki%p#ki%t#ki%u#ki&Z#ki&[#ki&]#ki&^#ki&_#ki&`#ki&a#ki&b#ki&c#ki&d#ki&e#ki&f#ki&g#ki&h#ki&i#ki&j#ki%Z#ki%_#ki~OV)kOn&wa~P'vOz)lOn&wa~Oz)lOn&wa~P%SOn)pO~O%Y)tO~Ot)wO#p'WO#q)vOP#niV#nif#nih#nio#nis#niv#ni!P#ni!Q#ni!T#ni!U#ni!X#ni!]#ni!h#ni!r#ni!s#ni!t#ni!{#ni!}#ni#P#ni#R#ni#T#ni#X#ni#Z#ni#^#ni#_#ni#a#ni#c#ni#l#ni#o#ni#s#ni#u#ni#z#ni#}#ni$P#ni%X#ni%o#ni%p#ni%t#ni%u#ni&Z#ni&[#ni&]#ni&^#ni&_#ni&`#ni&a#ni&b#ni&c#ni&d#ni&e#ni&f#ni&g#ni&h#ni&i#ni&j#ni%Z#ni%_#ni~OV)zOo0cOv0qO{$jO~P'vOo0cOv0qO{&xa~P'vOz*OO{&xa~OV*SOa*TOg*WO%q*UO%uWO~O{$jO&{*YO~Oh'_O~Oh!iO{$jO~O%[*_O~O%[*aO%_*aO~OV$}Oa$}Oo0cOv0qOg&Ua~P'vOz*dOg&Ua~Oo0cOv0qO{*gO!W&Xa~P'vOz*hO!W&Xa~Oo0cOv0qOz*hO{*kO!W&Xa~P'vOo0cOv0qOz*hO!W&Xa~P'vOz*hO{*kO!W&Xa~Om0dOn0dOo0mOp0nOgjikjisjizji!Tji!Uji%{ji!Wji{ji![ji#gji%[ji%_ji!Qji#[jitji!mji%zji~Ol0fO~P!NkOlji~P!NkOV'|Og*pOo0cOv0qO~P'vOn*rO~Og*pOz*tO~Og*uO~OV'|Oo0cOv0qO!W&Si~P'vOz*vO!W&Si~O!W*wO~OV(]Oo0cOv0qO![%}i#g%}i%[%}i%_%}ig%}i{%}i!m%}i%z%}i~P'vOz*zO!T%dO!U%cO![&Ti~Oz*}O![%}i#g%}i%[%}i%_%}ig%}i{%}i!m%}i%z%}i~O![+OO~Oa+QOo0cOv0qO![&Ti~P'vOz*zO![&Ti~O![+SO~OV+UOo0cOv0qO{&la![&la!m&la%z&la~P'vOz+VO{&la![&la!m&la%z&la~O!]+YO&n+[O![!nX~O![+^O~O{(kO![+_O~O{(kO![+_O!m+`O~OV&OOopOvqO{%hq!x%hq#g%hq%[%hq%_%hq%z%hq~P'vOz$ri{$ri!x$ri#g$ri%[$ri%_$ri%z$ri~P%SOV&OOopOvqO~P'vOV&OOo0cOv0qO#g%ha%[%ha%_%ha%z%ha~P'vOz+aO#g%ha%[%ha%_%ha%z%ha~Oz$ia#g$ia%[$ia%_$ian$ia~P%SO#g&Pi%[&Pi%_&Pin&Pi~P'vOz+dO#g#Wq%[#Wq%_#Wq~O#[+eOz$va#g$va%[$va%_$vag$va~O%uWO#g&ri%[&ri%_&rig&ri~Oz+gO#g&ri%[&ri%_&rig&ri~OV+iOh$WO%uWO~O%uWO#g&ti%[&ti%_&ti~Oo0cOv0qO#g&pi%[&pi%_&pi{&pi~P'vO{#{Oz#eX!W#eX~Oz+mO!W&uX~O!W+oO~Ot+rO#j)gOP#hqV#hqf#hqh#hqo#hqs#hqv#hq!P#hq!Q#hq!T#hq!U#hq!X#hq!]#hq!h#hq!r#hq!s#hq!t#hq!{#hq!}#hq#P#hq#R#hq#T#hq#X#hq#Z#hq#^#hq#_#hq#a#hq#c#hq#l#hq#o#hq#s#hq#u#hq#z#hq#}#hq$P#hq%X#hq%o#hq%p#hq%t#hq%u#hq&Z#hq&[#hq&]#hq&^#hq&_#hq&`#hq&a#hq&b#hq&c#hq&d#hq&e#hq&f#hq&g#hq&h#hq&i#hq&j#hq%Z#hq%_#hq~On$|az$|a~P%SOV)kOn&wi~P'vOz+yOn&wi~Oz,TO{$jO#[,TO~O#q,VOP#nqV#nqf#nqh#nqo#nqs#nqv#nq!P#nq!Q#nq!T#nq!U#nq!X#nq!]#nq!h#nq!r#nq!s#nq!t#nq!{#nq!}#nq#P#nq#R#nq#T#nq#X#nq#Z#nq#^#nq#_#nq#a#nq#c#nq#l#nq#o#nq#s#nq#u#nq#z#nq#}#nq$P#nq%X#nq%o#nq%p#nq%t#nq%u#nq&Z#nq&[#nq&]#nq&^#nq&_#nq&`#nq&a#nq&b#nq&c#nq&d#nq&e#nq&f#nq&g#nq&h#nq&i#nq&j#nq%Z#nq%_#nq~O#[,WOz%Oa{%Oa~Oo0cOv0qO{&xi~P'vOz,YO{&xi~O{#{O%z,[Og&zXz&zX~O%uWOg&zXz&zX~Oz,`Og&yX~Og,bO~O%Y,eO~O!T%dO!U%cOg&Viz&Vi~OV$}Oa$}Oo0cOv0qOg&Ui~P'vO{,hOz$la!W$la~Oo0cOv0qO{,iOz$la!W$la~P'vOo0cOv0qO{*gO!W&Xi~P'vOz,lO!W&Xi~Oo0cOv0qOz,lO!W&Xi~P'vOz,lO{,oO!W&Xi~Og$hiz$hi!W$hi~P%SOV'|Oo0cOv0qO~P'vOn,qO~OV'|Og,rOo0cOv0qO~P'vOV'|Oo0cOv0qO!W&Sq~P'vOz$gi![$gi#g$gi%[$gi%_$gig$gi{$gi!m$gi%z$gi~P%SOV(]Oo0cOv0qO~P'vOa+QOo0cOv0qO![&Tq~P'vOz,sO![&Tq~O![,tO~OV(]Oo0cOv0qO![%}q#g%}q%[%}q%_%}qg%}q{%}q!m%}q%z%}q~P'vO{,uO~OV+UOo0cOv0qO{&li![&li!m&li%z&li~P'vOz,zO{&li![&li!m&li%z&li~O!]+YO&n+[O![!na~O{(kO![,}O~OV&OOo0cOv0qO#g%hi%[%hi%_%hi%z%hi~P'vOz-OO#g%hi%[%hi%_%hi%z%hi~O%uWO#g&rq%[&rq%_&rqg&rq~Oz-RO#g&rq%[&rq%_&rqg&rq~OV)`Oa)`O%uWO!W&ua~Oz-TO!W&ua~On$|iz$|i~P%SOV)kO~P'vOV)kOn&wq~P'vOt-XOP#myV#myf#myh#myo#mys#myv#my!P#my!Q#my!T#my!U#my!X#my!]#my!h#my!r#my!s#my!t#my!{#my!}#my#P#my#R#my#T#my#X#my#Z#my#^#my#_#my#a#my#c#my#l#my#o#my#s#my#u#my#z#my#}#my$P#my%X#my%o#my%p#my%t#my%u#my&Z#my&[#my&]#my&^#my&_#my&`#my&a#my&b#my&c#my&d#my&e#my&f#my&g#my&h#my&i#my&j#my%Z#my%_#my~O%Z-]O%_-]O~P`O#q-^OP#nyV#nyf#nyh#nyo#nys#nyv#ny!P#ny!Q#ny!T#ny!U#ny!X#ny!]#ny!h#ny!r#ny!s#ny!t#ny!{#ny!}#ny#P#ny#R#ny#T#ny#X#ny#Z#ny#^#ny#_#ny#a#ny#c#ny#l#ny#o#ny#s#ny#u#ny#z#ny#}#ny$P#ny%X#ny%o#ny%p#ny%t#ny%u#ny&Z#ny&[#ny&]#ny&^#ny&_#ny&`#ny&a#ny&b#ny&c#ny&d#ny&e#ny&f#ny&g#ny&h#ny&i#ny&j#ny%Z#ny%_#ny~Oz-aO{$jO#[-aO~Oo0cOv0qO{&xq~P'vOz-dO{&xq~O%z,[Og&zaz&za~O{#{Og&zaz&za~OV*SOa*TO%q*UO%uWOg&ya~Oz-hOg&ya~O$S-lO~OV$}Oa$}Oo0cOv0qO~P'vOo0cOv0qO{-mOz$li!W$li~P'vOo0cOv0qOz$li!W$li~P'vO{-mOz$li!W$li~Oo0cOv0qO{*gO~P'vOo0cOv0qO{*gO!W&Xq~P'vOz-pO!W&Xq~Oo0cOv0qOz-pO!W&Xq~P'vOs-sO!T%dO!U%cOg&Oq!W&Oq![&Oqz&Oq~P!/jOa+QOo0cOv0qO![&Ty~P'vOz$ji![$ji~P%SOa+QOo0cOv0qO~P'vOV+UOo0cOv0qO~P'vOV+UOo0cOv0qO{&lq![&lq!m&lq%z&lq~P'vO{(kO![-xO!m-yO%z-wO~OV&OOo0cOv0qO#g%hq%[%hq%_%hq%z%hq~P'vO%uWO#g&ry%[&ry%_&ryg&ry~OV)`Oa)`O%uWO!W&ui~Ot-}OP#m!RV#m!Rf#m!Rh#m!Ro#m!Rs#m!Rv#m!R!P#m!R!Q#m!R!T#m!R!U#m!R!X#m!R!]#m!R!h#m!R!r#m!R!s#m!R!t#m!R!{#m!R!}#m!R#P#m!R#R#m!R#T#m!R#X#m!R#Z#m!R#^#m!R#_#m!R#a#m!R#c#m!R#l#m!R#o#m!R#s#m!R#u#m!R#z#m!R#}#m!R$P#m!R%X#m!R%o#m!R%p#m!R%t#m!R%u#m!R&Z#m!R&[#m!R&]#m!R&^#m!R&_#m!R&`#m!R&a#m!R&b#m!R&c#m!R&d#m!R&e#m!R&f#m!R&g#m!R&h#m!R&i#m!R&j#m!R%Z#m!R%_#m!R~Oo0cOv0qO{&xy~P'vOV*SOa*TO%q*UO%uWOg&yi~O$S-lO%Z.VO%_.VO~OV.aOh._O!X.^O!].`O!h.YO!s.[O!t.[O%p.XO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O~Oo0cOv0qOz$lq!W$lq~P'vO{.fOz$lq!W$lq~Oo0cOv0qO{*gO!W&Xy~P'vOz.gO!W&Xy~Oo0cOv.kO~P'vOs-sO!T%dO!U%cOg&Oy!W&Oy![&Oyz&Oy~P!/jO{(kO![.nO~O{(kO![.nO!m.oO~OV*SOa*TO%q*UO%uWO~Oh.tO!f.rOz$TX#[$TX%j$TXg$TX~Os$TX{$TX!W$TX![$TX~P$-bO%o.vO%p.vOs$UXz$UX{$UX#[$UX%j$UX!W$UXg$UX![$UX~O!h.xO~Oz.|O#[/OO%j.yOs&|X{&|X!W&|Xg&|X~Oa/RO~P$)zOh.tOs&}Xz&}X{&}X#[&}X%j&}X!W&}Xg&}X![&}X~Os/VO{$jO~Oo0cOv0qOz$ly!W$ly~P'vOo0cOv0qO{*gO!W&X!R~P'vOz/ZO!W&X!R~Og&RXs&RX!T&RX!U&RX!W&RX![&RXz&RX~P!/jOs-sO!T%dO!U%cOg&Qa!W&Qa![&Qaz&Qa~O{(kO![/^O~O!f.rOh$[as$[az$[a{$[a#[$[a%j$[a!W$[ag$[a![$[a~O!h/eO~O%o.vO%p.vOs$Uaz$Ua{$Ua#[$Ua%j$Ua!W$Uag$Ua![$Ua~O%j.yOs$Yaz$Ya{$Ya#[$Ya!W$Yag$Ya![$Ya~Os&|a{&|a!W&|ag&|a~P$)nOz/jOs&|a{&|a!W&|ag&|a~O!W/mO~Og/mO~O{/oO~O![/pO~Oo0cOv0qO{*gO!W&X!Z~P'vO{/sO~O%z/tO~P$-bOz/uO#[/OO%j.yOg'PX~Oz/uOg'PX~Og/wO~O!h/xO~O#[/OOs%Saz%Sa{%Sa%j%Sa!W%Sag%Sa![%Sa~O#[/OO%j.yOs%Waz%Wa{%Wa!W%Wag%Wa~Os&|i{&|i!W&|ig&|i~P$)nOz/zO#[/OO%j.yO!['Oa~Og'Pa~P$)nOz0SOg'Pa~Oa0UO!['Oi~P$)zOz0WO!['Oi~Oz0WO#[/OO%j.yO!['Oi~O#[/OO%j.yOg$biz$bi~O%z0ZO~P$-bO#[/OO%j.yOg%Vaz%Va~Og'Pi~P$)nO{0^O~Oa0UO!['Oq~P$)zOz0`O!['Oq~O#[/OO%j.yOz%Ui![%Ui~Oa0UO~P$)zOa0UO!['Oy~P$)zO#[/OO%j.yOg$ciz$ci~O#[/OO%j.yOz%Uq![%Uq~Oz+aO#g%ha%[%ha%_%ha%z%ha~P%SOV&OOo0cOv0qO~P'vOn0hO~Oo0hO~P'vO{0iO~Ot0jO~P!/jO&]&Z&j&h&i&g&f&d&e&c&b&`&a&_&^&[%u~",goto:"!=j'QPPPPPP'RP'Z*s+[+t,_,y-fP.SP'Z.r.r'ZPPP'Z2[PPPPPP2[5PPP5PP7b7k=sPP=v>h>kPP'Z'ZPP>zPP'Z'ZPP'Z'Z'Z'Z'Z?O?w'ZP?zP@QDXGuGyPG|HWH['ZPPPH_Hk'RP'R'RP'RP'RP'RP'RP'R'R'RP'RPP'RPP'RP'RPHqH}IVPI^IdPI^PI^I^PPPI^PKrPK{LVL]KrPI^LfPI^PLmLsPLwM]MzNeLwLwNkNxLwLwLwLw! ^! d! g! l! o! y!!P!!]!!o!!u!#P!#V!#s!#y!$P!$Z!$a!$g!$y!%T!%Z!%a!%k!%q!%w!%}!&T!&Z!&e!&k!&u!&{!'U!'[!'k!'s!'}!(UPPPPPPPPPPP!([!(_!(e!(n!(x!)TPPPPPPPPPPPP!-u!/Z!3^!6oPP!6w!7W!7a!8Y!8P!8c!8i!8l!8o!8r!8z!9jPPPPPPPPPPPPPPPPP!9m!9q!9wP!:]!:a!:m!:v!;S!;j!;m!;p!;v!;|!<S!<VP!<_!<h!=d!=g]eOn#g$j)t,P'}`OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0r{!cQ#c#p$R$d$p%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g}!dQ#c#p$R$d$p$u%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!P!eQ#c#p$R$d$p$u$v%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!R!fQ#c#p$R$d$p$u$v$w%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!T!gQ#c#p$R$d$p$u$v$w$x%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!V!hQ#c#p$R$d$p$u$v$w$x$y%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g!Z!hQ!n#c#p$R$d$p$u$v$w$x$y$z%e%j%p%q&`'O'g(q(|)j*o*x+w,v0g'}TOTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0r&eVOYZ[dnprxy}!P!Q!U!i!k!o!p!q!s!t#[#d#g#y#{#}$Q$h$j$}%S%Z%^%`%g%l%n%w%|&Z&_&j&k&u&x'P'W'Z'l'm'p'r's'w(O(W(^(d(g(p(r(z)^)e)g)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+U+V+Y+a+d+k,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0n0r%oXOYZ[dnrxy}!P!Q!U!i!k#[#d#g#y#{#}$Q$h$j$}%S%^%`%g%l%n%w%|&Z&_&j&k&u&x'P'W'Z'l'm'p'r's'w(O(W(^(d(g(p(r(z)^)e)g)p)t)z*O*Y*d*g*h*k*q*t*v*y*z*}+U+V+Y+a+d+k,P,X,Y,],g,h,i,k,l,o,s,u,w,y,z-O-d-f-m-p.f.g/V/Z0i0j0kQ#vqQ/[.kR0o0q't`OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0rh#jhz{$W$Z&l&q)S)X+f+g-RW#rq&].k0qQ$]|Q$a!OQ$n!VQ$o!WW$|!i'm*d,gS&[#s#tQ'S$iQ(s&UQ)U&nU)Y&s)Z+jW)a&w+m-T-{Q*Q']W*R'_,`-h.TQ+l)`S,_*S*TQ-Q+eQ-_,TQ-c,WQ.R-al.W-l.^._.a.z.|/R/j/o/t/y0U0Z0^Q/S.`Q/a.tQ/l/OU0P/u0S0[X0V/z0W0_0`R&Z#r!_!wYZ!P!Q!k%S%`%g'p'r's(O(W)g*g*h*k*q*t*v,h,i,k,l,o-m-p.f.g/ZR%^!vQ!{YQ%x#[Q&d#}Q&g$QR,{+YT.j-s/s!Y!jQ!n#c#p$R$d$p$u$v$w$x$y$z%e%j%p%q&`'O'g(q(|)j*o*x+w,v0gQ&X#kQ'c$oR*^'dR'l$|Q%V!mR/_.r'|_OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0rS#a_#b!P.[-l.^._.`.a.t.z.|/R/j/o/t/u/y/z0S0U0W0Z0[0^0_0`'|_OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$e$g$h$j$q$}%S%Z%^%`%c%g%l%n%w%|&O&Z&_&h&j&k&u&x&|'P'W'Z'l'm'p'r's'w'|(O(S(W(](^(d(g(p(r(z(})^)e)g)k)l)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+Q+U+V+Y+a+c+d+k+x+y,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0l0n0rT#a_#bT#^^#_R(o%xa(l%x(n(o+`,{-y-z.oT+[(k+]R-z,{Q$PsQ+l)aQ,^*RR-e,_X#}s$O$P&fQ&y$aQ'a$nQ'd$oR)s'SQ)b&wV-S+m-T-{ZgOn$j)t,PXkOn)t,PQ$k!TQ&z$bQ&{$cQ'^$mQ'b$oQ)q'RQ)x'WQ){'XQ)|'YQ*Z'`S*]'c'dQ+s)gQ+u)hQ+v)iQ+z)oS+|)r*[Q,Q)vQ,R)wS,S)y)zQ,d*^Q-V+rQ-W+tQ-Y+{S-Z+},OQ-`,UQ-b,VQ-|-XQ.O-[Q.P-^Q.Q-_Q.p-}Q.q.RQ/W.dR/r/XWkOn)t,PR#mjQ'`$nS)r'S'aR,O)sQ,]*RR-f,^Q*['`Q+})rR-[,OZiOjn)t,PQ'f$pR*`'gT-j,e-ku.c-l.^._.a.t.z.|/R/j/o/t/u/y0S0U0Z0[0^t.c-l.^._.a.t.z.|/R/j/o/t/u/y0S0U0Z0[0^Q/S.`X0V/z0W0_0`!P.Z-l.^._.`.a.t.z.|/R/j/o/t/u/y/z0S0U0W0Z0[0^0_0`Q.w.YR/f.xg.z.].{/b/i/n/|0O0Q0]0a0bu.b-l.^._.a.t.z.|/R/j/o/t/u/y0S0U0Z0[0^X.u.W.b/a0PR/c.tV0R/u0S0[R/X.dQnOS#on,PR,P)tQ&^#uR(x&^S%m#R#wS(_%m(bT(b%p&`Q%a!yQ%h!}W(P%a%h(U(YQ(U%eR(Y%jQ&i$RR)O&iQ(e%qQ*{(`T+R(e*{Q'n%OR*e'nS'q%R%SY*i'q*j,m-q.hU*j'r's'tU,m*k*l*mS-q,n,oR.h-rQ#Y]R%t#YQ#_^R%y#_Q(h%vS+W(h+XR+X(iQ+](kR,|+]Q#b_R%{#bQ#ebQ%}#cW&Q#e%}({+bQ({&cR+b0gQ$OsS&e$O&fR&f$PQ&v$_R)_&vQ&V#jR(t&VQ&m$VS)T&m+hR+h)UQ$Z{R&p$ZQ&t$]R)[&tQ+n)bR-U+nQ#hfR&S#hQ)f&zR+q)fQ&}$dS)m&})nR)n'OQ'V$kR)u'VQ'[$lS*P'[,ZR,Z*QQ,a*VR-i,aWjOn)t,PR#ljQ-k,eR.U-kd.{.]/b/i/n/|0O0Q0]0a0bR/h.{U.s.W/a0PR/`.sQ/{/nS0X/{0YR0Y/|S/v/b/cR0T/vQ.}.]R/k.}R!ZPXmOn)t,PWlOn)t,PR'T$jYfOn$j)t,PR&R#g[sOn#g$j)t,PR&d#}&dQOYZ[dnprxy}!P!Q!U!i!k!o!p!q!s!t#[#d#g#y#{#}$Q$h$j$}%S%Z%^%`%g%l%n%w%|&Z&_&j&k&u&x'P'W'Z'l'm'p'r's'w(O(W(^(d(g(p(r(z)^)e)g)p)t)z*O*Y*d*g*h*k*q*r*t*v*y*z*}+U+V+Y+a+d+k,P,X,Y,],g,h,i,k,l,o,q,s,u,w,y,z-O-d-f-m-p-s.f.g/V/Z/s0c0d0e0f0h0i0j0k0n0rQ!nTQ#caQ#poU$Rt%c(SS$d!R$gQ$p!XQ$u!cQ$v!dQ$w!eQ$x!fQ$y!gQ$z!hQ%e!zQ%j#OQ%p#SQ%q#TQ&`#xQ'O$eQ'g$qQ(q&OU(|&h(}+cW)j&|)l+x+yQ*o'|Q*x(]Q+w)kQ,v+QR0g0lQ!yYQ!}ZQ$b!PQ$c!QQ%R!kQ't%S^'{%`%g(O(W*q*t*v^*f'p*h,k,l-p.g/ZQ*l'rQ*m'sQ+t)gQ,j*gQ,n*kQ-n,hQ-o,iQ-r,oQ.e-mR/Y.f[bOn#g$j)t,P!^!vYZ!P!Q!k%S%`%g'p'r's(O(W)g*g*h*k*q*t*v,h,i,k,l,o-m-p.f.g/ZQ#R[Q#fdS#wrxQ$UyW$_}$Q'P)pS$l!U$hW${!i'm*d,gS%v#[+Y`&P#d%|(p(r(z+a-O0kQ&a#yQ&b#{Q&c#}Q'j$}Q'z%^W([%l(^*y*}Q(`%nQ(i%wQ(v&ZS(y&_0iQ)P&jQ)Q&kU)]&u)^+kQ)d&xQ)y'WY)}'Z*O,X,Y-dQ*b'lS*n'w0jW+P(d*z,s,wW+T(g+V,y,zQ+p)eQ,U)zQ,c*YQ,x+UQ-P+dQ-e,]Q-v,uQ.S-fR/q/VhUOn#d#g$j%|&_'w(p(r)t,P%U!uYZ[drxy}!P!Q!U!i!k#[#y#{#}$Q$h$}%S%^%`%g%l%n%w&Z&j&k&u&x'P'W'Z'l'm'p'r's(O(W(^(d(g(z)^)e)g)p)z*O*Y*d*g*h*k*q*t*v*y*z*}+U+V+Y+a+d+k,X,Y,],g,h,i,k,l,o,s,u,w,y,z-O-d-f-m-p.f.g/V/Z0i0j0kQ#qpW%W!o!s0d0nQ%X!pQ%Y!qQ%[!tQ%f0cS'v%Z0hQ'x0eQ'y0fQ,p*rQ-u,qS.i-s/sR0p0rU#uq.k0qR(w&][cOn#g$j)t,PZ!xY#[#}$Q+YQ#W[Q#zrR$TxQ%b!yQ%i!}Q%o#RQ'j${Q(V%eQ(Z%jQ(c%pQ(f%qQ*|(`Q,f*bQ-t,pQ.m-uR/].lQ$StQ(R%cR*s(SQ.l-sR/}/sR#QZR#V[R%Q!iQ%O!iV*c'm*d,g!Z!lQ!n#c#p$R$d$p$u$v$w$x$y$z%e%j%p%q&`'O'g(q(|)j*o*x+w,v0gR%T!kT#]^#_Q%x#[R,{+YQ(m%xS+_(n(oQ,}+`Q-x,{S.n-y-zR/^.oT+Z(k+]Q$`}Q&g$QQ)o'PR+{)pQ$XzQ)W&qR+i)XQ$XzQ&o$WQ)W&qR+i)XQ#khW$Vz$W&q)XQ$[{Q&r$ZZ)R&l)S+f+g-RR$^|R)c&wXlOn)t,PQ$f!RR'Q$gQ$m!UR'R$hR*X'_Q*V'_V-g,`-h.TQ.d-lQ/P.^R/Q._U.]-l.^._Q/U.aQ/b.tQ/g.zU/i.|/j/yQ/n/RQ/|/oQ0O/tU0Q/u0S0[Q0]0UQ0a0ZR0b0^R/T.`R/d.t",nodeNames:"\u26A0 print Escape { Comment Script AssignStatement * BinaryExpression BitOp BitOp BitOp BitOp ArithOp ArithOp @ ArithOp ** UnaryExpression ArithOp BitOp AwaitExpression await ) ( ParenthesizedExpression BinaryExpression or and CompareOp in not is UnaryExpression ConditionalExpression if else LambdaExpression lambda ParamList VariableName AssignOp , : NamedExpression AssignOp YieldExpression yield from TupleExpression ComprehensionExpression async for LambdaExpression ] [ ArrayExpression ArrayComprehensionExpression } { DictionaryExpression DictionaryComprehensionExpression SetExpression SetComprehensionExpression CallExpression ArgList AssignOp MemberExpression . PropertyName Number String FormatString FormatReplacement FormatSelfDoc FormatConversion FormatSpec FormatReplacement FormatSelfDoc ContinuedString Ellipsis None Boolean TypeDef AssignOp UpdateStatement UpdateOp ExpressionStatement DeleteStatement del PassStatement pass BreakStatement break ContinueStatement continue ReturnStatement return YieldStatement PrintStatement RaiseStatement raise ImportStatement import as ScopeStatement global nonlocal AssertStatement assert TypeDefinition type TypeParamList TypeParam StatementGroup ; IfStatement Body elif WhileStatement while ForStatement TryStatement try except finally WithStatement with FunctionDefinition def ParamList AssignOp TypeDef ClassDefinition class DecoratedStatement Decorator At MatchStatement match MatchBody MatchClause case CapturePattern LiteralPattern ArithOp ArithOp AsPattern OrPattern LogicOp AttributePattern SequencePattern MappingPattern StarPattern ClassPattern PatternArgList KeywordPattern KeywordPattern Guard",maxTerm:277,context:nS,nodeProps:[["isolate",-5,4,71,72,73,77,""],["group",-15,6,85,87,88,90,92,94,96,98,99,100,102,105,108,110,"Statement Statement",-22,8,18,21,25,40,49,50,56,57,60,61,62,63,64,67,70,71,72,79,80,81,82,"Expression",-10,114,116,119,121,122,126,128,133,135,138,"Statement",-9,143,144,147,148,150,151,152,153,154,"Pattern"],["openedBy",23,"(",54,"[",58,"{"],["closedBy",24,")",55,"]",59,"}"]],propSources:[hS],skippedNodes:[0,4],repeatNodeCount:34,tokenData:"!2|~R!`OX%TXY%oY[%T[]%o]p%Tpq%oqr'ars)Yst*xtu%Tuv,dvw-hwx.Uxy/tyz0[z{0r{|2S|}2p}!O3W!O!P4_!P!Q:Z!Q!R;k!R![>_![!]Do!]!^Es!^!_FZ!_!`Gk!`!aHX!a!b%T!b!cIf!c!dJU!d!eK^!e!hJU!h!i!#f!i!tJU!t!u!,|!u!wJU!w!x!.t!x!}JU!}#O!0S#O#P&o#P#Q!0j#Q#R!1Q#R#SJU#S#T%T#T#UJU#U#VK^#V#YJU#Y#Z!#f#Z#fJU#f#g!,|#g#iJU#i#j!.t#j#oJU#o#p!1n#p#q!1s#q#r!2a#r#s!2f#s$g%T$g;'SJU;'S;=`KW<%lOJU`%YT&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T`%lP;=`<%l%To%v]&n`%c_OX%TXY%oY[%T[]%o]p%Tpq%oq#O%T#O#P&o#P#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To&tX&n`OY%TYZ%oZ]%T]^%o^#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc'f[&n`O!_%T!_!`([!`#T%T#T#U(r#U#f%T#f#g(r#g#h(r#h#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc(cTmR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc(yT!mR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk)aV&n`&[ZOr%Trs)vs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk){V&n`Or%Trs*bs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk*iT&n`&^ZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To+PZS_&n`OY*xYZ%TZ]*x]^%T^#o*x#o#p+r#p#q*x#q#r+r#r;'S*x;'S;=`,^<%lO*x_+wTS_OY+rZ]+r^;'S+r;'S;=`,W<%lO+r_,ZP;=`<%l+ro,aP;=`<%l*xj,kV%rQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj-XT!xY&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj-oV%lQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk.]V&n`&ZZOw%Twx.rx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk.wV&n`Ow%Twx/^x#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk/eT&n`&]ZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk/{ThZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc0cTgR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk0yXVZ&n`Oz%Tz{1f{!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk1mVaR&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk2ZV%oZ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc2wTzR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To3_W%pZ&n`O!_%T!_!`-Q!`!a3w!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Td4OT&{S&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk4fX!fQ&n`O!O%T!O!P5R!P!Q%T!Q![6T![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk5WV&n`O!O%T!O!P5m!P#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk5tT!rZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti6[a!hX&n`O!Q%T!Q![6T![!g%T!g!h7a!h!l%T!l!m9s!m#R%T#R#S6T#S#X%T#X#Y7a#Y#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti7fZ&n`O{%T{|8X|}%T}!O8X!O!Q%T!Q![8s![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti8^V&n`O!Q%T!Q![8s![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti8z]!hX&n`O!Q%T!Q![8s![!l%T!l!m9s!m#R%T#R#S8s#S#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti9zT!hX&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk:bX%qR&n`O!P%T!P!Q:}!Q!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj;UV%sQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti;ro!hX&n`O!O%T!O!P=s!P!Q%T!Q![>_![!d%T!d!e?q!e!g%T!g!h7a!h!l%T!l!m9s!m!q%T!q!rA]!r!z%T!z!{Bq!{#R%T#R#S>_#S#U%T#U#V?q#V#X%T#X#Y7a#Y#^%T#^#_9s#_#c%T#c#dA]#d#l%T#l#mBq#m#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti=xV&n`O!Q%T!Q![6T![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti>fc!hX&n`O!O%T!O!P=s!P!Q%T!Q![>_![!g%T!g!h7a!h!l%T!l!m9s!m#R%T#R#S>_#S#X%T#X#Y7a#Y#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti?vY&n`O!Q%T!Q!R@f!R!S@f!S#R%T#R#S@f#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti@mY!hX&n`O!Q%T!Q!R@f!R!S@f!S#R%T#R#S@f#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiAbX&n`O!Q%T!Q!YA}!Y#R%T#R#SA}#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiBUX!hX&n`O!Q%T!Q!YA}!Y#R%T#R#SA}#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiBv]&n`O!Q%T!Q![Co![!c%T!c!iCo!i#R%T#R#SCo#S#T%T#T#ZCo#Z#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiCv]!hX&n`O!Q%T!Q![Co![!c%T!c!iCo!i#R%T#R#SCo#S#T%T#T#ZCo#Z#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%ToDvV{_&n`O!_%T!_!`E]!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TcEdT%{R&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkEzT#gZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkFbXmR&n`O!^%T!^!_F}!_!`([!`!a([!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TjGUV%mQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkGrV%zZ&n`O!_%T!_!`([!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkH`WmR&n`O!_%T!_!`([!`!aHx!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TjIPV%nQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkIoV_Q#}P&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%ToJ_]&n`&YS%uZO!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUoKZP;=`<%lJUoKge&n`&YS%uZOr%Trs)Ysw%Twx.Ux!Q%T!Q![JU![!c%T!c!tJU!t!uLx!u!}JU!}#R%T#R#SJU#S#T%T#T#fJU#f#gLx#g#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUoMRa&n`&YS%uZOr%TrsNWsw%Twx! vx!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUkN_V&n`&`ZOr%TrsNts#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkNyV&n`Or%Trs! `s#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk! gT&n`&bZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk! }V&n`&_ZOw%Twx!!dx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!!iV&n`Ow%Twx!#Ox#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!#VT&n`&aZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!#oe&n`&YS%uZOr%Trs!%Qsw%Twx!&px!Q%T!Q![JU![!c%T!c!tJU!t!u!(`!u!}JU!}#R%T#R#SJU#S#T%T#T#fJU#f#g!(`#g#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!%XV&n`&dZOr%Trs!%ns#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!%sV&n`Or%Trs!&Ys#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!&aT&n`&fZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!&wV&n`&cZOw%Twx!'^x#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!'cV&n`Ow%Twx!'xx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!(PT&n`&eZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!(ia&n`&YS%uZOr%Trs!)nsw%Twx!+^x!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!)uV&n`&hZOr%Trs!*[s#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!*aV&n`Or%Trs!*vs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!*}T&n`&jZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!+eV&n`&gZOw%Twx!+zx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!,PV&n`Ow%Twx!,fx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!,mT&n`&iZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!-Vi&n`&YS%uZOr%TrsNWsw%Twx! vx!Q%T!Q![JU![!c%T!c!dJU!d!eLx!e!hJU!h!i!(`!i!}JU!}#R%T#R#SJU#S#T%T#T#UJU#U#VLx#V#YJU#Y#Z!(`#Z#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUo!.}a&n`&YS%uZOr%Trs)Ysw%Twx.Ux!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!0ZT!XZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc!0qT!WR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj!1XV%kQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T~!1sO!]~k!1zV%jR&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T~!2fO![~i!2mT%tX&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T",tokenizers:[oS,iS,tS,lS,0,1,2,3,4],topRules:{Script:[0,5]},specialized:[{term:221,get:r=>fS[r]||-1}],tokenPrec:7668});var Co=class{constructor(e,t,i,s){this.state=e,this.pos=t,this.explicit=i,this.view=s,this.abortListeners=[],this.abortOnDocChange=!1}tokenBefore(e){let t=Be(this.state).resolveInner(this.pos,-1);for(;t&&e.indexOf(t.name)<0;)t=t.parent;return t?{from:t.from,to:this.pos,text:this.state.sliceDoc(t.from,this.pos),type:t.type}:null}matchBefore(e){let t=this.state.doc.lineAt(this.pos),i=Math.max(t.from,this.pos-250),s=t.text.slice(i-t.from,this.pos-t.from),n=s.search(zg(e,!1));return n<0?null:{from:i+n,to:this.pos,text:s.slice(n)}}get aborted(){return this.abortListeners==null}addEventListener(e,t,i){e=="abort"&&this.abortListeners&&(this.abortListeners.push(t),i&&i.onDocChange&&(this.abortOnDocChange=!0))}};function Ng(r){let e=Object.keys(r).join(""),t=/\w/.test(e);return t&&(e=e.replace(/\w/g,"")),`[${t?"\\w":""}${e.replace(/[^\w\s]/g,"\\$&")}]`}function cS(r){let e=Object.create(null),t=Object.create(null);for(let{label:s}of r){e[s[0]]=!0;for(let n=1;n<s.length;n++)t[s[n]]=!0}let i=Ng(e)+Ng(t)+"*$";return[new RegExp("^"+i),new RegExp(i)]}function Zh(r){let e=r.map(s=>typeof s=="string"?{label:s}:s),[t,i]=e.every(s=>/^\w+$/.test(s.label))?[/\w*$/,/\w+$/]:cS(e);return s=>{let n=s.matchBefore(i);return n||s.explicit?{from:n?n.from:s.pos,options:e,validFor:t}:null}}function Wg(r,e){return t=>{for(let i=Be(t.state).resolveInner(t.pos,-1);i;i=i.parent){if(r.indexOf(i.name)>-1)return null;if(i.type.isTop)break}return e(t)}}var Eo=class{constructor(e,t,i,s){this.completion=e,this.source=t,this.match=i,this.score=s}};function hs(r){return r.selection.main.from}function zg(r,e){var t;let{source:i}=r,s=e&&i[0]!="^",n=i[i.length-1]!="$";return!s&&!n?r:new RegExp(`${s?"^":""}(?:${i})${n?"$":""}`,(t=r.flags)!==null&&t!==void 0?t:r.ignoreCase?"i":"")}var ef=lt.define();function dS(r,e,t,i){let{main:s}=r.selection,n=t-s.from,o=i-s.from;return{...r.changeByRange(l=>{if(l!=s&&t!=i&&r.sliceDoc(l.from+n,l.from+o)!=r.sliceDoc(t,i))return{range:l};let a=r.toText(e);return{changes:{from:l.from+n,to:i==s.from?l.to:l.from+o,insert:a},range:M.cursor(l.from+n+a.length)}}),scrollIntoView:!0,userEvent:"input.complete"}}var Ig=new WeakMap;function uS(r){if(!Array.isArray(r))return r;let e=Ig.get(r);return e||Ig.set(r,e=Zh(r)),e}var Ao=re.define(),$r=re.define(),jh=class{constructor(e){this.pattern=e,this.chars=[],this.folded=[],this.any=[],this.precise=[],this.byWord=[],this.score=0,this.matched=[];for(let t=0;t<e.length;){let i=Ge(e,t),s=ct(i);this.chars.push(i);let n=e.slice(t,t+s),o=n.toUpperCase();this.folded.push(Ge(o==n?n.toLowerCase():o,0)),t+=s}this.astral=e.length!=this.chars.length}ret(e,t){return this.score=e,this.matched=t,this}match(e){if(this.pattern.length==0)return this.ret(-100,[]);if(e.length<this.pattern.length)return null;let{chars:t,folded:i,any:s,precise:n,byWord:o}=this;if(t.length==1){let T=Ge(e,0),C=ct(T),Q=C==e.length?0:-100;if(T!=t[0])if(T==i[0])Q+=-200;else return null;return this.ret(Q,[0,C])}let l=e.indexOf(this.pattern);if(l==0)return this.ret(e.length==this.pattern.length?0:-100,[0,this.pattern.length]);let a=t.length,h=0;if(l<0){for(let T=0,C=Math.min(e.length,200);T<C&&h<a;){let Q=Ge(e,T);(Q==t[h]||Q==i[h])&&(s[h++]=T),T+=ct(Q)}if(h<a)return null}let c=0,u=0,p=!1,y=0,O=-1,b=-1,v=/[a-z]/.test(e),k=!0;for(let T=0,C=Math.min(e.length,200),Q=0;T<C&&u<a;){let A=Ge(e,T);l<0&&(c<a&&A==t[c]&&(n[c++]=T),y<a&&(A==t[y]||A==i[y]?(y==0&&(O=T),b=T+1,y++):y=0));let R,D=A<255?A>=48&&A<=57||A>=97&&A<=122?2:A>=65&&A<=90?1:0:(R=fr(A))!=R.toLowerCase()?1:R!=R.toUpperCase()?2:0;(!T||D==1&&v||Q==0&&D!=0)&&(t[u]==A||i[u]==A&&(p=!0)?o[u++]=T:o.length&&(k=!1)),Q=D,T+=ct(A)}return u==a&&o[0]==0&&k?this.result(-100+(p?-200:0),o,e):y==a&&O==0?this.ret(-200-e.length+(b==e.length?0:-100),[0,b]):l>-1?this.ret(-700-e.length,[l,l+this.pattern.length]):y==a?this.ret(-900-e.length,[O,b]):u==a?this.result(-100+(p?-200:0)+-700+(k?0:-1100),o,e):t.length==2?null:this.result((s[0]?-700:0)+-200+-1100,s,e)}result(e,t,i){let s=[],n=0;for(let o of t){let l=o+(this.astral?ct(Ge(i,o)):1);n&&s[n-1]==o?s[n-1]=l:(s[n++]=o,s[n++]=l)}return this.ret(e-i.length,s)}},Hh=class{constructor(e){this.pattern=e,this.matched=[],this.score=0,this.folded=e.toLowerCase()}match(e){if(e.length<this.pattern.length)return null;let t=e.slice(0,this.pattern.length),i=t==this.pattern?0:t.toLowerCase()==this.folded?-200:null;return i==null?null:(this.matched=[0,t.length],this.score=i+(e.length==this.pattern.length?0:-100),this)}},$e=W.define({combine(r){return wt(r,{activateOnTyping:!0,activateOnCompletion:()=>!1,activateOnTypingDelay:100,selectOnOpen:!0,override:null,closeOnBlur:!0,maxRenderedOptions:100,defaultKeymap:!0,tooltipClass:()=>"",optionClass:()=>"",aboveCursor:!1,icons:!0,addToOptions:[],positionInfo:pS,filterStrict:!1,compareCompletions:(e,t)=>(e.sortText||e.label).localeCompare(t.sortText||t.label),interactionDelay:75,updateSyncTime:100},{defaultKeymap:(e,t)=>e&&t,closeOnBlur:(e,t)=>e&&t,icons:(e,t)=>e&&t,tooltipClass:(e,t)=>i=>Lg(e(i),t(i)),optionClass:(e,t)=>i=>Lg(e(i),t(i)),addToOptions:(e,t)=>e.concat(t),filterStrict:(e,t)=>e||t})}});function Lg(r,e){return r?e?r+" "+e:r:e}function pS(r,e,t,i,s,n){let o=r.textDirection==_e.RTL,l=o,a=!1,h="top",c,u,p=e.left-s.left,y=s.right-e.right,O=i.right-i.left,b=i.bottom-i.top;if(l&&p<Math.min(O,y)?l=!1:!l&&y<Math.min(O,p)&&(l=!0),O<=(l?p:y))c=Math.max(s.top,Math.min(t.top,s.bottom-b))-e.top,u=Math.min(400,l?p:y);else{a=!0,u=Math.min(400,(o?e.right:s.right-e.left)-30);let T=s.bottom-e.bottom;T>=b||T>e.top?c=t.bottom-e.top:(h="bottom",c=e.bottom-t.top)}let v=(e.bottom-e.top)/n.offsetHeight,k=(e.right-e.left)/n.offsetWidth;return{style:`${h}: ${c/v}px; max-width: ${u/k}px`,class:"cm-completionInfo-"+(a?o?"left-narrow":"right-narrow":l?"left":"right")}}var tf=re.define();function mS(r){let e=r.addToOptions.slice();return r.icons&&e.push({render(t){let i=document.createElement("div");return i.classList.add("cm-completionIcon"),t.type&&i.classList.add(...t.type.split(/\s+/g).map(s=>"cm-completionIcon-"+s)),i.setAttribute("aria-hidden","true"),i},position:20}),e.push({render(t,i,s,n){let o=document.createElement("span");o.className="cm-completionLabel";let l=t.displayLabel||t.label,a=0;for(let h=0;h<n.length;){let c=n[h++],u=n[h++];c>a&&o.appendChild(document.createTextNode(l.slice(a,c)));let p=o.appendChild(document.createElement("span"));p.appendChild(document.createTextNode(l.slice(c,u))),p.className="cm-completionMatchedText",a=u}return a<l.length&&o.appendChild(document.createTextNode(l.slice(a))),o},position:50},{render(t){if(!t.detail)return null;let i=document.createElement("span");return i.className="cm-completionDetail",i.textContent=t.detail,i},position:80}),e.sort((t,i)=>t.position-i.position).map(t=>t.render)}function Fh(r,e,t){if(r<=t)return{from:0,to:r};if(e<0&&(e=0),e<=r>>1){let s=Math.floor(e/t);return{from:s*t,to:(s+1)*t}}let i=Math.ceil((r-e)/t);return{from:r-i*t,to:r-(i-1)*t}}var Vh=class{constructor(e,t,i){this.view=e,this.stateField=t,this.applyCompletion=i,this.info=null,this.infoDestroy=null,this.placeInfoReq={read:()=>this.measureInfo(),write:a=>this.placeInfo(a),key:this},this.space=null,this.currentClass="";let s=e.state.field(t),{options:n,selected:o}=s.open,l=e.state.facet($e);this.optionContent=mS(l),this.optionClass=l.optionClass,this.tooltipClass=l.tooltipClass,this.range=Fh(n.length,o,l.maxRenderedOptions),this.dom=document.createElement("div"),this.dom.className="cm-tooltip-autocomplete",this.updateTooltipClass(e.state),this.dom.addEventListener("mousedown",a=>{let{options:h}=e.state.field(t).open;for(let c=a.target,u;c&&c!=this.dom;c=c.parentNode)if(c.nodeName=="LI"&&(u=/-(\d+)$/.exec(c.id))&&+u[1]<h.length){this.applyCompletion(e,h[+u[1]]),a.preventDefault();return}if(a.target==this.list){let c=this.list.classList.contains("cm-completionListIncompleteTop")&&a.clientY<this.list.firstChild.getBoundingClientRect().top?this.range.from-1:this.list.classList.contains("cm-completionListIncompleteBottom")&&a.clientY>this.list.lastChild.getBoundingClientRect().bottom?this.range.to:null;c!=null&&(e.dispatch({effects:tf.of(c)}),a.preventDefault())}}),this.dom.addEventListener("focusout",a=>{let h=e.state.field(this.stateField,!1);h&&h.tooltip&&e.state.facet($e).closeOnBlur&&a.relatedTarget!=e.contentDOM&&e.dispatch({effects:$r.of(null)})}),this.showOptions(n,s.id)}mount(){this.updateSel()}showOptions(e,t){this.list&&this.list.remove(),this.list=this.dom.appendChild(this.createListBox(e,t,this.range)),this.list.addEventListener("scroll",()=>{this.info&&this.view.requestMeasure(this.placeInfoReq)})}update(e){var t;let i=e.state.field(this.stateField),s=e.startState.field(this.stateField);if(this.updateTooltipClass(e.state),i!=s){let{options:n,selected:o,disabled:l}=i.open;(!s.open||s.open.options!=n)&&(this.range=Fh(n.length,o,e.state.facet($e).maxRenderedOptions),this.showOptions(n,i.id)),this.updateSel(),l!=((t=s.open)===null||t===void 0?void 0:t.disabled)&&this.dom.classList.toggle("cm-tooltip-autocomplete-disabled",!!l)}}updateTooltipClass(e){let t=this.tooltipClass(e);if(t!=this.currentClass){for(let i of this.currentClass.split(" "))i&&this.dom.classList.remove(i);for(let i of t.split(" "))i&&this.dom.classList.add(i);this.currentClass=t}}positioned(e){this.space=e,this.info&&this.view.requestMeasure(this.placeInfoReq)}updateSel(){let e=this.view.state.field(this.stateField),t=e.open;(t.selected>-1&&t.selected<this.range.from||t.selected>=this.range.to)&&(this.range=Fh(t.options.length,t.selected,this.view.state.facet($e).maxRenderedOptions),this.showOptions(t.options,e.id));let i=this.updateSelectedOption(t.selected);if(i){this.destroyInfo();let{completion:s}=t.options[t.selected],{info:n}=s;if(!n)return;let o=typeof n=="string"?document.createTextNode(n):n(s);if(!o)return;"then"in o?o.then(l=>{l&&this.view.state.field(this.stateField,!1)==e&&this.addInfoPane(l,s)}).catch(l=>tt(this.view.state,l,"completion info")):(this.addInfoPane(o,s),i.setAttribute("aria-describedby",this.info.id))}}addInfoPane(e,t){this.destroyInfo();let i=this.info=document.createElement("div");if(i.className="cm-tooltip cm-completionInfo",i.id="cm-completionInfo-"+Math.floor(Math.random()*65535).toString(16),e.nodeType!=null)i.appendChild(e),this.infoDestroy=null;else{let{dom:s,destroy:n}=e;i.appendChild(s),this.infoDestroy=n||null}this.dom.appendChild(i),this.view.requestMeasure(this.placeInfoReq)}updateSelectedOption(e){let t=null;for(let i=this.list.firstChild,s=this.range.from;i;i=i.nextSibling,s++)i.nodeName!="LI"||!i.id?s--:s==e?i.hasAttribute("aria-selected")||(i.setAttribute("aria-selected","true"),t=i):i.hasAttribute("aria-selected")&&(i.removeAttribute("aria-selected"),i.removeAttribute("aria-describedby"));return t&&_S(this.list,t),t}measureInfo(){let e=this.dom.querySelector("[aria-selected]");if(!e||!this.info)return null;let t=this.dom.getBoundingClientRect(),i=this.info.getBoundingClientRect(),s=e.getBoundingClientRect(),n=this.space;if(!n){let o=this.dom.ownerDocument.documentElement;n={left:0,top:0,right:o.clientWidth,bottom:o.clientHeight}}return s.top>Math.min(n.bottom,t.bottom)-10||s.bottom<Math.max(n.top,t.top)+10?null:this.view.state.facet($e).positionInfo(this.view,t,s,i,n,this.dom)}placeInfo(e){this.info&&(e?(e.style&&(this.info.style.cssText=e.style),this.info.className="cm-tooltip cm-completionInfo "+(e.class||"")):this.info.style.cssText="top: -1e6px")}createListBox(e,t,i){let s=document.createElement("ul");s.id=t,s.setAttribute("role","listbox"),s.setAttribute("aria-expanded","true"),s.setAttribute("aria-label",this.view.state.phrase("Completions")),s.addEventListener("mousedown",o=>{o.target==s&&o.preventDefault()});let n=null;for(let o=i.from;o<i.to;o++){let{completion:l,match:a}=e[o],{section:h}=l;if(h){let p=typeof h=="string"?h:h.name;if(p!=n&&(o>i.from||i.from==0))if(n=p,typeof h!="string"&&h.header)s.appendChild(h.header(h));else{let y=s.appendChild(document.createElement("completion-section"));y.textContent=p}}let c=s.appendChild(document.createElement("li"));c.id=t+"-"+o,c.setAttribute("role","option");let u=this.optionClass(l);u&&(c.className=u);for(let p of this.optionContent){let y=p(l,this.view.state,this.view,a);y&&c.appendChild(y)}}return i.from&&s.classList.add("cm-completionListIncompleteTop"),i.to<e.length&&s.classList.add("cm-completionListIncompleteBottom"),s}destroyInfo(){this.info&&(this.infoDestroy&&this.infoDestroy(),this.info.remove(),this.info=null)}destroy(){this.destroyInfo()}};function gS(r,e){return t=>new Vh(t,r,e)}function _S(r,e){let t=r.getBoundingClientRect(),i=e.getBoundingClientRect(),s=t.height/r.offsetHeight;i.top<t.top?r.scrollTop-=(t.top-i.top)/s:i.bottom>t.bottom&&(r.scrollTop+=(i.bottom-t.bottom)/s)}function Qg(r){return(r.boost||0)*100+(r.apply?10:0)+(r.info?5:0)+(r.type?1:0)}function yS(r,e){let t=[],i=null,s=null,n=c=>{t.push(c);let{section:u}=c.completion;if(u){i||(i=[]);let p=typeof u=="string"?u:u.name;i.some(y=>y.name==p)||i.push(typeof u=="string"?{name:p}:u)}},o=e.facet($e);for(let c of r)if(c.hasResult()){let u=c.result.getMatch;if(c.result.filter===!1)for(let p of c.result.options)n(new Eo(p,c.source,u?u(p):[],1e9-t.length));else{let p=e.sliceDoc(c.from,c.to),y,O=o.filterStrict?new Hh(p):new jh(p);for(let b of c.result.options)if(y=O.match(b.label)){let v=b.displayLabel?u?u(b,y.matched):[]:y.matched,k=y.score+(b.boost||0);if(n(new Eo(b,c.source,v,k)),typeof b.section=="object"&&b.section.rank==="dynamic"){let{name:T}=b.section;s||(s=Object.create(null)),s[T]=Math.max(k,s[T]||-1e9)}}}}if(i){let c=Object.create(null),u=0,p=(y,O)=>(y.rank==="dynamic"&&O.rank==="dynamic"?s[O.name]-s[y.name]:0)||(typeof y.rank=="number"?y.rank:1e9)-(typeof O.rank=="number"?O.rank:1e9)||(y.name<O.name?-1:1);for(let y of i.sort(p))u-=1e5,c[y.name]=u;for(let y of t){let{section:O}=y.completion;O&&(y.score+=c[typeof O=="string"?O:O.name])}}let l=[],a=null,h=o.compareCompletions;for(let c of t.sort((u,p)=>p.score-u.score||h(u.completion,p.completion))){let u=c.completion;!a||a.label!=u.label||a.detail!=u.detail||a.type!=null&&u.type!=null&&a.type!=u.type||a.apply!=u.apply||a.boost!=u.boost?l.push(c):Qg(c.completion)>Qg(a)&&(l[l.length-1]=c),a=c.completion}return l}var Uh=class r{constructor(e,t,i,s,n,o){this.options=e,this.attrs=t,this.tooltip=i,this.timestamp=s,this.selected=n,this.disabled=o}setSelected(e,t){return e==this.selected||e>=this.options.length?this:new r(this.options,qg(t,e),this.tooltip,this.timestamp,e,this.disabled)}static build(e,t,i,s,n,o){if(s&&!o&&e.some(h=>h.isPending))return s.setDisabled();let l=yS(e,t);if(!l.length)return s&&e.some(h=>h.isPending)?s.setDisabled():null;let a=t.facet($e).selectOnOpen?0:-1;if(s&&s.selected!=a&&s.selected!=-1){let h=s.options[s.selected].completion;for(let c=0;c<l.length;c++)if(l[c].completion==h){a=c;break}}return new r(l,qg(i,a),{pos:e.reduce((h,c)=>c.hasResult()?Math.min(h,c.from):h,1e8),create:xS,above:n.aboveCursor},s?s.timestamp:Date.now(),a,!1)}map(e){return new r(this.options,this.attrs,{...this.tooltip,pos:e.mapPos(this.tooltip.pos)},this.timestamp,this.selected,this.disabled)}setDisabled(){return new r(this.options,this.attrs,this.tooltip,this.timestamp,this.selected,!0)}},Gh=class r{constructor(e,t,i){this.active=e,this.id=t,this.open=i}static start(){return new r(wS,"cm-ac-"+Math.floor(Math.random()*2e6).toString(36),null)}update(e){let{state:t}=e,i=t.facet($e),n=(i.override||t.languageDataAt("autocomplete",hs(t)).map(uS)).map(a=>(this.active.find(c=>c.source==a)||new mi(a,this.active.some(c=>c.state!=0)?1:0)).update(e,i));n.length==this.active.length&&n.every((a,h)=>a==this.active[h])&&(n=this.active);let o=this.open,l=e.effects.some(a=>a.is(sf));o&&e.docChanged&&(o=o.map(e.changes)),e.selection||n.some(a=>a.hasResult()&&e.changes.touchesRange(a.from,a.to))||!bS(n,this.active)||l?o=Uh.build(n,t,this.id,o,i,l):o&&o.disabled&&!n.some(a=>a.isPending)&&(o=null),!o&&n.every(a=>!a.isPending)&&n.some(a=>a.hasResult())&&(n=n.map(a=>a.hasResult()?new mi(a.source,0):a));for(let a of e.effects)a.is(tf)&&(o=o&&o.setSelected(a.value,this.id));return n==this.active&&o==this.open?this:new r(n,this.id,o)}get tooltip(){return this.open?this.open.tooltip:null}get attrs(){return this.open?this.open.attrs:this.active.length?OS:vS}};function bS(r,e){if(r==e)return!0;for(let t=0,i=0;;){for(;t<r.length&&!r[t].hasResult();)t++;for(;i<e.length&&!e[i].hasResult();)i++;let s=t==r.length,n=i==e.length;if(s||n)return s==n;if(r[t++].result!=e[i++].result)return!1}}var OS={"aria-autocomplete":"list"},vS={};function qg(r,e){let t={"aria-autocomplete":"list","aria-haspopup":"listbox","aria-controls":r};return e>-1&&(t["aria-activedescendant"]=r+"-"+e),t}var wS=[];function jg(r,e){if(r.isUserEvent("input.complete")){let i=r.annotation(ef);if(i&&e.activateOnCompletion(i))return 12}let t=r.isUserEvent("input.type");return t&&e.activateOnTyping?5:t?1:r.isUserEvent("delete.backward")?2:r.selection?8:r.docChanged?16:0}var mi=class r{constructor(e,t,i=!1){this.source=e,this.state=t,this.explicit=i}hasResult(){return!1}get isPending(){return this.state==1}update(e,t){let i=jg(e,t),s=this;(i&8||i&16&&this.touches(e))&&(s=new r(s.source,0)),i&4&&s.state==0&&(s=new r(this.source,1)),s=s.updateFor(e,i);for(let n of e.effects)if(n.is(Ao))s=new r(s.source,1,n.value);else if(n.is($r))s=new r(s.source,0);else if(n.is(sf))for(let o of n.value)o.source==s.source&&(s=o);return s}updateFor(e,t){return this.map(e.changes)}map(e){return this}touches(e){return e.changes.touchesRange(hs(e.state))}},Ro=class r extends mi{constructor(e,t,i,s,n,o){super(e,3,t),this.limit=i,this.result=s,this.from=n,this.to=o}hasResult(){return!0}updateFor(e,t){var i;if(!(t&3))return this.map(e.changes);let s=this.result;s.map&&!e.changes.empty&&(s=s.map(s,e.changes));let n=e.changes.mapPos(this.from),o=e.changes.mapPos(this.to,1),l=hs(e.state);if(l>o||!s||t&2&&(hs(e.startState)==this.from||l<this.limit))return new mi(this.source,t&4?1:0);let a=e.changes.mapPos(this.limit);return kS(s.validFor,e.state,n,o)?new r(this.source,this.explicit,a,s,n,o):s.update&&(s=s.update(s,n,o,new Co(e.state,l,!1)))?new r(this.source,this.explicit,a,s,s.from,(i=s.to)!==null&&i!==void 0?i:hs(e.state)):new mi(this.source,1,this.explicit)}map(e){if(e.empty)return this;let t=this.result.map?this.result.map(this.result,e):this.result;return t?new r(this.source,this.explicit,e.mapPos(this.limit),t,e.mapPos(this.from),e.mapPos(this.to,1)):new mi(this.source,0)}touches(e){return e.changes.touchesRange(this.from,this.to)}};function kS(r,e,t,i){if(!r)return!1;let s=e.sliceDoc(t,i);return typeof r=="function"?r(s,t,i,e):zg(r,!0).test(s)}var sf=re.define({map(r,e){return r.map(t=>t.map(e))}}),ht=Qe.define({create(){return Gh.start()},update(r,e){return r.update(e)},provide:r=>[Va.from(r,e=>e.tooltip),z.contentAttributes.from(r,e=>e.attrs)]});function rf(r,e){let t=e.completion.apply||e.completion.label,i=r.state.field(ht).active.find(s=>s.source==e.source);return i instanceof Ro?(typeof t=="string"?r.dispatch({...dS(r.state,t,i.from,i.to),annotations:ef.of(e.completion)}):t(r,e.completion,i.from,i.to),!0):!1}var xS=gS(ht,rf);function Po(r,e="option"){return t=>{let i=t.state.field(ht,!1);if(!i||!i.open||i.open.disabled||Date.now()-i.open.timestamp<t.state.facet($e).interactionDelay)return!1;let s=1,n;e=="page"&&(n=Ua(t,i.open.tooltip))&&(s=Math.max(2,Math.floor(n.dom.offsetHeight/n.dom.querySelector("li").offsetHeight)-1));let{length:o}=i.open.options,l=i.open.selected>-1?i.open.selected+s*(r?1:-1):r?0:o-1;return l<0?l=e=="page"?0:o-1:l>=o&&(l=e=="page"?o-1:0),t.dispatch({effects:tf.of(l)}),!0}}var SS=r=>{let e=r.state.field(ht,!1);return r.state.readOnly||!e||!e.open||e.open.selected<0||e.open.disabled||Date.now()-e.open.timestamp<r.state.facet($e).interactionDelay?!1:rf(r,e.open.options[e.open.selected])},Wh=r=>r.state.field(ht,!1)?(r.dispatch({effects:Ao.of(!0)}),!0):!1,TS=r=>{let e=r.state.field(ht,!1);return!e||!e.active.some(t=>t.state!=0)?!1:(r.dispatch({effects:$r.of(null)}),!0)},Xh=class{constructor(e,t){this.active=e,this.context=t,this.time=Date.now(),this.updates=[],this.done=void 0}},PS=50,CS=1e3,ES=qe.fromClass(class{constructor(r){this.view=r,this.debounceUpdate=-1,this.running=[],this.debounceAccept=-1,this.pendingStart=!1,this.composing=0;for(let e of r.state.field(ht).active)e.isPending&&this.startQuery(e)}update(r){let e=r.state.field(ht),t=r.state.facet($e);if(!r.selectionSet&&!r.docChanged&&r.startState.field(ht)==e)return;let i=r.transactions.some(n=>{let o=jg(n,t);return o&8||(n.selection||n.docChanged)&&!(o&3)});for(let n=0;n<this.running.length;n++){let o=this.running[n];if(i||o.context.abortOnDocChange&&r.docChanged||o.updates.length+r.transactions.length>PS&&Date.now()-o.time>CS){for(let l of o.context.abortListeners)try{l()}catch(a){tt(this.view.state,a)}o.context.abortListeners=null,this.running.splice(n--,1)}else o.updates.push(...r.transactions)}this.debounceUpdate>-1&&clearTimeout(this.debounceUpdate),r.transactions.some(n=>n.effects.some(o=>o.is(Ao)))&&(this.pendingStart=!0);let s=this.pendingStart?50:t.activateOnTypingDelay;if(this.debounceUpdate=e.active.some(n=>n.isPending&&!this.running.some(o=>o.active.source==n.source))?setTimeout(()=>this.startUpdate(),s):-1,this.composing!=0)for(let n of r.transactions)n.isUserEvent("input.type")?this.composing=2:this.composing==2&&n.selection&&(this.composing=3)}startUpdate(){this.debounceUpdate=-1,this.pendingStart=!1;let{state:r}=this.view,e=r.field(ht);for(let t of e.active)t.isPending&&!this.running.some(i=>i.active.source==t.source)&&this.startQuery(t);this.running.length&&e.open&&e.open.disabled&&(this.debounceAccept=setTimeout(()=>this.accept(),this.view.state.facet($e).updateSyncTime))}startQuery(r){let{state:e}=this.view,t=hs(e),i=new Co(e,t,r.explicit,this.view),s=new Xh(r,i);this.running.push(s),Promise.resolve(r.source(i)).then(n=>{s.context.aborted||(s.done=n||null,this.scheduleAccept())},n=>{this.view.dispatch({effects:$r.of(null)}),tt(this.view.state,n)})}scheduleAccept(){this.running.every(r=>r.done!==void 0)?this.accept():this.debounceAccept<0&&(this.debounceAccept=setTimeout(()=>this.accept(),this.view.state.facet($e).updateSyncTime))}accept(){var r;this.debounceAccept>-1&&clearTimeout(this.debounceAccept),this.debounceAccept=-1;let e=[],t=this.view.state.facet($e),i=this.view.state.field(ht);for(let s=0;s<this.running.length;s++){let n=this.running[s];if(n.done===void 0)continue;if(this.running.splice(s--,1),n.done){let l=hs(n.updates.length?n.updates[0].startState:this.view.state),a=Math.min(l,n.done.from+(n.active.explicit?0:1)),h=new Ro(n.active.source,n.active.explicit,a,n.done,n.done.from,(r=n.done.to)!==null&&r!==void 0?r:l);for(let c of n.updates)h=h.update(c,t);if(h.hasResult()){e.push(h);continue}}let o=i.active.find(l=>l.source==n.active.source);if(o&&o.isPending)if(n.done==null){let l=new mi(n.active.source,0);for(let a of n.updates)l=l.update(a,t);l.isPending||e.push(l)}else this.startQuery(o)}(e.length||i.open&&i.open.disabled)&&this.view.dispatch({effects:sf.of(e)})}},{eventHandlers:{blur(r){let e=this.view.state.field(ht,!1);if(e&&e.tooltip&&this.view.state.facet($e).closeOnBlur){let t=e.open&&Ua(this.view,e.open.tooltip);(!t||!t.dom.contains(r.relatedTarget))&&setTimeout(()=>this.view.dispatch({effects:$r.of(null)}),10)}},compositionstart(){this.composing=1},compositionend(){this.composing==3&&setTimeout(()=>this.view.dispatch({effects:Ao.of(!1)}),20),this.composing=0}}}),AS=typeof navigator=="object"&&/Win/.test(navigator.platform),RS=vt.highest(z.domEventHandlers({keydown(r,e){let t=e.state.field(ht,!1);if(!t||!t.open||t.open.disabled||t.open.selected<0||r.key.length>1||r.ctrlKey&&!(AS&&r.altKey)||r.metaKey)return!1;let i=t.open.options[t.open.selected],s=t.active.find(o=>o.source==i.source),n=i.completion.commitCharacters||s.result.commitCharacters;return n&&n.indexOf(r.key)>-1&&rf(e,i),!1}})),Hg=z.baseTheme({".cm-tooltip.cm-tooltip-autocomplete":{"& > ul":{fontFamily:"monospace",whiteSpace:"nowrap",overflow:"hidden auto",maxWidth_fallback:"700px",maxWidth:"min(700px, 95vw)",minWidth:"250px",maxHeight:"10em",height:"100%",listStyle:"none",margin:0,padding:0,"& > li, & > completion-section":{padding:"1px 3px",lineHeight:1.2},"& > li":{overflowX:"hidden",textOverflow:"ellipsis",cursor:"pointer"},"& > completion-section":{display:"list-item",borderBottom:"1px solid silver",paddingLeft:"0.5em",opacity:.7}}},"&light .cm-tooltip-autocomplete ul li[aria-selected]":{background:"#17c",color:"white"},"&light .cm-tooltip-autocomplete-disabled ul li[aria-selected]":{background:"#777"},"&dark .cm-tooltip-autocomplete ul li[aria-selected]":{background:"#347",color:"white"},"&dark .cm-tooltip-autocomplete-disabled ul li[aria-selected]":{background:"#444"},".cm-completionListIncompleteTop:before, .cm-completionListIncompleteBottom:after":{content:'"\xB7\xB7\xB7"',opacity:.5,display:"block",textAlign:"center",cursor:"pointer"},".cm-tooltip.cm-completionInfo":{position:"absolute",padding:"3px 9px",width:"max-content",maxWidth:"400px",boxSizing:"border-box",whiteSpace:"pre-line"},".cm-completionInfo.cm-completionInfo-left":{right:"100%"},".cm-completionInfo.cm-completionInfo-right":{left:"100%"},".cm-completionInfo.cm-completionInfo-left-narrow":{right:"30px"},".cm-completionInfo.cm-completionInfo-right-narrow":{left:"30px"},"&light .cm-snippetField":{backgroundColor:"#00000022"},"&dark .cm-snippetField":{backgroundColor:"#ffffff22"},".cm-snippetFieldPosition":{verticalAlign:"text-top",width:0,height:"1.15em",display:"inline-block",margin:"0 -0.7px -.7em",borderLeft:"1.4px dotted #888"},".cm-completionMatchedText":{textDecoration:"underline"},".cm-completionDetail":{marginLeft:"0.5em",fontStyle:"italic"},".cm-completionIcon":{fontSize:"90%",width:".8em",display:"inline-block",textAlign:"center",paddingRight:".6em",opacity:"0.6",boxSizing:"content-box"},".cm-completionIcon-function, .cm-completionIcon-method":{"&:after":{content:"'\u0192'"}},".cm-completionIcon-class":{"&:after":{content:"'\u25CB'"}},".cm-completionIcon-interface":{"&:after":{content:"'\u25CC'"}},".cm-completionIcon-variable":{"&:after":{content:"'\u{1D465}'"}},".cm-completionIcon-constant":{"&:after":{content:"'\u{1D436}'"}},".cm-completionIcon-type":{"&:after":{content:"'\u{1D461}'"}},".cm-completionIcon-enum":{"&:after":{content:"'\u222A'"}},".cm-completionIcon-property":{"&:after":{content:"'\u25A1'"}},".cm-completionIcon-keyword":{"&:after":{content:"'\u{1F511}\uFE0E'"}},".cm-completionIcon-namespace":{"&:after":{content:"'\u25A2'"}},".cm-completionIcon-text":{"&:after":{content:"'abc'",fontSize:"50%",verticalAlign:"middle"}}}),Jh=class{constructor(e,t,i,s){this.field=e,this.line=t,this.from=i,this.to=s}},Yh=class r{constructor(e,t,i){this.field=e,this.from=t,this.to=i}map(e){let t=e.mapPos(this.from,-1,Le.TrackDel),i=e.mapPos(this.to,1,Le.TrackDel);return t==null||i==null?null:new r(this.field,t,i)}},Kh=class r{constructor(e,t){this.lines=e,this.fieldPositions=t}instantiate(e,t){let i=[],s=[t],n=e.doc.lineAt(t),o=/^\s*/.exec(n.text)[0];for(let a of this.lines){if(i.length){let h=o,c=/^\t*/.exec(a)[0].length;for(let u=0;u<c;u++)h+=e.facet(Ti);s.push(t+h.length-c),a=h+a.slice(c)}i.push(a),t+=a.length+1}let l=this.fieldPositions.map(a=>new Yh(a.field,s[a.line]+a.from,s[a.line]+a.to));return{text:i,ranges:l}}static parse(e){let t=[],i=[],s=[],n;for(let o of e.split(/\r\n?|\n/)){for(;n=/[#$]\{(?:(\d+)(?::([^{}]*))?|((?:\\[{}]|[^{}])*))\}/.exec(o);){let l=n[1]?+n[1]:null,a=n[2]||n[3]||"",h=-1;l===0&&(l=1e9);let c=a.replace(/\\[{}]/g,u=>u[1]);for(let u=0;u<t.length;u++)(l!=null?t[u].seq==l:c&&t[u].name==c)&&(h=u);if(h<0){let u=0;for(;u<t.length&&(l==null||t[u].seq!=null&&t[u].seq<l);)u++;t.splice(u,0,{seq:l,name:c}),h=u;for(let p of s)p.field>=h&&p.field++}for(let u of s)if(u.line==i.length&&u.from>n.index){let p=n[2]?3+(n[1]||"").length:2;u.from-=p,u.to-=p}s.push(new Jh(h,i.length,n.index,n.index+c.length)),o=o.slice(0,n.index)+a+o.slice(n.index+n[0].length)}o=o.replace(/\\([{}])/g,(l,a,h)=>{for(let c of s)c.line==i.length&&c.from>h&&(c.from--,c.to--);return a}),i.push(o)}return new r(i,s)}},MS=K.widget({widget:new class extends ai{toDOM(){let r=document.createElement("span");return r.className="cm-snippetFieldPosition",r}ignoreEvent(){return!1}}}),DS=K.mark({class:"cm-snippetField"}),Xs=class r{constructor(e,t){this.ranges=e,this.active=t,this.deco=K.set(e.map(i=>(i.from==i.to?MS:DS).range(i.from,i.to)),!0)}map(e){let t=[];for(let i of this.ranges){let s=i.map(e);if(!s)return null;t.push(s)}return new r(t,this.active)}selectionInsideField(e){return e.ranges.every(t=>this.ranges.some(i=>i.field==this.active&&i.from<=t.from&&i.to>=t.to))}},zr=re.define({map(r,e){return r&&r.map(e)}}),NS=re.define(),Fr=Qe.define({create(){return null},update(r,e){for(let t of e.effects){if(t.is(zr))return t.value;if(t.is(NS)&&r)return new Xs(r.ranges,t.value)}return r&&e.docChanged&&(r=r.map(e.changes)),r&&e.selection&&!r.selectionInsideField(e.selection)&&(r=null),r},provide:r=>z.decorations.from(r,e=>e?e.deco:K.none)});function nf(r,e){return M.create(r.filter(t=>t.field==e).map(t=>M.range(t.from,t.to)))}function IS(r){let e=Kh.parse(r);return(t,i,s,n)=>{let{text:o,ranges:l}=e.instantiate(t.state,s),{main:a}=t.state.selection,h={changes:{from:s,to:n==a.from?a.to:n,insert:oe.of(o)},scrollIntoView:!0,annotations:i?[ef.of(i),Re.userEvent.of("input.complete")]:void 0};if(l.length&&(h.selection=nf(l,0)),l.some(c=>c.field>0)){let c=new Xs(l,0),u=h.effects=[zr.of(c)];t.state.field(Fr,!1)===void 0&&u.push(re.appendConfig.of([Fr,$S,FS,Hg]))}t.dispatch(t.state.update(h))}}function Vg(r){return({state:e,dispatch:t})=>{let i=e.field(Fr,!1);if(!i||r<0&&i.active==0)return!1;let s=i.active+r,n=r>0&&!i.ranges.some(o=>o.field==s+r);return t(e.update({selection:nf(i.ranges,s),effects:zr.of(n?null:new Xs(i.ranges,s)),scrollIntoView:!0})),!0}}var LS=({state:r,dispatch:e})=>r.field(Fr,!1)?(e(r.update({effects:zr.of(null)})),!0):!1,QS=Vg(1),qS=Vg(-1);var BS=[{key:"Tab",run:QS,shift:qS},{key:"Escape",run:LS}],Bg=W.define({combine(r){return r.length?r[0]:BS}}),$S=vt.highest($s.compute([Bg],r=>r.facet(Bg)));function At(r,e){return{...e,apply:IS(r)}}var FS=z.domEventHandlers({mousedown(r,e){let t=e.state.field(Fr,!1),i;if(!t||(i=e.posAtCoords({x:r.clientX,y:r.clientY}))==null)return!1;let s=t.ranges.find(n=>n.from<=i&&n.to>=i);return!s||s.field==t.active?!1:(e.dispatch({selection:nf(t.ranges,s.field),effects:zr.of(t.ranges.some(n=>n.field>s.field)?new Xs(t.ranges,s.field):null),scrollIntoView:!0}),!0)}});var Wr={brackets:["(","[","{","'",'"'],before:")]}:;>",stringPrefixes:[]},as=re.define({map(r,e){let t=e.mapPos(r,-1,Le.TrackAfter);return t??void 0}}),of=new class extends Ot{};of.startSide=1;of.endSide=-1;var Ug=Qe.define({create(){return ce.empty},update(r,e){if(r=r.map(e.changes),e.selection){let t=e.state.doc.lineAt(e.selection.main.head);r=r.update({filter:i=>i>=t.from&&i<=t.to})}for(let t of e.effects)t.is(as)&&(r=r.update({add:[of.range(t.value,t.value+1)]}));return r}});function Gg(){return[zS,Ug]}var zh="()[]{}<>\xAB\xBB\xBB\xAB\uFF3B\uFF3D\uFF5B\uFF5D";function Xg(r){for(let e=0;e<zh.length;e+=2)if(zh.charCodeAt(e)==r)return zh.charAt(e+1);return fr(r<128?r:r+1)}function Jg(r,e){return r.languageDataAt("closeBrackets",e)[0]||Wr}var WS=typeof navigator=="object"&&/Android\b/.test(navigator.userAgent),zS=z.inputHandler.of((r,e,t,i)=>{if((WS?r.composing:r.compositionStarted)||r.state.readOnly)return!1;let s=r.state.selection.main;if(i.length>2||i.length==2&&ct(Ge(i,0))==1||e!=s.from||t!=s.to)return!1;let n=HS(r.state,i);return n?(r.dispatch(n),!0):!1}),jS=({state:r,dispatch:e})=>{if(r.readOnly)return!1;let i=Jg(r,r.selection.main.head).brackets||Wr.brackets,s=null,n=r.changeByRange(o=>{if(o.empty){let l=VS(r.doc,o.head);for(let a of i)if(a==l&&Mo(r.doc,o.head)==Xg(Ge(a,0)))return{changes:{from:o.head-a.length,to:o.head+a.length},range:M.cursor(o.head-a.length)}}return{range:s=o}});return s||e(r.update(n,{scrollIntoView:!0,userEvent:"delete.backward"})),!s},Yg=[{key:"Backspace",run:jS}];function HS(r,e){let t=Jg(r,r.selection.main.head),i=t.brackets||Wr.brackets;for(let s of i){let n=Xg(Ge(s,0));if(e==s)return n==s?XS(r,s,i.indexOf(s+s+s)>-1,t):US(r,s,n,t.before||Wr.before);if(e==n&&Kg(r,r.selection.main.from))return GS(r,s,n)}return null}function Kg(r,e){let t=!1;return r.field(Ug).between(0,r.doc.length,i=>{i==e&&(t=!0)}),t}function Mo(r,e){let t=r.sliceString(e,e+2);return t.slice(0,ct(Ge(t,0)))}function VS(r,e){let t=r.sliceString(e-2,e);return ct(Ge(t,0))==t.length?t:t.slice(1)}function US(r,e,t,i){let s=null,n=r.changeByRange(o=>{if(!o.empty)return{changes:[{insert:e,from:o.from},{insert:t,from:o.to}],effects:as.of(o.to+e.length),range:M.range(o.anchor+e.length,o.head+e.length)};let l=Mo(r.doc,o.head);return!l||/\s/.test(l)||i.indexOf(l)>-1?{changes:{insert:e+t,from:o.head},effects:as.of(o.head+e.length),range:M.cursor(o.head+e.length)}:{range:s=o}});return s?null:r.update(n,{scrollIntoView:!0,userEvent:"input.type"})}function GS(r,e,t){let i=null,s=r.changeByRange(n=>n.empty&&Mo(r.doc,n.head)==t?{changes:{from:n.head,to:n.head+t.length,insert:t},range:M.cursor(n.head+t.length)}:i={range:n});return i?null:r.update(s,{scrollIntoView:!0,userEvent:"input.type"})}function XS(r,e,t,i){let s=i.stringPrefixes||Wr.stringPrefixes,n=null,o=r.changeByRange(l=>{if(!l.empty)return{changes:[{insert:e,from:l.from},{insert:e,from:l.to}],effects:as.of(l.to+e.length),range:M.range(l.anchor+e.length,l.head+e.length)};let a=l.head,h=Mo(r.doc,a),c;if(h==e){if($g(r,a))return{changes:{insert:e+e,from:a},effects:as.of(a+e.length),range:M.cursor(a+e.length)};if(Kg(r,a)){let p=t&&r.sliceDoc(a,a+e.length*3)==e+e+e?e+e+e:e;return{changes:{from:a,to:a+p.length,insert:p},range:M.cursor(a+p.length)}}}else{if(t&&r.sliceDoc(a-2*e.length,a)==e+e&&(c=Fg(r,a-2*e.length,s))>-1&&$g(r,c))return{changes:{insert:e+e+e+e,from:a},effects:as.of(a+e.length),range:M.cursor(a+e.length)};if(r.charCategorizer(a)(h)!=be.Word&&Fg(r,a,s)>-1&&!JS(r,a,e,s))return{changes:{insert:e+e,from:a},effects:as.of(a+e.length),range:M.cursor(a+e.length)}}return{range:n=l}});return n?null:r.update(o,{scrollIntoView:!0,userEvent:"input.type"})}function $g(r,e){let t=Be(r).resolveInner(e+1);return t.parent&&t.from==e}function JS(r,e,t,i){let s=Be(r).resolveInner(e,-1),n=i.reduce((o,l)=>Math.max(o,l.length),0);for(let o=0;o<5;o++){let l=r.sliceDoc(s.from,Math.min(s.to,s.from+t.length+n)),a=l.indexOf(t);if(!a||a>-1&&i.indexOf(l.slice(0,a))>-1){let c=s.firstChild;for(;c&&c.from==s.from&&c.to-c.from>t.length+a;){if(r.sliceDoc(c.to-t.length,c.to)==t)return!1;c=c.firstChild}return!0}let h=s.to==e&&s.parent;if(!h)break;s=h}return!1}function Fg(r,e,t){let i=r.charCategorizer(e);if(i(r.sliceDoc(e-1,e))!=be.Word)return e;for(let s of t){let n=e-s.length;if(r.sliceDoc(n,e)==s&&i(r.sliceDoc(n-1,n))!=be.Word)return n}return-1}function Zg(r={}){return[RS,ht,$e.of(r),ES,YS,Hg]}var lf=[{key:"Ctrl-Space",run:Wh},{mac:"Alt-`",run:Wh},{mac:"Alt-i",run:Wh},{key:"Escape",run:TS},{key:"ArrowDown",run:Po(!0)},{key:"ArrowUp",run:Po(!1)},{key:"PageDown",run:Po(!0,"page")},{key:"PageUp",run:Po(!1,"page")},{key:"Enter",run:SS}],YS=vt.highest($s.computeN([$e],r=>r.facet($e).defaultKeymap?[lf]:[]));var e0=new eo,i0=new Set(["Script","Body","FunctionDefinition","ClassDefinition","LambdaExpression","ForStatement","MatchClause"]);function Do(r){return(e,t,i)=>{if(i)return!1;let s=e.node.getChild("VariableName");return s&&t(s,r),!0}}var KS={FunctionDefinition:Do("function"),ClassDefinition:Do("class"),ForStatement(r,e,t){if(t){for(let i=r.node.firstChild;i;i=i.nextSibling)if(i.name=="VariableName")e(i,"variable");else if(i.name=="in")break}},ImportStatement(r,e){var t,i;let{node:s}=r,n=((t=s.firstChild)===null||t===void 0?void 0:t.name)=="from";for(let o=s.getChild("import");o;o=o.nextSibling)o.name=="VariableName"&&((i=o.nextSibling)===null||i===void 0?void 0:i.name)!="as"&&e(o,n?"variable":"namespace")},AssignStatement(r,e){for(let t=r.node.firstChild;t;t=t.nextSibling)if(t.name=="VariableName")e(t,"variable");else if(t.name==":"||t.name=="AssignOp")break},ParamList(r,e){for(let t=null,i=r.node.firstChild;i;i=i.nextSibling)i.name=="VariableName"&&(!t||!/\*|AssignOp/.test(t.name))&&e(i,"variable"),t=i},CapturePattern:Do("variable"),AsPattern:Do("variable"),__proto__:null};function s0(r,e){let t=e0.get(e);if(t)return t;let i=[],s=!0;function n(o,l){let a=r.sliceString(o.from,o.to);i.push({label:a,type:l})}return e.cursor(xe.IncludeAnonymous).iterate(o=>{if(o.name){let l=KS[o.name];if(l&&l(o,n,s)||!s&&i0.has(o.name))return!1;s=!1}else if(o.to-o.from>8192){for(let l of s0(r,o.node))i.push(l);return!1}}),e0.set(e,i),i}var t0=/^[\w\xa1-\uffff][\w\d\xa1-\uffff]*$/,r0=["String","FormatString","Comment","PropertyName"];function ZS(r){let e=Be(r.state).resolveInner(r.pos,-1);if(r0.indexOf(e.name)>-1)return null;let t=e.name=="VariableName"||e.to-e.from<20&&t0.test(r.state.sliceDoc(e.from,e.to));if(!t&&!r.explicit)return null;let i=[];for(let s=e;s;s=s.parent)i0.has(s.name)&&(i=i.concat(s0(r.state.doc,s)));return{options:i,from:t?e.from:r.pos,validFor:t0}}var e2=["__annotations__","__builtins__","__debug__","__doc__","__import__","__name__","__loader__","__package__","__spec__","False","None","True"].map(r=>({label:r,type:"constant"})).concat(["ArithmeticError","AssertionError","AttributeError","BaseException","BlockingIOError","BrokenPipeError","BufferError","BytesWarning","ChildProcessError","ConnectionAbortedError","ConnectionError","ConnectionRefusedError","ConnectionResetError","DeprecationWarning","EOFError","Ellipsis","EncodingWarning","EnvironmentError","Exception","FileExistsError","FileNotFoundError","FloatingPointError","FutureWarning","GeneratorExit","IOError","ImportError","ImportWarning","IndentationError","IndexError","InterruptedError","IsADirectoryError","KeyError","KeyboardInterrupt","LookupError","MemoryError","ModuleNotFoundError","NameError","NotADirectoryError","NotImplemented","NotImplementedError","OSError","OverflowError","PendingDeprecationWarning","PermissionError","ProcessLookupError","RecursionError","ReferenceError","ResourceWarning","RuntimeError","RuntimeWarning","StopAsyncIteration","StopIteration","SyntaxError","SyntaxWarning","SystemError","SystemExit","TabError","TimeoutError","TypeError","UnboundLocalError","UnicodeDecodeError","UnicodeEncodeError","UnicodeError","UnicodeTranslateError","UnicodeWarning","UserWarning","ValueError","Warning","ZeroDivisionError"].map(r=>({label:r,type:"type"}))).concat(["bool","bytearray","bytes","classmethod","complex","float","frozenset","int","list","map","memoryview","object","range","set","staticmethod","str","super","tuple","type"].map(r=>({label:r,type:"class"}))).concat(["abs","aiter","all","anext","any","ascii","bin","breakpoint","callable","chr","compile","delattr","dict","dir","divmod","enumerate","eval","exec","exit","filter","format","getattr","globals","hasattr","hash","help","hex","id","input","isinstance","issubclass","iter","len","license","locals","max","min","next","oct","open","ord","pow","print","property","quit","repr","reversed","round","setattr","slice","sorted","sum","vars","zip"].map(r=>({label:r,type:"function"}))),t2=[At("def ${name}(${params}):\n	${}",{label:"def",detail:"function",type:"keyword"}),At("for ${name} in ${collection}:\n	${}",{label:"for",detail:"loop",type:"keyword"}),At("while ${}:\n	${}",{label:"while",detail:"loop",type:"keyword"}),At("try:\n	${}\nexcept ${error}:\n	${}",{label:"try",detail:"/ except block",type:"keyword"}),At(`if \${}:
	
`,{label:"if",detail:"block",type:"keyword"}),At("if ${}:\n	${}\nelse:\n	${}",{label:"if",detail:"/ else block",type:"keyword"}),At("class ${name}:\n	def __init__(self, ${params}):\n			${}",{label:"class",detail:"definition",type:"keyword"}),At("import ${module}",{label:"import",detail:"statement",type:"keyword"}),At("from ${module} import ${names}",{label:"from",detail:"import",type:"keyword"})],i2=Wg(r0,Zh(e2.concat(t2)));function af(r){let{node:e,pos:t}=r,i=r.lineIndent(t,-1),s=null;for(;;){let n=e.childBefore(t);if(n)if(n.name=="Comment")t=n.from;else if(n.name=="Body"||n.name=="MatchBody")r.baseIndentFor(n)+r.unit<=i&&(s=n),e=n;else if(n.name=="MatchClause")e=n;else if(n.type.is("Statement"))e=n;else break;else break}return s}function hf(r,e){let t=r.baseIndentFor(e),i=r.lineAt(r.pos,-1),s=i.from+i.text.length;return/^\s*($|#)/.test(i.text)&&r.node.to<s+100&&!/\S/.test(r.state.sliceDoc(s,r.node.to))&&r.lineIndent(r.pos,-1)<=t||/^\s*(else:|elif |except |finally:|case\s+[^=:]+:)/.test(r.textAfter)&&r.lineIndent(r.pos,-1)>t?null:t+r.unit}var ff=oo.define({name:"python",parser:Dg.configure({props:[gh.add({Body:r=>{var e;let t=/^\s*(#|$)/.test(r.textAfter)&&af(r)||r.node;return(e=hf(r,t))!==null&&e!==void 0?e:r.continue()},MatchBody:r=>{var e;let t=af(r);return(e=hf(r,t||r.node))!==null&&e!==void 0?e:r.continue()},IfStatement:r=>/^\s*(else:|elif )/.test(r.textAfter)?r.baseIndent:r.continue(),"ForStatement WhileStatement":r=>/^\s*else:/.test(r.textAfter)?r.baseIndent:r.continue(),TryStatement:r=>/^\s*(except[ :]|finally:|else:)/.test(r.textAfter)?r.baseIndent:r.continue(),MatchStatement:r=>/^\s*case /.test(r.textAfter)?r.baseIndent+r.unit:r.continue(),"TupleExpression ComprehensionExpression ParamList ArgList ParenthesizedExpression":ho({closing:")"}),"DictionaryExpression DictionaryComprehensionExpression SetExpression SetComprehensionExpression":ho({closing:"}"}),"ArrayExpression ArrayComprehensionExpression":ho({closing:"]"}),MemberExpression:r=>r.baseIndent+r.unit,"String FormatString":()=>null,Script:r=>{var e;let t=af(r);return(e=t&&hf(r,t))!==null&&e!==void 0?e:r.continue()}}),vm.add({"ArrayExpression DictionaryExpression SetExpression TupleExpression":wm,Body:(r,e)=>({from:r.from+1,to:r.to-(r.to==e.doc.length?0:1)}),"String FormatString":(r,e)=>({from:e.doc.lineAt(r.from).to,to:r.to})})]}),languageData:{closeBrackets:{brackets:["(","[","{","'",'"',"'''",'"""'],stringPrefixes:["f","fr","rf","r","u","b","br","rb","F","FR","RF","R","U","B","BR","RB"]},commentTokens:{line:"#"},indentOnInput:/^\s*([\}\]\)]|else:|elif |except |finally:|case\s+[^:]*:?)$/}});function n0(){return new lo(ff,[ff.data.of({autocomplete:ZS}),ff.data.of({autocomplete:i2})])}var o0=typeof String.prototype.normalize=="function"?r=>r.normalize("NFKD"):r=>r,Ai=class{constructor(e,t,i=0,s=e.length,n,o){this.test=o,this.value={from:0,to:0,precise:!1},this.done=!1,this.matches=[],this.buffer="",this.bufferPos=0,this.iter=e.iterRange(i,s),this.bufferStart=i,this.normalize=n?l=>n(o0(l)):o0,this.query=this.normalize(t)}peek(){if(this.bufferPos==this.buffer.length){if(this.bufferStart+=this.buffer.length,this.iter.next(),this.iter.done)return-1;this.bufferPos=0,this.buffer=this.iter.value}return Ge(this.buffer,this.bufferPos)}next(){for(;this.matches.length;)this.matches.pop();return this.nextOverlapping()}nextOverlapping(){for(;;){let e=this.peek();if(e<0)return this.done=!0,this;let t=fr(e),i=this.bufferStart+this.bufferPos;this.bufferPos+=ct(e);let s=this.normalize(t);if(s.length)for(let n=0,o=i,l=!0;;n++){let a=s.charCodeAt(n),h=this.match(a,o,l,this.bufferPos+this.bufferStart,n==s.length-1);if(h)return this.value=h,this;if(n==s.length-1)break;l&&n<t.length&&t.charCodeAt(n)==a?o++:l=!1}}}match(e,t,i,s,n){let o=null;for(let l=0;l<this.matches.length;){let a=this.matches[l],h=!1;this.query.charCodeAt(a.index)==e&&(a.index==this.query.length-1?o={from:a.from,to:s,precise:n&&a.precise}:(a.index++,h=!0)),h?l++:this.matches.splice(l,1)}return this.query.charCodeAt(0)==e&&(this.query.length==1?o={from:t,to:s,precise:i&&n}:this.matches.push({from:t,index:1,precise:i})),o&&this.test&&!this.test(o.from,o.to,this.buffer,this.bufferStart)&&(o=null),o}};typeof Symbol<"u"&&(Ai.prototype[Symbol.iterator]=function(){return this});var h0={from:-1,to:-1,match:/.*/.exec(""),precise:!0},gf="gm"+(/x/.unicode==null?"":"u"),Lo=class{constructor(e,t,i,s=0,n=e.length){if(this.text=e,this.to=n,this.curLine="",this.done=!1,this.value=h0,/\\[sWDnr]|\n|\r|\[\^/.test(t))return new qo(e,t,i,s,n);this.re=new RegExp(t,gf+(i!=null&&i.ignoreCase?"i":"")),this.test=i==null?void 0:i.test,this.iter=e.iter();let o=e.lineAt(s);this.curLineStart=o.from,this.matchPos=Bo(e,s),this.getLine(this.curLineStart)}getLine(e){this.iter.next(e),this.iter.lineBreak?this.curLine="":(this.curLine=this.iter.value,this.curLineStart+this.curLine.length>this.to&&(this.curLine=this.curLine.slice(0,this.to-this.curLineStart)),this.iter.next())}nextLine(){this.curLineStart=this.curLineStart+this.curLine.length+1,this.curLineStart>this.to?this.curLine="":this.getLine(0)}next(){for(let e=this.matchPos-this.curLineStart;;){this.re.lastIndex=e;let t=this.matchPos<=this.to&&this.re.exec(this.curLine);if(t){let i=this.curLineStart+t.index,s=i+t[0].length;if(this.matchPos=Bo(this.text,s+(i==s?1:0)),i==this.curLineStart+this.curLine.length&&this.nextLine(),(i<s||i>this.value.to)&&(!this.test||this.test(i,s,t)))return this.value={from:i,to:s,precise:!0,match:t},this;e=this.matchPos-this.curLineStart}else if(this.curLineStart+this.curLine.length<this.to)this.nextLine(),e=0;else return this.done=!0,this}}},cf=new WeakMap,Qo=class r{constructor(e,t){this.from=e,this.text=t}get to(){return this.from+this.text.length}static get(e,t,i){let s=cf.get(e);if(!s||s.from>=i||s.to<=t){let l=new r(t,e.sliceString(t,i));return cf.set(e,l),l}if(s.from==t&&s.to==i)return s;let{text:n,from:o}=s;return o>t&&(n=e.sliceString(t,o)+n,o=t),s.to<i&&(n+=e.sliceString(s.to,i)),cf.set(e,new r(o,n)),new r(t,n.slice(t-o,i-o))}},qo=class{constructor(e,t,i,s,n){this.text=e,this.to=n,this.done=!1,this.value=h0,this.matchPos=Bo(e,s),this.re=new RegExp(t,gf+(i!=null&&i.ignoreCase?"i":"")),this.test=i==null?void 0:i.test,this.flat=Qo.get(e,s,this.chunkEnd(s+5e3))}chunkEnd(e){return e>=this.to?this.to:this.text.lineAt(e).to}next(){for(;;){let e=this.re.lastIndex=this.matchPos-this.flat.from,t=this.re.exec(this.flat.text);if(t&&!t[0]&&t.index==e&&(this.re.lastIndex=e+1,t=this.re.exec(this.flat.text)),t){let i=this.flat.from+t.index,s=i+t[0].length;if((this.flat.to>=this.to||t.index+t[0].length<=this.flat.text.length-10)&&(!this.test||this.test(i,s,t)))return this.value={from:i,to:s,precise:!0,match:t},this.matchPos=Bo(this.text,s+(i==s?1:0)),this}if(this.flat.to==this.to)return this.done=!0,this;this.flat=Qo.get(this.text,this.flat.from,this.chunkEnd(this.flat.from+this.flat.text.length*2))}}};typeof Symbol<"u"&&(Lo.prototype[Symbol.iterator]=qo.prototype[Symbol.iterator]=function(){return this});function s2(r){try{return new RegExp(r,gf),!0}catch{return!1}}function Bo(r,e){if(e>=r.length)return e;let t=r.lineAt(e),i;for(;e<t.to&&(i=t.text.charCodeAt(e-t.from))>=56320&&i<57344;)e++;return e}var r2=r=>{let e=Yp(r,"cm-goto-line");if(e){let o=e.dom.querySelector("input[type=text]");return o&&o.select(),!0}let{state:t}=r,i=String(t.doc.lineAt(r.state.selection.main.head).number),{close:s,result:n}=Jp(r,{class:"cm-goto-line",label:t.phrase("Go to line"),input:{type:"text",name:"line",value:i},focus:!0,submitLabel:t.phrase("go")});return n.then(o=>{let l=o&&/^([+-])?(\d+)?(:\d+)?(%)?$/.exec(o.elements.line.value);if(!l){r.dispatch({effects:s});return}let a=t.doc.lineAt(t.selection.main.head),[,h,c,u,p]=l,y=u?+u.slice(1):0,O=c?+c:a.number;if(c&&p){let k=O/100;h&&(k=k*(h=="-"?-1:1)+a.number/t.doc.lines),O=Math.round(t.doc.lines*k)}else c&&h&&(O=O*(h=="-"?-1:1)+a.number);let b=t.doc.line(Math.max(1,Math.min(t.doc.lines,O))),v=M.cursor(b.from+Math.max(0,Math.min(y,b.length)));r.dispatch({effects:[s,z.scrollIntoView(v.from,{y:"center"})],selection:v})}),!0},n2={highlightWordAroundCursor:!1,minSelectionLength:1,maxMatches:100,wholeWords:!1},f0=W.define({combine(r){return wt(r,n2,{highlightWordAroundCursor:(e,t)=>e||t,minSelectionLength:Math.min,maxMatches:Math.min})}});function c0(r){let e=[f2,h2];return r&&e.push(f0.of(r)),e}var o2=K.mark({class:"cm-selectionMatch"}),l2=K.mark({class:"cm-selectionMatch cm-selectionMatch-main"});function l0(r,e,t,i){return(t==0||r(e.sliceDoc(t-1,t))!=be.Word)&&(i==e.doc.length||r(e.sliceDoc(i,i+1))!=be.Word)}function a2(r,e,t,i){return r(e.sliceDoc(t,t+1))==be.Word&&r(e.sliceDoc(i-1,i))==be.Word}var h2=qe.fromClass(class{constructor(r){this.decorations=this.getDeco(r)}update(r){(r.selectionSet||r.docChanged||r.viewportChanged)&&(this.decorations=this.getDeco(r.view))}getDeco(r){let e=r.state.facet(f0),{state:t}=r,i=t.selection;if(i.ranges.length>1)return K.none;let s=i.main,n,o=null;if(s.empty){if(!e.highlightWordAroundCursor)return K.none;let a=t.wordAt(s.head);if(!a)return K.none;o=t.charCategorizer(s.head),n=t.sliceDoc(a.from,a.to)}else{let a=s.to-s.from;if(a<e.minSelectionLength||a>200)return K.none;if(e.wholeWords){if(n=t.sliceDoc(s.from,s.to),o=t.charCategorizer(s.head),!(l0(o,t,s.from,s.to)&&a2(o,t,s.from,s.to)))return K.none}else if(n=t.sliceDoc(s.from,s.to),!n)return K.none}let l=[];for(let a of r.visibleRanges){let h=new Ai(t.doc,n,a.from,a.to);for(;!h.next().done;){let{from:c,to:u}=h.value;if((!o||l0(o,t,c,u))&&(s.empty&&c<=s.from&&u>=s.to?l.push(l2.range(c,u)):(c>=s.to||u<=s.from)&&l.push(o2.range(c,u)),l.length>e.maxMatches))return K.none}}return K.set(l)}},{decorations:r=>r.decorations}),f2=z.baseTheme({".cm-selectionMatch":{backgroundColor:"#99ff7780"},".cm-searchMatch .cm-selectionMatch":{backgroundColor:"transparent"}}),c2=({state:r,dispatch:e})=>{let{selection:t}=r,i=M.create(t.ranges.map(s=>r.wordAt(s.head)||M.cursor(s.head)),t.mainIndex);return i.eq(t)?!1:(e(r.update({selection:i})),!0)};function d2(r,e){let{main:t,ranges:i}=r.selection,s=r.wordAt(t.head),n=s&&s.from==t.from&&s.to==t.to;for(let o=!1,l=new Ai(r.doc,e,i[i.length-1].to);;)if(l.next(),l.done){if(o)return null;l=new Ai(r.doc,e,0,Math.max(0,i[i.length-1].from-1)),o=!0}else{if(o&&i.some(a=>a.from==l.value.from))continue;if(n){let a=r.wordAt(l.value.from);if(!a||a.from!=l.value.from||a.to!=l.value.to)continue}return l.value}}var u2=({state:r,dispatch:e})=>{let{ranges:t}=r.selection;if(t.some(n=>n.from===n.to))return c2({state:r,dispatch:e});let i=r.sliceDoc(t[0].from,t[0].to);if(r.selection.ranges.some(n=>r.sliceDoc(n.from,n.to)!=i))return!1;let s=d2(r,i);return s?(e(r.update({selection:r.selection.addRange(M.range(s.from,s.to),!1),effects:z.scrollIntoView(s.to)})),!0):!1},Ks=W.define({combine(r){return wt(r,{top:!1,caseSensitive:!1,literal:!1,regexp:!1,wholeWord:!1,createPanel:e=>new mf(e),scrollToMatch:e=>z.scrollIntoView(e)})}});var $o=class{constructor(e){this.search=e.search,this.caseSensitive=!!e.caseSensitive,this.literal=!!e.literal,this.regexp=!!e.regexp,this.replace=e.replace||"",this.valid=!!this.search&&(!this.regexp||s2(this.search)),this.unquoted=this.unquote(this.search),this.wholeWord=!!e.wholeWord,this.test=e.test}unquote(e){return this.literal?e:e.replace(/\\([nrt\\])/g,(t,i)=>i=="n"?`
`:i=="r"?"\r":i=="t"?"	":"\\")}eq(e){return this.search==e.search&&this.replace==e.replace&&this.caseSensitive==e.caseSensitive&&this.regexp==e.regexp&&this.wholeWord==e.wholeWord&&this.test==e.test}create(){return this.regexp?new uf(this):new df(this)}getCursor(e,t=0,i){let s=e.doc?e:pe.create({doc:e});return i==null&&(i=s.doc.length),this.regexp?Ys(this,s,t,i):Js(this,s,t,i)}},Fo=class{constructor(e){this.spec=e}};function p2(r,e,t){return(i,s,n,o)=>{if(t&&!t(i,s,n,o))return!1;let l=i>=o&&s<=o+n.length?n.slice(i-o,s-o):e.doc.sliceString(i,s);return r(l,e,i,s)}}function Js(r,e,t,i){let s;return r.wholeWord&&(s=m2(e.doc,e.charCategorizer(e.selection.main.head))),r.test&&(s=p2(r.test,e,s)),new Ai(e.doc,r.unquoted,t,i,r.caseSensitive?void 0:n=>n.toLowerCase(),s)}function m2(r,e){return(t,i,s,n)=>((n>t||n+s.length<i)&&(n=Math.max(0,t-2),s=r.sliceString(n,Math.min(r.length,i+2))),(e(Wo(s,t-n))!=be.Word||e(zo(s,t-n))!=be.Word)&&(e(zo(s,i-n))!=be.Word||e(Wo(s,i-n))!=be.Word))}var df=class extends Fo{constructor(e){super(e)}nextMatch(e,t,i){let s=Js(this.spec,e,i,e.doc.length).nextOverlapping();if(s.done){let n=Math.min(e.doc.length,t+this.spec.unquoted.length);s=Js(this.spec,e,0,n).nextOverlapping()}return s.done||s.value.from==t&&s.value.to==i?null:s.value}prevMatchInRange(e,t,i){for(let s=i;;){let n=Math.max(t,s-1e4-this.spec.unquoted.length),o=Js(this.spec,e,n,s),l=null;for(;!o.nextOverlapping().done;)l=o.value;if(l)return l;if(n==t)return null;s-=1e4}}prevMatch(e,t,i){let s=this.prevMatchInRange(e,0,t);return s||(s=this.prevMatchInRange(e,Math.max(0,i-this.spec.unquoted.length),e.doc.length)),s&&(s.from!=t||s.to!=i)?s:null}getReplacement(e){return this.spec.unquote(this.spec.replace)}matchAll(e,t){let i=Js(this.spec,e,0,e.doc.length),s=[];for(;!i.next().done;){if(s.length>=t)return null;s.push(i.value)}return s}highlight(e,t,i,s){let n=Js(this.spec,e,Math.max(0,t-this.spec.unquoted.length),Math.min(i+this.spec.unquoted.length,e.doc.length));for(;!n.next().done;)s(n.value.from,n.value.to)}};function g2(r,e,t){return(i,s,n)=>(!t||t(i,s,n))&&r(n[0],e,i,s)}function Ys(r,e,t,i){let s;return r.wholeWord&&(s=_2(e.charCategorizer(e.selection.main.head))),r.test&&(s=g2(r.test,e,s)),new Lo(e.doc,r.search,{ignoreCase:!r.caseSensitive,test:s},t,i)}function Wo(r,e){return r.slice(Ce(r,e,!1),e)}function zo(r,e){return r.slice(e,Ce(r,e))}function _2(r){return(e,t,i)=>!i[0].length||(r(Wo(i.input,i.index))!=be.Word||r(zo(i.input,i.index))!=be.Word)&&(r(zo(i.input,i.index+i[0].length))!=be.Word||r(Wo(i.input,i.index+i[0].length))!=be.Word)}var uf=class extends Fo{nextMatch(e,t,i){let s=Ys(this.spec,e,i,e.doc.length).next();return s.done&&(s=Ys(this.spec,e,0,t).next()),s.done?null:s.value}prevMatchInRange(e,t,i){for(let s=1;;s++){let n=Math.max(t,i-s*1e4),o=Ys(this.spec,e,n,i),l=null;for(;!o.next().done;)l=o.value;if(l&&(n==t||l.from>n+10))return l;if(n==t)return null}}prevMatch(e,t,i){return this.prevMatchInRange(e,0,t)||this.prevMatchInRange(e,i,e.doc.length)}getReplacement(e){return this.spec.unquote(this.spec.replace).replace(/\$([$&]|\d+)/g,(t,i)=>{if(i=="&")return e.match[0];if(i=="$")return"$";for(let s=i.length;s>0;s--){let n=+i.slice(0,s);if(n>0&&n<e.match.length)return e.match[n]+i.slice(s)}return t})}matchAll(e,t){let i=Ys(this.spec,e,0,e.doc.length),s=[];for(;!i.next().done;){if(s.length>=t)return null;s.push(i.value)}return s}highlight(e,t,i,s){let n=Ys(this.spec,e,Math.max(0,t-250),Math.min(i+250,e.doc.length));for(;!n.next().done;)s(n.value.from,n.value.to)}},Hr=re.define(),_f=re.define(),Ei=Qe.define({create(r){return new jr(pf(r).create(),null)},update(r,e){for(let t of e.effects)t.is(Hr)?r=new jr(t.value.create(),r.panel):t.is(_f)&&(r=new jr(r.query,t.value?yf:null));return r},provide:r=>Sr.from(r,e=>e.panel)});var jr=class{constructor(e,t){this.query=e,this.panel=t}},y2=K.mark({class:"cm-searchMatch"}),b2=K.mark({class:"cm-searchMatch cm-searchMatch-selected"}),O2=qe.fromClass(class{constructor(r){this.view=r,this.decorations=this.highlight(r.state.field(Ei))}update(r){let e=r.state.field(Ei);(e!=r.startState.field(Ei)||r.docChanged||r.selectionSet||r.viewportChanged)&&(this.decorations=this.highlight(e))}highlight({query:r,panel:e}){if(!e||!r.spec.valid)return K.none;let{view:t}=this,i=new Gt;for(let s=0,n=t.visibleRanges,o=n.length;s<o;s++){let{from:l,to:a}=n[s];for(;s<o-1&&a>n[s+1].from-2*250;)a=n[++s].to;r.highlight(t.state,l,a,(h,c)=>{let u=t.state.selection.ranges.some(p=>p.from==h&&p.to==c);i.add(h,c,u?b2:y2)})}return i.finish()}},{decorations:r=>r.decorations});function Vr(r){return e=>{let t=e.state.field(Ei,!1);return t&&t.query.spec.valid?r(e,t):Vo(e)}}var jo=Vr((r,{query:e})=>{let{to:t}=r.state.selection.main,i=e.nextMatch(r.state,t,t);if(!i)return!1;let s=M.single(i.from,i.to),n=r.state.facet(Ks);return r.dispatch({selection:s,effects:[bf(r,i),n.scrollToMatch(s.main,r)],userEvent:"select.search"}),u0(r),!0}),Ho=Vr((r,{query:e})=>{let{state:t}=r,{from:i}=t.selection.main,s=e.prevMatch(t,i,i);if(!s)return!1;let n=M.single(s.from,s.to),o=r.state.facet(Ks);return r.dispatch({selection:n,effects:[bf(r,s),o.scrollToMatch(n.main,r)],userEvent:"select.search"}),u0(r),!0}),v2=Vr((r,{query:e})=>{let t=e.matchAll(r.state,1e3);return!t||!t.length?!1:(r.dispatch({selection:M.create(t.map(i=>M.range(i.from,i.to))),userEvent:"select.search.matches"}),!0)}),w2=({state:r,dispatch:e})=>{let t=r.selection;if(t.ranges.length>1||t.main.empty)return!1;let{from:i,to:s}=t.main,n=[],o=0;for(let l=new Ai(r.doc,r.sliceDoc(i,s));!l.next().done;){if(n.length>1e3)return!1;l.value.from==i&&(o=n.length),n.push(M.range(l.value.from,l.value.to))}return e(r.update({selection:M.create(n,o),userEvent:"select.search.matches"})),!0},a0=Vr((r,{query:e})=>{let{state:t}=r,{from:i,to:s}=t.selection.main;if(t.readOnly)return!1;let n=e.nextMatch(t,i,i);if(!n)return!1;let o=n,l=[],a,h,c=[];o.precise?o.from==i&&o.to==s&&(h=t.toText(e.getReplacement(o)),l.push({from:o.from,to:o.to,insert:h}),o=e.nextMatch(t,o.from,o.to),c.push(z.announce.of(t.phrase("replaced match on line $",t.doc.lineAt(i).number)+"."))):o=e.nextMatch(t,o.from,o.to);let u=r.state.changes(l);return o&&(a=M.single(o.from,o.to).map(u),c.push(bf(r,o)),c.push(t.facet(Ks).scrollToMatch(a.main,r))),r.dispatch({changes:u,selection:a,effects:c,userEvent:"input.replace"}),!0}),k2=Vr((r,{query:e})=>{if(r.state.readOnly)return!1;let t=[];for(let s of e.matchAll(r.state,1e9)){let{from:n,to:o,precise:l}=s;l&&t.push({from:n,to:o,insert:e.getReplacement(s)})}if(!t.length)return!1;let i=r.state.phrase("replaced $ matches",t.length)+".";return r.dispatch({changes:t,effects:z.announce.of(i),userEvent:"input.replace.all"}),!0});function yf(r){return r.state.facet(Ks).createPanel(r)}function pf(r,e){var t,i,s,n,o;let l=r.selection.main,a=l.empty||l.to>l.from+100?"":r.sliceDoc(l.from,l.to);if(e&&!a)return e;let h=r.facet(Ks);return new $o({search:((t=e==null?void 0:e.literal)!==null&&t!==void 0?t:h.literal)?a:a.replace(/\n/g,"\\n"),caseSensitive:(i=e==null?void 0:e.caseSensitive)!==null&&i!==void 0?i:h.caseSensitive,literal:(s=e==null?void 0:e.literal)!==null&&s!==void 0?s:h.literal,regexp:(n=e==null?void 0:e.regexp)!==null&&n!==void 0?n:h.regexp,wholeWord:(o=e==null?void 0:e.wholeWord)!==null&&o!==void 0?o:h.wholeWord})}function d0(r){let e=Jn(r,yf);return e&&e.dom.querySelector("[main-field]")}function u0(r){let e=d0(r);e&&e==r.root.activeElement&&e.select()}var Vo=r=>{let e=r.state.field(Ei,!1);if(e&&e.panel){let t=d0(r);if(t&&t!=r.root.activeElement){let i=pf(r.state,e.query.spec);i.valid&&r.dispatch({effects:Hr.of(i)}),t.focus(),t.select()}}else r.dispatch({effects:[_f.of(!0),e?Hr.of(pf(r.state,e.query.spec)):re.appendConfig.of(S2)]});return!0},p0=r=>{let e=r.state.field(Ei,!1);if(!e||!e.panel)return!1;let t=Jn(r,yf);return t&&t.dom.contains(r.root.activeElement)&&r.focus(),r.dispatch({effects:_f.of(!1)}),!0},m0=[{key:"Mod-f",run:Vo,scope:"editor search-panel"},{key:"F3",run:jo,shift:Ho,scope:"editor search-panel",preventDefault:!0},{key:"Mod-g",run:jo,shift:Ho,scope:"editor search-panel",preventDefault:!0},{key:"Escape",run:p0,scope:"editor search-panel"},{key:"Mod-Shift-l",run:w2},{key:"Mod-Alt-g",run:r2},{key:"Mod-d",run:u2,preventDefault:!0}],mf=class{constructor(e){this.view=e;let t=this.query=e.state.field(Ei).query.spec;this.commit=this.commit.bind(this),this.searchField=Ee("input",{value:t.search,placeholder:mt(e,"Find"),"aria-label":mt(e,"Find"),class:"cm-textfield",name:"search",form:"","main-field":"true",onchange:this.commit,onkeyup:this.commit}),this.replaceField=Ee("input",{value:t.replace,placeholder:mt(e,"Replace"),"aria-label":mt(e,"Replace"),class:"cm-textfield",name:"replace",form:"",onchange:this.commit,onkeyup:this.commit}),this.caseField=Ee("input",{type:"checkbox",name:"case",form:"",checked:t.caseSensitive,onchange:this.commit}),this.reField=Ee("input",{type:"checkbox",name:"re",form:"",checked:t.regexp,onchange:this.commit}),this.wordField=Ee("input",{type:"checkbox",name:"word",form:"",checked:t.wholeWord,onchange:this.commit});function i(s,n,o){return Ee("button",{class:"cm-button",name:s,onclick:n,type:"button"},o)}this.dom=Ee("div",{onkeydown:s=>this.keydown(s),class:"cm-search"},[this.searchField,i("next",()=>jo(e),[mt(e,"next")]),i("prev",()=>Ho(e),[mt(e,"previous")]),i("select",()=>v2(e),[mt(e,"all")]),Ee("label",null,[this.caseField,mt(e,"match case")]),Ee("label",null,[this.reField,mt(e,"regexp")]),Ee("label",null,[this.wordField,mt(e,"by word")]),...e.state.readOnly?[]:[Ee("br"),this.replaceField,i("replace",()=>a0(e),[mt(e,"replace")]),i("replaceAll",()=>k2(e),[mt(e,"replace all")])],Ee("button",{name:"close",onclick:()=>p0(e),"aria-label":mt(e,"close"),type:"button"},["\xD7"])])}commit(){let e=new $o({search:this.searchField.value,caseSensitive:this.caseField.checked,regexp:this.reField.checked,wholeWord:this.wordField.checked,replace:this.replaceField.value});e.eq(this.query)||(this.query=e,this.view.dispatch({effects:Hr.of(e)}))}keydown(e){Fp(this.view,e,"search-panel")?e.preventDefault():e.keyCode==13&&e.target==this.searchField?(e.preventDefault(),(e.shiftKey?Ho:jo)(this.view)):e.keyCode==13&&e.target==this.replaceField&&(e.preventDefault(),a0(this.view))}update(e){for(let t of e.transactions)for(let i of t.effects)i.is(Hr)&&!i.value.eq(this.query)&&this.setQuery(i.value)}setQuery(e){this.query=e,this.searchField.value=e.search,this.replaceField.value=e.replace,this.caseField.checked=e.caseSensitive,this.reField.checked=e.regexp,this.wordField.checked=e.wholeWord}mount(){this.searchField.select()}get pos(){return 80}get top(){return this.view.state.facet(Ks).top}};function mt(r,e){return r.state.phrase(e)}var No=30,Io=/[\s\.,:;?!]/;function bf(r,{from:e,to:t}){let i=r.state.doc.lineAt(e),s=r.state.doc.lineAt(t).to,n=Math.max(i.from,e-No),o=Math.min(s,t+No),l=r.state.sliceDoc(n,o);if(n!=i.from){for(let a=0;a<No;a++)if(!Io.test(l[a+1])&&Io.test(l[a])){l=l.slice(a);break}}if(o!=s){for(let a=l.length-1;a>l.length-No;a--)if(!Io.test(l[a-1])&&Io.test(l[a])){l=l.slice(0,a);break}}return z.announce.of(`${r.state.phrase("current match")}. ${l} ${r.state.phrase("on line")} ${i.number}.`)}var x2=z.baseTheme({".cm-panel.cm-search":{padding:"2px 6px 4px",position:"relative","& [name=close]":{position:"absolute",top:"0",right:"4px",backgroundColor:"inherit",border:"none",font:"inherit",padding:0,margin:0},"& input, & button, & label":{margin:".2em .6em .2em 0"},"& input[type=checkbox]":{marginRight:".2em"},"& label":{fontSize:"80%",whiteSpace:"pre"}},"&light .cm-searchMatch":{backgroundColor:"#ffff0054"},"&dark .cm-searchMatch":{backgroundColor:"#00ffff8a"},"&light .cm-searchMatch-selected":{backgroundColor:"#ff6a0054"},"&dark .cm-searchMatch-selected":{backgroundColor:"#ff00ff8a"}}),S2=[Ei,vt.low(O2),x2];var Ur=se(ii(),1),Gr=se(Qi(),1),T2=z.theme({"&":{color:"#e6edf7",backgroundColor:"transparent",height:"100%",fontSize:"var(--code-size, 14px)"},".cm-scroller":{fontFamily:'"JetBrains Mono", "Fira Code", monospace',lineHeight:"1.55",overflow:"auto"},".cm-content":{caretColor:"#22d3ee",padding:"10px 0 30vh"},".cm-cursor, .cm-dropCursor":{borderLeftColor:"#22d3ee",borderLeftWidth:"2px"},"&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection":{backgroundColor:"rgba(34,211,238,.25) !important"},".cm-gutters":{backgroundColor:"rgba(8,13,28,.85)",color:"#4b5b7a",border:"none",borderRight:"1px solid rgba(148,163,184,.08)"},".cm-activeLineGutter":{backgroundColor:"rgba(34,211,238,.08)",color:"#9fb4d8"},".cm-activeLine":{backgroundColor:"rgba(148,163,184,.06)"},".cm-matchingBracket":{backgroundColor:"rgba(34,211,238,.22)",outline:"1px solid rgba(34,211,238,.45)"},".cm-tooltip":{backgroundColor:"#111a30",color:"#e6edf7",border:"1px solid rgba(148,163,184,.18)",borderRadius:"12px",overflow:"hidden"},".cm-tooltip-autocomplete > ul > li":{padding:"6px 10px !important"},".cm-tooltip-autocomplete > ul > li[aria-selected]":{backgroundColor:"rgba(34,211,238,.18)",color:"#fff"},".cm-completionDetail":{color:"#7c8db0",fontStyle:"normal",marginLeft:"8px"},".cm-panels":{backgroundColor:"#0d1528",color:"#e6edf7"},".cm-searchMatch":{backgroundColor:"rgba(245,158,11,.3)"},".cm-err-line":{backgroundColor:"rgba(239,68,68,.16)"}},{dark:!0}),P2=js.define([{tag:[E.keyword,E.controlKeyword,E.definitionKeyword,E.moduleKeyword,E.operatorKeyword],color:"#c792ea"},{tag:[E.bool,E.null,E.self],color:"#f78c6c"},{tag:[E.string,E.special(E.string)],color:"#c3e88d"},{tag:E.comment,color:"#5c6f94",fontStyle:"italic"},{tag:E.number,color:"#f78c6c"},{tag:[E.function(E.definition(E.variableName)),E.definition(E.className)],color:"#ffb86c",fontWeight:"600"},{tag:E.function(E.variableName),color:"#ffb86c"},{tag:E.className,color:"#ffcb6b"},{tag:E.propertyName,color:"#82aaff"},{tag:E.meta,color:"#ff79c6"},{tag:E.operator,color:"#89ddff"}]),C2={module:["gpiozero","RPi.GPIO","time","machine","utime","random","math","neopixel","dht","network","rp2","board","adafruit_dht","signal","os","sys","json","collections","datetime"],class:["LED","PWMLED","Button","Buzzer","TonalBuzzer","RGBLED","Motor","Robot","Servo","AngularServo","DistanceSensor","MotionSensor","LightSensor","LineSensor","MCP3008","TrafficLights","LEDBoard","LEDBarGraph","OutputDevice","DigitalInputDevice","CPUTemperature","Pin","PWM","ADC","Timer","I2C","SPI","UART","RTC","WDT","NeoPixel","DHT11","DHT22","WLAN","Signal"],function:["print","input","range","len","int","float","str","list","dict","tuple","set","abs","min","max","sum","round","sorted","enumerate","zip","isinstance","open","help","dir","type","sleep","sleep_ms","sleep_us","ticks_ms","ticks_us","ticks_diff","pause","setmode","setup","output","cleanup","setwarnings","add_event_detect","wait_for_edge","event_detected","on","off","toggle","blink","pulse","value","when_pressed","when_released","when_held","when_motion","wait_for_press","wait_for_release","is_pressed","distance","forward","backward","stop","freq","duty_u16","read_u16","irq","init","deinit","write","scan","measure","temperature","humidity","connect","isconnected","ifconfig"],constant:["BCM","BOARD","OUT","IN","HIGH","LOW","PUD_UP","PUD_DOWN","RISING","FALLING","BOTH","IRQ_RISING","IRQ_FALLING","PULL_UP","PULL_DOWN","OUT","True","False","None"]},E2=[["while True","while True:\n    ${}","loop forever"],["for in range","for ${i} in range(${10}):\n    ${}","counted loop"],["def","def ${name}(${}):\n    ${pass}","function"],["if","if ${cond}:\n    ${}","if block"],["try except",`try:
    \${}
except KeyboardInterrupt:
    \${pass}`,"stop with Ctrl+C"],["from gpiozero import","from gpiozero import ${LED}","gpiozero"],["import RPi.GPIO as GPIO","import RPi.GPIO as GPIO","RPi.GPIO"],["from machine import Pin","from machine import Pin","Pico"]];function A2(r){let e=r.matchBefore(/[\w.]*/);if(!e||e.from===e.to&&!r.explicit)return null;let t=[];for(let[s,n,o]of E2)t.push(At(n,{label:s,detail:o,type:"keyword",boost:1}));for(let[s,n]of Object.entries(C2))for(let o of n)t.push({label:o,type:s==="module"?"namespace":s});for(let s of["import","from","def","class","return","while","for","in","if","elif","else","try","except","finally","with","as","pass","break","continue","lambda","global","nonlocal","and","or","not","is","yield","async","await","raise","assert","del"])t.push({label:s,type:"keyword"});let i=new Set(t.map(s=>s.label));for(let s of r.state.doc.toString().matchAll(/\b[A-Za-z_]\w{2,}\b/g))i.has(s[0])||(i.add(s[0]),t.push({label:s[0],type:"variable"}));return{from:e.from+(e.text.lastIndexOf(".")+1),options:t,validFor:/^\w*$/}}var Uo=class{constructor(e,{code:t="",onChange:i,fontSize:s=14}={}){this.onChange=i,this.ro=new Ss,this.wrap=(0,Ur.h)("div",{class:"code-wrap py-wrap"}),this.cmHost=(0,Ur.h)("div",{class:"code-cm py-cm"}),this.wrap.append(this.cmHost,this.symbolBar()),e.appendChild(this.wrap),this.setFontSize(s),this.view=new z({parent:this.cmHost,state:this.makeState(t)})}makeState(e){return pe.create({doc:e,extensions:[em(),tm(),$m(),Hp(),Om(),Cm(),Gg(),Zg({override:[A2],icons:!1}),Up(),c0(),Ti.of("    "),pe.tabSize.of(4),$s.of([...Yg,...ug,...m0,...zm,...lf,pg,{key:"Mod-/",run:vh}]),n0(),xm(P2),T2,z.lineWrapping,this.ro.of(pe.readOnly.of(!1)),z.updateListener.of(t=>{t.docChanged&&this.onChange&&!this.silent&&this.onChange(t.state.doc.toString())}),z.domEventHandlers({focus:()=>this.wrap.classList.add("focused"),blur:()=>setTimeout(()=>{this.view.hasFocus||this.wrap.classList.remove("focused")},150)})]})}symbolBar(){let e=(0,Ur.h)("div",{class:"symbol-bar"}),t=n=>n.preventDefault(),i=n=>()=>{this.view.dispatch(this.view.state.replaceSelection(n)),this.view.focus()},s=(n,o,l="")=>{let a=(0,Ur.h)("button",{class:"sym "+l,onclick:o});return n.startsWith("<svg")?a.innerHTML=n:a.textContent=n,a.addEventListener("pointerdown",t),a.addEventListener("mousedown",t),a};return e.append(s("\u21E5",()=>{bo(this.view),this.view.focus()}),s("\u21E4",()=>{Oo(this.view),this.view.focus()}),s((0,Gr.icon)("arrowLeft",18),()=>{mo(this.view),this.view.focus()},"sym-icon"),s((0,Gr.icon)("forward",18),()=>{go(this.view),this.view.focus()},"sym-icon"),...[":","(",")",'"',"'","=","[","]","_",".",",","#","+","-","*","/","<",">","{","}"].map(n=>s(n,i(n))),s((0,Gr.icon)("undo",18),()=>{Lr(this.view),this.view.focus()},"sym-icon"),s((0,Gr.icon)("redo",18),()=>{Vs(this.view),this.view.focus()},"sym-icon")),e}get value(){return this.view.state.doc.toString()}load(e){this.silent=!0,this.view.setState(this.makeState(e)),this.silent=!1}setFontSize(e){this.wrap.style.setProperty("--code-size",e+"px"),this.fontSize=e}setReadOnly(e){this.view.dispatch({effects:this.ro.reconfigure(pe.readOnly.of(e))})}focus(){this.view.focus()}search(){Vo(this.view)}undo(){Lr(this.view)}redo(){Vs(this.view)}gotoLine(e){if(!(e>0&&e<=this.view.state.doc.lines))return;let t=this.view.state.doc.line(e);this.view.dispatch({selection:{anchor:t.from,head:t.to},scrollIntoView:!0})}refresh(){this.view.requestMeasure()}};var st=se(ii(),1);var cs=se($i(),1),Of="pi",fs="raspberrypi",Go=["apt","apt-get","basename","cal","cat","cd","chmod","clear","cp","date","df","dirname","echo","env","exit","export","false","fastfetch","find","free","grep","head","help","history","hostname","i2cdetect","id","ifconfig","ip","kill","logout","ls","lsb_release","lscpu","man","mkdir","mv","nano","neofetch","pinctrl","pinout","ping","pip","pip3","poweroff","ps","pwd","python","python3","raspi-config","raspi-gpio","reboot","rm","rmdir","rpicam-hello","shutdown","sleep","sudo","tail","thonny","top","touch","tree","true","uname","uptime","vcgencmd","vi","vim","wc","whoami","which","xdg-open","curl","wget","nslookup","iwgetid","nmcli","chromium-browser","chromium","mosquitto_pub","mosquitto_sub","systemctl"],Xo=class{constructor(e){this.ctx=e,this.sys=e.sys,this.cwd="/home/pi",this.prevCwd=this.cwd,this.env={HOME:"/home/pi",USER:Of,SHELL:"/bin/bash",PATH:"/home/pi/.local/bin:/usr/local/bin:/usr/bin:/bin",LANG:"en_GB.UTF-8",TERM:"xterm-256color"},this.status=0,this.hist=[],this.con=new bs({cls:"term",onKey:t=>this.key(t),extraKeys:[["Ctrl+C",()=>this.ctrlC()],["Tab",()=>this.complete()],["\u2191",t=>t.histMove(-1)],["\u2193",t=>t.histMove(1)],["Ctrl+D",()=>this.ctrlD()],["Ctrl+L",()=>{this.con.clear()}],["|",t=>t.insert("|")],["/",t=>t.insert("/")],["-",t=>t.insert("-")],["~",t=>t.insert("~")],['"',t=>t.insert('"')]]}),this.el=(0,st.h)("div",{class:"term-app"},this.con.el),this.alive=!0,this.banner(),this.loop()}get fs(){return this.sys.piFs}banner(){let e=cs.BOARDS[this.sys.board.startsWith("pico")?"pi5":this.sys.board],t=new Date(Date.now()-36e5);this.con.writeln(`Linux ${fs} ${e.kernel} #1 SMP PREEMPT Debian 1:6.6.51-1+rpt3 (2024-10-08) aarch64`),this.con.writeln(""),this.con.writeln("The programs included with the Debian GNU/Linux system are free software;"),this.con.writeln("the exact distribution terms for each program are described in the"),this.con.writeln("individual files in /usr/share/doc/*/copyright."),this.con.writeln(""),this.con.writeln("Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extent"),this.con.writeln("permitted by applicable law."),this.con.writeln(`Last login: ${t.toDateString().replace(/ (\d{4})$/,"")} ${t.toTimeString().slice(0,8)} ${t.getFullYear()} from 192.168.1.10`),this.con.writeln('Type "help" to see the commands of this simulated shell.',"fg-K")}promptSegs(){let e=this.env.HOME,t=this.cwd===e?"~":this.cwd.startsWith(e+"/")?"~"+this.cwd.slice(e.length):this.cwd;return[[`${Of}@${fs}`,"fg-G bold"],[":",""],[t,"fg-B bold"],[" $ ",""]]}async loop(){for(;this.alive;){let e=await this.con.prompt(this.promptSegs());if(e!==null){e.trim()&&this.hist.push(e);try{await this.run(e)}catch(t){this.con.writeln(String(t.message||t),"err"),this.status=1}}}}key(e){return e.key==="Tab"?(this.complete(),!0):e.ctrlKey&&(e.key==="c"||e.key==="C")?(this.ctrlC(),!0):e.ctrlKey&&(e.key==="d"||e.key==="D")?(this.ctrlD(),!0):e.ctrlKey&&(e.key==="l"||e.key==="L")?(this.con.clear(),!0):!1}ctrlC(){if(this.fg&&this.fg.interrupt){this.fg.interrupt();return}this.con.cancel("^C")}ctrlD(){if(this.fg&&this.fg.eof){this.fg.eof();return}this.con.input.value||(this.con.cancel(""),this.con.writeln("logout"),this.exit())}exit(){this.alive=!1,this.con.hideInput(),this.ctx.onExit?this.ctx.onExit():(this.con.writeln("[Process completed \u2014 tap to start a new shell]","fg-K"),this.el.addEventListener("click",()=>this.restart(),{once:!0}))}restart(){this.alive=!0,this.cwd=this.env.HOME,this.con.clear(),this.loop()}complete(){let e=this.con.input.value,i=/(\S*)$/.exec(e)[1],s=!e.trim().includes(" "),n=[];if(s&&!i.includes("/"))n=Go.filter(o=>o.startsWith(i));else{let o=i.includes("/")?ue(i.slice(0,i.lastIndexOf("/")+1)||"/",this.cwd):this.cwd,l=i.slice(i.lastIndexOf("/")+1);try{n=this.fs.list(o).filter(a=>a.startsWith(l)&&(l.startsWith(".")||!a.startsWith("."))).map(a=>i.slice(0,i.lastIndexOf("/")+1)+a+(this.fs.isDir(ue(a,o))?"/":""))}catch{n=[]}}if(n.length===1)this.con.input.value=e.slice(0,e.length-i.length)+n[0]+(n[0].endsWith("/")?"":" ");else if(n.length>1){let o=n[0];for(let l of n)for(;!l.startsWith(o);)o=o.slice(0,-1);if(o.length>i.length)this.con.input.value=e.slice(0,e.length-i.length)+o;else{let l=this.con.prefix.cloneNode(!0);this.con.writeln(n.map(a=>Ae(a.replace(/\/$/,""))+(a.endsWith("/")?"/":"")).join("  "))}}this.con.focus()}tokenize(e){let t=[],i="",s=null,n=!1;for(let o=0;o<e.length;o++){let l=e[o];if(s){l===s?s=null:l==="\\"&&s==='"'&&o+1<e.length?i+=e[++o]:i+=l;continue}if(l==='"'||l==="'"){s=l,n=!0;continue}if(l==="\\"&&o+1<e.length){i+=e[++o],n=!0;continue}if(/\s/.test(l)){(i||n)&&t.push(i),i="",n=!1;continue}if(l==="|"||l===";"||l===">"||l==="&"){(i||n)&&t.push(i),i="",n=!1,(l===">"||l==="&"||l==="|")&&e[o+1]===l?(t.push({op:l+l}),o++):t.push({op:l});continue}if(l==="$"&&!s){let a=/^\$(\?|\w+|\{\w+\})/.exec(e.slice(o));if(a){let h=a[1].replace(/[{}]/g,"");i+=h==="?"?String(this.status):h==="PWD"?this.cwd:this.env[h]??"",o+=a[0].length-1;continue}}i+=l}if(s)throw new Error("bash: unexpected EOF while looking for matching `"+s+"'");return(i||n)&&t.push(i),t}async run(e){if(!e.trim()||e.trim().startsWith("#"))return;let t=this.tokenize(e),i=[],s=[];for(let o of t)typeof o=="object"&&(o.op===";"||o.op==="&&"||o.op==="||")?(i.push({cmd:s,next:o.op}),s=[]):s.push(o);i.push({cmd:s,next:null});let n=null;for(let o of i){if(n==="&&"&&this.status!==0){n=o.next;continue}if(n==="||"&&this.status===0){n=o.next;continue}o.cmd.length&&await this.pipeline(o.cmd),n=o.next}}async pipeline(e){let t=[[]],i=null;for(let n=0;n<e.length;n++){let o=e[n];typeof o=="object"&&o.op==="|"?t.push([]):typeof o=="object"&&(o.op===">"||o.op===">>")?(i={append:o.op===">>",file:e[n+1]},n++):typeof o=="object"&&o.op==="&"||t[t.length-1].push(o)}let s=null;for(let n=0;n<t.length;n++){let l=!(n===t.length-1)||!!i;s=await this.command(t[n],{input:s,capture:l})}if(i){if(!i.file)throw new Error("bash: syntax error near unexpected token `newline'");let n=ue(i.file,this.cwd),o=i.append&&this.fs.isFile(n)?this.fs.read(n):"";this.fs.write(n,o+(s||""))}else s&&this.con.write(s)}async command(e,{input:t,capture:i}){let s="",n=b=>{s+=b},o=(b="")=>{s+=b+`
`},l=b=>{this.con.writeln(b,"err"),this.status=1},a=()=>i?s:(this.con.write(s),null),[h,...c]=e;if(h==="sudo"&&([h,...c]=c,!h))return l("usage: sudo command"),a();h&&h.startsWith("./")&&(c=[h,...c],h="python3"),this.status=0;let u=b=>ue(b,this.cwd,this.env.HOME),p=b=>c.filter(v=>v.startsWith("-")&&v.length>1).join("").replace(/-/g,""),y=()=>c.filter(b=>!b.startsWith("-")||b==="-"),O=b=>{let v=u(b);if(this.fs.isDir(v))throw new Error(`${h}: ${b}: Is a directory`);return v.startsWith("/proc/")?this.procFile(v):this.fs.read(v).replace(/^/,"")};switch(h){case"help":o("RaptiAuto virtual Raspberry Pi \u2014 simulated bash. Commands:");for(let b=0;b<Go.length;b+=8)o("  "+Go.slice(b,b+8).map(v=>v.padEnd(12)).join(""));o(""),o("Try:  pinout \xB7 python3 blink.py \xB7 python3 \xB7 nano hello.py \xB7 pinctrl get 17 \xB7 vcgencmd measure_temp");break;case"pwd":o(this.cwd);break;case"cd":{let b=c[0]||this.env.HOME;b==="-"&&(b=this.prevCwd,o(b));let v=u(b);if(!this.fs.exists(v)){l(`bash: cd: ${c[0]}: No such file or directory`);break}if(!this.fs.isDir(v)){l(`bash: cd: ${c[0]}: Not a directory`);break}this.prevCwd=this.cwd,this.cwd=v;break}case"ls":case"ll":case"dir":{let b=p()+(h==="ll"?"l":""),v=y().length?y():["."];for(let k of v){let T=u(k);if(!this.fs.exists(T)){l(`ls: cannot access '${k}': No such file or directory`);continue}v.length>1&&o(k+":");let C=this.fs.isDir(T)?this.fs.list(T):[Ae(T)];b.includes("a")?C=[".","..",...C]:C=C.filter(R=>!R.startsWith("."));let Q=this.fs.isDir(T)?T:Nt(T),A=R=>{let D=ue(R,Q),F=this.fs.stat(D);return!F||F.dir||R==="."||R===".."?"fg-B bold":F.x||R.endsWith(".sh")?"fg-G bold":""};if(b.includes("l")){o(`total ${C.length*4}`);for(let R of C){let D=ue(R,Q),F=this.fs.stat(D)||{dir:!0,size:4096,mtime:0},J=new Date(F.mtime||Date.now()-864e5*3),he=b.includes("h")?R2(F.size):String(F.size),Z=`${F.dir?"d":"-"}rw${F.dir||F.x?"x":"-"}r-${F.dir||F.x?"x":"-"}r-${F.dir||F.x?"x":"-"} ${F.dir?2:1} pi pi ${he.padStart(6)} ${J.toDateString().slice(4,10)} ${String(J.getHours()).padStart(2,"0")}:${String(J.getMinutes()).padStart(2,"0")} `;i?o(Z+R):(this.con.write(s+Z),s="",this.con.writeln(R,A(R)))}}else if(i)for(let R of C)o(R);else this.con.write(s),s="",C.forEach((R,D)=>{this.con.write(R,A(R)),this.con.write(D<C.length-1?"  ":`
`)})}break}case"cat":{if(!y().length&&t!=null){n(t);break}for(let b of y())try{let v=O(b);n(v)}catch(v){l(v.message.startsWith("cat")?v.message:`cat: ${b}: No such file or directory`)}break}case"echo":{let b=c[0]==="-n",v=b?c.slice(1):c;n(v.join(" ").replace(/\\n/g,c.includes("-e")?`
`:"\\n")+(b?"":`
`));break}case"touch":for(let b of y()){let v=u(b);this.fs.exists(v)?this.fs.isFile(v)&&this.fs.write(v,this.fs.read(v)):this.fs.write(v,"")}break;case"mkdir":for(let b of y())try{if(this.fs.exists(u(b))&&!p().includes("p"))throw new Error(`mkdir: cannot create directory '${b}': File exists`);this.fs.mkdir(u(b),p().includes("p"))}catch(v){l(v.message.startsWith("mkdir")?v.message:"mkdir: "+v.message)}break;case"rmdir":for(let b of y())try{if(this.fs.list(u(b)).length)throw new Error(`rmdir: failed to remove '${b}': Directory not empty`);this.fs.remove(u(b),!0)}catch(v){l(v.message)}break;case"rm":{let b=p();for(let v of y()){let k=u(v);if(!this.fs.exists(k)){b.includes("f")||l(`rm: cannot remove '${v}': No such file or directory`);continue}if(this.fs.isDir(k)&&!b.includes("r")&&!b.includes("R")){l(`rm: cannot remove '${v}': Is a directory`);continue}if(k==="/"||k==="/home"||k==="/home/pi"){l(`rm: refusing to remove '${v}'`);continue}this.fs.remove(k,!0)}break}case"cp":case"mv":{let b=y();if(b.length<2){l(`${h}: missing destination file operand after '${b[0]||""}'`);break}let v=u(b[b.length-1]);for(let k of b.slice(0,-1)){let T=u(k);if(!this.fs.exists(T)){l(`${h}: cannot stat '${k}': No such file or directory`);continue}if(h==="cp"&&this.fs.isDir(T)&&!/r/i.test(p())){l(`cp: -r not specified; omitting directory '${k}'`);continue}h==="cp"?this.fs.copy(T,v):this.fs.move(T,v)}break}case"chmod":{let b=c[0]||"";for(let v of c.slice(1)){let k=u(v);if(!this.fs.isFile(k)){l(`chmod: cannot access '${v}': No such file or directory`);continue}b.includes("+x")||/^7/.test(b)?this.fs.chmodX(k,!0):b.includes("-x")&&this.fs.chmodX(k,!1)}break}case"head":case"tail":{let b=c.indexOf("-n"),v=b>=0?Number(c[b+1]):10,k=c.find(R=>/^-\d+$/.test(R));k&&(v=Number(k.slice(1)));let T=c.filter((R,D)=>!R.startsWith("-")&&(b<0||D!==b+1)),C=T.length?T.map(R=>{try{return O(R)}catch{return l(`${h}: cannot open '${R}' for reading: No such file or directory`),""}}).join(""):t||"",Q=C.replace(/\n$/,"").split(`
`),A=h==="head"?Q.slice(0,v):Q.slice(-v);C&&o(A.join(`
`));break}case"wc":{let b=y(),v=b.length?b.map(A=>{try{return O(A)}catch{return""}}).join(""):t||"",k=(v.match(/\n/g)||[]).length,T=v.split(/\s+/).filter(Boolean).length,C=new TextEncoder().encode(v).length,Q=p();o(Q==="l"?`${k}${b[0]?" "+b[0]:""}`:Q==="w"?String(T):Q==="c"?String(C):`${String(k).padStart(3)} ${String(T).padStart(4)} ${String(C).padStart(5)}${b[0]?" "+b[0]:""}`);break}case"grep":{let b=p(),v=c.filter(A=>!A.startsWith("-")),k=v[0];if(k==null){l("Usage: grep [OPTION]... PATTERNS [FILE]...");break}let T;try{T=new RegExp(k,b.includes("i")?"i":"")}catch{T=new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),b.includes("i")?"i":"")}let C=v.slice(1),Q=(A,R)=>{A.split(`
`).forEach((D,F)=>{T.test(D)!==b.includes("v")&&D!==""&&o((C.length>1?R+":":"")+(b.includes("n")?F+1+":":"")+D)})};if(C.length)for(let A of C)try{Q(O(A),A)}catch{l(`grep: ${A}: No such file or directory`)}else Q(t||"","");s||(this.status=1);break}case"find":{let b=u(c.find(C=>!C.startsWith("-")&&c[c.indexOf(C)-1]!=="-name")||"."),v=c.indexOf("-name"),k=v>=0?new RegExp("^"+c[v+1].replace(/[.+^${}()|[\]\\]/g,"\\$&").replace(/\*/g,".*").replace(/\?/g,".")+"$"):null,T=C=>{for(let Q of this.fs.list(C)){let A=ue(Q,C);(!k||k.test(Q))&&o((c[0]&&!c[0].startsWith("-")?c[0].replace(/\/$/,""):".")+A.slice(b.length)),this.fs.isDir(A)&&T(A)}};try{k||o(c[0]&&!c[0].startsWith("-")?c[0]:"."),T(b)}catch{l(`find: '${c[0]}': No such file or directory`)}break}case"tree":{let b=u(y()[0]||"."),v=0,k=0;o(y()[0]||".");let T=(C,Q)=>{let A=this.fs.list(C).filter(R=>!R.startsWith("."));A.forEach((R,D)=>{let F=ue(R,C),J=D===A.length-1;o(Q+(J?"\u2514\u2500\u2500 ":"\u251C\u2500\u2500 ")+R),this.fs.isDir(F)?(v++,T(F,Q+(J?"    ":"\u2502   "))):k++})};try{T(b,""),o(`
${v} directories, ${k} files`)}catch(C){l(C.message)}break}case"basename":o(Ae(c[0]||""));break;case"dirname":o(Nt(c[0]||""));break;case"clear":this.con.clear();break;case"history":this.hist.forEach((b,v)=>o(`${String(v+1).padStart(5)}  ${b}`));break;case"whoami":o(Of);break;case"id":o("uid=1000(pi) gid=1000(pi) groups=1000(pi),4(adm),20(dialout),24(cdrom),27(sudo),29(audio),44(video),46(plugdev),60(games),100(users),104(input),106(render),108(netdev),997(gpio),998(i2c),999(spi)");break;case"hostname":o(c.includes("-I")?this.netIp()+" ":fs);break;case"uname":{let b=this.piInfo();o(c.includes("-a")?`Linux ${fs} ${b.kernel} #1 SMP PREEMPT Debian 1:6.6.51-1+rpt3 (2024-10-08) aarch64 GNU/Linux`:c.includes("-r")?b.kernel:c.includes("-m")?"aarch64":"Linux");break}case"lsb_release":o(`No LSB modules are available.
Distributor ID:	Debian
Description:	Debian GNU/Linux 12 (bookworm)
Release:	12
Codename:	bookworm`);break;case"date":o(new Date().toString().replace(/ GMT.*$/,"")+" "+new Date().getFullYear());break;case"cal":o(N2());break;case"uptime":{let b=Math.floor(performance.now()/6e4);o(` ${new Date().toTimeString().slice(0,8)} up ${b<60?b+" min":Math.floor(b/60)+":"+String(b%60).padStart(2,"0")},  1 user,  load average: 0.${this.sys.running?"98":"08"}, 0.12, 0.09`);break}case"free":{let b=this.sys.board==="pi5";c.includes("-h")?o(`               total        used        free      shared  buff/cache   available
Mem:           ${b?"7.9Gi":"3.7Gi"}       812Mi       ${b?"6.4Gi":"2.3Gi"}        52Mi       847Mi       ${b?"7.1Gi":"2.9Gi"}
Swap:          511Mi          0B       511Mi`):o(`               total        used        free      shared  buff/cache   available
Mem:         ${b?"8245104":"3884096"}      831488     ${b?"6545916":"2185432"}       53248      867700     ${b?"7413616":"3052608"}
Swap:         524284           0      524284`);break}case"df":o(`Filesystem      Size  Used Avail Use% Mounted on
udev            3.8G     0  3.8G   0% /dev
tmpfs           806M  6.6M  799M   1% /run
/dev/mmcblk0p2   29G  5.2G   22G  20% /
tmpfs           4.0G  208K  4.0G   1% /dev/shm
/dev/mmcblk0p1  510M   75M  436M  15% /boot/firmware`);break;case"ps":{o("    PID TTY          TIME CMD"),o("   1842 pts/0    00:00:00 bash"),this.sys.proc&&!this.sys.proc.dead&&o("   2051 pts/0    00:00:01 python3"),o(`   ${2100+this.hist.length} pts/0    00:00:00 ps`);break}case"top":{let b=this.sys.gpio.cpuTemp();o(`top - ${new Date().toTimeString().slice(0,8)} up 1:12,  1 user,  load average: 0.21, 0.15, 0.10`),o("Tasks: 187 total,   1 running, 186 sleeping,   0 stopped,   0 zombie"),o(`%Cpu(s):  ${this.sys.running?"24.6":" 1.3"} us,  0.8 sy,  0.0 ni, ${this.sys.running?"74.1":"97.6"} id,  0.0 wa,  0.0 hi,  0.3 si,  0.0 st`),o("MiB Mem :   8052.0 total,   6392.4 free,    812.2 used,    847.4 buff/cache"),o(""),o("    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND"),this.sys.proc&&!this.sys.proc.dead&&o("   2051 pi        20   0   27812  14336   7680 S  24.3   0.2   0:01.82 python3"),o("    987 pi        20   0  418924  98112  71424 S   1.3   1.2   0:12.40 labwc"),o("   1012 pi        20   0  320188  51200  38912 S   0.7   0.6   0:03.11 wf-panel-pi"),o("   1840 pi        20   0  402560  60416  45056 S   0.3   0.7   0:01.05 lxterminal"),o("      1 root      20   0  168696  12032   8960 S   0.0   0.1   0:02.31 systemd"),o(`(snapshot \xB7 CPU ${b}\xB0C)`);break}case"lscpu":{let b=this.piInfo(),v=this.sys.board==="pi5";o(`Architecture:            aarch64
  CPU op-mode(s):        32-bit, 64-bit
  Byte Order:            Little Endian
CPU(s):                  4
  On-line CPU(s) list:   0-3
Vendor ID:               ARM
  Model name:            ${v?"Cortex-A76":"Cortex-A72"}
    Thread(s) per core:  1
    Core(s) per cluster: 4
    CPU max MHz:         ${v?"2400.0000":"1800.0000"}
    CPU min MHz:         ${v?"1500.0000":"600.0000"}
Model:                   ${b.model}`);break}case"env":case"printenv":for(let[b,v]of Object.entries(this.env))o(`${b}=${v}`);o(`PWD=${this.cwd}`);break;case"export":for(let b of c){let v=/^(\w+)=(.*)$/.exec(b);v&&(this.env[v[1]]=v[2])}break;case"which":for(let b of c)Go.includes(b)?o(b==="python"||b==="python3"?"/usr/bin/python3":"/usr/bin/"+b):this.status=1;break;case"true":break;case"false":this.status=1;break;case"man":o(c[0]?`No manual entry for ${c[0]} (this is a simulated shell; try "help").`:`What manual page do you want?
For example, try 'man man'.`);break;case"kill":o("");break;case"exit":case"logout":this.exit();break;case"sleep":this.con.write(s),s="",await this.wait(Number(c[0]||1)*1e3);break;case"ping":this.con.write(s),s="",await this.ping(c);break;case"ifconfig":case"ip":o(I2(h==="ip",this.netIp(),this.netMac()));break;case"curl":await this.curl(c,{wl:o,w:n,err:l});break;case"wget":await this.wget(c,{wl:o,w:n,err:l});break;case"nslookup":{let b=c[0],v=b&&this.sys.net.resolve(b,this.sys.netDev);o(`Server:		192.168.1.1
Address:	192.168.1.1#53
`),v?o(`Non-authoritative answer:
Name:	${b}
Address: ${v}`):(o(`** server can't find ${b}: NXDOMAIN`),this.status=1);break}case"iwgetid":o(this.sys.net.online(this.sys.netDev)?c.includes("-r")?this.sys.netDev.ssid:`wlan0     ESSID:"${this.sys.netDev.ssid}"`:"");break;case"nmcli":o(this.nmcli(c));break;case"chromium-browser":case"chromium":this.ctx.openUrl?this.ctx.openUrl(c.find(b=>!b.startsWith("-"))||""):l("chromium: cannot open display");break;case"mosquitto_pub":this.con.write(s),s="",this.mosquittoPub(c);break;case"mosquitto_sub":this.con.write(s),s="",await this.mosquittoSub(c);break;case"systemctl":o(c[0]==="status"?`\u25CF ${c[1]||"unknown"}.service
     Loaded: loaded
     Active: active (running)`:"");break;case"vcgencmd":o(this.vcgencmd(c)),/^error/.test(s)&&(this.status=1);break;case"pinout":this.con.write(s),s="",this.pinout();break;case"pinctrl":o(this.pinctrl(c));break;case"raspi-gpio":o(this.raspiGpio(c));break;case"gpio":l("bash: gpio: command not found (wiringPi is deprecated \u2014 use pinctrl or gpiozero)");break;case"i2cdetect":o(this.i2cdetect(c));break;case"neofetch":case"fastfetch":this.con.write(s),s="",this.neofetch();break;case"raspi-config":o("raspi-config needs a full-screen text terminal. Open the Raspberry Pi menu \u2192 Preferences \u2192 Raspberry Pi Configuration on the Desktop tab.");break;case"rpicam-hello":case"libcamera-hello":case"rpicam-still":l("ERROR: *** no cameras available ***");break;case"apt":case"apt-get":this.con.write(s),s="",await this.apt(c);break;case"pip":case"pip3":o(y0(c)),c[0]==="install"&&(this.status=1);break;case"nano":case"vi":case"vim":case"mousepad":case"geany":await this.nano(c.filter(b=>!b.startsWith("-"))[0]);break;case"thonny":this.ctx.openThonny?this.ctx.openThonny(c[0]?u(c[0]):null):l("thonny: cannot open display");break;case"xdg-open":case"open":/^[a-z]+:\/\//i.test(c[0]||"")&&this.ctx.openUrl?this.ctx.openUrl(c[0]):c[0]&&this.ctx.openFile&&this.ctx.openFile(u(c[0]));break;case"reboot":await this.reboot();break;case"shutdown":case"poweroff":case"halt":this.con.writeln(`Broadcast message from root@${fs} on pts/0:

The system will power off now!`,"fg-Y"),this.sys.killProcess(),await this.wait(800),this.con.writeln("Connection to raspberrypi closed."),this.exit();break;case"python":case"python3":case"python3.11":this.con.write(s),s="",await this.python(c);break;case void 0:break;default:{let b=/^(\w+)=(.*)$/.exec(h);if(b){this.env[b[1]]=b[2];break}if(h.endsWith(".py")&&this.fs.isFile(u(h))){l(`bash: ${h}: command not found \u2014 run it with: python3 ${h}`),this.status=127;break}l(`bash: ${h}: command not found`),this.status=127}}return a()}wait(e){return new Promise(t=>{let i=setTimeout(()=>{this.fg=null,t()},e);this.fg={interrupt:()=>{clearTimeout(i),this.con.writeln("^C"),this.fg=null,this.status=130,t()}}})}piInfo(){return cs.BOARDS[this.sys.board.startsWith("pico")?"pi5":this.sys.board]}procFile(e){let t=this.piInfo(),i=this.sys.board==="pi5";if(e==="/proc/cpuinfo"){let s="";for(let n=0;n<4;n++)s+=`processor	: ${n}
BogoMIPS	: 108.00
Features	: fp asimd evtstrm aes pmull sha1 sha2 crc32 atomics fphp asimdhp cpuid asimdrdm lrcpc dcpop asimddp
CPU implementer	: 0x41
CPU architecture: 8
CPU variant	: ${i?"0x4":"0x0"}
CPU part	: ${i?"0xd0b":"0xd08"}
CPU revision	: ${i?"1":"3"}

`;return s+`Revision	: ${t.revision}
Serial		: 1a2b3c4d5e6f7a8b
Model		: ${t.model}
`}if(e==="/proc/meminfo")return`MemTotal:        ${i?"8245104":"3884096"} kB
MemFree:         ${i?"6545916":"2185432"} kB
MemAvailable:    ${i?"7413616":"3052608"} kB
`;if(e==="/proc/device-tree/model")return t.model+`
`;if(e==="/proc/version")return`Linux version ${t.kernel} (gcc-12 (Debian 12.2.0-14) 12.2.0) #1 SMP PREEMPT Debian 1:6.6.51-1+rpt3 (2024-10-08)
`;throw new Error(`cat: ${e}: No such file or directory`)}vcgencmd(e){let t=this.sys.board==="pi5";switch(e[0]){case"measure_temp":return`temp=${this.sys.gpio.cpuTemp().toFixed(1)}'C`;case"get_throttled":return"throttled=0x0";case"measure_clock":return e[1]==="arm"||!e[1]?`frequency(0)=${t?this.sys.running?24e8:15e8:this.sys.running?18e8:6e8}`:`frequency(0)=${t?96e7:5e8}`;case"measure_volts":return`volt=${t?"0.7200":"0.8500"}V`;case"get_mem":return e[1]==="gpu"?"gpu=8M":`arm=${t?8064:3968}M`;case"version":return`2024/09/23 14:02:56
Copyright (c) 2012 Broadcom
version 26826259 (release) (embedded)`;case"commands":return'commands="measure_temp, get_throttled, measure_clock, measure_volts, get_mem, version"';default:return e[0]?'error=1 error_msg="Command not registered"':"Usage: vcgencmd measure_temp | get_throttled | measure_clock arm | measure_volts | get_mem arm | version"}}pinout(){let e=this.piInfo(),t=this.sys.board==="pi5",i="fg-G",s="fg-Y",n="fg-R",o="fg-K",l="fg-C",a=t?[",--------------------------------.","| oooooooooooooooooooo J8   : +====","| 1ooooooooooooooooooo      : |USB2","|  Wi    +---+      +----+  : +====","|  Fi    |RAM|      |RP1 |    +====","||p      +---+      +----+    |USB3","||c       ------              +====","||i       |SoC|               +======","||e       ------  J14         |   Net","| pwr      |hd|   |hd| |cd|   +======","`-| |------| |-----| |--------------'"]:[",--------------------------------.","| oooooooooooooooooooo J8   +======","| 1ooooooooooooooooooo  PoE |   Net","|  Wi                    1o +======","|  Fi  Pi Model 4B  V1.5 oo      |","|        ,----. +---+         +====","| |D|    |SoC | |RAM|         |USB3","| |S|    |    | |   |         +====","| |I|    `----' +---+            |","|                   |C|       +====","|                   |S|       |USB2","| pwr   |hd|   |hd| |I||A|    +====","`-| |---|m0|---|m1|----|V|-------'"];for(let u of a)this.con.writeln(u,i);this.con.writeln("");let h=(u,p)=>{this.con.write(u.padEnd(19),"bold"),this.con.writeln(": "+p)};h("Revision",e.revision),h("SoC",e.soc.replace("Broadcom ","")),h("RAM",t?"8GB":"4GB"),h("Storage","MicroSD"),h("USB ports","4 (of which 2 USB3)"),h("Ethernet ports","1 (1000Mbps max. speed)"),h("Wi-fi","True"),h("Bluetooth","True"),h("Camera ports (CSI)",t?"2":"1"),h("Display ports (DSI)",t?"2":"1"),this.con.writeln(""),this.con.writeln("J8:","bold");let c=u=>u.type==="power3"?s:u.type==="power5"?n:u.type==="gnd"?o:u.type==="gpio"?i:l;for(let u=1;u<=40;u+=2){let p=cs.PI_HEADER[u-1],y=cs.PI_HEADER[u];this.con.write(p.name.padStart(8),c(p)),this.con.write(` (${u}) `.padStart(6)),this.con.write(`(${u+1})`.padEnd(5)),this.con.writeln(" "+y.name,c(y))}this.con.writeln(""),this.con.writeln("For further information, please refer to https://pinout.xyz/",o)}pinState(e){let t=this.sys.gpio,i=t.pins.get(e),s=t.read(e);return{pn:i,lvl:s}}pinctrl(e){this.sys.board==="pi4"&&e[0];let t=s=>{let{pn:n,lvl:o}=this.pinState(s),l=n.mode==="out"?"op":n.mode==="pwm"?"a0":"ip",a=n.pull==="up"?"pu":n.pull==="down"?"pd":"pn",h=cs.PI_HEADER.find(c=>c.gpio===s);return`${String(s).padStart(2)}: ${l}    ${a} | ${o?"hi":"lo"} // ${h?"GPIO"+s:""} = ${n.mode==="out"?"output":n.mode==="pwm"?"PWM":"input"}`},i=e[0];if(!i||i==="get")return(e.slice(1).length?e.slice(1):[...Array(28).keys()].map(String)).flatMap(n=>n.includes("-")?g0(n):[Number(n)]).filter(n=>n>=0&&n<=27).map(t).join(`
`);if(i==="set"){let s=Number(e[1]),n=e.slice(2);if(!(s>=0&&s<=27))return"pinctrl: invalid GPIO";let o=this.sys.gpio;return n.includes("op")&&o.setup(s,"out"),n.includes("ip")&&o.setup(s,"in",o.pins.get(s).pull),n.includes("pu")&&o.setPull(s,"up"),n.includes("pd")&&o.setPull(s,"down"),n.includes("pn")&&o.setPull(s,"none"),n.includes("dh")&&(o.pins.get(s).mode!=="out"&&o.setup(s,"out"),o.write(s,1)),n.includes("dl")&&(o.pins.get(s).mode!=="out"&&o.setup(s,"out"),o.write(s,0)),""}return i==="help"||i==="-h"?`Use:
  pinctrl [get] [GPIO]          show the state of pins
  pinctrl set GPIO [op|ip] [pu|pd|pn] [dh|dl]

  op = output, ip = input, pu/pd/pn = pull up / down / none, dh/dl = drive high / low`:this.pinctrl(["get",...e])}raspiGpio(e){return this.sys.board==="pi5"?"raspi-gpio is not supported on Pi 5 - use `pinctrl`":e[0]==="get"?(e[1]?e.slice(1).flatMap(i=>i.includes("-")?g0(i):[Number(i)]):[...Array(28).keys()]).map(i=>{let{pn:s,lvl:n}=this.pinState(i);return`GPIO ${i}: level=${n} fsel=${s.mode==="out"?1:0} func=${s.mode==="out"?"OUTPUT":"INPUT"} pull=${(s.pull||"none").toUpperCase()}`}).join(`
`):e[0]==="set"?this.pinctrl(e):"Usage: raspi-gpio get [GPIO]  |  raspi-gpio set <GPIO> [op|ip] [pu|pd|pn] [dh|dl]"}i2cdetect(e){if(!e.includes("-y"))return"Usage: i2cdetect -y 1";let t="     0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f",i=new Set(this.sys.gpio.parts.filter(s=>s.type==="lcd").map(s=>Number(s.props.addr??39)));for(let s=0;s<8;s++){t+=`
${(s*16).toString(16).padStart(2,"0")}: `;for(let n=0;n<16;n++){let o=s*16+n;t+=o<3||o>119?"   ":i.has(o)?o.toString(16).padStart(2,"0")+" ":"-- "}}return t}neofetch(){let e=this.piInfo(),t=["   .~~.   .~~.  ","  '. \\ ' ' / .'  ","   .~ .~~~..~.   ","  : .~.'~'.~. :  "," ~ (   ) (   ) ~ ","( : '~'.~.'~' : )"," ~ .~ (   ) ~. ~ ","  (  : '~' :  )  ","   '~ .~~~. ~'   ","       '~'       "],i=[["pi@raspberrypi",""],["--------------",""],["OS","Debian GNU/Linux 12 (bookworm) aarch64"],["Host",e.model],["Kernel",e.kernel],["Uptime",Math.floor(performance.now()/6e4)+" mins"],["Shell","bash 5.2.15"],["DE","labwc (Wayland)"],["Terminal","lxterminal"],["CPU",`${e.soc.replace("Broadcom ","")} (4) @ ${this.sys.board==="pi5"?"2.400":"1.800"}GHz`],["Memory",`812MiB / ${this.sys.board==="pi5"?"8052":"3793"}MiB`],["Temp",this.sys.gpio.cpuTemp()+"\xB0C"]];for(let s=0;s<Math.max(t.length,i.length);s++){this.con.write((t[s]||"").padEnd(20),s<2?"fg-G bold":"fg-R bold");let n=i[s];n&&(n[1]?(this.con.write(n[0],"fg-R bold"),this.con.write(": "+n[1])):this.con.write(n[0],"fg-G bold")),this.con.write(`
`)}}netIp(){let e=this.sys.netDev;return this.sys.net&&e&&e.ip&&this.sys.net.online(e)?e.ip:"192.168.1.50"}netMac(){let e=this.sys.netDev;return e&&this.sys.net?this.sys.net.macString(e,":").toLowerCase():"d8:3a:dd:12:34:57"}async ping(e){let t=e.filter(p=>!p.startsWith("-")&&e[e.indexOf(p)-1]!=="-c")[0];if(!t){this.con.writeln("ping: usage error: Destination address required","err"),this.status=1;return}let i=this.sys.net,s=this.sys.netDev;if(!i.online(s)){this.con.writeln("ping: connect: Network is unreachable","err"),this.status=2;return}let n=i.resolve(t,s);if(!n){this.con.writeln(`ping: ${t}: Temporary failure in name resolution`,"err"),this.status=2;return}let o=e.indexOf("-c"),l=o>=0?Number(e[o+1]):1/0,a=/^(127\.|192\.168\.)/.test(n);this.con.writeln(`PING ${t} (${n}) 56(84) bytes of data.`);let h=0,c=!1,u=[];for(this.fg={interrupt:()=>{c=!0}};!c&&h<l;){h++;let p=a?.2+Math.random()*3:8+Math.random()*14;u.push(p),this.con.writeln(`64 bytes from ${n}: icmp_seq=${h} ttl=${a?64:117} time=${p.toFixed(a?3:1)} ms`),await new Promise(y=>{let O=setTimeout(y,1e3);this.fg.interrupt=()=>{c=!0,clearTimeout(O),y()}})}this.fg=null,c&&this.con.writeln("^C"),this.con.writeln(`
--- ${t} ping statistics ---
${h} packets transmitted, ${h} received, 0% packet loss, time ${h*1001}ms
rtt min/avg/max/mdev = ${Math.min(...u).toFixed(3)}/${(u.reduce((p,y)=>p+y,0)/h).toFixed(3)}/${Math.max(...u).toFixed(3)}/2.114 ms`)}async curl(e,{wl:t,w:i,err:s}){let n="",o="",l="",a=!1,h=!1,c=!1,u={};for(let b=0;b<e.length;b++){let v=e[b];if(v==="-X"||v==="--request")n=e[++b];else if(v==="-d"||v==="--data"||v==="--data-raw")o=e[++b]||"";else if(v==="-H"||v==="--header"){let[k,...T]=String(e[++b]||"").split(":");u[k.trim()]=T.join(":").trim()}else v==="-I"||v==="--head"?a=!0:v==="-i"||v==="--include"?h=!0:v==="-s"||v==="--silent"||v==="-sS"||v==="-S"?c=!0:v==="-o"||v==="-u"||v==="-A"||v==="-m"?b++:v.startsWith("-")||(l=v)}if(!l){s("curl: try 'curl --help' for more information"),this.status=2;return}/^[a-z]+:\/\//i.test(l)||(l="http://"+l),o&&!n&&(n="POST"),o&&!u["Content-Type"]&&(u["Content-Type"]=/^\s*[{[]/.test(o)?"application/json":"application/x-www-form-urlencoded");let p=this.sys.net,y=this.sys.netDev,O=await p.request({method:a?"HEAD":n||"GET",url:l,headers:{"user-agent":"curl/7.88.1",...u},body:o,fromName:y.name},y);if(O.failed){let b={ERR_NAME_NOT_RESOLVED:["6",`Could not resolve host: ${new URL(l).hostname}`],ERR_CONNECTION_REFUSED:["7",`Failed to connect to ${new URL(l).hostname} port ${new URL(l).port||80} after 2 ms: Couldn't connect to server`]}[O.error]||["28",O.statusText||O.error];s(`curl: (${b[0]}) ${b[1]}`),this.status=+b[0];return}if(a||h){t(`HTTP/1.1 ${O.status} ${O.statusText}`);for(let[b,v]of Object.entries(O.headers))t(`${b.replace(/(^|-)(\w)/g,(k,T,C)=>T+C.toUpperCase())}: ${v}`);t("")}a||i(O.body+(O.body.endsWith(`
`)?"":`
`))}async wget(e,{wl:t,w:i,err:s}){let n=e.find(p=>!p.startsWith("-"));if(!n){s("wget: missing URL");return}/^[a-z]+:\/\//i.test(n)||(n="http://"+n);let o=e.indexOf("-O"),l=this.sys.net,a=this.sys.netDev,h=new URL(n);t(`--${new Date().toISOString().replace("T"," ").slice(0,19)}--  ${n}`),t(`Resolving ${h.hostname}... ${l.resolve(h.hostname,a)||"failed: Name or service not known."}`);let c=await l.request({method:"GET",url:n,headers:{"user-agent":"Wget/1.21.3"},fromName:a.name},a);if(c.failed){s(`wget: unable to resolve host address '${h.hostname}'`),this.status=4;return}if(t(`HTTP request sent, awaiting response... ${c.status} ${c.statusText}`),c.status>=400){s(`${new Date().toISOString().replace("T"," ").slice(0,19)} ERROR ${c.status}: ${c.statusText}.`),this.status=8;return}let u=o>=0?e[o+1]:h.pathname.split("/").filter(Boolean).pop()||"index.html";this.fs.write(ue(u,this.cwd,this.env.HOME),c.body),this.sys.emit("files"),t(`Length: ${c.body.length} [${c.headers["content-type"]||"text/plain"}]
Saving to: '${u}'

${u}      100%[===================>]  ${c.body.length} B  --.-KB/s    in 0s

'${u}' saved [${c.body.length}/${c.body.length}]`)}nmcli(e){let t=this.sys.net,i=this.sys.netDev;return e[0]==="dev"||e[0]==="device"?e[1]==="wifi"?`IN-USE  BSSID              SSID          MODE   CHAN  RATE        SIGNAL  BARS  SECURITY
`+t.scan().map(n=>`${n.ssid===i.ssid&&t.online(i)?"*":" "}       02:1A:2B:3C:4D:0${n.ch%10}  ${n.ssid.padEnd(12)}  Infra  ${String(n.ch).padEnd(4)}  130 Mbit/s  ${100+n.rssi+20}      \u2582\u2584\u2586\u2588  ${n.enc==="open"?"--":"WPA2"}`).join(`
`):`DEVICE  TYPE      STATE      CONNECTION
wlan0   wifi      ${t.online(i)?"connected":"disconnected"}  ${t.online(i)?i.ssid:"--"}
eth0    ethernet  unavailable  --
lo      loopback  unmanaged  --`:'nmcli: use "nmcli dev wifi" to list the Wi-Fi networks'}mosquittoPub(e){let t=c=>{let u=e.indexOf(c);return u>=0?e[u+1]:""},i=t("-h")||"localhost",s=t("-t"),n=t("-m"),o=Number(t("-p"))||1883;if(!s){this.con.writeln("Error: You must specify a topic to publish to.","err"),this.status=1;return}let l=this.sys.net.mqtt,a=this.sys.netDev,h=l.connect("mosquitto_pub_"+Date.now(),i,o,{},a);if(!h.ok){this.con.writeln(`Error: ${h.reason==="refused"?"Connection refused":"Unknown host"}`,"err"),this.status=1;return}l.publish(h.client,s,n,e.includes("-r")),l.disconnect(h.client)}async mosquittoSub(e){let t=u=>{let p=e.indexOf(u);return p>=0?e[p+1]:""},i=t("-h")||"localhost",s=t("-t"),n=Number(t("-p"))||1883;if(!s){this.con.writeln("Error: You must specify a topic to subscribe to.","err"),this.status=1;return}let o=this.sys.net.mqtt,l=this.sys.netDev,a=o.connect("mosquitto_sub_"+Date.now(),i,n,{},l);if(!a.ok){this.con.writeln(`Error: ${a.reason==="refused"?"Connection refused":"Unknown host"}`,"err"),this.status=1;return}o.subscribe(a.client,s);let h=!1,c=e.includes("-v");for(this.fg={interrupt:()=>{h=!0}};!h;){let u;for(;u=o.poll(a.client);)this.con.writeln(c?`${u.topic} ${u.payload}`:u.payload);await new Promise(p=>{let y=setTimeout(p,150);this.fg.interrupt=()=>{h=!0,clearTimeout(y),p()}})}o.disconnect(a.client),this.fg=null,this.con.writeln("^C")}async apt(e){let t=e.find(n=>!n.startsWith("-")),i=e.filter(n=>!n.startsWith("-")).slice(1),s=(n,o=250)=>(this.con.writeln(n),this.wait(o));if(t==="update")for(let n of["Hit:1 http://deb.debian.org/debian bookworm InRelease","Hit:2 http://deb.debian.org/debian-security bookworm-security InRelease","Hit:3 http://deb.debian.org/debian bookworm-updates InRelease","Hit:4 http://archive.raspberrypi.com/debian bookworm InRelease","Reading package lists... Done","Building dependency tree... Done","Reading state information... Done","All packages are up to date."])await s(n,280);else if(t==="install"||t==="upgrade"||t==="full-upgrade"){if(await s("Reading package lists... Done"),await s("Building dependency tree... Done"),await s("Reading state information... Done"),t!=="install"||!i.length){await s("Calculating upgrade... Done"),await s("0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.");return}let n={"python3-gpiozero":1,"python3-rpi.gpio":1,"python3-rpi-lgpio":1,python3:1,thonny:1,"python3-pip":1,mosquitto:1,"mosquitto-clients":1,"python3-flask":1,"python3-paho-mqtt":1,"python3-requests":1,curl:1,wget:1,git:1,"python3-psutil":1,chromium:1,"chromium-browser":1};for(let o of i)n[o]?await s(`${o} is already the newest version.`):(this.con.writeln(`E: Unable to locate package ${o}`,"err"),this.con.writeln("   (Built in: gpiozero, RPi.GPIO, requests, flask, paho-mqtt, mosquitto, curl, neopixel, adafruit_dht.)","fg-K"),this.status=100);this.status||await s("0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.")}else this.con.writeln(`apt 2.6.1 (arm64)
Usage: apt [options] command

Most used commands:
  update - retrieve new lists of packages
  upgrade - upgrade the system by installing/upgrading packages
  install - install packages`)}async nano(e){e||(e="New Buffer");let t=e==="New Buffer"?null:ue(e,this.cwd,this.env.HOME);if(t&&this.fs.isDir(t)){this.con.writeln(`"${e}" is a directory`,"err");return}let i=t&&this.fs.isFile(t)?this.fs.read(t):"";await new Promise(s=>{let n=(0,st.h)("textarea",{class:"nano-text",spellcheck:"false",autocapitalize:"off",autocorrect:"off"});n.value=i;let o=(0,st.h)("div",{class:"nano-status"},t&&!this.fs.isFile(t)?"[ New File ]":`[ Read ${i.split(`
`).length-1} lines ]`),l=!1;n.addEventListener("input",()=>{l=!0,u.lastChild.textContent="Modified"});let a=()=>t?(this.fs.write(t,n.value),l=!1,u.lastChild.textContent="",o.textContent=`[ Wrote ${n.value.split(`
`).length-(n.value.endsWith(`
`)?1:0)} lines ]`,!0):(o.textContent="[ No file name: open nano with a file name ]",!1),h=()=>{O.remove(),this.con.focus(),s()},c=()=>{if(!l)return h();o.innerHTML="",o.append("Save modified buffer? ",(0,st.h)("button",{class:"nano-btn",onclick:()=>{a()&&h()}},"Y Yes"),(0,st.h)("button",{class:"nano-btn",onclick:h},"N No"),(0,st.h)("button",{class:"nano-btn",onclick:()=>{o.textContent=""}},"^C Cancel"))},u=(0,st.h)("div",{class:"nano-title"},(0,st.h)("span",{},"  GNU nano 7.2"),(0,st.h)("b",{},t?Ae(t):"New Buffer"),(0,st.h)("span",{},"")),p=(b,v,k)=>(0,st.h)("button",{class:"nano-key",onclick:k},(0,st.h)("b",{},b)," "+v),y=(0,st.h)("div",{class:"nano-foot"},p("^O","Write Out",a),p("^X","Exit",c),p("^K","Cut",()=>M2(n)),p("^U","Paste",()=>D2(n)),p("Tab","Indent",()=>vf(n,"    ")),p("^W","Where Is",()=>{let b=prompt("Search:");if(b){let v=n.value.indexOf(b,n.selectionEnd);v>=0&&(n.setSelectionRange(v,v+b.length),n.focus())}}));n.addEventListener("keydown",b=>{b.ctrlKey&&(b.key==="o"||b.key==="s")?(b.preventDefault(),a()):b.ctrlKey&&b.key==="x"?(b.preventDefault(),c()):b.key==="Tab"&&(b.preventDefault(),vf(n,"    "))});let O=(0,st.h)("div",{class:"nano"},u,n,o,y);this.el.appendChild(O),setTimeout(()=>n.focus(),50)})}async reboot(){this.sys.killProcess(),this.sys.gpio.reset(),this.con.writeln(`Broadcast message from root@${fs} on pts/0:

The system will reboot now!`,"fg-Y"),await this.wait(700),this.con.clear();let e=["[    0.000000] Booting Linux on physical CPU 0x0000000000 [0x414fd0b1]",`[    0.000000] Linux version ${this.piInfo().kernel}`,`[    0.000000] Machine model: ${this.piInfo().model}`,"[    1.023112] mmc0: new ultra high speed DDR50 SDXC card at address aaaa","[    1.511904] EXT4-fs (mmcblk0p2): mounted filesystem","[  OK  ] Started systemd-udevd.service","[  OK  ] Reached target network.target","[  OK  ] Started ssh.service - OpenBSD Secure Shell server","[  OK  ] Started lightdm.service","",`Raspberry Pi OS (Debian GNU/Linux 12) ${fs} tty1`,""];for(let t of e)this.con.writeln(t,t.includes("OK")?"fg-G":""),await this.wait(90);this.cwd=this.env.HOME,this.banner()}async python(e){if(e[0]==="--version"||e[0]==="-V"){this.con.writeln("Python 3.11.2 (simulated by MicroPython 1.29.0)");return}if(e[0]==="-m"&&e[1]==="pip"){this.con.writeln(y0(e.slice(2)));return}if(e[0]==="-m"&&e[1]==="venv"){this.con.writeln(`Created virtual environment ${e[2]||""} (simulated)`);return}let t=this.sys;if(t.isPico){this.con.writeln("python3: switch the board to a Raspberry Pi 4 / 5 to use the terminal","err");return}let i=null,s=null;if(e[0]==="-c")i=e[1]||"";else if(e[0]&&!e[0].startsWith("-")&&(s=ue(e[0],this.cwd,this.env.HOME),!this.fs.isFile(s))){this.con.writeln(`python3: can't open file '${s}': [Errno 2] No such file or directory`,"err"),this.status=2;return}let n=await t.spawn({owner:this,cwd:this.cwd,out:(l,a)=>this.con.write(l,a==="err"?"err":""),readLine:l=>this.con.prompt(l,{keepHistory:!1}).then(a=>a??"")});if(this.fg={interrupt:()=>{n.busy?n.interrupt():this.con.cancel("^C")},eof:()=>{this.replEof=!0,this.con.cancel("")}},s||i!=null){await n.exec(`import sys
sys.argv = ${JSON.stringify([s||"-c",...e.slice(1)])}`);let l=s?await n.runFile(s):await n.runSource(i,"<string>");this.status=l,this.fg=null,t.proc===n&&t.killProcess();return}this.con.writeln("Python 3.11.2 \xB7 MicroPython 1.29.0 engine (RaptiAuto virtual Raspberry Pi) on linux"),this.con.writeln('Type "help()" for more information, exit() or Ctrl+D to leave.'),this.replEof=!1;let o=[];for(;!n.dead&&t.proc===n;){let l=o.length?o[o.length-1]:"",a=o.length?/^(\s*)/.exec(l)[1]+(/:\s*$/.test(l)?"    ":""):"",h=await this.con.prompt(o.length?"... ":">>> ",{value:a});if(this.replEof)break;if(h==null){if(o=[],n.busy)continue;this.con.writeln("KeyboardInterrupt","err");continue}if(!o.length&&/^\s*(exit|quit)\(\)\s*$/.test(h))break;if(!o.length&&!h.trim()||(o.push(h),kf(o,h)))continue;let c=o.join(`
`).replace(/\s+$/,"")+`
`;o=[],await n.replExec(c)}this.fg=null,t.proc===n&&t.killProcess()}};function kf(r,e){let t=r.join(`
`),i=0,s=null,n=!1;for(let o=0;o<t.length;o++){let l=t[o];if(s){n&&t.startsWith(s.repeat(3),o)?(s=null,n=!1,o+=2):!n&&l===s?s=null:l==="\\"&&o++;continue}if(l==="#"){for(;o<t.length&&t[o]!==`
`;)o++;continue}if(l==='"'||l==="'"){t.startsWith(l.repeat(3),o)?(s=l,n=!0,o+=2):s=l;continue}"([{".includes(l)?i++:")]}".includes(l)&&i--}return s&&n||i>0?!0:r.length===1?/:\s*(#.*)?$/.test(e)||/^\s*@/.test(e):e.trim()!==""}function g0(r){let[e,t]=r.split("-").map(Number),i=[];for(let s=e;s<=t;s++)i.push(s);return i}function R2(r){return r<1024?String(r):r<1048576?(r/1024).toFixed(1)+"K":(r/1048576).toFixed(1)+"M"}function vf(r,e){let t=r.selectionStart,i=r.selectionEnd;r.value=r.value.slice(0,t)+e+r.value.slice(i),r.setSelectionRange(t+e.length,t+e.length),r.dispatchEvent(new Event("input")),r.focus()}var wf="";function M2(r){let e=r.value,t=e.lastIndexOf(`
`,r.selectionStart-1)+1,i=e.indexOf(`
`,r.selectionStart);i=i<0?e.length:i+1,wf=e.slice(t,i),r.value=e.slice(0,t)+e.slice(i),r.setSelectionRange(t,t),r.dispatchEvent(new Event("input")),r.focus()}function D2(r){wf&&vf(r,wf)}function N2(){let r=new Date,e=r.getFullYear(),t=r.getMonth(),i=r.toLocaleString("en",{month:"long"})+" "+e,s=i.padStart(10+Math.ceil(i.length/2))+`
Su Mo Tu We Th Fr Sa
`,n=new Date(e,t,1).getDay(),o=new Date(e,t+1,0).getDate();s+="   ".repeat(n);for(let l=1;l<=o;l++)s+=String(l).padStart(2)+((n+l)%7?" ":`
`);return s.trimEnd()}function I2(r,e="192.168.1.50",t="d8:3a:dd:12:34:57"){return r?`1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN
    inet 127.0.0.1/8 scope host lo
2: eth0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 state DOWN
    link/ether d8:3a:dd:12:34:56 brd ff:ff:ff:ff:ff:ff
3: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 state UP
    link/ether ${t} brd ff:ff:ff:ff:ff:ff
    inet ${e}/24 brd 192.168.1.255 scope global dynamic noprefixroute wlan0`:`eth0: flags=4099<UP,BROADCAST,MULTICAST>  mtu 1500
        ether d8:3a:dd:12:34:56  txqueuelen 1000  (Ethernet)

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0

wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet ${e}  netmask 255.255.255.0  broadcast 192.168.1.255
        ether ${t}  txqueuelen 1000  (Ethernet)`}var _0={requests:"2.31.0",flask:"2.2.2","paho-mqtt":"2.1.0",psutil:"5.9.4",gpiozero:"2.0.1","rpi.gpio":"0.7.1",pyserial:"3.5",smbus2:"0.4.3",numpy:"1.24.2",pillow:"9.4.0"};function y0(r){if(r[0]==="install"){let e=r.slice(1).filter(t=>!t.startsWith("-"));if(e.length&&e.every(t=>_0[t.toLowerCase().replace(/[=<>].*$/,"").replace("_","-")]))return e.map(t=>{let i=t.toLowerCase().replace(/[=<>].*$/,"");return`Requirement already satisfied: ${i} in /usr/lib/python3/dist-packages (${_0[i]})`}).join(`
`);if(e.length)return e.map(t=>`ERROR: Could not find a version that satisfies the requirement ${t} (from versions: none)
ERROR: No matching distribution found for ${t}`).join(`
`)+`
(RaptiAuto: built in: requests, flask, paho-mqtt, psutil, gpiozero, RPi.GPIO, smbus2, pyserial, neopixel, adafruit_dht, board.)`}return r[0]==="install"?`error: externally-managed-environment

\xD7 This environment is externally managed
\u2570\u2500> To install Python packages system-wide, try apt install
    python3-xyz, where xyz is the package you are trying to
    install.

(RaptiAuto: the virtual Pi is offline. Built in: gpiozero, RPi.GPIO, smbus2, pyserial, neopixel, adafruit_dht, board.)`:r[0]==="list"?`Package    Version
---------- -------
gpiozero   2.0.1
RPi.GPIO   0.7.1
adafruit-circuitpython-dht 4.0.4
adafruit-circuitpython-neopixel 6.3.12
pyserial   3.5
smbus2     0.4.3`:"pip 23.0.1 from /usr/lib/python3/dist-packages/pip (python 3.11)"}var xf=se($i(),1),Yo=se(rn(),1),L2={new:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M6 2.5h8l4.5 4.5v14.5H6z" fill="#fff" stroke="#6b7280" stroke-width="1.3"/><path d="M14 2.5V7h4.5" fill="#e5e7eb" stroke="#6b7280" stroke-width="1.3"/><circle cx="17.5" cy="17.5" r="4.5" fill="#22a33a"/><path d="M17.5 15v5M15 17.5h5" stroke="#fff" stroke-width="1.8"/></svg>',load:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M2.5 6.5h7l2 2h10v11h-19z" fill="#f2c14e" stroke="#b7862a" stroke-width="1.2"/><path d="M2.5 10h19" stroke="#d9a63a" stroke-width="1.2"/></svg>',save:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M3.5 3.5h14l3 3v14h-17z" fill="#3b6fd8" stroke="#24479a" stroke-width="1.2"/><rect x="7" y="3.5" width="9" height="6" fill="#e8eefc"/><rect x="6.5" y="13" width="11" height="7.5" rx="1" fill="#fff"/></svg>',run:'<svg viewBox="0 0 24 24" width="28" height="28"><circle cx="12" cy="12" r="10" fill="#2fa84f" stroke="#1d7a37" stroke-width="1.2"/><path d="M9.5 7.5v9l7.5-4.5z" fill="#fff"/></svg>',stop:'<svg viewBox="0 0 24 24" width="28" height="28"><path d="M8 2.5h8l5.5 5.5v8L16 21.5H8L2.5 16V8z" fill="#d93a3a" stroke="#a52222" stroke-width="1.2"/><rect x="7.5" y="10.5" width="9" height="3" rx=".6" fill="#fff"/></svg>',examples:'<svg viewBox="0 0 24 24" width="26" height="26"><path d="M4 4.5h7a2 2 0 0 1 2 2v14a2 2 0 0 0-2-2H4z" fill="#8b5cf6" stroke="#5b34c2" stroke-width="1.1"/><path d="M20 4.5h-7a2 2 0 0 0-2 2v14a2 2 0 0 1 2-2h7z" fill="#a78bfa" stroke="#5b34c2" stroke-width="1.1"/></svg>',files:'<svg viewBox="0 0 24 24" width="26" height="26"><rect x="3" y="4" width="18" height="16" rx="2" fill="#fff" stroke="#6b7280" stroke-width="1.3"/><path d="M6 8h12M6 12h12M6 16h8" stroke="#3b6fd8" stroke-width="1.6"/></svg>',zoom:'<svg viewBox="0 0 24 24" width="26" height="26"><circle cx="10.5" cy="10.5" r="6.5" fill="#fff" stroke="#6b7280" stroke-width="1.6"/><path d="M15.5 15.5l5 5" stroke="#6b7280" stroke-width="2.2"/><path d="M8 10.5h5M10.5 8v5" stroke="#2fa84f" stroke-width="1.8"/></svg>'},Jo=class{constructor(e){this.ctx=e,this.sys=e.sys,this.proc=null,this.buf=[],this.pid=0,this.running=!1,this.font=Number(localStorage.getItem("rapti.pi.thonny.font"))||14,this.build(),this.loadTabs(),this.sys.on(t=>this.onSys(t))}get kind(){return this.sys.isPico?"pico":"pi"}get fs(){return this.sys.fs}get cur(){return this.tabs[this.ti]}build(){let e=(i,s,n,o="")=>(0,H.h)("button",{class:"th-tb "+o,title:s,onclick:n},(0,H.h)("i",{html:L2[i]}),(0,H.h)("span",{},s));this.runB=e("run","Run",()=>this.run(),"th-run"),this.stopB=e("stop","Stop",()=>this.stop(),"th-stop"),this.toolbar=(0,H.h)("div",{class:"th-toolbar"},e("new","New",()=>this.newTab()),e("load","Load",()=>this.loadDialog()),e("save","Save",()=>this.save()),(0,H.h)("span",{class:"th-sep"}),this.runB,this.stopB,(0,H.h)("span",{class:"th-sep"}),e("examples","Examples",()=>this.examples()),e("files","Files",()=>this.loadDialog()),(0,H.h)("span",{class:"th-flex"}),(0,H.h)("button",{class:"th-tb th-more",title:"More",html:(0,Xr.icon)("dots",20),onclick:i=>this.menu(i.currentTarget)})),this.tabBar=(0,H.h)("div",{class:"th-tabs"}),this.edHost=(0,H.h)("div",{class:"th-editor"}),this.editor=new Uo(this.edHost,{fontSize:this.font,onChange:i=>this.edited(i)}),this.con=new bs({cls:"th-con",onKey:i=>i.ctrlKey&&(i.key==="c"||i.key==="C")&&!window.getSelection().toString()?(this.interrupt(),!0):i.ctrlKey&&(i.key==="d"||i.key==="D")?(this.softReboot(),!0):!1,extraKeys:[["Ctrl+C",()=>this.interrupt()],["Ctrl+D",()=>this.softReboot()],["\u2191",i=>i.histMove(-1)],["\u2193",i=>i.histMove(1)],["Tab",i=>i.insert("    ")],[":",i=>i.insert(":")],["(",i=>i.insert("(")],[")",i=>i.insert(")")],['"',i=>i.insert('"')]]});let t=(0,H.h)("div",{class:"th-grip"},(0,H.h)("span"));this.shellHead=(0,H.h)("div",{class:"th-shell-head"},(0,H.h)("b",{},"Output \xB7 Shell"),(0,H.h)("button",{class:"th-clear",onclick:()=>{this.con.clear(),this.showPrompt()}},"Clear")),this.shell=(0,H.h)("div",{class:"th-shell"},this.shellHead,this.con.el),this.status=(0,H.h)("div",{class:"th-status"}),this.grip=t,this.el=(0,H.h)("div",{class:"thonny"}),this.codeEl=(0,H.h)("div",{class:"thonny th-code"}),this.outEl=(0,H.h)("div",{class:"thonny th-out"}),this.join(),this.dragGrip(t),this.updateStatus()}joined(){return this.join(),this.el}join(){this.mode!=="joined"&&(this.mode="joined",this.el.replaceChildren(this.toolbar,this.tabBar,this.edHost,this.grip,this.shell,this.status))}splitInto(e,t){this.mode!=="split"&&(this.mode="split",this.shell.style.flex="",this.codeEl.replaceChildren(this.toolbar,this.tabBar,this.edHost,this.status),this.outEl.replaceChildren(this.shell)),this.codeEl.parentNode!==e&&e.appendChild(this.codeEl),this.outEl.parentNode!==t&&t.appendChild(this.outEl)}dragGrip(e){let t=null,i=0;e.addEventListener("pointerdown",n=>{t=n.clientY,i=this.shell.getBoundingClientRect().height,e.setPointerCapture(n.pointerId)}),e.addEventListener("pointermove",n=>{if(t==null)return;let o=this.el.getBoundingClientRect().height,l=Math.max(90,Math.min(o-160,i-(n.clientY-t)));this.shell.style.flex=`0 0 ${l}px`});let s=()=>{t=null,this.editor.refresh()};e.addEventListener("pointerup",s),e.addEventListener("pointercancel",s)}updateStatus(){let e=xf.BOARDS[this.sys.board];this.status.innerHTML="",this.sys.isPico?this.status.append((0,H.h)("span",{},`MicroPython (${e.name})`),(0,H.h)("span",{class:"th-port"},"\u2022 Board CDC @ /dev/ttyACM0")):this.status.append((0,H.h)("span",{},"Local Python 3"),(0,H.h)("span",{class:"th-port"},"\u2022 /usr/bin/python3")),this.runB.classList.toggle("busy",this.running)}tabsKey(){return"rapti.pi.thonny."+this.kind}loadTabs(){this.loadedKind=this.kind;let e=null;try{e=JSON.parse(localStorage.getItem(this.tabsKey())||"null")}catch{e=null}if(this.tabs=[],e&&Array.isArray(e.tabs)){for(let t of e.tabs)t.path&&this.fs.isFile(t.path)?this.tabs.push({path:t.path,name:Ae(t.path),text:t.dirty?t.text:this.fs.read(t.path),dirty:!!t.dirty}):t.path||this.tabs.push({path:null,name:t.name||"<untitled>",text:t.text||"",dirty:!!t.dirty});this.ti=Math.min(e.ti||0,this.tabs.length-1)}if(!this.tabs.length){let t=this.sys.isPico?"/main.py":"/home/pi/blink.py";this.fs.isFile(t)?this.tabs.push({path:t,name:Ae(t),text:this.fs.read(t),dirty:!1}):this.tabs.push({path:null,name:"<untitled>",text:"",dirty:!1}),this.ti=0}this.showTab(this.ti)}saveTabs(){let e={ti:this.ti,tabs:this.tabs.map(t=>({path:t.path,name:t.name,dirty:t.dirty,text:t.dirty||!t.path?t.text:void 0}))};try{localStorage.setItem(this.tabsKey(),JSON.stringify(e))}catch{}}drawTabs(){this.tabBar.innerHTML="",this.tabs.forEach((e,t)=>{let i=(0,H.h)("button",{class:"th-tab-x","aria-label":"Close",onclick:n=>{n.stopPropagation(),this.closeTab(t)}},"\xD7"),s=(this.sys.isPico&&e.path?"[ "+e.name+" ]":e.name)+(e.dirty?" *":"");this.tabBar.appendChild((0,H.h)("div",{class:"th-tab"+(t===this.ti?" active":""),onclick:()=>this.showTab(t)},(0,H.h)("span",{},s),i))})}showTab(e){this.cur&&this.ti!==e&&(this.cur.text=this.editor.value),this.ti=e,this.editor.load(this.cur.text),this.drawTabs(),this.saveTabs()}edited(e){let t=this.cur;t.text=e,t.dirty||(t.dirty=!0,this.drawTabs()),clearTimeout(this.tabSaveT),this.tabSaveT=setTimeout(()=>this.saveTabs(),600)}newTab(e="<untitled>",t="",i=null){this.cur&&(this.cur.text=this.editor.value),this.tabs.push({path:i,name:e,text:t,dirty:!i&&!!t}),this.showTab(this.tabs.length-1)}async closeTab(e){let t=this.tabs[e];e===this.ti&&(t.text=this.editor.value),!(t.dirty&&t.text.trim()&&!await(0,H.confirmDialog)("Close tab",`Close ${t.name} without saving?`,"Close",!0))&&(this.tabs.splice(e,1),this.tabs.length||this.tabs.push({path:null,name:"<untitled>",text:"",dirty:!1}),this.ti=Math.min(this.ti>=e?Math.max(0,this.ti-1):this.ti,this.tabs.length-1),this.editor.load(this.cur.text),this.drawTabs(),this.saveTabs())}open(e){let t=this.tabs.findIndex(s=>s.path===e);if(t>=0){this.showTab(t);return}if(!this.fs.isFile(e)){(0,H.toast)("File not found: "+e,"error");return}let i=this.cur;if(i&&!i.path&&!i.dirty&&!this.editor.value.trim()){i.path=e,i.name=Ae(e),i.text=this.fs.read(e),i.dirty=!1,this.showTab(this.ti),this.editor.load(i.text);return}this.newTab(Ae(e),this.fs.read(e),e),this.cur.dirty=!1,this.drawTabs()}async save(e=!1){let t=this.cur;t.text=this.editor.value;let i=t.path;if(!i||e){let s=this.sys.isPico?"Raspberry Pi Pico":"/home/pi",n=await(0,H.promptDialog)(`Save to ${s} as`,t.path?Ae(t.path):t.name.startsWith("<")?"untitled.py":t.name);if(!n||(i=ue(n.endsWith(".py")||n.includes(".")?n:n+".py",this.sys.home),this.fs.isFile(i)&&i!==t.path&&!await(0,H.confirmDialog)("Replace file",`${Ae(i)} already exists. Replace it?`,"Replace",!0)))return!1}try{this.fs.write(i,t.text)}catch(s){return(0,H.toast)(s.message,"error"),!1}return t.path=i,t.name=Ae(i),t.dirty=!1,this.drawTabs(),this.saveTabs(),this.sys.emit("files"),!0}loadDialog(){let e=this.fs,t=this.cur&&this.cur.path?Nt(this.cur.path):this.sys.home,i=(0,H.h)("div",{class:"th-files"}),s=(0,H.h)("div",{class:"th-files-path"}),n=()=>{i.innerHTML="",s.textContent=this.sys.isPico?"Raspberry Pi Pico: "+t:"This computer: "+t,t!=="/"&&i.appendChild((0,H.h)("button",{class:"th-file dir",onclick:()=>{t=Nt(t),n()}},(0,H.h)("i",{html:(0,Xr.icon)("back",18)}),(0,H.h)("span",{},"..")));let l=e.list(t).filter(a=>!a.startsWith("."));l.sort((a,h)=>e.isDir(ue(h,t))-e.isDir(ue(a,t))||a.localeCompare(h));for(let a of l){let h=ue(a,t),c=e.isDir(h),u=(0,H.h)("div",{class:"th-file-row"},(0,H.h)("button",{class:"th-file"+(c?" dir":""),onclick:()=>{c?(t=h,n()):(o.close(),this.open(h))}},(0,H.h)("i",{html:(0,Xr.icon)(c?"folder":a.endsWith(".py")?"code":"book",18)}),(0,H.h)("span",{},a),c?null:(0,H.h)("small",{},Q2(e.stat(h).size))),c?null:(0,H.h)("button",{class:"icon-btn","aria-label":"Delete",html:(0,Xr.icon)("trash",17),onclick:async()=>{await(0,H.confirmDialog)("Delete",`Delete ${a}?`,"Delete",!0)&&(e.remove(h),this.sys.emit("files"),n())}}));i.appendChild(u)}l.length||i.appendChild((0,H.h)("p",{class:"muted th-empty"},"Empty folder"))};n();let o=new H.Sheet({title:this.sys.isPico?"Open from Raspberry Pi Pico":"Open file",icon:"folder",content:(0,H.h)("div",{},s,i)}).open()}examples(){let e=this.sys.isPico,t=(e?Yo.PICO_EXAMPLES:Yo.PI_EXAMPLES).filter(n=>!n.boards||n.boards.includes(this.sys.board)),i=(0,H.h)("div",{class:"th-ex-list"});for(let n of t)i.appendChild((0,H.h)("button",{class:"th-ex",onclick:()=>{s.close(),this.openExample(n)}},(0,H.h)("b",{},n.title),(0,H.h)("span",{},n.file+" \xB7 "+n.tags.join(", "))));let s=new H.Sheet({title:e?"MicroPython examples":"Python examples",icon:"book",content:i,height:"78vh"}).open()}async openExample(e){if(this.sys.isPico)this.newTab(e.file,e.code);else{let t="/home/pi/"+e.file;this.fs.isFile(t)||this.fs.write(t,e.code),this.open(t)}if(e.circuit)this.ctx.wire&&this.ctx.wire(e),(0,H.toast)("The circuit is built on the Circuit tab","ok");else if(e.parts&&e.parts.length){let t=e.parts.map(i=>i.type).join(", ");this.ctx.wire&&this.ctx.wire(e),(0,H.toast)(`Wired on the Circuit tab: ${t}`,"ok")}}menu(e){let t=this.sys.isPico;(0,H.popupMenu)(e,[{icon:"save",label:"Save as\u2026",action:()=>this.save(!0)},{icon:"close",label:"Close tab",action:()=>this.closeTab(this.ti)},{icon:"search",label:"Find in file",action:()=>this.editor.search()},"-",{icon:"plus",label:"Zoom in",action:()=>this.zoom(1)},{icon:"minus",label:"Zoom out",action:()=>this.zoom(-1)},"-",{icon:"stop",label:"Interrupt execution",hint:"Ctrl+C",action:()=>this.interrupt()},{icon:"restart",label:t?"Send EOF / Soft reboot":"Restart backend",hint:"Ctrl+D",action:()=>this.softReboot()},{icon:"eraser",label:"Clear shell",action:()=>{this.con.clear(),this.showPrompt()}}])}zoom(e){this.font=Math.max(10,Math.min(24,this.font+e)),this.editor.setFontSize(this.font),this.el.style.setProperty("--th-font",this.font+"px");try{localStorage.setItem("rapti.pi.thonny.font",this.font)}catch{}}onSys(e){e==="board"?(this.cur&&(this.cur.text=this.editor.value),this.saveTabs(),this.proc=null,this.buf=[],this.running=!1,this.con.hideInput(),this.con.clear(),this.loadTabs(),this.updateStatus(),this.visible&&this.ensureBackend()):e==="proc"&&this.proc&&this.sys.proc!==this.proc&&(this.proc=null,this.buf=[],this.running=!1,++this.pid,this.con.hideInput(),this.con.writeln(""),this.con.writeln(this.sys.isPico?"Connection lost (board reset). Press Stop to reconnect.":"Backend terminated. Press Stop to restart.","fg-K"),this.updateStatus())}banner(){if(this.sys.isPico){let e=xf.BOARDS[this.sys.board];return`MicroPython v1.29.0 on 2026-10-10; ${{pico:"Raspberry Pi Pico",picow:"Raspberry Pi Pico W",pico2:"Raspberry Pi Pico2",pico2w:"Raspberry Pi Pico 2 W"}[e.id]} with ${e.mcu}
Type "help()" for more information.`}return"Python 3.11.2 (/usr/bin/python3)"}async ensureBackend(e=!1){if(this.proc&&!this.proc.dead&&this.sys.proc===this.proc)return this.proc;if(this.starting)return this.starting;this.proc&&(this.proc.dead||this.sys.proc!==this.proc)&&(this.proc=null),this.starting=(async()=>{++this.pid,this.con.hideInput();let i=await this.sys.spawn({owner:this,cwd:this.sys.home,out:(s,n)=>{this.proc===i&&(this.con.write(s,n==="err"?"err":""),n==="err"&&(this.errText+=s))},readLine:s=>(++this.pid,this.sys.emit("input"),this.con.prompt(s,{keepHistory:!1}).then(n=>n??""))});return this.proc=i,e||this.con.writeln(this.banner()),i})().finally(()=>{this.starting=null});let t=await this.starting;return e||this.showPrompt(),t}showPrompt(){let e=this.proc;if(!e||e.dead||this.running)return;let t=++this.pid,i=this.buf.length?this.buf[this.buf.length-1]:"",s=this.buf.length?/^(\s*)/.exec(i)[1]+(/:\s*(#.*)?$/.test(i)?"    ":""):"";this.con.prompt(this.buf.length?"... ":">>> ",{value:s,focus:!1}).then(n=>this.onLine(t,n))}async onLine(e,t){if(e!==this.pid)return;if(t==null){this.buf=[],this.showPrompt();return}if(!this.buf.length&&!t.trim()){this.showPrompt();return}if(this.buf.push(t),kf(this.buf,t)){this.showPrompt();return}let i=this.buf.join(`
`).replace(/\s+$/,"")+`
`;this.buf=[];let s=/^%Run\s+(\S+)/.exec(i.trim());if(s){let o=ue(s[1],this.sys.home);if(this.fs.isFile(o))return this.open(o),this.run(!0);this.con.writeln(`%Run: file not found: ${s[1]}`,"err"),this.showPrompt();return}if(/^%?(cd|ls|clear)\b/.test(i.trim())){/clear/.test(i)?this.con.clear():this.con.writeln(this.fs.list(this.sys.home).join("  ")),this.showPrompt();return}let n=this.proc;this.running=!0,this.updateStatus(),await n.replExec(i),n===this.proc&&(this.running=!1,this.updateStatus(),this.showPrompt())}async run(e=!1){this.running&&this.proc&&this.sys.isPico&&await this.stopRun();let t=this.cur;t.text=this.editor.value,!e&&this.ctx.onRun&&this.ctx.onRun();let i=this.sys.isPico;if(!i&&(!t.path||t.dirty)&&!await this.save())return;let s=i?t.name.startsWith("<")?"<stdin>":t.name:t.path;++this.pid,this.con.hideInput(),this.buf=[],this.dropBackend(),i&&this.con.writeln("MPY: soft reboot","fg-K");let n=await this.ensureBackend(!0);e||this.con.write(">>> "),this.con.writeln(i?(t.path,"%Run -c $EDITOR_CONTENT"):`%Run ${Ae(t.path)}`,"th-magic"),this.running=!0,this.errText="",this.updateStatus(),this.sys.emit("run");let o;if(i?o=await n.runSource(t.text,s==="<stdin>"?"main.py":s):(await n.exec(`import sys, os
sys.argv = [${JSON.stringify(t.path)}]
os.chdir(${JSON.stringify(Nt(t.path))})`),o=await n.runFile(t.path)),n===this.proc){if(this.running=!1,this.updateStatus(),this.sys.emit("run"),o===1){let l=new RegExp(`File "${(i?s==="<stdin>"?"main.py":s:t.path).replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}", line (\\d+)`,"g"),a,h=null;for(;a=l.exec(this.errText);)h=Number(a[1]);h&&this.editor.gotoLine(h)}this.sys.syncBack(n),this.showPrompt()}}dropBackend(){let e=this.proc;this.proc=null,e&&!e.dead&&this.sys.proc===e&&this.sys.killProcess()}interrupt(){if(this.proc&&this.proc.busy){this.proc.interrupt();return}this.con.waiting&&(this.buf=[],this.con.cancel("^C"),this.proc&&!this.running&&this.con.writeln("KeyboardInterrupt","err"),this.showPrompt())}async stopRun(){let e=this.proc;e&&await e.stop(800)}async stop(){++this.pid,this.con.hideInput(),this.sys.isPico&&this.proc&&this.proc.busy&&(this.proc.interrupt(),await new Promise(e=>setTimeout(e,150))),this.dropBackend(),this.running=!1,this.buf=[],this.updateStatus(),this.sys.emit("run"),this.con.writeln(""),this.sys.isPico&&this.con.writeln("MPY: soft reboot","fg-K"),await this.ensureBackend()}async softReboot(){if(!this.sys.isPico)return this.stop();++this.pid,this.con.hideInput(),this.dropBackend(),this.running=!1,this.buf=[],this.con.writeln("MPY: soft reboot","fg-K");let e=await this.ensureBackend(!0);if(this.fs.isFile("/main.py")){if(this.running=!0,this.updateStatus(),this.sys.emit("run"),await e.runFile("/main.py"),e!==this.proc)return;this.running=!1,this.updateStatus(),this.sys.emit("run")}this.con.writeln(this.banner()),this.showPrompt()}shown(){this.visible=!0,this.loadedKind!==this.kind&&this.onSys("board"),this.editor.refresh(),(!this.proc||this.proc.dead||this.sys.proc!==this.proc)&&(!this.sys.proc||this.sys.owner===this||this.sys.owner==null)&&this.ensureBackend()}hidden(){this.visible=!1,this.cur&&(this.cur.text=this.editor.value),this.saveTabs()}};function Q2(r){return r<1024?r+" B":(r/1024).toFixed(1)+" KB"}var I=se(ii(),1),Ko=se(Qi(),1);var w0=se($i(),1),k0=se(O0(),1),v0='<svg viewBox="0 0 32 32" width="22" height="22"><path d="M10 5c-2-1.5-5-.5-4.5 1.5.8 2 3 2.6 5.2 2.5zM22 5c2-1.5 5-.5 4.5 1.5-.8 2-3 2.6-5.2 2.5z" fill="#3ec43e"/><g fill="#c51a4a"><circle cx="16" cy="12" r="4"/><circle cx="10" cy="15.5" r="3.8"/><circle cx="22" cy="15.5" r="3.8"/><circle cx="12.6" cy="21" r="3.8"/><circle cx="19.4" cy="21" r="3.8"/><circle cx="16" cy="26" r="3.3"/><circle cx="7.5" cy="21.5" r="2.5"/><circle cx="24.5" cy="21.5" r="2.5"/></g></svg>',ds={terminal:'<svg viewBox="0 0 24 24" width="100%" height="100%"><rect x="2" y="3.5" width="20" height="17" rx="2.5" fill="#2d2d2d" stroke="#111"/><path d="M6 9l3.5 3L6 15" stroke="#7ee787" stroke-width="1.8" fill="none"/><path d="M11 15.5h6" stroke="#ddd" stroke-width="1.8"/></svg>',thonny:'<svg viewBox="0 0 24 24" width="100%" height="100%"><rect x="2" y="2" width="20" height="20" rx="5" fill="#3a7bd5"/><text x="12" y="17" text-anchor="middle" font-size="14" font-weight="700" fill="#fff" font-family="sans-serif">Th</text></svg>',files:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M2 6h7.5l2 2.2H22V20H2z" fill="#4a90d9"/><path d="M2 9.5h20V20H2z" fill="#6aaef0"/></svg>',editor:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 2.5h10l4.5 4.5v14.5H5z" fill="#fff" stroke="#888"/><path d="M8 10h8M8 13h8M8 16h5" stroke="#3a7bd5" stroke-width="1.4"/></svg>',chromium:'<svg viewBox="0 0 24 24" width="100%" height="100%"><circle cx="12" cy="12" r="10" fill="#4285f4"/><path d="M12 2a10 10 0 0 1 8.7 5H12z" fill="#ea4335"/><path d="M3.3 7A10 10 0 0 0 7.6 21l4.4-7.5L7.7 7z" fill="#34a853" opacity=".9"/><circle cx="12" cy="12" r="4.4" fill="#fff"/><circle cx="12" cy="12" r="3.3" fill="#4285f4"/></svg>',calc:'<svg viewBox="0 0 24 24" width="100%" height="100%"><rect x="4" y="2" width="16" height="20" rx="2.5" fill="#555"/><rect x="6.5" y="4.5" width="11" height="4" rx="1" fill="#b9f6ca"/><g fill="#ddd"><rect x="6.5" y="11" width="3" height="2.5" rx=".5"/><rect x="10.5" y="11" width="3" height="2.5" rx=".5"/><rect x="14.5" y="11" width="3" height="2.5" rx=".5"/><rect x="6.5" y="15" width="3" height="2.5" rx=".5"/><rect x="10.5" y="15" width="3" height="2.5" rx=".5"/></g><rect x="14.5" y="15" width="3" height="5.5" rx=".5" fill="#ff9f43"/></svg>',config:'<svg viewBox="0 0 24 24" width="100%" height="100%"><circle cx="12" cy="12" r="10" fill="#c51a4a"/><path d="M12 7.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 2.3a2.2 2.2 0 1 1 0 4.4 2.2 2.2 0 0 1 0-4.4z" fill="#fff"/><g stroke="#fff" stroke-width="2"><path d="M12 3.5v2.5M12 18v2.5M3.5 12H6M18 12h2.5M6 6l1.8 1.8M16.2 16.2L18 18M6 18l1.8-1.8M16.2 7.8L18 6"/></g></svg>',trash:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 7h14l-1.3 14H6.3z" fill="#e8e8e8" stroke="#999"/><rect x="4" y="4.5" width="16" height="2.5" rx="1" fill="#bbb"/><path d="M9.5 10v8M12 10v8M14.5 10v8" stroke="#aaa"/></svg>',py:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 2.5h10l4.5 4.5v14.5H5z" fill="#fff" stroke="#999"/><path d="M12 8c-2.5 0-2.4 1-2.4 1v1.3h2.5v.5H8.6S7 10.6 7 13.2s1.4 2.5 1.4 2.5h.9v-1.2s0-1.4 1.4-1.4h2.4s1.3 0 1.3-1.3V9.4S14.6 8 12 8z" fill="#3776ab"/><path d="M12 19c2.5 0 2.4-1 2.4-1v-1.3h-2.5v-.5h3.5s1.6.2 1.6-2.4-1.4-2.5-1.4-2.5h-.9v1.2s0 1.4-1.4 1.4H11s-1.3 0-1.3 1.3v2.4S9.4 19 12 19z" fill="#ffd43b"/></svg>',txt:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M5 2.5h10l4.5 4.5v14.5H5z" fill="#fff" stroke="#999"/><path d="M8 10h8M8 13h8M8 16h8" stroke="#999" stroke-width="1.2"/></svg>',folder:'<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M2 5.5h7.5l2 2.2H22V20H2z" fill="#4a90d9"/><path d="M2 9h20v11H2z" fill="#6aaef0"/></svg>'},Jr={terminal:{title:"Terminal",ic:"terminal",multi:!0,w:640,h:400},thonny:{title:"Thonny",ic:"thonny",w:760,h:560},files:{title:"File Manager",ic:"files",w:620,h:440},editor:{title:"Text Editor",ic:"editor",multi:!0,w:560,h:420},chromium:{title:"Chromium",ic:"chromium",w:720,h:480},calc:{title:"Calculator",ic:"calc",w:280,h:390},config:{title:"Raspberry Pi Configuration",ic:"config",w:520,h:460}},q2=[["Programming",["thonny"]],["Internet",["chromium"]],["Accessories",["files","terminal","editor","calc"]],["Preferences",["config"]]],Zo=class{constructor(e){this.ctx=e,this.sys=e.sys,this.wins=[],this.z=10,this.build()}get fs(){return this.sys.piFs}build(){this.menuBtn=(0,I.h)("button",{class:"dk-pbtn dk-rasp","aria-label":"Menu",html:v0,onclick:i=>{i.stopPropagation(),this.toggleMenu()}});let e=i=>(0,I.h)("button",{class:"dk-pbtn",title:Jr[i].title,html:`<i class="dk-ic">${ds[Jr[i].ic]}</i>`,onclick:()=>this.open(i)});this.taskbar=(0,I.h)("div",{class:"dk-tasks"}),this.clock=(0,I.h)("span",{class:"dk-clock"});let t=(0,I.h)("div",{class:"dk-tray"},(0,I.h)("span",{class:"dk-tr",title:"Bluetooth",html:'<svg viewBox="0 0 24 24" width="17" height="17"><path d="M7 7l10 10-5 4V3l5 4L7 17" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>'}),(0,I.h)("span",{class:"dk-tr",title:"Wi-Fi: connected to RaptiNet",html:'<svg viewBox="0 0 24 24" width="17" height="17"><path d="M2 9a15 15 0 0 1 20 0M5 12.5a10.5 10.5 0 0 1 14 0M8.5 16a5.5 5.5 0 0 1 7 0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="19.5" r="1.6" fill="currentColor"/></svg>'}),(0,I.h)("span",{class:"dk-tr",title:"Volume",html:'<svg viewBox="0 0 24 24" width="17" height="17"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'}),this.clock);this.panel=(0,I.h)("div",{class:"dk-panel"},this.menuBtn,e("chromium"),e("files"),e("terminal"),(0,I.h)("span",{class:"dk-psep"}),this.taskbar,t),this.menu=(0,I.h)("div",{class:"dk-menu hidden"}),this.drawMenu(),this.icons=(0,I.h)("div",{class:"dk-icons"}),this.area=(0,I.h)("div",{class:"dk-area"},this.icons),this.area.addEventListener("click",()=>this.closeMenu()),this.el=(0,I.h)("div",{class:"desktop"},this.panel,this.area,this.menu),this.drawIcons(),this.sys.on(i=>{i==="files"&&(this.drawIcons(),this.wins.forEach(s=>s.app.refresh&&s.app.refresh()))}),this.tick()}tick(){let e=new Date;this.clock.textContent=`${String(e.getHours()).padStart(2,"0")}:${String(e.getMinutes()).padStart(2,"0")}`,clearTimeout(this.clockT),this.clockT=setTimeout(()=>this.tick(),(60-e.getSeconds())*1e3+50)}drawMenu(){this.menu.innerHTML="";for(let[e,t]of q2){let i=(0,I.h)("div",{class:"dk-sub"});for(let s of t)i.appendChild((0,I.h)("button",{class:"dk-mi",onclick:()=>{this.closeMenu(),this.open(s)}},(0,I.h)("i",{class:"dk-ic",html:ds[Jr[s].ic]}),(0,I.h)("span",{},Jr[s].title)));this.menu.appendChild((0,I.h)("div",{class:"dk-cat"},(0,I.h)("div",{class:"dk-cat-t"},e),i))}this.menu.appendChild((0,I.h)("div",{class:"dk-msep"})),this.menu.appendChild((0,I.h)("button",{class:"dk-mi",onclick:()=>{this.closeMenu(),this.help()}},(0,I.h)("i",{class:"dk-ic",html:(0,Ko.icon)("help",20)}),(0,I.h)("span",{},"Help"))),this.menu.appendChild((0,I.h)("button",{class:"dk-mi",onclick:()=>{this.closeMenu(),this.shutdownDialog()}},(0,I.h)("i",{class:"dk-ic",html:(0,Ko.icon)("power",20)}),(0,I.h)("span",{},"Shutdown\u2026")))}toggleMenu(){this.menu.classList.toggle("hidden")}closeMenu(){this.menu.classList.add("hidden")}drawIcons(){this.icons.innerHTML="";let e=(t,i,s)=>(0,I.h)("button",{class:"dk-dicon",ondblclick:s,onclick:n=>{n.detail<=1&&(this.icons.querySelectorAll(".sel").forEach(o=>o.classList.remove("sel")),n.currentTarget.classList.add("sel"),clearTimeout(this.tapT),this.tapT=setTimeout(()=>{},300))},onpointerup:n=>{n.pointerType==="touch"&&s()}},(0,I.h)("i",{html:ds[t]}),(0,I.h)("span",{},i));this.icons.appendChild(e("trash","Wastebasket",()=>(0,I.toast)("The wastebasket is empty"))),this.icons.appendChild(e("folder","pi",()=>this.open("files","/home/pi")));for(let t of this.fs.list("/home/pi/Desktop")){let i="/home/pi/Desktop/"+t;this.icons.appendChild(e(this.fs.isDir(i)?"folder":t.endsWith(".py")?"py":"txt",t,()=>this.openPath(i)))}}get phone(){return this.el.clientWidth<700}open(e,t){let i=Jr[e];if(!i.multi){let c=this.wins.find(u=>u.id===e);if(c)return this.focus(c),c.app.openArg&&c.app.openArg(t),c}let s=(0,I.h)("div",{class:"dk-wbody"}),n=(0,I.h)("span",{class:"dk-wtitle"},i.title),o={id:e,def:i,body:s,titleEl:n,el:null,app:null,max:!0},l=(c,u,p,y)=>(0,I.h)("button",{class:"dk-wbtn "+c,"aria-label":y,html:u,onclick:O=>{O.stopPropagation(),p()}}),a=(0,I.h)("div",{class:"dk-wbar"},(0,I.h)("i",{class:"dk-ic",html:ds[i.ic]}),n,l("min",'<svg viewBox="0 0 12 12" width="12" height="12"><path d="M2 9h8" stroke="currentColor" stroke-width="1.6"/></svg>',()=>this.minimize(o),"Minimise"),l("max",'<svg viewBox="0 0 12 12" width="12" height="12"><rect x="2" y="2" width="8" height="8" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>',()=>this.toggleMax(o),"Maximise"),l("close",'<svg viewBox="0 0 12 12" width="12" height="12"><path d="M2.5 2.5l7 7M9.5 2.5l-7 7" stroke="currentColor" stroke-width="1.6"/></svg>',()=>this.close(o),"Close"));o.el=(0,I.h)("div",{class:"dk-win"},a,s),o.el.addEventListener("pointerdown",()=>this.focus(o),!0),this.dragWin(o,a);let h=this.wins.length;return Object.assign(o.el.style,{width:i.w+"px",height:i.h+"px",left:30+h*26+"px",top:14+h*22+"px"}),o.max=this.phone||i.w>this.el.clientWidth-20,o.el.classList.toggle("max",o.max),this.area.appendChild(o.el),this.wins.push(o),o.task=(0,I.h)("button",{class:"dk-task",onclick:()=>o.el.classList.contains("min")||this.top!==o?this.focus(o):this.minimize(o)},(0,I.h)("i",{class:"dk-ic",html:ds[i.ic]}),(0,I.h)("span",{},i.title)),this.taskbar.appendChild(o.task),o.app=this.makeApp(e,o,t),this.focus(o),o}makeApp(e,t,i){let s=n=>{t.titleEl.textContent=n,t.task.lastChild.textContent=n};switch(e){case"terminal":{let n=new Xo({sys:this.sys,onExit:()=>this.close(t),openThonny:o=>this.openThonny(o),openFile:o=>this.openPath(o),openUrl:o=>this.open("chromium",o||"http://start.rapti.net/")});return t.body.appendChild(n.el),s("pi@raspberrypi: ~"),setTimeout(()=>n.con.focus(),60),{term:n,destroy:()=>{n.alive=!1,n.con.hideInput(),this.sys.owner===n&&this.sys.killProcess()}}}case"thonny":{let n=this.ctx.thonny;return t.body.appendChild(n.joined()),n.shown(),i&&n.open(i),s("Thonny  -  "+(n.cur&&n.cur.path?n.cur.path:"<untitled>")),{openArg:o=>{o&&n.open(o)},destroy:()=>{n.hidden()},thonny:!0}}case"files":return this.fileManager(t,i||"/home/pi",s);case"editor":return this.textEditor(t,i,s);case"chromium":return this.chromium(t,i,s);case"calc":return this.calculator(t);case"config":return this.configApp(t);default:return{}}}dragWin(e,t){let i=0,s=0,n=0,o=0,l=!1;t.addEventListener("pointerdown",a=>{e.max||a.target.closest("button")||(l=!0,i=a.clientX,s=a.clientY,n=e.el.offsetLeft,o=e.el.offsetTop,t.setPointerCapture(a.pointerId))}),t.addEventListener("pointermove",a=>{l&&(e.el.style.left=Math.max(-200,n+a.clientX-i)+"px",e.el.style.top=Math.max(0,o+a.clientY-s)+"px")}),t.addEventListener("pointerup",()=>{l=!1}),t.addEventListener("dblclick",()=>this.toggleMax(e))}focus(e){e.el.classList.remove("min"),e.el.style.zIndex=++this.z,this.top=e,this.wins.forEach(t=>t.task.classList.toggle("active",t===e)),e.app&&e.app.thonny&&this.ctx.thonny.editor.refresh()}minimize(e){e.el.classList.add("min"),e.task.classList.remove("active");let t=this.wins.filter(i=>i!==e&&!i.el.classList.contains("min"));this.top=t[t.length-1]||null}toggleMax(e){e.max=!e.max,e.el.classList.toggle("max",e.max),e.app&&e.app.thonny&&this.ctx.thonny.editor.refresh()}close(e){e.app&&e.app.destroy&&e.app.destroy(),e.el.remove(),e.task.remove(),this.wins=this.wins.filter(t=>t!==e)}thonnyWin(){return this.wins.find(e=>e.id==="thonny")}reclaimThonny(){let e=this.thonnyWin();e&&!e.body.contains(this.ctx.thonny.el)&&e.body.appendChild(this.ctx.thonny.joined())}openThonny(e){this.open("thonny",e)}openPath(e){this.fs.isDir(e)?this.open("files",e):e.endsWith(".py")?this.openThonny(e):this.open("editor",e)}fileManager(e,t,i){let s=t,n=[],o=this.fs,l=(0,I.h)("input",{class:"fm-path",value:s,onkeydown:v=>{v.key==="Enter"&&O(ue(l.value,s))}}),a=(0,I.h)("div",{class:"fm-list"}),h=(0,I.h)("div",{class:"fm-side"});for(let[v,k]of[["Home","/home/pi"],["Desktop","/home/pi/Desktop"],["Documents","/home/pi/Documents"],["Downloads","/home/pi/Downloads"],["projects","/home/pi/projects"],["Filesystem root","/"]])h.appendChild((0,I.h)("button",{class:"fm-place",onclick:()=>O(k)},(0,I.h)("i",{class:"dk-ic",html:ds.folder}),(0,I.h)("span",{},v)));let c=(v,k,T)=>(0,I.h)("button",{class:"fm-tb",title:k,html:(0,Ko.icon)(v,18),onclick:T}),u=(0,I.h)("div",{class:"fm-status"}),p=()=>{l.value=s,i(s==="/home/pi"?"pi":Ae(s)||"/"),a.innerHTML="";let v=[];try{v=o.list(s).filter(k=>!k.startsWith("."))}catch{v=[]}v.sort((k,T)=>o.isDir(ue(T,s))-o.isDir(ue(k,s))||k.localeCompare(T));for(let k of v){let T=ue(k,s),C=o.isDir(T),Q=(0,I.h)("button",{class:"fm-item",onclick:()=>C?O(T):this.openPath(T)},(0,I.h)("i",{html:ds[C?"folder":k.endsWith(".py")?"py":"txt"]}),(0,I.h)("span",{},k));Q.addEventListener("contextmenu",R=>{R.preventDefault(),y(T,k)});let A;Q.addEventListener("pointerdown",()=>{A=setTimeout(()=>{A=null,y(T,k)},600)}),Q.addEventListener("pointerup",()=>clearTimeout(A)),Q.addEventListener("pointerleave",()=>clearTimeout(A)),a.appendChild(Q)}u.textContent=`${v.length} items \xB7 Free space: 22.4 GB (Total: 29.0 GB)`},y=async(v,k)=>{let T=await(0,I.dialog)({title:k,body:"<p>What do you want to do?</p>",actions:[{label:"Rename",value:"ren",cls:"btn-ghost"},{label:"Delete",value:"del",cls:"btn-danger"},{label:"Cancel",value:null,cls:"btn-ghost"}]});if(T==="del")await(0,I.confirmDialog)("Delete",`Delete ${k}?`,"Delete",!0)&&(o.remove(v,!0),this.sys.emit("files"));else if(T==="ren"){let C=await(0,I.promptDialog)("Rename",k);C&&C!==k&&(o.move(v,ue(C,Nt(v))),this.sys.emit("files"))}},O=v=>{if(!o.isDir(v)){(0,I.toast)("Not a folder","error");return}v!==s&&n.push(s),s=v,p()},b=(0,I.h)("div",{class:"fm-bar"},c("arrowLeft","Back",()=>{n.length&&(s=n.pop(),p())}),c("back","Up",()=>O(Nt(s))),c("home","Home",()=>O("/home/pi")),l,c("folder","New folder",async()=>{let v=await(0,I.promptDialog)("New folder","New Folder");v&&(o.mkdir(ue(v,s),!0),this.sys.emit("files"))}),c("plus","New file",async()=>{let v=await(0,I.promptDialog)("New file","new.py");if(v){let k=ue(v,s);o.exists(k)||o.write(k,""),this.sys.emit("files"),this.openPath(k)}}));return e.body.appendChild((0,I.h)("div",{class:"fm"},b,(0,I.h)("div",{class:"fm-main"},h,a),u)),p(),{refresh:p,openArg:v=>{v&&O(v)}}}textEditor(e,t,i){let s=this.fs,n=(0,I.h)("textarea",{class:"te-text",spellcheck:"false",autocapitalize:"off"}),o=t||null,l=!1,a=()=>i(`${l?"*":""}${o?Ae(o):"Untitled"} - Text Editor`);o&&s.isFile(o)&&(n.value=s.read(o)),n.addEventListener("input",()=>{l||(l=!0,a())});let h=async()=>{if(!o){let p=await(0,I.promptDialog)("Save as","/home/pi/Documents/untitled.txt");if(!p)return;o=ue(p,"/home/pi")}s.write(o,n.value),l=!1,a(),this.sys.emit("files"),(0,I.toast)("Saved "+Ae(o),"ok")},c=async()=>{let p=await(0,I.promptDialog)("Open file",o||"/home/pi/Documents/notes.txt");if(!p)return;let y=ue(p,"/home/pi");if(!s.isFile(y)){(0,I.toast)("No such file","error");return}o=y,n.value=s.read(y),l=!1,a()},u=(p,y)=>(0,I.h)("button",{class:"te-mb",onclick:y},p);return e.body.appendChild((0,I.h)("div",{class:"te"},(0,I.h)("div",{class:"te-menu"},u("New",()=>{o=null,n.value="",l=!1,a()}),u("Open",c),u("Save",h),u("Save As",async()=>{let p=o;o=null,await h(),o||(o=p)})),n)),n.addEventListener("keydown",p=>{p.ctrlKey&&p.key==="s"&&(p.preventDefault(),h())}),a(),{}}chromium(e,t,i){let s=this.sys.net,n=new k0.VirtualBrowser({net:s,origin:this.sys.netDev,home:"http://start.rapti.net/",start:!1,bookmarks:[["Start","http://start.rapti.net/"],["RAPTI","http://rapti.net/"],["Google","https://www.google.com/"],["Wikipedia","https://en.wikipedia.org/"],["Dashboard","http://dashboard.rapti.net/"],["localhost:5000","http://localhost:5000/"],["localhost:8000","http://localhost:8000/"],["Weather","http://wttr.in/Dhaka"],["HiveMQ","http://www.hivemq.com/demos/websocket-client/"],["Docs","http://docs.rapti.net/"]],onTitle:o=>i("Chromium \u2014 "+(o||"New Tab"))});return e.body.appendChild(n.el),n.go(t||"http://start.rapti.net/"),{openArg:o=>{o&&n.go(/^[a-z]+:\/\//i.test(o)?o:n.fixUrl(o))},destroy:()=>n.destroy()}}calculator(e){let t=(0,I.h)("div",{class:"calc-disp"},"0"),i="",s=o=>{if(o==="C")i="";else if(o==="\u232B")i=i.slice(0,-1);else if(o==="=")try{if(!/^[\d+\-*/().% ]*$/.test(i))throw new Error;let l=Function(`"use strict";return (${i.replace(/%/g,"/100")})`)();i=Number.isFinite(l)?String(Math.round(l*1e10)/1e10):"Error"}catch{i="Error"}else i==="Error"&&(i=""),i+=o;t.textContent=i||"0"},n=["C","\u232B","%","/","7","8","9","*","4","5","6","-","1","2","3","+","0",".","(",")","="];return e.body.appendChild((0,I.h)("div",{class:"calc"},t,(0,I.h)("div",{class:"calc-keys"},...n.map(o=>(0,I.h)("button",{class:"calc-k"+(/[=]/.test(o)?" eq":/[+\-*/%]/.test(o)?" op":""),onclick:()=>s(o)},o))))),{}}configApp(e){let t="/boot/firmware/config.txt",i=this.fs,s=()=>i.isFile(t)?i.read(t):"",n=k=>k.test(s()),o=(k,T)=>{let C=s(),Q=new RegExp(`^#?${k.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}=on\\s*$`,"m");Q.test(C)?C=C.replace(Q,T?`${k}=on`:`#${k}=on`):T&&(C+=`${k}=on
`),i.write(t,C)},l=(()=>{try{return JSON.parse(localStorage.getItem("rapti.pi.config")||"{}")}catch{return{}}})(),a=()=>{try{localStorage.setItem("rapti.pi.config",JSON.stringify(l))}catch{}},h=(k,T,C)=>{let Q=(0,I.h)("button",{class:"cfg-radio"+(T()?" on":"")},"On"),A=(0,I.h)("button",{class:"cfg-radio"+(T()?"":" on")},"Off"),R=()=>{Q.classList.toggle("on",T()),A.classList.toggle("on",!T())};return Q.onclick=()=>{C(!0),R()},A.onclick=()=>{C(!1),R()},(0,I.h)("div",{class:"cfg-row"},(0,I.h)("span",{},k),(0,I.h)("div",{class:"cfg-tog"},Q,A))},c=(k,T)=>[()=>l[k]??T,C=>{l[k]=C,a()}],u=(k,T)=>(0,I.h)("div",{class:"cfg-row"},(0,I.h)("span",{},k),(0,I.h)("b",{},T)),p=w0.BOARDS[this.sys.board.startsWith("pico")?"pi5":this.sys.board],y={System:()=>[u("Password:","\u2022\u2022\u2022\u2022\u2022\u2022"),u("Hostname:","raspberrypi"),h("Boot to desktop:",...c("desktop",!0)),h("Auto login:",...c("autologin",!0)),h("Splash screen:",...c("splash",!0)),u("Board:",p.model)],Display:()=>[h("Screen blanking:",...c("blank",!1)),u("Resolution:","1920 \xD7 1080 (HDMI-A-1)")],Interfaces:()=>[h("SSH:",...c("ssh",!1)),h("VNC:",...c("vnc",!1)),h("SPI:",()=>n(/^dtparam=spi=on/m),k=>o("dtparam=spi",k)),h("I2C:",()=>n(/^dtparam=i2c_arm=on/m),k=>o("dtparam=i2c_arm",k)),h("Serial Port:",...c("serial",!1)),h("Serial Console:",...c("serialc",!1)),h("1-Wire:",...c("onewire",!1)),h("Remote GPIO:",...c("rgpio",!1))],Performance:()=>[u("Overlay File System:","Disabled"),u("Fan:",this.sys.board==="pi5"?"Automatic (Active Cooler)":"Not fitted")],Localisation:()=>[u("Locale:","en_GB.UTF-8"),u("Timezone:",Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC"),u("Keyboard:","English (US)"),u("WLAN Country:","BD Bangladesh")]},O=(0,I.h)("div",{class:"cfg-tabs"}),b=(0,I.h)("div",{class:"cfg-body"}),v=k=>{O.querySelectorAll("button").forEach(T=>T.classList.toggle("on",T.textContent===k)),b.innerHTML="",b.append(...y[k]())};for(let k of Object.keys(y))O.appendChild((0,I.h)("button",{onclick:()=>v(k)},k));return e.body.appendChild((0,I.h)("div",{class:"cfg"},O,b,(0,I.h)("div",{class:"cfg-foot"},(0,I.h)("button",{class:"cfg-btn",onclick:()=>this.close(e)},"Cancel"),(0,I.h)("button",{class:"cfg-btn pri",onclick:()=>{(0,I.toast)("Settings saved (some take effect after a reboot)","ok"),this.close(e)}},"OK")))),v("System"),{}}help(){let e=this.open("editor"),t=e.body.querySelector("textarea");t.value=`RaptiAuto virtual Raspberry Pi \u2014 help

\u2022 Terminal: a simulated bash. Try: ls, cd, cat, nano, pinout, pinctrl get 17,
  vcgencmd measure_temp, python3 blink.py, python3 (interactive).
\u2022 Thonny: write Python, press Run. Stop restarts the program.
\u2022 Python runs on a real MicroPython 1.29 engine with gpiozero, RPi.GPIO,
  neopixel and adafruit_dht libraries made for this simulator.
\u2022 The Board tab shows the GPIO header live and the parts you wired.
\u2022 There is no internet and no apt / pip installs; files are kept on this phone.
`,e.titleEl.textContent="Help - Text Editor"}async shutdownDialog(){let e=await(0,I.dialog)({title:"Shutdown options",body:"<p>What do you want to do?</p>",actions:[{label:"Shutdown",value:"off",cls:"btn-danger"},{label:"Reboot",value:"reboot",cls:"btn-ghost"},{label:"Logout",value:"logout",cls:"btn-ghost"},{label:"Cancel",value:null,cls:"btn-ghost"}]});if(!e)return;for(let s of[...this.wins])s.id!=="thonny"&&this.close(s);let t=this.thonnyWin();t&&this.close(t),this.sys.killProcess(),e!=="logout"&&this.sys.gpio.reset();let i=(0,I.h)("div",{class:"dk-veil"},(0,I.h)("div",{class:"dk-veil-logo",html:v0.replace(/width="22" height="22"/,'width="90" height="90"')}),(0,I.h)("p",{},e==="off"?"Power off":e==="reboot"?"Rebooting\u2026":"Logging out\u2026"));this.el.appendChild(i),e==="off"?(i.appendChild((0,I.h)("button",{class:"btn btn-primary dk-power",onclick:()=>{i.querySelector("p").textContent="Starting\u2026",i.querySelector(".dk-power").remove(),setTimeout(()=>i.remove(),1500)}},"Power on")),this.ctx.onShutdown&&this.ctx.onShutdown()):setTimeout(()=>i.remove(),e==="reboot"?2200:900)}shown(){this.reclaimThonny(),this.tick(),this.thonnyWin()&&this.ctx.thonny.shown()}hidden(){this.closeMenu()}};var V0=se(S0(),1);var L0=se(P0(),1),Q0=se(E0(),1),q0=se(R0(),1),jt=se(ii(),1),Tf=se(Qi(),1),Ht=se(D0(),1),B0=se(I0(),1),Yr=se(ml(),1),Sf=null,el=class extends L0.Editor{constructor(e,t,i){Sf=i,super(e,t),Sf=null}build(){this.pi=Sf,this.root=(0,jt.h)("section",{class:"pane pane-circuit pi-circuit"}),this.circuitPane=this.root,this.canvasHost=(0,jt.h)("div",{class:"canvas-host"}),this.root.appendChild(this.canvasHost),this.canvas=new Q0.CircuitCanvas(this.canvasHost,this),this.buildCircuitOverlay(),this.status=(0,jt.h)("div",{class:"sim-status pi-sim-status hidden"}),this.stale=(0,jt.h)("div",{class:"stale-banner hidden",html:`${(0,Tf.icon)("restart",16)}<span>Circuit changed \u2014 Stop and Run again to apply</span>`,onclick:()=>this.pi.restart()}),this.root.append(this.status,this.stale)}boardPart(){return this.project.parts.find(e=>(0,Ht.getDef)(e.type)&&(0,Ht.getDef)(e.type).board)}mount(e){e.appendChild(this.root),this.canvas.render(),requestAnimationFrame(()=>this.canvas.fit(!1))}shown(){requestAnimationFrame(()=>{this.canvas.applyView(),this.canvas.render()})}unmount(){this.stopEngine(),this.canvas.destroy(),this.audio.close(),this.root.remove()}updateLayout(){}setTab(){}setFullscreen(e){this.pi.setFullscreen(e)}setChrome(e){this.pi.setChrome(e)}leave(){this.pi.leave()}saveNow(){this.pi.saveCircuit()}showBoardInfo(){this.pi.boardSheet()}load(e,{undoable:t=!0}={}){t?(this.history.push(this.snapshot),this.future=[]):(this.history=[],this.future=[]),this.project.parts=e.parts,this.project.wires=e.wires,this.snapshot=this.serialize(),this.canvas.selection=null,this.canvas.render(),this.selectionChanged(null),requestAnimationFrame(()=>this.canvas.fit(!1))}addComponent(){if(this.engine){(0,jt.toast)("Stop the program to change the circuit","warn");return}(0,q0.openLibrary)({onPick:e=>this.placePartNow(e),noBoards:!0,title:"Add a part to the Pi"})}placePartNow(e){let t=this.boardPart();if(!t||e.layer===-1){super.placePartNow(e);return}let i=typeof e.box=="function"?e.box((0,Ht.defaultProps)(e)):e.box,s=i[2]-i[0],n=i[3]-i[1],[o,l,a]=(0,Ht.worldBox)(t),h=this.project.parts.map(R=>(0,Ht.worldBox)(R)),c=(R,D)=>!h.some(([F,J,he,Z])=>R<he+12&&R+s>F-12&&D<Z+12&&D+n>J-12),u=null;for(let R=0;R<8&&!u;R++){let D=l-50-n-R*(n+40);for(let F=o;F<=Math.max(a,o+200)&&!u;F+=20)c(F,D)&&(u=[F,D])}if(!u){super.placePartNow(e);return}let p={id:(0,Ht.newId)("p"),type:e.type,x:Math.round((u[0]-i[0])/10)*10,y:Math.round((u[1]-i[1])/10)*10,rot:0,props:{}};this.project.parts.push(p),this.commit("Add "+e.name),this.canvas.select({kind:"part",id:p.id});let y=this.canvasHost.getBoundingClientRect(),[O,b,v,k]=(0,Ht.worldBox)(p),[T,C]=this.canvas.worldToScreen(O,b),[Q,A]=this.canvas.worldToScreen(v,k);(T<y.left||C<y.top||Q>y.right||A>y.bottom)&&this.canvas.fit(),this.showHint("Drag to move. Tap one of its pins, then a pin of the Pi header, to draw a wire."),Yr.Native.vibrate(10)}deleteSelected(){let e=this.canvas.selection,t=this.boardPart();if(e&&t&&e.kind==="part"&&e.id===t.id){(0,jt.toast)("The board stays \u2014 change it with the board chip at the top","info");return}e&&t&&e.kind==="multi"&&e.parts.includes(t.id)&&(e.parts=e.parts.filter(i=>i!==t.id)),super.deleteSelected()}startEngine(){if(this.engine)return this.engine;this.canvas.wiring&&this.canvas.cancelWiring(),this.canvas.select(null),this.warnings=[],this.audio.resume();let e=new B0.SimEngine(this.project,{external:!0,onWarning:s=>this.addWarning(s),onError:s=>this.runtimeError(s),onSound:(s,n,o)=>this.audio.set(s,n,this.settings.sound===!1?0:o),onBurn:()=>{Yr.Native.vibrate(40),this.settings.sound!==!1&&this.audio.pop()}}),t=e.start();if(!t.ok)return(0,jt.toast)(t.error&&t.error.message||"The circuit could not start","error"),null;this.engine=e,this.pi.root.classList.add("simulating"),this.canvas.setMode("sim"),this.selectionChanged(null),this.status.classList.remove("hidden"),Yr.Native.keepScreenOn(!0),this.lastFrame=performance.now();let i=s=>{if(!this.engine)return;let n=Math.min(.1,(s-this.lastFrame)/1e3);this.lastFrame=s,this.engine.tick(s),this.engine&&(this.pi.onCircuitFrame&&this.pi.onCircuitFrame(n),this.pi.tab==="circuit"&&(this.canvas.frame(n),this.updateStatus()),this.raf=requestAnimationFrame(i))};return this.raf=requestAnimationFrame(i),e}stopEngine(){this.engine&&(cancelAnimationFrame(this.raf),this.engine.stop(),this.engine=null,this.audio.stopAll(),this.simSheet&&(this.simSheet.close(),this.simSheet=null),this.pi.root.classList.remove("simulating"),this.canvas.setMode("edit"),this.status.classList.add("hidden"),this.stale.classList.add("hidden"),Yr.Native.keepScreenOn(!1))}run(){this.pi.runProgram()}stop(){this.pi.stopAll()}toggleRun(){this.pi.toggleRun()}restart(){this.pi.restart()}updateStatus(){if(!this.engine)return;let i=`<span class="dot live"></span><b>${this.pi.programRunning()?"Python running":"Powered"}</b><span class="speed">${this.pi.sys.info.short}</span>`+(this.warnings.length?`<button class="warn-pill" id="warnpill">${(0,Tf.icon)("warning",14)}<span>${this.warnings.length}</span></button>`:"");if(i!==this._st){this._st=i,this.status.innerHTML=i;let s=this.status.querySelector("#warnpill");s&&(s.onclick=()=>this.showWarnings())}}runtimeError(e){let t=e||{message:"Unknown error"};this.pi.stopAll(),(0,jt.dialog)({title:t.electrical?"\u26A1 Power cut":"Circuit error",body:`<p>${String(t.message).replace(/[&<>]/g,i=>({"&":"&amp;","<":"&lt;",">":"&gt;"})[i])}</p>`,actions:[{label:"OK",value:!0,cls:"btn-primary"}]})}};var tl=()=>typeof performance<"u"?performance.now():Date.now(),il=class{constructor(e){this.engine=e,this.warned=new Set,this.rx={},e.opts.onUart=(t,i)=>{this.rx[t]=((this.rx[t]||"")+i).slice(-4096)}}has(e){return!!(this.engine.pins&&this.engine.pins.has(e))}advance(){this.pace(),this.engine.advanceTo(tl())}quietForEcho(){if(!this.quiet)return;let e=this.engine,t=e.time(),i=0;for(let s of e.parts.values())s&&s.def&&s.def.type==="hc-sr04"&&s.pending&&(i=Math.max(i,s.pending.start+s.pending.width));i>t&&this.quiet(tl()+(i-t)/1e3+6)}pace(){let e=tl();if(this.lastAccess!=null){let i=(e-this.lastAccess)*1e3;i<5e3&&(this.gapUs=this.gapUs?this.gapUs*.8+i*.2:i)}this.lastAccess=e;let t=Math.max(450,Math.min(2e4,6*(this.gapUs||0)));for(let i of this.engine.parts.values())i&&i.def&&i.def.type==="hc-sr04"&&(i.echoDelayUs=t)}syncPin(e){let t=this.engine,i=e.n,s=t.pins&&t.pins.get(i);if(s)if(this.advance(),e.mode==="out")s.servoUs!=null&&t.setServo(i,null),s.tone&&t.noTone(i),s.mode!==1&&t.pinMode(i,1),t.digitalWrite(i,e.out?1:0),e.out||this.quietForEcho();else if(e.mode==="pwm"){let n=e.freq||0,o=Math.max(0,Math.min(1,e.duty));s.mode!==1&&t.pinMode(i,1),n>=40&&n<=330&&o>0&&o<.2&&this.on(i,"servo","PWM")?(s.tone&&t.noTone(i),t.setServo(i,o*1e6/n)):n>=20&&this.on(i,"buzzer")&&this.passive(i)?(s.servoUs!=null&&t.setServo(i,null),o>.02&&o<.98?t.tone(i,n,0):(t.noTone(i),t.digitalWrite(i,o>=.98?1:0))):(s.servoUs!=null&&t.setServo(i,null),s.tone&&t.noTone(i),t.analogWrite(i,o,Math.round(o*255),255))}else{let n=e.pull==="up"?2:e.pull==="down"?3:0;s.servoUs!=null&&t.setServo(i,null),s.tone&&t.noTone(i),s.mode!==n&&t.pinMode(i,n)}}read(e){let t=this.engine;if(!this.has(e))return 0;this.advance();let i=t.digitalRead(e),s=t.pins.get(e);return s&&s.node>=0&&s.mode!==1&&t.vAvg(s.node)-t.vAvg(t.gnd)>3.9&&this.warnOnce("5v"+e,`${s.id} sees ${(t.vAvg(s.node)-t.vAvg(t.gnd)).toFixed(1)} V \u2014 Raspberry Pi GPIOs are 3.3 V only! Use a voltage divider (e.g. 1 k\u03A9 + 2 k\u03A9) on 5 V signals such as the HC-SR04 ECHO.`),i}partsOn(e,t,i=null){let s=this.engine;return this.has(e)?s.partsOnPin(e,n=>n.def&&n.def.type===t,i).map(n=>n.rt):[]}on(e,t,i=null){return this.partsOn(e,t,i).length>0}partsBehind(e,t,i=null){let s=this.partsOn(e,t,i);if(s.length)return s;let n=this.engine;if(!this.has(e))return[];let o=[];for(let l of n.resistiveNeighbours(n.pinNode(e)))o.push(...n.partsOnNode(l,a=>a.def&&a.def.type===t,i).map(a=>a.rt));return o}passive(e){return this.partsOn(e,"buzzer").some(t=>(t.part.props||{}).kind!=="active")}adc(e){let t=26+e;return e>2||!this.has(t)?null:(this.advance(),Math.max(0,Math.min(1,this.engine.analogRead(t)/3.3)))}mcp3008(e){let t=this.engine;this.advance(),t.ensureSolved();let i=s=>t.pinNode(s);for(let s of t.parts.values()){if(!s.mcp3008)continue;let n=s.part.id,o=t.nodeOf(n,"CLK")===i(11)&&t.nodeOf(n,"DOUT")===i(9)&&t.nodeOf(n,"DIN")===i(10),l=[i(8),i(7)].includes(t.nodeOf(n,"CS"));if(!o||!l){this.warnOnce("mcpwire","MCP3008: wire CLK \u2192 GPIO11 (SCLK), DOUT \u2192 GPIO9 (MISO), DIN \u2192 GPIO10 (MOSI) and CS \u2192 GPIO8 (CE0)");continue}return s.powered()?s.read(e):(this.warnOnce("mcppwr","MCP3008 has no power: VDD and VREF to 3V3, AGND and DGND to GND"),0)}return this.warnOnce("mcpnone","gpiozero MCP3008: add an MCP3008 ADC to the circuit (the Pi has no analog inputs)"),0}distance(e){let t=this.partsBehind(e,"hc-sr04","ECHO")[0];return t?t.powered()?(t.visual.ping=tl(),Math.max(.02,Math.min(4,t.distance/100))):(this.warnOnce("srpwr","HC-SR04 has no power: VCC to 5V, GND to GND"),-1):-1}dht(e,t){let i=this.partsOn(e,"dht22","DATA")[0];if(!i||i.powered&&!i.powered())return-999;let s=i.read();return t?s.h:s.t}light(e){let t=this.partsOn(e,"ldr-module","DO")[0]||this.partsOn(e,"ldr-module","AO")[0];return t?Math.max(0,Math.min(1,Math.log10(1+t.values.lux)/Math.log10(1001))):this.read(e)?0:1}neo(e,t){this.has(e)&&this.engine.sendWs2812(e,t)}uartWrite(e,t){return this.advance(),this.engine.externalUartOut(e,t)}uartWired(e){let t=this.engine,i=(t.board&&t.board.uart||{})[e];if(!i)return!1;let s=t.pinNode(i.rx),n=t.pinNode(i.tx);return(t.boards||[]).slice(1).some(o=>Object.values(o.board.uart||{s:{rx:0,tx:1}}).some(l=>o.pinNode(l.rx)===n||o.pinNode(l.tx)===s))}uartAny(e){return(this.rx[e]||"").length}uartRead(e,t){let i=this.rx[e]||"",s=t<0?i.length:Math.min(t,i.length);return this.rx[e]=i.slice(s),i.slice(0,s)}i2cDevices(){let e=this.engine,t=new Set([...e.pins.values()].map(s=>s.node).filter(s=>s>=0)),i=[];for(let s of e.parts.values()){if(!s.i2c||s===e.boardRt)continue;let n=s.i2cPins||s.def.i2cPins||{sda:"SDA",scl:"SCL"};t.has(e.nodeOf(s.part.id,n.sda))&&t.has(e.nodeOf(s.part.id,n.scl))&&i.push(s)}return i}i2cHas(e){return this.engine.ensureSolved(),this.i2cDevices().some(t=>t.i2c.address===e&&(!t.powered||t.powered()))}i2cScan(){return this.engine.ensureSolved(),this.i2cDevices().filter(e=>!e.powered||e.powered()).map(e=>e.i2c.address).sort((e,t)=>e-t)}i2cRead(e,t){this.advance();let i=this.i2cDevices().find(s=>s.i2c.address===e);if(i&&i.i2cRead){let s=i.i2cRead(t);return this.engine.dirty=!0,s}return new Array(t).fill(i?0:255)}i2cWrite(e,t){let i=this.i2cDevices().find(o=>o.i2c.address===e);if(i&&i.i2cWrite){this.advance(),i.i2cWrite(t),this.engine.dirty=!0;return}if(i&&i.ssd1306){this.advance(),this.ssd1306Write(i,t);return}if(!i||!i.hd44780)return;let s=i.hd44780,n=i._pcf||(i._pcf={en:0,hi:null,rs:0,mode8:!0,cg:-1});for(let o of t){s.backlight=!!(o&8);let l=o>>2&1;if(n.en&&!l){let a=o>>4,h=o&1;if(n.mode8)a===2&&(n.mode8=!1);else if(n.hi===null)n.hi=a,n.rs=h;else{let c=n.hi<<4|a;n.hi=null,n.rs?this.lcdData(s,n,c):this.lcdCmd(s,n,c)}}n.en=l}s.touch(),this.engine.dirty=!0}lcdCmd(e,t,i){i&128?(e.addr=i&127,t.cg=-1):i&64?t.cg=i&63:i&32?(e.initialized||e.init(),(i&16)===16&&(t.mode8=!0)):i&16?i&8?e.scroll(i&4?1:-1):e.step(i&4?1:-1):i&8?(e.on=!!(i&4),e.cursor=!!(i&2),e.blink=!!(i&1),e.initialized||e.init()):i&4?(e.inc=!!(i&2),e.autoShift=!!(i&1)):i&2?e.home():i&1&&(e.initialized||e.init(),e.clear())}lcdData(e,t,i){if(t.cg>=0){e.cgram[t.cg&63]=i&31,t.cg=t.cg+1&63;return}e.initialized||e.init(),e.write(i)}ssd1306Write(e,t){let i=e.ssd1306;if(e.powered&&!e.powered())return;let s=e._ssd||(e._ssd={mode:0,col:0,pg:0,c0:0,c1:127,p0:0,p1:7,need:0,cur:0,args:[]}),n=0;for(;n<t.length;){let o=t[n++],l=o&64;if(o&128)n<t.length&&this.ssdItem(i,s,l,t[n++]);else for(;n<t.length;)this.ssdItem(i,s,l,t[n++])}i.version++,this.engine.dirty=!0}ssdItem(e,t,i,s){if(i){if(t.pg>=0&&t.pg<e.h/8&&t.col>=0&&t.col<e.w)for(let n=0;n<8;n++)e.fb[(t.pg*8+n)*e.w+t.col]=s>>n&1;t.mode===1?++t.pg>t.p1&&(t.pg=t.p0,++t.col>t.c1&&(t.col=t.c0)):t.mode===2?t.col=(t.col+1)%e.w:++t.col>t.c1&&(t.col=t.c0,++t.pg>t.p1&&(t.pg=t.p0));return}if(t.need){if(t.args.push(s),--t.need)return;let n=t.args;switch(t.cur){case 32:t.mode=n[0]&3;break;case 33:t.c0=n[0]&127,t.c1=n[1]&127,t.col=t.c0;break;case 34:t.p0=n[0]&7,t.p1=n[1]&7,t.pg=t.p0;break;case 129:e.contrast=n[0]/255;break;default:break}return}if([32,129,211,213,217,218,219,141,168,173].includes(s)){t.cur=s,t.need=1,t.args=[];return}if(s===33||s===34){t.cur=s,t.need=2,t.args=[];return}if(s===38||s===39){t.cur=s,t.need=6,t.args=[];return}if(s===41||s===42){t.cur=s,t.need=5,t.args=[];return}if(s===163){t.cur=s,t.need=2,t.args=[];return}s===174?e.on=!1:s===175?e.on=!0:s===166?e.invert=!1:s===167?e.invert=!0:s>=176&&s<=183?t.pg=s&7:s<=15?(t.col=t.col&112|s&15,t.mode===2&&(t.c0=0)):s>=16&&s<=31&&(t.col=t.col&15|(s&7)<<4)}dispTm1637(e,t,i,s,n){let o=this.partsOn(e,"tm1637","CLK").find(a=>this.partsOn(t,"tm1637","DIO").includes(a));if(!o)return this.warnOnce("tmwire",`TM1637 display not found on CLK=GPIO${e}, DIO=GPIO${t}. Wire CLK, DIO, VCC and GND.`),0;if(o.powered&&!o.powered())return this.warnOnce("tmpwr","TM1637 has no power: VCC to 3V3 / 5V, GND to GND"),0;let l=o.tm1637;return l.brightness=s&7,l.on=!!n,i.length&&l.set(0,i),l.version++,this.engine.dirty=!0,1}spiXfer(e,t,i){this.advance();let s=new Array(i.length).fill(0);for(let n of this.partsOn(t,"max7219","DIN")){if(!this.partsOn(e,"max7219","CLK").includes(n))continue;if(n.powered&&!n.powered()){this.warnOnce("mxpwr","MAX7219 has no power: VCC to 5V, GND to GND");continue}let o=n.max7219,l=o.length;for(let a=0;a+1<i.length;a+=2){let h=o[l-1-a/2%l],c=i[a]&15,u=i[a+1]&255;c>=1&&c<=8?h.rows[c-1]=u:c===10?h.intensity=u&15:c===12&&(h.shutdown=!(u&1)),h.version++}return this.engine.dirty=!0,s}if(i.length===3&&i[0]===1&&i[1]&128){let n=Math.round(Math.max(0,Math.min(1,this.mcp3008(i[1]>>4&7)))*1023);return[0,n>>8&3,n&255]}return s}pinStates(e){let t=new Map;for(let i of e.pins.values()){if(!this.has(i.n))continue;let s=i.mode==="out"?i.out:i.mode==="pwm"?i.duty>=.5?1:0:i.used||i.watch?this.quietLevel(i.n):null;t.set(i.n,i.mode==="pwm"?"pwm":i.mode==="out"?i.out?"ohi":"olo":s==null?"":s?"ihi":"ilo")}return t}quietLevel(e){let t=this.engine,i=t.pins.get(e);return!i||i.node<0?0:t.vAvg(i.node)-t.vAvg(t.gnd)>1.65?1:0}warnOnce(e,t){this.warned.has(e)||(this.warned.add(e),this.engine.warn(t,null,"pi:"+e))}};var Mi=se(F0(),1),rl=se(rn(),1),U0=se(z0(),1),$2=[["circuit","circuit","Circuit"],["board","chip","Pinout"],["desktop","screen","Desktop"],["thonny","code","Thonny"],["output","list","Output"]],F2=[["circuit","circuit","Circuit"],["board","chip","Pinout"],["thonny","code","Thonny"],["output","list","Output"]],j0=r=>"rapti.pi.circuit.v1."+r,sl=class{constructor(e){this.app=e;let t="pi5";try{t=localStorage.getItem("rapti.pi.board")||"pi5"}catch{}rt.BOARDS[t]||(t="pi5"),this.sys=new nn(t,Ld),this.sys.gpio.parts=[],this.audio=new H0.AudioEngine;try{this.audio.enabled=localStorage.getItem("rapti.pi.mute")!=="1"}catch{}this.tab="circuit",this.panes=null,this.vis=["circuit"],this.fullscreen=!1,this.build(),this.offSys=this.sys.on(i=>this.onSys(i)),this.offGpio=this.sys.gpio.on(()=>this.refresh())}get isPico(){return this.sys.isPico}get settings(){return this.app.settings}build(){this.root=(0,L.h)("div",{class:"screen pi-screen editor"});let e=(0,L.h)("button",{class:"icon-btn","aria-label":"Back",html:(0,Fe.icon)("back"),onclick:()=>this.leave()});this.boardChip=(0,L.h)("button",{class:"board-chip",onclick:()=>this.boardSheet()}),this.runDot=(0,L.h)("span",{class:"pi-run-dot"}),this.runBtn=(0,L.h)("button",{class:"run-btn pi-runbtn",onclick:()=>this.toggleRun()});let t=(0,L.h)("button",{class:"icon-btn","aria-label":"Menu",html:(0,Fe.icon)("dots"),onclick:s=>this.menu(s.currentTarget)});this.top=(0,L.h)("header",{class:"ed-top pi-top"},e,(0,L.h)("div",{class:"ed-titles"},(0,L.h)("div",{class:"pi-title"},"Raspberry Pi Lab",this.runDot),this.boardChip),this.runBtn,t),this.main=(0,L.h)("main",{class:"pi-main"}),this.panes_={circuit:(0,L.h)("div",{class:"pi-pane pane-pcircuit"}),board:(0,L.h)("div",{class:"pi-pane pane-board"}),desktop:(0,L.h)("div",{class:"pi-pane pane-desktop"}),thonny:(0,L.h)("div",{class:"pi-pane pane-thonny"}),output:(0,L.h)("div",{class:"pi-pane pane-output"})};for(let s of Object.values(this.panes_))this.main.appendChild(s);this.nav=(0,L.h)("nav",{class:"ed-nav pi-nav"});let i=(s,n,o,l={})=>(0,L.h)("button",{class:"fs-btn",title:n,"aria-label":n,html:(0,Fe.icon)(s,20),onclick:o,...l});this.fsRun=i("play","Run",()=>this.toggleRun(),{class:"fs-btn fs-run"}),this.fsBar=(0,L.h)("div",{class:"fs-bar pi-fsbar"},i("fullscreenExit","Exit full screen",()=>this.setFullscreen(!1)),this.fsRun,i("circuit","Circuit",()=>this.toggleTab("circuit"),{"data-tab":"circuit"}),i("code","Thonny",()=>this.toggleTab("thonny"),{"data-tab":"thonny"}),i("list","Output",()=>this.toggleTab("output"),{"data-tab":"output"}),i("chip","Pinout",()=>this.toggleTab("board"),{"data-tab":"board"})),this.fsHandle=(0,L.h)("button",{class:"fs-handle","aria-label":"Show menus",title:"Show menus",html:(0,Fe.icon)("menu",19)}),this.root.append(this.top,this.main,this.nav,this.fsBar),this.dock=new U0.FsDock({root:this.root,bar:this.fsBar,handle:this.fsHandle,key:"pi",orient:"col",home:{fx:0,fy:1},settings:this.settings,save:()=>this.app.saveSettings(),toggle:()=>this.setChrome(this.root.classList.contains("fs-clean"))}),this.thonny=new Jo({sys:this.sys,wire:s=>this.wireExample(s),onRun:()=>this.revealOutput()}),this.desktop=new Zo({sys:this.sys,thonny:this.thonny}),this.panes_.desktop.appendChild(this.desktop.el),this.buildCircuitPane(),this.buildBoardPane(),this.drawNav(),this.drawBoard(),this.updateRun(),this.ro=new ResizeObserver(()=>this.updateLayout()),this.ro.observe(this.root)}drawNav(){this.nav.innerHTML="";for(let[e,t,i]of this.isPico?F2:$2)this.nav.appendChild((0,L.h)("button",{class:"nav-tab"+(e===this.tab?" active":""),"data-tab":e,onclick:()=>this.toggleTab(e),html:`${(0,Fe.icon)(t,22)}<span>${i}</span>`}));this.fsBar.querySelector('[data-tab="thonny"]').hidden=!1}visibleTabs(){return this.wide&&this.panes&&this.panes.includes(this.tab)?this.panes:[this.tab]}toggleTab(e){if(this.isPico&&e==="desktop"&&(e="circuit"),!this.wide){this.setTab(e);return}let t=[...this.visibleTabs()];if(t.includes(e)){if(t.length<2){Ri.Native.vibrate(5);return}t=t.filter(i=>i!==e)}else t.length<2&&!this.clash(t[0],e)?t.push(e):t.length<2?t=[e]:t[1]=e;t.length>1&&this.clash(t[0],t[1])&&(t=[e]),this.panes=t,this.setTab(t[t.length-1]),Ri.Native.vibrate(8)}clash(e,t){let i=s=>s==="thonny"||s==="output";return e==="desktop"&&i(t)||t==="desktop"&&i(e)}showOutput(){this.vis.includes("output")||(this.wide&&this.vis.length<2&&this.vis.includes("thonny")?this.toggleTab("output"):this.setTab("output"))}revealOutput(){if(!(this.vis.includes("output")||this.vis.includes("desktop"))){if(!this.wide){(0,L.toast)("Running \u2014 the output is on the Output tab");return}if(this.vis.length<2){this.toggleTab("output");return}this.fromRunBtn&&this.vis.includes("circuit")&&(this.panes=this.vis.map(e=>e==="circuit"?e:"output"),this.setTab("output"))}}updateLayout(){let e=this.root.getBoundingClientRect(),t=e.width>=760&&e.width>e.height*1.05;t!==this.wide&&(this.wide=t,this.root.classList.toggle("wide",t),this.setTab(this.tab))}setTab(e){if(this.isPico&&e==="desktop"&&(e="circuit"),this.panes){if(!this.wide)this.panes=null;else if(!this.panes.includes(e)){let c=this.panes.indexOf(this.tab);this.panes=c>=0&&this.panes.length>1?this.panes.map((u,p)=>p===c?e:u):[e]}}let t=this.vis||[this.tab];this.tab=e;let i=this.visibleTabs();this.vis=i;let s=c=>t.includes(c),n=c=>i.includes(c),o=i.length>1;this.root.classList.toggle("pi-split",o);let l=Object.keys(this.panes_).filter(c=>n(c));for(let[c,u]of Object.entries(this.panes_))u.classList.toggle("active",n(c)),u.classList.toggle("first",c===l[0]),u.classList.toggle("last",c===l[l.length-1]);this.nav.querySelectorAll(".nav-tab").forEach(c=>c.classList.toggle("active",n(c.dataset.tab))),this.fsBar.querySelectorAll("[data-tab]").forEach(c=>c.classList.toggle("active",n(c.dataset.tab))),this.root.dataset.tab=e,s("desktop")&&!n("desktop")&&this.desktop.hidden();let a=n("thonny")||n("output"),h=s("thonny")||s("output");a?(this.thonny.splitInto(this.panes_.thonny,this.panes_.output),(!h||e==="thonny"||e==="output")&&(this.thonny.shown(),n("output")&&this.thonny.con.scrollEnd())):(h||s("desktop")&&!n("desktop")&&!this.desktop.thonnyWin())&&this.thonny.hidden(),n("desktop")&&(!s("desktop")||e==="desktop")&&this.desktop.shown(),n("circuit")&&(!s("circuit")||e==="circuit")&&this.circuit.shown(),n("board")&&(!s("board")||e==="board")&&this.refresh(!0),!n("circuit")&&this.circuit&&this.circuit.canvas.wiring&&this.circuit.canvas.cancelWiring(),i.join()!==t.join()&&this.circuit&&setTimeout(()=>{this.circuit.canvas.applyView(),this.thonny.editor&&this.thonny.editor.refresh()},60)}buildCircuitPane(){this.circuit=new el(this.app,{name:"Pi circuit",parts:[],wires:[],code:""},this),this.circuit.load(this.loadCircuit(this.sys.board),{undoable:!1}),this.circuit.mount(this.panes_.circuit),this.fileChip=(0,L.h)("button",{class:"pi-filechip",onclick:()=>this.fileSheet()}),this.circuit.root.append(this.fileChip),this.drawFileChip()}loadCircuit(e){try{let t=JSON.parse(localStorage.getItem(j0(e))||"null");if(t&&Array.isArray(t.parts)&&t.parts.some(i=>i.type===V0.CIRCUIT_TYPE[e]))return{parts:t.parts,wires:t.wires||[]}}catch{}return(0,Mi.defaultCircuit)(e)}saveCircuit(){try{localStorage.setItem(j0(this.sys.board),JSON.stringify({parts:this.circuit.project.parts,wires:this.circuit.project.wires}))}catch{(0,L.toast)("Storage is full \u2014 the circuit could not be saved","error")}}wireExample(e){e.circuit&&this.sys.isPico||!e.circuit&&(!e.parts||!e.parts.length)||(this.stopCircuit(),this.circuit.load(e.circuit?e.circuit(this.sys.board):(0,Mi.autowire)(this.sys.board,e.parts)),this.isPico||(this.chosenFile="/home/pi/"+e.file,this.drawFileChip()),this.saveCircuit())}onCircuitFrame(){let e=this.sys.gpio,t=e.hw;if(!t)return;if(e.pins){for(let s of e.pins.values())if(s.watch){e.inputsChanged();break}}let i=this.circuit.engine&&this.circuit.engine.boardRt;if(i&&(this.fr=(this.fr||0)+1)%3===0){i.visual.pinSt=t.pinStates(e);let s=performance.now();i.visual.act=this.sys.running?Math.sin(s/37)+Math.sin(s/13)>.4:s%4e3<90;let n=this.sys.info.led;i.visual.L=n!=null&&e.pins.has(n)&&e.drive(n)||0}}powerOn(){if(this.circuit.engine)return!0;let e=this.circuit.startEngine();return e?(this.sys.gpio.attachHw(new il(e)),this.updateRun(),!0):(this.noAutoUntil=performance.now()+5e3,!1)}stopCircuit(){this.circuit.engine&&(this.sys.gpio.attachHw(null),this.circuit.stopEngine(),this.updateRun())}programRunning(){return!!(this.thonny.running||this.sys.running)}async toggleRun(){if(this.circuit.engine||this.programRunning()){await this.stopAll();return}await this.runProgram()}async runProgram(){let e=this.runFile();if(!e){(0,L.toast)("No Python file yet: write one in Thonny","warn");return}this.audio.resume(),this.powerOn()&&(this.thonny.open(e),this.fromRunBtn=!0,this.thonny.run(),this.fromRunBtn=!1,this.updateRun())}async stopAll(){this.noAutoUntil=performance.now()+900,this.programRunning()&&await this.thonny.stop(),this.stopCircuit(),this.updateRun()}async restart(){await this.stopAll(),await this.runProgram()}updateRun(){let e=!!(this.circuit&&this.circuit.engine)||this.programRunning();this.runDot.classList.toggle("on",this.programRunning()),this.runBtn.classList.toggle("running",e),this.runBtn.innerHTML=e?`${(0,Fe.icon)("stop",18)}<span>Stop</span>`:`${(0,Fe.icon)("play",20)}<span>Run</span>`,this.fsRun.innerHTML=(0,Fe.icon)(e?"stop":"play",20),this.fsRun.classList.toggle("running",e)}runFile(){let e=this.pyFiles(),t=this.chosenFile&&e.includes(this.chosenFile)?this.chosenFile:null;return!t&&this.thonny.cur&&e.includes(this.thonny.cur.path)&&(t=this.thonny.cur.path),t||(t=e.includes(this.isPico?"/main.py":"/home/pi/blink.py")?this.isPico?"/main.py":"/home/pi/blink.py":e[0]),t||null}pyFiles(){let e=this.sys.fs,t=[],i=(s,n)=>{for(let o of e.list(s)){let l=ue(o,s);o.startsWith(".")||(e.isDir(l)?n<2&&i(l,n+1):o.endsWith(".py")&&t.push(l))}};try{i(this.sys.home,0)}catch{}return t}drawFileChip(){let e=this.runFile();this.fileChip.innerHTML=`${(0,Fe.icon)("code",15)}<span>${e?this.isPico?e.replace(/^\//,""):e.replace("/home/pi/",""):"no .py file"}</span>${(0,Fe.icon)("forward",12)}`}fileSheet(){let e=(0,L.h)("div",{class:"pin-pick"}),t=this.runFile();for(let s of this.pyFiles())e.appendChild((0,L.h)("button",{class:"pin-opt"+(s===t?" active":""),onclick:()=>{i.close(),this.chosenFile=s,this.drawFileChip()}},(0,L.h)("b",{},this.isPico?s.replace(/^\//,""):s.replace("/home/pi/","")),(0,L.h)("span",{},"Run this file")));e.appendChild((0,L.h)("button",{class:"btn btn-ghost",html:`${(0,Fe.icon)("code",16)}<span>Open in Thonny</span>`,onclick:()=>{i.close();let s=this.runFile();this.setTab("thonny"),s&&this.thonny.open(s)}}));let i=new L.Sheet({title:"Program to run",icon:"code",content:e,height:"70vh"}).open()}setFullscreen(e){this.fullscreen=e,this.circuit.fullscreen=e,(0,L.smoothSwap)(()=>{this.root.classList.toggle("fs",e),this.setChrome(!e,!1),Ri.Native.setImmersive(e)},()=>{this.circuit.canvas.applyView(),setTimeout(()=>{this.circuit.canvas.applyView(),this.thonny.editor&&this.thonny.editor.refresh()},80)}),e&&!this.settings.piFsHinted&&(this.settings.piFsHinted=!0,this.app.saveSettings(),(0,L.toast)("Full screen \u2014 tap \u2630 for the menus, drag it to move it")),Ri.Native.vibrate(8)}setChrome(e,t=!0){this.root.classList.toggle("fs-clean",!e),this.fsHandle.innerHTML=(0,Fe.icon)(e?"close":"menu",19),this.fsHandle.setAttribute("aria-label",e?"Hide menus":"Show menus"),this.dock&&this.dock.place(),t&&Ri.Native.vibrate(6),setTimeout(()=>this.circuit.canvas.applyView(),30)}buildBoardPane(){let e=this.panes_.board;this.svgWrap=(0,L.h)("div",{class:"pb-svg"}),this.zoom=1;let t=(s,n)=>(0,L.h)("button",{class:"pb-zoom",html:(0,Fe.icon)(s,18),onclick:()=>{this.zoom=Math.max(1,Math.min(2.6,this.zoom+n)),this.svgWrap.style.setProperty("--z",this.zoom)}});this.zooms=(0,L.h)("div",{class:"pb-zooms"},t("minus",-.4),t("plus",.4)),this.strip=(0,L.h)("div",{class:"pb-strip"}),this.boardBox=(0,L.h)("div",{class:"pb-board"},this.svgWrap,this.strip),this.legend=(0,L.h)("div",{class:"pb-legend"}),this.legendRow=(0,L.h)("div",{class:"pb-legrow"},this.legend,this.zooms),this.pinoutNote=(0,L.h)("div",{class:"pb-note"},(0,L.h)("span",{html:(0,Fe.icon)("circuit",18)}),(0,L.h)("div",{},(0,L.h)("b",{},"Wire parts in the Circuit tab"),(0,L.h)("small",{},"Add LEDs, buttons, sensors, motors \u2026 with \uFF0B, tap a pin then another pin to draw a wire, then Run. Tap a pin here for its functions.")),(0,L.h)("button",{class:"btn btn-primary sm",onclick:()=>this.setTab("circuit")},"Circuit")),this.specs=(0,L.h)("div",{class:"pb-specs"}),e.append((0,L.h)("div",{class:"pb-inner"},this.boardBox,this.legendRow,this.pinoutNote,this.specs));let i=s=>{let n=s.target.closest("[data-phys]");n&&this.pinSheet(Number(n.dataset.phys))};this.svgWrap.addEventListener("click",i),this.strip.addEventListener("click",i)}drawBoard(){let e=this.sys.info;if(this.boardChip.innerHTML=`${(0,Fe.icon)("chip",14)}<span>${e.name}</span>${(0,Fe.icon)("forward",12)}`,this.svgWrap.innerHTML=(0,rt.boardSVG)(this.sys.board,"po-"),this.svg=this.svgWrap.querySelector("svg"),this.pinEls=new Map,this.svg.querySelectorAll(".hp[data-gpio]").forEach(n=>this.pinEls.set(Number(n.dataset.gpio),n)),this.strip.innerHTML="",this.stripEls=new Map,this.strip.hidden=this.isPico,!this.isPico){let n=(0,rt.headerOf)(this.sys.board),o=l=>(0,L.h)("div",{class:"ps-row"},...n.filter(a=>a.phys%2===1===l).map(a=>{let h=(0,L.h)("button",{class:"ps-pin t-"+a.type,"data-phys":a.phys},(0,L.h)("i"),(0,L.h)("b",{},a.gpio!=null?String(a.gpio):a.name.replace("GND","\u23DA")),(0,L.h)("small",{},String(a.phys)));return a.gpio!=null&&this.stripEls.set(a.gpio,h),h}));this.strip.append(o(!1),o(!0))}this.actLed=this.svg.querySelector(".led-act"),this.userLed=this.svg.querySelector(".led-user");let t=this.svg.querySelector(".bootsel");if(t){let n=l=>{l.preventDefault(),this.sys.gpio.bootsel=1,t.classList.add("down"),Ri.Native.vibrate(8)},o=()=>{this.sys.gpio.bootsel=0,t.classList.remove("down")};t.addEventListener("pointerdown",n),t.addEventListener("pointerup",o),t.addEventListener("pointerleave",o),t.addEventListener("pointercancel",o)}let i=this.svg.querySelector(".pwr-btn");i&&i.addEventListener("click",()=>{this.setTab("desktop"),this.desktop.shutdownDialog()}),this.legend.innerHTML="";let s=(n,o)=>(0,L.h)("span",{class:"lg "+n},(0,L.h)("i"),o);this.legend.append(s("l-3v3","3V3"),s("l-5v","5V"),s("l-gnd","GND"),s("l-gpio","GPIO"),s("l-hi","HIGH"),s("l-pwm","PWM"),s("l-in","Input")),this.drawSpecs(),this.drawFileChip(),this.refresh(!0)}drawSpecs(){let e=this.sys.info,t=(i,s)=>s?(0,L.h)("div",{class:"spec"},(0,L.h)("span",{},i),(0,L.h)("b",{},s)):null;this.specs.innerHTML="",this.specs.append(...[(0,L.h)("div",{class:"pb-sec"},(0,L.h)("b",{},e.name),(0,L.h)("span",{class:"muted"},` \xB7 ${e.year}`)),t(e.kind==="pico"?"MCU":"SoC",e.mcu||e.soc),t("CPU",e.cpu),t("Memory",e.ram),t("Flash",e.flash),t("GPU",e.gpu),t("I/O",e.io),t("Runs",e.kind==="pico"?"MicroPython 1.29 (machine, rp2"+(e.wifi?", network":"")+", neopixel, dht, i2c_lcd)":"Python 3 programs (gpiozero, RPi.GPIO, neopixel, adafruit_dht, i2c_lcd) on a MicroPython 1.29 engine")].filter(Boolean))}refresh(e){if(this.tab!=="board"&&!e)return;let t=this.sys.gpio,i=t.hw;for(let[s,n]of this.pinEls||[]){let o=t.pins.get(s);if(!o)continue;let l=o.mode!=="in"?t.level(s):i&&i.has(s)?i.quietLevel(s):t.read(s),a=o.mode==="pwm"?"pwm":o.mode==="out"?o.out?"ohi":"olo":o.used||o.watch?l?"ihi":"ilo":l?"fhi":"flo";n.dataset.st!==a&&(n.dataset.st=a);let h=this.stripEls&&this.stripEls.get(s);h&&h.dataset.st!==a&&(h.dataset.st=a),a==="pwm"?n.querySelector(".pst").style.opacity=String(.25+o.duty*.75):n.querySelector(".pst").style.opacity=""}if(this.userLed){let s=this.sys.info.led,n=t.pins.has(s)&&t.drive(s)||0;this.userLed.style.setProperty("--on",String(n)),this.userLed.classList.toggle("on",n>.02)}}loop(){this.raf=requestAnimationFrame(()=>this.loop());let e=performance.now();if(this.actLed&&this.tab==="board"){let s=this.sys.running?Math.sin(e/37)+Math.sin(e/13)>.4:e%4e3<90;s!==this.actOn&&(this.actOn=s,this.actLed.classList.toggle("on",s))}!this.circuit.engine&&this.sys.running&&!(this.noAutoUntil>e)&&this.powerOn();let t=this.programRunning();t!==this.lastRunning&&(this.lastRunning=t,this.updateRun())}boardSheet(){let e=(0,L.h)("div",{class:"pi-boards"});for(let i of rt.BOARD_ORDER){let s=rt.BOARDS[i];e.appendChild((0,L.h)("button",{class:"pi-bopt"+(i===this.sys.board?" active":""),onclick:()=>{t.close(),i!==this.sys.board&&this.switchBoard(i)}},(0,L.h)("div",{class:"pi-bthumb",html:(0,rt.boardSVG)(i,`th-${i}-`)}),(0,L.h)("div",{},(0,L.h)("b",{},s.name),(0,L.h)("small",{},`${s.cpu} \xB7 ${s.ram}`),(0,L.h)("small",{class:"muted"},s.kind==="pico"?"MicroPython \xB7 Thonny":"Desktop (with Terminal) \xB7 Thonny \xB7 Python 3"))))}let t=new L.Sheet({title:"Choose a board",icon:"chip",content:e,height:"80vh"}).open()}start(e={}){if(e.board&&rt.BOARDS[e.board]&&e.board!==this.sys.board&&this.switchBoard(e.board,!0),e.example){let t=(this.isPico?rl.PICO_EXAMPLES:rl.PI_EXAMPLES).find(i=>i.file===e.example);if(!t)return;this.thonny.openExample(t),this.isPico&&(this.chosenFile=null),this.drawFileChip(),this.setTab(t.circuit||t.parts&&t.parts.length?"circuit":"thonny")}else e.newProject&&this.newProject()}newProject(){this.stopCircuit(),this.saveCircuit(),this.circuit.load((0,Mi.boardOnly)(this.sys.board)),this.saveCircuit();let e=this.sys.fs,t=this.isPico?"":"/home/pi",i=1;for(;e.isFile(`${t}/project${i}.py`);)i++;let s=`${t}/project${i}.py`;e.write(s,this.isPico?z2:W2),this.chosenFile=s,this.drawFileChip(),this.thonny.open(s),this.setTab("circuit"),(0,L.toast)(`New project: add parts with \uFF0B, then write project${i}.py in Thonny`,"ok")}switchBoard(e,t=!1){this.stopCircuit(),this.saveCircuit(),this.sys.setBoard(e),t||(0,L.toast)(`${rt.BOARDS[e].name} ready`,"ok")}pinSheet(e){let t=(0,rt.headerOf)(this.sys.board).find(l=>l.phys===e);if(!t)return;let i=this.sys.gpio,s=[["Physical pin",String(e)],["Type",{power3:"3.3 V power",power5:"5 V power",gnd:"Ground",gpio:"GPIO",i2c:"GPIO (I\xB2C)",spi:"GPIO (SPI)",uart:"GPIO (UART)",id:"GPIO (HAT ID EEPROM)",adc:"GPIO + ADC",sys:"System pin"}[t.type]]];if(t.gpio!=null){let l=i.pins.get(t.gpio);s.push([this.isPico?"GP number":"BCM number",String(t.gpio)]),t.alt&&s.push(["Alt functions",t.alt]),s.push(["Mode",l.mode==="pwm"?`PWM ${l.freq} Hz, ${Math.round(l.duty*100)}%`:l.mode==="out"?"Output":"Input"]),s.push(["Level",(l.mode!=="in"?i.level(t.gpio):i.hw&&i.hw.has(t.gpio)?i.hw.quietLevel(t.gpio):i.read(t.gpio))?"HIGH (3.3 V)":"LOW (0 V)"]),l.mode==="in"&&s.push(["Pull",l.pull==="up"?"Pull-up":l.pull==="down"?"Pull-down":"None (floating)"]);let a=(this.isPico?"GP":"GPIO")+t.gpio,h=this.circuit.boardPart(),c=h?this.circuit.project.wires.filter(u=>u.from.part===h.id&&u.from.pin===a||u.to.part===h.id&&u.to.pin===a).length:0;s.push(["Wires on the canvas",String(c)]),s.push(["Python",this.isPico?`Pin(${t.gpio})`:`LED(${t.gpio}) \xB7 Button(${t.gpio}) \xB7 GPIO.setup(${t.gpio}, \u2026)`])}else t.type==="power3"?s.push(["Note","Max ~50 mA from the 3V3 pins."]):t.type==="power5"&&s.push(["Note","Straight from the power supply. Never connect 5 V to a GPIO pin!"]);let n=(0,L.h)("div",{class:"pin-info"},...s.map(([l,a])=>(0,L.h)("div",{class:"spec"},(0,L.h)("span",{},l),(0,L.h)("b",{},a))));n.appendChild((0,L.h)("button",{class:"btn btn-ghost",html:`${(0,Fe.icon)("circuit",16)}<span>Wire it in the Circuit tab</span>`,onclick:()=>{o.close(),this.setTab("circuit")}}));let o=new L.Sheet({title:t.gpio!=null?`${(0,rt.pinLabel)(this.sys.board,t.gpio)} \xB7 pin ${e}`:`${t.name} \xB7 pin ${e}`,icon:"pin",content:n}).open()}menu(e){(0,L.popupMenu)(e,[{icon:"chip",label:"Change board",action:()=>this.boardSheet()},{icon:"fullscreen",label:this.fullscreen?"Exit full screen":"Full screen",action:()=>this.setFullscreen(!this.fullscreen)},{icon:this.audio.enabled?"bell":"close",label:this.audio.enabled?"Mute buzzer sound":"Turn buzzer sound on",action:()=>{this.audio.enabled=!this.audio.enabled,this.audio.enabled||this.audio.stopAll();try{localStorage.setItem("rapti.pi.mute",this.audio.enabled?"0":"1")}catch{}}},"-",{icon:"restart",label:"Default circuit",action:async()=>{await(0,L.confirmDialog)("Default circuit","Replace the circuit with the default parts? (Undo brings it back.)","Replace")&&(this.stopCircuit(),this.circuit.load((0,Mi.defaultCircuit)(this.sys.board)),this.saveCircuit(),this.setTab("circuit"))}},{icon:"trash",label:"Clear the circuit (keep the board)",danger:!0,action:async()=>{await(0,L.confirmDialog)("Clear the circuit","Remove every part and wire except the board? (Undo brings them back.)","Clear",!0)&&(this.stopCircuit(),this.circuit.load((0,Mi.boardOnly)(this.sys.board)),this.saveCircuit(),this.setTab("circuit"))}},{icon:"trash",label:this.isPico?"Erase the Pico flash":"Reset the SD card (files)",danger:!0,action:()=>this.resetFiles()},"-",{icon:"info",label:"About the simulator",action:()=>this.about()}])}async resetFiles(){await(0,L.confirmDialog)(this.isPico?"Erase the flash":"Reset the SD card","All your files on this board go back to the examples. Continue?","Reset",!0)&&(this.sys.resetFs(),this.thonny.onSys("board"),(0,L.toast)(this.isPico?"Flash erased":"SD card reset","ok"))}about(){let e=(0,L.h)("div",{class:"dialog-body pi-about"},(0,L.h)("p",{},"Python runs on a real MicroPython 1.29 interpreter compiled to WebAssembly, inside the app (it needs no real internet: the simulated Wi-Fi network is built in)."),(0,L.h)("p",{},"The Circuit tab uses the same parts and circuit solver as the Arduino simulator: wire LEDs with resistors, buttons, sensors, motors, displays \u2026 to the header, and the GPIOs drive and read the real circuit (3.3 V logic, ~16 mA per pin, pull-ups, 5 V warnings)."),(0,L.h)("p",{},"Raspberry Pi 5 / 4: Python 3 style programs with gpiozero, RPi.GPIO, neopixel, adafruit_dht, RPLCD / i2c_lcd, adafruit_ssd1306 (OLED), tm1637, max7219 + spidev, requests, flask, http.server, socket, paho-mqtt and psutil. Pico boards: MicroPython machine (I2C, SPI), rp2, neopixel, dht, ssd1306, tm1637, max7219, i2c_lcd and \u2014 on the Pico W \u2014 network, urequests, umqtt and ntptime."),(0,L.h)("p",{class:"muted"},"Not simulated: a real Linux kernel, real apt / pip installs, the camera, PIO programs, CPython-only libraries such as numpy or OpenCV."));new L.Sheet({title:"About the Raspberry Pi Lab",icon:"info",content:e}).open()}onSys(e){e==="board"?(this.isPico&&this.tab==="desktop"&&this.setTab("circuit"),this.sys.gpio.parts=[],this.drawNav(),this.drawBoard(),this.circuit.load(this.loadCircuit(this.sys.board),{undoable:!1}),this.chosenFile=null,this.drawFileChip(),this.panes_.board.scrollTop=0):e==="files"?this.drawFileChip():e==="input"?(this.tab==="circuit"||this.tab==="board"||this.tab==="desktop"&&!this.desktop.thonnyWin()||this.tab==="thonny"&&!this.vis.includes("output"))&&this.showOutput():(e==="run"||e==="proc")&&(this.updateRun(),this.drawFileChip())}mount(e){e.appendChild(this.root),this.unback=(0,L.pushBack)(()=>this.onBack()),this.setTab(this.tab),this.loop(),this.audioResume=()=>{this.audio.resume(),this.circuit.audio.resume()},this.root.addEventListener("pointerdown",this.audioResume),this.circuit.project.parts.length<=1&&this.circuit.showHint("Tap \uFF0B to add parts, tap a pin and then another pin to draw a wire, then Run.")}onBack(){let e=()=>{this.unback=(0,L.pushBack)(()=>this.onBack())};if(this.fullscreen){this.setFullscreen(!1),e();return}if(this.tab==="circuit"&&this.circuit.canvas.wiring){this.circuit.canvas.cancelWiring(),e();return}if(this.tab==="circuit"&&this.circuit.canvas.selection){this.circuit.canvas.select(null),e();return}if(this.tab==="desktop"&&this.desktop.top&&this.desktop.wins.length){this.desktop.close(this.desktop.top),e();return}if(this.tab!=="circuit"){this.setTab("circuit"),e();return}this.unback=null,this.leave()}leave(){this.fullscreen&&this.setFullscreen(!1),this.saveCircuit(),this.app.showHome()}unmount(){cancelAnimationFrame(this.raf),this.ro&&this.ro.disconnect(),this.unback&&this.unback(),this.unback=null,this.thonny.hidden(),this.sys.gpio.attachHw(null),this.circuit.unmount(),this.sys.killProcess(),this.audio.stopAll(),this.audio.close&&this.audio.close(),this.offSys(),this.offGpio(),this.fullscreen&&Ri.Native.setImmersive(!1),this.root.remove()}saveNow(){this.thonny.cur&&(this.thonny.cur.text=this.thonny.editor.value,this.thonny.saveTabs()),this.saveCircuit()}onPause(){this.saveNow(),this.audio.suspend(),this.circuit.audio.suspend(),this.circuit.engine&&(this.circuit.engine.paused=!0)}onResume(){this.circuit.engine&&(this.circuit.engine.paused=!1,this.circuit.engine.lastWall=null)}};var W2=`# My Raspberry Pi project
# 1. Circuit tab: add parts with +, then wire them to the header pins
# 2. Write the program here and press Run
from gpiozero import LED
from time import sleep

led = LED(17)          # GPIO17 = pin 11

while True:
    led.toggle()
    sleep(0.5)
`,z2=`# My Raspberry Pi Pico project (MicroPython)
# 1. Circuit tab: add parts with +, then wire them to the GP pins
# 2. Write the program here and press Run
from machine import Pin
import time

led = Pin(15, Pin.OUT)

while True:
    led.toggle()
    time.sleep(0.5)
`;window.__raptiPi={PiScreen:sl};})();
