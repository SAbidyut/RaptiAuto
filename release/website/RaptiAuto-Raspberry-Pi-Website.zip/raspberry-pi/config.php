<?php
// RaptiAuto — Raspberry-Pi section: settings of this page.
if (!defined('RAPTI')) { http_response_code(403); exit; }

return array(
    // which part of RaptiAuto this page shows: 'arduino', 'plc' or 'pi' (needs the matching js/ files)
    'section' => 'pi',

    // the browser tab title and the search-engine description
    'title' => 'Raspberry Pi Lab — RaptiAuto',
    'description' => 'A virtual Raspberry Pi 5, Pi 4 and Pico: wire a breadboard and run Python in Thonny, right in your browser. By RAPTI.',

    // URL of this folder. Leave it '' when index.php is opened from this folder (https://your-site/raspberry-pi/).
    // When the page is included from somewhere else, write the folder's URL with a / at the end, e.g. '/raspberry-pi/'.
    'base' => '',

    // added to every css / js URL (?v=…) so visitors get the new files after an update
    'version' => '2.32.0-d93c2fae',

    // style sheets, in this order
    'css' => array('css/pi.css', 'css/style.css', 'css/theme.css'),
);
